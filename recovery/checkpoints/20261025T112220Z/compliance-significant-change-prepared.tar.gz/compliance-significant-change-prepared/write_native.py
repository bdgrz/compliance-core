from pathlib import Path
R=Path('/tmp/compliance-significant-change-prepared/work')
def put(p,s):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
C='src/Compliance.Common/Features/Changes/'
K='src/Compliance.Core/Features/Changes/'
p=R/(C+'SignificantChangeView.cs');s=p.read_text().replace('assessment.RelatedReviewWorkIds.All(id =>','assessment.RelatedReviewWorkIds.Concat(assessment.RelatedCorrectiveActionIds).All(id =>');p.write_text(s)
put(C+'SignificantChangeAuthorityHeader.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Bounded current authority; full versions, assessments and governed references remain immutable content.</summary>
public sealed record SignificantChangeAuthorityHeader(Uuid TenantId, Uuid ProgramId, Uuid SignificantChangeId,
    long Revision, int CurrentVersionNumber, string ContentSha256, string Title, string Status,
    string HandlingClass, DateOnly EffectiveOn, DateOnly? EffectiveThrough, Uuid OwnerMemberId,
    Uuid ActorMemberId, string ActorDisplay, DateTimeOffset UpdatedAt, bool PeriodCloseEligible);
''')
put(C+'ISignificantChangeFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

public interface ISignificantChangeFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid SubjectId { get; }
    long Revision { get; }
    Uuid? ActorMemberId { get; }
    DateTimeOffset OccurredAt { get; }
    SignificantChangeAuthorityHeader Header { get; }
    ImmutableContentRef CurrentContent { get; }
    ImmutableContentRef Change { get; }
    ImmutableContentRef OperationResult { get; }
    long NativeSequence { get; }
    int ChangeCount { get; }
}
''')
names=['SignificantChangeRecorded','SignificantChangeRevised','SignificantChangeImpactAssessed','ImpactReviewWorkLinked','SignificantChangeSystemDescriptionDecisionRecorded']
for name in names:
 import re
 p=R/(C+name+'.cs');s=p.read_text();tag=re.search(r'\[Discriminator\("([^"]+)", (\d+)\)\]',s)
 put(C+name+'.cs',f'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

/// <summary>One compact significant-change fact and its exact immutable local mutation.</summary>
[Discriminator("{tag[1]}", {int(tag[2])+1})]
public sealed record {name}(Uuid TenantId, Uuid SubjectId, long Revision, Uuid? ActorMemberId,
    SignificantChangeAuthorityHeader Header, ImmutableContentRef CurrentContent, ImmutableContentRef Change,
    long NativeSequence, int ChangeCount, OperationProvenance Operation, ImmutableContentRef FirstResponse,
    ImmutableContentRef OperationResult, DateTimeOffset OccurredAt) : DomainEvent, ISignificantChangeFact;
''')
put(K+'SignificantChangeMutation.cs','''namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Immutable proof of the exact before body and one verified business transition.</summary>
public sealed record SignificantChangeMutation(string Kind, string? BeforeSha256, string AfterSha256,
    SignificantChangeView After, bool Changed);
''')
put(K+'SignificantChangeContentStore.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Publishes exact immutable business content before accepting a bounded native fact.</summary>
public static class SignificantChangeContentStore
{
    public const string BodySchema = "significant-change-current.v1";
    public const string ChangeSchema = "significant-change-mutation.v1";
    public static SignificantChangeAuthorityHeader Header(SignificantChangeView state)
    {
        var current = state.Current ?? throw new ImmutableContentIntegrityException("The change has no current content.");
        return new(state.TenantId, state.ProgramId, state.SignificantChangeId, state.Revision,
            state.CurrentVersionNumber, current.ContentSha256, current.Content.Title, state.Status,
            current.Content.HandlingClass, current.Content.EffectiveOn, current.Content.EffectiveThrough,
            current.Content.OwnerMemberId, state.ActorMemberId, state.ActorDisplay, state.UpdatedAt, state.PeriodCloseEligible);
    }
    public static async ValueTask<FrozenSignificantChangeMutation> FreezeAsync(IImmutableContentStore content,
        SignificantChangeView? before, SignificantChangeRules rules, string kind, CancellationToken ct)
    {
        var after = rules.Current ?? throw new ImmutableContentIntegrityException("The change has no current content.");
        var realm = after.TenantId.ToString();
        var body = await content.WriteJsonAsync(realm, Uuid.CreateVersion5(after.SignificantChangeId,
            BodySchema + ":" + AuthoredIntentDigest.Compute(after)), BodySchema, after, ct).ConfigureAwait(false);
        var mutation = new SignificantChangeMutation(kind, before is null ? null : AuthoredIntentDigest.Compute(before),
            AuthoredIntentDigest.Compute(after), after, rules.PendingChanges.Count > 0);
        var change = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), ChangeSchema, mutation, ct).ConfigureAwait(false);
        return new(Header(after), body, change, mutation, before, after);
    }
    public static DomainEvent Fact(FrozenSignificantChangeMutation frozen, long sequence,
        OperationProvenance operation, ImmutableContentRef first, ImmutableContentRef result)
    {
        var h = frozen.Header;
        var count = frozen.Mutation.Changed ? 1 : 0;
        return frozen.Mutation.Kind switch
        {
            nameof(RecordSignificantChange) => new SignificantChangeRecorded(h.TenantId,h.SignificantChangeId,h.Revision,h.ActorMemberId,h,frozen.Body,frozen.Change,sequence,count,operation,first,result,operation.AcceptedAt),
            nameof(ReviseSignificantChange) => new SignificantChangeRevised(h.TenantId,h.SignificantChangeId,h.Revision,h.ActorMemberId,h,frozen.Body,frozen.Change,sequence,count,operation,first,result,operation.AcceptedAt),
            nameof(AssessSignificantChange) => new SignificantChangeImpactAssessed(h.TenantId,h.SignificantChangeId,h.Revision,h.ActorMemberId,h,frozen.Body,frozen.Change,sequence,count,operation,first,result,operation.AcceptedAt),
            nameof(LinkImpactReviewWork) => new ImpactReviewWorkLinked(h.TenantId,h.SignificantChangeId,h.Revision,h.ActorMemberId,h,frozen.Body,frozen.Change,sequence,count,operation,first,result,operation.AcceptedAt),
            nameof(RecordSignificantChangeSystemDescriptionDecision) => new SignificantChangeSystemDescriptionDecisionRecorded(h.TenantId,h.SignificantChangeId,h.Revision,h.ActorMemberId,h,frozen.Body,frozen.Change,sequence,count,operation,first,result,operation.AcceptedAt),
            _ => throw new ImmutableContentIntegrityException("The change mutation has another command kind."),
        };
    }
    public static bool ValidMutation(SignificantChangeView? before, SignificantChangeView after,
        SignificantChangeMutation mutation)
    {
        var rules = new SignificantChangeRules(after.TenantId, after.ProgramId, after.SignificantChangeId);
        if (rules.ValidateState(after) is not null || mutation.AfterSha256 != AuthoredIntentDigest.Compute(after) ||
            mutation.BeforeSha256 != (before is null ? null : AuthoredIntentDigest.Compute(before)) ||
            AuthoredIntentDigest.Compute(mutation.After) != mutation.AfterSha256)
            return false;
        if (!mutation.Changed)
            return before is not null && mutation.BeforeSha256 == mutation.AfterSha256 &&
                mutation.Kind is nameof(LinkImpactReviewWork) or nameof(RecordSignificantChangeSystemDescriptionDecision);
        if (before is null)
            return mutation.Kind == nameof(RecordSignificantChange) && SignificantChangeRules.ValidInitialState(after);
        var transition = mutation.Kind switch
        {
            nameof(ReviseSignificantChange) => "revise",
            nameof(AssessSignificantChange) => "assessment",
            nameof(LinkImpactReviewWork) => "work_link",
            nameof(RecordSignificantChangeSystemDescriptionDecision) => "description_decision",
            _ => "",
        };
        return SignificantChangeRules.ValidTransition(before, after, after.ActorMemberId, transition);
    }
    internal static void Apply(SignificantChangeRules rules, SignificantChangeMutation mutation)
    {
        if (!mutation.Changed)
            return;
        var state = mutation.After;
        object value = mutation.Kind switch
        {
            nameof(RecordSignificantChange) => new SignificantChangeRecordedBody(state.TenantId,state.SignificantChangeId,state.Revision,state.ActorMemberId,state,state.UpdatedAt),
            nameof(ReviseSignificantChange) => new SignificantChangeRevisedBody(state.TenantId,state.SignificantChangeId,state.Revision,state.ActorMemberId,state,state.UpdatedAt),
            nameof(AssessSignificantChange) => new SignificantChangeImpactAssessedBody(state.TenantId,state.SignificantChangeId,state.Revision,state.ActorMemberId,state,state.UpdatedAt),
            nameof(LinkImpactReviewWork) => new ImpactReviewWorkLinkedBody(state.TenantId,state.SignificantChangeId,state.Revision,state.ActorMemberId,state,state.UpdatedAt),
            nameof(RecordSignificantChangeSystemDescriptionDecision) => new SignificantChangeSystemDescriptionDecisionRecordedBody(state.TenantId,state.SignificantChangeId,state.Revision,state.ActorMemberId,state,state.UpdatedAt),
            _ => throw new ImmutableContentIntegrityException("The change mutation has another command kind."),
        };
        rules.Apply(value);
    }
}
''')
put(K+'FrozenSignificantChangeMutation.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Changes;

public sealed record FrozenSignificantChangeMutation(SignificantChangeAuthorityHeader Header,
    ImmutableContentRef Body, ImmutableContentRef Change, SignificantChangeMutation Mutation,
    SignificantChangeView? Before, SignificantChangeView After);
''')
put(K+'SignificantChange.cs','''using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Hosting.Persistence;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Compact native change authority. Governed references, assessments and history remain immutable content.</summary>
public sealed class SignificantChange : Aggregate
{
    public const string Area = "significant-changes";
    readonly Uuid _tenantId;
    readonly Uuid _requestedProgramId;
    public SignificantChange(Uuid tenantId, Uuid programId, Uuid changeId, Uuid selectedCommandId = default)
        : base(changeId, new EventStreamAddress(tenantId.ToString(), Area, changeId.ToString()))
    {
        _tenantId = tenantId;
        _requestedProgramId = programId;
        Acceptance = new NativeAcceptance(selectedCommandId);
        On<SignificantChangeRecorded>(ApplyFact);
        On<SignificantChangeRevised>(ApplyFact);
        On<SignificantChangeImpactAssessed>(ApplyFact);
        On<ImpactReviewWorkLinked>(ApplyFact);
        On<SignificantChangeSystemDescriptionDecisionRecorded>(ApplyFact);
    }
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => Header?.ProgramId ?? _requestedProgramId;
    public long Revision => Header?.Revision ?? 0;
    public SignificantChangeAuthorityHeader? Header { get; private set; }
    public ImmutableContentRef? CurrentContent { get; private set; }
    public long NativeSequence { get; private set; }
    public NativeAcceptance Acceptance { get; }
    public static string AssessmentSha256(SignificantChangeImpactView assessment) => SignificantChangeRules.AssessmentSha256(assessment);

    public Result Append(DomainEvent value, FrozenSignificantChangeMutation prepared, long sequence, ulong position)
    {
        if (NativeSequence != sequence || CommittedStreamPosition != position)
            return Fail("The significant change changed while its exact content was prepared.", true);
        if (value is not ISignificantChangeFact fact ||
            (Header is null ? prepared.Before is not null : prepared.Before is null || SignificantChangeContentStore.Header(prepared.Before) != Header) ||
            fact.Header != prepared.Header || fact.CurrentContent != prepared.Body || fact.Change != prepared.Change ||
            fact.ChangeCount != (prepared.Mutation.Changed ? 1 : 0) ||
            !SignificantChangeContentStore.ValidMutation(prepared.Before, prepared.After, prepared.Mutation) ||
            prepared.Header != SignificantChangeContentStore.Header(prepared.After))
            return Fail("The significant-change mutation does not carry its exact verified local transition.");
        try
        {
            Validate(value, fact);
            if (DomainEventPayload.Size(value) > DomainEventPayload.MaximumBytes)
                return Fail("The native significant-change fact exceeds the bounded event payload size.");
        }
        catch (InvalidOperationException)
        {
            return Fail("The significant-change mutation has an invalid native binding.");
        }
        RaiseEvent(value);
        return Result.Success;
    }
    void ApplyFact(DomainEvent value)
    {
        var fact = (ISignificantChangeFact)value;
        Validate(value, fact);
        Header = fact.Header;
        CurrentContent = fact.CurrentContent;
        NativeSequence = fact.NativeSequence;
        Acceptance.Observe(value);
    }
    void Validate(DomainEvent value, ISignificantChangeFact fact)
    {
        var h = fact.Header;
        var op = fact.Operation;
        var kind = value switch
        {
            SignificantChangeRecorded => nameof(RecordSignificantChange),
            SignificantChangeRevised => nameof(ReviseSignificantChange),
            SignificantChangeImpactAssessed => nameof(AssessSignificantChange),
            ImpactReviewWorkLinked => nameof(LinkImpactReviewWork),
            SignificantChangeSystemDescriptionDecisionRecorded => nameof(RecordSignificantChangeSystemDescriptionDecision),
            _ => "",
        };
        if (op is null || op.Actor is null || h is null)
            throw new InvalidOperationException("A native change requires its exact operation and current authority.");
        OwnerProvenance.RequireOwn(this, op.LogicalId, op);
        var memberCommand = kind is nameof(RecordSignificantChange) or nameof(ReviseSignificantChange) or nameof(AssessSignificantChange);
        if (fact.TenantId != _tenantId || h.TenantId != _tenantId || h.ProgramId == Uuid.Empty || h.SignificantChangeId != Id ||
            fact.SubjectId != Id || fact.Revision != h.Revision || h.Revision <= 0 || h.CurrentVersionNumber is < 1 or > 32 ||
            fact.NativeSequence != NativeSequence + 1 || fact.ActorMemberId != h.ActorMemberId || h.ActorMemberId == Uuid.Empty ||
            string.IsNullOrWhiteSpace(h.ActorDisplay) || h.ActorDisplay.Length > 200 || string.IsNullOrWhiteSpace(h.Title) || h.Title.Length > 300 ||
            !Hex(h.ContentSha256) || h.UpdatedAt == default || fact.OccurredAt != op.AcceptedAt || op.AcceptedAt == default ||
            !Reference(fact.CurrentContent, SignificantChangeContentStore.BodySchema) || !Reference(fact.Change, SignificantChangeContentStore.ChangeSchema) ||
            !Reference(fact.FirstResponse, FirstResponses.Schema) || !Reference(fact.OperationResult, "mutation-result-content.v1") ||
            op.CommandKind != kind || op.RootOperationId != op.LogicalId || op.CausationEventId is not null || op.Episode != Id.ToString() ||
            op.Owner != Stream || op.AffectedOwner != Stream || op.ExpectedRevisionOwner != Stream || op.FirstOwner != Stream ||
            !Hex(op.AuthoredIntentSha256) || fact.ChangeCount is < 0 or > 1 ||
            memberCommand && (op.Actor.Kind != "member" || !Uuid.TryParse(op.Actor.Id, out var actor) || actor != h.ActorMemberId) ||
            !memberCommand && op.Actor.Kind != "system")
            throw new InvalidOperationException("The significant change has another exact native owner, actor or content binding.");
        if (Header is null)
        {
            if (kind != nameof(RecordSignificantChange) || h.Revision != 1 || h.CurrentVersionNumber != 1 || h.Status != "recorded" ||
                fact.ChangeCount != 1 || op.LogicalId != Id || op.OriginalExpectedRevision is not null)
                throw new InvalidOperationException("A significant change begins with its own identified creation.");
            return;
        }
        if (h.ProgramId != Header.ProgramId || kind == nameof(RecordSignificantChange) ||
            h.Revision != Header.Revision + fact.ChangeCount || h.CurrentVersionNumber < Header.CurrentVersionNumber ||
            h.CurrentVersionNumber > Header.CurrentVersionNumber + 1 ||
            fact.ChangeCount == 0 && (h != Header || fact.CurrentContent != CurrentContent) ||
            kind is nameof(ReviseSignificantChange) or nameof(AssessSignificantChange) && op.OriginalExpectedRevision != unchecked((ulong)Header.Revision) ||
            kind is nameof(LinkImpactReviewWork) or nameof(RecordSignificantChangeSystemDescriptionDecision) && op.OriginalExpectedRevision is not null)
            throw new InvalidOperationException("A significant-change transition cannot rewrite identity or its original revision gate.");
    }
    static bool Reference(ImmutableContentRef? value, string schema) => value is not null && value.Schema == schema &&
        value.ContentId != Uuid.Empty && value.Length > 0 && Hex(value.Sha256);
    static bool Hex(string? value) => value is { Length: 64 } && value.All(Uri.IsHexDigit);
    static Result Fail(string message, bool transient = false) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
