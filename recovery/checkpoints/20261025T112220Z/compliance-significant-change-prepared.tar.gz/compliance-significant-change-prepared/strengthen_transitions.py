from pathlib import Path
R=Path('/tmp/compliance-significant-change-prepared/work');K='src/Compliance.Core/Features/Changes/'
p=R/(K+'SignificantChangeRules.cs');s=p.read_text();i=s.index('    internal static bool ValidTransition(')
s=s[:i]+'''    /// <summary>Re-executes the actual business rule against the exact prior body; scalar/header checks alone are insufficient.</summary>
    internal static bool VerifyTransition(SignificantChangeView? before, SignificantChangeView after, string kind)
    {
        var rules = new SignificantChangeRules(after.TenantId,after.ProgramId,after.SignificantChangeId);
        if (before is not null && rules.ValidateState(before) is not null)
            return false;
        rules._current = before;
        CommandFailure? failure;
        switch (kind)
        {
            case nameof(RecordSignificantChange):
                failure = rules.Record(after.Current!.Content,after.ActorMemberId,after.ActorDisplay,after.UpdatedAt);
                break;
            case nameof(ReviseSignificantChange) when before is not null:
                failure = rules.Revise(before.Revision,after.Current!.Content,after.Current.ChangeReason,
                    after.ActorMemberId,after.ActorDisplay,after.UpdatedAt);
                break;
            case nameof(AssessSignificantChange) when before is not null && after.CurrentAssessment is { } impact:
                failure = rules.Assess(before.Revision,new SignificantChangeImpactContent(impact.Significance,impact.Rationale,
                    impact.ChangesSystemBoundary,impact.ChangesServiceCommitment,impact.ChangesKeyControl,impact.ChangesInScopeInfrastructure,
                    impact.ImpactDomains,impact.AffectedRecords,impact.RelatedReviewWorkIds,impact.RelatedCorrectiveActionIds,
                    impact.RelatedExceptionIds,impact.EvidenceArtifactIds,impact.RequiresSystemDescriptionReview),
                    after.ActorMemberId,after.ActorDisplay,after.UpdatedAt);
                break;
            case nameof(LinkImpactReviewWork) when before is not null:
                failure = rules.LinkReviewWork(before.Revision,after.ReviewWorkLinks.Skip(before.ReviewWorkLinks.Count)
                    .Select(item => item.WorkId).ToArray(),after.ActorMemberId,after.ActorDisplay,after.UpdatedAt);
                break;
            case nameof(RecordSignificantChangeSystemDescriptionDecision) when before is not null && after.CurrentSystemDescriptionDecision is { } decision:
                failure = rules.RecordSystemDescriptionDecision(before.Revision,decision.Decision,decision.DecisionId,decision.Rationale,
                    decision.DecidedByMemberId,decision.DecidedByDisplay,decision.DecidedAt);
                break;
            default:
                return false;
        }
        return failure is null && rules.Current is not null && Digest(rules.Current) == Digest(after);
    }

'''+s[i:];p.write_text(s)
p=R/(K+'SignificantChangeContentStore.cs');s=p.read_text();a=s.index('        if (before is null)\n            return mutation.Kind');b=s.index('    internal static void Apply',a);s=s[:a]+'''        return SignificantChangeRules.VerifyTransition(before,after,mutation.Kind);
    }
'''+s[b:];p.write_text(s)
