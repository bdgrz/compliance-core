from pathlib import Path
import difflib,hashlib,json,re
P=Path('/tmp/compliance-significant-change-prepared')
def sha(b):return hashlib.sha256(b).hexdigest()
def patch(folders,predicate,out):
 base,work=[P/f for f in folders];rows=[];parts=[]
 for after in sorted(work.rglob('*')):
  if not after.is_file():continue
  rel=after.relative_to(work).as_posix()
  if not predicate(rel):continue
  before=base/rel;bb=before.read_bytes() if before.exists() else b'';ab=after.read_bytes()
  if before.exists() and bb==ab:continue
  parts.append(''.join(difflib.unified_diff(bb.decode().splitlines(keepends=True),ab.decode().splitlines(keepends=True),fromfile='a/'+rel if before.exists() else '/dev/null',tofile='b/'+rel)))
  rows.append({'path':rel,'before_sha256':sha(bb) if before.exists() else None,'after_sha256':sha(ab),'after_bytes':len(ab)})
 (P/out).write_text(''.join(parts));return rows
source=patch(['base','work'],lambda p:p.startswith('src/') and p not in ['src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs'],'implementation.patch')
tests=patch(['base','work'],lambda p:p.startswith('test/'),'tests.patch')
shared=patch(['shared-base','shared-work'],lambda p:True,'shared.patch')
# Snapshot original acceptance lists and meaningful new names.
new=[];removed=[]
for row in tests:
 b=P/'base'/row['path'];w=P/'work'/row['path'];old=set(re.findall(r'\b(Should\w+)\s*\(',b.read_text() if b.exists() else ''));now=set(re.findall(r'\b(Should\w+)\s*\(',w.read_text()));new.extend(sorted(now-old));removed.extend(sorted(old-now))
artifacts={n:{'sha256':sha((P/n).read_bytes()),'bytes':(P/n).stat().st_size} for n in ['implementation.patch','tests.patch','shared.patch','behavioral-red.patch','shared-wiring-deltas.json','static-checks.json']}
manifest={'status':'offline prepared; parent owns format, compilation, RED/green runtime and direct Jev; not runtime validated','implementation':source,'tests':tests,'shared':shared,'new_acceptance_names':new,'removed_acceptance_names':removed,'artifacts':artifacts,'future_baselines':['test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseSources.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseArchive.cs'],'integration_order':['old-API behavioral-red.patch, run each filter independently; reverse standalone patch','parent TypeII stage2 must land before CloseSources/CloseArchive overlays','apply implementation.patch and tests.patch together; reconcile shared.patch to current parent wiring','parent format, strict build, focused Changes+TypeII close suites, full unit, SignificantChangeHttpTests WebIntegration, direct per-file Jev']}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'owned-paths.txt').write_text('\n'.join(r['path'] for r in source+tests)+'\n')
print(json.dumps({'implementation':len(source),'tests':len(tests),'shared':len(shared),'new_methods':len(new),'removed_methods':removed,'artifacts':artifacts},indent=2))
