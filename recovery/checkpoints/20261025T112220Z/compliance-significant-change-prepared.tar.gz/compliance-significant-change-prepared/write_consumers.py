from pathlib import Path
exec(Path('/tmp/compliance-significant-change-prepared/write_native.py').read_text().split("p=R/(C+'SignificantChangeView.cs')")[0])
p=R/(K+'ISignificantChangeDirectoryReader.cs');s=p.read_text().replace('{\n','{\n    ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId, CancellationToken ct = default);\n\n',1);p.write_text(s)
s=Path('src/Compliance.Core/Features/AuditPackages/AuditPackageDirectoryReadConsistency.cs').read_text().replace('AuditPackages','Changes').replace('AuditPackage','SignificantChange').replace('SignificantChangeManifest.Area','SignificantChange.Area').replace('audit-package','significant-change');put(K+'SignificantChangeDirectoryReadConsistency.cs',s)
p=R/(K+'SignificantChangeDirectorySchema.cs');s=p.read_text().replace('KvDirectory<SignificantChangeView, Uuid>','KvDirectory<SignificantChangeDirectoryEntry, Uuid>').replace('"significant_change_details"','"significant_change_authority"').replace('Default.SignificantChangeView','Default.SignificantChangeDirectoryEntry');p.write_text(s)
put(K+'SignificantChangeDirectoryEntry.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Bounded discovery authority; current details are read from the exact native source.</summary>
public sealed record SignificantChangeDirectoryEntry(Uuid TenantId, Uuid ProgramId, Uuid SignificantChangeId,
    long NativeSequence, SignificantChangeAuthorityHeader Header);
''')
put(K+'FitzSignificantChangeDirectory.cs','''using Cntryl.Fitz;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

sealed class FitzSignificantChangeDirectory(IKvClient client, SignificantChangeReader changes)
    : FitzKvProjectionStore(client,"kv://bdgrz/significant-change-directory/projection-v2",SignificantChangeDirectoryProjector.ProjectorName),
      ISignificantChangeDirectoryReader,ISignificantChangeDirectoryProjection
{
    public async ValueTask ApplyAsync(DomainEvent value, CancellationToken ct = default)
    {
        if (value is not ISignificantChangeFact fact)
            return;
        var h = fact.Header;
        if (h.TenantId != fact.TenantId || h.SignificantChangeId != fact.SubjectId || h.ProgramId == Uuid.Empty ||
            h.Revision != fact.Revision || fact.NativeSequence < 1 || fact.ActorMemberId != h.ActorMemberId)
            throw new InvalidOperationException("The significant-change directory source has another authority binding.");
        var next = new SignificantChangeDirectoryEntry(h.TenantId,h.ProgramId,h.SignificantChangeId,fact.NativeSequence,h);
        var summary = ToSummary(h);
        var current = await SignificantChangeDirectorySchema.Details.GetAsync(Transaction,h.SignificantChangeId,ct).ConfigureAwait(false);
        if (current is null)
        {
            if (value is not SignificantChangeRecorded || fact.NativeSequence != 1)
                throw new InvalidOperationException("A change must be created before its later directory facts.");
            await SignificantChangeDirectorySchema.Details.InsertAsync(Transaction,next,ct).ConfigureAwait(false);
            await SignificantChangeDirectorySchema.Summaries.InsertAsync(Transaction,summary,ct).ConfigureAwait(false);
            return;
        }
        if (current.TenantId != h.TenantId || current.ProgramId != h.ProgramId)
            throw new InvalidOperationException("A change cannot change its directory scope.");
        if (fact.NativeSequence < current.NativeSequence)
            return;
        if (fact.NativeSequence == current.NativeSequence)
        {
            if (current != next)
                throw new InvalidOperationException("The change directory has conflicting same-sequence authority.");
            return;
        }
        if (fact.NativeSequence != current.NativeSequence+1)
            throw new InvalidOperationException("The change directory skipped a native source fact.");
        var priorSummary = await SignificantChangeDirectorySchema.Summaries.GetAsync(Transaction,h.SignificantChangeId,ct).ConfigureAwait(false)
            ?? throw new InvalidOperationException("A projected change has no discovery summary.");
        await SignificantChangeDirectorySchema.Details.ReplaceAsync(Transaction,current,next,ct).ConfigureAwait(false);
        await SignificantChangeDirectorySchema.Summaries.ReplaceAsync(Transaction,priorSummary,summary,ct).ConfigureAwait(false);
    }
    public async ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId,CancellationToken ct = default) =>
        await LoadCheckpointAsync(EventStreamPattern.ForPattern(tenantId.ToString(),SignificantChange.Area),ct).ConfigureAwait(false);
    public async ValueTask<SignificantChangeView?> GetAsync(Uuid tenantId,Uuid changeId,CancellationToken ct = default)
    {
        SignificantChangeDirectoryEntry? identity;
        await using (var tx = await BeginReadAsync(tenantId.ToString(),ct).ConfigureAwait(false))
            identity = await SignificantChangeDirectorySchema.Details.GetAsync(tx,changeId,ct).ConfigureAwait(false);
        return identity is null ? null : (await changes.ReadAsync(tenantId,identity.ProgramId,changeId,ct).ConfigureAwait(false)).View;
    }
    public async ValueTask<Page<SignificantChangeSummaryView>> ListAsync(Uuid tenantId,Uuid programId,int limit,string? cursor,CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(),ct).ConfigureAwait(false);
        return await SignificantChangeDirectorySchema.Summaries.QueryAsync(tx,SignificantChangeDirectorySchema.ByProgramUpdatedAt.Query()
            .WithPrefix(programId.ToString()).Take(Math.Clamp(limit,1,200)).After(cursor),ct).ConfigureAwait(false);
    }
    static SignificantChangeSummaryView ToSummary(SignificantChangeAuthorityHeader h) =>
        new(h.TenantId,h.ProgramId,h.SignificantChangeId,h.Title,h.Status,h.UpdatedAt);
}
''')
p=R/(K+'SignificantChangeDirectoryProjector.cs');s=p.read_text().replace('ForTenant()','ForTenant(SignificantChange.Area)').replace('DirectoryV1','DirectoryV2');p.write_text(s)
p=R/(K+'GetSignificantChangeHandler.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s;s=s.replace('GetSignificantChangeHandler(ISignificantChangeDirectoryReader directory,','GetSignificantChangeHandler(SignificantChangeReader changes,');s=s.replace('        var change = await directory.GetAsync(request.TenantId, request.ChangeId, ct)\n            .ConfigureAwait(false);','''        try
        {
        var change = (await changes.ReadAsync(request.TenantId,request.ProgramId,request.ChangeId,ct).ConfigureAwait(false)).View;''');pos=s.rfind('    }');s=s[:pos]+'''        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<SignificantChangeView>.Failure(SignificantChangeOperations.ContentFailure(exception));
        }
'''+s[pos:];p.write_text(s)
p=R/(K+'ListSignificantChangesHandler.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s;s=s.replace('RestrictedComplianceRecordVisibility visibility)','RestrictedComplianceRecordVisibility visibility, SignificantChangeDirectoryReadConsistency consistency)');s=s.replace('        var items =', '''        var fence = await consistency.CaptureAsync(request.TenantId,ct).ConfigureAwait(false);
        if (!fence.IsSuccess)
            return Result<Page<SignificantChangeSummaryView>>.Failure(fence.Error!);
        var items =''');s=s.replace('                    items.Add(summary);','''                    items.Add(new SignificantChangeSummaryView(detail.TenantId,detail.ProgramId,detail.SignificantChangeId,
                        current.Content.Title,detail.Status,detail.UpdatedAt));''');s=s.replace('        if (items.Count ==', '        try\n        {\n        if (items.Count ==',1);s=s.replace('        return Result<Page<SignificantChangeSummaryView>>.Success(','''        var confirmed = await consistency.ConfirmUnchangedAndCaughtUpAsync(request.TenantId,fence.Value,ct).ConfigureAwait(false);
        if (!confirmed.IsSuccess)
            return Result<Page<SignificantChangeSummaryView>>.Failure(confirmed.Error!);
        return Result<Page<SignificantChangeSummaryView>>.Success(''',1);needle='''    async ValueTask<bool> HasVisibleAfterAsync''';i=s.index(needle);j=s.rfind('    }',0,i);s=s[:j]+'''        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<Page<SignificantChangeSummaryView>>.Failure(SignificantChangeOperations.ContentFailure(exception));
        }
'''+s[j:];s=s.replace('        catch (KvDirectoryQueryException)','''        catch (ImmutableContentIntegrityException exception)
        {
            return Result<Page<SignificantChangeSummaryView>>.Failure(SignificantChangeOperations.ContentFailure(exception));
        }
        catch (KvDirectoryQueryException)''',1);p.write_text(s)
p=R/(K+'AggregateSystemDescriptionDecisionCorrelationReader.cs');s=p.read_text().replace('Reader(IAggregateReader reader)','Reader(IAggregateReader reader, SignificantChangeReader changes)').replace('var change = await reader.HydrateAsync(new SignificantChange(tenantId, programId, changeId), ct)','var change = await changes.ReadAsync(tenantId, programId, changeId, ct)').replace('change.Current is not','change.View is not');p.write_text(s)
p=R/(K+'RestrictedComplianceRecordMutationAuthorizer.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s;s=s.replace('    IAggregateReader reader,','    IAggregateReader reader, SignificantChangeReader changes,',1);s=s.replace('''            var aggregate = await reader.HydrateAsync(
                new SignificantChange(request.TenantId, request.ProgramId, target.Id), ct)
                .ConfigureAwait(false);
            var current = aggregate.Current;''','''            SignificantChangeView? current;
            try
            {
                current = (await changes.ReadAsync(request.TenantId,request.ProgramId,target.Id,ct).ConfigureAwait(false)).View;
            }
            catch (ImmutableContentIntegrityException exception)
            {
                return Result.Failure(SignificantChangeOperations.ContentFailure(exception));
            }''');p.write_text(s)
# Typed Unit dispatch preserves the existing untyped Incident branch.
p=R/(K+'ImpactReactionOutcomes.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s;i=s.index('    /// <summary>Whether an error');s=s[:i]+'''    public static async ValueTask SendAsync(IRequestBus bus,IRequest<UnitResult> command,IReactorContext context,CancellationToken ct)
    {
        var result = await bus.SendAsync(command,context,ct).ConfigureAwait(false);
        if (!result.IsSuccess && !IsSuperseded(result.Error!))
            throw new ReactionCommandFailedException(result.Error!);
    }

'''+s[i:];p.write_text(s)
p=R/(K+'SystemDescriptionDecisionReactor.cs');s=p.read_text().replace('new RecordSignificantChangeSystemDescriptionDecision(\n                ev.TenantId,','new RecordSignificantChangeSystemDescriptionDecision(\n                EffectIdentity.CommandId(ev.Metadata.EventId,"change:system-description-decision",$"{ev.TenantId}:{changeId}",null),\n                ev.TenantId,',1);i=s.index('new RecordSignificantChangeSystemDescriptionDecision(',s.index('new RecordSignificantChangeSystemDescriptionDecision(')+1);s=s[:i]+s[i:].replace('new RecordSignificantChangeSystemDescriptionDecision(\n                ev.TenantId,','new RecordSignificantChangeSystemDescriptionDecision(\n                EffectIdentity.CommandId(ev.Metadata.EventId,"change:system-description-decision",$"{ev.TenantId}:{ev.Decision.ChangeId}",null),\n                ev.TenantId,',1);p.write_text(s)
put(K+'LinkImpactReviewWorkReactor.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

public sealed partial class LinkImpactReviewWorkReactor(IProjectionCheckpointStore checkpoints,IRequestBus bus,IImmutableContentStore content)
    : Reactor(checkpoints,EventStreamPattern.ForTenant(SignificantChange.Area),WorkloadName),IReactorHandler<SignificantChangeImpactAssessed>
{
    public const string WorkloadName = "SignificantChangeImpactWorkLinksV2";
    public async ValueTask HandleAsync(IReactorContext<SignificantChangeImpactAssessed> context,CancellationToken ct)
    {
        var ev = context.Trigger;
        if (Pattern.IsTenantTemplate || Pattern.Realm != ev.TenantId.ToString() ||
            context.Source.Stream != new SignificantChange(ev.TenantId,ev.Header.ProgramId,ev.SubjectId).Stream ||
            ev.Metadata.EventId == Uuid.Empty || ev.ChangeCount != 1)
            throw new InvalidOperationException("The work-link reaction requires its exact native assessment source.");
        var mutation = await content.ReadJsonAsync<SignificantChangeMutation>(ev.TenantId.ToString(),ev.Change,ct).ConfigureAwait(false);
        var view = await content.ReadJsonAsync<SignificantChangeView>(ev.TenantId.ToString(),ev.CurrentContent,ct).ConfigureAwait(false);
        if (ev.Change.Schema != SignificantChangeContentStore.ChangeSchema || ev.CurrentContent.Schema != SignificantChangeContentStore.BodySchema ||
            mutation.Kind != nameof(AssessSignificantChange) || !mutation.Changed ||
            mutation.AfterSha256 != AuthoredIntentDigest.Compute(view) || SignificantChangeContentStore.Header(view) != ev.Header ||
            view.CurrentAssessment is not { } assessment || assessment.ContentVersion != ev.Header.CurrentVersionNumber)
            throw new ImmutableContentIntegrityException("The work-link source content differs from its native exact assessment.");
        if (assessment.RelatedReviewWorkIds.Count == 0 && assessment.RelatedCorrectiveActionIds.Count == 0)
            return;
        await ImpactReactionOutcomes.SendAsync(bus,new LinkImpactReviewWork(
            EffectIdentity.CommandId(ev.Metadata.EventId,"change:impact-work-links",ev.SubjectId.ToString(),null),
            ev.TenantId,ev.Header.ProgramId,ev.SubjectId,assessment.ContentVersion),context,ct).ConfigureAwait(false);
    }
}
''')
