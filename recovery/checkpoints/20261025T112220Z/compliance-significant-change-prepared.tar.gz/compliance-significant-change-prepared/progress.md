# SignificantChange native owner preparation

Parent scope: complete compact/native SignificantChange plus every selected command, reader, projector/reactor consumer, and TypeIIPeriodCloseHistory source seam. Offline only; no main edits, builds, git mutations, worktrees, branches or GitHub issues. Parent owns all runtime/JeV/integration. All team slots were occupied; Policy/Template integration proceeds independently.

59 relevant baselines/work files copied from current main. No implementation changes yet. `behavioral-red.patch` is ready: old owner surface only, valid 1,000 AffectedSystemIds + 1,000 EvidenceArtifactIds rejects due to repeated full-State payload. Filter `FullyQualifiedName~SignificantChangeTests.ShouldRecordCompleteGovernedReferencesGivenSourceContentExceedsEventBudget`; retain name and green native write/readback proof.

## Confirmed scope

SignificantChange currently retains one full SignificantChangeView and embeds it in five facts: Recorded/Revised/ImpactAssessed/ImpactReviewWorkLinked/SystemDescriptionDecisionRecorded. Current domain rules ~540 lines, max32 versions, max1000 references, default JsonSerializer logical digests. Preserve those exact digest preimages. Final selected target-event/command/reactor JSON catalogs do not list this retained owner/five facts; aggregate-contract-catalog and remaining-command-identities explicitly retain them, so this is not a removal/blocker. Advance retained event schemas and add complete native envelope/attribution/result.

Selected commands:
- RecordSignificantChange uses ChangeId as logical id; no caller revision.
- Revise/Assess add CommandId and retain exact caller ExpectedRevision; selected PUT /.../significant-changes/{change_id}/revisions|assessments/{command_id}.
- LinkImpactReviewWork adds CommandId; trusted system only, ContentVersion token, no caller primary revision. Deterministic source-event effect id from LinkImpactReviewWorkReactor.
- RecordSignificantChangeSystemDescriptionDecision adds CommandId; trusted system only, exact ContentVersion/SystemDescriptionId/VersionId/DecisionId/Decision/AssessmentSha256. Source correlation verifies actual immutable description decision, business actor/rationale/source DecisionAt. Operation actor may be system; business actor remains human.
- All immediate Unit -> IRequest<UnitResult>/typed handlers/200{} and MutationResultContent envelope. Exact native replay before source guards; current authorization still before replay.

Consumers: the five handlers; restricted mutation authorizer; Get/List; Fitz directory/projector; LinkImpactReviewWorkReactor; SystemDescriptionDecisionReactor; AggregateSystemDescriptionDecisionCorrelationReader; TypeIIPeriodCloseHistory. Incidents share authorizer, correlation reader, decision reactor and ImpactReactionOutcomes, so preserve incident branches. ImpactReactionOutcomes.SendAsync currently accepts untyped IRequest; add typed Unit overload for new significant callbacks while preserving incidents.

Current Get/List trust full directory details and list updated_at-desc with current restricted visibility using ALL retained assessor ids. Keep visibility and sort semantics; compact directory may store summary/current native sequence, while detail comes from source-backed reader. Add source-checkpoint fence and avoid silent missing-content omissions. Current authorizer edit visibility uses CURRENT assessor only. Current restricted handling must be checked before exact replay through existing authorizer.

TypeIIPeriodCloseHistory currently loads current SignificantChange then decodes each typed full-State payload under receipt cutoff. Must migrate to native immutable history reader, retain effective-window filter, current restricted visibility and PeriodCloseEligible checks. Receipt cutoff should use native Operation.AcceptedAt rather than business source DecisionAt. Source publication must contain verified actual content bytes, not only event refs to opaque body stores. Plan optional verified content blobs on TypeIIPeriodCloseNativeSource (ref + base64 exact bytes), preserving current native event payload/digest; generated source envelope remains canonical-proof .snapshot, not mislabeled JSON.

## Planned implementation

Follow frozen period/Control pattern: compact Header + CurrentContent ref + NativeSequence + NativeAcceptance; transient plain Rules and plain body mutations (never DomainEvent), exact-cut reader, full verified immutable content/actions, per-file parent shared deltas. Local append checks exact native/physical cut, full prepared before/after hashes + domain transition. No Aggregate.Current/full-view shim or shipped legacy read/write path.

Header needs immutable identity/program, logical Revision/content version/digest, title/status/handling/effective dates/owner, current assessment identity/digest/assessor/source time/description-review flag, exact expected/linked work digests/counts, current description decision id/digest, close eligibility, business actor/UpdatedAt, latest accepted receipt time. Full arrays/history stay immutable.

Allow native no-op acceptance for distinct trusted callback logical ids when same content-version work is already linked or empty. Existing rules return success without change; still persist original Unit on selected existing business fact with ChangeCount0, same logical Revision/current body ref, NativeSequence+1. Native same-command replay needs no second fact. Exact stale ContentVersion/assessment/decision classifications preserve existing terminal superseded vs transient not-yet-visible behavior.

System description copied decisions may have a business DecidedAt older than linked-at/current UpdatedAt. Preserve business attribution/source time in immutable view; native receipt time is server Operation.AcceptedAt and drives recorded cutoff. Don't conflate the two.
