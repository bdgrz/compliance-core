from pathlib import Path
import re
exec(Path('/tmp/compliance-significant-change-prepared/write_native.py').read_text().split("p=R/(C+'SignificantChangeView.cs')")[0])
T='test/Compliance.Tests/Features/Changes/'
# A plain rules model is test arrangement only; production owner hydration uses verified native readers.
for name in ['SignificantChangeTests.cs','ComplianceImpactReactionHandlerTests.cs','RestrictedComplianceRecordMutationAuthorizerTests.cs']:
 p=R/(T+name);s=p.read_text().replace('using SignificantChangeAggregate = Bdgrz.Compliance.Features.Changes.SignificantChange;','using SignificantChangeAggregate = Bdgrz.Compliance.Features.Changes.SignificantChangeRules;')
 if name!='SignificantChangeTests.cs':
  s=s.replace('static SignificantChange AssessedChange(', 'static SignificantChangeRules AssessedChange(').replace('new SignificantChange(tenantId, programId, changeId);','new SignificantChangeRules(tenantId, programId, changeId);')
 s=re.sub(r'await scenario.Reader.HydrateAsync\(new SignificantChange\(([^)]+)\)\)',r'await scenario.Changes.RulesAsync(\1)',s)
 # Add the new authored logical identity while preserving all existing content/revision tokens.
 for command in ['ReviseSignificantChange','AssessSignificantChange','LinkImpactReviewWork','RecordSignificantChangeSystemDescriptionDecision']:
  s=s.replace('new '+command+'(', 'new '+command+'(Uuid.CreateVersion4(), ')
 if name=='ComplianceImpactReactionHandlerTests.cs':
  s=s.replace('new LinkImpactReviewWorkHandler(scenario.Executor, scenario.Reader,','new LinkImpactReviewWorkHandler(scenario.ChangeOperations,').replace('ownership, new FixedTimeProvider(Now))','ownership)').replace('new WorkOwnershipReader([workItemId]), new FixedTimeProvider(Now))','new WorkOwnershipReader([workItemId]))').replace('new LaggingOwnershipReader(), new FixedTimeProvider(Now))','new LaggingOwnershipReader())')
  s=s.replace('scenario.Executor, scenario.Reader);','scenario.ChangeOperations, scenario.Reader);')
  s=s.replace('Assert.Equal(2, ownership.Calls);','Assert.Equal(1, ownership.Calls);')
  s=s.replace('            Operations = new NativeOperationExecutor(Reader, Executor, Content);','''            Operations = new NativeOperationExecutor(Reader, Executor, Content);
            Changes = new SignificantChangeReader(Reader,events,Content);
            ChangeOperations = new SignificantChangeOperations(Operations,Changes,Content,new FixedTimeProvider(Now));''')
  s=s.replace('        public IImmutableContentStore Content { get; }','''        public SignificantChangeReader Changes { get; }
        public SignificantChangeOperations ChangeOperations { get; }
        public ValueTask<SignificantChange> SaveAsync(SignificantChangeRules rules) => ChangeSeeds.WriteAsync(Writer,Content,rules);
        public IImmutableContentStore Content { get; }''')
 elif name=='RestrictedComplianceRecordMutationAuthorizerTests.cs':
  s=s.replace('Authorizer(scenario.Reader,','Authorizer(scenario,').replace('Authorizer(IAggregateReader reader,','Authorizer(Scenario scenario,').replace('permissions) => new(reader,','permissions) => new(scenario.Reader, scenario.Changes,')
  s=s.replace('            services.AddSingleton<IEventStore>(new InMemoryEventStore());','''            var events = new InMemoryEventStore();
            services.AddSingleton<IEventStore>(events);
            services.AddSingleton<IDomainEventReader>(events);''')
  s=s.replace('            writer = scope.ServiceProvider.GetRequiredService<IAggregateWriter>();','''            writer = scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
            Changes = new SignificantChangeReader(Reader,events,Content);''')
  s=s.replace('        readonly IAggregateWriter writer;','''        readonly IAggregateWriter writer;
        public Bdgrz.Compliance.Features.Content.IImmutableContentStore Content { get; } = ChangeSeeds.Content();
        public SignificantChangeReader Changes { get; }
        public ValueTask<SignificantChange> SaveAsync(SignificantChangeRules rules) => ChangeSeeds.WriteAsync(writer,Content,rules);''')
 else:
  s=s.replace('var events = new AggregateScenario<SignificantChangeAggregate>(change).PendingEvents.ToArray();','var changes = change.AppliedChanges.ToArray();').replace('var replay = new AggregateScenario<SignificantChangeAggregate>(NewChange()).Given(events).Aggregate;','var replay = NewChange();\n        foreach (var mutation in changes)\n            replay.Apply(mutation);')
 p.write_text(s)
# Native read helper returns an explicit transient rules composition for existing test assertions.
p=R/(K+'SignificantChangeReader.cs');s=p.read_text().replace('    public async ValueTask<SignificantChangeReadSnapshot> ReadThroughAsync','''    public async ValueTask<SignificantChangeRules> RulesAsync(Uuid tenantId,Uuid programId,Uuid changeId,CancellationToken ct = default) =>
        (await ReadAsync(tenantId,programId,changeId,ct).ConfigureAwait(false)).Rules;
    public async ValueTask<SignificantChangeReadSnapshot> ReadThroughAsync''');p.write_text(s)
p=R/(T+'ChangeAndIncidentCommandHandlerTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;\n'+s
for name in ['RecordSignificantChange','ReviseSignificantChange','AssessSignificantChange']:
 s=s.replace('new '+name+'Handler(scenario.Executor, scenario.Clock)','new '+name+'Handler(scenario.ChangeOperations)')
 if name!='RecordSignificantChange':s=s.replace('new '+name+'(','new '+name+'(Uuid.CreateVersion4(), ')
s=s.replace('await scenario.Reader.HydrateAsync(new SignificantChange(TenantId, ProgramId, changeId))','await scenario.Changes.RulesAsync(TenantId,ProgramId,changeId)')
s=s.replace('            services.AddSingleton<IEventStore>(new InMemoryEventStore());','''            var events = new InMemoryEventStore();
            services.AddSingleton<IEventStore>(events);
            services.AddSingleton<IDomainEventReader>(events);''')
s=s.replace('            Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();','''            Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();
            Changes = new SignificantChangeReader(Reader,events,Content);
            ChangeOperations = new SignificantChangeOperations(new NativeOperationExecutor(Reader,Executor,Content),Changes,Content,Clock);''')
s=s.replace('        public TimeProvider Clock','''        public IImmutableContentStore Content { get; } = ChangeSeeds.Content();
        public SignificantChangeReader Changes { get; }
        public SignificantChangeOperations ChangeOperations { get; }
        public TimeProvider Clock''');p.write_text(s)
# Native reactor test source is physically stored and typed Unit responses preserve failure classifications.
p=R/(T+'ComplianceImpactReactorTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;\n'+s
s=s.replace('var trigger = AssessedTrigger();','var content = ChangeSeeds.Content();\n        var trigger = await AssessedTriggerAsync(content);')
s=s.replace('.RespondTo<LinkImpactReviewWork>(Result.Failure(','.RespondTo<LinkImpactReviewWork, UnitResult>(Result<UnitResult>.Failure(').replace('scenario.RespondTo<LinkImpactReviewWork>(Result.Success);','scenario.RespondTo<LinkImpactReviewWork, UnitResult>(Result<UnitResult>.Success(new UnitResult()));')
s=s.replace('new LinkImpactReviewWorkReactor(checkpoints, scenario.Requests)','new LinkImpactReviewWorkReactor(checkpoints, scenario.Requests, content)')
s=s.replace('static SignificantChangeImpactAssessed AssessedTrigger()','static async ValueTask<SignificantChangeImpactAssessed> AssessedTriggerAsync(IImmutableContentStore content)').replace('return new AggregateScenario<SignificantChange>(change).PendingEvents','var owner = await ChangeSeeds.OwnerAsync(content,change);\n        return new AggregateScenario<SignificantChange>(owner).PendingEvents');p.write_text(s)
# Use the frozen period-stage2 baseline because this slice is queued after that owner cutover.
rel='test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseSources.cs'
future=Path('/tmp/compliance-typeii-period-prepared/work')/rel
if future.exists():
 (R.parent/'base'/rel).write_bytes(future.read_bytes());(R/rel).write_bytes(future.read_bytes())
p=R/rel;s=p.read_text();s='using Bdgrz.Compliance.Tests.Features.Changes;\n'+s;s=s.replace('new SignificantChange(fixture.TenantId, fixture.ProgramId, Uuid.CreateVersion4())','new SignificantChangeRules(fixture.TenantId, fixture.ProgramId, Uuid.CreateVersion4())').replace('await fixture.Writer.SaveAsync(change, new RequestDispatchContext(RequestActor.System));','await ChangeSeeds.WriteAsync(fixture.Writer,fixture.Host.Content,change);')
s=s.replace('new TypeIIPeriodCloseHistory(fixture.Reader, fixture.Events, new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(true)))','new TypeIIPeriodCloseHistory(fixture.Reader, fixture.Events, new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(true)),\n                    new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Host.Content),fixture.Host.Content)')
s=s.replace('new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(false)));','new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(false)),\n            new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Host.Content),fixture.Host.Content);');p.write_text(s)
