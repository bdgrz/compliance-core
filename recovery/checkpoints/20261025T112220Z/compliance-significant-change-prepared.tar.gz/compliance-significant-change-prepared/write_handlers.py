from pathlib import Path
exec(Path('/tmp/compliance-significant-change-prepared/write_native.py').read_text().split("p=R/(C+'SignificantChangeView.cs')")[0])
import re
for name in ['RecordSignificantChange','ReviseSignificantChange','AssessSignificantChange','LinkImpactReviewWork','RecordSignificantChangeSystemDescriptionDecision']:
 p=R/(C+name+'.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s
 if name!='RecordSignificantChange':
  s=s.replace('('+('Uuid TenantId'),'(Uuid CommandId, Uuid TenantId',1)
 s=s.replace(': IRequest,',': IRequest<UnitResult>, IIdentifiedRequest,')
 s=re.sub(r'(\[Discriminator\("[^"]+", )(\d+)(\)\])',lambda m:m[1]+str(int(m[2])+1)+m[3],s)
 s=s.rstrip().rstrip(';')+'\n{\n    Uuid IIdentifiedRequest.RequestId => '+('ChangeId' if name=='RecordSignificantChange' else 'CommandId')+';\n}\n';p.write_text(s)
for name,apply,expected in [('RecordSignificantChange','snapshot.Rules.Record(request.Content, member, display, operation.AcceptedAt)','null'),('ReviseSignificantChange','snapshot.Rules.Revise(request.ExpectedRevision, request.Content, request.ChangeReason, member, display, operation.AcceptedAt)','request.ExpectedRevision'),('AssessSignificantChange','snapshot.Rules.Assess(request.ExpectedRevision, request.Content, member, display, operation.AcceptedAt)','request.ExpectedRevision')]:
 put(K+name+'Handler.cs',f'''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Programs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

public sealed class {name}Handler(SignificantChangeOperations operations)
    : IRequestHandler<{name}, UnitResult>
{{
    public ValueTask<Result<UnitResult>> HandleAsync(IRequestContext<{name}> context, CancellationToken ct)
    {{
        var request = context.Request;
        var (member, display) = ClientServiceActor.Snapshot(context);
        return operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.ChangeId,
            {'request.ChangeId' if name=='RecordSignificantChange' else 'request.CommandId'}, nameof({name}), {expected}, ActorReference.ForMember(member, display),
            (snapshot, operation, token) => ValueTask.FromResult(SignificantChangeOperations.Outcome({apply})), ct);
    }}
}}
''')
p=R/(K+'LinkImpactReviewWorkHandler.cs');s=p.read_text()
s=s.replace('using Bdgrz.Compliance.Features.Versioning;','using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.NativeOperations;')
a=s.index('public sealed class');b=s.index('    /// <summary>')
s=s[:a]+'''public sealed class LinkImpactReviewWorkHandler(SignificantChangeOperations operations,
    IChangeImpactWorkOwnershipReader ownership) : IRequestHandler<LinkImpactReviewWork, UnitResult>
{
    public ValueTask<Result<UnitResult>> HandleAsync(IRequestContext<LinkImpactReviewWork> context, CancellationToken ct)
    {
        if (!RequestActor.IsSystem(context.Actor))
            return ValueTask.FromResult(Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Forbidden,
                "Impact-review work links may only be written by a trusted reactor.")));
        var request = context.Request;
        if (request.ContentVersion <= 0)
            return ValueTask.FromResult(Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Validation,
                "The exact assessment content version is required.")));
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.ChangeId,request.CommandId,
            nameof(LinkImpactReviewWork),null,ActorReference.ForSystemProcess("reactor:LinkImpactReviewWork","LinkImpactReviewWork"),
            async (snapshot,operation,token) =>
            {
                if (snapshot.View is not { CurrentAssessment: { } assessment } state ||
                    assessment.ContentVersion != request.ContentVersion)
                    return Result.Failure(NotCurrent(snapshot.View,request.ContentVersion));
                var ids = assessment.RelatedReviewWorkIds.Concat(assessment.RelatedCorrectiveActionIds)
                    .OrderBy(static id => id.ToString(),StringComparer.Ordinal).ToArray();
                var ready = await ownership.ConfirmOwnedByProgramAsync(request.TenantId,request.ProgramId,ids,token).ConfigureAwait(false);
                return !ready.IsSuccess ? ready : SignificantChangeOperations.Outcome(snapshot.Rules.LinkReviewWork(
                    state.Revision,ids,assessment.AssessedByMemberId,assessment.AssessedByDisplay,operation.AcceptedAt));
            },ct);
    }

'''+s[b:]
s=s.replace('NotCurrent(SignificantChange change, int contentVersion)','NotCurrent(SignificantChangeView? current, int contentVersion)').replace('if (change.Current is not { } current)','if (current is null)');p.write_text(s)
p=R/(K+'RecordSignificantChangeSystemDescriptionDecisionHandler.cs');s=p.read_text().replace('using Bdgrz.Compliance.Features.Versioning;','using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.NativeOperations;')
s=s.replace('IAggregateExecutor executor, IAggregateReader reader)','SignificantChangeOperations operations, IAggregateReader reader)')
s=s.replace('IRequestHandler<RecordSignificantChangeSystemDescriptionDecision>','IRequestHandler<RecordSignificantChangeSystemDescriptionDecision, UnitResult>')
s=s.replace('async ValueTask<Result>','ValueTask<Result<UnitResult>>')
s=s.replace('return Result.Failure(', 'return ValueTask.FromResult(Result<UnitResult>.Failure(')
# Handle the two early returns (each close had two )); now three needed)
s=s.replace('"System-description decisions may only be copied by a trusted reactor."));','"System-description decisions may only be copied by a trusted reactor.")));').replace('"The exact significant-change system-description decision is required."));','"The exact significant-change system-description decision is required.")));')
a=s.index('        var description =');b=s.index('    /// <summary>')
s=s[:a]+'''        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.ChangeId,request.CommandId,
            nameof(RecordSignificantChangeSystemDescriptionDecision),null,
            ActorReference.ForSystemProcess("reactor:SystemDescriptionDecision","SystemDescriptionDecision"),
            async (snapshot,operation,token) =>
            {
                var description = await reader.HydrateAsync(new SystemDescriptionAggregate(request.TenantId,
                    request.ProgramId,request.SystemDescriptionId),token).ConfigureAwait(false);
                var decision = SystemDescriptionDecisionCorrelation.Find(description,request.TenantId,request.ProgramId,
                    request.ChangeId,request.SystemDescriptionVersionId,request.DecisionId,request.Decision,request.AssessmentSha256);
                if (decision is null)
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The description decision is not an exact approved successor or no-change fact for this change."));
                if (Classify(snapshot.View,request,decision) is { } outcome)
                    return Result.Failure(outcome);
                if (snapshot.View?.CurrentAssessment is not { RequiresSystemDescriptionReview: true } assessment ||
                    assessment.ContentVersion != request.ContentVersion ||
                    SignificantChange.AssessmentSha256(assessment) != request.AssessmentSha256 || decision.DecidedAt < assessment.AssessedAt)
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The description decision does not match the current change assessment."));
                return SignificantChangeOperations.Outcome(snapshot.Rules.RecordSystemDescriptionDecision(snapshot.Rules.Revision,
                    decision.Decision,decision.DecisionId,decision.Rationale,decision.ActorMemberId,decision.ActorDisplay,decision.DecidedAt));
            },ct);
    }

'''+s[b:]
s=s.replace('Classify(SignificantChange change,','Classify(SignificantChangeView? current,').replace('if (change.Current is not { } current)','if (current is null)');p.write_text(s)
