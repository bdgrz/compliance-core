from pathlib import Path

exec(Path('/tmp/compliance-significant-change-prepared/write_native.py').read_text().split("p=R/(C+'SignificantChangeView.cs')")[0])
put(K+'SignificantChangeReadSnapshot.cs','''namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Explicit verified read composition, separate from the compact command owner.</summary>
public sealed record SignificantChangeReadSnapshot(SignificantChange Owner, SignificantChangeRules Rules)
{
    public SignificantChangeView? View => Rules.Current;
}
''')
put(K+'SignificantChangeReader.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Reconstructs exact verified business content at a native owner cut or recorded-through receipt cut.</summary>
public sealed class SignificantChangeReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async ValueTask<SignificantChangeReadSnapshot> ReadAsync(Uuid tenantId, Uuid programId, Uuid changeId,
        CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new SignificantChange(tenantId,programId,changeId),ct).ConfigureAwait(false);
        return await ReadAsync(owner,programId,null,ct).ConfigureAwait(false);
    }
    public async ValueTask<SignificantChangeReadSnapshot> ReadThroughAsync(Uuid tenantId, Uuid programId, Uuid changeId,
        DateTimeOffset recordedThrough, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new SignificantChange(tenantId,programId,changeId),ct).ConfigureAwait(false);
        return await ReadAsync(owner,programId,recordedThrough,ct).ConfigureAwait(false);
    }
    internal ValueTask<SignificantChangeReadSnapshot> ReadAsync(SignificantChange owner, Uuid programId, CancellationToken ct) =>
        ReadAsync(owner,programId,null,ct);
    async ValueTask<SignificantChangeReadSnapshot> ReadAsync(SignificantChange owner, Uuid programId,
        DateTimeOffset? through, CancellationToken ct)
    {
        var rules = new SignificantChangeRules(owner.TenantId,programId,owner.Id);
        if (owner.Header is null || owner.ProgramId != programId)
            return new(owner,rules);
        var sequence = 0L;
        ISignificantChangeFact? last = null;
        DateTimeOffset? previousReceipt = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(owner.TenantId.ToString(),
            SignificantChange.Area,owner.Id.ToString()),EventCursor.Start,ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit)
                continue;
            if (record.Event is not ISignificantChangeFact fact || fact.NativeSequence != sequence + 1 ||
                record.Stream != owner.Stream || fact.Header.ProgramId != programId ||
                previousReceipt is { } receipt && fact.Operation.AcceptedAt < receipt)
                throw new ImmutableContentIntegrityException("The change history has another native sequence, scope or receipt order.");
            if (fact.NativeSequence > owner.NativeSequence || through is { } cutoff && fact.Operation.AcceptedAt > cutoff)
                break;
            var mutation = await content.ReadJsonAsync<SignificantChangeMutation>(owner.TenantId.ToString(),fact.Change,ct).ConfigureAwait(false);
            var body = await content.ReadJsonAsync<SignificantChangeView>(owner.TenantId.ToString(),fact.CurrentContent,ct).ConfigureAwait(false);
            if (fact.Change.Schema != SignificantChangeContentStore.ChangeSchema || fact.CurrentContent.Schema != SignificantChangeContentStore.BodySchema ||
                mutation.Kind != fact.Operation.CommandKind || fact.ChangeCount != (mutation.Changed ? 1 : 0) ||
                !SignificantChangeContentStore.ValidMutation(rules.Current,body,mutation) ||
                SignificantChangeContentStore.Header(body) != fact.Header)
                throw new ImmutableContentIntegrityException("The change immutable body differs from its native transition or authority.");
            SignificantChangeContentStore.Apply(rules,mutation);
            sequence = fact.NativeSequence;
            previousReceipt = fact.Operation.AcceptedAt;
            last = fact;
        }
        if (through is null && (sequence != owner.NativeSequence || last?.Header != owner.Header || last.CurrentContent != owner.CurrentContent))
            throw new ImmutableContentUnavailableException("The complete exact native change cut is not readable yet.");
        return new(owner,rules);
    }
}
''')
put(K+'SignificantChangeOperations.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Changes;

/// <summary>Identified native operations with verified content preparation inside acceptance recovery.</summary>
public sealed class SignificantChangeOperations(NativeOperationExecutor operations, SignificantChangeReader changes,
    IImmutableContentStore content, TimeProvider clock)
{
    public async ValueTask<Result<UnitResult>> ExecuteAsync<TRequest>(IRequestContext<TRequest> context,
        Uuid tenantId, Uuid programId, Uuid changeId, Uuid commandId, string kind, long? expectedRevision,
        ActorReference actor, Func<SignificantChangeReadSnapshot,OperationProvenance,CancellationToken,ValueTask<Result>> prepare,
        CancellationToken ct) where TRequest : IRequestBase
    {
        if (tenantId == Uuid.Empty || programId == Uuid.Empty || changeId == Uuid.Empty || commandId == Uuid.Empty || expectedRevision is <= 0)
            return Fail(RequestErrorKind.Validation,"A change operation requires exact scope and command identities.");
        var operation = OwnerProvenance.For(new SignificantChange(tenantId,programId,changeId),commandId,kind,actor,
            changeId.ToString(),expectedRevision is { } revision ? unchecked((ulong)revision) : null,
            AuthoredIntentDigest.Compute(context.Request),clock.GetUtcNow());
        FrozenSignificantChangeMutation? frozen = null;
        ImmutableContentRef? result = null;
        var sequence = 0L;
        var position = 0UL;
        try
        {
            var accepted = await operations.ExecuteAsync(new NativeOperation<SignificantChange>(AcceptedOperationBinding.Of(operation),
                () => new SignificantChange(tenantId,programId,changeId,commandId),owner => owner.Acceptance,
                async (owner,token) =>
                {
                    try
                    {
                        if (kind == nameof(RecordSignificantChange) ? owner.Header is not null : owner.Header is null || owner.ProgramId != programId)
                            return Result<FirstResponseDescriptor>.Failure(new RequestError(kind == nameof(RecordSignificantChange) ? RequestErrorKind.Conflict : RequestErrorKind.NotFound,
                                "The significant change is not available for this operation."));
                        if (expectedRevision is { } expected && owner.Revision != expected)
                            return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,"The significant change requires its original expected revision."));
                        var snapshot = await changes.ReadAsync(owner,programId,token).ConfigureAwait(false);
                        var before = snapshot.View;
                        var ready = await prepare(snapshot,operation,token).ConfigureAwait(false);
                        if (!ready.IsSuccess)
                            return Result<FirstResponseDescriptor>.Failure(ready.Error!);
                        frozen = await SignificantChangeContentStore.FreezeAsync(content,before,snapshot.Rules,kind,token).ConfigureAwait(false);
                        var response = await NativeContent.FreezeUnitAsync(content,tenantId,token).ConfigureAwait(false);
                        result = response.Result;
                        sequence = owner.NativeSequence;
                        position = owner.CommittedStreamPosition;
                        return Result<FirstResponseDescriptor>.Success(response.Response);
                    }
                    catch (ImmutableContentIntegrityException exception)
                    {
                        return Result<FirstResponseDescriptor>.Failure(ContentFailure(exception));
                    }
                },(owner,response) => owner.Append(SignificantChangeContentStore.Fact(frozen!,sequence+1,operation,response,result!),
                    frozen!,sequence,position)),context,ct).ConfigureAwait(false);
            if (!accepted.IsSuccess)
                return Result<UnitResult>.Failure(accepted.Error!);
            var descriptor = accepted.Value switch
            {
                AcceptedAppendResult.Committed committed => committed.Response,
                AcceptedAppendResult.Replayed replayed => replayed.Response,
                _ => null,
            };
            if (descriptor is null)
                return Result<UnitResult>.Failure(AcceptedAppendResult.ConflictError);
            if (descriptor.HttpStatus != 200 || descriptor.ResultSchema != UnitResult.Schema ||
                descriptor.Body is not StandardResponseBody body || body.Content.Schema != UnitResult.Schema)
                throw new ImmutableContentIntegrityException("The original change response has another result contract.");
            return await NativeContent.ResponseAsync<UnitResult>(content,tenantId,accepted,ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<UnitResult>.Failure(ContentFailure(exception));
        }
    }
    public static Result Outcome(Bdgrz.Compliance.Features.Versioning.CommandFailure? failure) =>
        failure is null ? Result.Success : Result.Failure(failure.ToRequestError());
    public static RequestError ContentFailure(ImmutableContentIntegrityException exception) => new(RequestErrorKind.Conflict,
        "The significant change's exact immutable content cannot be verified.",exception is ImmutableContentUnavailableException);
    static Result<UnitResult> Fail(RequestErrorKind kind,string message) => Result<UnitResult>.Failure(new RequestError(kind,message));
}
''')
p=R/(K+'SignificantChange.cs');s=p.read_text().replace('value.Length > 0','value.Bytes > 0').replace('op.Actor.Kind != "system"','op.Actor.Kind != "system_process"');p.write_text(s)
