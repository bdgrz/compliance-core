from pathlib import Path
exec(Path('/tmp/compliance-significant-change-prepared/write_native.py').read_text().split("p=R/(C+'SignificantChangeView.cs')")[0])
O='src/Compliance.Core/Features/Operations/'
for name in ['TypeIIPeriodCloseNativeSource.cs']:
 for d in ['base','work']:
  p=R.parent/d/O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(Path(O+name).read_bytes())
put(O+'TypeIIPeriodCloseContentBlob.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Exact digest-verified immutable source bytes physically sealed in the published close source envelope.</summary>
public sealed record TypeIIPeriodCloseContentBlob(ImmutableContentRef Reference, string Base64);
''')
p=R/(O+'TypeIIPeriodCloseNativeSource.cs');s=p.read_text().replace('using System.Text.Json;','using System.Text.Json;\nusing System.Text.Json.Serialization;').replace('    JsonElement Payload);','''    JsonElement Payload)
{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public IReadOnlyList<TypeIIPeriodCloseContentBlob>? ContentBlobs { get; init; }
}
''');p.write_text(s)
p=R/(O+'TypeIIPeriodCloseHistory.cs');s=p.read_text().replace('RestrictedComplianceRecordVisibility visibility)','RestrictedComplianceRecordVisibility visibility, SignificantChangeReader changes, IImmutableContentStore content)');s=s.replace('''                    var current = await reader.HydrateAsync(new SignificantChange(period.TenantId, period.ProgramId, id), ct).ConfigureAwait(false);
                    var latest = current.Current ?? throw new ImmutableContentUnavailableException("A discovered native change is not readable yet.");
                    var past = ChangeState(group.Last().Payload)
                        ?? throw new ImmutableContentIntegrityException("A scoped change history has no complete final state.");''','''                    var latest = (await changes.ReadAsync(period.TenantId,period.ProgramId,id,ct).ConfigureAwait(false)).View
                        ?? throw new ImmutableContentUnavailableException("A discovered native change is not readable yet.");
                    var past = (await changes.ReadThroughAsync(period.TenantId,period.ProgramId,id,recordedThrough,ct).ConfigureAwait(false)).View
                        ?? throw new ImmutableContentIntegrityException("A scoped change history has no complete final immutable state.");''');
s=s.replace('result.Add(Capture(record.Stream, record.Event));','''var captured = Capture(record.Stream,record.Event);
            if (record.Event is ISignificantChangeFact change)
            {
                var body = await content.ReadVerifiedAsync(tenant.ToString(),change.CurrentContent,ct).ConfigureAwait(false);
                var mutation = await content.ReadVerifiedAsync(tenant.ToString(),change.Change,ct).ConfigureAwait(false);
                captured = captured with { ContentBlobs = [new(change.CurrentContent,Convert.ToBase64String(body.Span)),
                    new(change.Change,Convert.ToBase64String(mutation.Span))] };
            }
            result.Add(captured);''')
a=s.index('        SignificantChangeRecorded e =>');b=s.index('        ComplianceIncidentRecorded e =>',a);s=s[:a]+'''        ISignificantChangeFact e => (e.TenantId,e.Header.ProgramId,e.SubjectId,e.Operation.AcceptedAt),
'''+s[b:]
a=s.index('    static SignificantChangeView? ChangeState(');b=s.index('    static ComplianceIncidentView?',a);s=s[:a]+s[b:]
s=s.replace('pair.First.EventKind == pair.Second.EventKind && pair.First.PayloadSha256 == pair.Second.PayloadSha256);','''pair.First.EventKind == pair.Second.EventKind && pair.First.PayloadSha256 == pair.Second.PayloadSha256 &&
            AuthoredIntentDigest.Compute(pair.First.ContentBlobs) == AuthoredIntentDigest.Compute(pair.Second.ContentBlobs));''')
p.write_text(s)
p=R/(K+'FitzSignificantChangeDirectory.cs');s=p.read_text().replace('await LoadCheckpointAsync(EventStreamPattern.ForPattern(tenantId.ToString(),SignificantChange.Area),ct).ConfigureAwait(false);','await base.LoadCheckpointAsync(new CheckpointIdentity(SignificantChangeDirectoryProjector.ProjectorName,\n            EventStreamPattern.ForPattern(tenantId.ToString(),SignificantChange.Area)),ct).ConfigureAwait(false);');p.write_text(s)
