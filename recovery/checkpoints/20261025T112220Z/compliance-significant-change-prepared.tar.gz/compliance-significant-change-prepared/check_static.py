from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,re,json
r=Path('/tmp/compliance-significant-change-prepared');work=r/'work';p=Parser(Language(tree_sitter_c_sharp.language()))
files=list(work.rglob('*.cs'))+list((r/'shared-work').rglob('*.cs'))
def walk(n):
 stack=[n]
 while stack:
  current=stack.pop();yield current
  stack.extend(reversed(current.children))
syntax=[];missingtests=[];errors=[];types={}
for f in files:
 b=f.read_bytes();root=p.parse(b).root_node
 if root.has_error:syntax.append(str(f))
 if '/src/' not in str(f):continue
 for n in walk(root):
  if n.type in ['class_declaration','record_declaration','struct_declaration']:
   name=n.child_by_field_name('name');params=n.child_by_field_name('parameters')
   if not name:continue
   if params is None:
    params=next((c for c in n.children if c.type=='parameter_list'),None)
   if params:
    ps=[c for c in params.named_children if c.type=='parameter'];maxi=len(ps)
    mini=sum(1 for q in ps if not any(c.type=='equals_value_clause' for c in q.named_children) and b'=' not in b[q.start_byte:q.end_byte])
    types.setdefault(b[name.start_byte:name.end_byte].decode(),set()).add((mini,maxi))
for f in files:
 b=f.read_bytes();root=p.parse(b).root_node
 for n in walk(root):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=n.child_by_field_name('arguments')
  if args is None:args=next((c for c in n.children if c.type=='argument_list'),None)
  if typ is None or args is None:continue
  name=b[typ.start_byte:typ.end_byte].decode().split('.')[-1];count=len([c for c in args.named_children if c.type=='argument'])
  if name in types and not any(lo<=count<=hi for lo,hi in types[name]):
   errors.append((str(f.relative_to(r)),n.start_point.row+1,name,count,list(types[name])))
for b in (r/'base/test').rglob('*.cs'):
 rel=b.relative_to(r/'base');current=work/rel
 old=set(re.findall(r'\b(Should\w+)\s*\(',b.read_text()));new=set(re.findall(r'\b(Should\w+)\s*\(',current.read_text()))
 if old-new:missingtests.append((str(rel),sorted(old-new)))
report={'syntax_errors':syntax,'explicit_constructor_arity_signals':errors,'removed_acceptance_names':missingtests}
(r/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
