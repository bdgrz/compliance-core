from pathlib import Path
exec(Path('/tmp/compliance-significant-change-prepared/write_native.py').read_text().split("p=R/(C+'SignificantChangeView.cs')")[0])
T='test/Compliance.Tests/Features/Changes/'
put(T+'SignificantChangeNativeFixture.cs','''using System.Security.Claims;
using Bdgrz.Compliance.Features.Changes;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Changes;

internal sealed class SignificantChangeNativeFixture : IAsyncDisposable
{
    readonly ServiceProvider _provider;
    readonly AsyncServiceScope _scope;
    public SignificantChangeNativeFixture()
    {
        var services = new ServiceCollection();
        services.AddSingleton<IEventStore>(Events);
        services.AddPortia();
        _provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true });
        _scope = _provider.CreateAsyncScope();
        Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();
        Writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
        var executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();
        Changes = new SignificantChangeReader(Reader,Events,Content);
        Operations = new SignificantChangeOperations(new NativeOperationExecutor(Reader,executor,Content),Changes,Content,Clock);
    }
    public Uuid Tenant { get; } = Uuid.CreateVersion4();
    public Uuid Program { get; } = Uuid.CreateVersion4();
    public Uuid Change { get; } = Uuid.CreateVersion4();
    public Uuid User { get; } = Uuid.CreateVersion4();
    public InMemoryEventStore Events { get; } = new();
    public HookedContent Content { get; } = new(ChangeSeeds.Content());
    public MutableClock Clock { get; } = new();
    public IAggregateReader Reader { get; }
    public IAggregateWriter Writer { get; }
    public SignificantChangeReader Changes { get; }
    public SignificantChangeOperations Operations { get; }
    public SignificantChangeContent Body(string title = "Production migration") => new(null,null,null,title,"Move the governed service.",
        new DateOnly(2026,10,18),null,RbacIds.Member(Tenant,User),[Uuid.CreateVersion4()],"high","confidential",[]);
    public RequestContext<T> Context<T>(T request,Uuid? user = null) where T : IRequestBase => new(request,
        new ClaimsPrincipal(new ClaimsIdentity([new Claim("iss","bdgrz"),new Claim("sub",(user ?? User).ToString()),
            new Claim("name","Change recorder")],"UnitTest")));
    public async Task RecordAsync(SignificantChangeContent? body = null)
    {
        var result = await new RecordSignificantChangeHandler(Operations).HandleAsync(Context(new RecordSignificantChange(Tenant,Program,Change,body ?? Body())),CancellationToken.None);
        Assert.True(result.IsSuccess,result.Error?.Message);
    }
    public async Task<IReadOnlyList<DomainEvent>> FactsAsync()
    {
        var facts = new List<DomainEvent>();
        await foreach (var record in Events.ReadAsync(EventStreamPattern.ForPattern(Tenant.ToString(),SignificantChange.Area,Change.ToString()),EventCursor.Start,CancellationToken.None))
            if (!record.Event.Metadata.IsAudit)
                facts.Add(record.Event);
        return facts;
    }
    public async ValueTask DisposeAsync()
    {
        await _scope.DisposeAsync();
        await _provider.DisposeAsync();
    }
    internal sealed class MutableClock : TimeProvider
    {
        public DateTimeOffset Now { get; set; } = new(2026,10,24,12,0,0,TimeSpan.Zero);
        public override DateTimeOffset GetUtcNow() => Now;
    }
    internal sealed class HookedContent(IImmutableContentStore inner) : IImmutableContentStore
    {
        public Func<Task>? BeforeRead { get; set; }
        public Func<ImmutableContentRef,Exception?>? Failure { get; set; }
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm,Uuid id,string schema,string mediaType,ReadOnlyMemory<byte> bytes,CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm,id,schema,mediaType,bytes,ct);
        public async Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm,ImmutableContentRef reference,CancellationToken ct = default)
        {
            if (BeforeRead is { } before)
            {
                BeforeRead = null;
                await before();
                throw new ImmutableContentUnavailableException("The original preparation raced an equal winner and temporarily lost its body.");
            }
            if (Failure?.Invoke(reference) is { } failure)
                throw failure;
            return await inner.ReadVerifiedAsync(realm,reference,ct);
        }
    }
}
''')
put(T+'SignificantChangeNativeTests.cs','''using Bdgrz.Compliance.Features.Changes;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Hosting.Persistence;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.Changes;

public sealed class SignificantChangeNativeTests
{
    [Fact]
    public async Task ShouldReplayOriginalAcceptanceGivenLaterRevisionAndLostResponseRetry()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();
        var body = fixture.Body();
        var request = new RecordSignificantChange(fixture.Tenant,fixture.Program,fixture.Change,body);
        var handler = new RecordSignificantChangeHandler(fixture.Operations);
        Assert.True((await handler.HandleAsync(fixture.Context(request),CancellationToken.None)).IsSuccess);
        fixture.Clock.Now = fixture.Clock.Now.AddHours(1);
        var revised = await new ReviseSignificantChangeHandler(fixture.Operations).HandleAsync(fixture.Context(
            new ReviseSignificantChange(Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Change,1,body with { Title = "Corrected migration" },"Correct the title")),CancellationToken.None);
        Assert.True(revised.IsSuccess,revised.Error?.Message);

        // Act
        var replay = await handler.HandleAsync(fixture.Context(request),CancellationToken.None);
        var changedIntent = await handler.HandleAsync(fixture.Context(request with { Content = body with { Title = "Different authored creation" } }),CancellationToken.None);
        var changedActor = await handler.HandleAsync(fixture.Context(request,Uuid.CreateVersion4()),CancellationToken.None);
        var current = await fixture.Changes.ReadAsync(fixture.Tenant,fixture.Program,fixture.Change);

        // Assert
        Assert.True(replay.IsSuccess,replay.Error?.Message);
        Assert.False(changedIntent.IsSuccess);
        Assert.False(changedActor.IsSuccess);
        Assert.Equal(2,(await fixture.FactsAsync()).Count);
        Assert.Equal("Corrected migration",current.View!.Current!.Content.Title);
        Assert.Equal(2,current.Owner.NativeSequence);
    }

    [Fact]
    public async Task ShouldRecoverEqualWinnerGivenImmutablePreparationFailsAfterConcurrentAcceptance()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();
        var body = fixture.Body();
        await fixture.RecordAsync(body);
        fixture.Clock.Now = fixture.Clock.Now.AddMinutes(1);
        var handler = new ReviseSignificantChangeHandler(fixture.Operations);
        var request = new ReviseSignificantChange(Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Change,1,
            body with { Title = "A concurrent exact correction" },"Correct the title");
        fixture.Content.BeforeRead = async () =>
        {
            var winner = await handler.HandleAsync(fixture.Context(request),CancellationToken.None);
            Assert.True(winner.IsSuccess,winner.Error?.Message);
        };

        // Act
        var recovered = await handler.HandleAsync(fixture.Context(request),CancellationToken.None);

        // Assert
        Assert.True(recovered.IsSuccess,recovered.Error?.Message);
        Assert.Equal(2,(await fixture.FactsAsync()).Count);
        Assert.Equal(2,(await fixture.Changes.ReadAsync(fixture.Tenant,fixture.Program,fixture.Change)).View!.Revision);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ShouldClassifyExactImmutableBodyFailureGivenCurrentScopedRead(bool unavailable)
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();
        await fixture.RecordAsync();
        var before = (await fixture.FactsAsync()).Count;
        fixture.Content.Failure = reference => reference.Schema == SignificantChangeContentStore.BodySchema
            ? (unavailable ? new ImmutableContentUnavailableException("The body is temporarily absent.") : new ImmutableContentIntegrityException("The body hash differs.")) : null;
        var handler = new GetSignificantChangeHandler(fixture.Changes,new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(true)));

        // Act
        var result = await handler.HandleAsync(fixture.Context(new GetSignificantChange(fixture.Tenant,fixture.Program,fixture.Change)),CancellationToken.None);
        var foreign = await handler.HandleAsync(fixture.Context(new GetSignificantChange(fixture.Tenant,Uuid.CreateVersion4(),fixture.Change)),CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict,result.Error!.Kind);
        Assert.Equal(unavailable,result.Error.IsTransient);
        Assert.Equal(RequestErrorKind.NotFound,foreign.Error!.Kind);
        Assert.Equal(before,(await fixture.FactsAsync()).Count);
    }

    [Fact]
    public async Task ShouldUseReceiptCutGivenLaterContentCorrection()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();
        var body = fixture.Body();
        await fixture.RecordAsync(body);
        var cutoff = fixture.Clock.Now;
        fixture.Clock.Now = fixture.Clock.Now.AddHours(1);
        Assert.True((await new ReviseSignificantChangeHandler(fixture.Operations).HandleAsync(fixture.Context(new ReviseSignificantChange(
            Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Change,1,body with { Title = "After cutoff" },"Later source correction")),CancellationToken.None)).IsSuccess);

        // Act
        var historic = await fixture.Changes.ReadThroughAsync(fixture.Tenant,fixture.Program,fixture.Change,cutoff);
        var current = await fixture.Changes.ReadAsync(fixture.Tenant,fixture.Program,fixture.Change);

        // Assert
        Assert.Equal(body.Title,historic.View!.Current!.Content.Title);
        Assert.Equal(1,historic.View.Revision);
        Assert.Equal("After cutoff",current.View!.Current!.Content.Title);
    }

    [Fact]
    public async Task ShouldFenceDirectoryLagAndPreserveCurrentSummaryGivenScopedList()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();
        await fixture.RecordAsync();
        var directory = new FitzSignificantChangeDirectory(new InMemoryKvClient(),fixture.Changes);
        var consistency = new SignificantChangeDirectoryReadConsistency(directory,fixture.Events);
        var handler = new ListSignificantChangesHandler(directory,new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(true)),consistency);
        var context = fixture.Context(new ListSignificantChanges(fixture.Tenant,fixture.Program,50,null));

        // Act
        var behind = await handler.HandleAsync(context,CancellationToken.None);
        var checkpoint = await directory.LoadCheckpointAsync(fixture.Tenant);
        var pattern = EventStreamPattern.ForPattern(fixture.Tenant.ToString(),SignificantChange.Area);
        await using (var batch = await directory.BeginAsync(new ProjectionBatchContext(new CheckpointIdentity(SignificantChangeDirectoryProjector.ProjectorName,pattern),checkpoint)))
        {
            var cursor = checkpoint.Cursor;
            await foreach (var record in fixture.Events.ReadAsync(pattern,cursor,CancellationToken.None))
            {
                await directory.ApplyAsync(record.Event);
                cursor = record.NextCursor;
            }
            await batch.CommitAsync(new ProjectionCheckpoint(cursor));
        }
        var current = await handler.HandleAsync(context,CancellationToken.None);

        // Assert
        Assert.False(behind.IsSuccess);
        Assert.True(behind.Error!.IsTransient);
        Assert.True(current.IsSuccess,current.Error?.Message);
        Assert.Equal("Production migration",Assert.Single(current.Value.Items).Title);
    }
}
''')
# The large-content RED keeps its name and now proves the actual native write and verified reconstruction.
p=R/(T+'SignificantChangeTests.cs');s=p.read_text().replace('public void ShouldRecordCompleteGovernedReferencesGivenSourceContentExceedsEventBudget()','public async Task ShouldRecordCompleteGovernedReferencesGivenSourceContentExceedsEventBudget()');old='''        Assert.Equal(1000, change.Current.Current.Content.EvidenceArtifactIds.Count);
    }''';s=s.replace(old,'''        Assert.Equal(1000, change.Current.Current.Content.EvidenceArtifactIds.Count);
        await using var fixture = new SignificantChangeNativeFixture();
        await ChangeSeeds.WriteAsync(fixture.Writer,fixture.Content,change);
        var owner = await fixture.Reader.HydrateAsync(new Bdgrz.Compliance.Features.Changes.SignificantChange(TenantId,ProgramId,ChangeId));
        var native = Assert.Single(new AggregateScenario<Bdgrz.Compliance.Features.Changes.SignificantChange>(owner).CommittedEvents);
        Assert.True(Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.Size(native) < Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.MaximumBytes);
        var read = await fixture.Changes.ReadAsync(TenantId,ProgramId,ChangeId);
        Assert.Equal(1000,read.View!.Current!.Content.AffectedSystemIds.Count);
        Assert.Equal(1000,read.View.Current.Content.EvidenceArtifactIds.Count);
    }''',1)
# AggregateScenario may expose only pending; get actual events from source instead (no reliance on testing implementation internals).
s=s.replace('''        var native = Assert.Single(new AggregateScenario<Bdgrz.Compliance.Features.Changes.SignificantChange>(owner).CommittedEvents);
        Assert.True(Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.Size(native) < Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.MaximumBytes);''','''        Assert.Equal(1,owner.NativeSequence);
        await foreach (var source in fixture.Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString(),"significant-changes",ChangeId.ToString()),EventCursor.Start,CancellationToken.None))
            if (!source.Event.Metadata.IsAudit)
                Assert.True(Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.Size(source.Event) < Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.MaximumBytes);''');p.write_text(s)
