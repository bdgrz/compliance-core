from pathlib import Path
R=Path('/tmp/compliance-significant-change-prepared/work');T='test/Compliance.Tests/Features/Changes/'
s=Path('test/Compliance.Tests/Features/AuditPackages/AuditPackageReadHttpTests.cs').read_text().replace('AuditPackages','Changes').replace('AuditPackageReadHttpTests','SignificantChangeHttpTests').replace('AuditPackage','SignificantChange').replace('audit-packages','significant-changes').replace('audit-package','significant-change').replace('audit_package_id','change_id').replace('package_id','change_id').replace('package-reader','change-reader').replace('packageId','changeId')
s=s.replace('GetProperty("change_id").GetString()','GetProperty("significant_change_id").GetString()')
s=s.replace('"Audit package", summary.GetProperty("name")','"Governed production change", summary.GetProperty("name")').replace('"draft", summary.GetProperty("status")','"recorded", summary.GetProperty("status")')
# The canonical route spelling now matches DTO.ChangeId. Keep the source proof and existing per-program visibility checks.
a=s.index('            var package = new SignificantChangeRules(');b=s.index('            var projection =',a)
s=s[:a]+'''            var package = new SignificantChangeRules(Tenant,Program,Uuid.CreateVersion4());
            Assert.Null(package.Record(new SignificantChangeContent(null,null,null,"Governed production change","A complete change body.",
                new DateOnly(2026,10,18),null,Member,[Uuid.CreateVersion4()],"high","confidential",[]),Member,"Change recorder",Now));
            await ChangeSeeds.WriteAsync(writer,content,package);
'''+s[b:]
s=s.replace('FitzSignificantChangeDirectory.ProjectorName','SignificantChangeDirectoryProjector.ProjectorName').replace('SignificantChangeManifest.Area','SignificantChange.Area')
s=s.replace('''                if (record.Event is SignificantChangeCreated created)
                    await projection.ApplyAsync(created);''','''                if (record.Event is ISignificantChangeFact)
                    await projection.ApplyAsync(record.Event);''')
# Old alias-route absence assertion would equal the new canonical spelling; assert the old incompatible alias instead.
s=s.replace('Assert.False(paths.TryGetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/significant-changes/{change_id}", out _));','Assert.False(paths.TryGetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/significant-changes/{significant_change_id}", out _));')
s=s.replace('public async Task ShouldDescribeOnlyCanonicalRouteIdentityGivenCustomPackageReadBinder()','public async Task ShouldDescribeCanonicalRouteAndIdentifiedMutationsGivenChangeHttpContract()')
s=s.replace('ShouldUseCanonicalPackageRouteGivenMisleadingQueryIdentities','ShouldUseCanonicalChangeRouteGivenMisleadingQueryIdentities').replace('ShouldHidePackageGivenAnotherExistingProgramRoute','ShouldHideChangeGivenAnotherExistingProgramRoute')
s=s.replace('            Assert.True(route.TryGetProperty("put", out _));','''            Assert.True(route.TryGetProperty("put", out _));
            Assert.True(paths.GetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/significant-changes/{change_id}/revisions/{command_id}").TryGetProperty("put",out _));
            Assert.True(paths.GetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/significant-changes/{change_id}/assessments/{command_id}").TryGetProperty("put",out _));''')
s=s.replace('var packageId','var changeId').replace('{packageId}','{changeId}').replace('return package.Id;','return package.Id;')
(R/(T+'SignificantChangeHttpTests.cs')).write_text(s)
# Reader nullness is explicit rather than inferred through nullable conditional comparisons.
p=R/'src/Compliance.Core/Features/Changes/SignificantChangeReader.cs';s=p.read_text().replace('sequence != owner.NativeSequence || last?.Header != owner.Header || last.CurrentContent != owner.CurrentContent','sequence != owner.NativeSequence || last is null || last.Header != owner.Header || last.CurrentContent != owner.CurrentContent');p.write_text(s)
