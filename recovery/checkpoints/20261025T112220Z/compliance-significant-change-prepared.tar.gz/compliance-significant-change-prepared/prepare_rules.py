from pathlib import Path
import re
r=Path('/tmp/compliance-significant-change-prepared');w=r/'work';op=w/'src/Compliance.Core/Features/Changes'
s=(r/'base/src/Compliance.Core/Features/Changes/SignificantChange.cs').read_text()
names=['SignificantChangeRecorded','SignificantChangeRevised','SignificantChangeImpactAssessed','ImpactReviewWorkLinked','SignificantChangeSystemDescriptionDecisionRecorded']
for name in names:s=re.sub(r'\b'+name+r'\b',name+'Body',s)
s=re.sub(r'\bSignificantChange\b','SignificantChangeRules',s)
s=s.replace('public sealed class SignificantChangeRules : Aggregate','public sealed class SignificantChangeRules')
s=s.replace('''        : base(changeId, new EventStreamAddress(tenantId.ToString(), "significant-changes",
            changeId.ToString()))
''','')
s=s.replace('        _tenantId = tenantId;', '        Id = changeId;\n        Stream = new EventStreamAddress(tenantId.ToString(), SignificantChange.Area, changeId.ToString());\n        _tenantId = tenantId;',1)
s=s.replace('    const int MaximumEventBytes = DomainEventPayload.MaximumBytes;\n','')
s=s.replace('Func<Uuid, Uuid, long, Uuid?, SignificantChangeView, DateTimeOffset, DomainEvent> createEvent','Func<Uuid, Uuid, long, Uuid?, SignificantChangeView, DateTimeOffset, object> createEvent')
s=re.sub(r'        if \(DomainEventPayload.Size\(ev\) > MaximumEventBytes\)\n            return Invalid\("The complete significant-change history exceeds the bounded event payload\."\);\n','',s)
idx=s.index('    readonly Uuid _tenantId;')
s=s[:idx]+'''    readonly Dictionary<Type, Action<object>> _reducers = [];
    readonly List<object> _applied = [];
    readonly List<object> _pending = [];
    public Uuid Id { get; }
    public EventStreamAddress Stream { get; }
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;
    public IReadOnlyList<object> AppliedChanges => _applied.AsReadOnly();
    public IReadOnlyList<object> PendingChanges => _pending.AsReadOnly();
    public void ClearPendingChanges() => _pending.Clear();
    void On<T>(Action<T> reducer) where T : class => _reducers.Add(typeof(T), value => reducer((T)value));
    public void Apply(object value)
    {
        if (!_reducers.TryGetValue(value.GetType(), out var reducer))
            throw new InvalidOperationException("The significant-change rule mutation has another kind.");
        reducer(value);
        _applied.Add(value);
    }
    internal void RaiseEvent(object value)
    {
        Apply(value);
        _pending.Add(value);
    }

'''+s[idx:]
s=s.replace('    CommandFailure? ValidateState(', '    internal CommandFailure? ValidateState(')
s=s.replace('    static bool ValidTransition(', '    internal static bool ValidTransition(')
s=s.replace('    static bool ValidInitialState(', '    internal static bool ValidInitialState(')
s=s.replace('/// <summary>Owns a native significant-change fact, impact history, follow-up work, and description disposition.</summary>',
 '/// <summary>Transient business rules and immutable read reconstruction; never retained by the compact command owner.</summary>')
(op/'SignificantChangeRules.cs').write_text(s)
for name in names:
 p=r/f'base/src/Compliance.Common/Features/Changes/{name}.cs';s=p.read_text();s=re.sub(r'\[Discriminator\([^\n]+\)\]\n','',s)
 s=re.sub(r'\b'+name+r'\b',name+'Body',s).replace(' : DomainEvent;',';')
 s=re.sub(r'/// <summary>[\s\S]*?/// </summary>', '/// <summary>Plain transient rule mutation; never emitted as a durable domain event.</summary>',s,count=1)
 (op/(name+'Body.cs')).write_text(s)
print('Pure transient significant-change rules + five plain rule mutation records prepared')
