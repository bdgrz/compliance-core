from pathlib import Path
R=Path('/tmp/compliance-significant-change-prepared/work');rel='test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseArchive.cs'
future=Path('/tmp/compliance-typeii-period-prepared/work')/rel
for d in ['base','work']:
 p=R.parent/d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(future.read_bytes())
p=R/rel;s=p.read_text();s='using Bdgrz.Compliance.Features.Changes;\nusing Bdgrz.Compliance.Tests.Features.Changes;\nusing Bdgrz.Compliance.Tests.Testing;\n'+s
s=s.replace('''    public async Task ShouldArchiveExactPublishedNativeCloseSourceGivenReconciliationApprovalAndFreeze()
    {
        // Arrange''','''    public Task ShouldArchiveExactPublishedNativeCloseSourceGivenReconciliationApprovalAndFreeze() => ArchiveAsync(includeChange: false);

    [Fact]
    public Task ShouldArchiveExactVerifiedChangeBodiesGivenNativeCloseHistoryWithGovernedReferences() => ArchiveAsync(includeChange: true);

    static async Task ArchiveAsync(bool includeChange)
    {
        // Arrange''')
s=s.replace('        var root = Path.Combine(','''        SignificantChangeRules? change = null;
        if (includeChange)
        {
            change = new SignificantChangeRules(fixture.TenantId,fixture.ProgramId,Uuid.CreateVersion4());
            Assert.Null(change.Record(new SignificantChangeContent(null,null,null,"Exact source-byte history","A governed change body in the close archive.",
                fixture.PeriodStart,null,fixture.ProposerMemberId,Enumerable.Range(0,1000).Select(index => Uuid.CreateVersion5(change.Id,"system:"+index)).ToArray(),
                "high","confidential",[]),fixture.ProposerMemberId,"Recorder",StartedAt));
            Assert.Null(change.Assess(1,new SignificantChangeImpactContent("not_significant","No key boundary or control changes.",
                false,false,false,false,["other"],[],[],[],[],[],false),fixture.ActorMemberId,"Assessor",StartedAt.AddHours(1)));
            await ChangeSeeds.WriteAsync(fixture.Writer,fixture.Host.Content,change);
        }
        var root = Path.Combine(''',1)
s=s.replace('var sources = new PublishingCloseSources(publisher);','''var sources = new PublishingCloseSources(publisher,includeChange ? new TypeIIPeriodCloseHistory(fixture.Reader,fixture.Events,
                new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(true)),
                new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Host.Content),fixture.Host.Content) : null);''')
s=s.replace('            Assert.True(body.RootElement.GetProperty("records").GetArrayLength() > 0);','''            Assert.True(body.RootElement.GetProperty("records").GetArrayLength() > 0);
            if (includeChange)
            {
                var recorded = body.RootElement.GetProperty("records").EnumerateArray().Single(item =>
                    item.GetProperty("payload").TryGetProperty("header",out var header) &&
                    header.GetProperty("significant_change_id").GetString() == change!.Id.ToString() &&
                    header.GetProperty("revision").GetInt64() == 1);
                var blob = recorded.GetProperty("content_blobs")[0];
                var exact = Convert.FromBase64String(blob.GetProperty("base64").GetString()!);
                Assert.Equal(blob.GetProperty("reference").GetProperty("bytes").GetInt64(),exact.LongLength);
                Assert.Equal(blob.GetProperty("reference").GetProperty("sha256").GetString(),Bdgrz.Compliance.Features.Kernel.ContentDigest.Sha256(exact));
                var reconstructed = JsonSerializer.Deserialize(exact,Bdgrz.Compliance.ComplianceCoreJsonContext.Default.SignificantChangeView);
                Assert.Equal("Exact source-byte history",reconstructed!.Current!.Content.Title);
                Assert.Equal(1000,reconstructed.Current.Content.AffectedSystemIds.Count);
                Assert.Equal(change!.Current!.Current!.Content.ContentSha256,reconstructed.Current.ContentSha256);
            }''')
# Typo: content SHA belongs the version, not its Content DTO.
s=s.replace('change!.Current!.Current!.Content.ContentSha256','change!.Current!.Current!.ContentSha256')
s=s.replace('sealed class PublishingCloseSources(TypeIIPeriodCloseSourcePublication publication)','sealed class PublishingCloseSources(TypeIIPeriodCloseSourcePublication publication, TypeIIPeriodCloseHistory? history = null)')
s=s.replace('''            var facts = period.OccurrenceGenerations.Select(fact => TypeIIPeriodCloseHistory.Capture(period.Stream, fact)).ToArray();''','''            var native = period.OccurrenceGenerations.Select(fact => TypeIIPeriodCloseHistory.Capture(period.Stream,fact)).ToList();
            if (history is not null)
            {
                var captured = await history.ReadAsync(current,actor,operation.AcceptedAt,ct);
                Assert.Empty(captured.Blockers);
                native.AddRange(captured.Records);
            }
            var facts = native.ToArray();''');p.write_text(s)
# Existing named summary field remains Name.
p=R/'test/Compliance.Tests/Features/Changes/SignificantChangeNativeTests.cs';s=p.read_text().replace('Assert.Single(current.Value.Items).Title','Assert.Single(current.Value.Items).Name');p.write_text(s)
p=R/'src/Compliance.Core/Features/Changes/ListSignificantChangesHandler.cs';s=p.read_text();a=s.index('        try\n        {\n        if (items.Count');b=s.index('    async ValueTask<bool>',a)
section=s[a:b].replace('''        catch (ImmutableContentIntegrityException exception)''','''        catch (KvDirectoryQueryException)
        {
            return Result<Page<SignificantChangeSummaryView>>.Failure(new RequestError(RequestErrorKind.Validation,"The significant-change cursor is invalid."));
        }
        catch (ImmutableContentIntegrityException exception)''');s=s[:a]+section+s[b:];s=s.replace('''            if (summary.TenantId != tenantId || summary.ProgramId != programId)
                return false;''','''            if (summary.TenantId != tenantId || summary.ProgramId != programId)
                throw new ImmutableContentIntegrityException("The change discovery lookahead returned another scope.");''').replace('''                detail.ProgramId != programId || detail.SignificantChangeId != summary.SignificantChangeId)
                return false;''','''                detail.ProgramId != programId || detail.SignificantChangeId != summary.SignificantChangeId)
                throw new ImmutableContentUnavailableException("A listed native change is not readable yet.");''');p.write_text(s)
