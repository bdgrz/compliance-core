Old-API RED filters (each independent, same fixture):

- `FullyQualifiedName~SignificantChangeTests.ShouldRecordCompleteGovernedReferencesGivenSourceContentExceedsEventBudget`
- `FullyQualifiedName~SignificantChangeTests.ShouldRequireCorrectiveActionLinkGivenCurrentAssessmentWithoutDescriptionReview`

The first covers supported 1,000+1,000 refs rejected by full-State event size. The second demonstrates that current PeriodCloseEligible ignores RelatedCorrectiveActionIds when no description review is required, though LinkReviewWork requires both selected work kinds. Retain both acceptance names; parent owns all runtime RED/green.

- `FullyQualifiedName~SignificantChangeTests.ShouldRetainCompleteChronologyGivenMoreThanThirtyTwoGovernedVersions` proves the invented lifetime32 cap must be removed from both rules and native header validation; migrated acceptance publishes all40 bounded native facts and reconstructs the entire chronology.
