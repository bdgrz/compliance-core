from pathlib import Path
import difflib,subprocess,shutil
P=Path('/tmp/compliance-significant-change-prepared');T='test/Compliance.Tests/Features/Changes/SignificantChangeTests.cs';K=P/'work/src/Compliance.Core/Features/Changes'
p=K/'SignificantChange.cs';s=p.read_text().replace('h.CurrentVersionNumber is < 1 or > 32','h.CurrentVersionNumber < 1');p.write_text(s)
p=K/'SignificantChangeRules.cs';s=p.read_text().replace('    const int MaximumVersions = 32;\n','').replace('current.Status == "closed" || current.Versions.Count >= MaximumVersions','current.Status == "closed"').replace('A closed change or exhausted chronology cannot be revised.','A closed change cannot be revised.').replace('state.Versions.Count is < 1 or > MaximumVersions','state.Versions.Count < 1');p.write_text(s)
red='''    [Fact]
    public void ShouldRetainCompleteChronologyGivenMoreThanThirtyTwoGovernedVersions()
    {
        // Arrange
        var change = RecordedChange();

        // Act
        for (var version = 2; version <= 40; version++)
            Assert.Null(change.Revise(change.Revision,Content() with { Title = "Governed correction " + version },
                "Correct source narrative",RecorderId,"Compliance lead",Now.AddMinutes(version)));

        // Assert
        Assert.Equal(40,change.Current!.CurrentVersionNumber);
        Assert.Equal(40,change.Current.Versions.Count);
    }

'''
verify=P/'red-cap-reconstruction';shutil.rmtree(verify,ignore_errors=True);target=verify/T;target.parent.mkdir(parents=True);shutil.copy2(P/'base'/T,target)
r=subprocess.run(['patch','-p1','--batch','-i',str(P/'behavioral-red.patch')],cwd=verify,text=True,capture_output=True);assert r.returncode==0,r.stdout+r.stderr
old=target.read_text();old=old.replace('    [Fact]\n',red+'    [Fact]\n',1);target.write_text(old)
before=(P/'base'/T).read_text();(P/'behavioral-red.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),old.splitlines(keepends=True),fromfile='a/'+T,tofile='b/'+T)))
p=P/'work'/T;s=p.read_text();new=red.replace('public void ShouldRetainCompleteChronology','public async Task ShouldRetainCompleteChronology').replace('        Assert.Equal(40,change.Current.Versions.Count);','''        Assert.Equal(40,change.Current.Versions.Count);
        await using var fixture = new SignificantChangeNativeFixture();
        await ChangeSeeds.WriteAsync(fixture.Writer,fixture.Content,change);
        var snapshot = await fixture.Changes.ReadAsync(TenantId,ProgramId,ChangeId);
        Assert.Equal(40,snapshot.Owner.NativeSequence);Assert.Equal(40,snapshot.View!.Versions.Count);
        await foreach (var source in fixture.Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString(),"significant-changes",ChangeId.ToString()),EventCursor.Start,CancellationToken.None))
            if (!source.Event.Metadata.IsAudit)
                Assert.True(Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.Size(source.Event) < Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.MaximumBytes);''');s=s.replace('    [Fact]\n',new+'    [Fact]\n',1);p.write_text(s)
p=P/'behavioral-red.md';s=p.read_text()+'\n- `FullyQualifiedName~SignificantChangeTests.ShouldRetainCompleteChronologyGivenMoreThanThirtyTwoGovernedVersions` proves the invented lifetime32 cap must be removed from both rules and native header validation; migrated acceptance publishes all40 bounded native facts and reconstructs the entire chronology.\n';p.write_text(s)
p=P/'README.md';s=p.read_text().replace('Both compile using only existing old APIs.','All three compile using only existing old APIs.').replace('A distinct logical operation','The invented lifetime32 version cap is removed from both transient business rules and native header validation; a40-version old-API regression remains in the migrated suite with native publication/readback.\n\nA distinct logical operation');p.write_text(s)
