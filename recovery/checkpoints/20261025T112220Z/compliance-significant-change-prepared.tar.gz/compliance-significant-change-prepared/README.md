# SignificantChange native owner cutover — prepared offline

Status: source/test/shared patches prepared, not compiled or runtime-qualified by this agent. Parent exclusively owns dotnet format/build/test, direct per-file Jev and integration. Main was never edited. No new issue, branch or worktree was created.

## Integration sequence

1. Apply `behavioral-red.patch` to the current old owner surface and run each filter in `behavioral-red.md` independently. All three compile using only existing old APIs. Reverse that standalone patch before applying the full slice.
2. Land the frozen TypeII period stage2 first. `CloseSources.cs` and `CloseArchive.cs` intentionally use that future exact baseline; the rest of the implementation baselines are current retained Change source. Parent must preserve Policy/Control constructor overlays and its current shared wiring.
3. Apply `implementation.patch` and `tests.patch` together. Merge the three `shared.patch` hunks or use `shared-wiring-deltas.json`.
4. Parent runs whitespace formatting, strict Release build, focused `Features.Changes` + TypeII close tests, full unit suite, six `SignificantChangeHttpTests` WebIntegration cases, direct per-file Jev and normal PR integration. Refresh the shared aggregate-command coverage map from the actual resulting source.

`manifest.json` records every before/after SHA, artifact SHA and new acceptance name. `static-checks.json` records clean syntax/explicit constructor arity checks and zero original acceptance removals. These are preparation checks, not a build/test pass.

## Implemented behavior

The Aggregate retains only a bounded scalar `SignificantChangeAuthorityHeader`, immutable current-body reference, native sequence and selected `NativeAcceptance`. Full references, versions, assessments, links and decisions live in verified immutable JSON. `SignificantChangeRules` is a transient non-Aggregate business/read model; its five plain body mutations never become native DomainEvents.

The five retained business facts advance from version2 to3 (ImpactReviewWorkLinked likewise advances its actual prior schema). All carry bounded header/body/change refs, attribution, native provenance, frozen first-response ref and `MutationResultContent` envelope. No legacy full-State reader/writer or Aggregate.Current compatibility path is shipped. Original default-JsonSerializer logical content/assessment preimages remain unchanged.

All five handlers use identified native operations and explicit typed Unit200 responses. Creation's logical id remains ChangeId; revise/assess and trusted callbacks add CommandId. Revise/assess preserve caller ExpectedRevision exactly. Current program/restricted authorization remains in front of execution/replay. Reads, external guards, business application, publication and frozen response creation occur inside async NativeOperation.Prepare, so equal concurrent acceptance is rechecked on preparation failures. Append checks exact native and physical cuts and re-executes the actual domain rule against the verified before/after bodies, rather than trusting scalar header changes alone.

The invented lifetime32 version cap is removed from both transient business rules and native header validation; a40-version old-API regression remains in the migrated suite with native publication/readback.

A distinct logical operation whose domain rule is an existing no-op receives a durable original Unit receipt with ChangeCount0 and unchanged business revision/body; exact retries replay that receipt before revisiting current dependencies. New identified revision commands still require the current original ExpectedRevision. Native sequence advances per accepted operation, not per business change.

The actual eligibility defect is fixed: both selected review-work IDs and corrective-action IDs must be linked before PeriodCloseEligible. Incident Resolve/ValidResolution already enforce exact required follow-up IDs and completion proofs, so Incident behavior is preserved.

`SignificantChangeReader` verifies the native sequence, body/mutation schemas, exact before/after hashes and business equivalence at the hydrated owner cut; it also reconstructs the receipt cut for close sources. Current scoped reads hide foreign programs before reading their content. Missing immutable data returns transient Conflict; integrity failure returns permanent Conflict. Replay uses the original frozen typed response.

Discovery persists bounded header/summary rows in fresh projection-v2 / SignificantChangeDirectoryV2. List retains updated-at order and per-record restricted filtering, composes details from current verified sources, rejects repeated/invalid cursors, and fences the exact projection checkpoint/source tail before and after the entire page/lookahead. Get reads the authoritative scoped source directly. A missing/corrupt listed body fails the whole page.

The Link reactor verifies exact immutable assessment content before issuing a deterministic source-event command id. The shared description-decision reactor and correlation reader migrate only Change branches; all actual Incident branches remain intact. The existing typed reactor test bus gains Unit support and an explicit success reset for checkpoint recovery tests.

TypeII close history now reads native Change history under receipt cutoff while applying current live restricted visibility. Its published canonical source envelope includes exact digest-verified body and mutation bytes as Base64 plus their complete refs. The archive remains a correctly labeled domain-prefixed canonical `.snapshot` blob. The new real-flow regression publishes a Change with 1,000 governed IDs, captures it through production close history, approves/freezes the period close, builds a package ZIP and verifies the embedded full body bytes, physical length and digest. Incident history keeps its existing representation until its own owner cutover.

## Surface deltas

- `RecordSignificantChange` remains PUT .../significant-changes/{change_id}, now typed Unit200.
- `ReviseSignificantChange`: PUT .../{change_id}/revisions/{command_id}.
- `AssessSignificantChange`: PUT .../{change_id}/assessments/{command_id}.
- Get uses canonical `{change_id}` matching its existing DTO; obsolete `{significant_change_id}` alias is removed.
- Existing scoped list and callable command policies remain; internal callbacks remain trusted system only. No bare/global operation route or new lookup contract is introduced.

No external prerequisite blocks this Change slice. Runtime validation and any actual compiler/Jev findings remain for parent integration.
