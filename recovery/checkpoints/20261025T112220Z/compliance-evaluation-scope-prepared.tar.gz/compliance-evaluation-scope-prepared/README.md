# Native evaluation plan and system-instance scope cutovers

Frozen offline, clearly partitioned artifacts; parent runtime/integration pending. Requires the shared NativeOwnerHistory helper from small3. Source and wire ownership remain in this backend.

Apply behavioral-red.patch and run red-filter.txt first, then after-red.patch. Four old-API REDs prove actual lifetime history retention and replay failures across later plan progress/instance retirement. full.patch is the exact alternative reconstruction. implementation.patch and tests.patch are review subsets; manifest.json records exact before/after hashes and partitions.

Both command owners retain only latest native fact/ref and scalar authority plus selected NativeAcceptance. Complete original typed view/procedure/decision content is immutable and verified through source-generated serializers; version/as-of histories are reconstructed outside Aggregate. Native root facts carry Operation/FirstResponse/MutationResultContent envelopes. New operations resolve acceptance before mutable Control/instance/owner/person/waiver reads, freeze server clock once and recover an equal accepted winner even after expected preparation content failure. Current management, personal HTTP, restricted visibility, parent identity, exact source revision, independent waiver and monotonic effective-date checks are retained.

Existing public DTOs have no caller operation field, so their explicit computed IIdentifiedRequest implementations derive IDs from tenant/owner/immutable parent and original expected counter. No JSON field or URI is added. This gives stable original results and matching actual HTTP native captures, with changed actor/intent/revision conflicting. New production-host HTTP tests verify first-response descriptor rereads, exact frozen bytes/status, retries and anonymous refusal. Scope wrong-parent requests remain NotFound even after another scope decision was accepted.

All original rule tests are retained as explicit non-Aggregate Rules models; original handler/transport/projection tests and assertions remain. Real consumers (Get/List/Start evaluation, scope Get/projection/coverage contract) and all direct fixture/constructor sites are migrated. Read-model history is preserved; no compatibility Current/Decisions shim is added to native owners.

No main/source checkout, .NET, Git, worktree, Jev, GitHub issue or deployment mutations were performed. See LOCAL-QUALIFICATION.md for honest Control permit and persisted-v1 boundaries. Static artifacts are not runtime evidence.
