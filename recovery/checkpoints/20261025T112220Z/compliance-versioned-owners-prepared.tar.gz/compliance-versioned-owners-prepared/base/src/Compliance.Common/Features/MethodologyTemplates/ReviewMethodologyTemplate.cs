using Bdgrz.Compliance.Features.Tenants;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.MethodologyTemplates;

/// <summary>Records the review methodology template intent required by the owning feature workflow.</summary>
[Discriminator("bdgrz.methodology-templates.review-methodology-template", 2)]
public sealed record ReviewMethodologyTemplate(Uuid CommandId, Uuid TemplateId, long Version, string Outcome, string Comments) : IRequest, IPlatformOperatorRequest, IIdentifiedRequest, ICallable
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}
