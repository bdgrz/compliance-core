# Native MethodologyTemplate history and owning published reads

Prepared offline atop the integration queue: S29 scoped audit-package reads, then latest native contribution cutover. Shared base snapshots contain those prerequisites, so this delta preserves them. No main edits, builds/tests, Git writes or GitHub issues.

## Actual RED path

Apply `history-limits-red.patch` alone before production changes. Existing handler tests require 66 historical versions and an original body larger than the native event envelope; the snapshot owner fails its lifetime/frame limits. Optional `publication-reads-http-red.patch` adds baseline-compatible production-host tests for the currently absent scoped catalog GET. Run the two limit methods by name, plus MethodologyTemplateReadHttpTests with WebIntegration enabled. Then apply `tests-after-both-red.patch` if both RED patches were used, or `tests-after-red.patch` for history RED only, followed by `implementation.patch` and `shared.patch`. For direct application use `tests.patch` + implementation/shared.

## Complete owning cutover

The continuing MethodologyTemplate owner retains current authority, last published identity, immutable pointers and selected native receipt state. Whole history lives in immutable one-version deltas; retirement holds no version bodies. The exact-stream history reader checks the hydrated revision cut, scope/digest/schema, attribution and immutable-prefix transitions. All five existing mutation handlers replay original Unit results before reading current/history material. Independent review/approval, exact historical content, original display evidence and changed actor/intent/original revision refusals remain. Lifetime count/frame ceilings are removed, while bounded business content rules remain.

A fresh global platform publication directory indexes VersionId -> exact template/version identity and one catalog identity per first publication. Its rows contain no content/name/status authority. The owning GetVersion/List handlers resolve actual native selected content and use a caught-up source checkpoint before/after reads. List pages remain bounded and stable under later publication; cursors are scoped to the caller tenant/program around the installed KvDirectory opaque cursor. Later draft names/content are not exposed or read. Missing selected content yields transient Conflict, corruption permanent Conflict, and failures never return partial pages. Retired templates report retired status while exact historical published versions remain readable, preserving existing application behavior.

Shared changes register the owner/read services, both scoped handlers, a global publication projector, two scoped GET paths, and three JSON roots. No MCP tools are added. Existing IProgramReadRequest authorization applies before handlers; production-host regressions cover authorized catalog access, denied reads and unknown program scope. Existing Application and successor consumers use exact historical source versions; accepted application retry uses its retained original source before fresh content feasibility. No .Current template history shim, unbounded area scan, or throwing query is shipped.

Both original owner tests and every existing handler/contribution/application acceptance test name are retained. Additional tests cover compact large-body facts, 66 versions, exact replay with unavailable history, content failure/recovery, current published read independent of unavailable later draft, published-only discovery, stable pages and scoped cursors, projection lag/replay/races, retirement and no partial pages.

Remaining separate work is TemplateApplication native-history narrowing and the two concrete accepted-contribution/created-draft producer proof blockers in ../blockers.json. This cutover does not defer the unblocked GetVersion/List producer seam.

Only C# syntax parsing and three exact patch reconstruction sequences were run here. Parent runs actual RED/GREEN, semantic compilation, analyzers/format/full units, coverage regeneration and direct Jev per final hash.
