# S34 contribution cutover, atop the replay preparation

This stage replaces the retained MethodologyTemplateContribution command owner and its three existing producers. All edits are under this directory. No main source, index, branches, GitHub state, builds or tests were changed/run.

## RED and implementation artifacts

- `contribution-independence-red.patch`: a standalone actual-handler regression on the corrected replay baseline. It uses the existing handler constructors and proves the same user cannot review their own tenant proposal merely because platform context derives another member ID. Run `ShouldRejectContributionSelfReviewGivenSameUserAcrossTenantAndPlatformContexts` before native integration for behavioral RED.
- `contribution-implementation.patch`: compact owner, three compact native business facts, pure normalization/rules helper, verified reader, native original-result executor and all three existing producers.
- `contribution-tests.patch`: all native-flow tests/fixture migration, including that independence regression. Use this when the standalone RED patch was not applied.
- `contribution-tests-after-red.patch`: the remaining test migration if the standalone RED patch already exists.
- `contribution-shared.patch`: only two DI service registrations; no new HTTP/MCP route, producer registration, or JSON-context type is invented. Existing producer registrations remain active. Existing MethodologyTemplateContributionView serialization metadata already exists.
- `contribution-manifest.json`: exact baseline/prepared file SHAs, retained acceptance declarations, new test names and syntax status.

Patch order after the corrected eight-owner replay implementation: tests (or tests-after-red), implementation, shared DI. The isolated patch sequence reconstructed every prepared hash; C# syntax parsing was clean. Semantic compilation and test execution belong to the parent.

## Authority and recovery

The owner retains only source identity, canonical proposer/reviewer user identities, current phase/revision and one immutable content reference. It stores no read snapshot, contribution body, generic receipt event, or lifetime command dictionary. Existing business facts now carry OperationProvenance, first response and immutable original Unit result. NativeOperationExecutor supplies append/OCC/replay behavior; exact retry is resolved before current content or lifecycle reads.

Business bodies are verified immutable MethodologyTemplateContributionView content; existing content normalization, de-identification, three distinct actor checks, attribution and share privacy remain covered. Pure rules never emit events or implement an alternate persistence/read path. The verified reader checks scope/revision/phase and actor identities against compact authority. Shareable content continues to omit source tenant/record identity.

The canonical user subject now fences independence across client and platform roles. Presentation/member IDs remain frozen in the business view, while generated clock/display changes do not change native operation binding. Native root response content is read and verified on replay. A new regression makes current contribution content unavailable after acceptance and still replays all three original operations without reading it; changed intent conflicts.

This stage does not claim the entire S34 family complete. `blockers.json` records the exact missing accepted-contribution transfer producer and created-draft callback contracts. MethodologyTemplate's lifetime version history remains the next independent native-history conversion; no new undefined producer or query route is enabled here.
