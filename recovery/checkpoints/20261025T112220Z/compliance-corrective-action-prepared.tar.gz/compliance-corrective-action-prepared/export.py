from pathlib import Path
import hashlib,difflib,json,subprocess,shutil,os,re
p=Path('/tmp/compliance-corrective-action-prepared');base=p/'base';work=p/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
source=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')];red=[r for r in tests if not (base/r).exists()];migration=[r for r in tests if (base/r).exists()]
def export(name,selected):
 text=[]
 for r in selected:
  a=base/r;b=work/r;text+=difflib.unified_diff(a.read_text().splitlines(True) if a.exists() else [],b.read_text().splitlines(True),fromfile='a/'+r if a.exists() else '/dev/null',tofile='b/'+r)
 f=p/name;f.write_text(''.join(text));return {'path':str(f),'sha256':sha(f),'paths':selected}
arts={k:export(k,v) for k,v in [('implementation.patch',source),('tests.patch',tests),('behavioral-red.patch',red),('green-after-red.patch',source+migration),('full.patch',paths)]}
checks=[]
for name,sequence in [('full',['full.patch']),('staged',['behavioral-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/name;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest)
 for patch in sequence:
  run=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,text=True,capture_output=True);assert run.returncode==0,run.stdout+run.stderr
 assert all(sha(dest/r)==sha(work/r) for r in paths);checks.append({'sequence':sequence,'exact':True})
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
p=Parser(Language(tree_sitter_c_sharp.language()));fs=list(Path("/tmp/compliance-corrective-action-prepared/work").rglob("*.cs"));print(json.dumps({"files":len(fs),"errors":[str(f) for f in fs if p.parse(f.read_bytes()).root_node.has_error]}))
'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')));assert not syntax['errors'],syntax
acceptances=[]
for before in (base/'test').rglob('*.cs'):
 after=work/before.relative_to(base);names=lambda f:set(re.findall(r'\b(Should\w+)\s*\(',f.read_text()));assert names(before)<=names(after);assert after.read_text().count('Assert.')>=before.read_text().count('Assert.');acceptances+=sorted(names(before))
newtests=[name for r in red for name in re.findall(r'\b(Should\w+)\s*\(',(work/r).read_text())]
report={'paths':[{'path':r,'before':sha(base/r),'after':sha(work/r),'mainStillMatchesBaseline':sha(repo/r)==sha(base/r)} for r in paths],'artifacts':arts,'reconstruction':checks,'syntax':syntax,'prerequisites':['Current merged SourceUse72 finalized-history selection + protected owner fact hook','Merged central NativeOperationExecutor expected preparation failure acceptance recheck'],'runtime':'Not run; root owns slot.','preservedAcceptanceNames':acceptances,'newTests':newtests,'newRows':4,'constructors':{'CompleteCorrectiveActionHandler':'(NativeOperationExecutor, FindingReader, OperatingAuthority, IImmutableContentStore, TimeProvider); removed unused IAggregateReader. Existing direct construction absent. Old-API regression uses ActivatorUtilities.CreateInstance and compiles with both arities.'},'sourceUse':'base.Apply(ev); Uses.ObserveOwnerFact(ev) preserved exactly. Existing generic selection/finalization and all terminal proof binding remain unchanged. No reservation or terminal history collection reintroduced.','wire':'Existing actual v3 content tags/v1 source-use tags unchanged. Fresh completion producer explicitly records FirstOwner. No public routes/DTO/DI/JSON deltas.','qualification':'Stage1 corrective-action compaction only. Full Finding owner/admission/closure history migration follows separately; materializer still proves exact historical parent source before reply. No global operation qualification or fabricated migration.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n');(p/'behavioral-red-filter.txt').write_text('FullyQualifiedName~CorrectiveActionNativePreparationTests|FullyQualifiedName~CorrectiveActionNativeHistoryTests|FullyQualifiedName~CorrectiveActionMaterializationContentTests\n');(p/'focused-filter.txt').write_text('FullyQualifiedName~CorrectiveAction|FullyQualifiedName~Finding|FullyQualifiedName~SourceUseReservations|FullyQualifiedName~FollowUpCompletion|FullyQualifiedName~SignificantChange|FullyQualifiedName~ComplianceIncident\n');print(json.dumps({'paths':len(paths),'syntax':syntax,'preserved':len(acceptances),'artifacts':arts},indent=2))
