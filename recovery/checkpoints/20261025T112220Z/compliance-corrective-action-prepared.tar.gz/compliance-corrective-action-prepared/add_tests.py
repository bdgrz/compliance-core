from pathlib import Path
p=Path('/tmp/compliance-corrective-action-prepared/work/test/Compliance.Tests/Features/Remediation');p.mkdir(parents=True,exist_ok=True)
p.joinpath('CorrectiveActionNativePreparationTests.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Tests.Features.Operations;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Remediation;

public sealed class CorrectiveActionNativePreparationTests
{
    [Fact]
    public async Task ShouldReturnEqualCompletionWinnerGivenFindingReadFailsAfterConcurrentAdmission()
    {
        // Arrange
        var fixture = await OperationsFixture.CreateAsync();
        await using var provider = fixture.Provider;
        var finding = await fixture.RaiseFindingAsync(fixture.OwnerMemberId);
        finding = await fixture.AddActionAsync(finding, fixture.OwnerMemberId, fixture.Today.AddDays(7));
        var actionId = Assert.Single(finding.CorrectiveActions).ActionId;
        var request = fixture.Complete(finding, actionId, "Access removed.", OperationsFixture.FullSupport);
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var inner = services.GetRequiredService<IAggregateReader>();
        var executor = services.GetRequiredService<IAggregateExecutor>();
        var content = services.GetRequiredService<IImmutableContentStore>();
        var events = services.GetRequiredService<IDomainEventReader>();
        var clock = new MovingClock();
        FindingView? winner = null;
        var other = ActivatorUtilities.CreateInstance<CompleteCorrectiveActionHandler>(services, clock);
        var reader = new ConcurrentFindingReader(inner, FindingAggregate.StreamId(fixture.ProgramId, finding.FindingId), async () =>
        {
            clock.Now = clock.Now.AddDays(1);
            var accepted = await other.HandleAsync(new RequestContext<CompleteCorrectiveAction>(request,
                ProgramManagementServices.Actor(fixture.OwnerUserId)), CancellationToken.None);
            Assert.True(accepted.IsSuccess, accepted.Error?.Message);
            winner = accepted.Value;
        });
        var handler = ActivatorUtilities.CreateInstance<CompleteCorrectiveActionHandler>(services,
            new NativeOperationExecutor(reader, executor, content), new FindingReader(reader, events, content), clock);

        // Act
        var result = await handler.HandleAsync(new RequestContext<CompleteCorrectiveAction>(request,
            ProgramManagementServices.Actor(fixture.OwnerUserId)), CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.NotNull(winner);
        Assert.Equal(winner, result.Value);
        Assert.Equal(2, (await fixture.ActionAsync(finding.FindingId, actionId)).Revision);
        Assert.Equal(1, reader.CompetingAdmissions);
    }

    sealed class ConcurrentFindingReader(IAggregateReader inner, Uuid finding, Func<Task> admit) : IAggregateReader
    {
        bool _armed = true;
        public int CompetingAdmissions { get; private set; }
        public async ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate, CancellationToken ct = default)
            where TAggregate : Aggregate
        {
            if (_armed && aggregate is FindingAggregate && aggregate.Id == finding)
            {
                _armed = false;
                await admit();
                CompetingAdmissions++;
                return aggregate;
            }
            return await inner.HydrateAsync(aggregate, ct);
        }
    }

    sealed class MovingClock : TimeProvider
    {
        public DateTimeOffset Now { get; set; } = DateTimeOffset.UtcNow;
        public override DateTimeOffset GetUtcNow() => Now;
    }
}
''')
# Use the proven finalized history fixture shape without source-store bypasses.
s=Path('/tmp/compliance-evidence-request-prepared/work/test/Compliance.Tests/Features/Evidence/EvidenceRequestNativeHistoryTests.cs').read_text()
s=s.replace('Features.Evidence','Features.Remediation').replace('EvidenceRequestNativeHistoryTests','CorrectiveActionNativeHistoryTests').replace('ShouldKeepOnlyLifecycleContentAndSelectedFenceGivenLongSettledUseHistory','ShouldRetainOnlyLifecycleAndPermanentFenceGivenManyClosedParentGenerations')
a=s.index('        var source = ');b=s.index('        var facts = ',a)
s=s[:a]+'''        var findingId = Uuid.CreateVersion4();
        var source = new CorrectiveAction(tenant, program, findingId, id);
        var parent = new FindingAggregate(tenant, program, findingId).Stream;
        var memberId = Uuid.CreateVersion4();
        var actor = ActorReference.ForMember(memberId, "Action owner");
        var opened = new CorrectiveActionAddedV2(Uuid.CreateVersion4(), tenant, program, findingId, 1,
            NativeFacts.Ref(FindingContent.ActionSchema), NativeFacts.Root(source, Uuid.CreateVersion4(),
                nameof(MaterializeCorrectiveAction), null), NativeFacts.Ref(), null, null);
        var fulfilled = new CorrectiveActionCompletedV2(Uuid.CreateVersion4(), tenant, program, findingId, 2, id,
            "Access removed.", NativeFacts.Ref(FindingContent.EvidenceSchema), memberId, actor, NativeFacts.Now,
            NativeFacts.Root(source, Uuid.CreateVersion4(), nameof(CompleteCorrectiveAction), 1), NativeFacts.Ref(),
            NativeFacts.Ref());
'''+s[b:]
s=s.replace('var intent = NativeFacts.Ref(SourceUseAuthorizationIntent.Schema);','var intent = NativeFacts.Ref(SourceUseAuthorizationIntent.Schema);\n            var generation = index + 1L;')
s=s.replace('"Evidence use"','"Finding closure use"').replace('source.Stream, source.Stream,\n                source.Stream);','source.Stream, source.Stream,\n                parent);')
s=s.replace('EvidenceRequestActionCompletionUseAuthorized(source.Stream, 2, 1,','CorrectiveActionFindingClosureUseAuthorized(source.Stream, 2, generation,')
s=s.replace('EvidenceRequestActionCompletionUseSettled(source.Stream, 2, 1,','CorrectiveActionFindingClosureUseSettled(source.Stream, 2, generation,')
s=s.replace('operation with { LogicalId = Uuid.CreateVersion4() }, null, null));','operation with { LogicalId = Uuid.CreateVersion4() }, null, null, SourceUseSettlementDisposition.ParentClosed));')
s=s.replace('new ReservationKey(root, source.Stream, 1, source.Stream,','new ReservationKey(root, parent, (ulong)generation, source.Stream,').replace('SourceUsePurpose.ActionCompletionReview','SourceUsePurpose.FindingClosure')
s=s.replace('new EvidenceRequest(tenant, program, id)','new CorrectiveAction(tenant, program, findingId, id)').replace('typeof(EvidenceRequest)','typeof(CorrectiveAction)').replace('owner.AuthorizeActionCompletionUse','owner.AuthorizeFindingClosureUse').replace('owner.Opened','owner.Added').replace('owner.FulfilledFact','owner.Completed').replace('        Assert.Equal(fulfilled.ArtifactId, owner.View()!.ArtifactId);','        Assert.Contains("fenced by a closed finding generation", owner.PrepareComplete(2).Error!.Message, StringComparison.Ordinal);').replace('AggregateScenario<EvidenceRequest>','AggregateScenario<CorrectiveAction>')
p.joinpath('CorrectiveActionNativeHistoryTests.cs').write_text(s)
p.joinpath('CorrectiveActionMaterializationContentTests.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Tests.Features.Operations;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Remediation;

public sealed class CorrectiveActionMaterializationContentTests
{
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ShouldClassifyImmutableAdmissionFailureGivenMaterializationContentIsUnavailableOrCorrupt(bool unavailable)
    {
        // Arrange
        var fixture = await OperationsFixture.CreateAsync();
        await using var provider = fixture.Provider;
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var findingId = Uuid.CreateVersion4();
        var actionId = Uuid.CreateVersion4();
        var target = new CorrectiveAction(fixture.TenantId, fixture.ProgramId, findingId, actionId);
        var command = new MaterializeCorrectiveAction(Uuid.CreateVersion4(), new NativeFactReference(
            new FindingAggregate(fixture.TenantId, fixture.ProgramId, findingId).Stream, Uuid.CreateVersion4(), 1),
            target.Stream, actionId, 1, 0, NativeFacts.Ref(), findingId, actionId);
        var handler = new MaterializeCorrectiveActionHandler(services.GetRequiredService<IAggregateReader>(),
            services.GetRequiredService<IAggregateExecutor>(), new UnreadableContent(unavailable), TimeProvider.System);

        // Act
        var result = await handler.HandleAsync(new RequestContext<MaterializeCorrectiveAction>(command,
            RequestActor.System), CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error!.Kind);
        Assert.Equal(unavailable, result.Error.IsTransient);
        Assert.False((await fixture.ActionAsync(findingId, actionId)).IsMaterialized);
    }

    sealed class UnreadableContent(bool unavailable) : IImmutableContentStore
    {
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema,
            string mediaType, ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            throw new InvalidOperationException("No content can be written from an unverified admission.");
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference,
            CancellationToken ct = default) => Task.FromException<ReadOnlyMemory<byte>>(unavailable
                ? new ImmutableContentUnavailableException("The admission is temporarily absent.")
                : new ImmutableContentIntegrityException("The admission has a different digest."));
    }
}
''')
