from pathlib import Path
import shutil,re
p=Path('/tmp/compliance-corrective-action-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=['src/Compliance.Core/Features/Remediation/CorrectiveAction.cs','src/Compliance.Core/Features/Remediation/CompleteCorrectiveActionHandler.cs','src/Compliance.Core/Features/Remediation/AuthorizeCorrectiveActionFindingClosureUseHandler.cs','src/Compliance.Core/Features/Remediation/MaterializeCorrectiveActionHandler.cs','test/Compliance.Tests/Features/Remediation/FindingClosureTests.cs']
for rel in paths:
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,f)
f=p/'work'/paths[0];s=f.read_text().replace('    readonly List<DomainEvent> _facts = [];\n','').replace('    readonly SortedSet<long> _closedGenerations = [];','    long? _closedByGeneration;')
s=re.sub(r'^\s*_facts.Add\([^\n]+\);\n','\n',s,flags=re.M).replace('_closedGenerations.Add(settled.Generation);','_closedByGeneration ??= settled.Generation;')
s=s.replace('''    /// <summary>The finding generations whose closure fenced this action.</summary>
    public IReadOnlyCollection<long> ClosedGenerations => _closedGenerations;

    /// <summary>The fact with this event id.</summary>
    public DomainEvent? FactById(Uuid eventId) => _facts.FirstOrDefault(fact => fact.Metadata?.EventId == eventId);''','''    /// <summary>The first parent generation whose verified closed settlement permanently fenced this action.</summary>
    public long? ClosedByGeneration => _closedByGeneration;

    /// <summary>The original lifecycle content fact; technical use history is resolved by its verified selection.</summary>
    public DomainEvent? ContentFactById(Uuid eventId) => _added?.Metadata.EventId == eventId ? _added
        : _completed?.Metadata.EventId == eventId ? _completed : null;''').replace('_closedGenerations.Count > 0','_closedByGeneration is not null')
s=s.replace('SourceUsePurpose.FindingClosure, granted);\n\n','SourceUsePurpose.FindingClosure, granted);\n').replace('        _revision = 1;\n\n','        _revision = 1;\n').replace('        _revision = ev.Revision;\n\n','        _revision = ev.Revision;\n')
assert '_facts' not in s and '_closedGenerations' not in s and 'Uses.ObserveOwnerFact(ev);' in s
f.write_text(s)
f=p/'work'/paths[1];s=f.read_text();a=s.index('        var snapshot = await reader.HydrateAsync(');b=s.index('        var provenance =',a)
s=s[:a]+'''        var snapshot = new CorrectiveAction(request.TenantId, request.ProgramId,
            request.FindingId, request.ActionId, request.CommandId);
'''+s[b:]
s=s.replace('FindingCommands.Digest(request), now);','FindingCommands.Digest(request), now) with { FirstOwner = snapshot.Stream };')
a=s.index('        if (snapshot.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');start=s.index('\n        {',a)+len('\n        {');end=s.index('\n        }\n\n        var outcome =',start)
body=s[start:end].replace('snapshot.', 'owner.').replace(', ct)', ', token)').replace(', ct\n', ', token\n').replace('return current;','return Result<FirstResponseDescriptor>.Failure(current.Error!);').replace('Result<FindingView>.Failure','Result<FirstResponseDescriptor>.Failure')
s=s[:a]+'''        async ValueTask<Result<FirstResponseDescriptor>> PrepareAsync(CorrectiveAction owner, CancellationToken token)
        {'''+body+'''
            return Result<FirstResponseDescriptor>.Success(response!);
        }
'''+s[end+len('\n        }'):]
s=s.replace('''            action => FindingCommands.Prepared(action.PrepareComplete(request.ExpectedRevision), response),''','''            PrepareAsync,''').replace('\n\n\n','\n\n')
# Reader is now only used by executor dependency, not captured by owning handler itself.
s=s.replace('NativeOperationExecutor operations, IAggregateReader reader,\n    FindingReader findings','NativeOperationExecutor operations, FindingReader findings')
f.write_text(s)
f=p/'work'/paths[2];f.write_text(f.read_text().replace('action.FactById(request.SourceContentEventId)','action.ContentFactById(request.SourceContentEventId)'))
f=p/'work'/paths[3];s=f.read_text();needle='''        catch (ImmutableContentIntegrityException exception)
        {
            return SourceUseReceiverSupport.Permanent($"The frozen admission cannot be verified: {exception.Message}");
        }''';assert needle in s
s=s.replace(needle,'''        catch (ImmutableContentUnavailableException exception)
        {
            return SourceUseReceiverSupport.Transient($"The frozen admission is not available yet: {exception.Message}");
        }
'''+needle);f.write_text(s)
f=p/'work'/paths[4];s=f.read_text();s=re.sub(r'Assert.Equal\(\[1L\], (\w+)\.ClosedGenerations\);',r'Assert.Equal(1L, \1.ClosedByGeneration);',s).replace('Assert.Empty(action.ClosedGenerations);','Assert.Null(action.ClosedByGeneration);');f.write_text(s)
