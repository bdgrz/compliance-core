# Frozen identified operator retry admission/result follow-on (23 paths)

Apply after the frozen Digest35 history/claimed-attempt layer. Its manifest is e5bbfe91ab3159e75990f3e613d72f968d20f069420acba89e6b17fb727b738f. Every overlapping before hash here matches that prerequisite's exact after hash. This is the selected operator command slice; weekly identified receivers and complete ScheduleKey/source capture remain a separate, actionable internal layer. No main, .NET, Git, Jev, issues, worktrees, registry restore, or external delivery was touched by the preparing agent.

## Selected contract and behavior

remaining-command-identities.json:2442 selects required CommandId/ExpectedRevision and PUT /api/v1/platform/tenants/{tenant_id}/members/{member_id}/work-digest-dispatches/{week_of}/retry-authorizations/{command_id}. Current platform authorization remains before native acceptance/replay, and the handler still requires a personal HTTP invocation. The old unidentified POST is removed, with no alias and no new MCP mapping. Explicit route binders prevent body/query scope or command IDs from overriding the route.

The member stream's logical resource revision counts every native state transition across weeks. The existing status DTO adds Revision so callers can obtain that required owner revision. Full current reads expose the current member-stream revision; an authorization freezes its original next revision/status forever. Native preparation runs after selected acceptance, including evidence/rationale, exact Unknown state/message/attempt, original actor/intent/revision, frozen timezone/window/deadline, and configured attempt budget. The append checks the exact finalized native/physical cut again.

A fresh command ID permits a later Unknown episode to reuse the same external evidence. Exact retry returns the original attempt/status/revision, even after later progress or a later clock/configuration. Changed actor, scope, expected revision or authored text (including whitespace) conflicts before content reads. Evidence/rationale retain their original supplied text in the bounded Authored request and intent hash; existing business audit fields/results retain the existing trimming behavior.

The v2 fact carries an exact root OperationProvenance (explicit FirstOwner), bounded supplied request, original SDK actor attribution, logical revision, frozen attempt budget, immutable before/intent content, typed response content, FirstResponse descriptor and **MutationResultContent envelope** reference. Full source history reconstructs every prior authority and verifies these exact reference hashes/lengths/response envelope without requiring old business blobs on accepted replay. It binds saved actor attribution to the actual native frame and rejects unselected duplicate commands. Only the selected frozen descriptor/body need storage reads to return an accepted original response. Existing complete prefix/physical-cut protection remains installed.

## Wire and persistence changes

- AuthorizeWorkDigestUnknownRetry: occupied discriminator bdgrz.work.digest.dispatch.unknown_retry.authorize advances 1 -> 2; required CommandId and ExpectedRevision; IIdentifiedRequest uses that exact ID.
- WorkDigestUnknownRetryAuthorized: occupied bdgrz.work.digest_dispatch.unknown_retry_authorized advances 1 -> 2 for incompatible native provenance/result/proof fields.
- Other three dispatch technical facts and all four weekly facts remain at their unchanged occupied v1 payloads in this layer.
- WorkDigestDispatchStatusView adds logical Revision; new immutable status schema is work-digest-dispatch-status.v1. OperationResult always references mutation-result-content.v1, never the direct typed status body.
- Retained old v1 authorization history has no trusted command identity or original result and is not silently upgraded. No compatibility reader, discriminator alias or migration authority is shipped. Existing prerelease history qualification/disposal remains root-owned.
- Native binding remains the installed per-first-owner behavior. This change adds no realm/global uniqueness claim or bare-operation lookup (#1042 remains an existing platform qualification).

## Tests and evidence

Root genuinely qualified the standalone raw-JSON existing-API RED: old DTO ignores selected identity/revision extras and exact retry after another Unknown reauthorizes the later attempt and returns attempt2 instead of original attempt1. Exact test/source/log archived under recovery/provider-digest-duty-qualified-red. The same test is retained unchanged in the final source. behavioral-red.patch SHA8aa84fab479806842825d1f14de2c058ef87397192a6e2d39e609c953debfdaa.

Thirteen new methods / 28 rows include original replay after progress/window change, fresh-ID same evidence, changed-binding refusal before reads, actual committed unknown append recovery, actual equal winner before candidate failure, missing/corrupt original/candidate classification, current authorization before original reads, stored native root/owner/actor/revision/intent/before/result/metadata/legacy contradictions, and four actual production-host HTTP cases (frozen bytes/MutationResult envelope, canonical route, current authorization, selected OpenAPI route). No external sender is used.

All eight preexisting methods in changed test files remain; assertion counts do not decrease. The original first authorization test now expects exact replay success as selected, and retains its conflict assertions against changed intent. The original concurrent-authorizations test uses distinct command IDs (one business authorization wins); its barrier still records the two initial competing cuts while the native executor may perform later rechecks. Existing fake delivery scenarios remain and now use real native operator admissions, with actual immutable storage/actor provenance instead of opaque authorization references.

Modern parse, 267 explicit effective constructor calls, token-last/import checks, 36 tracked fixture member shapes, prerequisite hashes and three exact reconstruction routes pass. Runtime compiler/analyzers, unit/HTTP suites, direct Jev and integration remain root-owned and have not been run by this preparer.

## Patch composition

- Digest35 first, then full.patch; or tests.patch + implementation.patch.
- If the qualified original-authorization RED file remains installed, use after-red.patch after Digest35.
- shared-deltas.patch duplicates the four shared hunks for composition only; do not apply twice.
- Shared Program/Core JSON/Core DI/ProgramManagementServices are narrow deltas and must preserve current root overlays. No Persistence wrapper constructor change is needed.

## Next internal weekly work (not an external blocker)

DeliverWeeklyWorkDigest and RecordWorkDigestDelivery select required CommandId and the existing exact ScheduleEventId/DeliveryRequestEventId/attempt/key/revision/worker cause. Their current missing native admissions are internal work. ScheduleWeeklyWorkDigest explicitly retains ScheduleKey (not CommandId), the existing stable schedule tuple and **complete source cut**; technical pagination does not create another business schedule. Its current membership-page fan-out returns a mutable page aggregate and has no persisted complete schedule capture/original page result. The actual transport sender is the separate dispatch processor; no weekly delivery reactor/sender was found. These producer/source/result gaps must be implemented or precisely qualified in the next bounded layer, without fabricating an external callback, business cap, alias or global authority.
