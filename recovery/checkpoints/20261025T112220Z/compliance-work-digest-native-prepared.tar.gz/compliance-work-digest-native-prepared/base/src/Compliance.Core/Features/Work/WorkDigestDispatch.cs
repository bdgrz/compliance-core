using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>Bounded latest/explicit selected member-week authority; complete dispatch history is external.</summary>
public sealed class WorkDigestDispatch : Aggregate
{
    public const string Scheduled = "scheduled";
    public const string InFlight = "in_flight";
    public const string RetryPending = "retry_pending";
    public const string Sent = "sent";
    public const string Skipped = "skipped";
    public const string PermanentFailure = "permanent_failure";
    public const string RetryExhausted = "retry_exhausted";
    public const string Unknown = "unknown";

    public const string Area = "work-digest-dispatches";
    readonly Uuid _tenant;
    readonly DateOnly _selectedWeek;
    WorkDigestDispatchState? _latest;
    WorkDigestDispatchState? _selected;
    public WorkDigestDispatch(Uuid tenantId, Uuid memberId, DateOnly selectedWeek = default)
        : base(memberId, new EventStreamAddress(tenantId.ToString(), Area, memberId.ToString()))
    {
        (_tenant, _selectedWeek) = (tenantId, selectedWeek);
        On<WorkDigestDispatchScheduled>(ApplyFact);
        On<WorkDigestDispatchAttemptStarted>(ApplyFact);
        On<WorkDigestDispatchOutcomeRecorded>(ApplyFact);
        On<WorkDigestUnknownRetryAuthorized>(ApplyFact);
    }
    public Uuid TenantId => _tenant;
    public DateOnly SelectedWeek => _selectedWeek;
    internal WorkDigestDispatchState? LatestState => _latest;
    internal WorkDigestDispatchState? SelectedState => _selectedWeek == _latest?.WeekOf ? _latest : _selected;
    public DomainEvent? Latest { get; private set; }
    internal WorkDigestReplayCut ReplayCut { get; } = new();
    internal bool Schedule(WorkDigestScheduleWindow window, Uuid messageId, TimeSpan retryWindow, DateTimeOffset recordedAt)
    {
        if (_latest is { } latest && latest.WeekOf >= window.WeekOf || !ReplayCut.Allows(this))
            return false;
        var rules = new WorkDigestDispatchRules(_tenant, Id);
        if (!rules.Schedule(window, messageId, retryWindow, recordedAt))
            return false;
        RaiseEvent(rules.PendingEvents.Single());
        return true;
    }
    WorkDigestDispatchState? State(DateOnly week)
    {
        if (_latest?.WeekOf == week)
            return _latest;
        if (_selectedWeek == week)
            return _selected;
        if (_latest is not null && week < _latest.WeekOf)
            throw new InvalidOperationException("Historical dispatch authority requires explicit selected-week hydration.");
        return null;
    }
    public WorkDigestDispatchStatusView Read(DateOnly week) => State(week)?.View(_tenant, Id) ??
        new WorkDigestDispatchStatusView(_tenant, Id, week, "UTC", DateTimeOffset.MinValue, "not_scheduled", 0,
            null, Uuid.Empty, DateTimeOffset.MinValue, null, null, null, null, null);
    internal DateTimeOffset RetryDeadline(DateOnly week) => State(week)?.RetryDeadline ?? DateTimeOffset.MinValue;
    bool Change(DateOnly week, Func<WorkDigestDispatchRules, bool> change)
    {
        if (!ReplayCut.Allows(this) || State(week) is not { } state)
            return false;
        var rules = new WorkDigestDispatchRules(_tenant, Id);
        rules.Restore(state);
        if (!change(rules))
            return false;
        RaiseEvent(rules.PendingEvents.Single());
        return true;
    }
    public bool StartAttempt(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.StartAttempt(week, at));
    public bool RecordSent(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordSent(week, at));
    public bool RecordSkipped(DateOnly week, DateTimeOffset at, string reason) => Change(week, rules => rules.RecordSkipped(week, at, reason));
    public bool RecordPermanentRejection(DateOnly week, DateTimeOffset at, string code) => Change(week, rules => rules.RecordPermanentRejection(week, at, code));
    public bool RecordUnknown(DateOnly week, DateTimeOffset at, string code) => Change(week, rules => rules.RecordUnknown(week, at, code));
    public bool RecordInterruptedAttempt(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordInterruptedAttempt(week, at));
    public bool AuthorizeUnknownRetry(DateOnly week, Uuid by, string evidence, string rationale, DateTimeOffset at, int maximumAttempts) =>
        Change(week, rules => rules.AuthorizeUnknownRetry(week, by, evidence, rationale, at, maximumAttempts));
    public bool RecordTransientRejection(DateOnly week, DateTimeOffset at, int maximumAttempts, TimeSpan delay) =>
        Change(week, rules => rules.RecordTransientRejection(week, at, maximumAttempts, delay));
    public bool RecordRetryWindowExpired(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordRetryWindowExpired(week, at));
    public bool RecordMissedWeek(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordMissedWeek(week, at));
    void ApplyFact(DomainEvent fact)
    {
        var (tenant, member, week) = WorkDigestDispatchHistory.Scope(fact);
        if (tenant != _tenant || member != Id)
            throw new ImmutableContentIntegrityException("The dispatch fact belongs to another member or tenant.");
        if (fact is WorkDigestDispatchScheduled scheduled)
        {
            if (_latest is { } latest && week <= latest.WeekOf)
                throw new ImmutableContentIntegrityException("A dispatch schedule cannot repeat or precede its latest week.");
            var rules = new WorkDigestDispatchRules(_tenant, Id);
            rules.Replay(scheduled);
            _latest = rules.States[week];
            if (week == _selectedWeek)
                _selected = _latest;
        }
        else
        {
            if (_latest?.WeekOf == week)
                _latest = Updated(_latest, fact);
            if (_selectedWeek == week && _selected is not null && _latest?.WeekOf != week)
                _selected = Updated(_selected, fact);
            else if (_selectedWeek == week && _latest?.WeekOf == week)
                _selected = _latest;
        }
        Latest = fact;
        ReplayCut.Observe(fact);
    }
    WorkDigestDispatchState Updated(WorkDigestDispatchState state, DomainEvent fact)
    {
        var rules = new WorkDigestDispatchRules(_tenant, Id);
        rules.Restore(state);
        rules.Replay(fact);
        return rules.States[state.WeekOf];
    }
}
