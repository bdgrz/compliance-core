using System.Text.Json;
using Bdgrz.Compliance.Features.Work;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Testing;

/// <summary>Explicit committed compact technical fixture facts from complete transient rule transitions.</summary>
static class WorkDigestFacts
{
    public static async Task DispatchAsync(IServiceProvider provider, Uuid tenant, Uuid member,
        Func<WorkDigestDispatchRules, bool> arrange)
    {
        var rules = new WorkDigestDispatchRules(tenant, member);
        Assert.True(arrange(rules));
        await AppendAsync(provider, new WorkDigestDispatch(tenant, member), rules.PendingEvents);
    }
    public static async Task DispatchAsync(IServiceProvider provider, WorkDigestDispatchRules rules,
        Func<WorkDigestDispatchRules, Result> arrange)
    {
        var arranged = arrange(rules);
        Assert.True(arranged.IsSuccess, arranged.Error?.Message);
        await AppendAsync(provider, new WorkDigestDispatch(rules.TenantId, rules.Id), rules.PendingEvents);
    }
    public static Task WeeklyAsync(IServiceProvider provider, Uuid tenant, Uuid digest, WeeklyWorkDigestRules rules) =>
        AppendAsync(provider, new WeeklyWorkDigest(tenant, digest), rules.PendingEvents);
    public static async Task AppendAsync<TAggregate>(IServiceProvider provider, TAggregate owner,
        IReadOnlyList<DomainEvent> facts) where TAggregate : Aggregate
    {
        await using var scope = provider.CreateAsyncScope();
        owner = await scope.ServiceProvider.GetRequiredService<IAggregateReader>().HydrateAsync(owner);
        var appended = facts.Skip(checked((int)owner.Version)).Select((fact, index) =>
            DomainEventSeed.Attach(RoundTrip(fact), owner.Id, owner.Version + (ulong)index + 1)).ToArray();
        if (appended.Length > 0)
            await scope.ServiceProvider.GetRequiredService<IEventStore>().AppendAsync(owner.Stream,
                owner.CommittedStreamPosition, appended);
    }
    static DomainEvent RoundTrip(DomainEvent fact) => (DomainEvent)JsonSerializer.Deserialize(
        JsonSerializer.Serialize(fact, fact.GetType(), ComplianceCoreJsonContext.Default), fact.GetType(),
        ComplianceCoreJsonContext.Default)!;
}
