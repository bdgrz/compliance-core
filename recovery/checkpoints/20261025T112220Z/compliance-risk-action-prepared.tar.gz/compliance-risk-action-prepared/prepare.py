from pathlib import Path
import shutil,json,hashlib
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
out=Path('/tmp/compliance-risk-action-prepared')
base=out/'base'; work=out/'work'
overlays=[Path('/tmp/compliance-risk-native-prepared/work'),Path('/tmp/compliance-risk-method-prepared/work'),Path('/tmp/compliance-risk-governance-prepared/work')]
def own(p):
    target=work/p
    if target.exists(): return target
    src=root/p
    for layer in overlays:
        if (layer/p).exists(): src=layer/p
    if src.exists():
        (base/p).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,base/p)
        target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,target)
    else: target.parent.mkdir(parents=True,exist_ok=True)
    return target
def write(p,s): own(p).write_text(s)
paths=['src/Compliance.Core/Features/Risks/'+f for f in ['RiskTreatmentAction.cs','RiskActionReviewVerifier.cs','RiskActionCompletionReviewProcess.cs','AddRiskTreatmentActionHandler.cs','ReviseRiskTreatmentActionHandler.cs','CancelRiskTreatmentActionHandler.cs','SubmitRiskTreatmentActionCompletionHandler.cs','ReviewRiskTreatmentActionCompletionHandler.cs','CompleteRiskTreatmentActionReviewHandler.cs','AbortRiskTreatmentActionReviewHandler.cs','RiskGovernanceReader.cs']]
paths+=['src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs','test/Compliance.Tests/Testing/RiskSeeds.cs','test/Compliance.Tests/Features/Risks/RiskOwnerBoundaryTests.cs','test/Compliance.Tests/Features/Processes/SourceUseCancellationRecoveryTests.cs']
for p in paths: own(p)
p='src/Compliance.Core/Features/Risks/RiskTreatmentAction.cs'
s=(work/p).read_text()
s=s.replace('    readonly List<RiskTreatmentActionRevised> _revisions = [];\n    readonly List<RiskTreatmentActionCompletionSubmitted> _submissions = [];\n    readonly List<RiskTreatmentActionCompletionReviewed> _reviews = [];\n    readonly Dictionary<Uuid, RiskTreatmentActionCompletionReviewAccepted> _accepted = [];\n    readonly Dictionary<Uuid, DomainEvent> _terminal = [];\n    readonly List<DomainEvent> _facts = [];', '''    readonly Uuid _selectedReviewRoot;
    RiskTreatmentActionCompletionSubmitted? _submission;
    RiskTreatmentActionCompletionReviewAccepted? _selectedAccepted;
    DomainEvent? _selectedTerminal;
    DomainEvent? _latest;
    long _generation;''')
s=s.replace('Uuid actionId, Uuid selectedLogicalId = default)', 'Uuid actionId, Uuid selectedLogicalId = default,\n        Uuid selectedReviewRoot = default)')
s=s.replace('        Acceptance = new NativeAcceptance(selectedLogicalId);','        Acceptance = new NativeAcceptance(selectedLogicalId);\n        _selectedReviewRoot = selectedReviewRoot;')
a=s.index('    /// <summary>The revisions in order.</summary>'); b=s.index('    /// <summary>The cancellation fact',a)
s=s[:a]+'''    /// <summary>The tenant of this exact action owner.</summary>
    public Uuid TenantId => _tenantId;

    /// <summary>The program of this exact action owner.</summary>
    public Uuid ProgramId => _programId;

    /// <summary>The latest native fact at the captured command cut.</summary>
    public DomainEvent? Latest => _latest;

'''+s[b:]
s=s.replace('_status == RiskStates.ActionSubmitted ? _submissions[^1] : null;','_status == RiskStates.ActionSubmitted ? _submission : null;')
a=s.index('    /// <summary>Every fact in order.</summary>');b=s.index('    /// <summary>Checks that the action can be added.',a)
s=s[:a]+'''    /// <summary>The accepted review selected for recovery, or the currently pending review.</summary>
    public RiskTreatmentActionCompletionReviewAccepted? AcceptedReview(Uuid rootOperationId) =>
        _pending?.Operation.RootOperationId == rootOperationId ? _pending :
        _selectedReviewRoot == rootOperationId ? _selectedAccepted : null;

    /// <summary>The terminal fact of the selected review. Historical selections never change with current state.</summary>
    public DomainEvent? TerminalReview(Uuid rootOperationId) =>
        _selectedReviewRoot == rootOperationId ? _selectedTerminal : null;

'''+s[b:]
s=s.replace('_submissions.Count', '_generation')
s=s.replace('        _revisions.Add(ev);\n','')
s=s.replace('        _submissions.Add(ev);', '        _submission = ev;\n        _generation++;')
s=s.replace('            !_accepted.TryAdd(ev.Operation.RootOperationId, ev))', '            _selectedReviewRoot == ev.Operation.RootOperationId && _selectedAccepted is not null)')
s=s.replace('        _pending = ev;\n        Advance(ev);','        _pending = ev;\n        if (_selectedReviewRoot == ev.Operation.RootOperationId)\n            _selectedAccepted = ev;\n        Advance(ev);')
s=s.replace('        _terminal[ev.Operation.RootOperationId] = ev;\n        _reviews.Add(ev);','        if (_selectedReviewRoot == ev.Operation.RootOperationId)\n            _selectedTerminal = ev;')
s=s.replace('        _terminal[ev.Operation.RootOperationId] = ev;', '        if (_selectedReviewRoot == ev.Operation.RootOperationId)\n            _selectedTerminal = ev;')
s=s.replace('        _facts.Add(fact);', '        _latest = fact;')
# Bound root provenance at every reducer, preserving explicitly qualified null FirstOwner legacy normalization.
s=s.replace('        Acceptance.Observe(ev);','        Acceptance.Observe(ev);')
write(p,s)
# Explicitly select old review sources in every process/receiver hydration.
p='src/Compliance.Core/Features/Risks/RiskActionReviewVerifier.cs';s=(work/p).read_text().replace('intent.ActionId, commandId)', 'intent.ActionId, commandId, operationId)');write(p,s)
p='src/Compliance.Core/Features/Risks/RiskActionCompletionReviewProcess.cs';s=(work/p).read_text();s=s.replace('        var action = await reader.HydrateAsync', '        var root = record.Key.RootOperationId;\n        var action = await reader.HydrateAsync',1).replace('intent.ActionId), ct)', 'intent.ActionId, selectedReviewRoot: root), ct)').replace('        var root = record.Key.RootOperationId;\n        if (action.AcceptedReview', '        if (action.AcceptedReview');write(p,s)
for name in ['CompleteRiskTreatmentActionReviewHandler.cs','AbortRiskTreatmentActionReviewHandler.cs']:
 p='src/Compliance.Core/Features/Risks/'+name;s=(work/p).read_text().replace('intent.ActionId, command.CommandId)', 'intent.ActionId, command.CommandId, command.OperationId)').replace('proof.ActionId, command.CommandId)', 'proof.ActionId, command.CommandId, command.OperationId)');write(p,s)
# Shared Action-only consumers, based on frozen Governance prerequisite.
p='src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs';s=(work/p).read_text().replace('foreach (var fact in action.Facts)', 'foreach (var fact in await RiskTreatmentActionHistory.ReadAsync(events, action, ct).ConfigureAwait(false))');s=s.replace('public static IReadOnlyDictionary<Uuid, Uuid> SubmittersOf(RiskTreatmentAction action) =>\n        action.Submissions.ToDictionary(static submission => submission.SubmissionId,\n            static submission => submission.SubmitterMemberId);', '''public async Task<IReadOnlyDictionary<Uuid, Uuid>> SubmittersOfAsync(RiskTreatmentAction action,
        CancellationToken ct = default) =>
        (await RiskTreatmentActionHistory.ReadAsync(events, action, ct).ConfigureAwait(false))
        .OfType<RiskTreatmentActionCompletionSubmitted>().ToDictionary(static submission => submission.SubmissionId,
            static submission => submission.SubmitterMemberId);''');s=s.replace('in SubmittersOf(action))','in await SubmittersOfAsync(action, ct).ConfigureAwait(false))');write(p,s)
p='src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs';s=(work/p).read_text().replace('history.CaptureAsync(action.Stream, action.Facts,', 'history.CaptureAsync(action.Stream,\n                            await RiskTreatmentActionHistory.ReadAsync(events, action, ct).ConfigureAwait(false),');write(p,s)
p='test/Compliance.Tests/Features/Risks/RiskOwnerBoundaryTests.cs';s=(work/p).read_text().replace('action.Facts[^1]', 'action.Latest!').replace('Assert.Single(action.Facts.OfType<RiskTreatmentActionRevised>());','Assert.Single((await RiskTreatmentActionHistory.ReadAsync(\n            provider.GetRequiredService<IDomainEventReader>(), action)).OfType<RiskTreatmentActionRevised>());');write(p,s)
p='test/Compliance.Tests/Features/Processes/SourceUseCancellationRecoveryTests.cs';s=(work/p).read_text().replace('fixture.RiskId, request.ActionId));','fixture.RiskId, request.ActionId, selectedReviewRoot: request.CommandId));').replace('Assert.Empty(retained.Reviews);','Assert.Empty((await RiskTreatmentActionHistory.ReadAsync(\n            services.GetRequiredService<IDomainEventReader>(), retained)).OfType<RiskTreatmentActionCompletionReviewed>());');write(p,s)
