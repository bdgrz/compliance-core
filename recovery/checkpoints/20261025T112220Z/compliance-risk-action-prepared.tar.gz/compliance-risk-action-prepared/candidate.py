exec(open('/tmp/compliance-risk-action-prepared/prepare.py').read().split('paths=')[0])
p='src/Compliance.Core/Features/Risks/ReviewRiskTreatmentActionCompletionHandler.cs';s=(work/p).read_text();start=s.index('    async ValueTask<Result<(ImmutableContentRef Intent');head=s[:start];body=s[start:]
body=body.replace('        var tenant = request.TenantId;', '        var tenant = request.TenantId;\n        var candidate = Uuid.CreateVersion4();')
body=body.replace('Uuid.CreateVersion5(request.CommandId, id.ToString())', 'Uuid.CreateVersion5(candidate, id.ToString())').replace('content, tenant, request.CommandId,\n            RiskContent.AuthoredReviewSchema', 'content, tenant, candidate,\n            RiskContent.AuthoredReviewSchema').replace('Uuid.CreateVersion5(request.CommandId, "completion-evidence")', 'Uuid.CreateVersion5(candidate, "completion-evidence")').replace('Uuid.CreateVersion5(request.CommandId, "source-uses")', 'Uuid.CreateVersion5(candidate, "source-uses")').replace('content, tenant, request.CommandId,\n            RiskActionCompletionReviewIntent.Schema', 'content, tenant, candidate,\n            RiskActionCompletionReviewIntent.Schema')
s=head+body;write(p,s)
p='src/Compliance.Core/Features/Risks/RiskTreatmentActionHistory.cs';s=(work/p).read_text();s=s.replace('using Bdgrz.Compliance.Features.NativeOperations;', 'using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Remediation;')
idx=s.index('    static bool Child(')
s=s[:idx]+'''    /// <summary>Verifies the initial immutable body against its native action and original actor snapshot.</summary>
    public static async Task<RiskTreatmentActionView?> ReadInitialAsync(IImmutableContentStore content,
        RiskTreatmentAction owner, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(owner);
        if (owner.Added is not { } added)
            return null;
        var view = await FindingContent.ReadAsync<RiskTreatmentActionView>(content, owner.TenantId,
            added.ActionContent, ct).ConfigureAwait(false);
        if (added.ActionContent.Schema != RiskContent.ActionSchema || view.ActionId != owner.ActionId ||
            view.RiskId != owner.RiskId || view.Revision != 1 || view.Status != RiskStates.ActionOpen ||
            view.Completions.Count != 0 || view.CancelledAt is not null || view.CancelledBy is not null ||
            view.CancellationRationale is not null || view.CreatedBy != added.Operation.Actor ||
            view.CreatedAt != added.Operation.AcceptedAt || view.AccountableMemberId == Uuid.Empty ||
            RiskCommands.InvalidText(view.Title) || RiskCommands.InvalidText(view.TargetState) ||
            RiskCommands.InvalidText(view.ExpectedEvidence) || view.EvidenceRequestIds.Any(static id => id == Uuid.Empty) ||
            view.EvidenceRequestIds.Distinct().Count() != view.EvidenceRequestIds.Count)
            throw Invalid("The immutable initial action body belongs to another native identity or original attribution.");
        return view;
    }

'''+s[idx:];write(p,s)
p='src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs';s=(work/p).read_text();s=s.replace('''        if (action.Added is not { } added)
            return null;
        var view = await FindingContent.ReadAsync<RiskTreatmentActionView>(content, tenantId, added.ActionContent, ct)
            .ConfigureAwait(false);''','''        if (tenantId != action.TenantId)
            throw new ImmutableContentIntegrityException("The action composition belongs to another tenant.");
        if (await RiskTreatmentActionHistory.ReadInitialAsync(content, action, ct).ConfigureAwait(false) is not { } view)
            return null;''');write(p,s)
# Fix source indentation without invoking the runtime formatter.
for p in ['src/Compliance.Core/Features/Risks/'+name+'Handler.cs' for name in ['AddRiskTreatmentAction','ReviseRiskTreatmentAction','CancelRiskTreatmentAction','SubmitRiskTreatmentActionCompletion','ReviewRiskTreatmentActionCompletion']]:
 s=(work/p).read_text();lines=s.splitlines();start=next(i for i,l in enumerate(lines) if 'var risk = await RiskOwnerResolution.RequireRiskAsync' in l);end=next(i for i in range(start,len(lines)) if 'return Result<FirstResponseDescriptor>.Success(response!)' in lines[i]);risk_end=next(i for i in range(start,end) if 'return Result<FirstResponseDescriptor>.Failure(risk.Error!)' in lines[i]);
 for i in range(start,risk_end+1): lines[i]='        '+lines[i]
 for i in range(risk_end+1,end): lines[i]='    '+lines[i]
 s='\n'.join(lines)+'\n';s=s.replace('if (request.ActionId == Uuid.Empty', 'if (request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty || request.RiskId == Uuid.Empty ||\n            request.ActionId == Uuid.Empty',1) if 'if (request.ActionId == Uuid.Empty' in s else s.replace('if (request.CommandId == Uuid.Empty', 'if (request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty || request.RiskId == Uuid.Empty ||\n            request.CommandId == Uuid.Empty',1);write(p,s)
