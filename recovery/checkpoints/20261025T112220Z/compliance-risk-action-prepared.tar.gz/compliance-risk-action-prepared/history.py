exec(open('/tmp/compliance-risk-action-prepared/prepare.py').read().split('paths=')[0])
p='src/Compliance.Core/Features/Risks/RiskTreatmentActionHistory.cs'
write(p,'''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Verified immutable action history at one hydrated owner's exact native and physical cut.</summary>
public static class RiskTreatmentActionHistory
{
    /// <summary>Reads historical facts without retaining their collections in command authority.</summary>
    public static async Task<IReadOnlyList<DomainEvent>> ReadAsync(IDomainEventReader events,
        RiskTreatmentAction owner, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(owner);
        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, owner, ct).ConfigureAwait(false);
        if (facts.Count != owner.Revision || facts.Count > 0 && (owner.Latest is null ||
            ContentDigest.Sha256(facts[^1], facts[^1].GetType()) !=
            ContentDigest.Sha256(owner.Latest, owner.Latest.GetType())))
            throw Invalid("The action history differs from its exact hydrated cut.");
        var logicalIds = new HashSet<Uuid>();
        var status = RiskStates.ActionOpen;
        long generation = 0;
        RiskTreatmentActionCompletionReviewAccepted? pending = null;
        for (var index = 0; index < facts.Count; index++)
        {
            var fact = facts[index];
            if (fact is not INativeOperationFact native || native.Operation.LogicalId == Uuid.Empty ||
                !logicalIds.Add(native.Operation.LogicalId))
                throw Invalid("An action history repeats a logical operation or has another fact type.");
            var revision = index + 1;
            var root = native.Operation;
            bool valid;
            switch (fact)
            {
                case RiskTreatmentActionAdded added:
                    valid = index == 0 && Scope(added.TenantId, added.ProgramId, added.RiskId) &&
                        added.Revision == revision && root.LogicalId == owner.ActionId &&
                        NativeOwnerHistory.IsOwnRoot(owner, root, nameof(AddRiskTreatmentAction), 0);
                    break;
                case RiskTreatmentActionRevised revised:
                    valid = index > 0 && pending is null && status == RiskStates.ActionOpen &&
                        Scope(revised.TenantId, revised.ProgramId, revised.RiskId) &&
                        revised.ActionId == owner.ActionId && revised.Revision == revision &&
                        revised.ExpectedRevision == index && revised.RequestId == root.LogicalId &&
                        revised.RevisedBy == root.Actor && revised.RevisedAt == root.AcceptedAt &&
                        NativeOwnerHistory.IsOwnRoot(owner, root, nameof(ReviseRiskTreatmentAction), (ulong)index);
                    break;
                case RiskTreatmentActionCancelled canceled:
                    valid = index > 0 && pending is null &&
                        status is RiskStates.ActionOpen or RiskStates.ActionSubmitted &&
                        Scope(canceled.TenantId, canceled.ProgramId, canceled.RiskId) &&
                        canceled.ActionId == owner.ActionId && canceled.Revision == revision &&
                        canceled.CancellationId == root.LogicalId && canceled.CancelledBy == root.Actor &&
                        canceled.CancelledAt == root.AcceptedAt &&
                        NativeOwnerHistory.IsOwnRoot(owner, root, nameof(CancelRiskTreatmentAction), (ulong)index);
                    status = RiskStates.ActionCancelled;
                    break;
                case RiskTreatmentActionCompletionSubmitted submitted:
                    valid = index > 0 && pending is null && status == RiskStates.ActionOpen &&
                        Scope(submitted.TenantId, submitted.ProgramId, submitted.RiskId) &&
                        submitted.ActionId == owner.ActionId && submitted.Revision == revision &&
                        submitted.SubmissionId == root.LogicalId && submitted.SubmittedBy == root.Actor &&
                        submitted.SubmittedAt == root.AcceptedAt &&
                        NativeOwnerHistory.IsOwnRoot(owner, root, nameof(SubmitRiskTreatmentActionCompletion), (ulong)index);
                    generation++;
                    status = RiskStates.ActionSubmitted;
                    break;
                case RiskTreatmentActionCompletionReviewAccepted accepted:
                    valid = pending is null && status == RiskStates.ActionSubmitted &&
                        accepted.Owner == owner.Stream && accepted.Revision == revision &&
                        accepted.Generation == generation &&
                        NativeOwnerHistory.IsOwnRoot(owner, root, nameof(ReviewRiskTreatmentActionCompletion), (ulong)index);
                    pending = accepted;
                    break;
                case RiskTreatmentActionCompletionReviewed reviewed:
                    valid = pending is not null && Scope(reviewed.TenantId, reviewed.ProgramId, reviewed.RiskId) &&
                        reviewed.ActionId == owner.ActionId && reviewed.Revision == revision &&
                        reviewed.DecisionId == pending.Operation.RootOperationId &&
                        reviewed.Intent == pending.Intent && reviewed.Reviewer == pending.Operation.Actor &&
                        reviewed.ReviewedAt == pending.Operation.AcceptedAt &&
                        reviewed.Outcome is RiskStates.Accept or RiskStates.Reject &&
                        Child(owner, root, pending, nameof(CompleteRiskTreatmentActionReview));
                    status = reviewed.Outcome == RiskStates.Accept ? RiskStates.ActionCompleted : RiskStates.ActionOpen;
                    pending = null;
                    break;
                case RiskTreatmentActionCompletionReviewCanceled canceled:
                    valid = pending is not null && canceled.Owner == owner.Stream && canceled.Revision == revision &&
                        canceled.Generation == pending.Generation && canceled.Intent == pending.Intent &&
                        canceled.SourceProofs is not null &&
                        Child(owner, root, pending, nameof(AbortRiskTreatmentActionReview));
                    pending = null;
                    break;
                default:
                    valid = false;
                    break;
            }
            if (!valid)
                throw Invalid("The action history contains another owner, predecessor, attribution or review source.");
        }
        if (status != owner.Status || pending?.Metadata.EventId != owner.PendingReview?.Metadata.EventId)
            throw Invalid("The action history does not reproduce current bounded authority.");
        return facts;

        bool Scope(Uuid tenant, Uuid program, Uuid risk) =>
            tenant == owner.TenantId && program == owner.ProgramId && risk == owner.RiskId;
    }

    static bool Child(RiskTreatmentAction owner, OperationProvenance operation,
        RiskTreatmentActionCompletionReviewAccepted accepted, string kind) =>
        operation.Owner == owner.Stream && (operation.FirstOwner ?? operation.Owner) == owner.Stream &&
        operation.AffectedOwner == owner.Stream && operation.ExpectedRevisionOwner == owner.Stream &&
        operation.RootOperationId == accepted.Operation.RootOperationId && operation.CommandKind == kind &&
        operation.CausationEventId == accepted.Metadata.EventId && operation.Episode == accepted.Operation.Episode &&
        operation.Actor == accepted.Operation.Actor && operation.OriginalExpectedRevision == accepted.Operation.OriginalExpectedRevision &&
        operation.AuthoredIntentSha256 == accepted.Operation.AuthoredIntentSha256 && operation.AcceptedAt != default;

    static ImmutableContentIntegrityException Invalid(string message) => new(message);
}
''')
