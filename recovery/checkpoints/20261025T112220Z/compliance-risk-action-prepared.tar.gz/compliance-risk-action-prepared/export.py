from pathlib import Path
import json,hashlib,difflib,re,shutil,subprocess,sys,collections
r=Path('/tmp/compliance-risk-action-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
shared={'src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs','src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs','test/Compliance.Tests/Testing/RiskSeeds.cs','test/Compliance.Tests/Features/Risks/RiskOwnerBoundaryTests.cs'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def delta(a,b,path):return ''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+str(path) if a else '/dev/null',tofile='b/'+str(path)))
# Shared headers belong to the preceding reader/Assertion/Governance owners; retain exact before import layout.
for path in shared:
 p=r/'work'/path;b=r/'base'/path
 s=p.read_text();before=b.read_text();h=re.match(r'((?:using [^\n]+;\n)+)',before);a=re.match(r'((?:using [^\n]+;\n)+)',s)
 if h and a:s=h.group()+s[a.end():]
 p.write_text(s.rstrip()+'\n')
manifest=[];patches={n:[] for n in ['full.patch','implementation.patch','tests.patch','shared.patch','behavioral-red.patch','after-red.patch']}
for p in sorted((r/'work').rglob('*.cs')):
 path=p.relative_to(r/'work');b=r/'base'/path;before=b.read_text() if b.exists() else '';after=p.read_text()
 if before==after:continue
 kind='test' if path.parts[0]=='test' else 'implementation';part='shared-action-overlay' if str(path) in shared else 'http' if p.name.endswith('HttpTests.cs') else 'cancellation-proof' if 'CancellationProofTests' in p.name or p.name in ['RiskActionReviewFailureProof.cs','RiskContent.cs','AbortRiskTreatmentActionReviewHandler.cs','RiskActionReviewFences.cs'] else 'action-owner-history'
 m={'path':str(path),'kind':kind,'partition':part,'before_sha256':sha(b) if b.exists() else None,'after_sha256':sha(p),'baseline_matches_current_main':sha(b)==sha(repo/path) if b.exists() and (repo/path).exists() else not b.exists() and not (repo/path).exists()};manifest.append(m)
 patch=delta(before,after,path);patches['full.patch'].append(patch);patches['shared.patch' if str(path) in shared else 'tests.patch' if kind=='test' else 'implementation.patch'].append(patch)
 if str(path) in shared:
  f=r/'shared-overlays'/(str(path)+'.patch');f.parent.mkdir(parents=True,exist_ok=True);f.write_text(patch)
 red=r/'red'/path;redtext=red.read_text() if red.exists() else before
 if redtext!=after:patches['after-red.patch'].append(delta(redtext,after,path))
for p in sorted((r/'red').rglob('*.cs')):
 path=p.relative_to(r/'red');b=r/'base'/path;patches['behavioral-red.patch'].append(delta(b.read_text() if b.exists() else '',p.read_text(),path))
for n,parts in patches.items():(r/n).write_text(''.join(parts))
recon=[]
for name,sequence in [('full',['full.patch']),('red-green',['behavioral-red.patch','after-red.patch']),('partitioned',['implementation.patch','tests.patch','shared.patch'])]:
 d=r/'verify'/name
 if d.exists():shutil.rmtree(d)
 shutil.copytree(r/'base',d)
 for patch in sequence:
  x=subprocess.run(['patch','--batch','-p1','-d',str(d),'-i',str(r/patch)],text=True,capture_output=True)
  if x.returncode:raise RuntimeError(x.stdout+x.stderr)
 mismatches=[m['path'] for m in manifest if not (d/m['path']).exists() or sha(d/m['path'])!=m['after_sha256']]
 assert not mismatches,mismatches
 recon.append({'route':name,'patches':sequence,'mismatches':mismatches})
def names(s):return set(re.findall(r'\b(Should\w+)\s*\(',s))
old=set();new=set();removed=[];assertiondrop=[]
for m in manifest:
 if m['kind']!='test':continue
 b=r/'base'/m['path'];bs=b.read_text() if b.exists() else '';after=(r/'work'/m['path']).read_text();bn=names(bs);an=names(after);old|=bn;new|=an;removed+=sorted(bn-an)
 if bs.count('Assert.')>after.count('Assert.'):assertiondrop.append(m['path'])
sys.path.insert(0,'/tmp/compliance-csharp-syntax314');from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));syntax=[];token=[];collections_owner=[];defs={};uses=[]
watch={'RiskTreatmentAction','RiskActionReviewVerifier','RiskActionCompletionReviewReactor','RiskGovernanceReader','AddRiskTreatmentActionHandler','ReviseRiskTreatmentActionHandler','CancelRiskTreatmentActionHandler','SubmitRiskTreatmentActionCompletionHandler','ReviewRiskTreatmentActionCompletionHandler','CompleteRiskTreatmentActionReviewHandler','AbortRiskTreatmentActionReviewHandler','RiskActionReviewFailureProof'}
changed=set(m['path'] for m in manifest)
combined={str(p.relative_to(repo)):p for d in ['src','test'] for p in (repo/d).rglob('*.cs')}
for layer in ['/tmp/compliance-risk-native-prepared/work','/tmp/compliance-risk-method-prepared/work','/tmp/compliance-risk-governance-prepared/work',str(r/'work')]:
 layer=Path(layer);combined.update({str(p.relative_to(layer)):p for p in layer.rglob('*.cs')})
def walk(n):
 q=[n]
 while q:
  x=q.pop();yield x;q.extend(reversed(x.named_children))
for path,p in combined.items():
 data=p.read_bytes()
 if path not in changed and not any(x.encode() in data for x in watch):continue
 tree=parser.parse(data)
 if path in changed and tree.root_node.has_error:syntax.append(path)
 for n in walk(tree.root_node):
  if n.type in ['class_declaration','record_declaration']:
   nm=n.child_by_field_name('name');name=data[nm.start_byte:nm.end_byte].decode() if nm else '';pars=next((c for c in n.named_children if c.type=='parameter_list'),None)
   if name in watch and pars:
    args=[c for c in pars.named_children if c.type=='parameter'];defs[name]={'min':sum(c.child_by_field_name('default_value') is None and b'=' not in data[c.start_byte:c.end_byte] for c in args),'max':len(args)}
   if name=='RiskTreatmentAction' and path in changed:
    for c in n.child_by_field_name('body').named_children:
     if c.type=='constructor_declaration':
      pars=c.child_by_field_name('parameters') or next((z for z in c.named_children if z.type=='parameter_list'),None)
      if pars:
       args=[z for z in pars.named_children if z.type=='parameter'];defs[name]={'min':sum(b'=' not in data[z.start_byte:z.end_byte] for z in args),'max':len(args)}
     if c.type=='field_declaration' and re.search(rb'\b(List|Dictionary|HashSet)<',data[c.start_byte:c.end_byte]):collections_owner.append(data[c.start_byte:c.end_byte].decode())
  if path in changed and n.type=='parameter_list':
   ps=[c for c in n.named_children if c.type=='parameter']
   for i,c in enumerate(ps):
    if b'CancellationToken ' in data[c.start_byte:c.end_byte] and i!=len(ps)-1:token.append({'path':path,'line':data[:c.start_byte].count(b'\n')+1})
  if n.type=='object_creation_expression':
   typ=n.child_by_field_name('type');args=n.child_by_field_name('arguments')
   if typ and args:
    name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
    if name in watch:uses.append({'path':path,'type':name,'arity':len([c for c in args.named_children if c.type=='argument'])})
ctor=[u for u in uses if u['type'] in defs and not defs[u['type']]['min']<=u['arity']<=defs[u['type']]['max']]
serializer=(repo/'src/Compliance.Core/ComplianceCoreJsonContext.cs').read_text();serializers=[]
for name in ['RiskActionReviewFailureProof','RiskTreatmentActionAdded','RiskTreatmentActionRevised','RiskTreatmentActionCancelled','RiskTreatmentActionCompletionSubmitted','RiskTreatmentActionCompletionReviewAccepted','RiskTreatmentActionCompletionReviewed','RiskTreatmentActionCompletionReviewCanceled','RiskActionCompletionReviewIntent','RiskActionReviewDecision','RiskTreatmentActionView','RiskTreatmentActionRegistration','RiskTreatmentActionCompletionRegistration','UnitResult']:
 serializers.append({'type':name,'registered':bool(re.search(r'typeof\((?:[^)]+\.)?'+name+r'\)',serializer))})
assert not any([syntax,token,ctor,collections_owner,removed,assertiondrop]),{'syntax':syntax,'token':token,'ctor':ctor,'collections':collections_owner,'removed':removed,'assertiondrop':assertiondrop}
static={'syntax_errors':syntax,'constructor_definitions':defs,'constructor_uses':uses,'constructor_errors':ctor,'token_errors':token,'owner_collection_fields':collections_owner,'existing_acceptance_methods':len(old),'new_acceptance_methods':sorted(new-old),'removed_acceptance_methods':removed,'assertion_count_regressions':assertiondrop,'serializer_registrations':serializers,'runtime':'Not run. Root owns actual old-code RED, strict compiler/analyzers/format, focused/full/host HTTP, direct Jev and Git.'}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(r/'static-checks.json').write_text(json.dumps(static,indent=2)+'\n');(r/'reconstruction.json').write_text(json.dumps(recon,indent=2)+'\n')
prereq=[{'artifact':'/tmp/compliance-risk-native-prepared/handoff.json','scope':'Risk109 native draft/evaluation baseline'}, {'artifact':'/tmp/compliance-risk-method-prepared/handoff.json','scope':'Method36 consumer/fixture baseline'}, {'artifact':'/tmp/compliance-risk-governance-prepared/handoff.json','scope':'Gov12 shared reader/source/fixture baseline; root unchanged-tag correction remains separate'}, {'artifact':'/tmp/compliance-small-history-compactions-prepared/handoff.json','scope':'NativeOwnerHistory exact physical/native-cut helper','source':'src/Compliance.Core/Features/NativeOperations/NativeOwnerHistory.cs','sha256':sha(Path('/tmp/compliance-small-history-compactions-prepared/work/src/Compliance.Core/Features/NativeOperations/NativeOwnerHistory.cs'))}, {'artifact':'/tmp/compliance-incident-native-prepared/handoff.json','scope':'source-proof-foundation9 typed exact-source absence','source':'src/Compliance.Core/Features/SourceFacts/SourceFactUnavailableException.cs','sha256':sha(Path('/tmp/compliance-incident-native-prepared/work/src/Compliance.Core/Features/SourceFacts/SourceFactUnavailableException.cs'))}, {'scope':'Root-owned NativeOperationExecutor failure recheck changes; use actual final installed helper, no copy in this package'}, {'artifact':'/tmp/compliance-risk-source-bytes-prepared/handoff.json','scope':'Physical source bytes capture must be retained when composing shared contributor; no logical digest/preimage changes'}]
(r/'prerequisites.json').write_text(json.dumps(prereq,indent=2)+'\n')
(r/'focused-filter.txt').write_text('FullyQualifiedName~RiskTreatmentAction|FullyQualifiedName~RiskGovernance|FullyQualifiedName~RiskOwnerBoundary|FullyQualifiedName~RiskOwnerWorkSource|FullyQualifiedName~RiskTypeIBaselineSource|FullyQualifiedName~RiskGovernanceSource|FullyQualifiedName~SourceUseCancellationRecovery|FullyQualifiedName~ReviewerWorkAuthority|FullyQualifiedName~WorkQueueTests|FullyQualifiedName~PersonalRiskSignoffTransportTests\n')
(r/'web-filter.txt').write_text('FullyQualifiedName~RiskTreatmentActionHttpTests\n')
(r/'shared-deltas.json').write_text(json.dumps({'shared_action_only_paths':sorted(shared),'DI':'Static Action history helper has no registration. Abort ctor now (RiskActionReviewVerifier,IAggregateExecutor,IImmutableContentStore,TimeProvider); review reactor adds RiskActionReviewVerifier as fourth arg; verifier already registered scoped. No direct old ctor calls remain.','JSON':'Seven native fact schemas unchanged, existing fully qualified failure proof static serializer handles four new required immutable v2 fields. No new CLR serialization roots. Unit envelope remains existing UnitResult/MutationResultContent.','HTTP':'All existing public fields and scoped routes unchanged; existing OnNativeResult/WithNativeFirstResponse bridge handles actual200/202 and exact retries. New real host tests included; no new global/bare operation route.','Action_API':'ctor tenant,program,risk,action,selectedLogicalId=default,selectedReviewRoot=default; Latest and exact TenantId/ProgramId; PendingSubmission/PendingReview; bounded AcceptedReview/TerminalReview/SubmissionForReview selection. No Facts/Revisions/Submissions/Reviews compatibility collections.','history_API':'RiskTreatmentActionHistory.ReadAsync(events,owner,ct)->Task<IReadOnlyList<DomainEvent>>; ReadInitialAsync(content,owner,ct)->Task<RiskTreatmentActionView?>. Exact hydrated native/physical cut, audit-aware offsets, seven-fact history, latest full-body hash, original source scope/actor/revision and review lineage verified.','reader_hunks':'ComposeActionAsync uses ReadInitialAsync and verified historical facts; SubmittersOfAsync replaces removed owner.Submissions; contributor CaptureAsync uses verified Action history retaining receipt and exact physical source blobs. Parent composes these Action-only hunks with Assertion/Gov/source-byte overlays.','test_fixture_hunks':'RiskSeeds adds Action-only initial/FirstOwner wrapper; mixed RiskOwnerBoundary Action assertions use Latest/history; cancellation recovery uses selected historical root and bound v2 proof; WorkQueue one malformed submitter actor corrected without changing names/assertions.'},indent=2)+'\n')
(r/'LOCAL-QUALIFICATION.md').write_text('''This package is frozen offline preparation. No runtime, .NET, Git, main source, Jev, GitHub issue, worktree or deployment mutation was performed. Root owns all execution and integration.

The seven native facts already exist with externalized payloads. Original five current schemas/tags retain occupied v2; accepted/canceled retain v1. Final target-event catalog still says v1 for the original five; root explicitly selected preserving occupied unchanged schemas and will reconcile catalog metadata separately. No downgrade, legacy v1 reuse or dual reader is included.

The internal cancellation failure body is incompatible with unbound v1. Its schema advances to RiskTreatmentActionCompletionReviewCanceled.FailureProof.v2 and requires exact native Admission/OperationId/Generation/Intent. A v1 body is permanently refused; no fabricated qualification or migration authority is supplied. Other native event schemas/results remain unchanged. Persisted arbitrary seed episodes and unbound legacy histories are not silently accepted; fixture Action roots now carry initial episode and explicit FirstOwner. Nullable legacy FirstOwner normalization in NativeOwnerHistory is preserved as installed, while all new producers are explicit.

Current source authorization and personal HTTP/SoD/waiver rules remain. Evidence ActionCompletionReview uses the already-selected authoritative acquire/settle protocol, canonical acquisition, pending cancellation fence, settlement of never-acquired uses, forward recovery after irreversible review, and original selected terminal replay before held proof reads. Expected content absence stays pending; corrupt content is permanent. Unknown append transport outcomes propagate for process/driver retry; retry resolves selected native acceptance/terminal before acquiring or completing again. This is not a new global operation index or a claim of realm-wide UUID uniqueness.

Current WorkSource review work identity and combined RiskGovernanceSnapshot submitter lookup still omit ActionId when keying program+risk+SubmissionId. The same caller submission UUID is legal on two native action owners. This pre-existing scoped identity/assignment qualification is routed to parent/root separately; this snapshot does not fabricate old assignment/URL aliases or migration authority. Exact current public action routes and existing work identity behavior are retained pending that bounded coordinated correction. Do not call the whole risk work identity surface qualified from these tests.

NativeOwnerHistory small3 and typed SourceFactUnavailableException from Incident source-proof-foundation9 are explicit prerequisites, not copied/reimplemented. Root's NativeOperationExecutor expected preparation/descriptor failure recheck fix is an explicit prerequisite. Shared Action reader/contributor/test hunks require composition with parent Assertion/Gov/source-byte overlays. Physical source publication and authenticated recorded-through receipt semantics remain unchanged; no logical source digest preimages change.

Static syntax/constructor/token/collection/acceptance/serializer and exact reconstruction checks do not establish compiler, analyzer, test, broker or deployment success.
''')
(r/'README.md').write_text('''# RiskTreatmentAction bounded native authority

Frozen offline slice, 25 source/test paths; runtime and integration pending with root. Base snapshots layer current main plus relevant Risk109/Method36/Gov12 artifacts. Four parent-owned mixed files have separate Action-only patches under shared-overlays/. Do not overwrite newer Assertion/Gov/source-byte content with complete older snapshots.

Run behavioral-red.patch and behavioral-red-filter.txt against the old source first. Four old-API regressions prove actual32-revision retained command history, creation replay blocked by a now-unavailable fresh risk source, timed-content candidate collision after a failed acknowledgment write, and a forged native submitter changing original attribution. Then apply after-red.patch. full.patch is the exact alternative; implementation.patch + tests.patch + shared.patch are disjoint review partitions. manifest.json records every exact before/after SHA.

The action owner retains scalar revision/generation/status, current submission/pending review, fixed initial/cancellation refs, latest fact and only the selected review's accepted/submission/terminal facts. Complete history lives in verified read composition, never Aggregate lists/dictionaries. An independent review-root selector lets delayed receiver/evidence settlement recover the original terminal across later submissions without replaying current policy or leaked holds. Initial immutable view and seven native fact histories bind exact owner, original actor/revision, native/physical cut, root lineage and body hash. Audits consume physical positions without advancing native revision.

Five public handlers resolve native acceptance before all fresh scope/source/waiver/assignment/immutable work, using async Prepare so equal winning admissions recover after preparation failure. New root provenance explicitly names FirstOwner. Each unaccepted review candidate gets fresh physical content identity, preventing timed content from poisoning retries; accepted replies remain original200/202 bytes. The review process/receiver selectors and cancellation fixture migrate completely, no Current/Facts/history shim remains on the owner.

Cancellation proof v2 requires exact admitted native review, root, generation and frozen intent, with optional evidence constrained to the frozen citation set. Wrong proof cannot fence another review or release held evidence. Irreversible review still recovers forward. Existing ordered evidence held-use/cancellation/settlement semantics remain. The new real host tests verify actual native200/202, frozen body/status replay, changed intent and current/anonymous authorization.

No event discriminator is downgraded. No new public DTO/path, trusted callback, permit, global lookup or migration authority is introduced. See LOCAL-QUALIFICATION.md for persisted-history/tag metadata and pre-existing review work identity qualifications. Root must run old-code RED/GREEN, strict format/compiler/analyzers, focused/full/HTTP and direct per-file Jev before integration.
''')
art={n:{'sha256':sha(r/n),'bytes':(r/n).stat().st_size} for n in patches}
hand={'root':str(r),'status':'frozen offline; root runtime/review/integration pending','paths':len(manifest),'implementation_paths':sum(m['kind']=='implementation' for m in manifest),'test_paths':sum(m['kind']=='test' for m in manifest),'partitions':dict(collections.Counter(m['partition'] for m in manifest)),'manifest':'manifest.json','manifest_sha256':sha(r/'manifest.json'),'patches':art,'red_first':['behavioral-red.patch','run behavioral-red-filter.txt on old code','after-red.patch'],'prerequisites':'prerequisites.json','old_api_red_methods':len(names((r/'red/test/Compliance.Tests/Features/Risks/RiskTreatmentActionCompactionTests.cs').read_text())),'existing_acceptance_methods':len(old),'new_acceptance_methods':len(new-old),'removed_acceptance_methods':removed,'static_issues':{'syntax':syntax,'constructors':ctor,'tokens':token,'owner_collections':collections_owner,'assertions':assertiondrop},'reconstruction':recon,'shared_deltas':'shared-deltas.json','qualification':'LOCAL-QUALIFICATION.md'}
(r/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(hand,indent=2))
