exec(open('/tmp/compliance-risk-action-prepared/prepare.py').read().split('paths=')[0])
p='src/Compliance.Core/Features/Risks/RiskTreatmentAction.cs';s=(work/p).read_text()
s=s.replace('    RiskTreatmentActionCompletionSubmitted? _submission;','    RiskTreatmentActionCompletionSubmitted? _submission;\n    RiskTreatmentActionCompletionSubmitted? _selectedSubmission;')
s=s.replace('    /// <summary>The terminal fact of the selected review.', '''    /// <summary>The exact submitted completion sealed by a selected or currently pending review.</summary>
    public RiskTreatmentActionCompletionSubmitted? SubmissionForReview(Uuid rootOperationId) =>
        _pending?.Operation.RootOperationId == rootOperationId ? _submission :
        _selectedReviewRoot == rootOperationId ? _selectedSubmission : null;

    /// <summary>The terminal fact of the selected review.''')
s=s.replace('        if (_selectedReviewRoot == ev.Operation.RootOperationId)\n            _selectedAccepted = ev;','        if (_selectedReviewRoot == ev.Operation.RootOperationId)\n        {\n            _selectedAccepted = ev;\n            _selectedSubmission = _submission;\n        }')
s=s.replace('        if (operation.Owner != Stream || operation.LogicalId != _actionId || operation.OriginalExpectedRevision != 0)', '        if (!NativeOwnerHistory.IsOwnRoot(this, operation, nameof(AddRiskTreatmentAction), 0) ||\n            operation.LogicalId != _actionId)')
s=s.replace('            ev.Revision != 1 || ev.Operation.Owner != Stream || ev.Operation.LogicalId != _actionId)', '            ev.Revision != 1 || !NativeOwnerHistory.IsOwnRoot(this, ev.Operation, nameof(AddRiskTreatmentAction), 0) ||\n            ev.Operation.LogicalId != _actionId)')
s=s.replace('        if (_status != RiskStates.ActionOpen)\n            throw new InvalidOperationException("Only open work is revised.");', '        if (_status != RiskStates.ActionOpen || !NativeOwnerHistory.IsOwnRoot(this, ev.Operation,\n                nameof(ReviseRiskTreatmentAction), (ulong)_revision) || ev.RequestId != ev.Operation.LogicalId ||\n            ev.ExpectedRevision != _revision || ev.RevisedBy != ev.Operation.Actor || ev.RevisedAt != ev.Operation.AcceptedAt)\n            throw new InvalidOperationException("Only the exact attributed open work is revised.");')
s=s.replace('if (_status is not (RiskStates.ActionOpen or RiskStates.ActionSubmitted) || _pending is not null)', 'if (_status is not (RiskStates.ActionOpen or RiskStates.ActionSubmitted) || _pending is not null ||\n            !NativeOwnerHistory.IsOwnRoot(this, ev.Operation, nameof(CancelRiskTreatmentAction), (ulong)_revision) ||\n            ev.CancellationId != ev.Operation.LogicalId || ev.CancelledBy != ev.Operation.Actor ||\n            ev.CancelledAt != ev.Operation.AcceptedAt)')
s=s.replace('        if (_status != RiskStates.ActionOpen)\n            throw new InvalidOperationException("A completion is submitted for open work only.");', '        if (_status != RiskStates.ActionOpen || !NativeOwnerHistory.IsOwnRoot(this, ev.Operation,\n                nameof(SubmitRiskTreatmentActionCompletion), (ulong)_revision) || ev.SubmissionId != ev.Operation.LogicalId ||\n            ev.SubmittedBy != ev.Operation.Actor || ev.SubmittedAt != ev.Operation.AcceptedAt)\n            throw new InvalidOperationException("An exact attributed completion is submitted for open work only.");')
s=s.replace('            ev.Operation.RootOperationId != ev.Operation.LogicalId ||','            !NativeOwnerHistory.IsOwnRoot(this, ev.Operation, nameof(ReviewRiskTreatmentActionCompletion), (ulong)_revision) ||')
s=s.replace('            ev.Operation.RootOperationId != _pending.Operation.RootOperationId || ev.Operation.Owner != Stream)', '            !IsReviewChild(ev.Operation, nameof(CompleteRiskTreatmentActionReview)) ||\n            ev.DecisionId != _pending.Operation.RootOperationId || ev.Reviewer != _pending.Operation.Actor ||\n            ev.ReviewedAt != _pending.Operation.AcceptedAt || ev.Outcome is not (RiskStates.Accept or RiskStates.Reject))',1)
s=s.replace('            ev.Operation.RootOperationId != _pending.Operation.RootOperationId || ev.Operation.Owner != Stream)', '            !IsReviewChild(ev.Operation, nameof(AbortRiskTreatmentActionReview)) || ev.SourceProofs is null)',1)
a=s.index('    Result PrepareOwn(')
s=s[:a]+'''    bool IsReviewChild(OperationProvenance operation, string kind) => _pending is { } accepted &&
        operation.LogicalId != Uuid.Empty && operation.Owner == Stream &&
        (operation.FirstOwner ?? operation.Owner) == Stream && operation.AffectedOwner == Stream &&
        operation.ExpectedRevisionOwner == Stream && operation.RootOperationId == accepted.Operation.RootOperationId &&
        operation.CausationEventId == accepted.Metadata.EventId && operation.CommandKind == kind &&
        operation.Actor == accepted.Operation.Actor && operation.Episode == accepted.Operation.Episode &&
        operation.OriginalExpectedRevision == accepted.Operation.OriginalExpectedRevision &&
        operation.AuthoredIntentSha256 == accepted.Operation.AuthoredIntentSha256 && operation.AcceptedAt != default;

'''+s[a:]
# Before emitting a child, return typed invalid-proof result instead of relying on reducer exceptions.
s=s.replace('            _pending.Intent != intent || operation.Owner != Stream)', '            _pending.Intent != intent || !IsReviewChild(operation, nameof(CompleteRiskTreatmentActionReview)))')
s=s.replace('            operation.Owner != Stream)\n            return Result.Failure(new RequestError(RequestErrorKind.Conflict,\n                "Only the exact pending review can be canceled.', '            !IsReviewChild(operation, nameof(AbortRiskTreatmentActionReview)))\n            return Result.Failure(new RequestError(RequestErrorKind.Conflict,\n                "Only the exact pending review can be canceled.')
# Check the declared kind when preparing roots; reducer performs full exact root binding at append.
s=s.replace('        if (operation.Owner != Stream || operation.OriginalExpectedRevision is not { } expected)', '        if (operation.Owner != Stream || operation.OriginalExpectedRevision is not { } expected ||\n            operation.RootOperationId != operation.LogicalId || operation.LogicalId == Uuid.Empty ||\n            operation.CausationEventId is not null || (operation.FirstOwner ?? operation.Owner) != Stream ||\n            operation.AffectedOwner != Stream || operation.ExpectedRevisionOwner != Stream)')
write(p,s)
# All real Action seed facts use current root attribution. Other seeds remain parent-owned and unchanged.
p='test/Compliance.Tests/Testing/RiskSeeds.cs';s=(work/p).read_text();a=s.index('    public static async Task AddActionAsync');before=s[:a];tail=s[a:];tail=tail.replace('var operation = Operation(', 'var operation = ActionOperation(')
s=before+tail
idx=s.index('    static async Task<(ImmutableContentRef First,')
s=s[:idx]+'''    static OperationProvenance ActionOperation<T>(Aggregate owner, Uuid id, ulong? expected,
        ActorReference actor, DateTimeOffset at, string kind, T authored) where T : notnull =>
        Operation(owner, id, expected, actor, at, kind, authored) with
        { Episode = RootOperation.InitialEpisode, FirstOwner = owner.Stream };

'''+s[idx:]
write(p,s)
# Verify sealed header and exact original submission using selected historical authority, before foreign source use.
p='src/Compliance.Core/Features/Risks/RiskActionReviewVerifier.cs';s=(work/p).read_text()
old='''        return new RiskActionReview(null, action, intent, decision, tenant);'''
new='''        if (action.Stream != source.Stream)
            return RiskActionReview.Failed(Permanent("The frozen review belongs to another exact action stream."));
        if (action.AcceptedReview(operationId) is { } accepted)
        {
            var operation = accepted.Operation;
            var header = intent.Header;
            var submission = action.SubmissionForReview(operationId);
            if (header.FirstOwner != action.Stream || header.AffectedOwner != action.Stream ||
                header.ExpectedRevisionOwner != action.Stream || header.OriginalActor != operation.Actor ||
                header.Episode != operation.Episode || header.OriginalExpectedRevision != operation.OriginalExpectedRevision ||
                header.AuthoredIntentSha256 != operation.AuthoredIntentSha256 || header.AcceptedAt != operation.AcceptedAt ||
                submission is null || submission.SubmissionId != intent.SubmissionId ||
                decision.Reviewer != operation.Actor || decision.DecidedAt != operation.AcceptedAt ||
                decision.ReviewerMemberId.ToString() != operation.Actor.Id)
                return RiskActionReview.Failed(Permanent("The sealed review differs from its exact admitted submission or original authority."));
        }
        return new RiskActionReview(null, action, intent, decision, tenant);'''
assert old in s;s=s.replace(old,new);write(p,s)
