exec(open('/tmp/compliance-risk-action-prepared/prepare.py').read().split('paths=')[0])
names=['AddRiskTreatmentAction','ReviseRiskTreatmentAction','CancelRiskTreatmentAction','SubmitRiskTreatmentActionCompletion','ReviewRiskTreatmentActionCompletion']
for name in names:
 p='src/Compliance.Core/Features/Risks/'+name+'Handler.cs';s=(work/p).read_text()
 # Read scope only when the native first-owner has no accepted binding.
 a=s.index('        var risk = await RiskOwnerResolution.RequireRiskAsync');b=s.index('        var actor = RiskActor.From',a)
 risk=s[a:b]
 s=s[:a]+s[b:]
 a=s.index('        var snapshot = await reader.HydrateAsync(');b=s.index('        var provenance = ',a)
 snapshot=s[a:b]
 snapshot=snapshot.replace('var snapshot = await reader.HydrateAsync(', 'var snapshot = ').replace('), ct).ConfigureAwait(false);', ');')
 s=s[:a]+snapshot+s[b:]
 start=s.index('        var provenance = ');end=s.index('        var binding = ',start)
 s=s[:start]+s[start:end].replace('now);', 'now) with { FirstOwner = snapshot.Stream };')+s[end:]
 a=s.index('        if (snapshot.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');bs=s.index('        {',a)+len('        {\n');b=s.index('\n        }\n\n        var outcome',bs)
 body=s[bs:b]
 # Move all current snapshot/body/source/response work into async preparation.
 body=body.replace('snapshot.', 'action.')
 body=body.replace('ct)', 'token)').replace(', ct)', ', token)')
 risk=risk.replace('ct)', 'token)')
 if name in ['ReviseRiskTreatmentAction','CancelRiskTreatmentAction']:
  risk=risk.replace('return risk;', 'return Result<FirstResponseDescriptor>.Failure(risk.Error!);')
 else: risk=risk.replace('return Fail(risk.Error!);','return Result<FirstResponseDescriptor>.Failure(risk.Error!);').replace('return Result<OperationAcceptedResponse>.Failure(risk.Error!);','return Result<FirstResponseDescriptor>.Failure(risk.Error!);')
 if name=='ReviewRiskTreatmentActionCompletion':
  body=body.replace('FreezeAsync(request, snapshot,','FreezeAsync(request, action,')
  body=body.replace('return Result<OperationAcceptedResponse>.Failure(frozen.Error!);','return Result<FirstResponseDescriptor>.Failure(frozen.Error!);')
 else:
  body=body.replace('return Fail(prepared.Error!);','return Result<FirstResponseDescriptor>.Failure(prepared.Error!);').replace('return prepared;','return Result<FirstResponseDescriptor>.Failure(prepared.Error!);')
  body=body.replace('return Fail(', 'return Result<FirstResponseDescriptor>.Failure(').replace('return Result.Failure(', 'return Result<FirstResponseDescriptor>.Failure(')
 body='\n'.join('    '+ln for ln in (risk.rstrip()+'\n'+body.rstrip()).split('\n'))
 prep='''async (action, token) =>
            {
                try
                {
BODY
                    return Result<FirstResponseDescriptor>.Success(response!);
                }
                catch (ImmutableContentIntegrityException failure)
                {
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The exact treatment action source content cannot be verified.",
                        failure is ImmutableContentUnavailableException));
                }
            }'''.replace('BODY',body)
 s=s[:a]+s[b+len('\n        }\n'):]
 import re
 s=re.sub(r'action => FindingCommands.Prepared\(action\.Prepare\w+\([^\n]*\), response\)',lambda m:prep,s,count=1)
 # Guard preparation now references action rather than snapshot and no frozen bytes are needed before acceptance.
 # Classify failed response/descriptor reads as well, after the executor has rechecked equal winners.
 a=s.index('        var outcome = await operations.ExecuteAsync');b=s.index('\n    }',a)
 resulttype='Result<RiskTreatmentActionRegistration>' if name=='AddRiskTreatmentAction' else 'Result<RiskTreatmentActionCompletionRegistration>' if name=='SubmitRiskTreatmentActionCompletion' else 'Result<OperationAcceptedResponse>' if name=='ReviewRiskTreatmentActionCompletion' else 'Result'
 block=s[a:b]
 s=s[:a]+'''        try
        {
'''+ '\n'.join('    '+ln for ln in block.split('\n'))+'''
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return RESULT.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact treatment action content cannot be verified.", failure is ImmutableContentUnavailableException));
        }'''.replace('RESULT',resulttype)+s[b:]
 write(p,s)
