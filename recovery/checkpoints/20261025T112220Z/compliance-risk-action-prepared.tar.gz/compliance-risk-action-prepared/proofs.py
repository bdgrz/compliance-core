exec(open('/tmp/compliance-risk-action-prepared/prepare.py').read().split('paths=')[0])
p='src/Compliance.Core/Features/Risks/RiskActionReviewFailureProof.cs'
write(p,'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>An exact admitted review that cannot decide, with its authoritative reason and affected frozen evidence.</summary>
public sealed record RiskActionReviewFailureProof(Uuid ProgramId, Uuid RiskId, Uuid ActionId, string Reason,
    Uuid? EvidenceRequestId, NativeFactReference Admission, Uuid OperationId, long Generation, ImmutableContentRef Intent);
''')
p='src/Compliance.Core/Features/Risks/RiskContent.cs';s=own(p).read_text().replace('RiskTreatmentActionCompletionReviewCanceled.FailureProof.v1','RiskTreatmentActionCompletionReviewCanceled.FailureProof.v2');write(p,s)
p='src/Compliance.Core/Features/Risks/RiskActionReviewFences.cs';s=own(p).read_text();s=s.replace('''        var proof = await FindingContent.WriteDeterministicAsync(content, review.TenantId, intent.Header.RootOperationId,
            RiskContent.FailureSchema, new RiskActionReviewFailureProof(decision.ProgramId, decision.RiskId,
                intent.ActionId, reason, evidenceRequestId), ct).ConfigureAwait(false);''','''        var proof = action.TerminalReview(intent.Header.RootOperationId) is RiskTreatmentActionCompletionReviewCanceled canceledReview
            ? canceledReview.SourceProofs ?? throw new ImmutableContentIntegrityException("The cancellation has no exact failure proof.")
            : await FindingContent.WriteAsync(content, review.TenantId, RiskContent.FailureSchema,
                new RiskActionReviewFailureProof(decision.ProgramId, decision.RiskId, intent.ActionId, reason,
                    evidenceRequestId, source, intent.Header.RootOperationId, accepted.Generation, intentReference), ct)
                .ConfigureAwait(false);''');write(p,s)
p='src/Compliance.Core/Features/Risks/RiskActionCompletionReviewProcess.cs';s=(work/p).read_text();s=s.replace('new RiskActionReviewFailureProof(decision.ProgramId, decision.RiskId, intent.ActionId,\n                                record.Note ?? "The review process was aborted.", null)', 'new RiskActionReviewFailureProof(decision.ProgramId, decision.RiskId, intent.ActionId,\n                                record.Note ?? "The review process was aborted.", null, record.Source, root, generation, record.Intent)')
s=s.replace('throw new SourceFactVerificationException($"The frozen review cannot be verified yet:', 'throw new SourceFactUnavailableException($"The frozen review cannot be verified yet:').replace('throw new SourceFactVerificationException("The accepted review is not visible yet.")','throw new SourceFactUnavailableException("The accepted review is not visible yet.")').replace('throw new SourceFactVerificationException(held.Error.Message)', 'throw new SourceFactUnavailableException(held.Error.Message)').replace('?? throw new SourceFactVerificationException(\n                                "The review decision is not recorded on the process yet.")','?? throw new SourceFactUnavailableException(\n                                "The review decision is not recorded on the process yet.")');write(p,s)
p='src/Compliance.Core/Features/Risks/RiskActionCompletionReviewReactor.cs';s=own(p).read_text().replace('$"The frozen review cannot be verified yet: {exception.Message}", true)', '$"The frozen review cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException)');write(p,s)
p='src/Compliance.Core/Features/Risks/AbortRiskTreatmentActionReviewHandler.cs';s=(work/p).read_text();s=s.replace('sealed class AbortRiskTreatmentActionReviewHandler(IAggregateReader reader, IAggregateExecutor executor,','sealed class AbortRiskTreatmentActionReviewHandler(RiskActionReviewVerifier verifier, IAggregateExecutor executor,')
s=s.replace('''        RiskActionReviewFailureProof proof;''','''        if (command.FailureProof.Schema != RiskContent.FailureSchema)
            return SourceUseReceiverSupport.Permanent("The cancellation requires the current exact admitted-review failure schema.");
        RiskActionReviewFailureProof proof;''')
s=s.replace('''        if (stream != command.Target)
            return SourceUseReceiverSupport.Permanent("The failure proof names another action.");''','''        if (stream != command.Target || proof.OperationId != command.OperationId || proof.Generation != command.Generation ||
            proof.Admission.Stream != stream || proof.EvidenceRequestId == Uuid.Empty ||
            string.IsNullOrWhiteSpace(proof.Reason))
            return SourceUseReceiverSupport.Permanent("The failure proof names another exact action, review or generation.");''')
a=s.index('                var action = await reader.HydrateAsync');b=s.index('                var provenance = ',a)
s=s[:a]+'''                var review = await verifier.VerifyAcceptedAsync(proof.Admission, proof.Intent, command.OperationId,
                    command.CommandId, ct).ConfigureAwait(false);
                if (review.Error is not null)
                    return Result<ReceiverOutcome>.Failure(review.Error);
                var action = review.Action!;
                var intent = review.Intent!;
                var accepted = action.AcceptedReview(command.OperationId)!;
                if (accepted.Generation != command.Generation || accepted.Intent != proof.Intent ||
                    NativeFactReference.Of(action.Stream, accepted) != proof.Admission)
                    return SourceUseReceiverSupport.Permanent("The abort differs from the exact admitted review source.");
                if (proof.EvidenceRequestId is { } evidenceRequestId)
                {
                    try
                    {
                        var cited = await ImmutableSelectionManifests.ReadAsync<ReviewedEvidenceRequest>(content,
                            tenant.ToString(), intent.CompletionEvidence, ct).ConfigureAwait(false);
                        if (cited.All(item => item.EvidenceRequestId != evidenceRequestId))
                            return SourceUseReceiverSupport.Permanent("The failure evidence is outside the frozen review selection.");
                    }
                    catch (ImmutableContentIntegrityException failure)
                    {
                        return Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The exact cancellation evidence selection cannot be verified.", failure is ImmutableContentUnavailableException));
                    }
                }
'''+s[b:]
s=s.replace('Decide(action, binding, command.OperationId)', 'Decide(action, binding, command.OperationId, command.FailureProof)').replace('Decide(fresh, binding, command.OperationId)', 'Decide(fresh, binding, command.OperationId, command.FailureProof)')
s=s.replace('AcceptedOperationBinding binding, Uuid operationId)', 'AcceptedOperationBinding binding, Uuid operationId,\n        ImmutableContentRef failureProof)')
s=s.replace('''            case NativeAcceptanceDecision.Replayed:
                return SourceUseReceiverSupport.Replayed''','''            case NativeAcceptanceDecision.Replayed:
                if (action.Acceptance.SelectedFact is not RiskTreatmentActionCompletionReviewCanceled selected ||
                    selected.SourceProofs != failureProof)
                    return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
                return SourceUseReceiverSupport.Replayed''')
write(p,s)
p='test/Compliance.Tests/Features/Processes/SourceUseCancellationRecoveryTests.cs';s=(work/p).read_text().replace('"The completion can no longer be accepted.", null)', '"The completion can no longer be accepted.", null, source, request.CommandId, accepted.Generation, accepted.Intent)');write(p,s)
# Null structured bodies are malformed content, not an unclassified null dereference.
p='src/Compliance.Core/Features/Risks/RiskTreatmentActionHistory.cs';s=(work/p).read_text().replace('view.Completions.Count != 0', 'view.Completions is null || view.Completions.Count != 0').replace('view.EvidenceRequestIds.Any', 'view.EvidenceRequestIds is null || view.EvidenceRequestIds.Any');write(p,s)
