from pathlib import Path
r=Path('/tmp/compliance-program-native-prepared'); w=r/'work'; b=r/'base'
def put(p,s):
 p=w/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
# Preserve the pure business decisions and their validation order outside persisted command authority.
s=(b/'src/Compliance.Core/Features/Programs/ComplianceProgram.cs').read_text()
s=s.replace('public sealed class ComplianceProgram : Aggregate','public sealed class ProgramRules').replace('public ComplianceProgram(Uuid tenantId, Uuid programId)\n        : base(programId, new EventStreamAddress(tenantId.ToString(), "programs", programId.ToString()))','public ProgramRules(Uuid tenantId, Uuid programId)')
start=s.index('        On<ProgramCreated>'); end=s.index('\n    public CommandFailure? Create',start)
s=s[:start]+'''        Id = programId;
    }

    public Uuid TenantId => _tenantId;
    public Uuid Id { get; }
    public IReadOnlyList<ProgramRuleChange> AppliedChanges => _applied;
    public IReadOnlyList<ProgramRuleChange> PendingChanges => _pending;
    readonly List<ProgramRuleChange> _applied = [];
    readonly List<ProgramRuleChange> _pending = [];
    public void ClearPendingChanges() => _pending.Clear();
    void Add(ProgramRuleChange change)
    {
        _applied.Add(change);
        _pending.Add(change);
        _revision = change.Revision;
        if (change.Kind == nameof(CreateProgram))
        {
            _created = true;
            _initialName = change.Content!.Name;
            _initialPlan = change.Content.Plan;
        }
        else if (change.Kind == nameof(SelectProgramCriteriaEdition))
        {
            _criteriaEditionId = change.EditionId;
            _criteriaEditionHistory.Add((change.Revision, change.EditionId!.Value, change.ChangedAt));
            _lastChangeWasSelection = true;
        }
        else _lastChangeWasSelection = false;
    }
''' + s[end:]
start=s.index('        RaiseEvent(new ProgramCreated');end=s.index('        return null;',start)
s=s[:start]+'''        Add(new ProgramRuleChange(nameof(CreateProgram), 1, new ProgramContent(name.Trim(), plan), null,
            ActorReference.ForMember(actorMemberId, actorDisplay), changedAt));
'''+s[end:]
start=s.index('        RaiseEvent(new ProgramRevised');end=s.index('        return null;',start)
s=s[:start]+'''        Add(new ProgramRuleChange(nameof(ReviseProgram), _revision + 1, new ProgramContent(name.Trim(), plan), null,
            ActorReference.ForMember(actorMemberId, actorDisplay), changedAt));
'''+s[end:]
start=s.index('        RaiseEvent(new ProgramCriteriaEditionSelected');end=s.index('        return null;',start)
s=s[:start]+'''        Add(new ProgramRuleChange(nameof(SelectProgramCriteriaEdition), _revision + 1, null, editionId,
            ActorReference.ForMember(actorMemberId, actorDisplay), changedAt));
'''+s[end:]
# retain the static validation helper used by production as the exact same pure contract
s=s.replace('    static string? Validate(string name, ProgramPlan? plan)','''    public static CommandFailure? Validate(ProgramContent? content)
    {
        var error = Validate(content?.Name!, content?.Plan);
        return error is null ? null : CommandFailure.InvalidContent(error);
    }

    static string? Validate(string name, ProgramPlan? plan)''')
put(Path('src/Compliance.Core/Features/Programs/ProgramRules.cs'),s)
put(Path('src/Compliance.Core/Features/Programs/ProgramRuleChange.cs'),'''namespace Bdgrz.Compliance.Features.Programs;

public sealed record ProgramRuleChange(string Kind, long Revision, ProgramContent? Content,
    Uuid? EditionId, ActorReference Actor, DateTimeOffset ChangedAt);
''')
# transport identity mandatory, source field order stable after leading identity
for name,old,new,identity in [
 ('CreateProgram','CreateProgram(Uuid TenantId,','CreateProgram(Uuid ProgramId, Uuid TenantId,','ProgramId'),
 ('ReviseProgram','ReviseProgram(Uuid TenantId,','ReviseProgram(Uuid CommandId, Uuid TenantId,','CommandId'),
 ('SelectProgramCriteriaEdition','SelectProgramCriteriaEdition(Uuid TenantId,','SelectProgramCriteriaEdition(Uuid CommandId, Uuid TenantId,','CommandId')]:
 p=Path('src/Compliance.Common/Features/Programs')/(name+'.cs'); s=(b/p).read_text().replace(old,new)
 s=s.replace('ICallable;',f'ICallable, IIdentifiedRequest\n{{\n    public Uuid RequestId => {identity};\n}}')
 put(p,s)
# Owner exact original stale classification and null-safe/full metadata cuts
p=Path('src/Compliance.Core/Features/Programs/ComplianceProgram.cs');s=(w/p).read_text()
s=s.replace('using Bdgrz.Compliance.Features.Proofs;','using Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Features.Versioning;')
s=s.replace('var prepared = PrepareRevise((long)operation.OriginalExpectedRevision!.Value);','if (operation.OriginalExpectedRevision is not { } expected || expected > long.MaxValue)\n            return Failure("A program revision requires its original business revision.");\n        var prepared = PrepareRevise((long)expected);')
s=s.replace('var prepared = PrepareSelection((long)operation.OriginalExpectedRevision!.Value, editionId);','if (operation.OriginalExpectedRevision is not { } expected || expected > long.MaxValue)\n            return Failure("A criteria selection requires its original business revision.");\n        var prepared = PrepareSelection((long)expected, editionId);')
s=s.replace('Result Stale() => Failure($"Reload the program before revising. Current revision: {Revision}.");','Result Stale() => Result.Failure(CommandFailure.ForVersion(VersionedRecordRules.StaleRevision("program", Revision)).ToRequestError());')
s=s.replace('fact.Content is null || fact.TenantId', 'fact.Content is null || fact.Content.Schema != ProgramContent.Schema || fact.Content.MediaType != "application/json" || fact.TenantId')
put(p,s)
p=Path('src/Compliance.Core/Features/Programs/ProgramHistory.cs');s=(w/p).read_text().replace('fact is not IProgramFact native || !logical.Add(native.Operation.LogicalId)','fact is not IProgramFact native || native.Operation is null || !logical.Add(native.Operation.LogicalId)');put(p,s)
