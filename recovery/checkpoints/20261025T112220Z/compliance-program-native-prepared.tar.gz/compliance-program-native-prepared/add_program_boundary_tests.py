from pathlib import Path
import shutil
r=Path('/tmp/compliance-program-native-prepared');w=r/'work'
rel=Path('test/Compliance.Tests/Features/Programs/ProgramNativeBoundaryTests.cs')
q=Path('/Users/jrepanich/.codex/recovery/compliance-core-20261024T141258Z/client-import-program-qualified-red/tests')/rel
p=r/'qualified-red-base'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,p)
s=q.read_text().replace('public void ShouldKeepCurrentCriteriaAuthorityGivenManyEditionSelections()','public async Task ShouldKeepCurrentCriteriaAuthorityGivenManyEditionSelections()')
s=s.replace('var owner = new ComplianceProgram(Uuid.CreateVersion4(), Uuid.CreateVersion4());','await using var fixture = new ProgramNativeFixture();\n        var rules = new ProgramRules(Uuid.CreateVersion4(), Uuid.CreateVersion4());')
s=s.replace('Assert.Null(owner.Create(', 'Assert.Null(rules.Create(').replace('Assert.Null(owner.SelectCriteriaEdition(', 'Assert.Null(rules.SelectCriteriaEdition(')
s=s.replace('        // Act\n        var retained', '        await fixture.PublishAsync(rules);\n        var history = await fixture.Programs.HistoryAsync(rules.TenantId, rules.Id);\n        var owner = history.Owner;\n\n        // Act\n        var retained',1)
s=s.replace('owner.CriteriaEditionAt(at.AddMinutes(1))','history.CriteriaSelectionAt(at.AddMinutes(1))?.EditionId')
s=s.replace('// Required selected ProgramId is extra JSON so this executes against the old DTO unchanged.','// The selected creation identity is required authored input; unrelated dispatch traces do not allocate another program.')
p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
p=w/'test/Compliance.Tests/Testing/ProgramNativeFixture.cs';s=p.read_text().replace('public InMemoryEventStore Events { get; } = new();','public InMemoryEventStore Events { get; }').replace('public ProgramNativeFixture()\n    {','public ProgramNativeFixture(InMemoryEventStore? events = null)\n    {\n        Events = events ?? new InMemoryEventStore();');p.write_text(s)
