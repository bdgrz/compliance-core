from pathlib import Path
import json,hashlib,re
r=Path('/tmp/compliance-program-native-prepared');w=r/'work';b=r/'base'
owner=(w/'src/Compliance.Core/Features/Programs/ComplianceProgram.cs').read_text()
assert not any(x in owner for x in ['List<','Dictionary<','_criteriaEditionHistory','_initialName','_initialPlan','CriteriaSelectionAt(','CriteriaEditionAt('])
assert 'NativeCut.Require(this, Acceptance, operation)' in owner
assert 'Acceptance.Observe((DomainEvent)fact)' in owner
for rel in ['src/Compliance.Core/Features/Programs/ProgramOperations.cs','test/Compliance.Tests/Testing/ProgramSeeds.cs']:
 s=(w/rel).read_text();assert 'RootOperation.InitialEpisode' in s;assert 'OwnerProvenance.For' in s
for name in ['CreateProgram','ReviseProgram','SelectProgramCriteriaEdition']:
 s=(w/f'src/Compliance.Common/Features/Programs/{name}.cs').read_text();assert 'IIdentifiedRequest' in s and 'Uuid IIdentifiedRequest.RequestId' in s
for name in ['ProgramCreated','ProgramRevised','ProgramCriteriaEditionSelected']:
 s=(w/f'src/Compliance.Common/Features/Programs/{name}.cs').read_text();assert ' : DomainEvent' not in s or 'IProgramFact' in s;assert ', 2)]' in s;assert 'ProgramPlan' not in s and 'string Name' not in s
source='src/Compliance.Core/Features/Examinations/CriteriaTypeIBaselineSourceContributor.cs'
def tail(s,method):
 a=s.index('    static string '+method);z=s.index('\n    static ',a+4) if '\n    static ' in s[a+4:] else len(s);return s[a:z]
old=(b/source).read_text();new=(w/source).read_text();preserved={}
for method in ['SelectionDigest','EditionDigest']:
 assert tail(old,method)==tail(new,method),method
 preserved[method]=hashlib.sha256(tail(new,method).encode()).hexdigest()
for rel in ['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs']:
 before=(b/rel).read_text();after=(w/rel).read_text();assert 'WorkAssignment' in before and 'WorkAssignment' in after
 for text in re.findall(r'new (\w+AggregateReader)\(',before):assert text in after
 for text in re.findall(r'AddVerified\w+Reader\(\)',before):assert text in after
assert 'new object()' in (w/'test/Compliance.Tests/Testing/VerifiedProgramServices.cs').read_text()
res={'qualification':'Source invariants only, not runtime/compile/review.','boundedOwner':True,'allProducersUseActualInitialRootEpisode':True,'selectedIdentifiedDTOs':3,'nativeBusinessFactsAtOccupiedVersion2':3,'logicalDigestMethodsUnchanged':preserved,'existingReaderLayersPreserved':True,'registeredExecutorReaderEvidence':'PortiaApplicationServiceCollectionExtensions.cs lines44-47 resolve IAggregateReader lazily in the registered AggregateExecutor; ProgramNativeHistoryTests actual registered executor regression prepared.','errors':[]}
(r/'source-invariant-audit.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
