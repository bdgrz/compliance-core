from pathlib import Path
import re,json,hashlib
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-program-native-prepared');w=r/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 st=[n]
 while st:
  x=st.pop();yield x;st.extend(reversed(x.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
for p in (w/'test/Compliance.Tests/E2E').glob('*.cs'):
 t=p.read_bytes();edits=[]
 for n in walk(parser.parse(t).root_node):
  if n.type!='invocation_expression':continue
  fn=n.child_by_field_name('function');aa=n.child_by_field_name('arguments')
  if not fn or not aa or 'PostAsJsonAsync' not in tx(t,fn):continue
  args=[x for x in aa.children if x.type=='argument']
  if len(args)<2:continue
  arg=tx(t,args[0]);m=n
  while m and m.type not in ['method_declaration','local_function_statement']:m=m.parent
  if not m or not re.fullmatch(r'\w+',arg):continue
  body=tx(t,m)
  if re.search(r'var '+arg+r'\s*=\s*\$?"[^;\n]*?/programs"\s*;',body):
   edits.extend([(fn.start_byte,fn.end_byte,tx(t,fn).replace('PostAsJsonAsync','PutAsJsonAsync').encode()),
    (args[0].start_byte,args[0].end_byte,(arg+' + $"/{Uuid.CreateVersion4()}"').encode())])
 if edits:
  for a,z,v in sorted(edits,reverse=True):t=t[:a]+v+t[z:]
  p.write_bytes(t)
# Add IDs to the actual selected tool request inputs, preserving required permission probes.
for p in (w/'test/Compliance.Tests/E2E').glob('*.cs'):
 s=p.read_text()
 s=re.sub(r'(When\("bdgrz\.program\.(create|revise|criteria\.select)",\s*new Dictionary<string, object\?>\s*\{)',
   lambda m:m[1]+'\n                        ["'+('program_id' if m[2]=='create' else'command_id')+'"] = Uuid.CreateVersion4().ToString(),',s)
 if p.name=='ProgramAuthorizationMcpE2ETests.cs':
  for var,field in [('createInput','program_id'),('reviseInput','command_id'),('selectInput','command_id')]:
   s=re.sub(r'(var '+var+r' = new Dictionary<string, object\?>\s*\{)',r'\1\n                    ["'+field+r'"] = Uuid.CreateVersion4().ToString(),',s)
 if p.name=='CriteriaReadLeakMatrixE2ETests.cs':
  s=s.replace('string editionId) => new()\n        {','string editionId) => new()\n        {\n            ["command_id"] = Uuid.CreateVersion4().ToString(),')
  s=s.replace('if (record.Event is ProgramCriteriaEditionSelected)','if (record.Event is ProgramCriteriaEditionSelected { ChangeCount: 1 })')
 if p.name=='CriteriaCatalogE2ETests.cs':
  s=s.replace('if (record.Event is ProgramCriteriaEditionSelected selection)','if (record.Event is ProgramCriteriaEditionSelected { ChangeCount: 1 } selection)')
  s=s.replace('stored.StoredActor?.Kind','stored.Operation.Actor.Kind')
  # Every NoContent assertion in this file is one of the selected Program Unit commands.
  s=s.replace('HttpStatusCode.NoContent','HttpStatusCode.OK')
 # Native Program revision assertions only; leave ClientService/other families to their owner migrations.
 if p.name=='ProgramConcurrencyE2ETests.cs':s=s.replace('HttpStatusCode.NoContent','HttpStatusCode.OK')
 if p.name=='ProgramE2ETests.cs':
  for var in ['revisedResponse','reviseResponse','revisionResponse','revised','revise','updated']:
   s=s.replace('HttpStatusCode.NoContent, '+var+'.StatusCode','HttpStatusCode.OK, '+var+'.StatusCode')
 p.write_text(s)
