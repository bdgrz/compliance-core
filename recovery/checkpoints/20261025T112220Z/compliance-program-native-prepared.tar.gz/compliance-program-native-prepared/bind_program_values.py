from pathlib import Path
p=Path('work/src/Compliance.Core/Features/Programs/ProgramReader.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Kernel;\n'+s
s=s.replace('ReadContentAsync(content, tenantId, fact.Content, ct)','ReadContentAsync(content, fact, ct)')
mark='    public static async Task<ProgramContent> ReadContentAsync(IImmutableContentStore content, Uuid tenantId,'
helper='''    public static async Task<ProgramContent> ReadContentAsync(IImmutableContentStore content, IProgramFact fact,
        CancellationToken ct = default)
    {
        ProgramHistory.ValidateHeader(fact);
        var value = await ReadContentAsync(content, fact.TenantId, fact.Content, ct).ConfigureAwait(false);
        var expected = fact.Operation.OriginalExpectedRevision;
        var digest = fact switch
        {
            ProgramCreated => AuthoredIntentDigest.Compute(new CreateProgram(fact.ProgramId, fact.TenantId, value.Name, value.Plan)),
            ProgramRevised => AuthoredIntentDigest.Compute(new ReviseProgram(fact.Operation.LogicalId, fact.TenantId, fact.ProgramId,
                (long)expected!.Value, value.Name, value.Plan)),
            ProgramCriteriaEditionSelected selected => AuthoredIntentDigest.Compute(new SelectProgramCriteriaEdition(fact.Operation.LogicalId,
                fact.TenantId, fact.ProgramId, (long)expected!.Value, selected.EditionId)),
            _ => throw new ImmutableContentIntegrityException("The program has another authored value kind."),
        };
        if (digest != fact.Operation.AuthoredIntentSha256)
            throw new ImmutableContentIntegrityException("The program authored value differs from its exact native command binding.");
        return value;
    }

'''
s=s.replace(mark,helper+mark);p.write_text(s)
p=Path('work/src/Compliance.Core/Features/Programs/ProgramHistory.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Kernel;\n'+s
needle='''            throw new ImmutableContentIntegrityException("The program header differs from its exact native root, member or immutable references.");'''
s=s.replace(needle,needle+'''
        if (fact is ProgramCriteriaEditionSelected selection && operation.AuthoredIntentSha256 !=
            AuthoredIntentDigest.Compute(new SelectProgramCriteriaEdition(operation.LogicalId, fact.TenantId, fact.ProgramId,
                (long)operation.OriginalExpectedRevision!.Value, selection.EditionId)))
            throw new ImmutableContentIntegrityException("The program criteria selection differs from its exact authored command binding.");''');p.write_text(s)
p=Path('work/src/Compliance.Core/Features/Programs/FitzProgramDirectory.cs');s=p.read_text();s=s.replace('ProgramReader.ReadContentAsync(content, created.TenantId, created.Content, ct)','ProgramReader.ReadContentAsync(content, created, ct)').replace('ProgramReader.ReadContentAsync(content, revised.TenantId, revised.Content, ct)','ProgramReader.ReadContentAsync(content, revised, ct)').replace('ProgramReader.ReadContentAsync(content, selected.TenantId, selected.Content, ct)','ProgramReader.ReadContentAsync(content, selected, ct)');p.write_text(s)
