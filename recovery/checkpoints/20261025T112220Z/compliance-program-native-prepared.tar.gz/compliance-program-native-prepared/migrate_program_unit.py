from pathlib import Path
import re
r=Path('/tmp/compliance-program-native-prepared');w=r/'work';b=r/'base'
p=w/'test/Compliance.Tests/Features/Programs/ComplianceProgramTests.cs';s=p.read_text()
# pure decision tests continue to exercise original business failures, independent of persisted authority.
s=s.replace('var program = new ComplianceProgram(TenantId, ProgramId);','var program = new ProgramRules(TenantId, ProgramId);')
s=s.replace('new AggregateScenario<ComplianceProgram>(program).PendingEvents','program.AppliedChanges')
s=s.replace('new CreateProgram(TenantId, name,','new CreateProgram(requestId, TenantId, name,')
# Native fact attribution/serialization tests materialize actual immutable body references.
s=s.replace('public void ShouldPreserveEventsAndActorSnapshotGivenProgramRevision()', 'public async Task ShouldPreserveEventsAndActorSnapshotGivenProgramRevision()')
s=s.replace('public void ShouldPreserveLegacyActorGivenDifferentReviserAndReplay()', 'public async Task ShouldPreserveLegacyActorGivenDifferentReviserAndReplay()')
s=s.replace('        var events = program.AppliedChanges;', '        await using var native = new ProgramNativeFixture();\n        var events = await ProgramSeeds.FactsAsync(native.Content, program);')
a=s.index('        var legacyJson =');z=s.index('        // Act',a)
s=s[:a]+'''        var legacyJson = JsonSerializer.Serialize(original, ComplianceCoreJsonContext.Default.ProgramCreated);
        var legacyRevisionJson = $$"""
            {"program_id":"{{ProgramId}}","revision":1,"name":"SOC 2",
             "plan":{},"actor_member_id":"{{originalMemberId}}",
             "actor_display":"Original name","changed_at":"{{Now:O}}"}
            """;

'''+s[z:]
s=s.replace('original.StoredActor','original.Operation.Actor').replace('replacement.StoredActor','replacement.Operation.Actor')
s=s.replace('Assert.Null(replayed?.StoredActor);','Assert.Equal(original.Operation, replayed?.Operation);')
s=s.replace('currentDocument.RootElement.GetProperty("actor")','currentDocument.RootElement.GetProperty("operation").GetProperty("actor")')
p.write_text(s)
# Three criteria pure no-op/sequence cases retain the entire business acceptance matrix.
p=w/'test/Compliance.Tests/Features/Criteria/CriteriaCatalogTests.cs';s=p.read_text();s=s.replace('var program = new ComplianceProgram(TenantId, ProgramId);','var program = new ProgramRules(TenantId, ProgramId);').replace('new AggregateScenario<ComplianceProgram>(program).PendingEvents','program.AppliedChanges')
p.write_text(s)
