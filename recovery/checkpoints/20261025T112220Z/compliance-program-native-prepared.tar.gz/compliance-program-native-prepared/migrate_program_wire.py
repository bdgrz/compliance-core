from pathlib import Path
import json,hashlib,shutil
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-program-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()))
rows=json.loads((r/'program-wire-inventory.json').read_text());base=json.loads((r/'baselines.json').read_text());known={x['path'] for x in base}
by={}
for x in rows:by.setdefault(x['path'],[]).append(x)
def walk(n):
 st=[n]
 while st:
  x=st.pop();yield x;st.extend(reversed(x.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
changed=[]
for rel,items in by.items():
 if '/E2E/' not in rel:continue
 f=r/'work'/rel
 if not f.exists():
  original=(repo/rel).read_bytes()
  for tree in ['base','work']:
   p=r/tree/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(original)
  base.append({'path':rel,'baselineSource':str(repo/rel),'beforeSha256':hashlib.sha256(original).hexdigest(),'acceptanceNames':[]})
 t=f.read_bytes();edits=[]
 for n in walk(parser.parse(t).root_node):
  if n.type!='invocation_expression':continue
  fn=n.child_by_field_name('function');aa=n.child_by_field_name('arguments')
  if not fn or not aa:continue
  args=[x for x in aa.children if x.type=='argument']
  if len(args)<2:continue
  fun=tx(t,fn);arg=tx(t,args[0]);par=n
  while par and par.type not in ['method_declaration','local_function_statement']:par=par.parent
  meth=tx(t,par.child_by_field_name('name')) if par and par.child_by_field_name('name') else''
  create='PostAsJsonAsync' in fun and (arg in ['programsPath','programs'] or meth.startswith(('CreateProgram','CreateJourneyProgram')) and arg=='path' or arg.endswith('/programs"'))
  revise='PutAsJsonAsync' in fun and (arg=='programPath' or arg=='programsPath + "/" + firstProgram' or (rel.endswith('ProgramConcurrencyE2ETests.cs') and arg=='path'))
  select='PutAsJsonAsync' in fun and arg.endswith('/criteria-edition"')
  if create:
   edits.append((fn.start_byte,fn.end_byte,fun.replace('PostAsJsonAsync','PutAsJsonAsync').encode()))
   edits.append((args[0].start_byte,args[0].end_byte,(arg+' + $"/{Uuid.CreateVersion4()}"').encode()))
  elif revise or select:
   part='revisions' if revise else'selections'
   edits.append((args[0].start_byte,args[0].end_byte,(arg+' + $"/'+part+'/{Uuid.CreateVersion4()}"').encode()))
 if edits:
  for a,z,v in sorted(edits,reverse=True):t=t[:a]+v+t[z:]
  f.write_bytes(t);changed.append({'path':rel,'changes':len(edits)})
(r/'baselines.json').write_text(json.dumps(base,indent=2)+'\n');(r/'wire-migration.json').write_text(json.dumps(changed,indent=2)+'\n');print(json.dumps(changed))
