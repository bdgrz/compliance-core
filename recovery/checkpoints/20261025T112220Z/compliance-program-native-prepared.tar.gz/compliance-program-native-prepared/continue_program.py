from pathlib import Path
r=Path('/tmp/compliance-program-native-prepared');w=r/'work';b=r/'base'
def put(rel,s):
 p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put('src/Compliance.Core/Features/Programs/ProgramReadFailure.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public static class ProgramReadFailure
{
    public static RequestError Of(ImmutableContentIntegrityException error) => new(RequestErrorKind.Conflict,
        "The program's exact immutable source cannot be verified.", error is ImmutableContentUnavailableException);
}
''')
put('src/Compliance.Core/Features/Programs/ProgramReader.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public sealed class ProgramReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async Task<ProgramHistorySnapshot> HistoryAsync(Uuid tenantId, Uuid programId, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new ComplianceProgram(tenantId, programId), ct).ConfigureAwait(false);
        return await ProgramHistory.ReadAsync(events, owner, ct).ConfigureAwait(false);
    }

    public async Task<ProgramRules> RulesAsync(Uuid tenantId, Uuid programId, CancellationToken ct = default)
    {
        var history = await HistoryAsync(tenantId, programId, ct).ConfigureAwait(false);
        var rules = new ProgramRules(tenantId, programId);
        foreach (var fact in history.Facts.OfType<IProgramFact>())
        {
            if (fact.ChangeCount == 0)
                continue;
            var member = Uuid.Parse(fact.Operation.Actor.Id, CultureInfo.InvariantCulture);
            var display = fact.Operation.Actor.Display;
            var authored = await ReadContentAsync(content, tenantId, fact.Content, ct).ConfigureAwait(false);
            var failure = fact switch
            {
                ProgramCreated => rules.Create(authored.Name, authored.Plan, member, display, fact.Operation.AcceptedAt),
                ProgramRevised revised => rules.Revise(revised.Revision - 1, authored.Name, authored.Plan, member, display, revised.ChangedAt),
                ProgramCriteriaEditionSelected selected => rules.SelectCriteriaEdition(selected.Revision - 1, selected.EditionId,
                    member, display, selected.ChangedAt),
                _ => throw new ImmutableContentIntegrityException("The program has another history fact kind."),
            };
            if (failure is not null)
                throw new ImmutableContentIntegrityException("The program authored value violates its recorded business transition.");
        }
        rules.ClearPendingChanges();
        return rules;
    }

    public static async Task<ProgramContent> ReadContentAsync(IImmutableContentStore content, Uuid tenantId,
        Bdgrz.Compliance.Features.Proofs.ImmutableContentRef reference, CancellationToken ct = default)
    {
        if (reference.Schema != ProgramContent.Schema || reference.MediaType != ImmutableContentStoreExtensions.JsonMediaType)
            throw new ImmutableContentIntegrityException("The program authored value has another schema or media type.");
        var value = await content.ReadJsonAsync<ProgramContent>(tenantId.ToString(), reference, ct).ConfigureAwait(false);
        if (ProgramRules.Validate(value) is not null || value.Name != value.Name.Trim())
            throw new ImmutableContentIntegrityException("The program authored value is malformed or not canonical.");
        return value;
    }
}
''')
put('src/Compliance.Core/Features/Programs/ProgramOperations.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Versioning;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public sealed class ProgramOperations(NativeOperationExecutor operations, IImmutableContentStore content, TimeProvider clock)
{
    public const string RegistrationSchema = "program-registration.v1";

    public ValueTask<Result<ProgramRegistration>> CreateAsync(IRequestContext<CreateProgram> context, CancellationToken ct) =>
        ExecuteAsync<CreateProgram, ProgramRegistration>(context, context.Request.ProgramId, nameof(CreateProgram), null,
            context.Request with { Name = context.Request.Name?.Trim()! }, ct);

    public async ValueTask<Result> ReviseAsync(IRequestContext<ReviseProgram> context, CancellationToken ct)
    {
        var request = context.Request;
        var result = await ExecuteAsync<ReviseProgram, UnitResult>(context, request.CommandId, nameof(ReviseProgram), request.ExpectedRevision,
            request with { Name = request.Name?.Trim()! }, ct).ConfigureAwait(false);
        return result.IsSuccess ? Result.Success : Result.Failure(result.Error!);
    }

    public async ValueTask<Result> SelectAsync(IRequestContext<SelectProgramCriteriaEdition> context, CancellationToken ct)
    {
        var request = context.Request;
        var result = await ExecuteAsync<SelectProgramCriteriaEdition, UnitResult>(context, request.CommandId,
            nameof(SelectProgramCriteriaEdition), request.ExpectedRevision, request, ct).ConfigureAwait(false);
        return result.IsSuccess ? Result.Success : Result.Failure(result.Error!);
    }

    async ValueTask<Result<TOut>> ExecuteAsync<TRequest, TOut>(IRequestContext<TRequest> context, Uuid logicalId,
        string kind, long? expectedRevision, object intent, CancellationToken ct)
        where TRequest : IRequestBase where TOut : notnull
    {
        var tenant = intent switch { CreateProgram value => value.TenantId, ReviseProgram value => value.TenantId,
            SelectProgramCriteriaEdition value => value.TenantId, _ => throw new InvalidOperationException("Another program command.") };
        var program = intent switch { CreateProgram value => value.ProgramId, ReviseProgram value => value.ProgramId,
            SelectProgramCriteriaEdition value => value.ProgramId, _ => throw new InvalidOperationException("Another program command.") };
        if (tenant == Uuid.Empty || program == Uuid.Empty || logicalId == Uuid.Empty)
            return Result<TOut>.Failure(new RequestError(RequestErrorKind.Validation, "A program command requires its authored identities."));
        if (!UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var userId) || RequestActor.IsSystem(context.Actor))
            throw new InvalidOperationException("ProgramManagementAuthorizer must reject this actor.");
        var owner = new ComplianceProgram(tenant, program);
        var operation = OwnerProvenance.For(owner, logicalId, kind,
            ActorReference.ForMember(RbacIds.Member(tenant, userId), UserIdentityClaims.BdgrzDisplay(context.Actor, userId)),
            program.ToString(), expectedRevision is { } expected ? unchecked((ulong)expected) : null,
            AuthoredIntentDigest.Compute(intent), clock.GetUtcNow()) with { FirstOwner = owner.Stream };
        ImmutableContentRef? authored = null;
        ImmutableContentRef? result = null;
        try
        {
            var accepted = await operations.ExecuteAsync(new NativeOperation<ComplianceProgram>(AcceptedOperationBinding.Of(operation),
                () => new ComplianceProgram(tenant, program, logicalId), current => current.Acceptance,
                async (current, token) =>
                {
                    Result ready;
                    ProgramContent? value = null;
                    if (intent is CreateProgram create)
                    {
                        ready = current.PrepareCreate();
                        value = new ProgramContent(create.Name, create.Plan);
                    }
                    else if (intent is ReviseProgram revise)
                    {
                        ready = current.PrepareRevise(revise.ExpectedRevision);
                        value = new ProgramContent(revise.Name, revise.Plan);
                    }
                    else
                    {
                        var selection = (SelectProgramCriteriaEdition)intent;
                        var decision = current.PrepareSelection(selection.ExpectedRevision, selection.EditionId);
                        ready = decision.IsSuccess ? Result.Success : Result.Failure(decision.Error!);
                    }
                    if (!ready.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(ready.Error!);
                    if (value is not null)
                    {
                        var failure = ProgramRules.Validate(value);
                        if (failure is not null)
                            return Result<FirstResponseDescriptor>.Failure(failure.ToRequestError());
                        authored = await NativeContent.WriteAsync(content, tenant, ProgramContent.Schema, value, token).ConfigureAwait(false);
                    }
                    var frozen = intent is CreateProgram
                        ? await NativeContent.FreezeAsync(content, tenant, RegistrationSchema, new ProgramRegistration(program), token).ConfigureAwait(false)
                        : await NativeContent.FreezeUnitAsync(content, tenant, token).ConfigureAwait(false);
                    result = frozen.Result;
                    return Result<FirstResponseDescriptor>.Success(frozen.Response);
                }, (current, first) => intent switch
                {
                    CreateProgram => current.Create(operation, authored!, first, result!),
                    ReviseProgram => current.Revise(operation, authored!, first, result!),
                    SelectProgramCriteriaEdition selection => current.SelectCriteriaEdition(operation, selection.EditionId, first, result!),
                    _ => throw new InvalidOperationException("Another program command."),
                }), context, ct).ConfigureAwait(false);
            return await NativeContent.ResponseAsync<TOut>(content, tenant, accepted, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<TOut>.Failure(ProgramReadFailure.Of(error));
        }
    }
}
''')
for name,method,out in [('CreateProgram','CreateAsync','ProgramRegistration'),('ReviseProgram','ReviseAsync',None)]:
 p=f'src/Compliance.Core/Features/Programs/{name}Handler.cs'
 put(p,f'''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public sealed class {name}Handler(ProgramOperations operations) : IRequestHandler<{name}{', '+out if out else ''}>
{{
    public ValueTask<Result{('<'+out+'>') if out else ''}> HandleAsync(IRequestContext<{name}> context, CancellationToken ct) =>
        operations.{method}(context, ct);
}}
''')
s=(b/'src/Compliance.Core/Features/Programs/SelectProgramCriteriaEditionHandler.cs').read_text()
s=s.replace('IAggregateExecutor executor,\n    ICriteriaCatalog catalog, TimeProvider clock','ProgramOperations operations, ICriteriaCatalog catalog')
a=s.index('        var userId =');z=s.index('\n    }',a);s=s[:a]+'        return operations.SelectAsync(context, ct);'+s[z:];s=s.replace('using Bdgrz.Compliance.Features.Versioning;\n','')
put('src/Compliance.Core/Features/Programs/SelectProgramCriteriaEditionHandler.cs',s)
