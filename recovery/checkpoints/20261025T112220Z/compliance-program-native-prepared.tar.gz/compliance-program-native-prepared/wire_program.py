from pathlib import Path
r=Path('/tmp/compliance-program-native-prepared');w=r/'work';b=r/'base'
def edit(rel,f):
 p=w/rel;p.write_text(f(p.read_text()))
def put(rel,s):
 p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
edit('src/Compliance.Core/Features/Programs/ProgramRuleChange.cs',lambda s:'using Cntryl.Portia;\n\n'+s)
# Projection materializes only actual business changes, using verified immutable native values.
p='src/Compliance.Core/Features/Programs/FitzProgramDirectory.cs';s=(w/p).read_text()
s=s.replace('case ProgramCreated created:\n','case ProgramCreated created:\n                var creation = await ProgramReader.ReadContentAsync(content, created.TenantId, created.Content, ct).ConfigureAwait(false);\n')
s=s.replace('created.Name','creation.Name').replace('created.Plan','creation.Plan')
s=s.replace('case ProgramRevised revised:\n','case ProgramRevised revised:\n                var revision = await ProgramReader.ReadContentAsync(content, revised.TenantId, revised.Content, ct).ConfigureAwait(false);\n')
s=s.replace('revised.Name','revision.Name').replace('revised.Plan','revision.Plan')
s=s.replace('case ProgramCriteriaEditionSelected selected:\n','case ProgramCriteriaEditionSelected selected:\n                if (selected.ChangeCount == 0)\n                    break;\n                _ = await ProgramReader.ReadContentAsync(content, selected.TenantId, selected.Content, ct).ConfigureAwait(false);\n')
put(p,s)
# Full verified native history before choosing receipt membership; all old logical preimages preserved.
p='src/Compliance.Core/Features/Examinations/CriteriaTypeIBaselineSourceContributor.cs';s=(w/p).read_text()
s=s.replace('public sealed class CriteriaTypeIBaselineSourceContributor(IAggregateReader reader,','public sealed class CriteriaTypeIBaselineSourceContributor(IAggregateReader reader, IDomainEventReader events,')
s=s.replace('        var programReceipts =','        var history = await ProgramHistory.ReadAsync(events, program, ct).ConfigureAwait(false);\n        var programReceipts =')
s=s.replace('            .LastOrDefault();','            .LastOrDefault(static fact => fact.ChangeCount == 1);',1)
s=s.replace('program.CriteriaSelectionAt(through)','history.CriteriaSelectionAt(through)')
s=s.replace('        if (receiptCut is null && !Equals(selection, confirmed.CriteriaSelectionAt(through)))','        var confirmedHistory = await ProgramHistory.ReadAsync(events, confirmed, ct).ConfigureAwait(false);\n        if (receiptCut is null && !Equals(selection, confirmedHistory.CriteriaSelectionAt(through)))')
# Membership must be from the actual scoped, complete hydrated native prefix, with full metadata retained.
s=s.replace('        var selectedFact =', '''        if (programReceipts is not null && programReceipts.Records.Any(record =>
            !history.Facts.Any(fact => fact.GetType() == record.Event.GetType() && fact.Equals(record.Event) &&
                fact.Metadata == record.Event.Metadata)))
            throw new ImmutableContentIntegrityException("The criteria receipt cut differs from its exact verified native prefix.");
        var selectedFact =''')
put(p,s)
p='src/Compliance.Core/Features/Readiness/RunReadinessAssessmentHandler.cs';s=(w/p).read_text().replace('IAggregateReader reader, ControlReader','ProgramReader programs, ControlReader')
s=s.replace('var program = await reader.HydrateAsync(new ComplianceProgram(tenant, request.ProgramId), ct)\n            .ConfigureAwait(false);','var program = await programs.HistoryAsync(tenant, request.ProgramId, ct).ConfigureAwait(false);').replace('if (!program.IsCreated)','if (!program.Owner.IsCreated)').replace('program.CriteriaEditionAt(asOf)','program.CriteriaSelectionAt(asOf)?.EditionId');put(p,s)
# Existing keyed decoration helper assigns a distinct opaque key per layer.
p='src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=(w/p).read_text();s='using Bdgrz.Compliance.Features.Programs;\n'+s;s=s.replace('        Decorate<IRequestBus>', '        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new ProgramAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n        Decorate<IRequestBus>');put(p,s)
p='src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';s=(w/p).read_text().replace('        services.AddScoped<FitzProgramDirectory>();','        services.AddScoped<ProgramReader>();\n        services.AddScoped<ProgramOperations>();\n        services.AddScoped<FitzProgramDirectory>();');put(p,s)
p='src/Compliance.Core/ComplianceCoreJsonContext.cs';s=(w/p).read_text().replace('[JsonSerializable(typeof(CreateProgram))]','[JsonSerializable(typeof(ProgramContent))]\n[JsonSerializable(typeof(CreateProgram))]');put(p,s)
p='src/Compliance.App/Program.cs';s=(w/p).read_text();s=s.replace('MapPortiaPost<CreateProgram, ProgramRegistration>("/api/v1/tenants/{tenant_id}/programs"','MapPortiaPut<CreateProgram, ProgramRegistration>("/api/v1/tenants/{tenant_id}/programs/{program_id}"')
s=s.replace('"/api/v1/tenants/{tenant_id}/programs/{program_id}/criteria-edition", config => config.OnNativeResult()).WithNativeFirstResponse<SelectProgramCriteriaEdition>()','"/api/v1/tenants/{tenant_id}/programs/{program_id}/criteria-edition/selections/{command_id}", config => config.OnNativeResult()).WithNativeFirstResponse<SelectProgramCriteriaEdition>()')
s=s.replace('MapPortiaPut<ReviseProgram>("/api/v1/tenants/{tenant_id}/programs/{program_id}"','MapPortiaPut<ReviseProgram>("/api/v1/tenants/{tenant_id}/programs/{program_id}/revisions/{command_id}"');put(p,s)
# Test DI mirrors production with a separate opaque key, preserving prior wrappers.
p=Path('test/Compliance.Tests/Testing/VerifiedSourceUseServices.cs');original=(b/p).read_text();helper=original.replace('VerifiedSourceUseServices','VerifiedProgramServices').replace('AddVerifiedSourceUseReader','AddVerifiedProgramReader').replace('SourceUseAggregateReader','ProgramAggregateReader').replace('Features.SourceUse','Features.Programs');put('test/Compliance.Tests/Testing/VerifiedProgramServices.cs',helper)
p='test/Compliance.Tests/Testing/ProgramManagementServices.cs';s=(w/p).read_text().replace('        collection.AddScoped<NativeOperationExecutor>();','        collection.AddScoped<NativeOperationExecutor>();\n        collection.AddScoped<ProgramReader>();\n        collection.AddScoped<ProgramOperations>();').replace('        collection.AddVerifiedWorkDigestReader();','        collection.AddVerifiedWorkDigestReader();\n        collection.AddVerifiedProgramReader();')
mark='    public static async Task<RiskMethodRules> HydrateAsync'
helper='''    public static async Task SeedAsync(IServiceProvider provider, ProgramRules selected, Func<ProgramRules, Result> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var rules = await services.GetRequiredService<ProgramReader>().RulesAsync(selected.TenantId, selected.Id);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await ProgramSeeds.AppendAsync(services.GetRequiredService<IAggregateReader>(), services.GetRequiredService<IAggregateWriter>(),
            services.GetRequiredService<IDomainEventReader>(), services.GetRequiredService<IImmutableContentStore>(), rules);
    }

    public static async Task<ProgramRules> HydrateAsync(IServiceProvider provider, ProgramRules selected)
    {
        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<ProgramReader>().RulesAsync(selected.TenantId, selected.Id);
    }

'''
s=s.replace(mark,helper+mark);put(p,s)
