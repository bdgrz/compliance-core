using System.Reflection;
using System.Text.Json;
using Bdgrz.Compliance.Features.Programs;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Programs;

public sealed class ProgramNativeBoundaryTests
{
    [Fact]
    public void ShouldKeepCurrentCriteriaAuthorityGivenManyEditionSelections()
    {
        // Arrange
        var owner = new ComplianceProgram(Uuid.CreateVersion4(), Uuid.CreateVersion4());
        var member = Uuid.CreateVersion4();
        var at = new DateTimeOffset(2026, 10, 25, 12, 0, 0, TimeSpan.Zero);
        Assert.Null(owner.Create("SOC 2", new ProgramPlan(null, null, null, null, null, null), member, "Manager", at));
        var first = Uuid.CreateVersion4();
        var current = first;
        for (var index = 0; index < 32; index++)
        {
            current = index == 0 ? first : Uuid.CreateVersion4();
            Assert.Null(owner.SelectCriteriaEdition(index + 1, current, member, "Manager", at.AddMinutes(index + 1)));
        }

        // Act
        var retained = typeof(ComplianceProgram).GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
            .Where(field => field.GetValue(owner) is global::System.Collections.ICollection { Count: > 1 }).ToArray();

        // Assert
        Assert.Empty(retained);
        Assert.Equal(33, owner.Revision);
        Assert.Equal(current, owner.CriteriaEditionId);
        Assert.Equal(first, owner.CriteriaEditionAt(at.AddMinutes(1)));
    }

    [Fact]
    public async Task ShouldReturnSelectedCreationIdentityGivenSameProgramCommandDispatchedTwice()
    {
        // Arrange
        await using var provider = ProgramManagementServices.Build(new RecordingPermissionAuthorizer(allowed: true),
            portia => portia.AddRequestHandler<CreateProgramHandler>());
        await using var scope = provider.CreateAsyncScope();
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var actor = ProgramManagementServices.Actor(Uuid.CreateVersion4());
        // Required selected ProgramId is extra JSON so this executes against the old DTO unchanged.
        var json = """{"program_id":"__program__","tenant_id":"__tenant__","name":"SOC 2","plan":{"target_readiness_date":null,"target_type_i_as_of_date":null,"target_type_ii_start_date":null,"target_type_ii_end_date":null,"readiness_advisor":null,"audit_firm":null}}"""
            .Replace("__program__", program.ToString(), StringComparison.Ordinal)
            .Replace("__tenant__", tenant.ToString(), StringComparison.Ordinal);
        var request = JsonSerializer.Deserialize(json, ComplianceCoreJsonContext.Default.CreateProgram)!;
        var bus = scope.ServiceProvider.GetRequiredService<IRequestBus>();
        var first = await bus.SendAsync(request, actor);
        Assert.True(first.IsSuccess, first.Error?.Message);

        // Act
        var replay = await bus.SendAsync(request, actor);

        // Assert
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(first.Value, replay.Value);
        Assert.Equal(program, replay.Value.ProgramId);
    }
}
