from pathlib import Path
import difflib,subprocess,hashlib,json,shutil
r=Path('/tmp/compliance-program-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
shared=['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.App/Program.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs']
patch=[];rows=[]
for rel in shared:
 old=(r/'base'/rel).read_bytes();after=(r/'work'/rel).read_bytes();current=(repo/rel).read_bytes()
 for tree,data in [('pre-rebase-base',old),('pre-rebase-work',after),('shared-current',current),('shared-current-before',current)]:
  p=r/tree/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 rows.append({'path':rel,'previousBeforeSha256':hashlib.sha256(old).hexdigest(),'previousAfterSha256':hashlib.sha256(after).hexdigest(),'currentBeforeSha256':hashlib.sha256(current).hexdigest()})
p=r/'shared-own-original.patch';p.write_text(''.join(patch))
ret=subprocess.run(['patch','-p1','--batch','--fuzz=0','-i',str(p)],cwd=r/'shared-current',capture_output=True,text=True)
print(ret.stdout);print(ret.stderr);assert ret.returncode==0
base=json.loads((r/'baselines.json').read_text())
for row in rows:
 rel=row['path'];current=(r/'shared-current-before'/rel).read_bytes();after=(r/'shared-current'/rel).read_bytes();row['currentAfterSha256']=hashlib.sha256(after).hexdigest()
 (r/'base'/rel).write_bytes(current);(r/'work'/rel).write_bytes(after)
 selected=next(x for x in base if x['path']==rel);selected['previousBeforeSha256']=selected['beforeSha256'];selected['beforeSha256']=row['currentBeforeSha256'];selected['rebaseProvenance']='shared-rebase.json'
(r/'baselines.json').write_text(json.dumps(base,indent=2)+'\n');(r/'shared-rebase.json').write_text(json.dumps(rows,indent=2)+'\n')
