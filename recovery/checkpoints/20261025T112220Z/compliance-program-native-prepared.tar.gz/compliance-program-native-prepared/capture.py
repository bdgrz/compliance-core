from pathlib import Path
import json,hashlib,re
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');r=Path('/tmp/compliance-program-native-prepared');paths=set()
terms=['ComplianceProgram','ProgramCreated','ProgramRevised','ProgramCriteriaEditionSelected','CreateProgram','ReviseProgram','SelectProgramCriteriaEdition']
for folder in ['src','test']:
 for f in (repo/folder).rglob('*.cs'):
  if {'bin','obj'}.intersection(f.parts):continue
  text=f.read_text()
  if any(t in text for t in terms) or '/Features/Programs/' in str(f):paths.add(str(f.relative_to(repo)))
for p in ['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.App/Program.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs','test/Compliance.Tests/Testing/VerifiedSourceUseServices.cs']:
 if (repo/p).exists():paths.add(p)
rows=[]
for p in sorted(paths):
 data=(repo/p).read_bytes()
 for tree in ['base','work']:
  f=r/tree/p;f.parent.mkdir(parents=True,exist_ok=True);assert not f.exists(),f;f.write_bytes(data)
 rows.append({'path':p,'baselineSource':str(repo/p),'beforeSha256':hashlib.sha256(data).hexdigest(),'acceptanceNames':re.findall(r'\b(Should\w+)\s*\(',data.decode()) if p.startswith('test/') else[]})
(r/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows))
