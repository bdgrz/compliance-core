from pathlib import Path
w=Path('work')
p=w/'src/Compliance.Core/Features/Programs/ProgramHistory.cs';s=p.read_text();s='using System.Globalization;\nusing Bdgrz.Compliance.Features.Proofs;\n'+s
s=s.replace('            try\n            {\n                replay.ObserveVerified(fact);','            try\n            {\n                ValidateHeader(native);\n                replay.ObserveVerified(fact);')
mark='    static bool Same('
helper='''    public static void ValidateHeader(IProgramFact fact)
    {
        var owner = new ComplianceProgram(fact.TenantId, fact.ProgramId);
        var operation = fact.Operation;
        var kind = fact switch
        {
            ProgramCreated => nameof(CreateProgram),
            ProgramRevised => nameof(ReviseProgram),
            ProgramCriteriaEditionSelected => nameof(SelectProgramCriteriaEdition),
            _ => throw new ImmutableContentIntegrityException("The program has another native fact kind."),
        };
        if (fact.TenantId == Uuid.Empty || fact.ProgramId == Uuid.Empty || fact.Revision < 1 || fact.NativeSequence < 1 ||
            fact.ChangeCount is < 0 or > 1 || fact.ChangeCount == 0 && fact is not ProgramCriteriaEditionSelected ||
            operation is null || operation.Actor is null || operation.Actor.Kind != "member" ||
            !Uuid.TryParse(operation.Actor.Id, CultureInfo.InvariantCulture, out var member) || member == Uuid.Empty ||
            !NativeOwnerHistory.IsOwnRoot(owner, operation, kind, operation.OriginalExpectedRevision) ||
            (fact is ProgramCreated ? operation.LogicalId != owner.Id || operation.OriginalExpectedRevision is not null
                : operation.OriginalExpectedRevision is not { } expected || expected > long.MaxValue) ||
            !Reference(fact.Content, ProgramContent.Schema) || !Reference(fact.FirstResponse, FirstResponses.Schema) ||
            !Reference(fact.OperationResult, "mutation-result-content.v1"))
            throw new ImmutableContentIntegrityException("The program header differs from its exact native root, member or immutable references.");
    }

    static bool Reference(ImmutableContentRef? reference, string schema) => reference is not null &&
        reference.ContentId != Uuid.Empty && reference.Bytes > 0 && reference.Sha256 is { Length: 64 } &&
        reference.Sha256.All(Uri.IsHexDigit) && reference.Schema == schema && reference.MediaType == "application/json";

'''
s=s.replace(mark,helper+mark);p.write_text(s)
p=w/'src/Compliance.Core/Features/Programs/ComplianceProgram.cs';s=p.read_text().replace('        var kind = fact switch','        ProgramHistory.ValidateHeader(fact);\n        var kind = fact switch');p.write_text(s)
p=w/'src/Compliance.Core/Features/Programs/FitzProgramDirectory.cs';s=p.read_text().replace('        switch (domainEvent)','        if (domainEvent is IProgramFact native)\n            ProgramHistory.ValidateHeader(native);\n        switch (domainEvent)');p.write_text(s)
# Strongly typed canonical digest; object serialization is not the contract.
for rel in ['src/Compliance.Core/Features/Programs/ProgramOperations.cs','test/Compliance.Tests/Testing/ProgramSeeds.cs']:
 p=w/rel;s=p.read_text().replace('AuthoredIntentDigest.Compute(intent)','IntentDigest(intent)').replace('AuthoredIntentDigest.Compute(request)','IntentDigest(request)')
 at=s.rfind('\n}')
 s=s[:at]+'''
    static string IntentDigest(object intent) => intent switch
    {
        CreateProgram value => AuthoredIntentDigest.Compute(value),
        ReviseProgram value => AuthoredIntentDigest.Compute(value),
        SelectProgramCriteriaEdition value => AuthoredIntentDigest.Compute(value),
        _ => throw new InvalidOperationException("Another program authored intent."),
    };
'''+s[at:];p.write_text(s)
