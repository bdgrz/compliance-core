from pathlib import Path
import re
r=Path('/tmp/compliance-program-native-prepared');w=r/'work'
def edit(rel,f):
 p=w/'test/Compliance.Tests'/rel;s=f(p.read_text());
 if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
 p.write_text(s)
# Inline compact source objects: materialize the native immutable fixture, then return its actual owner.
for rel in ['Features/Programs/ProjectionFreshnessTests.cs','Features/AccessControl/AccessGrantProposalValidatorTests.cs','Features/Programs/ProgramResourceScopeResolverTests.cs','Features/Snapshots/ScopeSnapshotTests.cs']:
 def change(s):
  # Direct Create calls have one simple statement; preserve every Assert.Null and old failure variable.
  pat=r'(?P<indent>        )var (?P<var>program|source) = new ComplianceProgram\((?P<ids>[^;]+)\);(?P<create>\s+(?:Assert.Null\((?P=var)\.Create\([\s\S]*?\)\);|var failure = (?P=var)\.Create\([\s\S]*?;\s+Assert.Null\(failure\);))'
  def sub(m):
   v=m['var'];block=m[0].replace('new ComplianceProgram(', 'new ProgramRules(',1)
   block=re.sub(r'\b'+v+r'\b',v+'Rules',block)
   return block+'\n        await using var programNative = new ProgramNativeFixture();\n        var '+v+' = await ProgramSeeds.OwnerAsync(programNative.Content, '+v+'Rules);'
  s=re.sub(pat,sub,s)
  # Synchronous private helper is upgraded rather than blocking on the actual immutable writes.
  if rel.endswith('ProgramResourceScopeResolverTests.cs'):
   s=s.replace('static ComplianceProgram CreatedProgram(', 'static async Task<ComplianceProgram> CreatedProgram(')
   s=s.replace('var program = CreatedProgram(', 'var program = await CreatedProgram(').replace('var foreignProgram = CreatedProgram(', 'var foreignProgram = await CreatedProgram(')
  return s
 edit(rel,change)
# Static fixture helpers all have async callers.
for rel,name in [('Features/Snapshots/SnapshotPagedReadContractTests.cs','Program'),('Features/Programs/ProgramAndClientServicePagedReadContractTests.cs','ProgramSource')]:
 def change(s):
  s=s.replace('static ComplianceProgram '+name+'(', 'static async Task<ComplianceProgram> '+name+'(')
  s=s.replace('var program = new ComplianceProgram(', 'var program = new ProgramRules(')
  s=s.replace('        return program;', '        await using var native = new ProgramNativeFixture();\n        return await ProgramSeeds.OwnerAsync(native.Content, program);')
  if name=='ProgramSource':
   s=s.replace('new AggregateReader(ProgramSource(', 'new AggregateReader(await ProgramSource(')
   s=s.replace('var scenario = CreateScenario(', 'var scenario = await CreateScenario(')
   s=s.replace('static Scenario CreateScenario(', 'static async Task<Scenario> CreateScenario(')
  else:
   s=s.replace('new AggregateReader(Program(', 'new AggregateReader(await Program(')
  return s
 edit(rel,change)
# Persistent fixture seeds have all owning dependencies and retain the same authored actor/timestamp.
edit('Features/Risks/RiskMethodPublicationTests.cs',lambda s:s.replace('var program = new ComplianceProgram(', 'var program = new ProgramRules(').replace('await fixture.Writer.SaveAsync(program, new RequestDispatchContext(RequestActor.System));','await ProgramSeeds.WriteAsync(fixture.Reader, fixture.Writer, fixture.Events, fixture.Content, program);'))
edit('Features/Commitments/CommitmentNativeDirectoryReadTests.cs',lambda s:s.replace('var programSource = new ComplianceProgram(', 'var programSource = new ProgramRules(').replace('await native.Writer.SaveAsync(programSource, new RequestDispatchContext(RequestActor.System));','await ProgramSeeds.WriteAsync(native.Reader, native.Writer, native.Events, native.Content, programSource);'))
