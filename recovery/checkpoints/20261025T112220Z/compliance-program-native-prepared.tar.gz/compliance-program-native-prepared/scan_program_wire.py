from pathlib import Path
import json
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));r=Path('/tmp/compliance-program-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def walk(n):
 st=[n]
 while st:
  x=st.pop();yield x;st.extend(reversed(x.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
out=[]
for f in (repo/'test/Compliance.Tests').rglob('*.cs'):
 if {'bin','obj'}.intersection(f.parts):continue
 rel=f.relative_to(repo);p=r/'work'/rel;t=(p if p.exists() else f).read_bytes()
 for n in walk(parser.parse(t).root_node):
  if n.type!='invocation_expression':continue
  fn=n.child_by_field_name('function');aa=n.child_by_field_name('arguments')
  if not fn or not aa:continue
  fun=tx(t,fn)
  if not any(x in fun for x in ['PostAsJsonAsync','PutAsJsonAsync','PostAsync','PutAsync']):continue
  args=[x for x in aa.children if x.type=='argument']
  if not args:continue
  arg=tx(t,args[0]);parent=n
  while parent and parent.type not in ['method_declaration','local_function_statement']:parent=parent.parent
  meth=tx(t,parent.child_by_field_name('name')) if parent and parent.child_by_field_name('name') else''
  if any(x in arg.lower() for x in ['programspath','programs"','programs\'','programpath','criteria-edition']) or (meth.startswith('CreateProgram') and arg in ['path','programs','programsPath']) or (f.name=='ProgramConcurrencyE2ETests.cs' and arg=='path'):
   out.append({'path':str(rel),'line':t[:n.start_byte].count(b'\n')+1,'method':meth,'function':fun,'arg':arg,'body':tx(t,args[1])[:95] if len(args)>1 else''})
(r/'program-wire-inventory.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
