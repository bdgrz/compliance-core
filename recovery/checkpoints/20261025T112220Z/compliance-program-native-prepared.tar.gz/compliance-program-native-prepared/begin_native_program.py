from pathlib import Path
r=Path('/tmp/compliance-program-native-prepared');common=r/'work/src/Compliance.Common/Features/Programs';core=r/'work/src/Compliance.Core/Features/Programs'
(common/'IProgramFact.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

/// <summary>A native program acceptance, with a separate business change and native sequence.</summary>
public interface IProgramFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid ProgramId { get; }
    long Revision { get; }
    ulong NativeSequence { get; }
    int ChangeCount { get; }
    ImmutableContentRef Content { get; }
}
''')
for name,tag,extra in [('ProgramCreated','bdgrz.program.created',''),('ProgramRevised','bdgrz.program.revised',''),('ProgramCriteriaEditionSelected','bdgrz.program.criteria.selected','Uuid EditionId, ')]:
 text=f'''using System.Globalization;
using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

/// <summary>The exact native program acceptance; authored value bytes remain in verified immutable content.</summary>
[Discriminator("{tag}", 2)]
public sealed record {name}(Uuid TenantId, Uuid ProgramId, long Revision, {extra}
    ImmutableContentRef Content, DateTimeOffset ChangedAt, OperationProvenance Operation,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult, ulong NativeSequence, int ChangeCount)
    : DomainEvent, IProgramFact
{{
    [JsonIgnore]
    public ActorReference Actor => Operation.Actor;
    [JsonIgnore]
    public Uuid ActorMemberId => Uuid.TryParse(Actor.Id, CultureInfo.InvariantCulture, out var member) ? member : Uuid.Empty;
    [JsonIgnore]
    public string ActorDisplay => Actor.Display;
}}
''';(common/(name+'.cs')).write_text(text)
# Reuse the established bounded digest/cut algorithm, scoped to this owner.
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
s=(repo/'src/Compliance.Core/Features/Applications/ApplicationImportSourceDigest.cs').read_text().replace('Features.Applications','Features.Programs').replace('ApplicationImportSourceDigest','ProgramDigest');(core/'ProgramDigest.cs').write_text(s)
s=(repo/'src/Compliance.Core/Features/Applications/ApplicationImportBatchNativeCut.cs').read_text().replace('Features.Applications','Features.Programs').replace('ApplicationImportBatchNativeCut','ProgramNativeCut').replace('ApplicationImportSourceDigest','ProgramDigest').replace('application import batch','program');(core/'ProgramNativeCut.cs').write_text(s)
