from pathlib import Path
p=Path('work/test/Compliance.Tests/Features/Examinations/CriteriaTypeIBaselineSourceContributorTests.cs');s=p.read_text()
s=s.replace('var program = Program(', 'var program = await Program(')
s=s.replace('NativeFacts.Raised(program)', 'program.Facts')
s=s.replace('static CriteriaTypeIBaselineSourceContributor Contributor(IAggregateReader reader,','static CriteriaTypeIBaselineSourceContributor Contributor(ProgramReader reader,')
s=s.replace('new(reader, catalog, overlays ?? new OverlayReader([]));','new(reader, reader.Events, catalog, overlays ?? new OverlayReader([]));')
s=s.replace('new CriteriaTypeIBaselineSourceContributor(new ProgramReader(program), catalog, new OverlayReader([current]), store)','new CriteriaTypeIBaselineSourceContributor(new ProgramReader(program), events, catalog, new OverlayReader([current]), store)')
s=s.replace('static ComplianceProgram Program(', 'static async Task<ProgramSource> Program(')
s=s.replace('var program = new ComplianceProgram(TenantId, ProgramId);','var program = new ProgramRules(TenantId, ProgramId);')
s=s.replace('        return program;','        return await SourceAsync(program);')
# Inline creation has no selection, retaining no-edition blocker test.
s=s.replace('var contributor = Contributor(new ProgramReader(program), Catalog(Edition(Uuid.CreateVersion4())));','var contributor = Contributor(new ProgramReader(await SourceAsync(program)), Catalog(Edition(Uuid.CreateVersion4())));')
s=s.replace('    sealed class ProgramReader(params ComplianceProgram[] programs) : IAggregateReader', '''    static async Task<ProgramSource> SourceAsync(ProgramRules rules)
    {
        var content = new FitzKvImmutableContentStore(new InMemoryKvClient());
        var facts = await ProgramSeeds.FactsAsync(content, rules);
        var owner = new ComplianceProgram(rules.TenantId, rules.Id);
        new AggregateScenario<ComplianceProgram>(owner).Given(facts.ToArray());
        var events = new InMemoryEventStore();
        await events.AppendAsync(owner.Stream, 0, facts);
        return new ProgramSource(owner, events, facts);
    }

    sealed record ProgramSource(ComplianceProgram Owner, InMemoryEventStore Events, IReadOnlyList<DomainEvent> Facts)
    {
        public EventStreamAddress Stream => Owner.Stream;
    }

    sealed class ProgramReader(params ProgramSource[] programs) : IAggregateReader''')
s=s.replace('        public ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate,','        public IDomainEventReader Events => programs[0].Events;\n        public ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate,')
s=s.replace('programs.FirstOrDefault(program => program.Id == aggregate.Id)\n                is TAggregate found','programs.FirstOrDefault(program => program.Owner.Id == aggregate.Id)?.Owner\n                is TAggregate found')
p.write_text(s)
p=Path('work/test/Compliance.Tests/Features/Criteria/CriteriaCatalogTests.cs');s=p.read_text().replace('public void ShouldKeepExactEditionSelectionGivenExplicitRemap()', 'public async Task ShouldKeepExactEditionSelectionGivenExplicitRemap()');p.write_text(s)
p=Path('work/test/Compliance.Tests/Testing/ProgramSeeds.cs');s=p.read_text().replace('new ReviseProgram(Uuid.CreateVersion4(), logical,','new ReviseProgram(logical,').replace('new SelectProgramCriteriaEdition(Uuid.CreateVersion4(), logical,','new SelectProgramCriteriaEdition(logical,');p.write_text(s)
for name in ['CreateProgram','ReviseProgram','SelectProgramCriteriaEdition']:
 p=Path('work/src/Compliance.Common/Features/Programs')/(name+'.cs');s=p.read_text().replace('public Uuid RequestId =>','Uuid IIdentifiedRequest.RequestId =>');p.write_text(s)
