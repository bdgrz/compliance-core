from pathlib import Path
import re
r=Path('/tmp/compliance-program-native-prepared');w=r/'work';b=r/'base'
owned=set((r/'root-fixture-ownership.txt').read_text().splitlines())
# Add identified DTO fields; original explicit metadata helper already migrated separately.
for p in (w/'test').rglob('*.cs'):
 if str(p.relative_to(w)) in owned:continue
 s=p.read_text()
 for name in ['CreateProgram','ReviseProgram','SelectProgramCriteriaEdition']:
  s=re.sub(r'new '+name+r'\((?!requestId,|programId, tenantId,|Uuid\.CreateVersion4\(\),)', 'new '+name+'(Uuid.CreateVersion4(), ',s)
 # v1 slots are occupied; native bodies consistently register at v2.
 for name in ['ProgramCreated','ProgramRevised','ProgramCriteriaEditionSelected']:
  s=s.replace('AddPortiaEvent<'+name+'>(1,','AddPortiaEvent<'+name+'>(2,')
 p.write_text(s)
# Real handler construction must put the verified reader inside both executor hydrations.
p=w/'test/Compliance.Tests/Features/Criteria/CriteriaCatalogTests.cs';s=p.read_text()
s=s.replace('new SelectProgramCriteriaEditionHandler(fixture.Repository,\n            catalog, TimeProvider.System)', 'new SelectProgramCriteriaEditionHandler(ProgramSeeds.Operations(fixture.Repository, fixture.Repository, fixture.Store, content), catalog)')
s=s.replace('new SelectProgramCriteriaEditionHandler(fixture.Repository, catalog,\n            TimeProvider.System)', 'new SelectProgramCriteriaEditionHandler(ProgramSeeds.Operations(fixture.Repository, fixture.Repository, fixture.Store, content), catalog)')
s=s.replace('new CreateProgramHandler(fixture.Repository, TimeProvider.System)', 'new CreateProgramHandler(ProgramSeeds.Operations(fixture.Repository, fixture.Repository, fixture.Store, content))')
s=s.replace('        await using var fixture = new StoreFixture();','        await using var fixture = new StoreFixture();\n        var content = new FitzKvImmutableContentStore(new InMemoryKvClient());')
s=s.replace('public void ShouldSelectCriteriaEditionGivenCurrentProgramRevision()', 'public async Task ShouldSelectCriteriaEditionGivenCurrentProgramRevision()')
s=s.replace('        var events = program.AppliedChanges;', '        await using var native = new ProgramNativeFixture();\n        var events = await ProgramSeeds.FactsAsync(native.Content, program);')
s=s.replace('if (record.Event is ProgramCriteriaEditionSelected selection)','if (record.Event is ProgramCriteriaEditionSelected { ChangeCount: 1 } selection)')
s=s.replace('wire.RootElement.GetProperty("actor")','wire.RootElement.GetProperty("operation").GetProperty("actor")')
if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
if 'using Bdgrz.Compliance.Features.Content;' not in s:s='using Bdgrz.Compliance.Features.Content;\nusing Cntryl.Fitz.Testing;\n'+s
p.write_text(s)
# Projection worker must use the same immutable store used when producing its facts.
p=w/'test/Compliance.Tests/Features/Criteria/ProgramCriteriaProjectionTests.cs';s=p.read_text();s=s.replace('        var tenantId = Uuid.CreateVersion4();','        var content = new FitzKvImmutableContentStore(new InMemoryKvClient());\n        var tenantId = Uuid.CreateVersion4();',1)
s=s.replace('new CreateProgramHandler(fixture.Repository, TimeProvider.System)','new CreateProgramHandler(ProgramSeeds.Operations(fixture.Repository, fixture.Repository, fixture.Store, content))')
s=s.replace('new ReviseProgramHandler(fixture.Repository, TimeProvider.System)','new ReviseProgramHandler(ProgramSeeds.Operations(fixture.Repository, fixture.Repository, fixture.Store, content))')
s=s.replace('new SelectProgramCriteriaEditionHandler(fixture.Repository,\n                CriteriaCatalog.Platform, TimeProvider.System)','new SelectProgramCriteriaEditionHandler(ProgramSeeds.Operations(fixture.Repository, fixture.Repository, fixture.Store, content), CriteriaCatalog.Platform)')
s=s.replace('BuildReplayWorker(fixture.Store, tenantId)','BuildReplayWorker(fixture.Store, content, tenantId)').replace('BuildReplayWorker(IDomainEventReader reader, Uuid tenant)','BuildReplayWorker(IDomainEventReader reader, IImmutableContentStore content, Uuid tenant)')
s=s.replace('builder.Services.AddSingleton<IImmutableContentStore>(provider =>\n            new FitzKvImmutableContentStore(provider.GetRequiredService<IKvClient>()));','builder.Services.AddSingleton(content);')
if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
p.write_text(s)
p=w/'test/Compliance.Tests/Features/Programs/ProgramStageProjectionTests.cs';s=p.read_text()
s=s.replace('CreateProgramAsync(fixture, tenantId)','CreateProgramAsync(fixture, content, tenantId)').replace('CreateProgramAsync(StoreFixture fixture, Uuid tenantId)','CreateProgramAsync(StoreFixture fixture, IImmutableContentStore content, Uuid tenantId)')
s=s.replace('new CreateProgramHandler(fixture.Repository, TimeProvider.System)','new CreateProgramHandler(ProgramSeeds.Operations(fixture.Repository, fixture.Repository, fixture.Store, content))');p.write_text(s)
p=w/'test/Compliance.Tests/Features/MethodologyTemplates/MethodologyTemplateCommandHandlerTests.cs';s=p.read_text().replace('new CreateProgramHandler(scenario.Executor, scenario.Clock)','new CreateProgramHandler(ProgramSeeds.Operations(scenario.Reader, scenario.Writer, scenario.Events, scenario.ContentStore, scenario.Clock))')
s=s.replace('        public IAggregateReader Reader { get; }','        public IAggregateReader Reader { get; }\n        public IDomainEventReader Events => _events;\n        public IAggregateWriter Writer => _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();');p.write_text(s)
