from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
p=Parser(Language(tree_sitter_c_sharp.language()));t=Path('work/test/Compliance.Tests/Features/Examinations/CriteriaTypeIBaselineSourceContributorTests.cs').read_bytes()
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
for n in walk(p.parse(t).root_node):
 if n.type=='method_declaration' and t[n.child_by_field_name('name').start_byte:n.child_by_field_name('name').end_byte]==b'Program':
  ps=n.child_by_field_name('parameters');print([(c.type,t[c.start_byte:c.end_byte].decode()) for c in ps.children])
