from pathlib import Path
import re
r=Path('/tmp/compliance-program-native-prepared');w=r/'work';b=r/'base'
owned=['Testing/BoundarySourceFixture.cs','Testing/ControlSourceFixture.cs','Testing/RiskDraftSourceFixture.cs','Testing/PolicySourceFixture.cs','Testing/CommitmentSourceFixture.cs','Testing/CampaignHost.cs','Features/Incidents/ComplianceIncidentHttpTests.cs','Features/AdvisorCollaboration/AdvisorNativeHttpTests.cs','Features/Examinations/ExaminationEngagementNativeHttpTests.cs','Features/SystemDescription/SystemDescriptionHttpTests.cs','Features/Risks/RiskDraftHttpTests.cs','Features/Policies/PolicyNativeHttpTests.cs','Features/MethodologyTemplates/MethodologyTemplateReadHttpTests.cs','Features/Operations/ObservationPeriodReadHttpTests.cs','Features/AuditPackages/AuditPackageReadHttpTests.cs','Features/AuditorRequests/AuditorRequestScopedReadHttpTests.cs','Features/AuditorRequests/AuditorRequestReadHttpTests.cs','Features/AuditorRequests/AuditorRequestReadHandlerTests.cs','Features/Changes/SignificantChangeHttpTests.cs','Features/MethodologyTemplates/MethodologyTemplateNativeHistoryTests.cs']
(r/'root-fixture-ownership.txt').write_text('\n'.join('test/Compliance.Tests/'+x for x in owned)+'\n')
# Only change typed Program seeding in real shared seed APIs; preserve all owner locators and reads.
for p in (w/'test').rglob('*.cs'):
 if str(p.relative_to(w/'test/Compliance.Tests')) in owned:continue
 s=p.read_text();s=re.sub(r'(ProgramManagementServices\.SeedAsync\([\s\S]{0,110}?)new ComplianceProgram\(',r'\1new ProgramRules(',s)
 s=re.sub(r'(ControlOperationE2ETests\.SeedAsync\([\s\S]{0,110}?)new ComplianceProgram\(',r'\1new ProgramRules(',s)
 p.write_text(s)
p=w/'test/Compliance.Tests/Testing/ProgramManagementServices.cs';s=p.read_text();mark='    public static async Task SeedAsync(IServiceProvider provider, ProgramRules selected, Func<ProgramRules, Result> operation)'
s=s.replace(mark,'''    public static Task SeedAsync(IServiceProvider provider, ProgramRules selected,
        Func<ProgramRules, Bdgrz.Compliance.Features.Versioning.CommandFailure?> operation) =>
        SeedAsync(provider, selected, rules =>
        {
            var failure = operation(rules);
            Assert.Null(failure);
            return Result.Success;
        });

'''+mark);p.write_text(s)
p=w/'test/Compliance.Tests/Testing/ProgramSeeds.cs';s=p.read_text().replace('using Cntryl.Portia;','using Cntryl.Portia;\nusing Cntryl.Portia.Testing;')
s=s.replace('    public static Task WriteAsync', '''    public static async Task<ComplianceProgram> OwnerAsync(IImmutableContentStore content, ProgramRules rules)
    {
        var owner = new ComplianceProgram(rules.TenantId, rules.Id);
        new AggregateScenario<ComplianceProgram>(owner).Given((await FactsAsync(content, rules)).ToArray());
        return owner;
    }

    public static Task WriteAsync''',1);p.write_text(s)
