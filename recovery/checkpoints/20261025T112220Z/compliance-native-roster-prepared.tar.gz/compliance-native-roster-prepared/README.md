Offline native PlatformOperatorRoster preparation

This package changes only the platform roster flow. It keeps the fixed singleton creation identity, one authoritative stream, typed grant/revoke identities, original expected roster revision, exact assignment episode, last-operator rule, current operator authorization before replay, and canonical original attribution. It introduces no projection-based authorization, independent child authority, data reset, deployment, or cross-stream atomicity claim.

Apply in order:
1. tests.patch: adds ShouldKeepAcceptingFactBoundedGivenLargeLegalBootstrapRoster against the captured OLD API. Run the red filter before implementation. A legal 4096-user seed currently embeds the entire roster in its event, exceeding 48 KiB. No native-only symbols are used by this RED.
2. implementation.patch: native compact roster, immutable authority/change/result/response, transient rules, native handlers, exact access/list/bootstrap reads.
3. migrated-tests.patch: preserves all 19 original roster acceptance method names; converts owner fixtures into native receipts, retains bus behavior tests, adds original Unit result replay, changed binding, unavailable/corrupt read, prepared cut tamper and retained-history boundary cases. Also updates compiled transport and BrokerIntegration read consumers.
4. shared-registration.patch: additive JsonContext registration for two new content DTOs and DI registration for PlatformOperatorRosterOperations.

The parent owns dotnet, format/build/test, all runtime/HTTP qualification, direct Jev review and Git/GitHub integration. No dotnet, Git mutations, worktree changes, Jev calls, GitHub writes, or repository edits were made while preparing this package. Tests and patches are prepared, not executed proof.

Suggested parent gates:
- RED: FullyQualifiedName~ShouldKeepAcceptingFactBoundedGivenLargeLegalBootstrapRoster
- Focused: FullyQualifiedName~PlatformOperatorRosterTests|FullyQualifiedName~PlatformOperatorTransportTests|FullyQualifiedName~PlatformOperatorAuthorityTests|FullyQualifiedName~PlatformOperatorOrTenantAdminAuthorizerTests
- Include WebIntegration for the HTTP first-response bridge. Exclude only Category=BrokerIntegration as instructed.
- Parent's frozen native HTTP package is complementary: roster handlers now invoke NativeOperationExecutor and publish genuine native descriptor/body receipts. Apply both transport-test changes; this package changes only the exact roster read, while the bridge package changes HTTP 204 expectations to declared 200.

Compatibility / qualification boundary:
The existing named facts still decode additively. Old facts lack trusted immutable authority, native provenance and original frozen Unit response, so the runtime owner deliberately rejects those streams rather than inventing native receipts. An explicit trusted retained-history conversion protocol is not supplied by existing contracts. This is recorded locally and does not block fresh native streams, unit proof, or integration. There is no implicit dual writer, migration claim, new issue, data reset or deployment authorization.

Authority and history:
The runtime aggregate retains only its NativeAcceptance selector, scalar revision/count and one current-authority reference. Full current membership and full original change content live in verified immutable content. The append checks both original revision and physical stream cut, exact before state, exact after state reconstructed by business rules, exact immutable change, exact named fact reconstruction, and descriptor pointing to canonical original Unit bytes. History reads reconstruct business transitions through the exact hydrated authority cut. Authorizers retain their existing IPlatformOperatorAccess dependency; its concrete event-sourced implementation now reads verified exact native authority. The existing developer-authentication bypass remains unchanged.

Artifacts:
- manifest.json: real before and after hashes for every path, new-file status and capture drift.
- before/: actual captured bytes for all 15 pre-existing paths; no tracked path is emitted from /dev/null.
- after/: complete prepared sources for 21 paths.
- audit.json: C# syntax parse, original acceptance-name preservation, compact-owner audit, constructor/Append arity and native receipt reconstruction notes. The existing huge JsonContext exceeds the tree-sitter grammar attribute depth, so all roster attributes are parsed independently; all other files parse with zero syntax errors.
- handoff.json: staged order, patch hashes and filters.

Shared file drift is expected during parent integration. Apply small JsonContext/DI hunks additively rather than overwriting their full snapshots. The transport test capture can drift because the parent is applying the frozen HTTP package; preserve both changes.
