from pathlib import Path
import hashlib,json,difflib,re
root=Path('/tmp/compliance-native-roster-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
paths=sorted(str(p.relative_to(root/'after')) for p in (root/'after').rglob('*') if p.is_file())
manifest=[]
for path in paths:
 b=root/'before'/path;a=root/'after'/path
 if not b.exists() and (repo/path).exists(): raise Exception('Existing path missing real captured before baseline: '+path)
 manifest.append({'path':path,'beforeSha256':sha(b),'afterSha256':sha(a),'currentSourceSha256':sha(repo/path),'sourceDriftedSinceCapture':b.exists() and sha(b)!=sha(repo/path),'newFile':not b.exists()})
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shared={'src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs'}
redpath='test/Compliance.Tests/Features/Tenants/PlatformOperatorRosterTests.cs'
def patch(entries):
 out=[]
 for path,b,a in entries:
  before=b.read_text().splitlines(keepends=True) if b.exists() else []
  after=a.read_text().splitlines(keepends=True) if a.exists() else []
  if before==after: continue
  out.append('diff --git a/'+path+' b/'+path+'\n')
  if not b.exists(): out.append('new file mode 100644\n')
  out.extend(difflib.unified_diff(before,after,fromfile='a/'+path if b.exists() else '/dev/null',tofile='b/'+path,n=3))
 return ''.join(out)
(root/'tests.patch').write_text(patch([(redpath,root/'before'/redpath,root/'red'/redpath)]))
(root/'implementation.patch').write_text(patch([(x,root/'before'/x,root/'after'/x) for x in paths if x.startswith('src/') and x not in shared]))
(root/'migrated-tests.patch').write_text(patch([(x,root/'red'/x if x==redpath else root/'before'/x,root/'after'/x) for x in paths if x.startswith('test/')]))
(root/'shared-registration.patch').write_text(patch([(x,root/'before'/x,root/'after'/x) for x in sorted(shared)]))
audit=json.loads((root/'audit.json').read_text())
audit['ctorAndAppendArities']={'PlatformOperatorMutationContent':11,'PlatformOperatorAuthorityContent':3,'PlatformOperatorRosterOperations':4,'PlatformOperatorRoster.Append':7,'PlatformOperatorRosterSeeded':4,'PlatformOperatorGranted':8,'PlatformOperatorRevoked':9,'GrantPlatformOperatorHandler':1,'RevokePlatformOperatorHandler':1,'SeedPlatformOperatorRosterHandler':1,'status':'Source callsites inspected; parent compilation remains authoritative.'}
audit['nativeFactReconstruction']={'factory':'PlatformOperatorRosterContent.Fact','append':'Reconstructs exact named fact and compares generated JSON digest; validates exact before/after authority, immutable change, descriptor, canonical Unit bytes, source revision and physical cut.','history':'Verified change/authority/descriptor/result read, exact fact reconstruction and business fold through selected authority cut.','nativeOnly':'No legacy writers, synchronous roster lookup methods, authority dictionaries or receipt arrays on runtime owner.'}
audit['baselineCoverage']={'existing':sum(not x['newFile'] for x in manifest),'new':sum(x['newFile'] for x in manifest),'trackedOrExistingAsDevNull':[],'drifted':[x['path'] for x in manifest if x['sourceDriftedSinceCapture']]}
(root/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
patches={x:sha(root/x) for x in ['tests.patch','implementation.patch','migrated-tests.patch','shared-registration.patch']}
handoff={'artifact':str(root),'status':'frozen offline preparation; runtime and Jev pending','paths':len(paths),'patchOrder':list(patches),'patches':patches,'redFilter':'FullyQualifiedName~ShouldKeepAcceptingFactBoundedGivenLargeLegalBootstrapRoster','focusedFilter':'FullyQualifiedName~PlatformOperatorRosterTests|FullyQualifiedName~PlatformOperatorTransportTests|FullyQualifiedName~PlatformOperatorAuthorityTests|FullyQualifiedName~PlatformOperatorOrTenantAdminAuthorizerTests','runtimeFilterRequirement':'Category!=BrokerIntegration (include WebIntegration for native HTTP first-response bridge qualification)','sharedOverlap':'Apply registration hunks additively to current JsonContext/ServiceCollection. Transport test read change may overlap frozen HTTP migrated tests; preserve both. No Program.cs edits.','retainedHistoryQualification':'Legacy v1 facts still decode, but missing trusted native authority/result/response causes hydration to fail closed. No implicit converter, data reset, deployment or retained-stream qualification claim.','audit':'audit.json','manifest':'manifest.json'}
(root/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'patches':patches,'sourceDrifted':audit['baselineCoverage']['drifted']},indent=2))
