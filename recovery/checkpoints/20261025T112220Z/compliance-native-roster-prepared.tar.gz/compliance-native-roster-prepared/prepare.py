from pathlib import Path
p=Path('/tmp/compliance-native-roster-prepared/after')
import shutil
for source in (p.parent/'before').rglob('*'):
 if source.is_file():
  target=p/source.relative_to(p.parent/'before');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
def write(path,s):
 f=p/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
write('src/Compliance.Common/Features/Tenants/IPlatformOperatorFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>A compact receipt on the single authoritative platform roster stream.</summary>
public interface IPlatformOperatorFact : INativeOperationFact
{
    ulong Revision { get; }
    int ActiveCount { get; }
    ImmutableContentRef Authority { get; }
    ImmutableContentRef Change { get; }
    ImmutableContentRef? OperationResult { get; }
}
''')
for name in ['PlatformOperatorRosterSeeded','PlatformOperatorGranted','PlatformOperatorRevoked']:
 f=p/f'src/Compliance.Common/Features/Tenants/{name}.cs';s=f.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;\n'+s
 s=s.replace(': DomainEvent;', ''': DomainEvent, IPlatformOperatorFact
{
    public OperationProvenance Operation { get; init; } = default!;
    public ImmutableContentRef? FirstResponse { get; init; }
    public ImmutableContentRef? OperationResult { get; init; }
    public ImmutableContentRef Authority { get; init; } = default!;
    public ImmutableContentRef Change { get; init; } = default!;
    public ulong Revision { get; init; }
    public int ActiveCount { get; init; }
}
''');f.write_text(s)
write('src/Compliance.Common/Features/Tenants/PlatformOperatorAuthorityContent.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>The canonical complete current roster, read only through its native authority reference.</summary>
public sealed record PlatformOperatorAuthorityContent(Uuid RosterId, ulong Revision,
    PlatformOperatorAssignmentView[] Operators);
''')
write('src/Compliance.Common/Features/Tenants/PlatformOperatorMutationContent.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>Exact immutable authored intent and original attribution of one roster operation.</summary>
public sealed record PlatformOperatorMutationContent(string CommandKind, Uuid CommandId, ulong? ExpectedRevision,
    Uuid ActorUserId, Uuid SubjectUserId, Uuid AssignmentId, Uuid[] BootstrapUserIds, string Reason,
    ActorAttribution OriginalActor, ActorReference Actor, DateTimeOffset AcceptedAt);
''')
write('src/Compliance.Core/Features/Tenants/PlatformOperatorRoster.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Hosting.Persistence;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>Compact authority on one stream preserves the global nonempty-roster invariant.</summary>
public sealed class PlatformOperatorRoster : Aggregate
{
    static readonly Uuid RosterId = Uuid.Parse(
        "bc279ad5-e9ae-5033-a174-4d1350ce2b07", CultureInfo.InvariantCulture);

    public PlatformOperatorRoster(Uuid selectedCommandId = default)
        : base(RosterId, new EventStreamAddress("bdgrz", "platform-operator-roster", RosterId.ToString()))
    {
        Acceptance = new(selectedCommandId);
        On<PlatformOperatorRosterSeeded>(Apply);
        On<PlatformOperatorGranted>(Apply);
        On<PlatformOperatorRevoked>(Apply);
    }

    public static Uuid CreationId => RosterId;
    public NativeAcceptance Acceptance { get; }
    public bool IsInitialized => CurrentAuthority is not null;
    public ulong Revision { get; private set; }
    public int ActiveCount { get; private set; }
    public ImmutableContentRef? CurrentAuthority { get; private set; }

    public Result Append(DomainEvent value, ulong preparedRevision, ulong preparedPhysicalPosition,
        PlatformOperatorMutationContent mutation, PlatformOperatorAuthorityContent before,
        PlatformOperatorAuthorityContent after)
    {
        if (preparedRevision != Revision || preparedPhysicalPosition != CommittedStreamPosition)
            return Failure(RequestErrorKind.Conflict, "The roster changed while its exact authority was prepared.");
        try
        {
            var fact = value as IPlatformOperatorFact ?? throw new InvalidOperationException();
            Validate(value, fact);
            PlatformOperatorRosterContent.RequireAuthority(before, Revision, ActiveCount);
            Require(CurrentAuthority is null ? Revision == 0 && before.Operators.Length == 0 :
                PlatformOperatorRosterContent.Matches(CurrentAuthority, before, PlatformOperatorRosterContent.AuthoritySchema));
            var evaluated = PlatformOperatorRosterRules.Apply(before, mutation);
            if (!evaluated.IsSuccess)
                return Result.Failure(evaluated.Error!);
            Require(ContentDigest.OfJson(evaluated.Value!) == ContentDigest.OfJson(after) &&
                PlatformOperatorRosterContent.Matches(fact.Authority, after, PlatformOperatorRosterContent.AuthoritySchema) &&
                PlatformOperatorRosterContent.Matches(fact.Change, mutation, PlatformOperatorRosterContent.ChangeSchema));
            var expected = PlatformOperatorRosterContent.Fact(mutation, fact.Operation, fact.Change,
                fact.Authority, fact.FirstResponse!, fact.OperationResult!, after);
            Require(ContentDigest.Sha256(expected, expected.GetType()) == ContentDigest.Sha256(value, value.GetType()));
            Require(fact.Operation.AuthoredIntentSha256 == PlatformOperatorRosterContent.IntentDigest(mutation));
            Require(DomainEventPayload.Size(value) <= DomainEventPayload.MaximumBytes);
        }
        catch (InvalidOperationException)
        {
            return Failure(RequestErrorKind.Validation, "The roster fact differs from its exact prepared native authority.");
        }
        RaiseEvent(value);
        return Result.Success;
    }

    void Apply(PlatformOperatorRosterSeeded value) => ApplyFact(value);
    void Apply(PlatformOperatorGranted value) => ApplyFact(value);
    void Apply(PlatformOperatorRevoked value) => ApplyFact(value);

    void ApplyFact(DomainEvent value)
    {
        var fact = (IPlatformOperatorFact)value;
        Validate(value, fact);
        Acceptance.Observe(value);
        CurrentAuthority = fact.Authority;
        Revision = fact.Revision;
        ActiveCount = fact.ActiveCount;
    }

    void Validate(DomainEvent value, IPlatformOperatorFact fact)
    {
        // Retained legacy facts have no trusted immutable authority or original native response. They must not
        // silently become qualified native acceptances; an explicit trusted conversion is a separate protocol.
        Require(fact.Operation is not null && fact.Operation.Actor is not null);
        var operation = fact.Operation;
        OwnerProvenance.RequireOwn(this, operation.LogicalId, operation);
        Require(operation.RootOperationId == operation.LogicalId && operation.CausationEventId is null &&
            operation.AffectedOwner == Stream && operation.ExpectedRevisionOwner == Stream &&
            (operation.FirstOwner is null || operation.FirstOwner == Stream) && operation.Episode == Id.ToString() &&
            operation.AcceptedAt != default && operation.AuthoredIntentSha256.Length == 64 &&
            operation.AuthoredIntentSha256.All(static c => c is >= '0' and <= '9' or >= 'a' and <= 'f') &&
            fact.Revision == Revision + 1 && fact.ActiveCount > 0 &&
            PlatformOperatorRosterContent.Reference(fact.Authority, PlatformOperatorRosterContent.AuthoritySchema) &&
            PlatformOperatorRosterContent.Reference(fact.Change, PlatformOperatorRosterContent.ChangeSchema) &&
            PlatformOperatorRosterContent.Reference(fact.FirstResponse, FirstResponses.Schema) &&
            PlatformOperatorRosterContent.Reference(fact.OperationResult, UnitResult.Schema));
        switch (value)
        {
            case PlatformOperatorRosterSeeded seed:
                Require(!IsInitialized && Revision == 0 && seed.RosterId == Id && seed.UserIds.Length == 0 &&
                    operation.LogicalId == Id && operation.CommandKind == nameof(SeedPlatformOperatorRoster) &&
                    operation.OriginalExpectedRevision is null && operation.Actor.Kind == "system_process" &&
                    operation.Actor.Id == "platform-operator-bootstrap" && RequestActorAttribution(seed.Actor) &&
                    seed.OccurredAt == operation.AcceptedAt);
                break;
            case PlatformOperatorGranted grant:
                Require(IsInitialized && operation.CommandKind == nameof(GrantPlatformOperator) &&
                    grant.CommandId == operation.LogicalId && grant.ExpectedRevision == Revision &&
                    operation.OriginalExpectedRevision == Revision && fact.ActiveCount == ActiveCount + 1 &&
                    ValidChange(grant.ActorUserId, grant.SubjectUserId, grant.Reason, grant.Actor, operation) &&
                    grant.ActorDisplay == operation.Actor.Display && grant.OccurredAt == operation.AcceptedAt);
                break;
            case PlatformOperatorRevoked revoke:
                Require(IsInitialized && operation.CommandKind == nameof(RevokePlatformOperator) &&
                    revoke.CommandId == operation.LogicalId && revoke.ExpectedRevision == Revision &&
                    operation.OriginalExpectedRevision == Revision && fact.ActiveCount == ActiveCount - 1 &&
                    revoke.AssignmentId != Uuid.Empty &&
                    ValidChange(revoke.ActorUserId, revoke.SubjectUserId, revoke.Reason, revoke.Actor, operation) &&
                    revoke.ActorDisplay == operation.Actor.Display && revoke.OccurredAt == operation.AcceptedAt);
                break;
            default:
                throw new InvalidOperationException("Unknown roster fact.");
        }
    }

    static bool ValidChange(Uuid actor, Uuid subject, string reason, ActorAttribution attribution,
        OperationProvenance operation) => actor != Uuid.Empty && subject != Uuid.Empty &&
        PlatformOperatorRosterRules.ValidReason(reason) && reason == reason.Trim() &&
        RequestActorAttribution(attribution) && attribution.Subject == actor.ToString() &&
        operation.Actor.Kind == "platform_operator" && operation.Actor.Id == actor.ToString();
    static bool RequestActorAttribution(ActorAttribution actor) => actor is not null &&
        !string.IsNullOrWhiteSpace(actor.Subject) && !string.IsNullOrWhiteSpace(actor.Issuer);
    static void Require(bool valid)
    {
        if (!valid)
            throw new InvalidOperationException("The roster requires its exact original native authority and operation.");
    }
    static Result Failure(RequestErrorKind kind, string message) => Result.Failure(new RequestError(kind, message));
}
''')
write('src/Compliance.Core/Features/Tenants/PlatformOperatorRosterRules.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>Transient business evaluation over a verified complete source cut; never a second authority.</summary>
public static class PlatformOperatorRosterRules
{
    public static Result<PlatformOperatorAuthorityContent> Apply(PlatformOperatorAuthorityContent before,
        PlatformOperatorMutationContent mutation)
    {
        if (mutation.CommandId == Uuid.Empty || mutation.OriginalActor is null || mutation.Actor is null ||
            string.IsNullOrWhiteSpace(mutation.OriginalActor.Subject) || string.IsNullOrWhiteSpace(mutation.OriginalActor.Issuer) ||
            mutation.AcceptedAt == default)
            return Failure(RequestErrorKind.Validation, "A selected command identity and original actor are required.");
        var operators = before.Operators.ToDictionary(static item => item.UserId, static item => item.AssignmentId);
        if (mutation.CommandKind == nameof(SeedPlatformOperatorRoster))
        {
            if (mutation.CommandId != PlatformOperatorRoster.CreationId || mutation.ExpectedRevision is not null ||
                mutation.ActorUserId != Uuid.Empty || mutation.SubjectUserId != Uuid.Empty || mutation.AssignmentId != Uuid.Empty ||
                mutation.Reason.Length != 0 || mutation.Actor.Kind != "system_process" ||
                mutation.Actor.Id != "platform-operator-bootstrap" || mutation.BootstrapUserIds.Length == 0 ||
                mutation.BootstrapUserIds.Contains(Uuid.Empty) ||
                !mutation.BootstrapUserIds.SequenceEqual(CanonicalUsers(mutation.BootstrapUserIds)))
                return Failure(RequestErrorKind.Validation, "The fixed seed identity and canonical bootstrap users are required.");
            if (before.Revision != 0 || operators.Count != 0)
                return Failure(RequestErrorKind.Conflict, "The initial roster already exists.");
            foreach (var user in mutation.BootstrapUserIds)
                operators.Add(user, Uuid.CreateVersion5(PlatformOperatorRoster.CreationId, $"platform-operator:initial:{user}"));
        }
        else
        {
            if (!operators.ContainsKey(mutation.ActorUserId))
                return Failure(RequestErrorKind.Forbidden, "The actor is not a platform operator.");
            if (mutation.SubjectUserId == Uuid.Empty || mutation.Actor.Kind != "platform_operator" ||
                mutation.Actor.Id != mutation.ActorUserId.ToString() ||
                mutation.OriginalActor.Subject != mutation.ActorUserId.ToString() ||
                !ValidReason(mutation.Reason) || mutation.Reason != mutation.Reason.Trim() || mutation.BootstrapUserIds.Length != 0)
                return Failure(RequestErrorKind.Validation, "An attributed platform user and bounded canonical reason are required.");
            if (mutation.ExpectedRevision != before.Revision)
                return Failure(RequestErrorKind.Conflict, "The operator roster revision changed.");
            if (mutation.CommandKind == nameof(GrantPlatformOperator))
            {
                if (mutation.AssignmentId != Uuid.Empty)
                    return Failure(RequestErrorKind.Validation, "A grant cannot name another assignment episode.");
                if (!operators.TryAdd(mutation.SubjectUserId, mutation.CommandId))
                    return Failure(RequestErrorKind.Conflict, "The user is already assigned.");
            }
            else if (mutation.CommandKind == nameof(RevokePlatformOperator))
            {
                if (mutation.AssignmentId == Uuid.Empty)
                    return Failure(RequestErrorKind.Validation, "An operator assignment identity is required.");
                if (!operators.TryGetValue(mutation.SubjectUserId, out var assignment) || assignment != mutation.AssignmentId)
                    return Failure(RequestErrorKind.Conflict, "The operator assignment episode changed.");
                if (operators.Count == 1)
                    return Failure(RequestErrorKind.Conflict, "The last platform operator cannot be revoked.");
                operators.Remove(mutation.SubjectUserId);
            }
            else
                return Failure(RequestErrorKind.Validation, "Unknown roster operation.");
        }
        return Result<PlatformOperatorAuthorityContent>.Success(new(PlatformOperatorRoster.CreationId, before.Revision + 1,
            operators.OrderBy(static entry => entry.Key.ToString(), StringComparer.Ordinal)
                .Select(static entry => new PlatformOperatorAssignmentView(entry.Key, entry.Value)).ToArray()));
    }

    public static bool ValidReason(string? reason) => !string.IsNullOrWhiteSpace(reason) && reason.Trim().Length <= 500;
    public static Uuid[] CanonicalUsers(IEnumerable<Uuid> users) => users.Distinct()
        .OrderBy(static id => id.ToString(), StringComparer.Ordinal).ToArray();
    static Result<PlatformOperatorAuthorityContent> Failure(RequestErrorKind kind, string message) =>
        Result<PlatformOperatorAuthorityContent>.Failure(new RequestError(kind, message));
}
''')
write('src/Compliance.Core/Features/Tenants/PlatformOperatorRosterContent.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>Verified immutable roster authority, full change history and exact receipt reconstruction.</summary>
public static class PlatformOperatorRosterContent
{
    public const string Realm = "bdgrz";
    public const string AuthoritySchema = "platform-operator-current-authority.v1";
    public const string ChangeSchema = "platform-operator-mutation.v1";

    public static PlatformOperatorAuthorityContent Empty => new(PlatformOperatorRoster.CreationId, 0, []);

    public static async Task<PlatformOperatorAuthorityContent> ReadAsync(IImmutableContentStore content,
        PlatformOperatorRoster owner, CancellationToken ct = default)
    {
        if (owner.CurrentAuthority is null)
            return Empty;
        if (!Reference(owner.CurrentAuthority, AuthoritySchema))
            throw new ImmutableContentIntegrityException("The roster authority has another schema.");
        var state = await content.ReadJsonAsync<PlatformOperatorAuthorityContent>(Realm, owner.CurrentAuthority, ct)
            .ConfigureAwait(false);
        RequireAuthority(state, owner.Revision, owner.ActiveCount);
        return state;
    }

    public static async Task<PlatformOperatorMutationContent> ReadChangeAsync(IImmutableContentStore content,
        DomainEvent value, CancellationToken ct = default)
    {
        if (value is not IPlatformOperatorFact fact || fact.Operation is null ||
            !Reference(fact.Change, ChangeSchema) || !Reference(fact.Authority, AuthoritySchema) ||
            !Reference(fact.FirstResponse, FirstResponses.Schema) || !Reference(fact.OperationResult, UnitResult.Schema))
            throw new ImmutableContentIntegrityException("The roster fact has no exact native change and response.");
        var mutation = await content.ReadJsonAsync<PlatformOperatorMutationContent>(Realm, fact.Change, ct).ConfigureAwait(false);
        var state = await content.ReadJsonAsync<PlatformOperatorAuthorityContent>(Realm, fact.Authority, ct).ConfigureAwait(false);
        RequireAuthority(state, fact.Revision, fact.ActiveCount);
        var expected = Fact(mutation, fact.Operation, fact.Change, fact.Authority, fact.FirstResponse!, fact.OperationResult!, state);
        if (ContentDigest.Sha256(expected, expected.GetType()) != ContentDigest.Sha256(value, value.GetType()) ||
            fact.Operation.AuthoredIntentSha256 != IntentDigest(mutation))
            throw new ImmutableContentIntegrityException("The roster native receipt differs from its immutable original change.");
        return mutation;
    }

    /// <summary>Reads only the hydrated authority cut; later appends cannot change this historical composition.</summary>
    public static async Task<IReadOnlyList<PlatformOperatorMutationContent>> ReadHistoryAsync(IImmutableContentStore content,
        IEventStore events, PlatformOperatorRoster owner, CancellationToken ct = default)
    {
        var changes = new List<PlatformOperatorMutationContent>();
        var state = Empty;
        await foreach (var record in events.ReadAsync(owner.Stream, 0, ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit)
                continue;
            if (state.Revision == owner.Revision)
                break;
            var mutation = await ReadChangeAsync(content, record.Event, ct).ConfigureAwait(false);
            var evaluated = PlatformOperatorRosterRules.Apply(state, mutation);
            if (!evaluated.IsSuccess || record.Event is not IPlatformOperatorFact fact ||
                !Matches(fact.Authority, evaluated.Value!, AuthoritySchema))
                throw new ImmutableContentIntegrityException("The roster history has an invalid original authority transition.");
            state = evaluated.Value!;
            changes.Add(mutation);
        }
        if (state.Revision != owner.Revision || owner.CurrentAuthority is { } authority && !Matches(authority, state, AuthoritySchema))
            throw new ImmutableContentIntegrityException("The roster history does not reconstruct the selected native authority cut.");
        return changes;
    }

    public static string IntentDigest(PlatformOperatorMutationContent mutation) => AuthoredIntentDigest.Compute(
        mutation with { Actor = mutation.Actor with { Display = string.Empty }, AcceptedAt = default });

    public static DomainEvent Fact(PlatformOperatorMutationContent mutation, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef firstResponse,
        ImmutableContentRef result, PlatformOperatorAuthorityContent after)
    {
        if (operation.Actor != mutation.Actor || operation.AcceptedAt != mutation.AcceptedAt ||
            operation.LogicalId != mutation.CommandId || operation.CommandKind != mutation.CommandKind ||
            operation.OriginalExpectedRevision != mutation.ExpectedRevision)
            throw new InvalidOperationException("The roster change differs from its original provenance.");
        return mutation.CommandKind switch
        {
            nameof(SeedPlatformOperatorRoster) => new PlatformOperatorRosterSeeded(mutation.CommandId, [],
                mutation.OriginalActor, mutation.AcceptedAt)
            {
                Operation = operation, Authority = authority, Change = change, FirstResponse = firstResponse,
                OperationResult = result, Revision = after.Revision, ActiveCount = after.Operators.Length
            },
            nameof(GrantPlatformOperator) => new PlatformOperatorGranted(mutation.CommandId, mutation.ExpectedRevision!.Value,
                mutation.ActorUserId, mutation.SubjectUserId, mutation.OriginalActor, mutation.AcceptedAt,
                mutation.Reason, mutation.Actor.Display)
            {
                Operation = operation, Authority = authority, Change = change, FirstResponse = firstResponse,
                OperationResult = result, Revision = after.Revision, ActiveCount = after.Operators.Length
            },
            nameof(RevokePlatformOperator) => new PlatformOperatorRevoked(mutation.CommandId, mutation.ExpectedRevision!.Value,
                mutation.ActorUserId, mutation.SubjectUserId, mutation.AssignmentId, mutation.OriginalActor,
                mutation.AcceptedAt, mutation.Reason, mutation.Actor.Display)
            {
                Operation = operation, Authority = authority, Change = change, FirstResponse = firstResponse,
                OperationResult = result, Revision = after.Revision, ActiveCount = after.Operators.Length
            },
            _ => throw new InvalidOperationException("Unknown roster operation.")
        };
    }

    public static void RequireAuthority(PlatformOperatorAuthorityContent state, ulong revision, int count)
    {
        if (state is null || state.RosterId != PlatformOperatorRoster.CreationId || state.Revision != revision ||
            state.Operators is null || state.Operators.Length != count || (revision == 0 ? count != 0 : count <= 0) ||
            state.Operators.Any(static item => item.UserId == Uuid.Empty || item.AssignmentId == Uuid.Empty) ||
            state.Operators.Select(static item => item.UserId).Distinct().Count() != count ||
            !state.Operators.Select(static item => item.UserId).SequenceEqual(
                PlatformOperatorRosterRules.CanonicalUsers(state.Operators.Select(static item => item.UserId))))
            throw new ImmutableContentIntegrityException("The roster authority is not the exact canonical nonempty source state.");
    }

    public static bool Reference(ImmutableContentRef? reference, string schema) => reference is not null &&
        reference.ContentId != Uuid.Empty && reference.Schema == schema && reference.MediaType == "application/json" &&
        reference.Length > 0 && reference.Sha256.Length == 64 &&
        reference.Sha256.All(static c => c is >= '0' and <= '9' or >= 'a' and <= 'f');
    public static bool Matches<T>(ImmutableContentRef reference, T value, string schema) where T : notnull =>
        Reference(reference, schema) && reference.Sha256 == ContentDigest.OfJson(value);
}
''')
write('src/Compliance.Core/Features/Tenants/PlatformOperatorRosterOperations.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>Native roster admission; the request pipeline authorizes current authority before any replay.</summary>
public sealed class PlatformOperatorRosterOperations(NativeOperationExecutor operations, IImmutableContentStore content,
    IPlatformUserDirectoryReader users, TimeProvider clock)
{
    public ValueTask<Result> SeedAsync(IRequestContext<SeedPlatformOperatorRoster> context, CancellationToken ct)
    {
        var request = context.Request;
        if (!RequestActor.IsSystem(context.Actor))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Forbidden,
                "Only the trusted bootstrap producer may seed the roster.")));
        var mutation = new PlatformOperatorMutationContent(nameof(SeedPlatformOperatorRoster), request.RosterId, null,
            Uuid.Empty, Uuid.Empty, Uuid.Empty, PlatformOperatorRosterRules.CanonicalUsers(request.UserIds), string.Empty,
            RbacOperationActor.From(context.Actor), ActorReference.ForSystemProcess("platform-operator-bootstrap", "Platform operator bootstrap"),
            clock.GetUtcNow());
        return ExecuteAsync(context, mutation, ct);
    }

    public ValueTask<Result> GrantAsync(IRequestContext<GrantPlatformOperator> context, CancellationToken ct) =>
        Personal(context, (actor, attribution) => ExecuteAsync(context, new(nameof(GrantPlatformOperator),
            context.Request.CommandId, context.Request.ExpectedRevision, actor, context.Request.UserId, Uuid.Empty, [],
            context.Request.Reason?.Trim() ?? string.Empty, attribution,
            ActorReference.ForPlatformOperator(actor, UserIdentityClaims.BdgrzDisplay(context.Actor, actor)), clock.GetUtcNow()), ct));

    public ValueTask<Result> RevokeAsync(IRequestContext<RevokePlatformOperator> context, CancellationToken ct) =>
        Personal(context, (actor, attribution) => ExecuteAsync(context, new(nameof(RevokePlatformOperator),
            context.Request.CommandId, context.Request.ExpectedRevision, actor, context.Request.UserId,
            context.Request.AssignmentId, [], context.Request.Reason?.Trim() ?? string.Empty, attribution,
            ActorReference.ForPlatformOperator(actor, UserIdentityClaims.BdgrzDisplay(context.Actor, actor)), clock.GetUtcNow()), ct));

    static ValueTask<Result> Personal<T>(IRequestContext<T> context,
        Func<Uuid, ActorAttribution, ValueTask<Result>> next) where T : IRequest
    {
        if (!UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var actor))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Unauthorized,
                "An authenticated platform user is required.")));
        return next(actor, RbacOperationActor.From(context.Actor));
    }

    async ValueTask<Result> ExecuteAsync(IExecutionContext context, PlatformOperatorMutationContent mutation, CancellationToken ct)
    {
        if (mutation.CommandId == Uuid.Empty)
            return Result.Failure(new RequestError(RequestErrorKind.Validation, "A selected command identity is required."));
        var candidate = new PlatformOperatorRoster(mutation.CommandId);
        var operation = OwnerProvenance.For(candidate, mutation.CommandId, mutation.CommandKind, mutation.Actor,
            candidate.Id.ToString(), mutation.ExpectedRevision, PlatformOperatorRosterContent.IntentDigest(mutation), mutation.AcceptedAt);
        PlatformOperatorAuthorityContent? before = null;
        PlatformOperatorAuthorityContent? after = null;
        ImmutableContentRef? change = null;
        ImmutableContentRef? authority = null;
        ImmutableContentRef? result = null;
        ulong revision = 0;
        ulong position = 0;
        var accepted = await operations.ExecuteAsync(new NativeOperation<PlatformOperatorRoster>(AcceptedOperationBinding.Of(operation),
            () => new(mutation.CommandId), static roster => roster.Acceptance, async (roster, token) =>
            {
                before = await PlatformOperatorRosterContent.ReadAsync(content, roster, token).ConfigureAwait(false);
                var evaluated = PlatformOperatorRosterRules.Apply(before, mutation);
                if (!evaluated.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(evaluated.Error!);
                if (mutation.CommandKind == nameof(GrantPlatformOperator) &&
                    !await users.ExistsAsync(mutation.SubjectUserId, token).ConfigureAwait(false))
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The platform user is not available yet.", isTransient: true));
                after = evaluated.Value!;
                revision = roster.Revision;
                position = roster.CommittedStreamPosition;
                change = await content.WriteJsonAsync(PlatformOperatorRosterContent.Realm, Uuid.CreateVersion4(),
                    PlatformOperatorRosterContent.ChangeSchema, mutation, token).ConfigureAwait(false);
                authority = await content.WriteJsonAsync(PlatformOperatorRosterContent.Realm, Uuid.CreateVersion4(),
                    PlatformOperatorRosterContent.AuthoritySchema, after, token).ConfigureAwait(false);
                var response = await UnitResponses.FreezeAsync(content, PlatformOperatorRosterContent.Realm, token).ConfigureAwait(false);
                result = ((StandardResponseBody)response.Body).Content;
                return Result<FirstResponseDescriptor>.Success(response);
            }, (roster, first) => roster.Append(PlatformOperatorRosterContent.Fact(mutation, operation, change!, authority!,
                first, result!, after!), revision, position, mutation, before!, after!)), context, ct).ConfigureAwait(false);
        if (!accepted.IsSuccess)
            return Result.Failure(accepted.Error!);
        var response = accepted.Value switch
        {
            AcceptedAppendResult.Committed committed => committed.Response,
            AcceptedAppendResult.Replayed replayed => replayed.Response,
            _ => null
        };
        if (response is null)
            return Result.Failure(AcceptedAppendResult.ConflictError);
        if (response.HttpStatus != 200 || response.ResultSchema != UnitResult.Schema || response.ContentType != "application/json" ||
            response.Body is not StandardResponseBody body || body.Content.Schema != UnitResult.Schema)
            throw new ImmutableContentIntegrityException("The roster operation has no exact original Unit response.");
        await content.ReadJsonAsync<UnitResult>(PlatformOperatorRosterContent.Realm, body.Content, ct).ConfigureAwait(false);
        return Result.Success;
    }
}
''')
for command,method in [('GrantPlatformOperator','Grant'),('RevokePlatformOperator','Revoke'),('SeedPlatformOperatorRoster','Seed')]:
 write(f'src/Compliance.Core/Features/Tenants/{command}Handler.cs',f'''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

public sealed class {command}Handler(PlatformOperatorRosterOperations operations) : IRequestHandler<{command}>
{{
    public ValueTask<Result> HandleAsync(IRequestContext<{command}> context, CancellationToken ct) =>
        operations.{method}Async(context, ct);
}}
''')
f=p/'src/Compliance.Core/Features/Tenants/EventSourcedPlatformOperatorAccess.cs';s=f.read_text().replace('using Cntryl.Portia;','using Bdgrz.Compliance.Features.Content;\nusing Cntryl.Portia;').replace('PlatformOperatorAuthority configuration)','PlatformOperatorAuthority configuration, IImmutableContentStore content)').replace('return roster.IsOperator(userId);','var authority = await PlatformOperatorRosterContent.ReadAsync(content, roster, ct).ConfigureAwait(false);\n        return authority.Operators.Any(entry => entry.UserId == userId);');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/ListPlatformOperatorsHandler.cs';s=f.read_text().replace('using Cntryl.Portia;','using Bdgrz.Compliance.Features.Content;\nusing Cntryl.Portia;').replace('(IAggregateReader reader)','(IAggregateReader reader, IImmutableContentStore content)').replace('return Result<PlatformOperatorRosterView>.Success(new PlatformOperatorRosterView(roster.Version, roster.Operators));','var authority = await PlatformOperatorRosterContent.ReadAsync(content, roster, ct).ConfigureAwait(false);\n        return Result<PlatformOperatorRosterView>.Success(new PlatformOperatorRosterView(authority.Revision, authority.Operators));');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRosterBootstrap.cs';s=f.read_text().replace('using Cntryl.Portia;','using Bdgrz.Compliance.Features.Content;\nusing Cntryl.Portia;').replace('if (roster.IsInitialized)\n            return;','if (roster.IsInitialized)\n        {\n            await PlatformOperatorRosterContent.ReadAsync(services.GetRequiredService<IImmutableContentStore>(), roster, cancellationToken)\n                .ConfigureAwait(false);\n            return;\n        }');f.write_text(s)
f=p/'src/Compliance.Core/ComplianceCoreJsonContext.cs';s=f.read_text().replace('[JsonSerializable(typeof(SeedPlatformOperatorRoster))]','[JsonSerializable(typeof(PlatformOperatorAuthorityContent))]\n[JsonSerializable(typeof(PlatformOperatorMutationContent))]\n[JsonSerializable(typeof(SeedPlatformOperatorRoster))]');f.write_text(s)
f=p/'src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';s=f.read_text().replace('services.AddScoped<IPlatformOperatorAccess, EventSourcedPlatformOperatorAccess>();','services.AddScoped<IPlatformOperatorAccess, EventSourcedPlatformOperatorAccess>();\n        services.AddScoped<PlatformOperatorRosterOperations>();');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRosterContent.cs';s=f.read_text().replace('reference.Length > 0','reference.Bytes > 0');f.write_text(s)
f=p/'test/Compliance.Tests/Features/Tenants/PlatformOperatorRosterTests.cs';s=f.read_text().replace('using System.Security.Claims;','using System.Security.Claims;\nusing Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;\nusing Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Hosting.Persistence;\nusing Cntryl.Fitz.Testing;')
s=s.replace('await scope.ServiceProvider.GetRequiredService<IAggregateReader>()\n            .HydrateAsync(new PlatformOperatorRoster())','await ReadRosterAsync(scope.ServiceProvider)').replace('await scope.ServiceProvider.GetRequiredService<IAggregateReader>().HydrateAsync(new PlatformOperatorRoster())','await ReadRosterAsync(scope.ServiceProvider)').replace('await reader.HydrateAsync(new PlatformOperatorRoster())','await ReadRosterAsync(scope.ServiceProvider)')
s=s.replace('        var reader = scope.ServiceProvider.GetRequiredService<IAggregateReader>();\n','')
s=s.replace('''        var owner = new PlatformOperatorRoster(id);
        var facts = new DomainEvent[] { Seeded(First), Granted(id), Revoked(Uuid.CreateVersion4(), id) };
        var restored = facts.Select((fact, index) => serializer.Deserialize(serializer.Serialize(
            DomainEventSeed.Attach(fact, owner.Id, (ulong)index + 1)))).ToArray();
        var scenario = new AggregateScenario<PlatformOperatorRoster>(owner).Given(restored);''','''        var native = Given(id, Seeded(First), Granted(id), Revoked(Uuid.CreateVersion4(), id));
        var restored = native.Facts.Select(fact => serializer.Deserialize(serializer.Serialize(fact))).ToArray();
        var scenario = RosterFixture.Restore(id, restored, native.State);
        var owner = scenario.Aggregate;''')
s=s.replace('''        services.AddSingleton(TimeProvider.System);''','''        services.AddSingleton(TimeProvider.System);
        services.AddSingleton<IImmutableContentStore>(new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient())));
        services.AddScoped<NativeOperationExecutor>();
        services.AddScoped<PlatformOperatorRosterOperations>();''')
start=s.index('    static AggregateScenario<PlatformOperatorRoster> Given(')
end=s.index('    sealed class ExistingUsers',start)
s=s[:start]+'''    static RosterFixture Given(Uuid selected, params DomainEvent[] facts) => RosterFixture.Create(selected, facts);

    static async Task<RosterFixture> ReadRosterAsync(IServiceProvider services)
    {
        var owner = await services.GetRequiredService<IAggregateReader>().HydrateAsync(new PlatformOperatorRoster());
        var state = await PlatformOperatorRosterContent.ReadAsync(services.GetRequiredService<IImmutableContentStore>(), owner);
        return RosterFixture.Restore(Uuid.Empty, [], state, owner);
    }

    /// <summary>Transient test fold: every fixture fact is a real native receipt before the runtime owner sees it.</summary>
    sealed class RosterFixture
    {
        readonly PlatformOperatorRoster _owner;
        readonly AggregateScenario<PlatformOperatorRoster> _scenario;
        public PlatformOperatorAuthorityContent State { get; private set; }
        public RosterFixture Aggregate => this;
        public DomainEvent[] Facts { get; }
        public IReadOnlyList<DomainEvent> PendingEvents => _scenario.PendingEvents.ToArray();
        public ulong Version => _owner.Version;
        public IReadOnlyList<PlatformOperatorAssignmentView> Operators => State.Operators;
        public bool IsOperator(Uuid user) => State.Operators.Any(item => item.UserId == user);
        public Uuid? AssignmentId(Uuid user) => State.Operators.FirstOrDefault(item => item.UserId == user)?.AssignmentId;

        RosterFixture(PlatformOperatorRoster owner, AggregateScenario<PlatformOperatorRoster> scenario,
            PlatformOperatorAuthorityContent state, DomainEvent[] facts)
        {
            _owner = owner;
            _scenario = scenario;
            State = state;
            Facts = facts;
        }

        public static RosterFixture Restore(Uuid selected, DomainEvent[] facts, PlatformOperatorAuthorityContent state,
            PlatformOperatorRoster? hydrated = null)
        {
            var owner = hydrated ?? new PlatformOperatorRoster(selected);
            var scenario = new AggregateScenario<PlatformOperatorRoster>(owner).Given(facts);
            return new(owner, scenario, state, facts);
        }

        public static RosterFixture Create(Uuid selected, DomainEvent[] inputs)
        {
            var state = PlatformOperatorRosterContent.Empty;
            var facts = new List<DomainEvent>();
            var owner = new PlatformOperatorRoster(selected);
            foreach (var input in inputs)
            {
                var mutation = input switch
                {
                    PlatformOperatorRosterSeeded seed => SeedMutation(seed.RosterId, seed.UserIds, seed.Actor, seed.OccurredAt),
                    PlatformOperatorGranted grant => Change(nameof(GrantPlatformOperator), grant.CommandId, grant.ExpectedRevision,
                        grant.ActorUserId, grant.SubjectUserId, Uuid.Empty, grant.Reason, grant.Actor, grant.OccurredAt, grant.ActorDisplay),
                    PlatformOperatorRevoked revoke => Change(nameof(RevokePlatformOperator), revoke.CommandId, revoke.ExpectedRevision,
                        revoke.ActorUserId, revoke.SubjectUserId, revoke.AssignmentId, revoke.Reason, revoke.Actor, revoke.OccurredAt, revoke.ActorDisplay),
                    _ => throw new InvalidOperationException()
                };
                var next = PlatformOperatorRosterRules.Apply(state, mutation);
                Assert.True(next.IsSuccess);
                state = next.Value!;
                facts.Add(DomainEventSeed.Attach(Fact(owner, mutation, state), owner.Id, (ulong)facts.Count + 1));
            }
            return Restore(selected, facts.ToArray(), state);
        }

        public Result Seed(Uuid id, IEnumerable<Uuid> users, ActorAttribution actor, DateTimeOffset at) =>
            Admit(SeedMutation(id, users, actor, at));
        public Result Grant(Uuid id, ulong revision, Uuid actorUserId, Uuid subject, string reason,
            ActorAttribution actor, DateTimeOffset at, string? display = null) => Admit(Change(nameof(GrantPlatformOperator),
            id, revision, actorUserId, subject, Uuid.Empty, reason, actor, at, display));
        public Result Revoke(Uuid id, ulong revision, Uuid actorUserId, Uuid subject, Uuid assignment, string reason,
            ActorAttribution actor, DateTimeOffset at, string? display = null) => Admit(Change(nameof(RevokePlatformOperator),
            id, revision, actorUserId, subject, assignment, reason, actor, at, display));

        Result Admit(PlatformOperatorMutationContent mutation)
        {
            var operation = Provenance(_owner, mutation);
            var binding = _owner.Acceptance.Decide(AcceptedOperationBinding.Of(operation));
            if (binding == NativeAcceptanceDecision.Replayed)
                return Result.Success;
            if (binding == NativeAcceptanceDecision.Conflict)
                return Result.Failure(AcceptedAppendResult.ConflictError);
            var next = PlatformOperatorRosterRules.Apply(State, mutation);
            if (!next.IsSuccess)
                return Result.Failure(next.Error!);
            var result = _owner.Append(Fact(_owner, mutation, next.Value!), _owner.Revision,
                _owner.CommittedStreamPosition, mutation, State, next.Value!);
            if (result.IsSuccess)
                State = next.Value!;
            return result;
        }

        static PlatformOperatorMutationContent SeedMutation(Uuid id, IEnumerable<Uuid> users, ActorAttribution actor,
            DateTimeOffset at) => new(nameof(SeedPlatformOperatorRoster), id, null, Uuid.Empty, Uuid.Empty, Uuid.Empty,
            PlatformOperatorRosterRules.CanonicalUsers(users), string.Empty, actor,
            ActorReference.ForSystemProcess("platform-operator-bootstrap", "Platform operator bootstrap"), at);
        static PlatformOperatorMutationContent Change(string kind, Uuid id, ulong revision, Uuid actorUserId,
            Uuid subject, Uuid assignment, string reason, ActorAttribution actor, DateTimeOffset at, string? display) =>
            new(kind, id, revision, actorUserId, subject, assignment, [], reason.Trim(), actor,
                ActorReference.ForPlatformOperator(actorUserId, string.IsNullOrWhiteSpace(display) ? actorUserId.ToString() : display.Trim()), at);
        static OperationProvenance Provenance(PlatformOperatorRoster owner, PlatformOperatorMutationContent mutation) =>
            OwnerProvenance.For(owner, mutation.CommandId, mutation.CommandKind, mutation.Actor, owner.Id.ToString(),
                mutation.ExpectedRevision, PlatformOperatorRosterContent.IntentDigest(mutation), mutation.AcceptedAt);
        static ImmutableContentRef Reference<T>(T value, string schema) where T : notnull =>
            new(Uuid.CreateVersion4(), ContentDigest.OfJson(value), 2, "application/json", schema);
        static DomainEvent Fact(PlatformOperatorRoster owner, PlatformOperatorMutationContent mutation,
            PlatformOperatorAuthorityContent state) => PlatformOperatorRosterContent.Fact(mutation, Provenance(owner, mutation),
                Reference(mutation, PlatformOperatorRosterContent.ChangeSchema), Reference(state, PlatformOperatorRosterContent.AuthoritySchema),
                new(Uuid.CreateVersion4(), new string('a', 64), 2, "application/json", FirstResponses.Schema),
                Reference(new UnitResult(), UnitResult.Schema), state);
    }

'''+s[end:]
f.write_text(s)
f=p/'test/Compliance.Tests/Features/Tenants/PlatformOperatorTransportTests.cs';s=f.read_text().replace('using Bdgrz.Compliance.Tests.E2E;','using Bdgrz.Compliance.Tests.E2E;\nusing Bdgrz.Compliance.Features.Content;');s=s.replace('Assert.Equal(next, owner.AssignmentId(target));','var authority = await PlatformOperatorRosterContent.ReadAsync(scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), owner);\n        Assert.Equal(next, Assert.Single(authority.Operators, item => item.UserId == target).AssignmentId);');f.write_text(s)
red='''    [Fact]
    public async Task ShouldKeepAcceptingFactBoundedGivenLargeLegalBootstrapRoster()
    {
        // Arrange
        await using var provider = Services();
        var users = Enumerable.Range(0, 4096).Select(_ => Uuid.CreateVersion4()).ToArray();
        await using var scope = provider.CreateAsyncScope();

        // Act
        var accepted = await scope.ServiceProvider.GetRequiredService<IRequestBus>().SendAsync(
            new SeedPlatformOperatorRoster(PlatformOperatorRoster.CreationId, users), RequestActor.System);
        var facts = new List<DomainEvent>();
        var stream = new PlatformOperatorRoster().Stream;
        await foreach (var record in provider.GetRequiredService<IEventStore>().ReadAsync(stream, 0))
            facts.Add(record.Event);

        // Assert
        Assert.True(accepted.IsSuccess);
        var fact = Assert.IsType<PlatformOperatorRosterSeeded>(Assert.Single(facts));
        var bytes = System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(fact, ComplianceCoreJsonContext.Default.PlatformOperatorRosterSeeded);
        Assert.True(bytes.Length <= 48 * 1024, $"The legal bootstrap roster emitted {bytes.Length} event payload bytes.");
    }

'''
f=p/'test/Compliance.Tests/Features/Tenants/PlatformOperatorRosterTests.cs';s=f.read_text().replace('    static ServiceProvider Services(',red+'    static ServiceProvider Services(')
s=s.replace('static ServiceProvider Services(ExistingUsers? users = null, IEventStore? store = null)','static ServiceProvider Services(ExistingUsers? users = null, IEventStore? store = null, IImmutableContentStore? content = null)').replace('services.AddSingleton<IImmutableContentStore>(new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient())));','services.AddSingleton<IImmutableContentStore>(content ?? new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient())));')
extra='''    [Fact]
    public async Task ShouldRetainOriginalNativeUnitResultGivenExactRetryAfterLaterProgress()
    {
        // Arrange
        await using var provider = Services();
        await SeedAsync(provider, First);
        await using var scope = provider.CreateAsyncScope();
        var bus = scope.ServiceProvider.GetRequiredService<IRequestBus>();
        var request = new GrantPlatformOperator(Second, " Cover operations ", Uuid.CreateVersion4(), 1);
        Assert.True((await bus.SendAsync(request, Actor(First))).IsSuccess);
        var original = await scope.ServiceProvider.GetRequiredService<IAggregateReader>()
            .HydrateAsync(new PlatformOperatorRoster(request.CommandId));
        var accepted = Assert.IsType<PlatformOperatorGranted>(original.Acceptance.SelectedFact);
        var content = provider.GetRequiredService<IImmutableContentStore>();
        var descriptor = await FirstResponses.ReplayAsync(content, "bdgrz", accepted.FirstResponse!);
        var body = Assert.IsType<StandardResponseBody>(descriptor.Body);
        var bytes = await content.ReadVerifiedAsync("bdgrz", body.Content);
        Assert.True((await bus.SendAsync(new RevokePlatformOperator(Second, "Ended", Uuid.CreateVersion4(), 2,
            request.CommandId), Actor(First))).IsSuccess);
        var displayChanged = Actor(First);
        ((ClaimsIdentity)displayChanged.Identity!).AddClaim(new Claim("name", "Updated profile"));

        // Act
        var retry = await bus.SendAsync(request with { Reason = "Cover operations" }, displayChanged);
        var current = await scope.ServiceProvider.GetRequiredService<IAggregateReader>()
            .HydrateAsync(new PlatformOperatorRoster(request.CommandId));
        var history = await PlatformOperatorRosterContent.ReadHistoryAsync(content,
            provider.GetRequiredService<IEventStore>(), current);

        // Assert
        Assert.True(retry.IsSuccess);
        Assert.Equal(accepted.FirstResponse, ((IPlatformOperatorFact)current.Acceptance.SelectedFact!).FirstResponse);
        Assert.Equal(200, descriptor.HttpStatus);
        Assert.Equal(UnitResult.Schema, descriptor.ResultSchema);
        Assert.Equal(accepted.OperationResult, body.Content);
        Assert.Equal("{}", System.Text.Encoding.UTF8.GetString(bytes.Span));
        Assert.Equal(3, history.Count);
        Assert.Equal(accepted.Operation.Actor, history[1].Actor);
        Assert.False((await ReadRosterAsync(scope.ServiceProvider)).IsOperator(Second));
    }

    [Theory]
    [InlineData("actor")]
    [InlineData("issuer")]
    [InlineData("subject")]
    [InlineData("reason")]
    [InlineData("revision")]
    [InlineData("kind")]
    public async Task ShouldConflictGivenChangedNativeBindingUnderAcceptedGrantIdentity(string change)
    {
        // Arrange
        await using var provider = Services();
        await SeedAsync(provider, First, Third);
        await using var scope = provider.CreateAsyncScope();
        var bus = scope.ServiceProvider.GetRequiredService<IRequestBus>();
        var request = new GrantPlatformOperator(Second, "Cover operations", Uuid.CreateVersion4(), 1);
        Assert.True((await bus.SendAsync(request, Actor(First))).IsSuccess);
        var actor = change == "actor" ? Actor(Third) : change == "issuer" ? new ClaimsPrincipal(new ClaimsIdentity(
            [new Claim("iss", "bdgrz"), new Claim("sub", First.ToString(), ClaimValueTypes.String, "other")], "BdgrzSession")) : Actor(First);
        IRequest candidate = change == "kind" ? new RevokePlatformOperator(Second, "Cover operations", request.CommandId, 1, request.CommandId) :
            request with { UserId = change == "subject" ? Uuid.CreateVersion4() : Second,
                Reason = change == "reason" ? "Changed" : request.Reason, ExpectedRevision = change == "revision" ? 2UL : 1 };

        // Act
        var result = await bus.SendAsync(candidate, actor);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error!.Kind);
        Assert.Equal(2UL, (await ReadRosterAsync(scope.ServiceProvider)).Version);
    }

    [Theory]
    [InlineData(PlatformOperatorRosterContent.AuthoritySchema)]
    [InlineData(FirstResponses.Schema)]
    [InlineData(UnitResult.Schema)]
    public async Task ShouldFailClosedGivenUnavailableOriginalAuthorityOrResponseOnRetry(string schema)
    {
        // Arrange
        var content = new RejectingContent(new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient())));
        await using var provider = Services(content: content);
        await SeedAsync(provider, First);
        await using var scope = provider.CreateAsyncScope();
        var bus = scope.ServiceProvider.GetRequiredService<IRequestBus>();
        var request = new GrantPlatformOperator(Second, "Cover operations", Uuid.CreateVersion4(), 1);
        Assert.True((await bus.SendAsync(request, Actor(First))).IsSuccess);
        content.RejectedSchema = schema;

        // Act
        // Assert
        await Assert.ThrowsAsync<ImmutableContentIntegrityException>(async () => await bus.SendAsync(request, Actor(First)));
        var owner = await scope.ServiceProvider.GetRequiredService<IAggregateReader>().HydrateAsync(new PlatformOperatorRoster());
        Assert.Equal(2UL, owner.Revision);
    }

    [Fact]
    public async Task ShouldRejectChangedPreparedAuthorityGivenAnOtherwiseValidNativeAppend()
    {
        // Arrange
        await using var provider = Services();
        await SeedAsync(provider, First, Third);
        await using var scope = provider.CreateAsyncScope();
        var owner = await scope.ServiceProvider.GetRequiredService<IAggregateReader>().HydrateAsync(new PlatformOperatorRoster());
        var content = provider.GetRequiredService<IImmutableContentStore>();
        var before = await PlatformOperatorRosterContent.ReadAsync(content, owner);
        var id = Uuid.CreateVersion4();
        var mutation = new PlatformOperatorMutationContent(nameof(GrantPlatformOperator), id, 1, First, Second, Uuid.Empty, [],
            "Cover operations", Provenance(First), ActorReference.ForPlatformOperator(First, "One"), Now);
        var after = PlatformOperatorRosterRules.Apply(before, mutation).Value!;
        var authority = await content.WriteJsonAsync("bdgrz", Uuid.CreateVersion4(), PlatformOperatorRosterContent.AuthoritySchema, after);
        var change = await content.WriteJsonAsync("bdgrz", Uuid.CreateVersion4(), PlatformOperatorRosterContent.ChangeSchema, mutation);
        var response = await UnitResponses.FreezeAsync(content, "bdgrz");
        var first = await FirstResponses.FreezeAsync(content, "bdgrz", response);
        var operation = OwnerProvenance.For(owner, id, mutation.CommandKind, mutation.Actor, owner.Id.ToString(), 1,
            PlatformOperatorRosterContent.IntentDigest(mutation), Now);
        var fact = PlatformOperatorRosterContent.Fact(mutation, operation, change, authority, first,
            ((StandardResponseBody)response.Body).Content, after);
        var changedBefore = before with { Operators = [before.Operators[0]] };

        // Act
        var result = owner.Append(fact, owner.Revision, owner.CommittedStreamPosition, mutation, changedBefore, after);

        // Assert
        Assert.Equal(RequestErrorKind.Validation, result.Error!.Kind);
        Assert.Equal(1UL, owner.Revision);
    }

    sealed class RejectingContent(IImmutableContentStore inner) : IImmutableContentStore
    {
        public string? RejectedSchema { get; set; }
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema,
            string mediaType, ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default) =>
            reference.Schema == RejectedSchema ? throw new ImmutableContentIntegrityException("Unavailable or corrupt immutable source.") :
                inner.ReadVerifiedAsync(realm, reference, ct);
    }

'''
s=s.replace('    static ServiceProvider Services(',extra+'    static ServiceProvider Services(')
f.write_text(s)
# A red-only source applies cleanly to the real captured old API; it neither references new symbols nor changes its helper.
f=p.parent/'red'/'test/Compliance.Tests/Features/Tenants/PlatformOperatorRosterTests.cs';f.parent.mkdir(parents=True,exist_ok=True)
base=(p.parent/'before'/'test/Compliance.Tests/Features/Tenants/PlatformOperatorRosterTests.cs').read_text();f.write_text(base.replace('    static ServiceProvider Services(',red+'    static ServiceProvider Services('))
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRoster.cs';s=f.read_text().replace('using Bdgrz.Compliance.Features.Kernel;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;').replace('PlatformOperatorAuthorityContent after)\n    {','PlatformOperatorAuthorityContent after, FirstResponseDescriptor response)\n    {').replace('Require(fact.Operation.AuthoredIntentSha256 == PlatformOperatorRosterContent.IntentDigest(mutation));','''Require(fact.Operation.AuthoredIntentSha256 == PlatformOperatorRosterContent.IntentDigest(mutation));
            Require(response.HttpStatus == 200 && response.ContentType == "application/json" && response.ResultSchema == UnitResult.Schema &&
                response.Body is StandardResponseBody body && body.Content == fact.OperationResult &&
                PlatformOperatorRosterContent.Matches(body.Content, new UnitResult(), UnitResult.Schema) &&
                PlatformOperatorRosterContent.Matches(fact.FirstResponse!, response, FirstResponses.Schema));''').replace('catch (InvalidOperationException)','catch (Exception exception) when (exception is InvalidOperationException or ImmutableContentIntegrityException)');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRosterContent.cs';s=f.read_text().replace('using Bdgrz.Compliance.Features.Content;','using System.Text.Json;\nusing Bdgrz.Compliance.Features.Content;').replace('Reference(reference, schema) && reference.Sha256 == ContentDigest.OfJson(value);','''Reference(reference, schema) && reference.Sha256 == ContentDigest.OfJson(value) &&
        reference.Bytes == JsonSerializer.SerializeToUtf8Bytes(value,
            ComplianceCoreJsonContext.Default.GetTypeInfo(typeof(T))!).Length;''');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRosterOperations.cs';s=f.read_text().replace('ImmutableContentRef? result = null;','ImmutableContentRef? result = null;\n        FirstResponseDescriptor? descriptor = null;').replace('var response = await UnitResponses.FreezeAsync(content, PlatformOperatorRosterContent.Realm, token).ConfigureAwait(false);','descriptor = await UnitResponses.FreezeAsync(content, PlatformOperatorRosterContent.Realm, token).ConfigureAwait(false);').replace('result = ((StandardResponseBody)response.Body).Content;','result = ((StandardResponseBody)descriptor.Body).Content;').replace('Result<FirstResponseDescriptor>.Success(response);','Result<FirstResponseDescriptor>.Success(descriptor);').replace('first, result!, after!), revision, position, mutation, before!, after!))','first, result!, after!), revision, position, mutation, before!, after!, descriptor!))');f.write_text(s)
f=p/'test/Compliance.Tests/Features/Tenants/PlatformOperatorRosterTests.cs';s=f.read_text().replace('new Claim("name", "Updated profile")','new Claim("email", "updated@example.test")').replace('var scenario = new AggregateScenario<PlatformOperatorRoster>(owner).Given(facts);','var scenario = new AggregateScenario<PlatformOperatorRoster>(owner);\n            if (hydrated is null)\n                scenario.Given(facts);').replace('mutation, changedBefore, after);','mutation, changedBefore, after, response);').replace('_owner.CommittedStreamPosition, mutation, State, next.Value!);','_owner.CommittedStreamPosition, mutation, State, next.Value!, Response());').replace('new(Uuid.CreateVersion4(), ContentDigest.OfJson(value), 2, "application/json", schema);','new(Uuid.CreateVersion4(), ContentDigest.OfJson(value),\n                System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(value, ComplianceCoreJsonContext.Default.GetTypeInfo(typeof(T))!).Length,\n                "application/json", schema);').replace('new(Uuid.CreateVersion4(), new string(\'a\', 64), 2, "application/json", FirstResponses.Schema),\n                Reference(new UnitResult(), UnitResult.Schema), state);','Reference(Response(), FirstResponses.Schema), UnitReference, state);').replace('        static DomainEvent Fact(PlatformOperatorRoster owner,','''        static readonly ImmutableContentRef UnitReference = Reference(new UnitResult(), UnitResult.Schema);
        static FirstResponseDescriptor Response() => new(200, "application/json", UnitResult.Schema, new StandardResponseBody(UnitReference));
        static DomainEvent Fact(PlatformOperatorRoster owner,''');f.write_text(s)
# Migrate every compiled E2E consumer as well; this package does not run broker qualification.
path='test/Compliance.Tests/E2E/OperatorPortfolioE2ETests.cs'
source=Path('/Users/jrepanich/Code/bdgrz/compliance-core')/path
baseline=p.parent/'before'/path
if not baseline.exists():
 baseline.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,baseline)
s=baseline.read_text().replace('using Bdgrz.Compliance;','using Bdgrz.Compliance;\nusing Bdgrz.Compliance.Features.Content;')
s=s.replace('if (roster.IsOperator(operatorId))','if ((await PlatformOperatorRosterContent.ReadAsync(scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), roster)).Operators.Any(item => item.UserId == operatorId))')
s=s.replace('''                    Assert.Fail($"The worker did not read the operator seed; API initialized={apiRoster.IsInitialized}, " +
                                $"API operator={apiRoster.IsOperator(operatorId)}.");''','''                    var apiAuthority = await PlatformOperatorRosterContent.ReadAsync(apiScope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), apiRoster);
                    Assert.Fail($"The worker did not read the operator seed; API initialized={apiRoster.IsInitialized}, " +
                                $"API operator={apiAuthority.Operators.Any(item => item.UserId == operatorId)}.");''')
s=s.replace('Assert.True(roster.IsOperator(ordinaryId));','var authority = await PlatformOperatorRosterContent.ReadAsync(scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), roster);\n                Assert.Contains(authority.Operators, item => item.UserId == ordinaryId);')
write(path,s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRosterContent.cs';s=f.read_text().replace('''        return mutation;
    }

    /// <summary>Reads only''','''        var response = await FirstResponses.ReplayAsync(content, Realm, fact.FirstResponse!, ct).ConfigureAwait(false);
        if (response.HttpStatus != 200 || response.ContentType != "application/json" || response.ResultSchema != UnitResult.Schema ||
            response.Body is not StandardResponseBody body || body.Content != fact.OperationResult ||
            !Matches(fact.OperationResult!, new UnitResult(), UnitResult.Schema))
            throw new ImmutableContentIntegrityException("The roster receipt has another original Unit result or descriptor.");
        await content.ReadJsonAsync<UnitResult>(Realm, body.Content, ct).ConfigureAwait(false);
        return mutation;
    }

    /// <summary>Reads only''');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRosterOperations.cs';s=f.read_text().replace('response.Body is not StandardResponseBody body || body.Content.Schema != UnitResult.Schema)','response.Body is not StandardResponseBody body ||\n            !PlatformOperatorRosterContent.Matches(body.Content, new UnitResult(), UnitResult.Schema))');f.write_text(s)
f=p/'test/Compliance.Tests/Features/Tenants/PlatformOperatorRosterTests.cs';s=f.read_text().replace('    static ServiceProvider Services(','''    [Fact]
    public void ShouldFailClosedGivenRetainedLegacyRosterWithoutTrustedNativeAuthority()
    {
        // Arrange
        var owner = new PlatformOperatorRoster();
        var legacy = DomainEventSeed.Attach(Seeded(First), owner.Id, 1);

        // Act
        // Assert
        Assert.Throws<InvalidOperationException>(() => new AggregateScenario<PlatformOperatorRoster>(owner).Given(legacy));
    }

    static ServiceProvider Services(''');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRosterContent.cs';s=f.read_text().replace('''        var changes = new List<PlatformOperatorMutationContent>();
        var state = Empty;''','''        var changes = new List<PlatformOperatorMutationContent>();
        if (owner.Revision == 0)
            return changes;
        var state = Empty;''').replace('state.Operators.Any(static item => item.UserId == Uuid.Empty || item.AssignmentId == Uuid.Empty)','state.Operators.Any(static item => item is null || item.UserId == Uuid.Empty || item.AssignmentId == Uuid.Empty)').replace('reference.Bytes > 0 && reference.Sha256.Length == 64','reference.Bytes > 0 && reference.Sha256 is { Length: 64 }');f.write_text(s)
f=p/'src/Compliance.Core/Features/Tenants/PlatformOperatorRoster.cs';s=f.read_text().replace('operation.AcceptedAt != default && operation.AuthoredIntentSha256.Length == 64','operation.AcceptedAt != default && operation.AuthoredIntentSha256 is { Length: 64 }');f.write_text(s)
