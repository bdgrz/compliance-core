from pathlib import Path
p=Path('/tmp/compliance-risk-governance-prepared/work/src/Compliance.Core/Features/Risks')
for name,message in [('AssignRiskOwnerHandler','The exact risk owner source cannot be verified.'),('RaiseRiskReassessmentTriggersHandler','The exact reassessment source cannot be verified.')]:
 f=p/(name+'.cs');s=f.read_text();a=s.index('                async (owner, token) =>\n                {')+len('                async (owner, token) =>\n                {');b=s.index('\n                }, (owner, first)',a)
 body=s[a:b]
 s=s[:a]+'''\n                    try
                    {'''+''.join('\n    '+line for line in body.splitlines() if line)+'''
                    }
                    catch (ImmutableContentIntegrityException error)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "'''+message+'''", error is ImmutableContentUnavailableException));
                    }'''+s[b:];f.write_text(s)
