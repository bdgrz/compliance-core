from pathlib import Path
import shutil
p=Path('/tmp/compliance-risk-governance-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');method=Path('/tmp/compliance-risk-method-prepared/work');risk=Path('/tmp/compliance-risk-native-prepared/work')
paths=['src/Compliance.Core/Features/Risks/RiskGovernance.cs','src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs','src/Compliance.Core/Features/Risks/AssignRiskOwnerHandler.cs','src/Compliance.Core/Features/Risks/RaiseRiskReassessmentTriggersHandler.cs','src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs','src/Compliance.Common/Features/Risks/RiskOwnerAssigned.cs','src/Compliance.Common/Features/Risks/RiskReassessmentTriggered.cs','test/Compliance.Tests/Testing/RiskSeeds.cs','test/Compliance.Tests/Features/Risks/RiskOwnerBoundaryTests.cs']
for rel in paths:
 origin=method/rel if (method/rel).exists() else risk/rel if (risk/rel).exists() else repo/rel
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,f)
q=p/'work/src/Compliance.Core/Features/Risks/RiskGovernance.cs';s=q.read_text()
s=s.replace('''    readonly List<RiskOwnerAssigned> _owners = [];
    readonly List<RiskReassessmentTriggered> _triggers = [];
    readonly List<DomainEvent> _facts = [];''','''    RiskOwnerAssigned? _owner;
    DomainEvent? _latest;''')
s=s.replace('''    public RiskOwnerAssigned? Owner => _owners.Count == 0 ? null : _owners[^1];''','''    public RiskOwnerAssigned? Owner => _owner;
    public DomainEvent? Latest => _latest;
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;''')
a=s.index('    /// <summary>Every reassessment trigger');b=s.index('    /// <summary>Checks that the owner can be assigned',a);s=s[:a]+s[b:]
a=s.index('    /// <summary>Checks that the trigger can be raised');b=s.index('    /// <summary>Assigns the owner',a);s=s[:a]+'''    /// <summary>Fences a source-history decision against the exact command owner cut it observed.</summary>
    public Result PrepareTrigger(long expectedRevision, ulong expectedPhysicalPosition) =>
        expectedRevision == Revision && expectedPhysicalPosition == CommittedStreamPosition
            ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact risk governance cut changed; retry trigger admission.", true));

'''+s[b:]
s=s.replace('''        ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(triggerContent);''','''        ImmutableContentRef firstResponse, ImmutableContentRef operationResult,
        long expectedRevision, ulong expectedPhysicalPosition)
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(triggerContent);''')
s=s.replace('operation.Owner != Stream || triggerContent.ContentId != TriggerContentId(triggerId)', 'operation.Owner != Stream || triggerId == Uuid.Empty').replace('"A trigger is a root operation of its own risk governance stored under its trigger identity."','"A trigger requires its exact risk governance owner and semantic identity."').replace('var prepared = PrepareTrigger(triggerId);','var prepared = PrepareTrigger(expectedRevision, expectedPhysicalPosition);')
s=s.replace('_owners.Add(ev);','_owner = ev;').replace('_triggers.Add(ev);','')
s=s.replace('''            operation.Owner != Stream)''','''            operation.Owner != Stream || operation.FirstOwner != Stream ||
            !NativeOwnerHistory.IsOwnRoot(this, operation,
                operation.CommandKind == nameof(AssignRiskOwner) ? nameof(AssignRiskOwner) : nameof(RaiseRiskReassessmentTriggers),
                operation.CommandKind == nameof(AssignRiskOwner) ? (ulong)_revision : null) ||
            operation.CommandKind is not (nameof(AssignRiskOwner) or nameof(RaiseRiskReassessmentTriggers)))''')
s=s.replace('''        _facts.Add(fact);''','''        _latest = fact;''')
# Native fact-specific schemas and command kinds must not be interchangeable.
s=s.replace('''        Acceptance.Observe(ev);
        EnsureNext(ev.TenantId, ev.ProgramId, ev.RiskId, ev.Revision, ev.Operation);
        _owner = ev;''','''        if (ev.Operation.CommandKind != nameof(AssignRiskOwner) || ev.OwnerContent.Schema != RiskContent.OwnerSchema ||
            ev.FirstResponse is null || ev.OperationResult is null || ev.Operation.Actor.Kind != "member")
            throw new InvalidOperationException("The owner assignment has another exact native kind or content schema.");
        EnsureNext(ev.TenantId, ev.ProgramId, ev.RiskId, ev.Revision, ev.Operation);
        Acceptance.Observe(ev);
        _owner = ev;''')
s=s.replace('''        Acceptance.Observe(ev);
        EnsureNext(ev.TenantId, ev.ProgramId, ev.RiskId, ev.Revision, ev.Operation);
        
        Advance(ev);''','''        if (ev.Operation.CommandKind != nameof(RaiseRiskReassessmentTriggers) || ev.TriggerContent.Schema != RiskContent.TriggerSchema ||
            ev.FirstResponse is null || ev.OperationResult is null || ev.Operation.Actor.Kind != "system_process")
            throw new InvalidOperationException("The reassessment trigger has another exact native kind or content schema.");
        EnsureNext(ev.TenantId, ev.ProgramId, ev.RiskId, ev.Revision, ev.Operation);
        Acceptance.Observe(ev);
        Advance(ev);''')
q.write_text(s)
for name in ['RiskOwnerAssigned','RiskReassessmentTriggered']:
 q=p/'work/src/Compliance.Common/Features/Risks'/f'{name}.cs';s=q.read_text().replace(', 2)]',', 1)]');q.write_text(s)
q=p/'work/test/Compliance.Tests/Testing/RiskSeeds.cs';s=q.read_text();s=s.replace('''var operation = Operation(owner, Uuid.CreateVersion4(), (ulong)owner.Revision, actor, at, nameof(AssignRiskOwner), view);''','''var command = Uuid.CreateVersion4();
        var request = new AssignRiskOwner(command, tenant, program, risk, owner.Revision, person, rationale);
        var operation = RootOperation.Provenance(command, nameof(AssignRiskOwner), owner.Stream, actor,
            owner.Revision, AuthoredIntentDigest.Compute(request), at) with { FirstOwner = owner.Stream };''');q.write_text(s)
