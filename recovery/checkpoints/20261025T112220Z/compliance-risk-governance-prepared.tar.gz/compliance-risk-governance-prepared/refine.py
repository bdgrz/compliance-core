from pathlib import Path
import shutil
p=Path('/tmp/compliance-risk-governance-prepared');risk=Path('/tmp/compliance-risk-native-prepared/work')
rel='src/Compliance.Core/Features/Risks/GetRiskGovernanceHandler.cs'
for part in ['base','work']:
 f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(risk/rel,f)
f=p/'work'/rel;s=f.read_text().replace('''$"The risk governance content cannot be verified yet: {exception.Message}", true''','''"The exact risk governance content cannot be verified.", exception is ImmutableContentUnavailableException''');f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Risks/AssignRiskOwnerHandler.cs';s=f.read_text().replace('''request.CommandId == Uuid.Empty || request.ExpectedRevision < 0''','''request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty || request.RiskId == Uuid.Empty ||
            request.CommandId == Uuid.Empty || request.ExpectedRevision < 0''');f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Risks/RaiseRiskReassessmentTriggersHandler.cs';s=f.read_text().replace('''request.CommandId == Uuid.Empty || request.RiskId == Uuid.Empty || request.RaisedAt == default''','''request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty ||
            request.CommandId == Uuid.Empty || request.RiskId == Uuid.Empty || request.RaisedAt == default''');f.write_text(s)
# Validate header reference binding without reading body data in the reducer.
f=p/'work/src/Compliance.Core/Features/Risks/RiskGovernance.cs';s=f.read_text().replace('''ev.FirstResponse is null || ev.OperationResult is null || ev.Operation.Actor.Kind != "member")''','''ev.FirstResponse is null || ev.OperationResult is null || ev.Operation.Actor.Kind != "member" ||
            !Uuid.TryParse(ev.Operation.Actor.Id, out var member) || member == Uuid.Empty)''');f.write_text(s)
