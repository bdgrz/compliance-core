from pathlib import Path
p=Path('/tmp/compliance-risk-governance-prepared');f=p/'work/test/Compliance.Tests/Features/Risks/RiskGovernanceRetryTests.cs';s=f.read_text().replace('using Bdgrz.Compliance.Features.Content;','using System.Security.Claims;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;')
marker='    [Fact]\n    public async Task ShouldRaiseOneSemanticTrigger'
case='''    [Fact]
    public async Task ShouldReplayOriginalAssignmentGivenRiskSourceCannotBeReselected()
    {
        // Arrange
        var fixture = await RiskGovernanceHandlerTests.Fixture.CreateAsync("accept");
        await using var provider = fixture.Provider;
        var person = await fixture.SeedPersonAsync(fixture.ApproverUserId);
        await using var scope = provider.CreateAsyncScope();
        var inner = scope.ServiceProvider.GetRequiredService<IAggregateReader>();
        var reader = new UnavailableRiskReader(inner);
        var content = scope.ServiceProvider.GetRequiredService<IImmutableContentStore>();
        var executor = scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();
        var handler = new AssignRiskOwnerHandler(new NativeOperationExecutor(reader, executor, content), reader,
            content, TimeProvider.System);
        var request = new AssignRiskOwner(Uuid.CreateVersion4(), fixture.TenantId, fixture.ProgramId, fixture.RiskId,
            0, person, "Owns the recorded risk.");
        var actor = new ClaimsPrincipal(new ClaimsIdentity([new Claim("iss", "bdgrz"),
            new Claim("sub", fixture.AssessorUserId.ToString()), new Claim("email", "owner@example.test")], "BdgrzSession"));
        var first = await handler.HandleAsync(new RequestContext<AssignRiskOwner>(request, actor), CancellationToken.None);
        Assert.True(first.IsSuccess, first.Error?.Message);
        reader.Unavailable = true;

        // Act
        var replay = await handler.HandleAsync(new RequestContext<AssignRiskOwner>(request, actor), CancellationToken.None);

        // Assert
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(0, reader.UnavailableReads);
        Assert.Equal(1, (await inner.HydrateAsync(new RiskGovernance(fixture.TenantId, fixture.ProgramId, fixture.RiskId))).Revision);
    }

'''
s=s.replace(marker,case+marker)
pos=s.rfind('\n}')
helper='''
    sealed class UnavailableRiskReader(IAggregateReader inner) : IAggregateReader
    {
        public bool Unavailable { get; set; }
        public int UnavailableReads { get; private set; }
        public ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate, CancellationToken ct = default) where TAggregate : Aggregate
        {
            if (Unavailable && aggregate is RiskDraft)
            {
                UnavailableReads++;
                return ValueTask.FromResult(aggregate);
            }
            return inner.HydrateAsync(aggregate, ct);
        }
    }
'''
s=s[:pos]+helper+s[pos:];f.write_text(s);(p/'behavioral-red-source.cs').write_text(s)
