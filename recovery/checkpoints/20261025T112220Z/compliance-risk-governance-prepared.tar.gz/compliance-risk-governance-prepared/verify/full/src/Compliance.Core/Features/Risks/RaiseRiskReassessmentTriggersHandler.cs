using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Remediation;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Admits one semantic trigger after verified cut-scoped deduplication; identical accepted commands replay first.</summary>
public sealed class RaiseRiskReassessmentTriggersHandler(NativeOperationExecutor operations, IAggregateReader reader,
    IImmutableContentStore content, TimeProvider clock, RiskGovernanceReader history) : IRequestHandler<RaiseRiskReassessmentTriggers>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<RaiseRiskReassessmentTriggers> context, CancellationToken ct)
    {
        var request = context.Request;
        if (request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty ||
            request.CommandId == Uuid.Empty || request.RiskId == Uuid.Empty || request.RaisedAt == default ||
            request.TriggerKind is not (RiskStates.MethodChanged or RiskStates.BoundaryChanged) ||
            string.IsNullOrWhiteSpace(request.SourceReference) || request.SourceReference.Length > 4000)
            return Result.Failure(new RequestError(RequestErrorKind.Validation,
                "A reassessment trigger requires its exact command, risk, kind, source and source time."));
        var triggerId = RiskGovernance.TriggerIdFor(request.ProgramId, request.RiskId, request.TriggerKind, request.SourceReference);
        var workload = request.TriggerKind == RiskStates.MethodChanged ? RiskMethodReassessmentReactor.WorkloadName : BoundaryRiskReassessmentReactor.WorkloadName;
        var stream = new RiskGovernance(request.TenantId, request.ProgramId, request.RiskId).Stream;
        var provenance = FindingContent.Provenance(request.CommandId, nameof(RaiseRiskReassessmentTriggers), stream,
            ActorReference.ForSystemProcess("reactor:" + workload, workload), null, FindingCommands.Digest(request), clock.GetUtcNow())
            with { FirstOwner = stream };
        var noChange = new RequestError(RequestErrorKind.Conflict, "The semantic reassessment obligation already exists or no longer applies.");
        ImmutableContentRef? triggerContent = null;
        ImmutableContentRef? result = null;
        long revision = 0;
        ulong physical = 0;
        try
        {
            var outcome = await operations.ExecuteAsync(new NativeOperation<RiskGovernance>(AcceptedOperationBinding.Of(provenance),
                () => new RiskGovernance(request.TenantId, request.ProgramId, request.RiskId, request.CommandId), owner => owner.Acceptance,
                async (owner, token) =>
                {
                    try
                    {
                        if (await history.FindTriggerAsync(owner, triggerId, token).ConfigureAwait(false) is not null)
                            return Result<FirstResponseDescriptor>.Failure(noChange);
                        var risk = await RiskOwnerResolution.RequireRiskAsync(reader, request.TenantId, request.ProgramId, request.RiskId, token).ConfigureAwait(false);
                        if (!risk.IsSuccess)
                            return Result<FirstResponseDescriptor>.Failure(risk.Error!);
                        var evaluation = await reader.HydrateAsync(new RiskEvaluation(request.TenantId, request.RiskId), token).ConfigureAwait(false);
                        if (evaluation.Header?.InherentMethodVersionId is not { } inherent || request.MethodVersionId is { } method && inherent == method)
                            return Result<FirstResponseDescriptor>.Failure(noChange);
                        triggerContent = await FindingContent.WriteAsync(content, request.TenantId, RiskContent.TriggerSchema,
                            new RiskReassessmentTriggerView(triggerId, request.RiskId, request.TriggerKind, request.SourceReference, request.RaisedAt), token).ConfigureAwait(false);
                        var frozen = await RiskCommands.FreezeUnitAsync(content, request.TenantId, token).ConfigureAwait(false);
                        result = frozen.Result;
                        revision = owner.Revision;
                        physical = owner.CommittedStreamPosition;
                        return Result<FirstResponseDescriptor>.Success(frozen.Response);
                    }
                    catch (ImmutableContentIntegrityException error)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The exact reassessment source cannot be verified.", error is ImmutableContentUnavailableException));
                    }
                }, (owner, first) => owner.RaiseTrigger(provenance, triggerId, triggerContent!, first, result!, revision, physical)), context, ct).ConfigureAwait(false);
            // The executor rechecked exact acceptance/collision before exposing this existing semantic no-op.
            if (!outcome.IsSuccess && ReferenceEquals(outcome.Error, noChange))
                return Result.Success;
            return await RiskCommands.UnitAsync(content, request.TenantId, outcome, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact reassessment trigger history cannot be verified.", error is ImmutableContentUnavailableException));
        }
    }
}
