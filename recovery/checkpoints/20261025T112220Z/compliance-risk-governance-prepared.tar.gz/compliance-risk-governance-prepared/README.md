# RiskGovernance compact owner and native admission: stage 2

Frozen metadata: `handoff.json`. Twelve paths: eight owning source files and four tests/helpers. Depends on frozen RiskMethod36 and its Risk109/source-bytes6/NativeOwnerHistory predecessors. No main edits, runtime/build/format, git/Jev calls or new issues were performed by this agent.

## RED and integration

Apply `behavioral-red.patch` first to the old API and run `behavioral-red-filter.txt`. It has two real behavioral counterexamples: an exact accepted owner retry currently rereads a now-unavailable risk source and returns NotFound; a deterministic orphan trigger blob currently prevents the first actual semantic trigger from ever being admitted when its bytes differ. Both tests use existing producer/reader APIs. Apply `green-after-red.patch` afterward; full, split and RED/green reconstruction match all twelve final SHA256s. Direct `implementation.patch` plus `tests.patch` is equivalent. There are no DI/JSON/HTTP map additions; the Raise handler adds the existing RiskGovernanceReader as its fifth constructor dependency.

## State and protocol

RiskGovernance keeps its logical revision, latest owner assignment, latest native fact and selected NativeAcceptance. It retains no owner history, trigger list, fact list, semantic-id dictionary or aggregate.Current shim. ReadGovernanceFactsAsync freezes the hydrated owner's physical/native cut through the common NativeOwnerHistory, verifies exact risk scope/predecessors/latest fact, and composes history outside the command owner. Trigger lookup reads verified immutable semantic identities at that exact cut. Current owner authority remains one bounded immutable reference.

AssignRiskOwner resolves exact acceptance before selecting mutable risk/person/current-owner state. All gate, source, validation, body publication and typed Unit200 result freezing are in native async preparation. Every new fact carries explicit FirstOwner and original actor/time/gate/intent/result. Source absence is transient, corruption permanent; expected prepare failures return through the executor's acceptance recheck. The existing assignment and SoD business rules remain intact, including recorded workforce person and snapshotted correlation.

RaiseRiskReassessmentTriggers retains the trusted system-only existing contract and exact semantic identity (risk/kind/source reference). It resolves accepted command replay first, checks verified source-cut semantic history, and fences a new append with both logical revision and physical tail. Fresh verified content ids prevent orphan or competing pre-admission bytes from becoming a permanent liveness dependency. The original effective RaisedAt is preserved. A second trusted source for an already present semantic trigger remains the existing successful business no-op, after the executor rechecks acceptance/collision; it does not append another trigger or pretend to create a second durable accepting fact. No new public no-op lookup, callback, global binding or permit protocol is invented. Existing bare/global operation qualification remains unchanged.

The two actual facts retain every selected field and content schema, with exact final catalog discriminator versions 1. Latest member/system actor, first/affected/revision owner, command kind and predecessor are checked by the reducer; complete owner and trigger bodies are verified during read composition. There is no legacy v2 conversion/dual read. Pre-release old histories require deliberate disposal or separately selected migration; no persisted old history qualification is claimed.

## Consumers and tests

The source contributor consumes verified history outside the compact owner and preserves authenticated receipt selection and the separate physical business-byte envelope. Existing RiskGovernanceReader current/public/query composition uses real immutable owner/trigger bodies; GetRiskGovernance now distinguishes unavailable from corrupt content. Other treatment line/action branches remain unchanged for their subsequent slices. Shared RiskSeeds changes only owner assignment arrangement to real initial RootOperation with exact authored request and explicit FirstOwner; it leaves other family's helpers intact.

Twelve existing acceptance names remain, with no assertion reduction. Six new rows cover the two old-API failures, 24 semantic triggers followed by owner assignment/read composition, an actual changed-cut append fence, and missing/corrupt query classification. Twelve C# parses and sixteen relevant explicit constructor checks pass. Exact full/split/staged reconstruction passes. These are static checks only.

Parent owns meaningful RED execution, strict compilation/format, focused/full suite and per-file direct Jev. RiskTreatmentAssertion and RiskTreatmentAction remain pending work; this stage does not claim their compaction or any realm-wide operation binding.
