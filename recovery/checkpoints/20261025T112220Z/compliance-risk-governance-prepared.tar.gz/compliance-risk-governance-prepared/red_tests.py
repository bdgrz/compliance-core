from pathlib import Path
p=Path('/tmp/compliance-risk-governance-prepared');rel='test/Compliance.Tests/Features/Risks/RiskGovernanceRetryTests.cs';f=p/'work'/rel;f.parent.mkdir(parents=True,exist_ok=True)
f.write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Risks;

public sealed class RiskGovernanceRetryTests
{
    [Fact]
    public async Task ShouldRaiseOneSemanticTriggerGivenDifferentOrphanContentBeforeAdmission()
    {
        // Arrange
        var fixture = await RiskGovernanceHandlerTests.Fixture.CreateAsync("accept");
        await using var provider = fixture.Provider;
        var at = DateTimeOffset.UtcNow;
        var source = Uuid.CreateVersion4().ToString();
        var trigger = RiskGovernance.TriggerIdFor(fixture.ProgramId, fixture.RiskId, "method_changed", source);
        var command = new RaiseRiskReassessmentTriggers(Uuid.CreateVersion4(), fixture.TenantId, fixture.ProgramId,
            "method_changed", source, at, Uuid.CreateVersion4(), fixture.RiskId);
        await using var scope = provider.CreateAsyncScope();
        var content = scope.ServiceProvider.GetRequiredService<IImmutableContentStore>();
        await FindingContent.WriteDeterministicAsync(content, fixture.TenantId, trigger, RiskContent.TriggerSchema,
            new RiskReassessmentTriggerView(trigger, fixture.RiskId, "method_changed", source, at.AddMinutes(-1)), CancellationToken.None);

        // Act
        await RequestScenario.For(provider).GivenActor(RequestActor.System).When(command).ExpectSuccess();
        await RequestScenario.For(provider).GivenActor(RequestActor.System)
            .When(command with { CommandId = Uuid.CreateVersion4(), RaisedAt = at.AddMinutes(2) }).ExpectSuccess();
        var snapshot = await scope.ServiceProvider.GetRequiredService<RiskGovernanceReader>()
            .ReadRiskAsync(fixture.TenantId, fixture.ProgramId, fixture.RiskId);

        // Assert
        var captured = Assert.Single(snapshot.OpenTriggers(fixture.RiskId, []));
        Assert.Equal(trigger, captured.TriggerId);
        Assert.Equal(at, captured.RaisedAt);
        Assert.Equal(1, snapshot.RevisionOf(fixture.RiskId));
    }
}
''')
(p/'behavioral-red-source.cs').write_text(f.read_text())
