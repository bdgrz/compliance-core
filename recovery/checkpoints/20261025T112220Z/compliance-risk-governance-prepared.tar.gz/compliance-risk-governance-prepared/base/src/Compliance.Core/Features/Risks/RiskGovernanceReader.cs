using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Remediation;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>
///     Reads a risk's governance from its own owner streams and composes the public views. A risk's owner and triggers
///     come from its governance stream, its treatment assertion lines from the stream of each (risk, control), and its
///     actions from the stream of each action; every owner is discovered from its first fact and hydrated on its own, so
///     no program-wide ledger exists and nothing is retained as command state.
/// </summary>
public sealed class RiskGovernanceReader(IAggregateReader reader, IDomainEventReader events,
    IImmutableContentStore content)
{
    /// <summary>The governance of every risk of the program.</summary>
    public ValueTask<RiskGovernanceSnapshot> ReadAsync(Uuid tenantId, Uuid programId, CancellationToken ct = default) =>
        CollectAsync(tenantId, programId, null, ct);

    /// <summary>The governance of one risk of the program.</summary>
    public ValueTask<RiskGovernanceSnapshot> ReadRiskAsync(Uuid tenantId, Uuid programId, Uuid riskId,
        CancellationToken ct = default) => CollectAsync(tenantId, programId, riskId, ct);

    /// <summary>The control a treatment of the risk belongs to, or null when the risk has no such treatment.</summary>
    public async ValueTask<Uuid?> LocateControlAsync(Uuid tenantId, Uuid programId, Uuid riskId, Uuid treatmentId,
        CancellationToken ct = default)
    {
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(tenantId.ToString(),
                           RiskTreatmentAssertion.Area), EventCursor.Start, ct).ConfigureAwait(false))
            if (!record.Event.Metadata.IsAudit && record.Event is RiskControlTreatmentProposed proposed &&
                proposed.TenantId == tenantId && proposed.ProgramId == programId && proposed.RiskId == riskId &&
                proposed.Operation.LogicalId == treatmentId)
                return (await FindingContent.ReadAsync<RiskControlTreatmentView>(content, tenantId,
                    proposed.TreatmentContent, ct).ConfigureAwait(false)).ControlId;
        return null;
    }

    /// <summary>The treatments of a line composed from its facts, in the order proposed.</summary>
    public async ValueTask<IReadOnlyList<RiskControlTreatmentView>> ComposeTreatmentsAsync(Uuid tenantId,
        RiskTreatmentAssertion line, CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(line);
        var views = new List<RiskControlTreatmentView>();
        foreach (var treatment in line.Treatments)
        {
            var proposed = await FindingContent.ReadAsync<RiskControlTreatmentView>(content, tenantId,
                treatment.Proposed.TreatmentContent, ct).ConfigureAwait(false);
            var view = proposed with { Status = treatment.Status };
            if (treatment.Reviewed is { } reviewed)
                view = view with
                {
                    ReviewDecisionId = reviewed.DecisionId,
                    ReviewedBy = reviewed.Reviewer,
                    ReviewRationale = reviewed.Rationale,
                    ReviewedAt = reviewed.ReviewedAt,
                    SeparationOfDutiesWaiverId = reviewed.SeparationOfDutiesWaiverId,
                };
            if (treatment.Retired is { } retired)
                view = view with
                {
                    RetiredBy = retired.RetiredBy,
                    RetirementRationale = retired.Rationale,
                    RetiredAt = retired.RetiredAt,
                };
            views.Add(view with { Revision = line.Revision });
        }

        return views;
    }

    /// <summary>The action composed from its facts, or null when it was not added.</summary>
    public async ValueTask<RiskTreatmentActionView?> ComposeActionAsync(Uuid tenantId, RiskTreatmentAction action,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(action);
        if (action.Added is not { } added)
            return null;
        var view = await FindingContent.ReadAsync<RiskTreatmentActionView>(content, tenantId, added.ActionContent, ct)
            .ConfigureAwait(false);
        var completions = new List<RiskTreatmentActionCompletionView>();
        foreach (var fact in action.Facts)
        {
            switch (fact)
            {
                case RiskTreatmentActionRevised revised:
                    view = view with
                    {
                        Title = revised.Title,
                        TargetState = revised.TargetState,
                        ExpectedEvidence = revised.ExpectedEvidence,
                        DueOn = revised.DueOn,
                        AccountableMemberId = revised.AccountableMemberId,
                        EvidenceRequestIds = await FindingContent.ReadAsync<IReadOnlyList<Uuid>>(content, tenantId,
                            revised.EvidenceRequestIdsManifest, ct).ConfigureAwait(false),
                    };
                    break;
                case RiskTreatmentActionCompletionSubmitted submitted:
                    completions.Add(new RiskTreatmentActionCompletionView(submitted.SubmissionId, submitted.Summary,
                        await FindingContent.ReadAsync<IReadOnlyList<Uuid>>(content, tenantId,
                            submitted.EvidenceRequestIdsManifest, ct).ConfigureAwait(false), submitted.SubmittedBy,
                        submitted.SubmittedAt, null, null, null, null, null, null));
                    break;
                case RiskTreatmentActionCompletionReviewed reviewed:
                    completions[^1] = completions[^1] with
                    {
                        ReviewDecisionId = reviewed.DecisionId,
                        ReviewOutcome = reviewed.Outcome,
                        ReviewedBy = reviewed.Reviewer,
                        ReviewRationale = reviewed.Rationale,
                        ReviewedAt = reviewed.ReviewedAt,
                        SeparationOfDutiesWaiverId = reviewed.SeparationOfDutiesWaiverId,
                    };
                    break;
                case RiskTreatmentActionCancelled cancelled:
                    view = view with
                    {
                        CancellationRationale = cancelled.Rationale,
                        CancelledBy = cancelled.CancelledBy,
                        CancelledAt = cancelled.CancelledAt,
                    };
                    break;
            }
        }

        return view with { Status = action.Status, Completions = completions, Revision = action.Revision };
    }

    /// <summary>The submitting members of the action's completion submissions, by submission id.</summary>
    public static IReadOnlyDictionary<Uuid, Uuid> SubmittersOf(RiskTreatmentAction action) =>
        action.Submissions.ToDictionary(static submission => submission.SubmissionId,
            static submission => submission.SubmitterMemberId);

    /// <summary>
    ///     Discovers every governed risk, every (risk, control) assertion line and every action of the program from the
    ///     first facts of their own owner streams.
    /// </summary>
    public async ValueTask<RiskOwnerDiscovery> DiscoverAsync(Uuid tenantId, Uuid programId, Uuid? only,
        CancellationToken ct = default)
    {
        var governed = new SortedSet<Uuid>(UuidOrder);
        var lines = new SortedSet<(Uuid Risk, Uuid Control)>(Comparer<(Uuid Risk, Uuid Control)>.Create(
            static (left, right) => string.CompareOrdinal($"{left.Risk}|{left.Control}", $"{right.Risk}|{right.Control}")));
        var actions = new SortedSet<(Uuid Risk, Uuid Action)>(Comparer<(Uuid Risk, Uuid Action)>.Create(
            static (left, right) => string.CompareOrdinal($"{left.Risk}|{left.Action}", $"{right.Risk}|{right.Action}")));
        var realm = tenantId.ToString();
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(realm, RiskGovernance.Area),
                           EventCursor.Start, ct).ConfigureAwait(false))
            switch (record.Event)
            {
                case RiskOwnerAssigned ev when !record.Event.Metadata.IsAudit && Wanted(ev.TenantId, ev.ProgramId, ev.RiskId):
                    governed.Add(ev.RiskId);
                    break;
                case RiskReassessmentTriggered ev when !record.Event.Metadata.IsAudit && Wanted(ev.TenantId, ev.ProgramId, ev.RiskId):
                    governed.Add(ev.RiskId);
                    break;
            }

        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(realm,
                           RiskTreatmentAssertion.Area), EventCursor.Start, ct).ConfigureAwait(false))
            if (!record.Event.Metadata.IsAudit && record.Event is RiskControlTreatmentProposed proposed &&
                Wanted(proposed.TenantId, proposed.ProgramId, proposed.RiskId))
                lines.Add((proposed.RiskId, (await FindingContent.ReadAsync<RiskControlTreatmentView>(content,
                    tenantId, proposed.TreatmentContent, ct).ConfigureAwait(false)).ControlId));

        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(realm, RiskTreatmentAction.Area),
                           EventCursor.Start, ct).ConfigureAwait(false))
            if (!record.Event.Metadata.IsAudit && record.Event is RiskTreatmentActionAdded added &&
                Wanted(added.TenantId, added.ProgramId, added.RiskId))
                actions.Add((added.RiskId, added.Operation.LogicalId));

        return new RiskOwnerDiscovery(governed, lines, actions);

        bool Wanted(Uuid eventTenant, Uuid eventProgram, Uuid eventRisk) =>
            eventTenant == tenantId && eventProgram == programId && (only is null || only == eventRisk);
    }

    async ValueTask<RiskGovernanceSnapshot> CollectAsync(Uuid tenantId, Uuid programId, Uuid? only, CancellationToken ct)
    {
        var (governed, lines, actions) = await DiscoverAsync(tenantId, programId, only, ct).ConfigureAwait(false);
        var risks = new SortedSet<Uuid>(governed, UuidOrder);
        risks.UnionWith(lines.Select(static line => line.Risk));
        risks.UnionWith(actions.Select(static action => action.Risk));
        var records = new Dictionary<Uuid, RiskGovernanceRecord>();
        foreach (var riskId in risks)
        {
            var governance = await reader.HydrateAsync(new RiskGovernance(tenantId, programId, riskId), ct)
                .ConfigureAwait(false);
            var owner = governance.Owner is { } assigned
                ? await FindingContent.ReadAsync<RiskOwnerView>(content, tenantId, assigned.OwnerContent, ct)
                    .ConfigureAwait(false)
                : (RiskOwnerView?)null;
            var triggers = new List<RiskReassessmentTriggerView>();
            foreach (var trigger in governance.Triggers)
                triggers.Add(await FindingContent.ReadAsync<RiskReassessmentTriggerView>(content, tenantId,
                    trigger.TriggerContent, ct).ConfigureAwait(false));
            var treatments = new List<RiskControlTreatmentView>();
            foreach (var (_, controlId) in lines.Where(line => line.Risk == riskId))
            {
                var line = await reader.HydrateAsync(new RiskTreatmentAssertion(tenantId, programId, riskId, controlId),
                    ct).ConfigureAwait(false);
                treatments.AddRange(await ComposeTreatmentsAsync(tenantId, line, ct).ConfigureAwait(false));
            }

            var views = new List<RiskTreatmentActionView>();
            var submitters = new Dictionary<Uuid, Uuid>();
            foreach (var (_, actionId) in actions.Where(action => action.Risk == riskId))
            {
                var action = await reader.HydrateAsync(new RiskTreatmentAction(tenantId, programId, riskId, actionId),
                    ct).ConfigureAwait(false);
                if (await ComposeActionAsync(tenantId, action, ct).ConfigureAwait(false) is not { } view)
                    continue;
                views.Add(view);
                foreach (var (submission, submitter) in SubmittersOf(action))
                    submitters[submission] = submitter;
            }

            records.Add(riskId, new RiskGovernanceRecord(governance.Revision, owner, treatments.OrderBy(
                static treatment => treatment.ProposedAt).ToArray(), triggers, views.OrderBy(static action => action.CreatedAt)
                .ToArray(), submitters));
        }

        return new RiskGovernanceSnapshot(tenantId, programId, records);
    }

    /// <summary>The owner streams of a program's risk governance, discovered from their first facts.</summary>
    public sealed record RiskOwnerDiscovery(IReadOnlyCollection<Uuid> Governed,
        IReadOnlyCollection<(Uuid Risk, Uuid Control)> Lines, IReadOnlyCollection<(Uuid Risk, Uuid Action)> Actions);

    static readonly Comparer<Uuid> UuidOrder = Comparer<Uuid>.Create(static (left, right) =>
        string.CompareOrdinal(left.ToString(), right.ToString()));
}
