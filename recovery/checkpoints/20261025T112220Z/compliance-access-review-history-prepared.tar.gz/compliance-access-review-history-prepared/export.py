from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,re
p=Path('/tmp/compliance-access-review-history-prepared');base=p/'base';work=p/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
src=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')]
red={'test/Compliance.Tests/Features/AccessReviews/AccessReviewNativeBoundaryTests.cs','test/Compliance.Tests/Features/AccessReviews/AccessReviewPreparationReplayTests.cs','test/Compliance.Tests/Features/AccessReviews/AccessReviewCompletionFailureBindingTests.cs'}
arts={}
for name,selected in [('implementation.patch',src),('tests.patch',tests),('green-after-red.patch',[r for r in paths if r not in red]),('full.patch',paths)]:
 text=''
 for r in selected:
  b=base/r;f=work/r;text+=''.join(difflib.unified_diff(b.read_text().splitlines(True) if b.exists() else [],f.read_text().splitlines(True),fromfile='a/'+r if b.exists() else '/dev/null',tofile='b/'+r))
 f=p/name;f.write_text(text);arts[name]={'path':str(f),'sha256':sha(f)}
for name in ['behavioral-red.patch','completion-cancellation-red.patch']:
 arts[name]={'path':str(p/name),'sha256':sha(p/name)}
checks=[]
for label,sequence in [('full',['full.patch']),('split',['tests.patch','implementation.patch']),('staged',['behavioral-red.patch','completion-cancellation-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/label;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest)
 for patch in sequence:
  result=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,capture_output=True,text=True)
  assert result.returncode==0,result.stdout+result.stderr
 assert all(sha(dest/r)==sha(work/r) for r in paths),label
 checks.append({'sequence':sequence,'exact':True})
rows=[{'path':r,'before':sha(base/r),'after':sha(work/r),'mainMatchesBase':sha(repo/r)==sha(base/r)} for r in paths]
(p/'owned-paths.txt').write_text('\n'.join(paths)+'\n')
(p/'hashes.json').write_text(json.dumps(rows,indent=2)+'\n')
report={'status':'FROZEN','paths':rows,'artifacts':arts,'reconstruction':checks,'prerequisites':['Merged AccessExpectation20 including current ct-last ResolveLineAsync corrections','Merged SourceUse72 selected-finalization wrapper, generic prepare/freeze equal-winner recovery and NativeOwnerHistory','Existing production ISourceFactResolver registration and source-generated metadata for existing Access event/content types'],
'scope':'Compact Campaign/Item native authority; complete transient exact-prefix chronology/rolling commitment; selected historical batch/completion/pin facts; all 8 personal/campaign producers prepare and freeze inside NativeOperationExecutor and bind exact append cuts; complete bulk holds/provisional/publication/cancellation fences and completion drain/hold/close/settle consumers; verified current readers and Work/TypeI source consumers.',
'wire':'Existing public DTOs, route maps, discriminator tags/versions, source logical digests/physical-byte/receipt semantics and FirstResponse/MutationResultContent envelopes unchanged. New root provenance explicitly records its actual FirstOwner. No shared Program/DI/JSON edits required; existing scoped registrations automatically resolve added IDomainEventReader/ISourceFactResolver constructor dependencies.',
'authority':'Lifetime facts/admitted/canceled/provisional/published/fenced collections are removed from Campaign/Item. History snapshots are transient and complete. The independent DecisionBatch remains unchanged: its lifecycle is bounded to admission plus publication, or cancellation acceptance plus cancellation. SourceUse72 selected-finalized proofs and protected Apply observer are preserved.',
'protocol':'Bulk selections and completion use/drain manifests verify full descriptors, complete canonical membership, duplicate/scope/first-owner header/native source identity. Completion verifies all launched item uses and exact earlier admitted item/batch drain tuples, not only counts. Abort requires Evidence == exact selected accepted completion and optional failed item belongs its frozen selection. Missing content is transient, corrupt content permanent. Exact authorized accepted retry resolves before unrelated mutable body reads/freezes.',
'metadataQualification':'Established rolling typed payload + immutable EventId/AggregateId/AggregateVersion/OccurredOn/IsAudit commitment; selected actual facts also compare full metadata. NativeOwnerHistory includes physical offsets/audits at the hydrated cut. This does not invent ordering/receipt semantics or rewrite historical source bytes.',
'legacyQualification':'No migration or dual-read path. Previously persisted malformed manual fixture histories (missing materialization causation/FirstOwner) are corrected in tests, not accepted by fallback. Production bulk child processing of pre-cutover null FirstOwner admissions is not qualified by the stricter exact frozen-header gate; existing exact accepted root retry retains NativeAcceptance semantics. Existing prerelease disposable-history decision applies.',
'runtimeEvidence':'Root qualified initial OLD-API stage2 RED3: 64 decisions retain item facts; 32 admissions retain campaign maps; losing decision manifest write hides an equal winner. Root qualified additional OLD-API completion cancellation RED1 against merged55dc8c23: earlier completion failure proof unsafely cancelled later pending completion after real held-item setup. No local .NET/build/test/Jev execution. Root owns runtime/Jev/integration.',
'validation':'Static full effective-source syntax/constructor and unchanged acceptance-name/assert-count gates saved in static-checks.json. Full/split/qualified-red-staged patch application reconstructs every exact final path hash. New history tests cover 4 intermediate payload/metadata substitutions, 4 cache descriptor tamper cases, selected old publication after later batch, and 2 typed missing/corrupt body cases.',
'filters':['FullyQualifiedName~Features.AccessReviews|FullyQualifiedName~AccessReviewCampaignsTypeIBaselineSourceContributorTests|FullyQualifiedName~FitzAccessReviewCampaignWorkItemDirectoryTests','Category=WebIntegration&FullyQualifiedName~PersonalAccessReviewTransportTests'],
'remaining':'ApplicationImportSource claim/settle/fence lineage is next independent task; no claim about other retained families. Root owns all main/runtime/Git/Jev operations; no new issues.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'source':len(src),'tests':len(tests),'drift':[row['path'] for row in rows if not row['mainMatchesBase']],'artifacts':arts,'reconstruction':checks},indent=2))
