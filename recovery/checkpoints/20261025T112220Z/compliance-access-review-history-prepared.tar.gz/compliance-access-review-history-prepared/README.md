# Access Campaign / Item native history cutover — FROZEN

67 changed paths: 52 production, 15 test. Exact manifest: `handoff.json`; all changed base hashes match current main. No main, .NET, Git, Jev, broker, or issue operations performed here.

Root already qualified the three original old-API RED cases and the additional completion cancellation RED. Apply `full.patch`, or `tests.patch` then `implementation.patch`. The staged sequence `behavioral-red.patch`, `completion-cancellation-red.patch`, `green-after-red.patch` also reconstructs every final hash exactly. Tests-only final migration requires the native implementation APIs; the two standalone RED patches compile against old APIs.

Static gates: all 171 saved C# files parse; 64 explicit constructors in effective current source match new arities; all 171 original acceptance names and existing assert counts survive. Full/split/staged reconstruction passed. Parent owns strict format/build, focused/full/HTTP tests, direct Jev, commit/PR/merge.

The two compact owners retain only current authority plus facts explicitly selected before hydration. Complete transient histories certify actual hydrated rolling payload/metadata and physical cuts, and the installed reader validates these before normal read or accepted retry. All eight owning producers now read business state and freeze content inside async native Prepare, then bind the exact prepared cut at append. All batch/completion receivers explicitly select historical roots/pins. The independent DecisionBatch is unchanged and finite.

Complete manifests verify every descriptor, canonical owner order, duplicate-free scope, exact first-owner header and authoritative admission. Closure drains equal the complete earlier admitted item/batch tuples; cancellation cannot consume another completion's failure proof. Reactors verify the committed typed source at its actual physical resource offset before effects. Current read/preview failures classify missing bytes transient and corrupt bytes permanent. Existing current authorization and accepted original results remain.

No shared routes/DI/JSON deltas: constructor additions resolve through existing registrations; the owning fixture registers a broker-free resolver and binds direct reactor scenarios to the tenant. Existing public DTOs/event tags/source bytes/receipt semantics are unchanged. `handoff.json` documents the exact persisted-history qualification: no fabricated migration/dual-read fallback for historical null FirstOwner bulk admissions or malformed manual seeds.

Focused suggested filter: `FullyQualifiedName~Features.AccessReviews|FullyQualifiedName~AccessReviewCampaignsTypeIBaselineSourceContributorTests|FullyQualifiedName~FitzAccessReviewCampaignWorkItemDirectoryTests`. Existing personal transport fixtures are preserved; run relevant WebIntegration coverage centrally.
