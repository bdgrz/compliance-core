from pathlib import Path
import difflib,hashlib
r=Path('/tmp/compliance-source-byte-closure-prepared');p='test/Compliance.Tests/Features/Examinations/FindingTypeIBaselineSourceContributorTests.cs';f=r/'work'/p;s=f.read_text();imports='''using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.AuditPackages;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Snapshots;
''';s=imports+s;pos=s.index('    static FindingTypeIBaselineSourceContributor Contributor(');method='''    [Fact]
    public async Task ShouldArchiveExactFindingActionAndEvidenceBytesGivenProductionSourcePublication()
    {
        // Arrange
        var fixture = await OperationsFixture.CreateAsync();
        var finding = await FindingTests.RaiseWithCompletedActionAsync(fixture);
        var directory = Directory.CreateTempSubdirectory("bdgrz-finding-source-archive-").FullName;
        try
        {
            var content = fixture.Provider.GetRequiredService<IImmutableContentStore>();
            var artifacts = new LocalArtifactContentStore(new ArtifactContentStoreOptions(directory, null,
                ArtifactContentLimits.MaxContentLength), TimeProvider.System);
            var publisher = new PublishedTypeIBaselinePreviewReader(
                new TypeIBaselinePreviewReader([Contributor(fixture)]), artifacts, content);
            var preview = await publisher.ReadAsync(Engagement(fixture, DateOnly.FromDateTime(DateTime.UtcNow).AddDays(1)));
            Assert.True(preview.IsSuccess, preview.Error?.Message);
            var source = Assert.Single(preview.Value.Sources);
            Assert.NotNull(source.Content);
            var selected = new AuditPackageSelectionEntry("findings", "F-01", source.Kind, source.RecordId,
                source.Revision, source.Content.FileExtension, source.ContentSha256, source.Content.Bytes,
                "product_calculated", source.VersionId, source.Content);
            var manifest = new AuditPackageManifestView(fixture.TenantId, fixture.ProgramId, Uuid.CreateVersion4(),
                Uuid.CreateVersion4(), 1, Uuid.CreateVersion4(), preview.Value.ContentSha256, [finding.FindingId],
                [new AuditPackageManifestEntryView(selected, "findings/F-01." + selected.Extension)],
                new string('a', 64), DateTimeOffset.UtcNow);

            // Act
            var built = await new AuditPackageArchiveBuilder(artifacts).BuildAsync(fixture.TenantId, manifest,
                CancellationToken.None);
            Assert.True(built.IsSuccess, built.Error?.Message);
            await using var stored = await artifacts.OpenVerifiedAsync(new ArtifactContentReference(fixture.TenantId,
                built.Value.ArchiveSha256!, built.Value.ArchiveBytes!.Value));
            using var zip = new ZipArchive(stored!, ZipArchiveMode.Read);
            var entry = Assert.Single(zip.Entries);
            await using var payload = entry.Open();
            using var envelope = await JsonDocument.ParseAsync(payload);
            var proof = Convert.FromBase64String(envelope.RootElement.GetProperty("source_base64").GetString()!);
            var recovered = new List<string>();
            foreach (var blob in envelope.RootElement.GetProperty("content_blobs").EnumerateArray())
            {
                var reference = blob.GetProperty("reference").Deserialize(ComplianceCoreJsonContext.Default.ImmutableContentRef)!;
                var bytes = Convert.FromBase64String(blob.GetProperty("base64").GetString()!);
                Assert.Equal(reference.Bytes, bytes.LongLength);
                Assert.Equal(reference.Sha256, Convert.ToHexStringLower(SHA256.HashData(bytes)));
                Assert.Equal((await content.ReadVerifiedAsync(fixture.TenantId.ToString(), reference)).ToArray(), bytes);
                recovered.Add(Encoding.UTF8.GetString(bytes));
            }

            // Assert
            Assert.Equal(source.ContentSha256, Convert.ToHexStringLower(SHA256.HashData(proof)));
            Assert.StartsWith("bdgrz.snapshot.source.finding.v1\\0", Encoding.UTF8.GetString(proof), StringComparison.Ordinal);
            Assert.Equal(source.ContentSha256, envelope.RootElement.GetProperty("logical_content_sha256").GetString());
            Assert.Equal("application/vnd.bdgrz.finding-snapshot-source.v1+json", source.Content.MediaType);
            Assert.Equal(source.Content.Bytes, entry.Length);
            Assert.Contains(recovered, body => body.Contains("Remove stale VPN accounts.", StringComparison.Ordinal));
            Assert.Contains(recovered, body => body.Contains("Removal ticket", StringComparison.Ordinal));
            Assert.Contains(recovered, body => body.Contains(fixture.ControlId.ToString(), StringComparison.Ordinal));
        }
        finally
        {
            Directory.Delete(directory, recursive: true);
        }
    }

''';s=s[:pos]+method+s[pos:];f.write_text(s);(r/'finding-red-final.cs').write_text(s);base=(r/'base'/p).read_text();patch=''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='a/'+p,tofile='b/'+p));(r/'finding-behavioral-red.patch').write_text(patch);print(hashlib.sha256(patch.encode()).hexdigest())
