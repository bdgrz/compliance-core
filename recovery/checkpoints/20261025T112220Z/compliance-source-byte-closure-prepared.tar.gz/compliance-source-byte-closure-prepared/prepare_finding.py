from pathlib import Path
r=Path('/tmp/compliance-source-byte-closure-prepared');w=r/'work'
p=w/'src/Compliance.Core/Features/Snapshots/SnapshotSourceCapture.cs';s=p.read_text();at=s.index('    internal sealed class Scope');s=s[:at]+'''    public static void Finding(string logicalSha256, ReadOnlySpan<byte> source,
        IReadOnlyList<SnapshotSourceContentBlob> blobs)
    {
        if (blobs.Count > 0 && Current.Value is { } scope)
            scope.Business(logicalSha256, source, blobs, "application/vnd.bdgrz.finding-snapshot-source.v1+json",
                "Exact canonical finding source proof and its digest-verified immutable business content bytes.");
    }

    public static void TypeIIClose(string logicalSha256, ReadOnlySpan<byte> source,
        IReadOnlyList<SnapshotSourceContentBlob> blobs)
    {
        if (blobs.Count > 0 && Current.Value is { } scope)
            scope.Business(logicalSha256, source, blobs, "application/vnd.bdgrz.type-ii-close-snapshot-source.v1+json",
                "Exact canonical Type II close source proof and its digest-verified selected operating content bytes.");
    }

'''+s[at:];start=s.index('        public void Risk(');brace=s.index('        {',start);s=s[:brace]+'''            => Business(logicalSha256, source, blobs, "application/vnd.bdgrz.risk-snapshot-source.v1+json",
                "Exact canonical risk source proof and its digest-verified immutable business content bytes.");

        public void Business(string logicalSha256, ReadOnlySpan<byte> source,
            IReadOnlyList<SnapshotSourceContentBlob> blobs, string mediaType, string description)
'''+s[brace:];s=s.replace('"A risk source envelope differs from its exact logical preimage."','"A snapshot source envelope differs from its exact logical preimage."').replace('"A risk source blob differs from its exact immutable reference."','"A snapshot source blob differs from its exact immutable reference."');s=s.replace('''                var descriptor = new SnapshotSourceBlob(physical, input.Length,
                    "application/vnd.bdgrz.risk-snapshot-source.v1+json", "json",
                    "Exact canonical risk source proof and its digest-verified immutable business content bytes.");''','''                var descriptor = new SnapshotSourceBlob(physical, input.Length, mediaType, "json", description);''');p.write_text(s)
p=w/'src/Compliance.Core/Features/Examinations/FindingTypeIBaselineSourceEvent.cs';s=p.read_text().replace('using System.Text.Json;','using System.Text.Json;\nusing System.Text.Json.Serialization;\nusing Bdgrz.Compliance.Features.Snapshots;').replace('    JsonElement Payload);','''    JsonElement Payload)
{
    [JsonIgnore]
    public IReadOnlyList<SnapshotSourceContentBlob>? ContentBlobs { get; init; }
}''');p.write_text(s)
p=w/'src/Compliance.Core/Features/Examinations/FindingTypeIBaselineSourceContributor.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.Remediation;','using Bdgrz.Compliance.Features.Remediation;\nusing Bdgrz.Compliance.Features.Proofs;');s=s.replace('    IDomainEventReader events, IAggregateReader aggregates) : ITypeIBaselineSourceContributor','    IDomainEventReader events, IAggregateReader aggregates, IImmutableContentStore contentStore) : ITypeIBaselineSourceContributor');needle='''    {
        if (engagement is null || context?.PreviouslyCapturedSources is null ||''';replacement='''    {
        try
        {
            return await ReadCoreAsync(engagement, context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<TypeIBaselineSourceContribution>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The finding's exact immutable source bytes cannot be verified.", exception is ImmutableContentUnavailableException));
        }
    }

    async ValueTask<Result<TypeIBaselineSourceContribution>> ReadCoreAsync(ExaminationEngagementView engagement,
        TypeIBaselineSourceReadContext context, CancellationToken ct)
    {
        if (engagement is null || context?.PreviouslyCapturedSources is null ||''';assert needle in s;s=s.replace(needle,replacement,1);s=s.replace('history.Add(Capture(fact));','history.Add(await CaptureAsync(engagement.TenantId, fact, ct).ConfigureAwait(false));')
at=s.index('    static FindingTypeIBaselineSourceEvent Capture(')
s=s[:at]+'''    async ValueTask<FindingTypeIBaselineSourceEvent> CaptureAsync(Uuid tenant, DomainEvent fact, CancellationToken ct)
    {
        var references = new List<ImmutableContentRef>();
        void Add(ImmutableContentRef? reference)
        {
            if (reference is not null)
                references.Add(reference);
        }
        ImmutableContentRef? intent = null;
        switch (fact)
        {
            case FindingRaisedV2 value:
                Add(value.LinksManifest);
                break;
            case CorrectiveActionAdmitted value:
                Add(intent = value.Intent);
                Add(value.SourceProofs);
                break;
            case CorrectiveActionAddedV2 value:
                Add(value.ActionContent);
                Add(intent = value.Intent);
                break;
            case CorrectiveActionCompletedV2 value:
                Add(value.EvidenceManifest);
                break;
            case FindingAcceptanceLinkedV2 value:
                Add(value.AcceptanceContent);
                break;
            case FindingClosureAccepted value:
                Add(intent = value.Intent);
                Add(value.SourceProofs);
                break;
            case FindingClosedV2 value:
                Add(value.ClosureContent);
                Add(value.ActionCompletionProofs);
                Add(intent = value.Intent);
                break;
            case FindingClosureCanceled value:
                Add(intent = value.Intent);
                Add(value.SourceProofs);
                break;
        }
        if (intent is { Schema: ChildAdmissionIntent.Schema })
        {
            var child = await contentStore.ReadJsonAsync<ChildAdmissionIntent>(tenant.ToString(), intent, ct).ConfigureAwait(false);
            Add(child.CanonicalAuthoredContent);
            Add(child.SelectedSourceProofs.Content);
        }
        else if (intent is { Schema: ClosureIntent.Schema })
        {
            var closure = await contentStore.ReadJsonAsync<ClosureIntent>(tenant.ToString(), intent, ct).ConfigureAwait(false);
            Add(closure.AdmittedChildren.Content);
            Add(closure.AuthoredDecision);
            Add(closure.SourceUses.Content);
            Add(closure.WaiverProof);
        }
        var blobs = new List<SnapshotSourceContentBlob>();
        foreach (var reference in references.Distinct())
            blobs.Add(new(reference, (await contentStore.ReadVerifiedAsync(tenant.ToString(), reference, ct)
                .ConfigureAwait(false)).ToArray()));
        return Capture(fact) with { ContentBlobs = blobs };
    }

'''+s[at:];s=s.replace('''        return Convert.ToHexStringLower(SnapshotSourceCapture.HashData(material));''','''        var digest = Convert.ToHexStringLower(SnapshotSourceCapture.HashData(material));
        SnapshotSourceCapture.Finding(digest, material, content.History.SelectMany(item => item.ContentBlobs ?? []).ToArray());
        return digest;''');p.write_text(s)
p=w/'test/Compliance.Tests/Features/Examinations/FindingTypeIBaselineSourceContributorTests.cs';s=p.read_text().replace('scope.ServiceProvider.GetRequiredService<IAggregateReader>());','scope.ServiceProvider.GetRequiredService<IAggregateReader>(),\n            scope.ServiceProvider.GetRequiredService<IImmutableContentStore>());');p.write_text(s)
print('prepared selective Finding physical bytes and reused Risk envelope writer')
