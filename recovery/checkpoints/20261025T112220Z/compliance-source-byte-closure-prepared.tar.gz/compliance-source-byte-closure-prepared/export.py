from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
r=Path('/tmp/compliance-source-byte-closure-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
find='test/Compliance.Tests/Features/Examinations/FindingTypeIBaselineSourceContributorTests.cs';oper='test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseSourceBusinessBytes.cs'
def sha(b):return hashlib.sha256(b).hexdigest()
def diff(p,a,b):return ''.join(difflib.unified_diff((a or b'').decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p if a is not None else '/dev/null',tofile='b/'+p))
prov={x['path']:x for x in json.loads((r/'baselines.json').read_text())};files={};manifest=[];groups={x:[] for x in ['implementation.patch','tests.patch','full.patch','green-after-red.patch']}
redFind=(r/'finding-red-final.cs').read_bytes();redOperating=''.join((r/'operating-behavioral-red.patch').read_text().splitlines(True)[3:])
# Read exact original test body from immutable patch added lines; no guessed reconstruction.
redOperating=''.join(line[1:] for line in (r/'operating-behavioral-red.patch').read_text().splitlines(True) if line.startswith('+') and not line.startswith('+++')).encode()
for f in sorted((r/'work').rglob('*.cs')):
 p=str(f.relative_to(r/'work'));b=r/'base'/p;before=b.read_bytes() if b.exists() else None;after=f.read_bytes()
 if before==after:continue
 assert not (repo/p).exists() or before is not None,('Existing repository changed path has no saved before',p)
 if before is not None:assert sha(before)==prov[p]['beforeSha256'],p
 assert after.endswith(b'\n') and b'\r\n' not in after,p
 files[p]={'before':before,'after':after}
 phase='tests.patch' if p.startswith('test/') else 'implementation.patch';d=diff(p,before,after);groups[phase].append(d);groups['full.patch'].append(d)
 redBefore=redFind if p==find else redOperating if p==oper else before
 groups['green-after-red.patch'].append(diff(p,redBefore,after))
 manifest.append({'path':p,'phase':phase,'beforeSha256':sha(before) if before is not None else None,'afterSha256':sha(after),'redSha256':sha(redBefore) if p in [find,oper] else None,'baselineSource':prov[p]['baselineSource'] if p in prov else None,'originalExistsInRepository':(repo/p).exists()})
for n,v in groups.items():(r/n).write_text(''.join(v))
(r/'behavioral-red.patch').write_bytes((r/'finding-behavioral-red.patch').read_bytes()+(r/'operating-behavioral-red.patch').read_bytes())
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');verified={}
for mode,order in {'tests-first':['behavioral-red.patch','green-after-red.patch'],'full':['full.patch'],'split':['implementation.patch','tests.patch']}.items():
 t=Path(tempfile.mkdtemp(prefix='byte-closure-reconstruct-',dir=r))
 try:
  for p,x in files.items():
   if x['before'] is not None:
    q=t/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(x['before'])
  for n in order:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/n)],cwd=t,capture_output=True,text=True);assert x.returncode==0,(mode,n,x.stdout,x.stderr)
  assert all((t/p).read_bytes()==x['after'] for p,x in files.items()),mode
  verified[mode]={'exactFiles':len(files),'patchOrder':order}
 finally:shutil.rmtree(t)
(r/'reconstruction.json').write_text(json.dumps(verified,indent=2)+'\n')
a=json.loads((r/'audit.json').read_text())
for k in ['syntaxErrors','constructorErrors','cancellationTokenNotLast','duplicateUsings','potentialMissingProofsUsing','removedAcceptanceNames','assertionCountDrops','existingRepositoryPathsMissingBefore']:assert not a[k],(k,a[k])
patches=['finding-behavioral-red.patch','operating-behavioral-red.patch','behavioral-red.patch','implementation.patch','tests.patch','full.patch','green-after-red.patch']
h={'root':str(r),'status':'FROZEN offline selected Finding + TypeII operating source-byte closure, layered after frozen Risk source-bytes6. Parent owns all runtime RED/GREEN/build/analyzers/format/full tests/direct per-file Jev and integration/delivery.','changedPaths':len(files),'sourcePaths':sum(p.startswith('src/') for p in files),'testPaths':sum(p.startswith('test/') for p in files),'existingPathsWithOriginals':sum(x['before'] is not None for x in files.values()),'newPaths':sum(x['before'] is None for x in files.values()),'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'patches':{p:{'sha256':sha((r/p).read_bytes()),'bytes':(r/p).stat().st_size} for p in patches},'testsFirst':['behavioral-red.patch','green-after-red.patch'],'allFinal':['full.patch'],'splitFinal':['implementation.patch','tests.patch'],'oldApiRedFilter':'FullyQualifiedName~ShouldArchiveExactFindingActionAndEvidenceBytesGivenProductionSourcePublication|FullyQualifiedName~ShouldArchiveExactOperatingBodiesGivenProductionNativeCloseReconciliation','focusedFilter':'FullyQualifiedName~FindingTypeIBaselineSourceContributorTests|FullyQualifiedName~SelectedSnapshotSourceEnvelopeTests|FullyQualifiedName~TypeIIPeriodCommandHandlerTests|FullyQualifiedName~RiskSnapshotSourceEnvelopeTests|FullyQualifiedName~RiskTypeIBaselineSourceContributorTests','suiteFilter':'Category!=BrokerIntegration','sourceAudit':'source-byte-audit.json','audit':'audit.json','reconstruction':'reconstruction.json','readme':'README.md','localBlockers':'LOCAL-BLOCKERS.md','constructorDelta':'FindingTypeIBaselineSourceContributor gains IImmutableContentStore as third constructor argument. DI infers it; sole explicit test helper updated.','staticExplicitConstructorCalls':a['constructorCallsAcrossEffectiveTree'],'originalAcceptanceNames':a['originalAcceptanceNames'],'baselineCancellationTokenNote':'Existing untouched TypeIIPeriodCloseSourcePublication.SealAsync optional coverage follows CancellationToken; retained with exact baseline signature, not introduced by this change.','notes':['Requires frozen /tmp/compliance-risk-source-bytes-prepared helper SnapshotSourceContentBlob and exact SnapshotSourceCapture baseline. No mutation of that frozen artifact. RiskMethod36 still calls unchanged Risk wrapper.','Logical Finding and TypeII native-close canonical shapes/preimages/digests/source versionIDs remain. New selected physical bytes are ignored in JSON source rows and produce optional physical SnapshotSourceBlob JSON envelopes with family-accurate media types.','Risk envelope writer is factored behind unchanged Risk wrapper; its actual output JSON/media/description ordering stays identical.','No-blob legacy frames/media/descriptors remain identical; existing serialized SignificantChange ContentBlobs preserved. Parent active native Incident body closure preserved through additive CaptureOperatingAsync insertion; apply delta hunks rather than replacing future source.','Known explicit business-ref closure only, excluding operation first-response/result bytes and unrelated binary evidence bodies. Missing/corrupt selected content gets typed conflict classification, no mutable current fallback.','All21 TypeI families and exported TypeII lanes inspected. Local missing opening-lineage publication selection contract recorded without invented archive entries.','Existing frozen historical publications are not retroactively modified; only newly authorized captures receive the complete physical envelope.'],'noRuntimeOrJevClaims':True}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'changedPaths':h['changedPaths'],'sourcePaths':h['sourcePaths'],'testPaths':h['testPaths'],'manifestSha256':h['manifestSha256'],'handoffSha256':sha((r/'handoff.json').read_bytes()),'patches':h['patches']},indent=2))
