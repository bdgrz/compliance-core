from pathlib import Path
r=Path('/tmp/compliance-source-byte-closure-prepared');p=r/'work/test/Compliance.Tests/Features/Examinations/FindingTypeIBaselineSourceContributorTests.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Proofs;');at=s.index('    static FindingTypeIBaselineSourceContributor Contributor(');s=s[:at]+'''    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ShouldClassifyUnverifiableFindingBusinessBytesGivenSelectedSourceFact(bool unavailable)
    {
        // Arrange
        var fixture = await OperationsFixture.CreateAsync();
        var finding = await fixture.RaiseFindingAsync(fixture.OwnerMemberId);
        using var scope = fixture.Provider.CreateScope();
        var reader = scope.ServiceProvider.GetRequiredService<IAggregateReader>();
        var owner = await reader.HydrateAsync(new FindingAggregate(fixture.TenantId, fixture.ProgramId, finding.FindingId));
        var contributor = new FindingTypeIBaselineSourceContributor(scope.ServiceProvider.GetRequiredService<IDomainEventReader>(),
            reader, new UnverifiableFindingContent(fixture.Content, owner.Raised!.LinksManifest, unavailable));

        // Act
        var outcome = await contributor.ReadAsync(Engagement(fixture, fixture.Today.AddDays(1)), CancellationToken.None);

        // Assert
        Assert.False(outcome.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, outcome.Error?.Kind);
        Assert.Equal(unavailable, outcome.Error!.IsTransient);
    }

    [Fact]
    public async Task ShouldIgnoreUnselectedBusinessContentGivenFindingRecordedAfterCutoff()
    {
        // Arrange
        var fixture = await OperationsFixture.CreateAsync();
        var finding = await fixture.RaiseFindingAsync(fixture.OwnerMemberId);
        using var scope = fixture.Provider.CreateScope();
        var reader = scope.ServiceProvider.GetRequiredService<IAggregateReader>();
        var owner = await reader.HydrateAsync(new FindingAggregate(fixture.TenantId, fixture.ProgramId, finding.FindingId));
        var contributor = new FindingTypeIBaselineSourceContributor(scope.ServiceProvider.GetRequiredService<IDomainEventReader>(),
            reader, new UnverifiableFindingContent(fixture.Content, owner.Raised!.LinksManifest, false));

        // Act
        var outcome = await contributor.ReadAsync(Engagement(fixture, fixture.Today.AddDays(-2)), CancellationToken.None);

        // Assert
        Assert.True(outcome.IsSuccess, outcome.Error?.Message);
        Assert.Empty(outcome.Value.Sources);
    }

    sealed class UnverifiableFindingContent(IImmutableContentStore inner, ImmutableContentRef selected,
        bool unavailable) : IImmutableContentStore
    {
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema,
            string mediaType, ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference,
            CancellationToken ct = default) => reference.ContentId == selected.ContentId
            ? throw (unavailable ? new ImmutableContentUnavailableException("The finding source bytes are unavailable.")
                : new ImmutableContentIntegrityException("The finding source bytes cannot be verified."))
            : inner.ReadVerifiedAsync(realm, reference, ct);
    }

'''+s[at:];p.write_text(s)
p=r/'work/test/Compliance.Tests/Features/AuditPackages/SelectedSnapshotSourceEnvelopeTests.cs';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('''using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Snapshots;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.AuditPackages;

public sealed class SelectedSnapshotSourceEnvelopeTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void ShouldPreserveExactLegacyLogicalBytesGivenSelectedFamilyWithoutBusinessBlobs(bool close)
    {
        // Arrange
        var source = Encoding.UTF8.GetBytes("bdgrz.snapshot.source.test.v1\\0{\\"events\\":[]}");
        using var capture = SnapshotSourceCapture.Begin(Uuid.CreateVersion4());
        var logical = Convert.ToHexStringLower(SnapshotSourceCapture.HashData(source));
        Assert.True(capture.TryGet(logical, out var original));

        // Act
        Capture(close, logical, source, []);
        Assert.True(capture.TryGet(logical, out var result));

        // Assert
        Assert.Equal(original!.Blob, result!.Blob);
        Assert.Equal(source, File.ReadAllBytes(result.Path));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void ShouldRetainLogicalPreimageAndDeduplicatedVerifiedBytesGivenSelectedFamilyBodies(bool close)
    {
        // Arrange
        var source = Encoding.UTF8.GetBytes("bdgrz.snapshot.source.test.v1\\0{\\"events\\":[1]}");
        var bytes = Encoding.UTF8.GetBytes("{\\"narrative\\":\\"Exact selected business bytes\\"}");
        var reference = new ImmutableContentRef(Uuid.CreateVersion4(), Convert.ToHexStringLower(SHA256.HashData(bytes)),
            bytes.LongLength, "application/json", "source-business-test.v1");
        using var capture = SnapshotSourceCapture.Begin(Uuid.CreateVersion4());
        var logical = Convert.ToHexStringLower(SnapshotSourceCapture.HashData(source));

        // Act
        Capture(close, logical, source, [new(reference, bytes), new(reference, bytes)]);
        Assert.True(capture.TryGet(logical, out var result));
        var physical = File.ReadAllBytes(result!.Path);
        using var document = JsonDocument.Parse(physical);
        var blob = Assert.Single(document.RootElement.GetProperty("content_blobs").EnumerateArray());

        // Assert
        Assert.Equal(logical, document.RootElement.GetProperty("logical_content_sha256").GetString());
        Assert.Equal(source, Convert.FromBase64String(document.RootElement.GetProperty("source_base64").GetString()!));
        Assert.Equal(bytes, Convert.FromBase64String(blob.GetProperty("base64").GetString()!));
        Assert.Equal(result.Blob.Sha256, Convert.ToHexStringLower(SHA256.HashData(physical)));
        Assert.Equal(result.Blob.Bytes, physical.LongLength);
        Assert.Equal(close ? "application/vnd.bdgrz.type-ii-close-snapshot-source.v1+json" :
            "application/vnd.bdgrz.finding-snapshot-source.v1+json", result.Blob.MediaType);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void ShouldRefuseMismatchedBusinessBlobGivenSelectedSourceEnvelope(bool close)
    {
        // Arrange
        var source = Encoding.UTF8.GetBytes("bdgrz.snapshot.source.test.v1\\0{\\"events\\":[]}");
        byte[] bytes = [1, 2];
        var reference = new ImmutableContentRef(Uuid.CreateVersion4(), Convert.ToHexStringLower(SHA256.HashData(bytes)),
            2, "application/json", "source-business-test.v1");
        using var capture = SnapshotSourceCapture.Begin(Uuid.CreateVersion4());
        var logical = Convert.ToHexStringLower(SnapshotSourceCapture.HashData(source));

        // Act
        var failure = Assert.Throws<ImmutableContentIntegrityException>(() =>
            Capture(close, logical, source, [new(reference, [2, 1])]));

        // Assert
        Assert.NotEmpty(failure.Message);
        Assert.True(capture.TryGet(logical, out var preserved));
        Assert.Equal(source, File.ReadAllBytes(preserved!.Path));
    }

    static void Capture(bool close, string logical, byte[] source, IReadOnlyList<SnapshotSourceContentBlob> blobs)
    {
        if (close)
            SnapshotSourceCapture.TypeIIClose(logical, source, blobs);
        else
            SnapshotSourceCapture.Finding(logical, source, blobs);
    }
}
''');print('prepared classified selected/unselected Finding failures and family physical-envelope regressions')
