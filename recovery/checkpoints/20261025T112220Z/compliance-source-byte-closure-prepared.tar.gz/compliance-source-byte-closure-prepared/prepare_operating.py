from pathlib import Path
r=Path('/tmp/compliance-source-byte-closure-prepared');w=r/'work'
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriodCloseNativeSource.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.NativeOperations;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Snapshots;').replace('''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public DateTimeOffset? RecordedAt''','''    [JsonIgnore]
    internal IReadOnlyList<SnapshotSourceContentBlob>? PhysicalContentBlobs { get; init; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public DateTimeOffset? RecordedAt''');p.write_text(s)
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriodCloseHistory.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.SourceFacts;','using Bdgrz.Compliance.Features.SourceFacts;\nusing Bdgrz.Compliance.Features.Snapshots;\nusing Bdgrz.Compliance.Features.Proofs;');at=s.index('    public static TypeIIPeriodCloseNativeSource Capture(');s=s[:at]+'''    /// <summary>Retains only the business bodies referenced by this exact selected operating source fact.</summary>
    public async ValueTask<TypeIIPeriodCloseNativeSource> CaptureOperatingAsync(EventStreamAddress stream,
        DomainEvent fact, CancellationToken ct)
    {
        var references = new List<ImmutableContentRef>();
        var tenant = Uuid.Parse(stream.Realm, System.Globalization.CultureInfo.InvariantCulture);
        switch (fact)
        {
            case ControlOperatingPlanProposed value:
                references.Add(value.PlanContent);
                break;
            case ControlOperatingPlanApproved value:
                references.Add(value.ReassignmentsManifest);
                break;
            case ControlOccurrenceOpened value:
                references.Add(value.CreationIntent);
                references.Add(value.Intent);
                break;
            case ControlOccurrenceAttested value:
                references.Add(value.AttestationContent);
                break;
            case ControlOccurrenceReviewed value:
                references.Add(value.ReviewContent);
                break;
            case DueControlOccurrencesGenerated value:
                references.Add(value.OccurrenceIdsManifest);
                references.Add(value.CreationIntentManifest);
                references.Add(value.CurrentContent);
                var selection = await content.ReadJsonAsync<ControlOccurrenceSelectionManifest>(tenant.ToString(),
                    value.CreationIntentManifest, ct).ConfigureAwait(false);
                references.AddRange(selection.Selections.Select(item => item.Intent));
                break;
        }
        var blobs = new List<SnapshotSourceContentBlob>();
        foreach (var reference in references.Distinct())
            blobs.Add(new(reference, (await content.ReadVerifiedAsync(tenant.ToString(), reference, ct)
                .ConfigureAwait(false)).ToArray()));
        return Capture(stream, fact) with { PhysicalContentBlobs = blobs };
    }

'''+s[at:];p.write_text(s)
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriodCloseReconciliation.cs';s=p.read_text().replace('native.Add(TypeIIPeriodCloseHistory.Capture(period.Owner.Stream, fact));','native.Add(await history.CaptureOperatingAsync(period.Owner.Stream, fact, ct).ConfigureAwait(false));');s=s.replace('native.AddRange(owner.Facts.Select(fact => TypeIIPeriodCloseHistory.Capture(owner.Stream, fact)));','''foreach (var fact in owner.Facts)
                            native.Add(await history.CaptureOperatingAsync(owner.Stream, fact, ct).ConfigureAwait(false));''');s=s.replace('native.AddRange(line.Facts.Select(fact => TypeIIPeriodCloseHistory.Capture(line.Stream, fact)));','''foreach (var fact in line.Facts)
                    native.Add(await history.CaptureOperatingAsync(line.Stream, fact, ct).ConfigureAwait(false));''');p.write_text(s)
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriodCloseSourcePublication.cs';s=p.read_text();old='''        await using var stream = new MemoryStream(bytes, writable: false);
        var written = await artifacts.StoreIfAbsentAsync(period.TenantId, stream, ct).ConfigureAwait(false);
        if (written.Content.TenantId != period.TenantId || written.Content.Sha256 != digest || written.Content.Length != bytes.Length)
            throw new ImmutableContentIntegrityException("The complete close source differs from its exact published byte identity.");''';new='''        var blob = new SnapshotSourceBlob(digest, bytes.Length, "application/vnd.bdgrz.canonical-snapshot-source.v1",
            "snapshot", "Canonical Type II close source proof bytes (domain, NUL delimiter, exact complete JSON payload).");
        using var capture = SnapshotSourceCapture.Begin(period.TenantId);
        SnapshotSourceCapture.Material? material = null;
        var bodies = records.SelectMany(record => record.PhysicalContentBlobs ?? []).ToArray();
        if (bodies.Length > 0)
        {
            _ = SnapshotSourceCapture.HashData(bytes);
            SnapshotSourceCapture.TypeIIClose(digest, bytes, bodies);
            if (!capture.TryGet(digest, out material) || material is null)
                throw new ImmutableContentIntegrityException("The complete selected operating source bytes were not captured.");
            blob = material.Blob;
        }
        if (blob.Bytes > ArtifactContentLimits.MaxContentLength)
            throw new ImmutableContentIntegrityException("The complete close source exceeds supported artifact storage size.");
        await using var stream = material is null ? (Stream)new MemoryStream(bytes, writable: false)
            : new FileStream(material.Path, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, FileOptions.Asynchronous);
        var written = await artifacts.StoreIfAbsentAsync(period.TenantId, stream, ct).ConfigureAwait(false);
        if (written.Content.TenantId != period.TenantId || written.Content.Sha256 != blob.Sha256 || written.Content.Length != blob.Bytes)
            throw new ImmutableContentIntegrityException("The complete close source differs from its exact published byte identity.");''';assert old in s;s=s.replace(old,new);old='''        var blob = new SnapshotSourceBlob(digest, bytes.Length, "application/vnd.bdgrz.canonical-snapshot-source.v1",
            "snapshot", "Canonical Type II close source proof bytes (domain, NUL delimiter, exact complete JSON payload).");
        return (reference,''';assert old in s;s=s.replace(old,'        return (reference,');p.write_text(s)
print('prepared selected operating business bytes + physical-only close envelope, legacy logical bytes unchanged')
