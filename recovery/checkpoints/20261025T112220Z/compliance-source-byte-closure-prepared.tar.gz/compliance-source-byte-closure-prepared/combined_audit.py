from pathlib import Path
import json,re,hashlib
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-source-byte-closure-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()))
paths=sorted(str(f.relative_to(r/'work')) for f in (r/'work').rglob('*.cs') if not (r/'base'/f.relative_to(r/'work')).exists() or f.read_bytes()!=(r/'base'/f.relative_to(r/'work')).read_bytes())
def walk(n):
 pending=[n]
 while pending:
  x=pending.pop();yield x;pending.extend(reversed(x.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
def signature(t,n):
 ps=[x for x in n.children if x.type=='parameter'];return(sum('=' not in tx(t,x) for x in ps),len(ps))
def defs(t):
 out={}
 for n in walk(parser.parse(t).root_node):
  if n.type not in {'class_declaration','record_declaration','struct_declaration'}:continue
  nm=n.child_by_field_name('name');pl=next((x for x in n.children if x.type=='parameter_list'),None)
  if nm and pl:out.setdefault(tx(t,nm),[]).append(signature(t,pl))
  body=n.child_by_field_name('body')
  if nm and body:
   for c in body.children:
    if c.type=='constructor_declaration':
     pl=next((x for x in c.children if x.type=='parameter_list'),None)
     if pl:out.setdefault(tx(t,nm),[]).append(signature(t,pl))
 return out
sources={}
for root in [repo,Path('/tmp/compliance-system-description-prepared/work'),Path('/tmp/compliance-risk-native-prepared/work'),Path('/tmp/compliance-calendar-prepared/work'),r/'work']:
 for d in ['src','test']:
  for f in (root/d).rglob('*.cs'):
   if not {'bin','obj'}.intersection(f.parts):sources[str(f.relative_to(root))]=f
known={}
for p,f in sources.items():
 if p.startswith('src/Compliance.') and '/Features/' in p:known.update(defs(f.read_bytes()))
known={n:s for n,s in known.items() if n.startswith(('SnapshotSource','FindingTypeIBaseline','TypeIIPeriodClose','AuditPackage','ArtifactContent','LocalArtifactContentStore','PublishedTypeIBaseline','TypeIBaselinePreviewReader','AttestationInput','FindingAggregate'))}
syntax=[];removed=[];drops=[];missing=[];originalNames=0;newNames=[];tokens=[];duplicates=[];missingProofs=[];existing=0;changed=[]
def errors(t):
 return [{'line':t[:n.start_byte].count(b'\n')+1,'text':tx(t,n)} for n in walk(parser.parse(t).root_node) if n.type=='ERROR' or n.is_missing]
for p in paths:
 f=r/'work'/p;t=f.read_bytes();b=r/'base'/p
 if not b.exists() or t!=b.read_bytes():changed.append(p)
 if b.exists():existing+=1
 if parser.parse(t).root_node.has_error:
  before=errors(b.read_bytes()) if b.exists() else[];after=errors(t)
  syntax.append({'path':p,'errors':after,'baselineErrors':before,'unchangedBaselineGrammar': [x['text'] for x in before]==[x['text'] for x in after]})
 for node in walk(parser.parse(t).root_node):
  if node.type!='parameter_list':continue
  pars=[x for x in node.children if x.type=='parameter']
  for index,pa in enumerate(pars):
   typ=pa.child_by_field_name('type')
   if typ and tx(t,typ).split('.')[-1]=='CancellationToken' and index!=len(pars)-1:tokens.append({'path':p,'line':t[:pa.start_byte].count(b'\n')+1})
 usings=re.findall(r'^using .*?;$',t.decode(),re.M);duplicates.extend({'path':p,'using':u} for u in set(usings) if usings.count(u)>1)
 if re.search(r'(?<![\w.])ImmutableContentRef(?!\w)', t.decode()) and 'using Bdgrz.Compliance.Features.Proofs;' not in t.decode() and 'namespace Bdgrz.Compliance.Features.Proofs' not in t.decode() and 'Features.Proofs.ImmutableContentRef' not in t.decode():missingProofs.append(p)
 if (repo/p).exists() and not b.exists():missing.append(p)
 if b.exists() and p.startswith('test/'):
  old=b.read_text();names=re.findall(r'\b(Should\w+)\s*\(',old);originalNames+=len(names);now=re.findall(r'\b(Should\w+)\s*\(',t.decode());removed.extend({'path':p,'name':n} for n in names if n not in now);newNames.extend({'path':p,'name':n} for n in now if n not in names)
  if t.count(b'Assert.')<old.count('Assert.'):drops.append({'path':p,'before':old.count('Assert.'),'after':t.count(b'Assert.')})
 elif p.startswith('test/'):newNames.extend({'path':p,'name':n} for n in re.findall(r'\b(Should\w+)\s*\(',t.decode()))
ctor=[];count=0
for p,f in sources.items():
 t=f.read_bytes()
 if not any(n.encode() in t for n in known):continue
 tree=parser.parse(t);local=defs(t)
 aliases={a:b.split('.')[-1] for a,b in re.findall(r'^using (\w+) = ([\w.]+);$',t.decode(),re.M)}
 for n in walk(tree.root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((c for c in n.children if c.type=='argument_list'),None)
  if not typ or not args:continue
  name=tx(t,typ).split('.')[-1];name=aliases.get(name,name)
  if name not in known:continue
  num=sum(c.type=='argument' for c in args.children);count+=1;expected=local.get(name,known[name])
  if not any(a<=num<=b for a,b in expected):ctor.append({'path':p,'line':t[:n.start_byte].count(b'\n')+1,'type':name,'args':num,'expected':expected})
baselineTokens=[]
for item in tokens[:]:
 b=r/'base'/item['path']
 if b.exists() and 'CancellationToken ct,\n        IReadOnlyList<TypeIBaselineSourceCoverage>? coverage = null)' in b.read_text():
  tokens.remove(item);baselineTokens.append(item)
result={'unchangedBaselineCancellationTokenNotLast':baselineTokens,'qualification':'Static only; parent runs actual compiler/analyzers, RED/GREEN, HTTP, full suites and direct Jev review.','scannedPreparedPaths':len(paths),'changedPaths':len(changed),'existingBaselinePaths':existing,'syntaxErrors':syntax,'constructorCallsAcrossEffectiveTree':count,'constructorErrors':ctor,'cancellationTokenNotLast':tokens,'duplicateUsings':duplicates,'potentialMissingProofsUsing':missingProofs,'originalAcceptanceNames':originalNames,'removedAcceptanceNames':removed,'assertionCountDrops':drops,'existingRepositoryPathsMissingBefore':missing,'newAcceptanceNames':newNames}
(r/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
