# Local contract/qualification limits

The selected Finding and operating native facts have real existing immutable business refs and qualified source paths, so no missing contract blocks these corrections.

Source-confirmed separate contract gap: StartTypeIIObservationPeriodHandler.OpeningManifest commits plan/outcome/SystemDescription hashes, but OpeningSourceReferences and SourceContentManifest are copied from the baseline21-family source publication. That opening lane defines no separate plan/outcome/description publication entry or package-selectable source type. Do not manufacture archive selection authority; a separate selected source contract is needed if those lineage objects must be standalone package entries. No new issue was created.

No blanket sidecars are added to internal TypeII material-impact discovery proofs, binary evidence references, operation responses or unrelated native refs. Existing artifact content and source families retain their own contracts.

Parent must execute the two REDs, all focused/legacy cases, strict compiler/analyzers/format, full Category!=BrokerIntegration suite and direct per-file Jev. Active Incident overlay source-byte branch must be preserved. No preparer runtime/Jev/broker claim exists.
