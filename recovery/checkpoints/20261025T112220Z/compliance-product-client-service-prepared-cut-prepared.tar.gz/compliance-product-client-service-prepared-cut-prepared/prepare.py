from pathlib import Path
import json,hashlib
r=Path('/tmp/compliance-product-client-service-prepared-cut-prepared');frozen=Path('/tmp/compliance-product-client-service-native-prepared')
rel=Path('src/Compliance.Core/Features/Programs/ProductClientServiceOperations.cs');before=(frozen/'work'/rel).read_bytes()
for tree in ['base','work']:
 p=r/tree/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(before)
s=before.decode().replace('        ImmutableContentRef? frozenResult = null;','        ImmutableContentRef? frozenResult = null;\n        PreparedCut? preparedCut = null;')
s=s.replace('                    frozenResult = frozen.Result;\n                    return','                    frozenResult = frozen.Result;\n                    preparedCut = PreparedCut.Of(owner);\n                    return')
old='''                }, (owner, first) => intent switch
                {
                    CreateClientService create => owner.Create(operation, create.ProgramId, preparedContent!, first, frozenResult!),
                    ReviseClientService => owner.Revise(operation, preparedContent!, first, frozenResult!),
                    RetireClientService => owner.Retire(operation, preparedContent!, first, frozenResult!),
                    _ => throw new InvalidOperationException("Another service command."),
                }), context, ct).ConfigureAwait(false);'''
new='''                }, (owner, first) =>
                {
                    if (preparedCut != PreparedCut.Of(owner))
                        return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The service source cut changed while its native operation was prepared.", true));
                    return intent switch
                    {
                        CreateClientService create => owner.Create(operation, create.ProgramId, preparedContent!, first, frozenResult!),
                        ReviseClientService => owner.Revise(operation, preparedContent!, first, frozenResult!),
                        RetireClientService => owner.Retire(operation, preparedContent!, first, frozenResult!),
                        _ => throw new InvalidOperationException("Another service command."),
                    };
                }), context, ct).ConfigureAwait(false);'''
assert old in s;s=s.replace(old,new)
at=s.rfind('\n}')
s=s[:at]+'''
    sealed record PreparedCut(ulong Version, ulong Position, string PayloadDigest, string MetadataDigest)
    {
        public static PreparedCut Of(ClientService owner) => new(owner.Version, owner.CommittedStreamPosition,
            owner.NativeCut.Digest, owner.NativeCut.MetadataDigest);
    }
'''+s[at:]
(r/'work'/rel).write_text(s)
(r/'baselines.json').write_text(json.dumps([{'path':str(rel),'baselineSource':str(frozen/'work'/rel),'beforeSha256':hashlib.sha256(before).hexdigest(),'prerequisiteHandoffSha256':'25d912f6e4876b68562782209ab80ef83c38dcb16a24f6f039edd5bc4b085f72'}],indent=2)+'\n')
