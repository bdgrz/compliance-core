from pathlib import Path
import json,hashlib,difflib,subprocess,shutil
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-product-client-service-prepared-cut-prepared');h=lambda b:hashlib.sha256(b).hexdigest();parser=Parser(Language(tree_sitter_c_sharp.language()))
paths=sorted(str(p.relative_to(r/'work')) for p in (r/'work').rglob('*.cs'));assert len(paths)==2
rows=[]
def patch(selected):
 out=[]
 for p in selected:
  b=r/'base'/p;before=b.read_text().splitlines(True) if b.exists() else[];after=(r/'work'/p).read_text().splitlines(True)
  assert not parser.parse(''.join(after).encode()).root_node.has_error,p
  out.append('diff --git a/'+p+' b/'+p+'\n')
  if not b.exists():out.append('new file mode 100644\n')
  out.extend(difflib.unified_diff(before,after,fromfile='a/'+p if b.exists() else'/dev/null',tofile='b/'+p))
 return ''.join(out)
for p in paths:
 b=r/'base'/p;after=(r/'work'/p).read_bytes();rows.append({'path':p,'beforeSha256':h(b.read_bytes()) if b.exists() else None,'afterSha256':h(after),'beforeSource':str(b) if b.exists() else None,'afterSource':str(r/'work'/p)})
source=[p for p in paths if p.startswith('src/')];tests=[p for p in paths if p.startswith('test/')]
exports={'implementation.patch':patch(source),'tests.clean.patch':patch(tests),'old-api-red.patch':patch(tests),'full.clean.patch':patch(paths)}
for n,t in exports.items():(r/n).write_text(t)
for label,names in [('full',['full.clean.patch']),('partition',['tests.clean.patch','implementation.patch'])]:
 d=r/'reconstruction'/label
 if d.exists():shutil.rmtree(d)
 d.mkdir(parents=True)
 for row in rows:
  b=r/'base'/row['path']
  if b.exists():p=d/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b.read_bytes())
 for n in names:
  x=subprocess.run(['patch','-p1','--batch','--fuzz=0','-i',str(r/n)],cwd=d,capture_output=True,text=True);assert x.returncode==0,x.stdout+x.stderr
 for row in rows:assert h((d/row['path']).read_bytes())==row['afterSha256']
(r/'manifest.json').write_text(json.dumps({'status':'FROZEN','paths':rows,'sourceBaseline':'Exact frozen ProductClientService50 after-source','qualification':'Static parsing and2patch reconstructions only; A/B regression candidate pending parent runtime against50 before own delta.'},indent=2)+'\n')
files={n:{'path':str(r/n),'sha256':h((r/n).read_bytes())} for n in [*exports,'manifest.json','README.md']}
(r/'handoff.json').write_text(json.dumps({'status':'FROZEN','artifact':str(r),'paths':2,'production':1,'tests':1,'prerequisite':'/tmp/compliance-product-client-service-native-prepared/handoff.json SHA25d912f6e4876b68562782209ab80ef83c38dcb16a24f6f039edd5bc4b085f72','oldApiRedFilter':'FullyQualifiedName~ProductClientServicePreparedCutTests','oldApiRedQualification':'Uses only frozen50 APIs,1coherent A/B regression; no shared helper/route/DTO changes. Parent mustqualifybeforeapplying source delta.','apply':'Install tests.clean.patch againstProduct50, qualifyoldAPI RED, thenimplementation.patch; full.clean.patch equivalentfinalsource.','files':files,'runtime':'No agent .NET/Jev/Git/main operation; all runtimeparent-owned.'},indent=2)+'\n');print(json.dumps({'handoffSha256':h((r/'handoff.json').read_bytes()),'manifestSha256':h((r/'manifest.json').read_bytes()),'exports':{n:h((r/n).read_bytes()) for n in exports}},indent=2))
