from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
p=Path('/tmp/compliance-risk-method-prepared');base=p/'base';work=p/'work'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None
allpaths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
shared=['src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs']
impl=[r for r in allpaths if r.startswith('src/') and r not in shared];tests=[r for r in allpaths if r.startswith('test/')]
redrel='test/Compliance.Tests/Features/Risks/RiskMethodPublicationTests.cs';red=p/'behavioral-red-source.cs'
def make(name,items,fromred=False):
 text=[]
 for r in items:
  a=base/r;b=work/r
  old=red if fromred and r==redrel else a
  text+=difflib.unified_diff(old.read_text().splitlines(True) if old.exists() else [],b.read_text().splitlines(True),fromfile='a/'+r if old.exists() else '/dev/null',tofile='b/'+r)
 q=p/name;q.write_text(''.join(text));return {'path':str(q),'sha256':sha(q),'paths':items}
arts={}
arts['implementation.patch']=make('implementation.patch',impl)
arts['tests.patch']=make('tests.patch',tests)
arts['shared.patch']=make('shared.patch',shared)
arts['full.patch']=make('full.patch',allpaths)
redpatch=p/'behavioral-red.patch';redpatch.write_text(''.join(difflib.unified_diff([],red.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+redrel)))
arts['behavioral-red.patch']={'path':str(redpatch),'sha256':sha(redpatch),'paths':[redrel]}
arts['green-after-red.patch']=make('green-after-red.patch',allpaths,True)
checks=[]
for label,sequence in [('full',['full.patch']),('staged',['behavioral-red.patch','green-after-red.patch']),('split',['implementation.patch','tests.patch','shared.patch'])]:
 dest=p/'verify'/label
 if dest.exists():shutil.rmtree(dest)
 shutil.copytree(base,dest)
 for patch in sequence:
  result=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,text=True,capture_output=True)
  if result.returncode:raise RuntimeError(result.stdout+result.stderr)
 assert all(sha(dest/r)==sha(work/r) for r in allpaths)
 checks.append({'sequence':sequence,'exact':True,'paths':len(allpaths)})
checksReport=json.loads((p/'static-checks.json').read_text())
report={'paths':[{'path':r,'before':sha(base/r),'after':sha(work/r)} for r in allpaths],'artifacts':arts,'reconstruction':checks,'static':checksReport,'prerequisites':['Risk109 native Draft/Evaluation owner cutover','Risk source bytes six-file overlay','Small3 NativeOwnerHistory common helper SHA256 9c7a81dd90f42109065c2d784c39b1a97a72803c7f7554a8d48cd6e5006bd65c'],'shared':'Compose by shared-wiring-deltas.json; full shared baselines are context only and must preserve latest merged owners. Test ProgramManagementServices gains only method reader + Rules seeding overloads.','runtime':'Not run; root owns all runtime/strict/format/Jev checks.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n')
(p/'behavioral-red-filter.txt').write_text('FullyQualifiedName~RiskMethodPublicationTests.ShouldReplayOriginalPublicationGivenLaterVersionAndMovedClock\n')
(p/'focused-filter.txt').write_text('FullyQualifiedName~RiskMethod|FullyQualifiedName~RiskTypeIBaselineSourceContributor|FullyQualifiedName~RiskAcceptanceWork|FullyQualifiedName~RiskGovernanceHandler|FullyQualifiedName~RiskAssessmentIdentity|FullyQualifiedName~RiskAcceptanceIdentity|FullyQualifiedName~RiskTreatmentIdentity|FullyQualifiedName~WorkSourceComposition|FullyQualifiedName~ProviderAssurance\n')
print(json.dumps({'paths':len(allpaths),'source':len(impl),'tests':len(tests),'shared':len(shared),'reconstruction':checks,'artifacts':arts},indent=2))
