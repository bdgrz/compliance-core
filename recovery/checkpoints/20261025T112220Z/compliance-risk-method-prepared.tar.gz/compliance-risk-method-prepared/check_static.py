from pathlib import Path
import re,json,os,subprocess
p=Path('/tmp/compliance-risk-method-prepared');files=list((p/'work').rglob('*.cs'))
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
parser=Parser(Language(tree_sitter_c_sharp.language()))
files=list(Path("/tmp/compliance-risk-method-prepared/work").rglob("*.cs"))
print(json.dumps({"files":len(files),"errors":[str(f) for f in files if parser.parse(f.read_bytes()).root_node.has_error]}))
'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')))
assert not syntax['errors']
# Stable older parser only walks explicit new object constructors; SDK-backed definitions are checked separately.
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()))
heads={}
search=list((p/'work').rglob('*.cs'))+list(Path('/tmp/compliance-risk-native-prepared/work').rglob('*.cs'))+list(Path('/Users/jrepanich/Code/bdgrz/compliance-core/src').rglob('*.cs'))
for f in search:
 text=f.read_text()
 for name,params in re.findall(r'\b(?:public|internal|private)\s+(?:sealed\s+)?class\s+(\w+)\s*\(([^\n]*?(?:\n[^{}]*?)?)\)\s*(?::|\{)',text):
  pass
# Relevant migrated declarations and calls: exact string signatures/argument counts reported for parent review.
ctorNames=['RiskMethod','RiskMethodReader','RiskMethodReassessmentReactor','PublishRiskMethodVersionHandler','GetRiskMethodHandler','GetRiskMethodVersionHandler','RiskEvaluationOperations','RiskAcceptanceWorkItemDirectory','RiskMethodReadSnapshot','RiskMethodPublicationContent']
expected={'RiskMethod':(2,3),'RiskMethodReader':(3,3),'RiskMethodReassessmentReactor':(6,6),'PublishRiskMethodVersionHandler':(4,4),'GetRiskMethodHandler':(1,1),'GetRiskMethodVersionHandler':(1,1),'RiskEvaluationOperations':(6,6),'RiskAcceptanceWorkItemDirectory':(7,7),'RiskMethodReadSnapshot':(2,2),'RiskMethodPublicationContent':(2,2)}
issues=[];calls=[]
def walk(n):
 stack=[n]
 while stack:
  current=stack.pop()
  yield current
  stack.extend(current.children)
for f in files:
 data=f.read_bytes();tree=parser.parse(data)
 for n in walk(tree.root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=n.child_by_field_name('arguments')
  if not typ or not args:continue
  name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
  if name not in expected:continue
  count=len([c for c in args.named_children if c.type=='argument']);calls.append({'path':str(f.relative_to(p/'work')),'type':name,'arguments':count})
  low,high=expected[name]
  if not low<=count<=high:issues.append(calls[-1])
preserved=[];added=[]
for before in (p/'base/test').rglob('*.cs'):
 after=p/'work'/before.relative_to(p/'base')
 if not after.exists():continue
 names=lambda q:set(re.findall(r'\b(Should\w+)\s*\(',q.read_text()))
 old=names(before);new=names(after);assert old<=new,(str(before),old-new)
 if before.read_text().count('Assert.')>after.read_text().count('Assert.'):issues.append({'assertionsReduced':str(before)})
 preserved+=sorted(old);added+=sorted(new-old)
assert not issues,issues
report={'syntax':syntax,'constructorCalls':calls,'issues':issues,'preservedAcceptanceNames':len(preserved),'addedExistingFixtureNames':added,'runtime':'Not run; parent exclusive slot.'}
(p/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'syntax':syntax,'constructorCalls':len(calls),'preserved':len(preserved),'issues':issues}))
