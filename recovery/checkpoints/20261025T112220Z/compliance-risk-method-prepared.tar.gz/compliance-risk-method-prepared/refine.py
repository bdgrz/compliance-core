from pathlib import Path
p=Path('/tmp/compliance-risk-method-prepared')
def f(rel):return p/'work'/rel
q=f('src/Compliance.Core/Features/Risks/RiskMethodPublicationContent.cs');q.write_text('''namespace Bdgrz.Compliance.Features.Risks;

/// <summary>The exact authored publication and immutable version it produced.</summary>
public sealed record RiskMethodPublicationContent(PublishRiskMethodVersion Request, RiskMethodVersionView Version);
''')
q=f('src/Compliance.Core/Features/Risks/PublishRiskMethodVersionHandler.cs');s=q.read_text().replace('using Bdgrz.Compliance.Features.Proofs;', 'using Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Features.Versioning;').replace('new RequestError(RequestErrorKind.Validation, validation.Message)', 'validation.ToRequestError()').replace('RiskMethodContent.Schema, version, token)', 'RiskMethodContent.Schema, new RiskMethodPublicationContent(request, version), token)');q.write_text(s)
q=f('src/Compliance.Core/Features/Risks/RiskMethodContent.cs');s=q.read_text().replace('using Bdgrz.Compliance.Features.Content;', 'using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;')
s=s.replace('fact.FirstResponse is null || fact.OperationResult is null || fact.Operation is null', '''fact.FirstResponse is not { Schema: FirstResponses.Schema } ||
            fact.OperationResult is not { Schema: "mutation-result-content.v1" } ||
            fact.Operation?.Actor is not { Kind: "member" } actor || !Uuid.TryParse(actor.Id, out var member) || member == Uuid.Empty''')
s=s.replace('''var version = await NativeContent.ReadAsync<RiskMethodVersionView>(content, fact.TenantId, fact.Content, ct).ConfigureAwait(false);''','''var publication = await NativeContent.ReadAsync<RiskMethodPublicationContent>(content, fact.TenantId, fact.Content, ct).ConfigureAwait(false);
        if (publication is not { Request: { } request, Version: { } version } ||
            request.TenantId != fact.TenantId || request.ProgramId != fact.ProgramId ||
            request.ExpectedVersion != fact.PublishedVersion - 1 ||
            AuthoredIntentDigest.Compute(request) != fact.Operation.AuthoredIntentSha256)
            throw new ImmutableContentIntegrityException("The publication differs from its exact original authored intent.");''')
s=s.replace('''        return version;
    }''','''        var rules = new RiskMethodRules(fact.TenantId, fact.ProgramId);
        var failure = rules.Publish(fact.ProgramId, 0, request.LikelihoodScale, request.ImpactScale,
            request.AppetiteThreshold, fact.Operation.Actor, fact.Operation.AcceptedAt);
        var expected = rules.Current! with { Version = version.Version, MethodVersionId = version.MethodVersionId };
        if (failure is not null || AuthoredIntentDigest.Compute(expected) != AuthoredIntentDigest.Compute(version))
            throw new ImmutableContentIntegrityException("The published method does not reproduce its exact original business transition.");
        return version;
    }''')
# Do not dereference rules.Current if validation failed.
s=s.replace('''        var expected = rules.Current! with { Version = version.Version, MethodVersionId = version.MethodVersionId };
        if (failure is not null || AuthoredIntentDigest.Compute(expected) != AuthoredIntentDigest.Compute(version))''','''        if (failure is not null || rules.Current is not { } first)
            throw new ImmutableContentIntegrityException("The original method publication violates its business rules.");
        var expected = first with { Version = version.Version, MethodVersionId = version.MethodVersionId };
        if (AuthoredIntentDigest.Compute(expected) != AuthoredIntentDigest.Compute(version))''')
q.write_text(s)
q=f('src/Compliance.Core/Features/Risks/RiskMethodRules.cs');s=q.read_text().replace('    public IReadOnlyList<RiskMethodVersionView> Versions', '''    int _originalVersion;
    public IReadOnlyList<RiskMethodVersionView> PendingVersions => _versions.Skip(_originalVersion).ToArray();
    public static RiskMethodRules FromVersions(Uuid tenant, Uuid program, IReadOnlyList<RiskMethodVersionView> versions)
    {
        var rules = new RiskMethodRules(tenant, program);
        rules._versions.AddRange(versions);
        rules._originalVersion = versions.Count;
        return rules;
    }
    public IReadOnlyList<RiskMethodVersionView> Versions''');q.write_text(s)
q=f('src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs');s=q.read_text()
s=s.replace('''                !ValidMetadata(metadata, methodId, expectedVersion, seenEventIds) ||''','''                !ValidMetadata(metadata, methodId, metadata.IsAudit ? expectedVersion - 1 : expectedVersion, seenEventIds) ||''')
s=s.replace('''                context.RecordedThrough is null && priorRecordedAt is { } prior && metadata.OccurredOn < prior ||
                record.Event is not RiskMethodVersionPublished published ||
                !TryMethodEvent(published, tenantId, programId, versions.Count + 1,
                    out var occurredAt))
                return InvalidHistory<MethodHistory>();
            var publishedVersion''','''                context.RecordedThrough is null && priorRecordedAt is { } prior && metadata.OccurredOn < prior)
                return InvalidHistory<MethodHistory>();
            if (metadata.IsAudit)
                continue;
            if (record.Event is not RiskMethodVersionPublished published || published.TenantId != tenantId ||
                published.ProgramId != programId || published.PublishedVersion != versions.Count + 1)
                return InvalidHistory<MethodHistory>();
            var publishedVersion''')
s=s.replace('!ValidMethodVersion(publishedVersion, tenantId, programId, expectedVersion)', '!ValidMethodVersion(publishedVersion, tenantId, programId, versions.Count + 1)').replace('''var isAsOf = context.RecordedThrough is null ? occurredAt <= through && metadata.OccurredOn <= through :''','''var isAsOf = context.RecordedThrough is null ? publishedVersion.PublishedAt <= through && metadata.OccurredOn <= through :''',1 if False else 0)
# Narrow replacement: only method loop, not evaluation effective time.
a=s.index('async ValueTask<Result<MethodHistory>>');b=s.index('async ValueTask<Result<GovernanceHistory>>',a)
part=s[a:b].replace('occurredAt <= through','publishedVersion.PublishedAt <= through');s=s[:a]+part+s[b:]
a=s.index('    static bool TryMethodEvent(');b=s.index('    static bool ValidMethodVersion',a);s=s[:a]+s[b:]
q.write_text(s)
