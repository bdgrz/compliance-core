# RiskMethod compact native publication: stage 1 of the remaining risk owner group

Frozen artifact metadata: `handoff.json`. This stage completes the existing RiskMethod owning publication, current/version reads, exact source read and reassessment reactor, plus their actual Risk109/Work/test consumers. It does **not** claim RiskGovernance, RiskTreatmentAssertion or RiskTreatmentAction compaction; those are subsequent independent work.

No main edits, dotnet/format/build/runtime tests, git/Jev calls or issues were performed by this agent. Parent owns all runtime qualification.

## Prerequisites and staged RED

This follows (1) Risk109 native Draft/Evaluation cutover, (2) `/tmp/compliance-risk-source-bytes-prepared`, preserving the merged native receipt source overlay, and (3) the common `NativeOwnerHistory` from the frozen small3 compaction package, SHA256 `9c7a81dd90f42109065c2d784c39b1a97a72803c7f7554a8d48cd6e5006bd65c`.

The standalone `behavioral-red.patch` adds only an old-API test fixture with the current old handler/read constructors. Apply it and run `behavioral-red-filter.txt`: publishing version 1, publishing version 2, moving the clock and retrying the identical original command currently returns a stale version conflict. The test requires the original immutable result and leaves version 2 current. It uses no new production symbols. Then apply `green-after-red.patch`, composing newer shared files by `shared-wiring-deltas.json`. Full, staged and split patch reconstruction all match every final hash. `implementation.patch` + `tests.patch` + `shared.patch` are the direct alternative.

## Owner, identity and original result

RiskMethod now keeps one latest native fact and selected NativeAcceptance. It retains no versions, narrative lists, lifetime operation ledger or aggregate.Current compatibility shim. `RiskMethodRules` is explicit non-owner business/read/test composition. Publication needs only the scalar original version gate; current reads verify the latest immutable body, without reading old narratives.

The existing public command retains exactly its JSON fields. Its explicit IIdentifiedRequest.RequestId is derived from the exact tenant/program method owner plus the original ExpectedVersion slot, allowing the installed native HTTP observer/bridge to return the real frozen 200 result. The handler uses that same identity, full authored intent, actor, expected revision, first/affected/revision owner and explicit FirstOwner. Exact acceptance resolves before mutable program/version checks. Changed payload or actor under an already accepted slot conflicts. No new public route, lookup contract or claimed realm-wide identity authority is introduced.

Async native preparation checks the program and original gate, publishes an immutable RiskMethodPublicationContent containing the exact authored request and resulting version, and freezes both the typed result and MutationResultContent envelope before append. The body reader reproduces the complete business transition and verifies scope, deterministic version identity, original author/time/intent, cleaned descriptors and appetite. Storage absence is transient, corruption permanent. The original result remains stable after later versions and clock movement.

The actual persisted RiskMethodVersionPublished discriminator advances from version 1 to version 2 with compact content/operation/result references. No legacy event conversion or dual reader is shipped. Pre-release retained histories require deliberate disposal or a separately selected migration contract; nothing here claims existing old persisted history qualifies. RiskMethod is absent from the final selected refactor catalogs, so this implementation does not invent catalog completion counts or proposed fields/events.

## Verified reads, reactor, source and consumers

RiskMethodReader(reader, events, content).ReadAsync(tenant, program) composes RiskMethodReadSnapshot(Versions,Facts) at the hydrated owner's exact physical/native cut via NativeOwnerHistory. Its Current/GetVersion/Find are read composition only. CurrentAsync reads only the latest immutable version. Existing current/version HTTP GET routes use these authoritative reads and retain current program authorization.

The reassessment reactor verifies the bound tenant/program stream, exact committed event identity, full metadata and concrete native payload before any first-version suppression or fan-out. It uses the verified original method version and existing deterministic effect identities. Directory/source gates and native Risk109 fan-out behavior remain in place.

All actual consumers are migrated: queued RiskEvaluationOperations assessment/acceptance prepares, RiskAcceptanceWork, owning work directory and queue, Risk source contributor, method read handlers and reassessment reactor. The source contributor validates the immutable publication and captures its exact bytes using the frozen physical source envelope API. Existing authenticated recorded-through selection is preserved, with audit-aware native version accounting; ordinary null-cutoff reads do not introduce receipt calls. No live-current method substitute is used for a cited historical version.

Tests retain their existing names and business assertions by composing RiskMethodRules or publishing through RiskMethodSeeds. The shared test fixture seeds real native facts/content/results, rather than reintroducing old aggregate constructors. New tests cover original retry, changed actor/intent, 128 sequential publications and old result replay, missing/corrupt current content, forged scope/original intent, original request whitespace, and no-op/forged committed reactor sources.

## Static evidence and integration details

36 C# files parse; 29 relevant explicit constructor calls match their new signatures. 76 captured original acceptance names remain, with no assertion reduction. All 36 paths reconstruct exactly from full, split or RED/green patch sequences. These are static checks, not compiler or runtime claims.

`shared-wiring-deltas.json` is authoritative for shared composition: add RiskMethodReader to production DI; add RiskMethodPublicationContent to generated JSON; preserve all global OnNativeResult routes and newer owner registrations. Test ProgramManagementServices adds RiskMethodReader and explicit Rules hydrate/seed overloads. WorkQueueReader adds its final optional method reader; actual risk paths fail closed if required native readers are absent. Its copied baseline includes Risk109 and must be merged as a delta over newer queued shared owner seams.

Parent must run the supplied old-code RED, strict build/format, supplied focused filter/full suite and direct per-file Jev before qualifying or merging. No external dependency blocker was found for this owning publication/read/reactor slice.
