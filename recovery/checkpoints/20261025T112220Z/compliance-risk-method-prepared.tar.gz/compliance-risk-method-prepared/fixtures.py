from pathlib import Path
import shutil
p=Path('/tmp/compliance-risk-method-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');risk=Path('/tmp/compliance-risk-native-prepared/work')
# Existing tests retain pure business coverage through the extracted non-owner rules.
for f in (p/'work/test').rglob('*.cs'):
 s=f.read_text().replace('new RiskMethod(', 'new RiskMethodRules(')
 s=s.replace('new AggregateScenario<RiskMethod>(method).PendingEvents.Count','method.PendingVersions.Count')
 s=s.replace('''new AggregateScenario<RiskMethod>(method).PendingEvents.ToArray()''','''new AggregateScenario<RiskMethod>(await RiskMethodSeeds.OwnerAsync(content, method)).PendingEvents.ToArray()''')
 if 'RiskMethodSeeds.' in s and 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
 f.write_text(s)
# Test composition is a shared delta; parent must preserve newer registration/owner overlays.
rel='test/Compliance.Tests/Testing/ProgramManagementServices.cs';origin=risk/rel if (risk/rel).exists() else repo/rel
for part in ['base','work']:
 f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,f)
f=p/'work'/rel;s=f.read_text();marker='        services?.Invoke(collection);';s=s.replace(marker,'        collection.AddScoped<RiskMethodReader>();\n'+marker)
marker='    public static async Task SeedAsync(IServiceProvider provider, ControlRules selected,'
addition='''    public static async Task<RiskMethodRules> HydrateAsync(IServiceProvider provider, RiskMethodRules selected)
    {
        await using var scope = provider.CreateAsyncScope();
        var snapshot = await scope.ServiceProvider.GetRequiredService<RiskMethodReader>()
            .ReadAsync(selected.TenantId, selected.ProgramId);
        return RiskMethodRules.FromVersions(selected.TenantId, selected.ProgramId, snapshot.Versions);
    }

    public static async Task SeedAsync(IServiceProvider provider, RiskMethodRules selected,
        Func<RiskMethodRules, Result> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var rules = await HydrateAsync(provider, selected);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await RiskMethodSeeds.AppendAsync(scope.ServiceProvider.GetRequiredService<IAggregateReader>(),
            scope.ServiceProvider.GetRequiredService<IAggregateWriter>(),
            scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), rules);
    }

'''
s=s.replace(marker,addition+marker);f.write_text(s)
# Explicit source/reader ctor seams.
for f in (p/'work/test').rglob('*.cs'):
 s=f.read_text()
 # Existing direct directory tests already supply native evaluation reader as final argument.
 s=s.replace('scope.ServiceProvider.GetRequiredService<RiskEvaluationReader>());', 'scope.ServiceProvider.GetRequiredService<RiskEvaluationReader>(), scope.ServiceProvider.GetRequiredService<RiskMethodReader>());') if 'new RiskAcceptanceWorkItemDirectory' in s else s
 s=s.replace('provider.GetRequiredService<RiskEvaluationReader>()));','provider.GetRequiredService<RiskEvaluationReader>(), provider.GetRequiredService<RiskMethodReader>()));') if 'new RiskAcceptanceWorkItemDirectory' in s else s
 # Named WorkQueue optional ports retain source compatibility; tests that exercise risks need authoritative method source.
 if 'riskEvaluations:' in s and 'new WorkQueueReader' in s:
  import re
  s=re.sub(r'riskEvaluations:\s*([^\n]+?)\)\)',r'riskEvaluations: \1, riskMethods: scope.ServiceProvider.GetRequiredService<RiskMethodReader>()))',s) if False else s
 f.write_text(s)
# Native test publication helpers: immutable bytes and exact provenance are produced through the same content seams.
f=p/'work/test/Compliance.Tests/Testing/RiskMethodSeeds.cs'
f.write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

static class RiskMethodSeeds
{
    public static async Task<RiskMethod> OwnerAsync(IImmutableContentStore content, RiskMethodRules rules)
    {
        var owner = new RiskMethod(rules.TenantId, rules.ProgramId);
        foreach (var version in rules.Versions)
            await ApplyAsync(content, owner, version);
        return owner;
    }

    public static async Task AppendAsync(IAggregateReader reader, IAggregateWriter writer,
        IImmutableContentStore content, RiskMethodRules rules)
    {
        var owner = await reader.HydrateAsync(new RiskMethod(rules.TenantId, rules.ProgramId));
        foreach (var version in rules.PendingVersions)
        {
            await ApplyAsync(content, owner, version);
            await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System));
        }
    }

    static async Task ApplyAsync(IImmutableContentStore content, RiskMethod owner, RiskMethodVersionView version)
    {
        var request = new PublishRiskMethodVersion(version.TenantId, version.ProgramId, version.Version - 1,
            version.LikelihoodScale, version.ImpactScale, version.AppetiteThreshold);
        var operation = RootOperation.Provenance(((IIdentifiedRequest)request).RequestId, nameof(PublishRiskMethodVersion),
            owner.Stream, version.PublishedBy, request.ExpectedVersion, AuthoredIntentDigest.Compute(request), version.PublishedAt)
            with { FirstOwner = owner.Stream };
        var body = await NativeContent.WriteAsync(content, version.TenantId, RiskMethodContent.Schema,
            new RiskMethodPublicationContent(request, version));
        var response = await NativeContent.FreezeAsync(content, version.TenantId, RiskMethodContent.ResultSchema, version);
        var first = await FirstResponses.FreezeAsync(content, version.TenantId.ToString(), response.Response);
        var outcome = owner.Append(operation, body, first, response.Result);
        Assert.True(outcome.IsSuccess, outcome.Error?.Message);
    }
}
''')
