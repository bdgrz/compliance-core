from pathlib import Path
import shutil,json
p=Path('/tmp/compliance-risk-method-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
for rel in ['src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs']:
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,f)
f=p/'work/src/Compliance.Core/ComplianceCoreJsonContext.cs';s=f.read_text();marker='[JsonSerializable(typeof(RiskMethodVersionPublished))]';assert marker in s;s=s.replace(marker,marker+'\n[JsonSerializable(typeof(RiskMethodPublicationContent))]');f.write_text(s)
f=p/'work/src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';s=f.read_text();marker='        services.AddScoped<RiskGovernanceReader>();';assert marker in s;s=s.replace(marker,marker+'\n        services.AddScoped<RiskMethodReader>();');f.write_text(s)
delta={'productionDI':['AddScoped<RiskMethodReader>()'],'productionJSON':['JsonSerializable(typeof(RiskMethodPublicationContent))'],'routes':'Existing risk-method POST/current GET/version GET remain mapped and keep global OnNativeResult transport bridge. DTO now implements computed IIdentifiedRequest.RequestId without a JSON field.','fixtureDI':['ProgramManagementServices: AddScoped<RiskMethodReader>()'],'constructors':{'PublishRiskMethodVersionHandler':'(NativeOperationExecutor, IAggregateReader, IImmutableContentStore, TimeProvider)','GetRiskMethodHandler':'(RiskMethodReader)','GetRiskMethodVersionHandler':'(RiskMethodReader)','RiskMethodReassessmentReactor':'Existing5+RiskMethodReader','RiskEvaluationOperations':'Existing5+RiskMethodReader','RiskAcceptanceWorkItemDirectory':'Existing6+RiskMethodReader','WorkQueueReader':'Adds final optional RiskMethodReader? riskMethods=null; actual risk branch requires it.'}}
(p/'shared-wiring-deltas.json').write_text(json.dumps(delta,indent=2)+'\n')
