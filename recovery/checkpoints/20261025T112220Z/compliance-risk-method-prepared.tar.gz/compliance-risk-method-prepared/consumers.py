from pathlib import Path
import shutil
p=Path('/tmp/compliance-risk-method-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');risk=Path('/tmp/compliance-risk-native-prepared/work')
def existing(rel):
 if not (p/'base'/rel).exists():
  origin=risk/rel if (risk/rel).exists() else repo/rel
  for part in ['base','work']:
   dest=p/part/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,dest)
 return p/'work'/rel
f=existing('src/Compliance.Core/Features/Risks/RiskEvaluationOperations.cs');s=f.read_text().replace('NativeOperationExecutor operations, IImmutableContentStore content, TimeProvider clock)', 'NativeOperationExecutor operations, IImmutableContentStore content, TimeProvider clock, RiskMethodReader methodSources)')
s=s.replace('await reader.HydrateAsync(new RiskMethod(request.TenantId, request.ProgramId), token)', 'await methodSources.ReadAsync(request.TenantId, request.ProgramId, token)');f.write_text(s)
f=existing('src/Compliance.Core/Features/Work/RiskAcceptanceWork.cs');s=f.read_text().replace('RiskEvaluationReader? evaluationSources, CancellationToken ct)', 'RiskEvaluationReader? evaluationSources, RiskMethodReader? methodSources, CancellationToken ct)')
s=s.replace('if (evaluationSources is null)', 'if (evaluationSources is null || methodSources is null)').replace('await reader.HydrateAsync(new RiskMethod(tenantId, programId), ct)', 'await methodSources.ReadAsync(tenantId, programId, ct)').replace('RiskMethod methods,','RiskMethodReadSnapshot methods,');f.write_text(s)
f=existing('src/Compliance.Core/Features/Work/WorkQueueReader.cs');s=f.read_text().replace('RiskEvaluationReader? riskEvaluations = null)', 'RiskEvaluationReader? riskEvaluations = null,\n    RiskMethodReader? riskMethods = null)').replace('workItemId, riskEvaluations, ct)', 'workItemId, riskEvaluations, riskMethods, ct)');f.write_text(s)
f=existing('src/Compliance.Core/Features/Work/RiskAcceptanceWorkItemDirectory.cs');s=f.read_text().replace('RiskEvaluationReader evaluationSources)', 'RiskEvaluationReader evaluationSources, RiskMethodReader methodSources)').replace('workItemId, evaluationSources, ct)', 'workItemId, evaluationSources, methodSources, ct)');f.write_text(s)
f=existing('src/Compliance.Core/Features/Risks/RiskMethodReassessmentReactor.cs');s=f.read_text().replace('using Cntryl.Portia;', 'using Cntryl.Portia;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;\nusing Bdgrz.Compliance.Features.NativeOperations;')
s=s.replace('RiskDraftListReadConsistency consistency)', 'RiskDraftListReadConsistency consistency, RiskMethodReader methods)')
s=s.replace('''        var version = context.Trigger.Version;
        if (version.Version <= 1)''','''        var source = context.Trigger;
        var stream = new RiskMethod(source.TenantId, source.ProgramId).Stream;
        if (Pattern.IsTenantTemplate || Pattern.Realm != source.TenantId.ToString() || context.Source.Stream != stream)
            throw new ImmutableContentIntegrityException("A method reaction must originate from its exact tenant and program owner.");
        var snapshot = await methods.ReadAsync(source.TenantId, source.ProgramId, ct).ConfigureAwait(false);
        var actual = snapshot.Facts.SingleOrDefault(fact => fact.Metadata.EventId == source.Metadata.EventId);
        if (actual is null)
            throw new ImmutableContentUnavailableException("The exact method publication is not visible yet.");
        if (NativeFactReference.Of(stream, actual) != NativeFactReference.Of(stream, source) ||
            ContentDigest.OfJson(actual) != ContentDigest.OfJson(source))
            throw new ImmutableContentIntegrityException("A method reaction differs from its exact committed publication.");
        var version = snapshot.GetVersion(actual.PublishedVersion)!;
        if (version.Version <= 1)''');f.write_text(s)
f=existing('src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs');s=f.read_text()
s=s.replace('''            if (record.Event is not RiskMethodVersionPublished published ||
                !ValidMethodVersion(published.Version, tenantId, programId, expectedVersion))''','''            if (record.Event is not RiskMethodVersionPublished published ||
                !RiskMethodContent.ValidNative(published))''')
# Exact prior loop code is mechanically rewritten around the selected native content.
a=s.index('        await foreach (var record in events.ReadAsync(stream, 0, ct).ConfigureAwait(false))',s.index('async ValueTask<Result<MethodHistory>>'))
b=s.index('        return Result<MethodHistory>.Success',a)
old=s[a:b]
# Presence shape validated below; replace only method-local legacy Version references.
old=old.replace('''record.Event is not RiskMethodVersionPublished published ||''','''record.Event is not RiskMethodVersionPublished published ||''')
old=old.replace('!ValidMethodVersion(published.Version, tenantId, programId, expectedVersion)', '!RiskMethodContent.ValidNative(published)')
# Insert verified immutable composition once the event type/scope has been checked.
needle='''            versions.Add(published.Version);'''
assert needle in old,old
old=old.replace(needle, '''            var publishedVersion = await RiskMethodContent.ReadAsync(content, published, ct).ConfigureAwait(false);
            if (!ValidMethodVersion(publishedVersion, tenantId, programId, expectedVersion))
                return InvalidHistory<MethodHistory>();
            versions.Add(publishedVersion);''')
old=old.replace('published.Version.PublishedAt','publishedVersion.PublishedAt').replace('asOfVersions.Add(published.Version)','asOfVersions.Add(publishedVersion)')
old=old.replace('''var source = await reader.HydrateAsync(new RiskMethod(tenantId, programId), ct)
            .ConfigureAwait(false);''','''var source = await new RiskMethodReader(reader, events, content).ReadAsync(tenantId, programId, ct)
            .ConfigureAwait(false);''').replace('source.Id != methodId || ','')
s=s[:a]+old+s[b:]
s=s.replace('''            IRiskDraftFact fact => [fact.Content],''','''            RiskMethodVersionPublished fact => [fact.Content],
            IRiskDraftFact fact => [fact.Content],''')
# Method source content failure uses same Result classification as the other owning native sources.
a=s.index('        var methodHistory = await ReadMethodHistoryAsync');b=s.index('        var governance = ',a)
method=s[a:b]
method='''        Result<MethodHistory> methodHistory;
        try
        {
'''+method.replace('        var methodHistory =', '            methodHistory =')+'''        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<TypeIBaselineSourceContribution>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact risk method source content cannot be verified.", failure is ImmutableContentUnavailableException));
        }
'''
s=s[:a]+method+s[b:];f.write_text(s)
