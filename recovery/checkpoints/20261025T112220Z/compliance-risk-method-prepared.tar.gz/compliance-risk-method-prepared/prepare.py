from pathlib import Path
import shutil
p=Path('/tmp/compliance-risk-method-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');risk=Path('/tmp/compliance-risk-native-prepared/work');physical=Path('/tmp/compliance-risk-source-bytes-prepared/work')
rels=['src/Compliance.Core/Features/Risks/RiskMethod.cs','src/Compliance.Core/Features/Risks/PublishRiskMethodVersionHandler.cs','src/Compliance.Core/Features/Risks/GetRiskMethodHandler.cs','src/Compliance.Core/Features/Risks/GetRiskMethodVersionHandler.cs','src/Compliance.Core/Features/Risks/RiskMethodReassessmentReactor.cs','src/Compliance.Common/Features/Risks/RiskMethodVersionPublished.cs','src/Compliance.Common/Features/Risks/PublishRiskMethodVersion.cs','src/Compliance.Core/Features/Risks/RiskEvaluationOperations.cs','src/Compliance.Core/Features/Work/RiskAcceptanceWork.cs','src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs']
rels+=sorted(str(f.relative_to(repo)) for f in (repo/'test').rglob('*.cs') if 'RiskMethod' in f.read_text())
for rel in dict.fromkeys(rels):
 origin=physical/rel if (physical/rel).exists() else risk/rel if (risk/rel).exists() else repo/rel
 for d in ['base','work']:
  f=p/d/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,f)
def put(rel,s):
 f=p/'work'/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
# Extract existing pure rules, preserving the complete business contract outside the compact command owner.
f=p/'base/src/Compliance.Core/Features/Risks/RiskMethod.cs';s=f.read_text()
s=s.replace('public sealed class RiskMethod : Aggregate','public sealed class RiskMethodRules').replace('public RiskMethod(Uuid tenantId, Uuid programId)','public RiskMethodRules(Uuid tenantId, Uuid programId)')
a=s.index('        : base(');b=s.index('        _tenantId = tenantId;',a)
s=s[:a]+'''    {
'''+s[b:]
s=s.replace('        On<RiskMethodVersionPublished>(ev => _versions.Add(ev.Version));\n','')
s=s.replace('    public long PublishedVersion =>', '''    public Uuid Id => RiskMethod.IdFor(_tenantId, _programId);
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;
    public IReadOnlyList<RiskMethodVersionView> Versions => _versions.AsReadOnly();
    public long PublishedVersion =>''')
s=s.replace('RaiseEvent(new RiskMethodVersionPublished(_tenantId, programId,\n            new RiskMethodVersionView(', '_versions.Add(new RiskMethodVersionView(')
s=s.replace('AnnualReassessment, publishedBy, publishedAt)));','AnnualReassessment, publishedBy, publishedAt));')
s=s.replace('        var version = PublishedVersion + 1;', '''        if (PublishedVersion == long.MaxValue || publishedBy is null || publishedAt == default)
            return CommandFailure.InvalidContent("A method requires attributable bounded publication identity.");
        var version = PublishedVersion + 1;''')
put('src/Compliance.Core/Features/Risks/RiskMethodRules.cs',s)
put('src/Compliance.Core/Features/Risks/RiskMethod.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Bounded command authority for one program's immutable publication line.</summary>
public sealed class RiskMethod : Aggregate
{
    public const string Area = "risk-methods";
    public const string QualitativeFiveByFive = "qualitative_5x5";
    public const string AnnualReassessment = "P1Y";
    readonly Uuid _tenant;
    readonly Uuid _program;

    public RiskMethod(Uuid tenantId, Uuid programId, Uuid selectedLogicalId = default)
        : base(IdFor(tenantId, programId), new EventStreamAddress(tenantId.ToString(), Area, IdFor(tenantId, programId).ToString()))
    {
        (_tenant, _program) = (tenantId, programId);
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<RiskMethodVersionPublished>(ApplyFact);
    }

    public NativeAcceptance Acceptance { get; }
    public RiskMethodVersionPublished? Latest { get; private set; }
    public long PublishedVersion => Latest?.PublishedVersion ?? 0;
    public static Uuid IdFor(Uuid tenantId, Uuid programId) => Uuid.CreateVersion5(tenantId, $"risk-method:{programId}");

    public Result PreparePublish(long expectedVersion) => expectedVersion == PublishedVersion && expectedVersion < long.MaxValue
        ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict,
            $"Reload the risk method before publishing. Current version: {PublishedVersion}."));

    public Result Append(OperationProvenance operation, ImmutableContentRef version, ImmutableContentRef first,
        ImmutableContentRef result)
    {
        if (operation.OriginalExpectedRevision is not { } expected || expected > long.MaxValue)
            return Result.Failure(new RequestError(RequestErrorKind.Validation, "A method publication requires its original version gate."));
        var prepared = PreparePublish((long)expected);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new RiskMethodVersionPublished(_tenant, _program, PublishedVersion + 1, version, operation, first, result));
        return Result.Success;
    }

    void ApplyFact(RiskMethodVersionPublished fact)
    {
        if (fact.TenantId != _tenant || fact.ProgramId != _program || fact.PublishedVersion != PublishedVersion + 1 ||
            !RiskMethodContent.ValidNative(fact) || fact.Operation.FirstOwner != Stream)
            throw new InvalidOperationException("A method publication differs from its exact native owner and predecessor.");
        Acceptance.Observe(fact);
        Latest = fact;
    }
}
''')
put('src/Compliance.Common/Features/Risks/RiskMethodVersionPublished.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>One immutable method publication, with its original operation and result.</summary>
[Discriminator("bdgrz.risk.method.version_published", 2)]
public sealed record RiskMethodVersionPublished(Uuid TenantId, Uuid ProgramId, long PublishedVersion,
    ImmutableContentRef Content, OperationProvenance Operation, ImmutableContentRef? FirstResponse,
    ImmutableContentRef? OperationResult) : DomainEvent, INativeOperationFact;
''')
f=p/'work/src/Compliance.Common/Features/Risks/PublishRiskMethodVersion.cs';s=f.read_text().replace('IClientManagementMutationRequest, ICallable;','''IClientManagementMutationRequest, ICallable, IIdentifiedRequest
{
    // One publication can occupy an original version slot. Scope and original gate form its retry identity.
    Uuid IIdentifiedRequest.RequestId => Uuid.CreateVersion5(
        Uuid.CreateVersion5(TenantId, $"risk-method:{ProgramId}"),
        "publish-version:" + ExpectedVersion.ToString(System.Globalization.CultureInfo.InvariantCulture));
}
''');f.write_text(s)
put('src/Compliance.Core/Features/Risks/RiskMethodContent.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Verifies the original immutable method body against its native publication and owner.</summary>
public static class RiskMethodContent
{
    public const string Schema = "risk-method-version.v1";
    public const string ResultSchema = "risk-method-publication-result.v1";

    public static bool ValidNative(RiskMethodVersionPublished fact)
    {
        if (fact.TenantId == Uuid.Empty || fact.ProgramId == Uuid.Empty || fact.PublishedVersion < 1 ||
            fact.Content is not { Schema: Schema, MediaType: ImmutableContentStoreExtensions.JsonMediaType, Bytes: >= 0 } ||
            fact.Content.ContentId == Uuid.Empty || fact.Content.Sha256 is not { Length: 64 } || !fact.Content.Sha256.All(Uri.IsHexDigit) ||
            fact.FirstResponse is null || fact.OperationResult is null || fact.Operation is null)
            return false;
        var owner = new RiskMethod(fact.TenantId, fact.ProgramId);
        var identity = (IIdentifiedRequest)new PublishRiskMethodVersion(fact.TenantId, fact.ProgramId,
            fact.PublishedVersion - 1, [], []);
        return fact.Operation.FirstOwner == owner.Stream && fact.Operation.LogicalId == identity.RequestId &&
            NativeOwnerHistory.IsOwnRoot(owner, fact.Operation, nameof(PublishRiskMethodVersion), (ulong)(fact.PublishedVersion - 1));
    }

    public static async Task<RiskMethodVersionView> ReadAsync(IImmutableContentStore content,
        RiskMethodVersionPublished fact, CancellationToken ct = default)
    {
        if (!ValidNative(fact))
            throw new ImmutableContentIntegrityException("The method source has another exact publication binding.");
        var version = await NativeContent.ReadAsync<RiskMethodVersionView>(content, fact.TenantId, fact.Content, ct).ConfigureAwait(false);
        if (version.TenantId != fact.TenantId || version.ProgramId != fact.ProgramId || version.Version != fact.PublishedVersion ||
            version.MethodVersionId != Uuid.CreateVersion5(RiskMethod.IdFor(fact.TenantId, fact.ProgramId),
                version.Version.ToString(System.Globalization.CultureInfo.InvariantCulture)) ||
            version.PublishedBy != fact.Operation.Actor || version.PublishedAt != fact.Operation.AcceptedAt ||
            version.Kind != RiskMethod.QualitativeFiveByFive || version.ReassessmentInterval != RiskMethod.AnnualReassessment ||
            !ValidScale(version.LikelihoodScale) || !ValidScale(version.ImpactScale) || version.AppetiteThreshold is < 1 or > 25)
            throw new ImmutableContentIntegrityException("The immutable method differs from its native identity, original actor, time or rules.");
        var request = new PublishRiskMethodVersion(fact.TenantId, fact.ProgramId, version.Version - 1,
            version.LikelihoodScale, version.ImpactScale, version.AppetiteThreshold);
        // The authored hash is retained by acceptance. Trimmed stored descriptors may differ from original whitespace.
        return version;
    }

    static bool ValidScale(IReadOnlyList<string>? values) => values is { Count: 5 } && values.All(value =>
        !string.IsNullOrWhiteSpace(value) && value == value.Trim() && value.Length <= 200);
}
''')
# Remove unused variable immediately; validation reconstructs semantic identity without claiming raw intent preimages.
f=p/'work/src/Compliance.Core/Features/Risks/RiskMethodContent.cs';s=f.read_text();a=s.index('        var request = new PublishRiskMethodVersion',s.index('public static async'));b=s.index('        return version;',a);s=s[:a]+s[b:];s=s.replace('using Bdgrz.Compliance.Features.Kernel;\n','');f.write_text(s)
put('src/Compliance.Core/Features/Risks/RiskMethodReadSnapshot.cs','''namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Verified read composition; publication history is never command-owner state.</summary>
public sealed record RiskMethodReadSnapshot(IReadOnlyList<RiskMethodVersionView> Versions,
    IReadOnlyList<RiskMethodVersionPublished> Facts)
{
    public long PublishedVersion => Versions.Count;
    public RiskMethodVersionView? Current => Versions.Count == 0 ? null : Versions[^1];
    public RiskMethodVersionView? GetVersion(long version) => version > 0 && version <= Versions.Count ? Versions[(int)version - 1] : null;
    public RiskMethodVersionView? Find(Cntryl.Portia.Uuid id) => Versions.FirstOrDefault(version => version.MethodVersionId == id);
}
''')
put('src/Compliance.Core/Features/Risks/RiskMethodReader.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Authoritative current and immutable history reads at the owner's exact physical cut.</summary>
public sealed class RiskMethodReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async Task<RiskMethodVersionView?> CurrentAsync(Uuid tenant, Uuid program, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new RiskMethod(tenant, program), ct).ConfigureAwait(false);
        return owner.Latest is { } fact ? await RiskMethodContent.ReadAsync(content, fact, ct).ConfigureAwait(false) : null;
    }

    public async Task<RiskMethodReadSnapshot> ReadAsync(Uuid tenant, Uuid program, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new RiskMethod(tenant, program), ct).ConfigureAwait(false);
        var facts = await NativeOwnerHistory.ReadAsync<RiskMethodVersionPublished>(events, owner, ct).ConfigureAwait(false);
        if (facts.Count != owner.PublishedVersion || facts.Count > 0 &&
            ContentDigest.OfJson(facts[^1]) != ContentDigest.OfJson(owner.Latest))
            throw new ImmutableContentIntegrityException("The method history differs from its exact hydrated current cut.");
        var versions = new List<RiskMethodVersionView>(facts.Count);
        foreach (var fact in facts)
        {
            if (fact.TenantId != tenant || fact.ProgramId != program || fact.PublishedVersion != versions.Count + 1)
                throw new ImmutableContentIntegrityException("The method history has another scope or sequential version.");
            versions.Add(await RiskMethodContent.ReadAsync(content, fact, ct).ConfigureAwait(false));
        }
        return new RiskMethodReadSnapshot(versions.AsReadOnly(), facts);
    }
}
''')
put('src/Compliance.Core/Features/Risks/PublishRiskMethodVersionHandler.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Resolves an exact accepted publication before checking mutable program or version state.</summary>
public sealed class PublishRiskMethodVersionHandler(NativeOperationExecutor operations,
    IAggregateReader reader, IImmutableContentStore content, TimeProvider clock)
    : IRequestHandler<PublishRiskMethodVersion, RiskMethodVersionView>
{
    public async ValueTask<Result<RiskMethodVersionView>> HandleAsync(IRequestContext<PublishRiskMethodVersion> context,
        CancellationToken ct)
    {
        var request = context.Request;
        if (request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty || request.ExpectedVersion < 0)
            return Result<RiskMethodVersionView>.Failure(new RequestError(RequestErrorKind.Validation,
                "A method publication requires its tenant, program and original non-negative version."));
        var actor = RiskActor.From(context.Actor, request.TenantId);
        var command = ((IIdentifiedRequest)request).RequestId;
        var stream = new RiskMethod(request.TenantId, request.ProgramId).Stream;
        var provenance = RootOperation.Provenance(command, nameof(PublishRiskMethodVersion), stream,
            ActorReference.ForMember(actor.MemberId, actor.Display), request.ExpectedVersion,
            AuthoredIntentDigest.Compute(request), clock.GetUtcNow()) with { FirstOwner = stream };
        ImmutableContentRef? body = null;
        ImmutableContentRef? result = null;
        try
        {
            var accepted = await operations.ExecuteAsync(new NativeOperation<RiskMethod>(AcceptedOperationBinding.Of(provenance),
                () => new RiskMethod(request.TenantId, request.ProgramId, command), owner => owner.Acceptance,
                async (owner, token) =>
                {
                    var gate = owner.PreparePublish(request.ExpectedVersion);
                    if (!gate.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(gate.Error!);
                    var program = await reader.HydrateAsync(new ComplianceProgram(request.TenantId, request.ProgramId), token).ConfigureAwait(false);
                    if (!program.IsCreated)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The program was not found."));
                    var rules = new RiskMethodRules(request.TenantId, request.ProgramId);
                    var validation = rules.Publish(request.ProgramId, 0, request.LikelihoodScale, request.ImpactScale,
                        request.AppetiteThreshold, provenance.Actor, provenance.AcceptedAt);
                    if (validation is not null)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Validation, validation.Message));
                    var version = rules.Current! with
                    {
                        Version = request.ExpectedVersion + 1,
                        MethodVersionId = Uuid.CreateVersion5(owner.Id,
                            (request.ExpectedVersion + 1).ToString(System.Globalization.CultureInfo.InvariantCulture)),
                    };
                    body = await NativeContent.WriteAsync(content, request.TenantId, RiskMethodContent.Schema, version, token).ConfigureAwait(false);
                    var frozen = await NativeContent.FreezeAsync(content, request.TenantId, RiskMethodContent.ResultSchema, version, token).ConfigureAwait(false);
                    result = frozen.Result;
                    return Result<FirstResponseDescriptor>.Success(frozen.Response);
                }, (owner, first) => owner.Append(provenance, body!, first, result!)), context, ct).ConfigureAwait(false);
            return await NativeContent.ResponseAsync<RiskMethodVersionView>(content, request.TenantId, accepted, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            return Result<RiskMethodVersionView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact risk method content cannot be verified.", error is ImmutableContentUnavailableException));
        }
    }
}
''')
for name,current in [('GetRiskMethodHandler',True),('GetRiskMethodVersionHandler',False)]:
 f=p/'work/src/Compliance.Core/Features/Risks'/f'{name}.cs';s=f.read_text().replace('IAggregateReader reader','RiskMethodReader reader')
 a=s.index('        var method = await reader.HydrateAsync');b=s.index('\n    }',a)
 call='''        try
        {
'''+('''            var version = await reader.CurrentAsync(context.Request.TenantId, context.Request.ProgramId, ct).ConfigureAwait(false);
            return Found(version);
''' if current else '''            var method = await reader.ReadAsync(context.Request.TenantId, context.Request.ProgramId, ct).ConfigureAwait(false);
            return GetRiskMethodHandler.Found(method.GetVersion(context.Request.Version));
''')+'''        }
        catch (ImmutableContentIntegrityException error)
        {
            return Result<RiskMethodVersionView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact risk method content cannot be verified.", error is ImmutableContentUnavailableException));
        }'''
 s=s[:a]+call+s[b:];s='using Bdgrz.Compliance.Features.Content;\n'+s;f.write_text(s)
