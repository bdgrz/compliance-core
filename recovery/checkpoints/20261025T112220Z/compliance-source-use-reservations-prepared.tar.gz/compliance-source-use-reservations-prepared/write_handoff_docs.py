from pathlib import Path
import hashlib,json,shutil,re
r=Path('/tmp/compliance-source-use-reservations-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');sdk=Path('/tmp/compliance-pr-review-20261024/packages');portia=Path('/Users/jrepanich/Code/cntryl/portia')
items=[sdk/'cntryl.portia.abstractions/0.9.1/lib/net10.0/Portia.Abstractions.xml',sdk/'cntryl.portia.abstractions/0.9.1/cntryl.portia.abstractions.nuspec',sdk/'cntryl.portia.core/0.9.1/lib/net10.0/Portia.Core.xml',sdk/'cntryl.portia.core/0.9.1/cntryl.portia.core.nuspec',sdk/'cntryl.portia.dependencyinjection/0.9.1/lib/net10.0/Portia.DependencyInjection.xml',sdk/'cntryl.portia.dependencyinjection/0.9.1/cntryl.portia.dependencyinjection.nuspec',portia/'src/Portia.Abstractions/Aggregates/Aggregate.cs',portia/'src/Portia.Abstractions/Events/DomainEvent.cs',portia/'src/Portia.Abstractions/Events/DomainEventMetadata.cs',portia/'src/Portia.Abstractions/Events/DomainEventRecord.cs',portia/'src/Portia.Core/Aggregates/AggregateRepository.cs',portia/'src/Portia.Core/Aggregates/AggregateExecutor.cs',portia/'src/Portia.DependencyInjection/Hosting/PortiaApplicationServiceCollectionExtensions.cs']
snap=[]
for p in items:
 rel=p.relative_to(sdk) if p.is_relative_to(sdk) else Path('local-source')/p.relative_to(portia)
 q=r/'sdk-snapshots'/rel;q.parent.mkdir(parents=True,exist_ok=True);data=p.read_bytes();q.write_bytes(data)
 snap.append({'source':str(p),'snapshot':str(q.relative_to(r)),'sha256':hashlib.sha256(data).hexdigest(),'qualification':'Selected0.9.1 package API/metadata snapshot' if p.is_relative_to(sdk) else 'Local Portia source inspection, not asserted byte-equivalent to selected package build'})
(r/'sdk-snapshots.json').write_text(json.dumps(snap,indent=2)+'\n')
(r/'SDK-QUALIFICATION.md').write_text('''# SDK boundary qualification (static only)

The selected backend package versions are Cntryl.Portia0.9.1. Exact cached Abstractions/Core/DependencyInjection XML and nuspec files are retained under `sdk-snapshots/`; hashes/provenance are in `sdk-snapshots.json`. These nuspecs name repository commit `9671b793abfa8c5462d74accdf82d54b5cebefa5`.

The selected public API documents `Aggregate.Apply(DomainEvent)` as protected virtual, `IAggregateReader.HydrateAsync` returning the caller's owner, and `IAggregateExecutor` hydrating before invoking its operation. No end-hydration callback is exposed by that selected public API. The prepared boundary decorates the reader instead.

Separately retained local Portia source files show the current registration factory resolving `IAggregateReader` when constructing `AggregateExecutor`, the repository receiving exact contiguous resource offsets, aggregate metadata version validation, and audits written to independent audit-session streams. The local source tree is inspected evidence; its bytes are **not claimed equal to the selected package build**. Parent must qualify these observations against the actual0.9.1 runtime using the prepared real `AddCompliance` registration/executor test and focused/full suites. No SDK binary, build, runtime or broker execution was performed by this preparer.

Save attribution (correlation/causation/execution/actor) is stamped after `RaiseEvent`. The rolling owner cut therefore commits each concrete typed payload, eventID, aggregateID, metadata aggregateVersion, occurredOn and audit flag; it does not hash fields the writer stamps later. Selected actual grant/settle facts independently compare their **complete** metadata between replay and the validating native stream read, including attribution. This permits save followed by in-place catch-up without silently substituting selected metadata.
''')
(r/'README.md').write_text('''# Frozen SourceUseReservations53 offline handoff

This is a separate follow-on after frozen catalog53, with current main snapshots for other paths. Parent alone applies changes, runs .NET/format/analyzers, proves RED/GREEN, reviews every changed file with Jev, and delivers. No main files, Git state, issues, worktrees, brokers or memory were changed here.

## Problem and result

The old component retains every settled/fenced slot in a lifetime dictionary. The prepared component keeps live grants, explicitly requested historical slots, a grant counter and a bounded rolling commitment to the actual replayed payload/immutable metadata cut. Historical authority remains the existing ordered native stream; no new grant, release, source-use, immutable-node, wire or JSON contract is introduced.

`SourceUseAggregateReader` calls the original keyed reader, then validates the entire exact native owner cut using a transient full dictionary. That pass rejects an unselected late grant after a historical fence or a second historical settlement. It verifies full key scope, actual physical resource offsets, metadata identity/version, full payload cut, and complete selected native metadata. Missing/truncated history never proves absence. Only live+selected facts survive in the returned owner.

`ForSourceUses(key...)` or `ForSourceUse(owner => exactKey)` must select historical keys before hydration. Existing `Find` and `GrantOf` operate on live or selected state; unknown historical lookup throws instead of pretending absence. A selected absence is authorized only by complete exact-cut finalization. A genuinely empty owner may prove absence locally. The original full tuple is preserved: target owner stream, root operation, first owner, source generation, purpose.

Every32 existing grant/settle producer method requires selected finalized evidence for its exact current owner Version and CommittedStreamPosition before emitting. Generic receivers select the key for both their explicit reads and their fresh executor owner. Real source verification/disposition, current caller authorization, source pins, exact native retry, original first responses and OCC gates stay in the owning protocols. No mutable content body read was added by finalization.

## Patch stages

1. Apply `tests-red.patch` alone and run `FullyQualifiedName~SourceUseReservationsNativeBoundaryTests`: its existing-API test is expected RED because the old component retains128 terminal entries.
2. Apply `implementation.patch`, then the single shared delta `shared.patch`.
3. Apply `migrated-tests.patch` and `native-tests.patch`.

For final-only integration use `implementation.patch`, `shared.patch`, `tests-full.patch`. `reconstruction.json` proves both orders reproduce all53 final C# files exactly. `manifest.json` records every before/after SHA; all45 existing/layered paths have nonnull saved originals. Eight paths are new. Full snapshot trees remain under `base/` and `work/`, but **only manifest paths belong to this handoff**; do not overwrite unrelated files from these snapshots.

Shared wiring is only `Hosting/Persistence/PersistenceServiceCollectionExtensions.cs`: retain the original scoped `IAggregateReader` registration under the existing opaque-key decoration mechanism and wrap it with `SourceUseAggregateReader(inner, IDomainEventReader)`. Event-store safety decoration happens first. The original keyed factory resolves its original AggregateRepository, not the decorated interface. The registered executor resolves the decorated reader at its scope. Non-source owners forward directly. See `wiring.json` and `SDK-QUALIFICATION.md`; actual registration qualification is a parent runtime gate.

## Verification prepared

The old-API retention RED and native regressions cover long compact state, unselected duplicate grants/settlements, first-owner/generation/purpose scope, original grant after settlement, actual terminal metadata, selected metadata substitution, truncated and substituted historical cuts, local empty absence, audit-session physical offsets, and production DI/executor registration. Existing real-process fixtures retain their acceptance names/assertions and select terminal keys explicitly. The handoff preserves74 existing acceptance names. Static tree-sitter parsing and369 explicit constructor calls pass; all changed-path originals, token position, duplicate-using and assertion/name preservation gates pass.

Parent should run the `handoff.json` focused filters, then `Category!=BrokerIntegration` full suite. Direct per-file Jev and actual runtime RED/GREEN remain unrun. O(N) transient validation/scans remain; this change bounds returned **domain component** state by live+selected slots, and makes no constant-time or SDK infrastructure memory claim.

The13 source owners with existing pairs retain all32 native reducer hooks. ControlDraft still implements ISourceUseOwner but has no actual selected source-use pair; no such producer was invented. This work does not compact unrelated owner histories (for example practice commitments or bulk-decision business state). Risk109, Calendar28, Boundary and catalog53 artifacts remain frozen and untouched.
''')
(r/'LOCAL-BLOCKERS.md').write_text('''# Local qualification and remaining scope

No missing producer/source-use contract blocks the existing16 acquire/settle pairs. All32 actual fact registrations are explicitly classified; no permits, release rules or absence authority were invented. The compatibility ControlDraft owner has no actual selected use pair and gains none.

Parent gates: existing-API RED, actual0.9.1 compile/analyzers/format, native focused cases, all real consuming process tests, `Category!=BrokerIntegration` full suite, exact-head direct per-file Jev review and final delivery. The preparer made no runtime/Jev or broker claims.

Full history is still read and transiently validated in O(N) space/time. Returned domain component state is compact; the SDK may retain its own infrastructure identity state. Persistent indexes/checkpointed verification are a possible separate performance task, not needed for current correctness and not implemented here. Other owner-specific historical collections are outside this generic reservation slice.
''')
(r/'wiring.json').write_text(json.dumps({'sharedDelta':'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','reader':'new SourceUseAggregateReader(originalKeyedReader, IDomainEventReader)','lifetime':'Original scoped IAggregateReader lifetime preserved by existing opaque-key Decorate mechanism; registered AggregateExecutor factory resolves decorated reader.','registrationOrder':['Decorate IEventStore with PersistenceEventStore','Decorate IKvClient with PersistenceKvClient','Decorate IAggregateReader with SourceUseAggregateReader','Decorate IRequestBus with PersistenceValidationRequestBus'],'recursionBoundary':'Original keyed IAggregateReader factory continues resolving original AggregateRepository; wrapper only receives this keyed original.','constructorChanges':[],'methodChanges':['Historical consumers explicitly select full ReservationKeys before hydration via ForSourceUses or ForSourceUse.','EngagementUseOwners.HydrateAsync and private personal-decision owner resolver receive ReservationKey immediately before final CancellationToken.','Test-only CampaignHost/CampaignSeed.ParticipantAsync accept optional selectedUse for terminal assertions.'],'jsonRootsAdded':[],'wireChanges':[],'owningCatalogDependency':'/tmp/compliance-ratification-native-prepared/handoff.json'},indent=2)+'\n')
(r/'WORK-IN-PROGRESS.md').write_text('''FROZEN: complete offline SourceUseReservations53 preparation. See handoff.json, README.md, manifest.json, exact reconstruction and SDK-QUALIFICATION.md. Parent owns all runtime verification and integration. Do not mutate frozen artifacts without coordination.
''')
print('wrote manifest-linked docs and retained',len(snap),'SDK package/source snapshots')
