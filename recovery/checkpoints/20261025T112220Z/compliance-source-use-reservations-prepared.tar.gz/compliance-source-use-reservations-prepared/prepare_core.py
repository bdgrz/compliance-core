from pathlib import Path
import re,json
r=Path('/tmp/compliance-source-use-reservations-prepared'); w=r/'work'
def put(path,text):
 p=w/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
old=(w/'src/Compliance.Core/Features/SourceUse/SourceUseReservations.cs').read_text()
purpose=old[old.index('    /// <summary>The wire name'):old.index('    Slot SlotOf')]
put('src/Compliance.Core/Features/SourceUse/SourceUseSlot.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceUse;

readonly record struct SourceUseSlot(Uuid Root, EventStreamAddress FirstOwner, ulong SourceGeneration, string Purpose)
{
    public static SourceUseSlot Of(EventStreamAddress owner, ReservationKey key)
    {
        ArgumentNullException.ThrowIfNull(key);
        if (key.Target != owner)
            throw new ArgumentException("The key names another target owner.", nameof(key));
        return new(key.RootOperationId, key.FirstOwner, key.SourceGeneration, key.Purpose);
    }

    public static SourceUseSlot Of(EventStreamAddress owner, SourceUsePurpose purpose, ISourceUseFact fact)
    {
        ArgumentNullException.ThrowIfNull(fact);
        return Of(owner, purpose, fact.Operation, fact.Generation, fact.Owner);
    }

    public static SourceUseSlot Of(EventStreamAddress owner, SourceUsePurpose purpose, OperationProvenance operation,
        long generation, EventStreamAddress? factOwner = null)
    {
        ArgumentNullException.ThrowIfNull(operation);
        if (factOwner is not null && factOwner != owner || operation.Owner != owner || generation < 0 ||
            operation.RootOperationId == Uuid.Empty)
            throw new InvalidOperationException("A source use fact belongs to its own owner stream and root operation.");
        return new(operation.RootOperationId, operation.FirstOwner ?? operation.Owner, (ulong)generation,
            SourceUseReservations.PurposeName(purpose));
    }
}
''')
put('src/Compliance.Core/Features/SourceUse/SourceUseReservations.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceUse;

/// <summary>
/// Current live grants and explicitly selected historical slots. The verified aggregate reader validates the full
/// ordered history transiently before returning an existing owner. Closed slots never accumulate in command state.
/// </summary>
public sealed class SourceUseReservations(EventStreamAddress owner)
{
    readonly Dictionary<SourceUseSlot, SourceUseEntry> _active = [];
    readonly Dictionary<SourceUseSlot, SourceUseEntry> _selected = [];
    readonly HashSet<SourceUseSlot> _selection = [];
    bool _observed;
    bool _verified;
    ulong _verifiedVersion;
    ulong _verifiedPosition;

    /// <summary>The receiver's monotonic grant counter, independent of owner revisions and physical position.</summary>
    public ulong Generation { get; private set; }

    /// <summary>True while any granted use is not settled; a conflicting writer must wait.</summary>
    public bool HasActiveUse => _active.Count != 0;

    /// <summary>The live grants in receiver grant order.</summary>
    public IReadOnlyList<SourceUseEntry> ActiveUses => Array.AsReadOnly(_active.Values
        .OrderBy(entry => entry.ReservationGeneration).ToArray());

    /// <summary>Selects an exact historical key before replay; selection is request-local, never lifetime state.</summary>
    public void Select(ReservationKey key)
    {
        if (_observed)
            throw new InvalidOperationException("Select historical source uses before hydrating the owner.");
        _selection.Add(SourceUseSlot.Of(owner, key));
    }

    /// <summary>A live or explicitly selected historical slot. Only an empty owner or a verified selection proves absence.</summary>
    public SourceUseEntry? Find(ReservationKey key)
    {
        var slot = SourceUseSlot.Of(owner, key);
        if (_active.TryGetValue(slot, out var active))
            return active;
        if (_selection.Contains(slot))
            return _selected.GetValueOrDefault(slot);
        if (!_observed)
            return null;
        throw new InvalidOperationException("Historical source-use lookup requires explicit selection before hydration.");
    }

    /// <summary>The actual original grant of a selected or live key, including after settlement.</summary>
    public ReservationGrant? GrantOf(ReservationKey key) => Find(key) is { GrantFact: not null } entry
        ? new ReservationGrant(key, entry.ReservationGeneration, NativeFactReference.Of(owner, entry.GrantFact))
        : null;

    /// <summary>Requires the exact selected history proof at this owner's current append cut.</summary>
    public void RequireForAppend(SourceUsePurpose purpose, OperationProvenance operation, long generation,
        ulong ownerVersion, ulong physicalPosition)
    {
        var slot = SourceUseSlot.Of(owner, purpose, operation, generation);
        if (ownerVersion == 0 && physicalPosition == 0 && !_observed)
        {
            _selection.Add(slot);
            return;
        }
        if (!_verified || _verifiedVersion != ownerVersion || _verifiedPosition != physicalPosition ||
            !_selection.Contains(slot))
            throw new InvalidOperationException("A source-use append requires its finalized exact selected owner cut.");
    }

    /// <summary>Reducer hook for a grant. Full historical duplicate validation is performed at reader finalization.</summary>
    public void ApplyGranted(SourceUsePurpose purpose, ISourceUseFact fact)
    {
        var slot = SourceUseSlot.Of(owner, purpose, fact);
        if (_active.ContainsKey(slot) || _selected.ContainsKey(slot))
            throw new InvalidOperationException("A source use is granted at most once and never after its fence.");
        _observed = true;
        _verified = false;
        Generation = checked(Generation + 1);
        var entry = new SourceUseEntry(Generation, (DomainEvent)fact, null);
        _active.Add(slot, entry);
        if (_selection.Contains(slot))
            _selected.Add(slot, entry);
    }

    /// <summary>Reducer hook for settlement; only real terminal source facts release or fence a key.</summary>
    public void ApplySettled(SourceUsePurpose purpose, ISourceUseFact fact)
    {
        var slot = SourceUseSlot.Of(owner, purpose, fact);
        if (_selected.GetValueOrDefault(slot) is { IsSettled: true })
            throw new InvalidOperationException("A source use is settled at most once.");
        var settled = _active.Remove(slot, out var entry)
            ? entry with { SettleFact = (DomainEvent)fact }
            : new SourceUseEntry(0, null, (DomainEvent)fact);
        _observed = true;
        _verified = false;
        if (_selection.Contains(slot))
            _selected[slot] = settled;
    }

    internal void BeginHydration() => _verified = false;

    internal void Confirm(SourceUseHistoryValidation history, ulong ownerVersion, ulong physicalPosition)
    {
        if (Generation != history.Generation || _active.Count != history.Active.Count ||
            _active.Any(pair => !history.Active.TryGetValue(pair.Key, out var expected) ||
                !SourceUseHistoryValidation.Same(pair.Value, expected)))
            throw new InvalidOperationException("The source-use replay differs from the verified exact native history.");
        _selected.Clear();
        foreach (var slot in _selection)
            if (history.Entries.TryGetValue(slot, out var entry))
                _selected.Add(slot, entry);
        _verifiedVersion = ownerVersion;
        _verifiedPosition = physicalPosition;
        _verified = true;
    }

'''+purpose+'}\n')
put('src/Compliance.Core/Features/SourceUse/SourceUseHistoryValidation.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceUse;

/// <summary>Transient full-history validation; never retained by the returned owner or a singleton cache.</summary>
sealed class SourceUseHistoryValidation(EventStreamAddress owner)
{
    public Dictionary<SourceUseSlot, SourceUseEntry> Entries { get; } = [];
    public Dictionary<SourceUseSlot, SourceUseEntry> Active { get; } = [];
    public ulong Generation { get; private set; }

    public void Observe(SourceUsePurpose purpose, bool granted, ISourceUseFact fact)
    {
        var slot = SourceUseSlot.Of(owner, purpose, fact);
        if (granted)
        {
            if (Entries.ContainsKey(slot))
                throw new InvalidOperationException("A source use is granted at most once and never after its fence.");
            Generation = checked(Generation + 1);
            var entry = new SourceUseEntry(Generation, (DomainEvent)fact, null);
            Entries.Add(slot, entry);
            Active.Add(slot, entry);
            return;
        }
        if (Entries.TryGetValue(slot, out var previous) && previous.IsSettled)
            throw new InvalidOperationException("A source use is settled at most once.");
        Entries[slot] = previous is null
            ? new SourceUseEntry(0, null, (DomainEvent)fact)
            : previous with { SettleFact = (DomainEvent)fact };
        Active.Remove(slot);
    }

    public static bool Same(SourceUseEntry actual, SourceUseEntry expected) =>
        actual.ReservationGeneration == expected.ReservationGeneration &&
        SameFact(actual.GrantFact, expected.GrantFact) && SameFact(actual.SettleFact, expected.SettleFact);

    static bool SameFact(DomainEvent? actual, DomainEvent? expected) => actual is null ? expected is null
        : expected is not null && actual.GetType() == expected.GetType() && actual.Equals(expected) &&
            actual.Metadata == expected.Metadata;
}
''')
put('src/Compliance.Core/Features/SourceUse/SourceUseSelection.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceUse;

/// <summary>Explicit request-local history selection made before aggregate replay.</summary>
public static class SourceUseSelection
{
    /// <summary>Selects the exact historical reservation keys needed by this reader or receiver.</summary>
    public static TOwner ForSourceUses<TOwner>(this TOwner owner, params ReservationKey[] keys)
        where TOwner : Aggregate, ISourceUseOwner
    {
        ArgumentNullException.ThrowIfNull(owner);
        ArgumentNullException.ThrowIfNull(keys);
        foreach (var key in keys)
            owner.Uses.Select(key);
        return owner;
    }
}
''')
# derive actual owner reducer registrations, not comments/interface occurrences.
pairs={}
for x in json.loads((r/'inventory.json').read_text())['owners']:
 p=w/x['path'];s=p.read_text()
 for m in re.finditer(r'On<(\w+)>\([^\n]*=>\s*\{(.*?)\n        \}\);',s,re.S):
  for use in re.finditer(r'Uses\.Apply(Granted|Settled)\(SourceUsePurpose\.(\w+),',m[2]): pairs[m[1]]=(use[2],use[1]=='Granted')
assert len(pairs)==32,len(pairs)
imports=sorted({'.'.join(str(p.relative_to(w)).split('/')[3:-1]) for p in []})
areas=['AccessControl','AccessReviews','AuditorRequests','Evidence','PolicyDistribution','Providers','Readiness','Remediation']
put('src/Compliance.Core/Features/SourceUse/SourceUseFactKinds.cs',''.join(f'using Bdgrz.Compliance.Features.{a};\n' for a in areas)+'''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceUse;

/// <summary>The existing reducer registrations, expressed once for full transient stream validation.</summary>
static class SourceUseFactKinds
{
    public static (SourceUsePurpose Purpose, bool Granted)? Classify(DomainEvent fact) => fact switch
    {
'''+''.join(f'        {k} => (SourceUsePurpose.{v[0]}, {str(v[1]).lower()}),\n' for k,v in sorted(pairs.items()))+'''        _ => null,
    };
}
''')
put('src/Compliance.Core/Features/SourceUse/SourceUseAggregateReader.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceUse;

/// <summary>
/// Finalizes source-use owners at the exact hydrated cut. Full transient validation protects unselected historical
/// fences as well as selected ones. Its inner reader is the original keyed registration, never this decorator.
/// </summary>
public sealed class SourceUseAggregateReader(IAggregateReader inner, IDomainEventReader events) : IAggregateReader
{
    /// <inheritdoc />
    public async ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate, CancellationToken ct = default)
        where TAggregate : Aggregate
    {
        ArgumentNullException.ThrowIfNull(aggregate);
        if (aggregate is not ISourceUseOwner source)
            return await inner.HydrateAsync(aggregate, ct).ConfigureAwait(false);
        source.Uses.BeginHydration();
        var owner = await inner.HydrateAsync(aggregate, ct).ConfigureAwait(false);
        var history = new SourceUseHistoryValidation(owner.Stream);
        var position = 0UL;
        var version = 0UL;
        var ids = new HashSet<Uuid>();
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(owner.Stream.Realm,
            owner.Stream.Area, owner.Stream.Resource), EventCursor.Start, ct).ConfigureAwait(false))
        {
            if (record.ResourceOffset >= owner.CommittedStreamPosition)
                break;
            var metadata = record.Event.Metadata;
            if (record.Stream != owner.Stream || record.ResourceOffset != position || metadata.IsAudit ||
                metadata.AggregateId != owner.Id || metadata.AggregateVersion != checked(version + 1) ||
                metadata.EventId == Uuid.Empty || !ids.Add(metadata.EventId))
                throw new ImmutableContentIntegrityException("The source-use history has another exact owner, physical offset or metadata version.");
            if (SourceUseFactKinds.Classify(record.Event) is { } kind)
                history.Observe(kind.Purpose, kind.Granted, (ISourceUseFact)record.Event);
            position = checked(record.ResourceOffset + 1);
            version = metadata.AggregateVersion;
        }
        if (position != owner.CommittedStreamPosition || version != owner.Version)
            throw new ImmutableContentUnavailableException("The source-use owner's exact hydrated history cut is not visible yet.");
        ct.ThrowIfCancellationRequested();
        source.Uses.Confirm(history, owner.Version, owner.CommittedStreamPosition);
        return owner;
    }
}
''')
# Every source-use producer must possess a finalized selected proof at its current OCC cut.
for x in json.loads((r/'inventory.json').read_text())['owners']:
 p=w/x['path'];s=p.read_text();changed=False
 for fact,(purpose,grant) in pairs.items():
  pat=r'(        )RaiseEvent\(new '+re.escape(fact)+r'\('
  if re.search(pat,s):
   s=re.sub(pat,lambda m:m[1]+f'Uses.RequireForAppend(SourceUsePurpose.{purpose}, operation, generation, Version, CommittedStreamPosition);\n'+m[1]+'RaiseEvent(new '+fact+'(',s);changed=True
 if changed:p.write_text(s)
# Register once, after persisted event-store decoration; executor factory resolves this decorated reader.
p=w/'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=p.read_text().replace('using Cntryl.Fitz;','using Bdgrz.Compliance.Features.SourceUse;\nusing Cntryl.Fitz;').replace('        Decorate<IRequestBus>', '        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new SourceUseAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n        Decorate<IRequestBus>');p.write_text(s)
# Generic receiver selections cover both explicit and executor-internal hydration.
for name in ['AuthorizeSourceUseHandler','SettleSourceUseHandler']:
 p=w/f'src/Compliance.Core/Features/SourceUse/{name}.cs';s=p.read_text().replace('reader.HydrateAsync(Open(request, request.CommandId), ct)', 'reader.HydrateAsync(Open(request, request.CommandId).ForSourceUses(source.Key), ct)').replace('executor.ExecuteAsync(Open(request, request.CommandId), fresh =>','executor.ExecuteAsync(Open(request, request.CommandId).ForSourceUses(source.Key), fresh =>');p.write_text(s)
(r/'classifier.json').write_text(json.dumps(pairs,indent=2)+'\n')
print('prepared compact component, full transient validator/reader,',len(pairs),'classified native contracts and producer guards')
