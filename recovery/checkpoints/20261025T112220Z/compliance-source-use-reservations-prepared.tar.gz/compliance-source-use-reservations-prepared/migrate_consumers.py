from pathlib import Path
import re
r=Path('/tmp/compliance-source-use-reservations-prepared/work')
def path(name):
 xs=list((r/'src/Compliance.Core/Features').rglob(name+'.cs'));assert len(xs)==1,(name,xs);return xs[0]
def imp(s):
 if 'using Bdgrz.Compliance.Features.SourceUse;' not in s:s='using Bdgrz.Compliance.Features.SourceUse;\n'+s
 return s
def endparen(s,start):
 level=0
 for i in range(start,len(s)):
  if s[i]=='(':level+=1
  elif s[i]==')':
   level-=1
   if level==0:return i
 raise Exception('no paren')
def wrapvar(name,var,selection,all=False):
 p=path(name);s=p.read_text();pat=r'var '+var+r' = await (?:reader|_reader)\.HydrateAsync\(new (\w+)\('
 matches=list(re.finditer(pat,s));assert matches,(name,var)
 if not all:assert len(matches)==1,(name,var,len(matches))
 for m in reversed(matches):
  start=s.index('(',m.start()+s[m.start():].index('new '));end=endparen(s,start)
  s=s[:end+1]+f'.ForSourceUse(candidate => {selection})'+s[end+1:]
 p.write_text(imp(s))
# Single source lookups, expressed from constructor identity before replay.
for args in [
 ('ProfessionalDutyChangeReceivers','staff','ProfessionalDutyRules.StaffUseKey(assertionId, change.Owner!.Stream, requirement)'),
 ('CompleteProviderAssuranceReviewHandler','report','ProviderReviewEffects.UseKey(request.OperationId, request.Target, requirement.SourceOwner)'),
 ('PublishAccessReviewDecisionBatchHandler','item','candidate.BulkKey(command.DecisionBatchId)'),
 ('CompleteAccessReviewCampaignClosureHandler','owner','AccessReviewCompletionVerifier.UseKey(command.OperationId, campaign, requirement)'),
 ('BulkAccessDecisionProcess','item','candidate.BulkKey(batchId)'),
 ('CompletePolicyCampaignClosureHandler','owner','key'),
 ('AuditorRequestResolutionProofs','response','AuditorRequestResolutionEffects.UseKey(intent, candidate.Stream)'),
 ('RiskActionReviewProofs','request','RiskActionReviewEffects.UseKey(intent, generation, candidate.Stream)'),
 ('FindingClosureProofs','action','FindingClosureEffects.UseKey(intent, candidate.Stream)'),
 ('ReadinessDecisionProofs','plan','ReadinessEffects.UseKey(intent, decision.Generation, candidate.Stream)'),
]:wrapvar(*args)
# Add typed selector overload.
p=r/'src/Compliance.Core/Features/SourceUse/SourceUseSelection.cs';s=p.read_text();at=s.rfind('}')
s=s[:at]+'''    /// <summary>Selects one exact key derived from the unhydrated owner's immutable stream identity.</summary>
    public static TOwner ForSourceUse<TOwner>(this TOwner owner, Func<TOwner, ReservationKey> select)
        where TOwner : Aggregate, ISourceUseOwner
    {
        ArgumentNullException.ThrowIfNull(owner);
        ArgumentNullException.ThrowIfNull(select);
        return owner.ForSourceUses(select(owner));
    }
'''+s[at:];p.write_text(s)
# Private and shared engagement owner selectors now require an explicit exact key.
for name,signature in [('AuthorizeEngagementPersonalDecisionHandler','Uuid tenantId, CancellationToken ct)'),('EngagementUseOwners','DurableIntentHeader header, Uuid tenantId, CancellationToken ct)')]:
 p=path(name);s=p.read_text();assert signature in s;s=s.replace(signature,signature.replace('CancellationToken ct','ReservationKey key, CancellationToken ct'))
 # only switch return owner constructions; retain all other hydrate calls unchanged.
 pat=r'return await reader\.HydrateAsync\(new (ClientServiceIndependence|FirmStaffRecord|FirmProfessionalDutyDesignation|IndependenceRuleCatalog|IndependenceRuleRatificationCatalog)\('
 for m in reversed(list(re.finditer(pat,s))):
  start=s.index('(',s.index('new ',m.start()));end=endparen(s,start);s=s[:end+1]+'.ForSourceUses(key)'+s[end+1:]
 if name=='AuthorizeEngagementPersonalDecisionHandler':
  s=s.replace('            var source = await HydrateAsync(requirement.SourceOwner, intent, tenantId, ct).ConfigureAwait(false);','            var key = EngagementPersonalDecisionEffects.UseKey(intent.DecisionId, engagement, requirement.SourceOwner);\n            var source = await HydrateAsync(requirement.SourceOwner, intent, tenantId, key, ct).ConfigureAwait(false);')
  # remove original duplicate key declaration after source guard.
  line='            var key = EngagementPersonalDecisionEffects.UseKey(intent.DecisionId, engagement, requirement.SourceOwner);\n';first=s.index(line);second=s.index(line,first+len(line));s=s[:second]+s[second+len(line):]
 p.write_text(imp(s))
p=path('AuthorizeEngagementPracticeCommitmentsHandler');s=p.read_text();s=s.replace('            var source = await EngagementUseOwners.HydrateAsync(reader, requirement.SourceOwner, intent.Header, tenantId, ct)','            var key = EngagementAcceptanceEffects.UseKey(command.OperationId, engagement, requirement.SourceOwner);\n            var source = await EngagementUseOwners.HydrateAsync(reader, requirement.SourceOwner, intent.Header, tenantId, key, ct)');line='            var key = EngagementAcceptanceEffects.UseKey(command.OperationId, engagement, requirement.SourceOwner);\n';first=s.index(line);second=s.index(line,first+len(line));s=s[:second]+s[second+len(line):];p.write_text(s)
wrapvar('AuthorizeEngagementPracticeCommitmentsHandler','held','EngagementAcceptanceEffects.UseKey(command.OperationId, engagement, candidate.Stream)')
p=path('EngagementAcceptanceProofs');s=p.read_text();s=s.replace('                    var owner = await EngagementUseOwners.HydrateAsync(reader, requirement.SourceOwner, intent.Header,\n                        tenantId, ct)', '                    var key = EngagementAcceptanceEffects.UseKey(operationId, root.Stream, requirement.SourceOwner);\n                    var owner = await EngagementUseOwners.HydrateAsync(reader, requirement.SourceOwner, intent.Header,\n                        tenantId, key, ct)');s=s.replace('                    var key = EngagementAcceptanceEffects.UseKey(operationId, root.Stream, requirement.SourceOwner);\n                    proofs.Add','                    proofs.Add');# practice reservation only (permanent proof lookup does not need a use key)
start=s.index('    public static Task<ImmutableContentRef> ReservationsAsync');end=s.index('    /// <summary>The exact permanent commitment',start);part=s[start:end];m=re.search(r'var owner = await reader.HydrateAsync\(new PracticeIndependenceCommitment\(',part);pos=part.index('(',part.index('new ',m.start()));finish=endparen(part,pos);part=part[:finish+1]+'.ForSourceUse(candidate => EngagementAcceptanceEffects.UseKey(operationId, root.Stream, candidate.Stream))'+part[finish+1:];s=s[:start]+part+s[end:];p.write_text(s)
# Bulk apply looks up settled slots on both the first read and the executor's fresh owner.
p=path('ApplyAccessReviewItemDecisionHandler');s=p.read_text();old='''    static AccessReviewItem Open(Uuid tenant, ApplyAccessReviewItemDecision command) =>
        new(tenant, command.CampaignId, command.ItemId, command.CommandId);''';new='''    static AccessReviewItem Open(Uuid tenant, ApplyAccessReviewItemDecision command)
    {
        var owner = new AccessReviewItem(tenant, command.CampaignId, command.ItemId, command.CommandId);
        return owner.ForSourceUses(owner.BulkKey(command.OperationId));
    }''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=path('AuthorizeAccessReviewItemCampaignCompletionUseHandler');s=p.read_text();old='        var owner = await _reader.HydrateAsync(Open(request, Uuid.Empty), ct).ConfigureAwait(false);';new='''        var selected = Open(request, Uuid.Empty);
        selected.ForSourceUses(selections.Select(selection => selected.BulkKey(selection.DecisionBatchId)).ToArray());
        var owner = await _reader.HydrateAsync(selected, ct).ConfigureAwait(false);''';assert old in s;s=s.replace(old,new);p.write_text(s)
print('migrated all inventoried production lookup sites and generic fresh owner factories')
