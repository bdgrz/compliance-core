from pathlib import Path
import json,re
r=Path('/tmp/compliance-source-use-reservations-prepared');w=r/'work'
p=w/'src/Compliance.Core/Features/SourceUse/SourceUseHistoryDigest.cs';p.write_text('''using System.Buffers.Binary;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceUse;

/// <summary>
/// A bounded rolling commitment to the actual ordered payloads and immutable metadata identity seen by replay.
/// Save attribution is stamped after RaiseEvent and is checked on selected actual facts, not mixed into this cut.
/// </summary>
static class SourceUseHistoryDigest
{
    public static string Empty { get; } = new('0', 64);

    public static string Append(string previous, DomainEvent fact)
    {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        Add(hash, Encoding.UTF8.GetBytes(previous));
        Add(hash, Encoding.UTF8.GetBytes(fact.GetType().FullName!));
        Add(hash, JsonSerializer.SerializeToUtf8Bytes(fact,
            ComplianceCoreJsonContext.Default.GetTypeInfo(fact.GetType())!));
        var metadata = fact.Metadata;
        Add(hash, Encoding.UTF8.GetBytes(metadata.EventId.ToString()));
        Add(hash, Encoding.UTF8.GetBytes(metadata.AggregateId.ToString()));
        Add(hash, Encoding.UTF8.GetBytes(metadata.AggregateVersion.ToString(CultureInfo.InvariantCulture)));
        Add(hash, Encoding.UTF8.GetBytes(metadata.OccurredOn.ToString("O", CultureInfo.InvariantCulture)));
        Add(hash, [metadata.IsAudit ? (byte)1 : (byte)0]);
        return Convert.ToHexStringLower(hash.GetHashAndReset());
    }

    static void Add(IncrementalHash hash, ReadOnlySpan<byte> bytes)
    {
        Span<byte> length = stackalloc byte[sizeof(int)];
        BinaryPrimitives.WriteInt32LittleEndian(length, bytes.Length);
        hash.AppendData(length);
        hash.AppendData(bytes);
    }
}
''')
p=w/'src/Compliance.Core/Features/SourceUse/SourceUseReservations.cs';s=p.read_text().replace('    ulong _verifiedPosition;','    ulong _verifiedPosition;\n    string _historyDigest = SourceUseHistoryDigest.Empty;\n    ulong _ownerFacts;');s=s.replace('        if (_observed)\n            throw new InvalidOperationException("Select','        if (_observed || _ownerFacts != 0)\n            throw new InvalidOperationException("Select');s=s.replace('    internal void BeginHydration()', '''    internal void ObserveOwnerFact(DomainEvent fact)
    {
        _historyDigest = SourceUseHistoryDigest.Append(_historyDigest, fact);
        _ownerFacts = checked(_ownerFacts + 1);
        _verified = false;
    }

    internal void BeginHydration()''');s=s.replace('        if (Generation != history.Generation || _active.Count != history.Active.Count ||','        if (_ownerFacts != ownerVersion || _historyDigest != history.Digest ||\n            Generation != history.Generation || _active.Count != history.Active.Count ||');p.write_text(s)
p=w/'src/Compliance.Core/Features/SourceUse/SourceUseHistoryValidation.cs';s=p.read_text().replace('    public ulong Generation { get; private set; }','    public ulong Generation { get; private set; }\n    public string Digest { get; private set; } = SourceUseHistoryDigest.Empty;\n\n    public void ObserveOwnerFact(DomainEvent fact) => Digest = SourceUseHistoryDigest.Append(Digest, fact);');p.write_text(s)
p=w/'src/Compliance.Core/Features/SourceUse/SourceUseAggregateReader.cs';s=p.read_text().replace('            if (SourceUseFactKinds.Classify(record.Event)', '            history.ObserveOwnerFact(record.Event);\n            if (SourceUseFactKinds.Classify(record.Event)');p.write_text(s)
# Current identity + all ordered payloads, not just current live grants, bind the validated cut.
n=0
for x in json.loads((r/'inventory.json').read_text())['owners']:
 p=w/x['path'];s=p.read_text()
 if ': Aggregate, ISourceUseOwner' not in s:continue
 assert 'override void Apply(' not in s,p
 at=s.rfind('}')
 s=s[:at]+'''    protected override void Apply(DomainEvent value)
    {
        base.Apply(value);
        Uses.ObserveOwnerFact(value);
    }
'''+s[at:];p.write_text(s);n+=1
print('installed bounded full-cut digest on',n,'concrete owners')
