# Frozen SourceUseReservations53 offline handoff

This is a separate follow-on after frozen catalog53, with current main snapshots for other paths. Parent alone applies changes, runs .NET/format/analyzers, proves RED/GREEN, reviews every changed file with Jev, and delivers. No main files, Git state, issues, worktrees, brokers or memory were changed here.

## Problem and result

The old component retains every settled/fenced slot in a lifetime dictionary. The prepared component keeps live grants, explicitly requested historical slots, a grant counter and a bounded rolling commitment to the actual replayed payload/immutable metadata cut. Historical authority remains the existing ordered native stream; no new grant, release, source-use, immutable-node, wire or JSON contract is introduced.

`SourceUseAggregateReader` calls the original keyed reader, then validates the entire exact native owner cut using a transient full dictionary. That pass rejects an unselected late grant after a historical fence or a second historical settlement. It verifies full key scope, actual physical resource offsets, metadata identity/version, full payload cut, and complete selected native metadata. Missing/truncated history never proves absence. Only live+selected facts survive in the returned owner.

`ForSourceUses(key...)` or `ForSourceUse(owner => exactKey)` must select historical keys before hydration. Existing `Find` and `GrantOf` operate on live or selected state; unknown historical lookup throws instead of pretending absence. A selected absence is authorized only by complete exact-cut finalization. A genuinely empty owner may prove absence locally. The original full tuple is preserved: target owner stream, root operation, first owner, source generation, purpose.

Every32 existing grant/settle producer method requires selected finalized evidence for its exact current owner Version and CommittedStreamPosition before emitting. Generic receivers select the key for both their explicit reads and their fresh executor owner. Real source verification/disposition, current caller authorization, source pins, exact native retry, original first responses and OCC gates stay in the owning protocols. No mutable content body read was added by finalization.

## Patch stages

1. Apply `tests-red.patch` alone and run `FullyQualifiedName~SourceUseReservationsNativeBoundaryTests`: its existing-API test is expected RED because the old component retains128 terminal entries.
2. Apply `implementation.patch`, then the single shared delta `shared.patch`.
3. Apply `migrated-tests.patch` and `native-tests.patch`.

For final-only integration use `implementation.patch`, `shared.patch`, `tests-full.patch`. `reconstruction.json` proves both orders reproduce all53 final C# files exactly. `manifest.json` records every before/after SHA; all45 existing/layered paths have nonnull saved originals. Eight paths are new. Full snapshot trees remain under `base/` and `work/`, but **only manifest paths belong to this handoff**; do not overwrite unrelated files from these snapshots.

Shared wiring is only `Hosting/Persistence/PersistenceServiceCollectionExtensions.cs`: retain the original scoped `IAggregateReader` registration under the existing opaque-key decoration mechanism and wrap it with `SourceUseAggregateReader(inner, IDomainEventReader)`. Event-store safety decoration happens first. The original keyed factory resolves its original AggregateRepository, not the decorated interface. The registered executor resolves the decorated reader at its scope. Non-source owners forward directly. See `wiring.json` and `SDK-QUALIFICATION.md`; actual registration qualification is a parent runtime gate.

## Verification prepared

The old-API retention RED and native regressions cover long compact state, unselected duplicate grants/settlements, first-owner/generation/purpose scope, original grant after settlement, actual terminal metadata, selected metadata substitution, truncated and substituted historical cuts, local empty absence, audit-session physical offsets, and production DI/executor registration. Existing real-process fixtures retain their acceptance names/assertions and select terminal keys explicitly. The handoff preserves74 existing acceptance names. Static tree-sitter parsing and369 explicit constructor calls pass; all changed-path originals, token position, duplicate-using and assertion/name preservation gates pass.

Parent should run the `handoff.json` focused filters, then `Category!=BrokerIntegration` full suite. Direct per-file Jev and actual runtime RED/GREEN remain unrun. O(N) transient validation/scans remain; this change bounds returned **domain component** state by live+selected slots, and makes no constant-time or SDK infrastructure memory claim.

The13 source owners with existing pairs retain all32 native reducer hooks. ControlDraft still implements ISourceUseOwner but has no actual selected source-use pair; no such producer was invented. This work does not compact unrelated owner histories (for example practice commitments or bulk-decision business state). Risk109, Calendar28, Boundary and catalog53 artifacts remain frozen and untouched.
