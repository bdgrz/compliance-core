from pathlib import Path
import re
r=Path('/tmp/compliance-source-use-reservations-prepared/work');root=r/'test/Compliance.Tests'
def get(name):
 xs=list(root.rglob(name+'.cs'));assert len(xs)==1,(name,xs);return xs[0]
def imp(s):return s if 'using Bdgrz.Compliance.Features.SourceUse;' in s else 'using Bdgrz.Compliance.Features.SourceUse;\n'+s
def endparen(s,start):
 level=0
 for i in range(start,len(s)):
  if s[i]=='(':level+=1
  elif s[i]==')':
   level-=1
   if level==0:return i
 raise Exception('no paren')
def wrap(s,needle,select):
 start=s.index(needle);pos=s.index('(',s.index('new ',start));end=endparen(s,pos);return s[:end+1]+f'.ForSourceUse(candidate => {select})'+s[end+1:]
# Existing acceptance names and assertions stay intact; only explicit selections are added.
p=get('ProfessionalDutyChangeTests');s=p.read_text().replace('host.HydrateAsync(new FirmStaffRecord(staff))).Uses.Find(key)', 'host.HydrateAsync(new FirmStaffRecord(staff).ForSourceUses(key))).Uses.Find(key)');s=s.replace('        var staffRecord = await host.HydrateAsync(new FirmStaffRecord(staff));\n        var key = await host.StaffUseKeyAsync(await host.HydrateAsync(Owner(user)), active.Evidence.AssertionId);','        var key = await host.StaffUseKeyAsync(await host.HydrateAsync(Owner(user)), active.Evidence.AssertionId);\n        var staffRecord = await host.HydrateAsync(new FirmStaffRecord(staff).ForSourceUses(key));');s=s.replace('        // Act\n        uses.ApplyGranted(SourceUsePurpose.ProfessionalDutyRecording, Granted(owner, first));','        uses.Select(first);\n        uses.Select(second);\n        uses.Select(third);\n\n        // Act\n        uses.ApplyGranted(SourceUsePurpose.ProfessionalDutyRecording, Granted(owner, first));');s=s.replace('        uses.ApplyGranted(SourceUsePurpose.ProfessionalDutyRecording, Granted(target, first));','        uses.Select(first);\n        uses.Select(second);\n        uses.ApplyGranted(SourceUsePurpose.ProfessionalDutyRecording, Granted(target, first));');p.write_text(imp(s))
p=get('EngagementPersonalDecisionTests');s=p.read_text();needle='var service0 = await host.HydrateAsync(new ClientServiceIndependence(host.Tenant))';s=wrap(s,needle,'EngagementPersonalDecisionEffects.UseKey(command.AcknowledgementId, engagementStream, candidate.Stream)');start=s.index('    static async Task<IReadOnlyList<(string Area, SourceUseEntry? Entry)>> UseEntriesAsync');part=s[start:]
for m in reversed(list(re.finditer(r'await host.HydrateAsync\(new (?:ClientServiceIndependence|FirmStaffRecord|FirmProfessionalDutyDesignation|IndependenceRuleCatalog|IndependenceRuleRatificationCatalog)\(',part))):
 pos=part.index('(',part.index('new ',m.start()));end=endparen(part,pos);part=part[:end+1]+'.ForSourceUse(candidate => EngagementPersonalDecisionEffects.UseKey(decision, engagementStream, candidate.Stream))'+part[end+1:]
s=s[:start]+part;p.write_text(imp(s))
p=get('PracticeIndependenceCommitmentTests');s=p.read_text();needle='var owner = await host.HydrateAsync(new PracticeIndependenceCommitment(host.Tenant, PracticeSubjectKind.Staff,';s=wrap(s,needle,'new ReservationKey(operation, candidate.Stream, 1, candidate.Stream, "actual_staff_assignment")');# actual same-practice second acquisition needs a distinct known key.
s=s.replace('        var same = await executor.ExecuteAsync(new PracticeIndependenceCommitment(host.Tenant,','        var sameOperation = Uuid.CreateVersion4();\n        var same = await executor.ExecuteAsync(new PracticeIndependenceCommitment(host.Tenant,');s=s.replace('PracticeSubjectKind.Staff, subject, Uuid.Empty, "attest", Uuid.CreateVersion4()), owner =>\n            AggregateOutcome.Commit(owner.Reserve(Reserve(Uuid.CreateVersion4()), Intent, 1))','PracticeSubjectKind.Staff, subject, Uuid.Empty, "attest", Uuid.CreateVersion4()).ForSourceUse(candidate =>\n                new ReservationKey(sameOperation, stream, 1, candidate.Stream, "actual_staff_assignment")), owner =>\n            AggregateOutcome.Commit(owner.Reserve(Reserve(sameOperation), Intent, 1))');p.write_text(imp(s))
p=get('PracticeCommitmentFacts');s=p.read_text()
for m in reversed(list(re.finditer(r'executor.ExecuteAsync\(new PracticeIndependenceCommitment\(',s))):
 pos=s.index('(',s.index('new ',m.start()));end=endparen(s,pos);s=s[:end+1]+'.ForSourceUse(candidate => new ReservationKey(operationId, stream, 1, candidate.Stream, "actual_staff_assignment"))'+s[end+1:]
p.write_text(imp(s))
p=get('ServiceEngagementAcceptanceTests');s=p.read_text();start=s.index('        var user = await host.HydrateAsync(new PracticeIndependenceCommitment(host.Tenant,\n            PracticeSubjectKind.CanonicalUser, lead.UserId));');end=s.index('    [Fact]',start);part=s[start:end]
for m in reversed(list(re.finditer(r'host.HydrateAsync\(new PracticeIndependenceCommitment\(',part))):
 pos=part.index('(',part.index('new ',m.start()));finish=endparen(part,pos);part=part[:finish+1]+'.ForSourceUse(candidate => EngagementAcceptanceEffects.UseKey(command.CommandId, stream, candidate.Stream))'+part[finish+1:]
s=s[:start]+part+s[end:];p.write_text(imp(s))
p=get('EngagementAcceptanceProcessTests');s=p.read_text();needle='var service = await host.HydrateAsync(new ClientServiceIndependence(host.Tenant));';s=wrap(s,needle,'EngagementAcceptanceEffects.UseKey(command.CommandId, stream, candidate.Stream)');needle='var owner = await host.HydrateAsync(new PracticeIndependenceCommitment(host.Tenant, subject.Kind,';s=wrap(s,needle,'EngagementAcceptanceEffects.UseKey(command.CommandId, stream, candidate.Stream)');s=s.replace('HydrateOwnerAsync(host, requirement.SourceOwner, partner)','HydrateOwnerAsync(host, requirement.SourceOwner, partner,\n                EngagementAcceptanceEffects.UseKey(command.CommandId, stream, requirement.SourceOwner))');s=s.replace('        PartnerSetup partner)\n    {\n        switch (stream.Area)','        PartnerSetup partner, ReservationKey selectedUse)\n    {\n        switch (stream.Area)');start=s.index('    static async Task<ISourceUseOwner> HydrateOwnerAsync');part=s[start:]
for m in reversed(list(re.finditer(r'host.HydrateAsync\(new (?:ClientServiceIndependence|FirmStaffRecord|FirmProfessionalDutyDesignation|IndependenceRuleCatalog|IndependenceRuleRatificationCatalog)\(',part))):
 pos=part.index('(',part.index('new ',m.start()));end=endparen(part,pos);part=part[:end+1]+'.ForSourceUses(selectedUse)'+part[end+1:]
s=s[:start]+part;p.write_text(imp(s))
# Test-only participant read helper accepts explicit selected key, preserving all existing calls.
p=get('CampaignSeed');s=p.read_text();s=s.replace('        Uuid campaignId, Uuid personId)\n    {\n        await using var scope = provider.CreateAsyncScope();\n        return await scope.ServiceProvider.GetRequiredService<IAggregateReader>()\n            .HydrateAsync(new PolicyCampaignParticipant(tenantId, campaignId, personId));','        Uuid campaignId, Uuid personId, ReservationKey? selectedUse = null)\n    {\n        await using var scope = provider.CreateAsyncScope();\n        var owner = new PolicyCampaignParticipant(tenantId, campaignId, personId);\n        if (selectedUse is not null)\n            owner.ForSourceUses(selectedUse);\n        return await scope.ServiceProvider.GetRequiredService<IAggregateReader>().HydrateAsync(owner);');p.write_text(imp(s))
p=get('CampaignHost');s=p.read_text().replace('ParticipantAsync(Uuid campaignId, Uuid person) =>\n        CampaignSeed.ParticipantAsync(_provider, Tenant, campaignId, person);','ParticipantAsync(Uuid campaignId, Uuid person, ReservationKey? selectedUse = null) =>\n        CampaignSeed.ParticipantAsync(_provider, Tenant, campaignId, person, selectedUse);');p.write_text(imp(s))
p=get('PolicyCampaignClosureProcessTests');s=p.read_text();old='        var participant = await host.ParticipantAsync(campaign, host.LearnerPerson);';pattern='        var key = PolicyCampaignClosureEffects.UseKey(closeId, owner.Stream, 1, participant.Stream);'
# Two terminal assertions, not live-only fixture reads.
for m in reversed(list(re.finditer(re.escape(old),s))):
 tail=s[m.end():];keyAt=tail.find(pattern)
 if keyAt<0 or keyAt>230:continue
 replacement='''        var key = PolicyCampaignClosureEffects.UseKey(closeId, owner.Stream, 1,
            new PolicyCampaignParticipant(host.Tenant, campaign, host.LearnerPerson).Stream);
        var participant = await host.ParticipantAsync(campaign, host.LearnerPerson, key);'''
 end=m.end()+keyAt+len(pattern)
 between=s[m.end():m.end()+keyAt]
 s=s[:m.start()]+replacement+between+s[end:]
p.write_text(imp(s))
# Minimal catalog fixture uses Portia's real executor with the same verified reader boundary.
p=get('IndependenceCatalogSourceFixture');s=p.read_text().replace('Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>(); Writer','Reader = new SourceUseAggregateReader(_scope.ServiceProvider.GetRequiredService<IAggregateReader>(), Events); Writer').replace('Executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();','Executor = new AggregateExecutor(Reader, Writer);');p.write_text(imp(s))
p=get('IndependenceRuleCatalogLifetimeTests');s=p.read_text();# source key identity is known before either hydration.
s=s.replace('        var catalog = await fixture.Reader.HydrateAsync(new IndependenceRuleCatalog());\n        var root = Uuid.CreateVersion4();','        var root = Uuid.CreateVersion4();\n        var catalog = await fixture.Reader.HydrateAsync(new IndependenceRuleCatalog().ForSourceUse(candidate =>\n            new ReservationKey(root, candidate.Stream, 1, candidate.Stream, "engagement_personal_decision")));');s=s.replace('        var catalog = await fixture.Reader.HydrateAsync(new IndependenceRuleRatificationCatalog());\n        var root = Uuid.CreateVersion4();','        var root = Uuid.CreateVersion4();\n        var catalog = await fixture.Reader.HydrateAsync(new IndependenceRuleRatificationCatalog().ForSourceUse(candidate =>\n            new ReservationKey(root, candidate.Stream, 1, candidate.Stream, "engagement_personal_decision")));');s=s.replace('        var settled = catalog.SettleEngagementUse(Provenance(catalog.Stream, Uuid.CreateVersion4(), root), Intent, 1);','        catalog = await fixture.Reader.HydrateAsync(catalog);\n        var settled = catalog.SettleEngagementUse(Provenance(catalog.Stream, Uuid.CreateVersion4(), root), Intent, 1);');p.write_text(imp(s))
print('migrated existing terminal-proof assertions and producer fixtures without renaming acceptance methods')
