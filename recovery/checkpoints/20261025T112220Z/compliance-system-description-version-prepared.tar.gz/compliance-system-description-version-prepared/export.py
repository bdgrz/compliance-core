from pathlib import Path
import json,hashlib,difflib,shutil,subprocess,re,sys
r=Path('/tmp/compliance-system-description-version-prepared');sd=Path('/tmp/compliance-system-description-prepared')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def diff(a,b,p):return ''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+str(p) if a else '/dev/null',tofile='b/'+str(p)))
patches={n:[] for n in ['full.patch','implementation.patch','tests.patch','behavioral-red.patch','after-red.patch']};manifest=[]
for p in sorted((r/'work').rglob('*.cs')):
 rel=p.relative_to(r/'work');b=r/'base'/rel;before=b.read_text() if b.exists() else '';after=p.read_text();kind='test' if rel.parts[0]=='test' else 'implementation'
 patch=diff(before,after,rel);patches['full.patch'].append(patch);patches['tests.patch' if kind=='test' else 'implementation.patch'].append(patch)
 red=r/'red'/rel;redtext=red.read_text() if red.exists() else before
 if redtext!=after:patches['after-red.patch'].append(diff(redtext,after,rel))
 if red.exists():patches['behavioral-red.patch'].append(diff(before,redtext,rel))
 manifest.append({'path':str(rel),'kind':kind,'before_sha256':sha(b) if b.exists() else None,'after_sha256':sha(p),'frozen101_unchanged':sha(sd/'work'/rel)==sha(b) if b.exists() else not(sd/'work'/rel).exists()})
for n,parts in patches.items():(r/n).write_text(''.join(parts))
checks=[]
for name,seq in [('full',['full.patch']),('red-green',['behavioral-red.patch','after-red.patch']),('partitioned',['implementation.patch','tests.patch'])]:
 d=r/'verify'/name
 if d.exists():shutil.rmtree(d)
 shutil.copytree(r/'base',d)
 for patch in seq:
  x=subprocess.run(['patch','--batch','-p1','-d',str(d),'-i',str(r/patch)],capture_output=True,text=True)
  assert x.returncode==0,x.stdout+x.stderr
 bad=[m['path'] for m in manifest if sha(d/m['path'])!=m['after_sha256']];assert not bad
 checks.append({'route':name,'mismatches':bad})
sys.path.insert(0,'/tmp/compliance-csharp-syntax314');from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));errors=[str(p.relative_to(r/'work')) for p in (r/'work').rglob('*.cs') if parser.parse(p.read_bytes()).root_node.has_error];assert not errors
assert all(m['frozen101_unchanged'] for m in manifest)
# All actual literal gate occurrences; business narrative Version 1 is intentionally not a wire schema gate.
tags={row['name'] for row in json.loads((r/'audit.json').read_text())};gates=[]
roots=[Path('/Users/jrepanich/Code/bdgrz/compliance-core/src'),sd/'work',sd/'shared-work',Path('/tmp/compliance-incident-native-prepared/work'),Path('/tmp/compliance-significant-change-prepared/work'),Path('/tmp/compliance-source-byte-closure-prepared/work')]
for root in roots:
 if not root.exists():continue
 for p in root.rglob('*.cs'):
  for line,text in enumerate(p.read_text().splitlines(),1):
   if any(tag in text for tag in tags):gates.append({'path':str(p),'line':line,'kind':'discriminator_declaration' if '[Discriminator(' in text else 'literal_version_consumer','text':text.strip()})
assert not any(g['kind']=='literal_version_consumer' for g in gates)
static={'syntax_errors':errors,'native_tags_advanced':len(tags),'parameter_or_payload_changes':False,'literal_consumer_version_gates':[],'all_literal_occurrences':gates,'frozen101_sources_unchanged':True,'reconstruction':checks,'new_acceptance_methods':3,'new_acceptance_rows':10,'runtime':'Not run; root owns focused RED/GREEN, compiler/analyzers, tests/Jev/Git.'}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(r/'static-checks.json').write_text(json.dumps(static,indent=2)+'\n');(r/'reconstruction.json').write_text(json.dumps(checks,indent=2)+'\n')
(r/'README.md').write_text('''# System Description occupied wire-version correction

Separate frozen overlay atop `/tmp/compliance-system-description-prepared` (SD101). SD101 artifacts remain byte-for-byte unchanged. Apply SD101 first, then behavioral-red.patch and run focused-filter.txt before applying after-red.patch. Full.patch or implementation.patch+tests.patch are exact alternative reconstruction routes.

All eight legacy facts in SD101 base and current main already occupy the same discriminator name@1. They carry inline typed Version/Review/Approval/Decision/Binding. SD101 replaces each payload with verified immutable refs and native operation/first response/result/header/current authority/sequence/actor fields while incorrectly retaining name@1. This is incompatible: all eight names advance to version2, preserving names and the entire frozen SD101 native payload unchanged. No lower version is reused or downgraded.

The source-backed audit records exact original/main/native hashes and field-boundary reason. Actual main, SD101+shared, queued Incident/Change and byte-closure source consumers have no literal wire-version1 gates for these names. SourceFact EventKind.Of derives name@2 dynamically, and the Portia event catalog/serializer resolves exact name+version. Therefore no consumer source change is required; narrative version numbers, immutable content schema strings and business logical/native sequence counters remain unchanged.

The focused test includes eight explicit expected wire-kind rows, real native creation persistence canonical round-trip, refusal of an actual old inline-v1 envelope, and exact actual-resource-offset source proof verification that accepts native@2 but rejects legacy@1 while preserving business OwnerRevision1. No source proof assumes aggregate-version-minus-one equals physical position.

Final selected target-event JSON and the original SD101 README claim version1 and are stale metadata. Root owns explicit reconciliation and any source inventory map export; this overlay edits no catalog or frozen101 document. No legacy converter/upcaster/dual reader, store reset, deployed migration, new public callback, SourceUse authority or routing contract is introduced. Incident/Change consumers and currentSourceUse receipt/proof semantics remain as prepared.

Static modern C# syntax and all three exact reconstruction routes pass. Actual runtime, strict/analyzers, focused/full, per-file Jev and integration remain root-owned and unrun here.
''')
art={n:{'sha256':sha(r/n),'bytes':(r/n).stat().st_size} for n in patches};hand={'root':str(r),'status':'frozen offline; root runtime/integration pending','prerequisite':'/tmp/compliance-system-description-prepared/handoff.json','paths':len(manifest),'source_paths':8,'test_paths':1,'manifest_sha256':sha(r/'manifest.json'),'patches':art,'audit':'audit.json','consumer_gates':'static-checks.json','new_acceptance_rows':10,'frozen101_unchanged':True,'syntax_errors':errors,'reconstruction':checks,'catalog_reconciliation':'Root must explicitly reconcile final target-event version1 metadata and stale SD101 README claim; no catalog edits supplied.'};(r/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(hand,indent=2))
