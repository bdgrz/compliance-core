from pathlib import Path
import json,re,shutil,hashlib
r=Path('/tmp/compliance-system-description-version-prepared');frozen=Path('/tmp/compliance-system-description-prepared');main=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
rows=[]
for p in sorted((frozen/'work/src/Compliance.Common/Features/SystemDescription').glob('*.cs')):
 after=p.read_text();d=re.search(r'\[Discriminator\("([^"]+)",\s*(\d+)\)\]',after)
 if not d or ': DomainEvent' not in after:continue
 rel=p.relative_to(frozen/'work');original=frozen/'base'/rel;live=main/rel
 tag=d.group(1);extract=lambda x: re.search(r'\[Discriminator\("([^"]+)",\s*(\d+)\)\]',x).groups()
 originaltext=original.read_text();livevalue=extract(live.read_text());basevalue=extract(originaltext)
 assert basevalue==livevalue==(tag,'1')
 incompatible=('INativeOperationFact' in after or 'ISystemDescriptionFact' in after) and 'ImmutableContentRef' in after and 'ImmutableContentRef' not in originaltext
 assert incompatible,(rel,'not proven incompatible')
 for folder in ['base','work']:
  q=r/folder/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(after)
 changed=after.replace(f'[Discriminator("{tag}", 1)]',f'[Discriminator("{tag}", 2)]')
 (r/'work'/rel).write_text(changed)
 sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
 rows.append({'path':str(rel),'type':p.stem,'name':tag,'occupied_base_version':1,'occupied_current_main_version':1,'sd101_proposed_version':1,'selected_overlay_version':2,'actual_base_sha256':sha(original),'actual_current_main_sha256':sha(live),'sd101_native_before_sha256':sha(p),'overlay_after_sha256':sha(r/'work'/rel),'incompatible_change':'Inline business view/decision replaced by immutable ref plus native Operation/FirstResponse/Result/authority/header/sequence/attribution; no legacy-v1 converter or dual registration.'})
assert len(rows)==8
(r/'audit.json').write_text(json.dumps(rows,indent=2)+'\n')
p=Path('test/Compliance.Tests/Features/SystemDescription/SystemDescriptionNativeVersionContractTests.cs');q=r/'work'/p;q.parent.mkdir(parents=True,exist_ok=True)
q.write_text('''using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SystemDescription;
using Bdgrz.Compliance.Tests.Hosting.Persistence;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.SystemDescription;

public sealed class SystemDescriptionNativeVersionContractTests
{
    [Theory]
INLINE
    public void ShouldAdvanceOccupiedLegacySchemaGivenIncompatibleNativePayload(Type eventType, string name)
    {
        // Arrange
        var expected = name + "@2";

        // Act
        var actual = EventKind.Of(eventType);

        // Assert
        Assert.Equal(expected, actual);
    }

    [Fact]
    public async Task ShouldPersistExactNativeEnvelopeAndRefuseLegacyInlineV1GivenDescriptionCreation()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        var rules = await fixture.SeedAsync();
        var created = Assert.IsType<SystemDescriptionDraftCreated>(Assert.Single(await fixture.FactsAsync()));
        await using var provider = EventPersistenceFrameTests.Compose();
        var serializer = provider.GetRequiredService<IDomainEventSerializer>();
        var nativeBytes = serializer.Serialize(created);
        var envelope = JsonNode.Parse(nativeBytes.Span)!.AsObject();
        var legacy = new JsonObject
        {
            ["name"] = "bdgrz.systemdescription.system-description-draft-created",
            ["version"] = 1,
            ["metadata"] = envelope["metadata"]!.DeepClone(),
            ["payload"] = new JsonObject
            {
                ["tenant_id"] = created.TenantId.ToString(),
                ["program_id"] = created.ProgramId.ToString(),
                ["system_description_id"] = created.SystemDescriptionId.ToString(),
                ["aggregate_revision"] = 1,
                ["version"] = JsonSerializer.SerializeToNode(rules.CurrentVersion!,
                    ComplianceCoreJsonContext.Default.SystemDescriptionVersionView),
                ["occurred_at"] = created.OccurredAt.ToString("O", CultureInfo.InvariantCulture),
            },
        };
        var oldBytes = Encoding.UTF8.GetBytes(legacy.ToJsonString());

        // Act
        var failure = Record.Exception(() => serializer.Deserialize(oldBytes));
        var restored = Assert.IsType<SystemDescriptionDraftCreated>(serializer.Deserialize(nativeBytes));
        var roundTrip = serializer.Serialize(restored);

        // Assert
        Assert.IsType<InvalidOperationException>(failure);
        Assert.Equal(2, envelope["version"]!.GetValue<int>());
        Assert.Equal("bdgrz.systemdescription.system-description-draft-created", envelope["name"]!.GetValue<string>());
        Assert.Equal(created.Metadata, restored.Metadata);
        Assert.Equal(created.Operation, restored.Operation);
        Assert.Equal(created.VersionContent, restored.VersionContent);
        Assert.Equal(created.CurrentAuthorityContent, restored.CurrentAuthorityContent);
        Assert.Equal(created.FirstResponse, restored.FirstResponse);
        Assert.Equal(created.OperationResult, restored.OperationResult);
        Assert.Equal(nativeBytes.ToArray(), roundTrip.ToArray());
    }

    [Fact]
    public async Task ShouldVerifyNativeV2AndRejectLegacyKindGivenExactBrokerSourceProof()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        await fixture.SeedAsync();
        var snapshot = await fixture.Descriptions.ReadAsync(fixture.Tenant, fixture.Program, fixture.Description);
        var created = Assert.IsType<SystemDescriptionDraftCreated>(Assert.Single(snapshot.Facts));
        ulong? offset = null;
        await foreach (var record in fixture.Events.ReadAsync(snapshot.Stream, 0, CancellationToken.None))
            if (record.Event.Metadata.EventId == created.Metadata.EventId)
                offset = record.ResourceOffset;
        Assert.NotNull(offset);
        var resolver = new EventStoreSourceFactResolver(fixture.Events);
        var source = await resolver.ResolveAsync(snapshot.Stream, offset.Value);
        var locator = source.Locator;
        var required = await fixture.Content.WriteJsonAsync(fixture.Tenant.ToString(), Uuid.CreateVersion4(),
            SourceFactProofs.RequiredFactsSchema, locator);
        var proof = new SourceFactProof<SystemDescriptionDraftCreated>(locator.Source, locator.EventId,
            locator.ResourcePosition, locator.AggregateVersion, EventKind.Of(created), locator.PayloadSha256,
            required, locator.GlobalPosition, locator.RealmPosition);

        // Act
        var verified = await resolver.VerifyAsync(proof);
        var refusal = await Record.ExceptionAsync(() => resolver.VerifyAsync(proof with
        { EventKind = "bdgrz.systemdescription.system-description-draft-created@1" }));

        // Assert
        Assert.Equal("bdgrz.systemdescription.system-description-draft-created@2", proof.EventKind);
        Assert.Equal(1UL, proof.OwnerRevision);
        Assert.Equal(offset.Value, proof.PhysicalPosition);
        Assert.Equal(created.Metadata.EventId, verified.EventId);
        Assert.Equal(created.VersionContent, verified.Facts.VersionContent);
        Assert.IsType<SourceFactVerificationException>(refusal);
    }
}
'''.replace('INLINE','\n'.join('    [InlineData(typeof('+x['type']+'), "'+x['name']+'")]' for x in rows)))
# The overlay RED targets the frozen native101 implementation, not legacy main API.
red=r/'red'/p;red.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,red)
(r/'focused-filter.txt').write_text('FullyQualifiedName~SystemDescriptionNativeVersionContractTests\n')
