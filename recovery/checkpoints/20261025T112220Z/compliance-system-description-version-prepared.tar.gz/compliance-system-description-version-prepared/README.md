# System Description occupied wire-version correction

Separate frozen overlay atop `/tmp/compliance-system-description-prepared` (SD101). SD101 artifacts remain byte-for-byte unchanged. Apply SD101 first, then behavioral-red.patch and run focused-filter.txt before applying after-red.patch. Full.patch or implementation.patch+tests.patch are exact alternative reconstruction routes.

All eight legacy facts in SD101 base and current main already occupy the same discriminator name@1. They carry inline typed Version/Review/Approval/Decision/Binding. SD101 replaces each payload with verified immutable refs and native operation/first response/result/header/current authority/sequence/actor fields while incorrectly retaining name@1. This is incompatible: all eight names advance to version2, preserving names and the entire frozen SD101 native payload unchanged. No lower version is reused or downgraded.

The source-backed audit records exact original/main/native hashes and field-boundary reason. Actual main, SD101+shared, queued Incident/Change and byte-closure source consumers have no literal wire-version1 gates for these names. SourceFact EventKind.Of derives name@2 dynamically, and the Portia event catalog/serializer resolves exact name+version. Therefore no consumer source change is required; narrative version numbers, immutable content schema strings and business logical/native sequence counters remain unchanged.

The focused test includes eight explicit expected wire-kind rows, real native creation persistence canonical round-trip, refusal of an actual old inline-v1 envelope, and exact actual-resource-offset source proof verification that accepts native@2 but rejects legacy@1 while preserving business OwnerRevision1. No source proof assumes aggregate-version-minus-one equals physical position.

Final selected target-event JSON and the original SD101 README claim version1 and are stale metadata. Root owns explicit reconciliation and any source inventory map export; this overlay edits no catalog or frozen101 document. No legacy converter/upcaster/dual reader, store reset, deployed migration, new public callback, SourceUse authority or routing contract is introduced. Incident/Change consumers and currentSourceUse receipt/proof semantics remain as prepared.

Static modern C# syntax and all three exact reconstruction routes pass. Actual runtime, strict/analyzers, focused/full, per-file Jev and integration remain root-owned and unrun here.
