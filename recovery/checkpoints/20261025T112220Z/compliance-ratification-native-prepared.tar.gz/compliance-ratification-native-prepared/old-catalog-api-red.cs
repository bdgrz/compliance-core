using System.Collections;
using System.Reflection;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.AccessControl;

public sealed class IndependenceCatalogNativeBoundaryTests
{
    [Fact]
    public void ShouldRetainOnlyCurrentBusinessAuthorityGivenLongCatalogAndPersonalRatificationHistory()
    {
        // Arrange
        var actor = ActorReference.ForPlatformOperator(Uuid.CreateVersion4(), "Operator");
        var staff = new FirmStaffMemberView(Uuid.CreateVersion4(), Uuid.CreateVersion4(), "attest", "Staff source", true, 1, actor, DateTimeOffset.UtcNow);
        var duty = new FirmProfessionalDutyDesignationView(Uuid.CreateVersion4(), staff.StaffMemberId, staff.UserId, FirmProfessionalDuty.RuleRatifier,
            null, "Duty evidence", 1, true, 1, actor, DateTimeOffset.UtcNow, actor, DateTimeOffset.UtcNow, null);
        var ratifier = ActorReference.ForFirmStaff(staff.UserId, "Ratifier");
        var rules = new IndependenceRuleCatalog();
        var decisions = new IndependenceRuleRatificationCatalog();
        for (var index = 0; index < 105; index++)
        {
            var value = new IndependenceRuleContent(12, [new IndependenceServiceRuleContent("readiness", "conditionally_compatible", "impairing")], "Rules " + index);
            Assert.True(rules.ReviseRules(Uuid.CreateVersion4(), rules.Sequence, value, actor, DateTimeOffset.UtcNow).IsSuccess);
            Assert.True(decisions.Ratify(Uuid.CreateVersion4(), Uuid.CreateVersion4(), index + 1, index + 1, decisions.Sequence,
                IndependenceSourceDigest.RuleContent(value), "Personal evidence", staff, duty, ratifier, DateTimeOffset.UtcNow).IsSuccess);
        }

        // Act
        var history = new object[] { rules, decisions }.SelectMany(owner => owner.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(owner) is ICollection { Count: > 1 })).ToArray();

        // Assert
        Assert.Empty(history);
        Assert.Equal(105, rules.Sequence);
        Assert.Equal(105, decisions.Sequence);
    }

    [Fact]
    public void ShouldAcceptCompleteMaximumClassifiedRuleValueGivenImmutableRuleStorage()
    {
        // Arrange
        var rules = new IndependenceRuleCatalog();
        var content = new IndependenceRuleContent(12, Enumerable.Range(0, 100).Select(index =>
            new IndependenceServiceRuleContent(index.ToString("D3", System.Globalization.CultureInfo.InvariantCulture) + new string('界', 97),
                "conditionally_compatible", "impairing")).ToArray(), new string('界', 2000));

        // Act
        var result = rules.ReviseRules(Uuid.CreateVersion4(), 0, content, ActorReference.ForPlatformOperator(Uuid.CreateVersion4(), "Operator"), DateTimeOffset.UtcNow);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(1, rules.Sequence);
    }
}
