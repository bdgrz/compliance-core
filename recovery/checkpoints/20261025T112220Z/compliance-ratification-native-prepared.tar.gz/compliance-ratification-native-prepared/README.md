# Frozen Independence catalog native handoff

Start with `handoff.json`. `manifest.json` records53 final changed paths with exact original/final/RED hashes. All31 existing changed paths have physical originals in `base/`;22 new paths and final bytes are in `work/`.

The actual owners are `IndependenceRuleCatalog` and `IndependenceRuleRatificationCatalog`. Their business state now retains a current header/content reference, bounded latest native source fact and one selected native acceptance. Full authored versions and personal decisions live in verified linked immutable bodies. Readers compose current values and history; no owner Current/Versions/Active/Ratifications shim remains. The complete current rule catalog stays one value proof, retaining its existing classified-service validation.

Ratification activation remains monotonic and ratification IDs remain globally unique within the catalog history. Native Append verifies exact immutable bytes, owner/actor/intent/gate, previous cut and authenticated historical ID absence; truncated evidence and reused historical IDs conflict without appending. Native facts stay compact when a decoded-valid complete rule value exceeds the prior raw event byte cap.

Current operator authorization precedes revision replay. Current signed professional ratifier authority precedes personal-decision replay and is reconfirmed for new admission. Accepted logical retries return original typed200 bodies before selecting mutable current catalog data. Existing staff/duty continuity and personal attribution remain intact. Business Sequence, native sequence, physical tail, source-use grant generation and metadata aggregate version remain separate.

The actual existing EngagementPersonalDecision catalog acquire/settle/fence APIs and producers are retained. Exact source stream/eventID/metadata version pins still accompany the business ResourceRevision. A mixed-active race is corrected: newer active ratification metadata cannot pin older caller evidence. Historical draft lookup remains available when the current draft is newer than the latest ratified version. Missing/corrupt bodies fail through typed immutable boundaries, including personal admission and acceptance evidence assembly.

## Parent execution

1. Apply `tests-red.patch` to the old catalog API. Run `FullyQualifiedName~IndependenceCatalogNativeBoundaryTests`. Expected actual failures: retained lifetime lists/response dictionaries after105 decisions; raw48KiB rejection of a domain-valid100-service maximum Unicode rule value.
2. Apply `implementation.patch`, `shared.patch`, `migrated-tests.patch`, `native-tests.patch`. Run native/consumer filters in `handoff.json`, actual production-host revision tests, then required backend suite `Category!=BrokerIntegration`.
3. Parent runs format/build/analyzers, direct per-file Jev on exact final source hashes, resolves actual findings and performs delivery.

After RED is captured, `implementation.patch`, `shared.patch`, `tests-full.patch` reconstruct the same final53 files. Both orders were independently applied in isolated `/tmp` directories and matched final bytes exactly; see `reconstruction.json`.

Intentional wire change: `ReviseIndependenceRules(CommandId,ExpectedSequence,Content)` requires the authored UUID. Revision writes use `PUT /api/v1/platform/independence/rules/{command_id}` with the existing typed200 result; the read path remains `/rules`. Ratify maps its existing CommandId to IIdentifiedRequest. Existing native result hooks remain exactly once. Record the UUID/path change in PR and client contract notes.

`wiring.json` lists four scoped services, four JSON roots, constructor deltas and native v2 fields. Shared/helpers use narrow deltas; ProgramManagementServices baseline includes frozen Risk109, and later receipt/SystemDescription/Calendar/native Boundary changes must be preserved.

`audit.json` reports54 C# parses,77 explicit constructor checks and73 retained original acceptance names, with no syntax, arity, token-last, duplicate/import, assertion-count-drop or missing-before findings. New regressions cover real native histories, max payload, malformed intent/absence, immutable classification, exact source pins, current signed-duty retry and actual HTTP byte replay/current operator/malformed input. None were executed by this preparation agent.

Generic SourceUseReservations lifetime settled/fenced state is queued unblocked separate compaction and remains preserved. See `SOURCE-USE-CONSTRAINTS.md` for its exact slot/API/proof semantics and `LOCAL-BLOCKERS.md` for scope, traversal cost, persistence compatibility and remaining evidence gates. No main checkout, .NET, build, broker, Git, worktree, GitHub, Jev, issue or memory mutations were performed.
