using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.PolicyDistribution;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.PolicyDistribution;

public sealed class CampaignLaunchMemberBindingTests
{
    [Theory]
    [InlineData("another_member", false)]
    [InlineData("nonmember_actor", false)]
    [InlineData("malformed_member", false)]
    [InlineData("another_member", true)]
    [InlineData("nonmember_actor", true)]
    [InlineData("malformed_member", true)]
    public async Task ShouldRejectForgedLaunchingMemberGivenCoherentNativeActorAndDefaultOrExecutorRead(string alteration,
        bool execute)
    {
        // Arrange
        await using var host = new CampaignHost();
        var campaignId = await host.LaunchAsync();
        var facts = await host.EventsAsync<DomainEvent>(host.CampaignStream(campaignId));
        var original = Assert.Single(facts.OfType<PolicyCampaignLaunched>());
        var actor = alteration switch
        {
            "nonmember_actor" => original.Actor with { Kind = "organization" },
            "malformed_member" => original.Actor with { Id = "not-a-member-uuid" },
            _ => original.Actor,
        };
        var forged = original with
        {
            Actor = actor,
            ActorMemberId = alteration == "another_member" ? Uuid.CreateVersion4() : original.ActorMemberId,
            Operation = original.Operation with { Actor = actor },
        };
        forged.AttachMetadata(original.Metadata);
        var events = new InMemoryEventStore();
        await events.AppendAsync(host.CampaignStream(campaignId), 0,
            [forged, Assert.Single(facts.OfType<PolicyCampaignAudienceFrozen>())]);
        var services = new ServiceCollection();
        services.AddCompliance(new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Fitz:Endpoint"] = "ws://fitz:4090/ws",
            ["Fitz:ApplicationName"] = "compliance",
        }).Build(), developerAuthentication: true);
        services.AddSingleton<IEventStore>(events);
        services.AddSingleton<IDomainEventReader>(events);
        services.AddSingleton<IKvClient>(new InMemoryKvClient());
        await using var provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true });
        await using var scope = provider.CreateAsyncScope();
        var owner = new PolicyDistributionCampaign(host.Tenant, campaignId);
        var entered = false;

        // Act
        var failure = await Record.ExceptionAsync(async () =>
        {
            if (execute)
                await scope.ServiceProvider.GetRequiredService<IAggregateExecutor>().ExecuteAsync(owner, _ =>
                { entered = true; return AggregateOutcome.Discard(Result.Success); }, new RequestDispatchContext(RequestActor.System));
            else
                await scope.ServiceProvider.GetRequiredService<IAggregateReader>().HydrateAsync(owner);
        });

        // Assert
        Assert.Equal(original.Metadata, forged.Metadata);
        Assert.Equal(forged.Actor, forged.Operation.Actor);
        Assert.Equal(original.Operation.AuthoredIntentSha256, forged.Operation.AuthoredIntentSha256);
        Assert.IsType<ImmutableContentIntegrityException>(failure);
        Assert.False(entered);
    }
}
