# Prepared bounded replay fixes

All edits are isolated snapshots under this directory. Main, the git index, branches and worktrees were not edited. No dotnet build/test, GitHub write or issue creation ran. `manifest.json` records every baseline/prepared SHA; all 72 baseline files matched main when prepared.

## Artifacts and application order

For a compilable behavioral RED before GREEN:

1. Apply `contract-scaffold.patch`: the catalog-selected 17 required DTO identity changes plus mechanical existing-test constructor migrations. This includes no owner or handler behavior fix.
2. Apply `tests.patch`: eight new test declarations (two are two-row theories) plus a strengthened existing creation-replay test, for 11 focused regression rows. Run these focused tests to capture RED; failures are expected until step 3. The regression source uses the selected typed DTO identities, so the scaffold is required before RED compilation.
3. Apply `implementation-body.patch`: owner/handler fixes and provenance on the existing business facts.
4. Apply `shared-routes.patch`: seven catalog-prescribed PUT routes carrying command/draft IDs, plus idempotent commitment creation MCP metadata. No new methodology endpoint is invented and no new DI registration is required.
5. Format, build and run focused tests, then the backend unit suite and repository contract/spec checks. Parent owns these executions.

Alternative single integration: `implementation.patch` + `test-migrations.patch` + `tests.patch` + `shared-routes.patch`. Do not apply `implementation.patch` on top of the split scaffold/body sequence, because it contains both source halves.

The patch files use repository-relative a/ and b/ paths. They were applied with patch -p1 to an isolated baseline reconstruction; its resulting bytes matched every prepared file SHA exactly. `syntax-check.json` is an independent C# tree-sitter parse result. Neither proves semantic compilation or passing tests.

## Resulting behavior

- TemplateApplication creation compares the complete pinned version, key and canonical requester after draft receipts; generated clock and display changes cannot conflict with an exact application retry.
- MethodologyTemplate creation compares its immutable first version/author. Mutations use required CommandId and a selected business fact before latest-version/lifecycle/clock guards.
- MethodologyTemplateContribution proposal no longer requires current Revision == 1 or the old server time. Review/accept use selected CommandId before current status/revision checks. The three distinct actor rules remain in place for new operations.
- Commitment creation requires catalog-selected DraftId, verifies it equals existing IdFor, and compares initial authored content and actor instead of transport RequestId. A new identifier in tests carries its own new deterministic DraftId.
- Control, commitment and policy review/approval compare owner, kind, canonical actor, original caller revision and complete authored request under the same CommandId. Exact replay returns before mutable impact/waiver/source checks. Changed intent conflicts without append. Mutation IDs cannot reuse the immutable resource creation identity.
- Policy captures the selected approval's initial typed view while folding its original fact, so later retirement/supersession cannot change the returned approval body.
- ExaminationEngagement creation retains a frozen initial view; revision has required CommandId and selected receipt checked before current contact/source resolution or stale revision checks.

`AuthoredCommandReplay` uses existing OperationProvenance/NativeAcceptance. Only one selected business fact is retained for retry hydration; no generic receipt events or aggregate lifetime command dictionaries are added. The original source actor/display on business views remains unchanged. The authored operation binding uses the stable actor identity rather than a presentation name, and candidate AcceptedAt is excluded by AcceptedOperationBinding.

## Scope and remaining accepted work

This is a bounded recovery repair for the eight confirmed alerts, not completion of S32/S33/S34. It leaves existing version-history caps, external content-manifest conversion, missing revision/creation callback producers, waiver read-hold protocols and SystemDescription export work in the separate versioned-content plan. Optional provenance permits retained pre-migration facts/test fixtures; full native FirstResponse content descriptors and operation-status routing are not introduced here. No status/result endpoint or realm-wide uniqueness guarantee is enabled. Existing caller authentication and current top-level authorization remain ahead of handler replay.

No external contract decision blocks these eight patches. The seven changed HTTP paths come directly from remaining-command-identities.json. Existing routes whose selected catalog has no HTTP delta retain their existing path and require the new CommandId in their typed request. All command DTO wire discriminators advance to version 2 for changed required shapes.

## Focused regression declarations

- TemplateApplicationTests.ShouldReplayApplicationAfterDraftReceiptGivenLaterClockAndDisplay
- MethodologyTemplateCommandHandlerTests.ShouldReplayOriginalTemplateCommandsGivenLaterPublicationAndClock
- MethodologyTemplateCommandHandlerTests.ShouldReplayContributionProposalAndDecisionsGivenAcceptedContributionAndLaterClock
- CommitmentDraftReplayTests.ShouldReplayOriginalCreateAndRejectNewDraftGivenRetiredService (strengthened)
- ControlActivationHandlerTests.ShouldReplayOnePersonalControlDecisionGivenSameCommandAndChangedIntent (review/approval)
- PersonalCommitmentDecisionTransportTests.ShouldReplayOneCommitmentDecisionGivenSameCommandAndOriginalRevision (review/approval)
- PersonalPolicyDecisionTransportTests.ShouldReturnOriginalReviewGivenSameCommandAfterLaterDraftRevision
- PersonalPolicyDecisionTransportTests.ShouldReturnFirstApprovalBodyGivenExactRetryAfterPolicyRetirement
- ExaminationEngagementCommandHandlerTests.ShouldReplayOriginalCreateAndRevisionGivenLaterEngagementTerms
