from pathlib import Path
import json,hashlib,difflib,subprocess,shutil,re
r=Path('/tmp/compliance-access-receiver-preparation-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
h=lambda b:hashlib.sha256(b).hexdigest()
base_rows={x['path']:x for x in json.loads((r/'baselines.json').read_text())};redrows={x['path']:x for x in json.loads((r/'qualified-red-baselines.json').read_text())}
paths=sorted(str(p.relative_to(r/'work')) for p in (r/'work').rglob('*.cs') if not (r/'base'/p.relative_to(r/'work')).exists() or p.read_bytes()!=(r/'base'/p.relative_to(r/'work')).read_bytes())
assert len(paths)==17
rows=[];impl=[];tests=[];original_names=0
for p in paths:
 b=r/'base'/p;w=r/'work'/p;rb=r/'qualified-red-base'/p;after=w.read_bytes();before=b.read_bytes() if b.exists() else None
 assert not (repo/p).exists() or before is not None,(p,'current existing clean path needs original baseline')
 if before is not None:
  assert p in base_rows and h(before)==base_rows[p]['beforeSha256']
  assert (repo/p).read_bytes()==before,(p,'current production baseline changed')
  impl.append(p)
 else:tests.append(p)
 before_red=rb.read_bytes() if rb.exists() else before
 if p in redrows:assert h(before_red)==redrows[p]['beforeRedSha256']
 oldnames=re.findall(r'\b(Should\w+)\s*\(',before_red.decode()) if before_red and p.startswith('test/') else[]
 assert set(oldnames)<=set(re.findall(r'\b(Should\w+)\s*\(',after.decode()))
 if before_red and p.startswith('test/'):assert after.count(b'Assert.')>=before_red.count(b'Assert.')
 rows.append({'path':p,'partition':'implementation' if before is not None else 'tests','beforeCleanSha256':h(before) if before is not None else None,'beforeRedSha256':h(before_red) if before_red is not None else None,'afterSha256':h(after),'baselineSource':base_rows[p]['baselineSource'] if p in base_rows else None,'qualifiedRedSource':redrows[p]['qualifiedRuntimeSource'] if p in redrows else None,'afterSource':str(w),'originalQualifiedAcceptanceNames':oldnames})
for p,row in base_rows.items():
 if not p.startswith('test/'):continue
 old=(r/'base'/p).read_text();now=(r/'work'/p).read_text();names=re.findall(r'\b(Should\w+)\s*\(',old);original_names+=len(names);assert set(names)<=set(re.findall(r'\b(Should\w+)\s*\(',now))
 assert now.count('Assert.')>=old.count('Assert.')
assert len(impl)==12 and len(tests)==5

def patch(paths,stage):
 out=[]
 for p in paths:
  b=(r/'qualified-red-base'/p) if stage=='red' and (r/'qualified-red-base'/p).exists() else r/'base'/p
  before=b.read_text().splitlines(True) if b.exists() else[];after=(r/'work'/p).read_text().splitlines(True)
  if before==after:continue
  out.append('diff --git a/'+p+' b/'+p+'\n')
  if not b.exists():out.append('new file mode 100644\n')
  out.extend(difflib.unified_diff(before,after,fromfile='a/'+p if b.exists() else '/dev/null',tofile='b/'+p,n=3))
 return ''.join(out)
exports={'implementation.patch':patch(impl,'clean'),'tests.clean.patch':patch(tests,'clean'),'tests.after-red.patch':patch(tests,'red'),'full.clean.patch':patch(paths,'clean'),'full.after-red.patch':patch(paths,'red')}
for n,t in exports.items():(r/n).write_text(t)
reconstruction=[]
for label,stage,patches in [('clean-full','clean',['full.clean.patch']),('clean-partition','clean',['implementation.patch','tests.clean.patch']),('red-full','red',['full.after-red.patch']),('red-partition','red',['implementation.patch','tests.after-red.patch'])]:
 d=r/'reconstruction'/label
 if d.exists():shutil.rmtree(d)
 d.mkdir(parents=True)
 for p in paths:
  b=(r/'qualified-red-base'/p) if stage=='red' and (r/'qualified-red-base'/p).exists() else r/'base'/p
  if b.exists():q=d/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b.read_bytes())
 outputs=[]
 for n in patches:
  result=subprocess.run(['patch','-p1','--batch','--forward','--fuzz=0','-i',str(r/n)],cwd=d,capture_output=True,text=True);assert result.returncode==0,(label,n,result.stdout,result.stderr);outputs.append(result.stdout)
 for row in rows:assert h((d/row['path']).read_bytes())==row['afterSha256'],(label,row['path'])
 assert not list(d.rglob('*.rej')) and not list(d.rglob('*.orig'))
 reconstruction.append({'stage':label,'pathsVerified':len(paths),'patches':patches,'allFinalHashesMatch':True})
(r/'reconstruction.json').write_text(json.dumps(reconstruction,indent=2)+'\n')
(r/'manifest.json').write_text(json.dumps({'status':'FROZEN','paths':rows,'existingOriginalBeforeGate':True,'allCapturedOriginalAcceptanceNamesPreserved':original_names,'qualifiedRedAcceptanceNamesPreserved':sum(len(x['originalQualifiedAcceptanceNames']) for x in rows),'revisionTestRefinement':'Two batch materialization assertions 1 -> actual business revision 0; metadata version remains 1.','runtime':'Parent qualified RED29 against 8ece7f2e; agent did not run .NET or Jev.'},indent=2)+'\n')
helper=repo/'src/Compliance.Core/Features/NativeOperations/NativeReceiverPreparation.cs'
files={n:{'path':str(r/n),'sha256':h((r/n).read_bytes())} for n in [*exports,'README.md','LOCAL-QUALIFICATIONS.md','BINDINGS.md','manifest.json','static-audit.json','method-audit.json','reconstruction.json','qualified-red-baselines.json']}
handoff={'status':'FROZEN','artifact':str(r),'paths':len(paths),'production':len(impl),'tests':len(tests),'constructorDeltas':[],'sharedWiringDeltas':[],'nativeDtoTagOrRouteDeltas':[],'prerequisite':{'helper':str(helper),'sha256':h(helper.read_bytes()),'qualification':'Shipping Policy shared NativeReceiverPreparation; reused unchanged.'},'qualifiedRed':{'rows':29,'base':'8ece7f2e','filters':['FullyQualifiedName~AccessItemReceiverPreparationTests','FullyQualifiedName~AccessBatchReceiverPreparationTests','FullyQualifiedName~AccessCompletionReceiverPreparationTests','FullyQualifiedName~AccessBulkReceiverPreparationTests'],'baseline':str(r/'qualified-red-base'),'variant':'Bulk V3 exact qualified archive bytes; V1/V2 unqualified and preserved.'},'addedGreenRows':31,'focusedFilter':'Category!=BrokerIntegration&Category!=WebIntegration&(FullyQualifiedName~AccessReviews|FullyQualifiedName~NativeReceiverPreparation)','patchAlternatives':{'clean':['implementation.patch','tests.clean.patch'],'afterExactQualifiedRed':['implementation.patch','tests.after-red.patch']},'staticOnly':True,'reconstruction':reconstruction,'files':files,'localQualifications':str(r/'LOCAL-QUALIFICATIONS.md')}
(r/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'handoffSha256':h((r/'handoff.json').read_bytes()),'manifestSha256':h((r/'manifest.json').read_bytes()),'readmeSha256':h((r/'README.md').read_bytes()),'paths':len(paths),'originalAcceptanceNamesPreserved':original_names,'exports':{n:h((r/n).read_bytes()) for n in exports}},indent=2))
