from pathlib import Path
r=Path('/tmp/compliance-access-receiver-preparation-prepared')
p='src/Compliance.Core/Features/AccessReviews/PublishAccessReviewDecisionBatchHandler.cs';s=(r/'base'/p).read_text().replace('var bulk = await verifier.VerifyAsync(', 'var bulk = await verifier.ReadNativeAsync(')
s=s.replace('        var intent = bulk.Intent!;\n','')
s=s.replace('command.Source.EventId, intent.Header, command.Target, clock.GetUtcNow());','command.Source.EventId, AccessReviewIntentBindings.HeaderOf(bulk.Admitted!.Operation), command.Target, clock.GetUtcNow());')
a=s.index('        var batch = await reader.HydrateAsync(');b=s.index('        for (var attempt',a)
s=s[:a]+'''        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewDecisionBatch, PreparedPublication>(reader,
            () => new AccessReviewDecisionBatch(tenant, campaignId, command.DecisionBatchId, command.CommandId),
            owner => Decide(owner, binding, command, provenance),
            (owner, token) => PrepareAsync(tenant, campaignId, command, bulk, owner, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var prepared = preparation.Value.Value!;
        if (prepared.Outcome is { } terminal)
            return terminal;
        var result = prepared.Content!;
'''+s[b:]
s=s.replace('Decide(fresh, binding)','Decide(fresh, binding, command, provenance)')
a=s.index('    async Task<Verified> VerifyProofsAsync(')
s=s[:a]+'''    async ValueTask<Result<PreparedPublication>> PrepareAsync(Uuid tenant, Uuid campaignId,
        PublishAccessReviewDecisionBatch command, AccessReviewBulk native, AccessReviewDecisionBatch batch, CancellationToken ct)
    {
        var bulk = await verifier.PrepareAsync(tenant, native, ct).ConfigureAwait(false);
        if (bulk.Error is not null)
            return Result<PreparedPublication>.Failure(bulk.Error);
        if (batch.Accepted is null)
            return Result<PreparedPublication>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The batch is not materialized yet.", true));
        try
        {
            var verified = await VerifyProofsAsync(tenant, campaignId, command, bulk.Intent!, ct).ConfigureAwait(false);
            if (verified.Outcome is { } outcome)
                return outcome.IsSuccess
                    ? Result<PreparedPublication>.Success(new PreparedPublication(null, outcome))
                    : Result<PreparedPublication>.Failure(outcome.Error!);
            var body = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion5(command.CommandId, "result-body"),
                AccessReviewContent.BulkResultSchema, new BulkAccessDecisionResult(verified.Decisions!), ct)
                .ConfigureAwait(false);
            var result = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion5(command.CommandId, "result"),
                "mutation-result-content.v1", new MutationResultContent(AccessReviewContent.BulkResultSchema,
                    new StandardResponseBody(body)), ct).ConfigureAwait(false);
            return Result<PreparedPublication>.Success(new PreparedPublication(result, null));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedPublication>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen bulk decision cannot be verified yet: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
s=s.replace('static Result<ReceiverOutcome>? Decide(AccessReviewDecisionBatch batch, AcceptedOperationBinding binding)\n    {','''static Result<ReceiverOutcome>? Decide(AccessReviewDecisionBatch batch, AcceptedOperationBinding binding,
        PublishAccessReviewDecisionBatch command, OperationProvenance provenance)
    {
        if (batch.Accepted is { } materialized &&
            (materialized.Intent != command.Intent || materialized.Operation.RootOperationId != command.OperationId ||
                materialized.Operation.CausationEventId != command.Source.EventId || materialized.Operation.FirstOwner != provenance.FirstOwner))
            return SourceUseReceiverSupport.Permanent("The materialized batch has another exact native admission.");
        if (batch.Published is { } prior &&
            (prior.Intent != command.Intent || prior.Operation.RootOperationId != command.OperationId ||
                prior.Operation.CausationEventId != command.Source.EventId || prior.Operation.FirstOwner != provenance.FirstOwner ||
                AcceptedOperationBinding.Of(prior.Operation with { LogicalId = provenance.LogicalId }) != binding))
            return SourceUseReceiverSupport.Permanent("The published batch has another exact native source binding.");
        // Publication is irreversible. As before, its accepted retry returns the recorded proof set and result.
        // A new publication must verify the incoming proof claim in PrepareAsync.''')
s=s.replace('    sealed record Verified(', '    sealed record PreparedPublication(ImmutableContentRef? Content, Result<ReceiverOutcome>? Outcome);\n\n    sealed record Verified(')
(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/AccessReviews/CompleteAccessReviewDecisionBatchCancellationHandler.cs';s=(r/'base'/p).read_text().replace('var bulk = await verifier.VerifyAsync(', 'var bulk = await verifier.ReadNativeAsync(')
s=s.replace('        var intent = bulk.Intent!;\n','').replace('nameof(CompleteAccessReviewDecisionBatchCancellation), command.Source.EventId, intent.Header, command.Target,','nameof(CompleteAccessReviewDecisionBatchCancellation), command.Source.EventId,\n            AccessReviewIntentBindings.HeaderOf(bulk.Admitted!.Operation), command.Target,')
a=s.index('        var batch = await reader.HydrateAsync(');b=s.index('        for (var attempt',a)
s=s[:a]+'''        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewDecisionBatch, VerifiedCancellation>(reader,
            () => new AccessReviewDecisionBatch(tenant, campaignId, command.DecisionBatchId, command.CommandId),
            owner => Decide(owner, binding, command, provenance),
            (owner, token) => PrepareAsync(tenant, campaignId, command, bulk, owner, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
'''+s[b:]
s=s.replace('Decide(fresh, binding)','Decide(fresh, binding, command, provenance)')
a=s.index('    async Task<Result<ReceiverOutcome>?> VerifyFencesAsync(')
s=s[:a]+'''    async ValueTask<Result<VerifiedCancellation>> PrepareAsync(Uuid tenant, Uuid campaignId,
        CompleteAccessReviewDecisionBatchCancellation command, AccessReviewBulk native, AccessReviewDecisionBatch batch,
        CancellationToken ct)
    {
        var bulk = await verifier.PrepareAsync(tenant, native, ct).ConfigureAwait(false);
        if (bulk.Error is not null)
            return Result<VerifiedCancellation>.Failure(bulk.Error);
        if (batch.CancellationAccepted is null)
            return Result<VerifiedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The batch cancellation is not visible yet.", true));
        try
        {
            if (await VerifyFencesAsync(tenant, campaignId, command, bulk.Intent!, ct).ConfigureAwait(false) is { } failure)
                return Result<VerifiedCancellation>.Failure(failure.Error!);
            return Result<VerifiedCancellation>.Success(new VerifiedCancellation());
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<VerifiedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen bulk decision cannot be verified yet: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
s=s.replace('static Result<ReceiverOutcome>? Decide(AccessReviewDecisionBatch batch, AcceptedOperationBinding binding)\n    {','''static Result<ReceiverOutcome>? Decide(AccessReviewDecisionBatch batch, AcceptedOperationBinding binding,
        CompleteAccessReviewDecisionBatchCancellation command, OperationProvenance provenance)
    {
        if (batch.Accepted is { } materialized &&
            (materialized.Intent != command.Intent || materialized.Operation.RootOperationId != command.OperationId ||
                materialized.Operation.CausationEventId != command.Source.EventId || materialized.Operation.FirstOwner != provenance.FirstOwner))
            return SourceUseReceiverSupport.Permanent("The materialized batch has another exact native admission.");
        if (batch.Canceled is { } prior &&
            (prior.Intent != command.Intent || prior.Operation.RootOperationId != command.OperationId ||
                prior.Operation.CausationEventId != command.Source.EventId || prior.Operation.FirstOwner != provenance.FirstOwner ||
                AcceptedOperationBinding.Of(prior.Operation with { LogicalId = provenance.LogicalId }) != binding))
            return SourceUseReceiverSupport.Permanent("The canceled batch has another exact native source binding.");
        // As before, an accepted cancellation retry returns its recorded fence set; only a new one verifies the claim.''')
s=s.replace('    sealed record Decided(', '    sealed record VerifiedCancellation;\n\n    sealed record Decided(')
(r/'work'/p).write_text(s)
