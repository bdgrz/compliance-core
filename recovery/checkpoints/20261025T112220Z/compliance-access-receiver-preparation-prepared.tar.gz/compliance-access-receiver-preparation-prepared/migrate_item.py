from pathlib import Path
p=Path('/tmp/compliance-access-receiver-preparation-prepared/work/src/Compliance.Core/Features/AccessReviews/MaterializeAccessReviewItemHandler.cs');s=p.read_text()
a=s.index('        AccessReviewItemCreationIntent intent;');b=s.index('        for (var attempt = 1; ; attempt++)',a)
s=s[:a]+'''        var campaign = await reader.HydrateAsync(new AccessReviewCampaign(tenant, command.CampaignId), ct).ConfigureAwait(false);
        var launched = campaign.Launched;
        if (command.Source.Stream != campaign.Stream)
            return SourceUseReceiverSupport.Permanent("The source is not a launch of this campaign.");
        if (launched is null || launched.Metadata.EventId != command.Source.EventId)
            return SourceUseReceiverSupport.Transient("The launch is not visible on its campaign yet.");
        if (launched.Metadata.AggregateVersion != command.Source.AggregateVersion ||
            launched.Operation.RootOperationId != command.OperationId)
            return SourceUseReceiverSupport.Permanent("The source differs from the launch of this operation.");
        var operation = launched.Operation;
        var header = new DurableIntentHeader(operation.RootOperationId, operation.FirstOwner ?? operation.Owner,
            operation.AffectedOwner, operation.ExpectedRevisionOwner, operation.Actor, operation.Episode,
            operation.OriginalExpectedRevision, operation.AuthoredIntentSha256, operation.AcceptedAt);
        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(MaterializeAccessReviewItem),
            command.Source.EventId, header, target, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewItem, AccessReviewItemCreationIntent>(reader,
            () => new AccessReviewItem(tenant, command.CampaignId, command.ItemId, command.CommandId),
            owner => Decide(owner, binding, command, provenance), (_, token) => PrepareAsync(tenant, command, launched, token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
''' +s[b:]
s=s.replace('Decide(current, binding)', 'Decide(current, binding, command, provenance)').replace('Decide(item, binding)', 'Decide(item, binding, command, provenance)')
# The expanded native decision covers exact logical replay and a prior same-intent item under a different delivery ID.
a=s.index('                if (current.Opened is { } existing)');b=s.index('\n                var step =',a);s=s[:a]+s[b:]
a=s.index('    /// <summary>The launch fact');b=s.index('    static NativeFactReference Fact',a)
s=s[:a]+'''    async ValueTask<Result<AccessReviewItemCreationIntent>> PrepareAsync(Uuid tenant, MaterializeAccessReviewItem command,
        AccessReviewCampaignLaunched launched, CancellationToken ct)
    {
        try
        {
            var intent = await AccessReviewContent.ReadAsync<AccessReviewItemCreationIntent>(content, tenant, command.Intent, ct)
                .ConfigureAwait(false);
            var entry = await AccessReviewContent.ReadAsync<AccessReviewItemView>(content, tenant, intent.PopulationEntry, ct)
                .ConfigureAwait(false);
            if (intent.CampaignId != command.CampaignId || intent.ItemId != command.ItemId ||
                intent.Header.RootOperationId != command.OperationId ||
                intent.CampaignGeneration != (ulong)AccessReviewEffects.Generation || entry.ItemId != command.ItemId ||
                entry.SystemInstanceId != intent.SystemInstanceId || entry.ReviewerMemberId != intent.ReviewerMemberId)
                return Failed("The materialization differs from the frozen creation intent.");
            AccessReviewIntentBindings.Require(intent.Header, launched.Operation);
            var intents = await manifests.IntentsAsync(command.Target.Realm, launched.ItemIntentManifest, ct).ConfigureAwait(false);
            return intents.TryGetValue(command.ItemId, out var frozen) && frozen == command.Intent
                ? Result<AccessReviewItemCreationIntent>.Success(intent)
                : Failed("The launch manifest does not carry this item and intent.");
        }
        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return Result<AccessReviewItemCreationIntent>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The frozen creation intent cannot be verified: " + exception.Message,
                exception is ImmutableContentUnavailableException));
        }
    }

    static Result<AccessReviewItemCreationIntent> Failed(string message) =>
        Result<AccessReviewItemCreationIntent>.Failure(new RequestError(RequestErrorKind.Conflict, message));

    static Result<ReceiverOutcome>? Decide(AccessReviewItem item, AcceptedOperationBinding binding,
        MaterializeAccessReviewItem command, OperationProvenance provenance)
    {
        if (item.Opened is { } opened && opened.Intent != command.Intent)
            return SourceUseReceiverSupport.Permanent("The item is already materialized with a different frozen creation intent.");
        switch (item.Acceptance.Decide(binding))
        {
            case NativeAcceptanceDecision.Replayed:
                return SourceUseReceiverSupport.Replayed(Fact(item.Stream, item.Acceptance.SelectedFact!));
            case NativeAcceptanceDecision.Conflict:
                return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
        }
        if (item.Opened is not { } existing)
            return null;
        return AcceptedOperationBinding.Of(existing.Operation with { LogicalId = provenance.LogicalId }) == binding
            ? SourceUseReceiverSupport.Replayed(Fact(item.Stream, existing))
            : SourceUseReceiverSupport.Permanent("The existing item has another exact native source binding.");
    }

''' +s[b:]
p.write_text(s)
