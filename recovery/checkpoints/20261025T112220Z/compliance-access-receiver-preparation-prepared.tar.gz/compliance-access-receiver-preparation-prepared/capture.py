from pathlib import Path
import hashlib,json,re
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');r=Path('/tmp/compliance-access-receiver-preparation-prepared');paths=set()
for prefix in ['src/Compliance.Common/Features/AccessReviews','src/Compliance.Core/Features/AccessReviews','test/Compliance.Tests/Features/AccessReviews']:
 paths.update(str(p.relative_to(repo)) for p in (repo/prefix).rglob('*.cs'))
rows=[]
for p in sorted(paths):
 data=(repo/p).read_bytes()
 for tree in ['base','work']:
  f=r/tree/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 rows.append({'path':p,'baselineSource':str(repo/p),'beforeSha256':hashlib.sha256(data).hexdigest(),'acceptanceNames':re.findall(r'\b(Should\w+)\s*\(',data.decode()) if p.startswith('test/') else[]})
(r/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows))
