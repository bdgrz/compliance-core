from pathlib import Path
p=Path('/tmp/compliance-access-receiver-preparation-prepared/work/src/Compliance.Core/Features/AccessReviews/AccessReviewBulkVerifier.cs');s=p.read_text();a=s.index('    public async ValueTask<AccessReviewBulk> VerifyAsync');b=s.index('    /// <summary>The frozen item intent',a)
s=s[:a]+'''    public async ValueTask<AccessReviewBulk> VerifyAsync(Uuid tenantId, Uuid campaignId, NativeFactReference source,
        ImmutableContentRef intentReference, Uuid operationId, CancellationToken ct)
    {
        var native = await ReadNativeAsync(tenantId, campaignId, source, intentReference, operationId, ct).ConfigureAwait(false);
        return native.Error is not null ? native : await PrepareAsync(tenantId, native, ct).ConfigureAwait(false);
    }

    /// <summary>Resolves exact native admission authority before immutable preparation or receiver receipt knowledge.</summary>
    public async ValueTask<AccessReviewBulk> ReadNativeAsync(Uuid tenantId, Uuid campaignId, NativeFactReference source,
        ImmutableContentRef intentReference, Uuid operationId, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(source);
        ArgumentNullException.ThrowIfNull(intentReference);
        var campaign = await reader.HydrateAsync(new AccessReviewCampaign(tenantId, campaignId, selectedRootId: operationId), ct)
            .ConfigureAwait(false);
        if (campaign.AdmittedFor(operationId) is not { } admitted)
            return AccessReviewBulk.Failed(Transient("The admitted bulk decision is not visible yet."));
        return source.Stream != campaign.Stream || admitted.Metadata.EventId != source.EventId ||
            admitted.Metadata.AggregateVersion != source.AggregateVersion || admitted.Intent != intentReference ||
            admitted.Operation.RootOperationId != operationId
            ? AccessReviewBulk.Failed(Permanent("The source is not the admitted bulk decision of this campaign."))
            : new AccessReviewBulk(campaign, admitted, null, null);
    }

    /// <summary>Validates the complete frozen bulk selection for a new receiver candidate.</summary>
    public async ValueTask<AccessReviewBulk> PrepareAsync(Uuid tenantId, AccessReviewBulk native, CancellationToken ct)
    {
        var campaign = native.Campaign!;
        var admitted = native.Admitted!;
        BulkAccessDecisionIntent intent;
        try
        {
            intent = await AccessReviewContent.ReadAsync<BulkAccessDecisionIntent>(content, tenantId, admitted.Intent, ct)
                .ConfigureAwait(false);
            if (intent.Header is null || intent.Header.RootOperationId != admitted.Operation.RootOperationId ||
                intent.DecisionBatchId != admitted.Operation.RootOperationId || intent.CampaignId != campaign.Id ||
                intent.CampaignGeneration != (ulong)AccessReviewEffects.Generation)
                return AccessReviewBulk.Failed(Permanent("The command differs from the frozen bulk decision intent."));
            AccessReviewIntentBindings.Require(intent.Header, admitted.Operation);
            var items = await manifests.BulkItemsAsync(AccessReviewContent.Realm(tenantId), intent.Items, ct).ConfigureAwait(false);
            if (items.Count == 0 || intent.ExpectedCampaignRevision != admitted.Operation.OriginalExpectedRevision ||
                items.Values.Any(item => item.ItemId == Uuid.Empty || item.ReviewerMemberId == Uuid.Empty ||
                    item.ExpectedItemRevision == 0 || item.ItemOwner != AccessReviewEffects.ItemStream(tenantId, campaign.Id, item.ItemId)))
                throw new ImmutableContentIntegrityException("The complete bulk selection differs from its admitted scoped item owners.");
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return AccessReviewBulk.Failed(new RequestError(RequestErrorKind.Conflict, error.Message,
                error is ImmutableContentUnavailableException));
        }
        return native with { Intent = intent };
    }

''' +s[b:];p.write_text(s)
