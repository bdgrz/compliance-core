from pathlib import Path
r=Path('/tmp/compliance-access-receiver-preparation-prepared');p='src/Compliance.Core/Features/AccessReviews/CompleteAccessReviewCampaignClosureHandler.cs';s=(r/'base'/p).read_text()
s=s.replace('var completion = await verifier.VerifyAsync(', 'var completion = await verifier.ReadNativeAsync(')
a=s.index('        var (campaign, intent) =');b=s.index('        for (var attempt',a)
s=s[:a]+'''        completion = await verifier.BindAsync(tenant, completion, ct).ConfigureAwait(false);
        if (completion.Error is not null)
            return Result<ReceiverOutcome>.Failure(completion.Error);
        var (campaign, intent) = (completion.Campaign!, completion.Intent!);
        if (command.ItemProofs != intent.SourceUses.Content)
            return SourceUseReceiverSupport.Permanent("The closure differs from the frozen completion item manifest.");
        var now = clock.GetUtcNow();
        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(CompleteAccessReviewCampaignClosure),
            command.Source.EventId, intent.Header, campaign.Stream, now);
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewCampaign, PreparedClosure>(reader,
            () => new AccessReviewCampaign(tenant, command.CampaignId, command.CommandId, command.OperationId),
            owner => Decide(owner, binding, command.OperationId),
            (owner, token) => PrepareAsync(context, command, completion with { Campaign = owner }, tenant, now, token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var prepared = preparation.Value.Value!;
        if (prepared.Outcome is { } outcome)
            return outcome;
        var (preparedCut, completionContent, proofs, result) = (prepared.Cut!, prepared.Content!, prepared.Proofs!, prepared.Result!);
'''+s[b:]
a=s.index('    async Task<Built> BuildAsync(')
s=s[:a]+'''    async ValueTask<Result<PreparedClosure>> PrepareAsync(IRequestContext<CompleteAccessReviewCampaignClosure> context,
        CompleteAccessReviewCampaignClosure command, AccessReviewCompletion completion, Uuid tenant, DateTimeOffset now,
        CancellationToken ct)
    {
        var verified = await verifier.PrepareAsync(tenant, completion, ct).ConfigureAwait(false);
        if (verified.Error is not null)
            return Result<PreparedClosure>.Failure(verified.Error);
        if (verified.Campaign!.Pending is not { } pending || pending.Operation.RootOperationId != command.OperationId)
            return Result<PreparedClosure>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The closure differs from the pending completion admission.", false));
        var cut = AccessReviewPreparedCut.Capture(verified.Campaign);
        try
        {
            var built = await BuildAsync(context, command, verified, tenant, now, ct).ConfigureAwait(false);
            if (built.Outcome is { } outcome)
                return outcome.IsSuccess
                    ? Result<PreparedClosure>.Success(new PreparedClosure(null, null, null, null, outcome))
                    : Result<PreparedClosure>.Failure(outcome.Error!);
            var completionContent = await AccessReviewContent.WriteAsync(content, tenant,
                AccessReviewContent.CompletionSchema, built.View!, ct).ConfigureAwait(false);
            var result = await AccessReviewContent.WriteResultAsync(content, tenant,
                AccessReviewContent.CompletionViewSchema, completionContent, ct).ConfigureAwait(false);
            return Result<PreparedClosure>.Success(new PreparedClosure(cut, completionContent, built.Proofs!, result, null));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedClosure>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen completion cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
pos=s.index('    sealed record Built(')
s=s[:pos]+'''    sealed record PreparedClosure(AccessReviewPreparedCut? Cut, ImmutableContentRef? Content, ImmutableContentRef? Proofs,
        ImmutableContentRef? Result, Result<ReceiverOutcome>? Outcome);

'''+s[pos:]
(r/'work'/p).write_text(s)
# Abort has no direct Proofs type, retain its original imports.
p='src/Compliance.Core/Features/AccessReviews/AbortAccessReviewCampaignCompletionHandler.cs';s=(r/'work'/p).read_text().replace('using Bdgrz.Compliance.Features.Proofs;\n','');(r/'work'/p).write_text(s)
