from pathlib import Path
p=Path('/tmp/compliance-access-receiver-preparation-prepared/work/src/Compliance.Core/Features/AccessReviews/MaterializeAccessReviewDecisionBatchHandler.cs');s=p.read_text()
s=s.replace('var bulk = await verifier.VerifyAsync(', 'var bulk = await verifier.ReadNativeAsync(')
a=s.index('        var provenance = SourceUseReceiverSupport.Child');b=s.index('        for (var attempt = 1; ; attempt++)',a)
s=s[:a]+'''        var operation = bulk.Admitted!.Operation;
        var header = new DurableIntentHeader(operation.RootOperationId, operation.FirstOwner ?? operation.Owner,
            operation.AffectedOwner, operation.ExpectedRevisionOwner, operation.Actor, operation.Episode,
            operation.OriginalExpectedRevision, operation.AuthoredIntentSha256, operation.AcceptedAt);
        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(MaterializeAccessReviewDecisionBatch),
            command.Source.EventId, header, target, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewDecisionBatch, BulkAccessDecisionIntent>(reader,
            () => new AccessReviewDecisionBatch(tenant, command.CampaignId, command.DecisionBatchId, command.CommandId),
            owner => Decide(owner, binding, command, provenance), async (_, token) =>
            {
                var prepared = await verifier.PrepareAsync(tenant, bulk, token).ConfigureAwait(false);
                return prepared.Error is not null ? Result<BulkAccessDecisionIntent>.Failure(prepared.Error)
                    : Result<BulkAccessDecisionIntent>.Success(prepared.Intent!);
            }, ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
''' +s[b:]
s=s.replace('BulkReceiverSupport.Decide(current.Acceptance, current.Stream, binding)', 'Decide(current, binding, command, provenance)').replace('BulkReceiverSupport.Decide(batch.Acceptance, batch.Stream, binding)', 'Decide(batch, binding, command, provenance)')
a=s.index('                if (current.Accepted is { } existing)');b=s.index('\n                var step',a);s=s[:a]+s[b:]
pos=s.index('    sealed record Decided')
s=s[:pos]+'''    static Result<ReceiverOutcome>? Decide(AccessReviewDecisionBatch batch, AcceptedOperationBinding binding,
        MaterializeAccessReviewDecisionBatch command, OperationProvenance provenance)
    {
        if (batch.Accepted is { } existing &&
            (existing.Intent != command.Intent || existing.Operation.RootOperationId != command.OperationId ||
                existing.Operation.CausationEventId != command.Source.EventId || existing.Operation.FirstOwner != provenance.FirstOwner))
            return SourceUseReceiverSupport.Permanent("The batch is already materialized with another exact source or frozen intent.");
        if (BulkReceiverSupport.Decide(batch.Acceptance, batch.Stream, binding) is { } known)
            return known;
        if (batch.Accepted is not { } accepted)
            return null;
        return AcceptedOperationBinding.Of(accepted.Operation with { LogicalId = provenance.LogicalId }) == binding
            ? SourceUseReceiverSupport.Replayed(BulkReceiverSupport.Fact(batch.Stream, accepted))
            : SourceUseReceiverSupport.Permanent("The materialized batch has another exact native source binding.");
    }

''' +s[pos:]
p.write_text(s)
