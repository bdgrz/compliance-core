from pathlib import Path
r=Path('/tmp/compliance-access-receiver-preparation-prepared')
p='src/Compliance.Core/Features/AccessReviews/ApplyAccessReviewItemDecisionHandler.cs';s=(r/'base'/p).read_text().replace('var bulk = await verifier.VerifyAsync(', 'var bulk = await verifier.ReadNativeAsync(')
a=s.index('        var (campaign, intent) =');b=s.index('        for (var attempt',a)
s=s[:a]+'''        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(ApplyAccessReviewItemDecision),
            command.Source.EventId, AccessReviewIntentBindings.HeaderOf(bulk.Admitted!.Operation), command.Target,
            clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewItem, PreparedDecisions>(reader,
            () => Open(tenant, command), owner => Decide(owner, binding, command, provenance),
            (_, token) => PrepareAsync(tenant, command, bulk, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var decisions = preparation.Value.Value!.Content;
'''+s[b:]
s=s.replace('Decide(current, binding, command.OperationId)','Decide(current, binding, command, provenance)').replace('Decide(item, binding, command.OperationId)','Decide(item, binding, command, provenance)')
a=s.index('    static AccessReviewItem Open(')
s=s[:a]+'''    async ValueTask<Result<PreparedDecisions>> PrepareAsync(Uuid tenant, ApplyAccessReviewItemDecision command,
        AccessReviewBulk native, CancellationToken ct)
    {
        var bulk = await verifier.PrepareAsync(tenant, native, ct).ConfigureAwait(false);
        if (bulk.Error is not null)
            return Result<PreparedDecisions>.Failure(bulk.Error);
        var (campaign, intent) = (bulk.Campaign!, bulk.Intent!);
        try
        {
            var selected = await verifier.ItemOfAsync(command.Target.Realm, intent, command.Target.Resource, ct)
                .ConfigureAwait(false);
            if (selected is null || selected.ItemId != command.ItemId || campaign.Launched is not { } launched)
                return Result<PreparedDecisions>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The apply differs from the frozen bulk decision selection.", false));
            var view = new AccessDecisionView(Uuid.CreateVersion5(command.OperationId, $"bulk-decision:{command.ItemId}"),
                command.ItemId, intent.Decision, intent.Rationale, selected.ReviewerMemberId, intent.Header.OriginalActor,
                intent.Header.AcceptedAt, intent.PreviewToken, intent.Header.AcceptedAt > launched.Deadline, null);
            var decisions = await content.WriteJsonAsync<IReadOnlyList<AccessDecisionView>>(command.Target.Realm,
                Uuid.CreateVersion5(command.CommandId, "bulk-decisions"), AccessReviewContent.DecisionsSchema, [view], ct)
                .ConfigureAwait(false);
            return Result<PreparedDecisions>.Success(new PreparedDecisions(decisions));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedDecisions>.Failure(new RequestError(RequestErrorKind.Conflict,
                error.Message, error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
s=s.replace('''        Uuid batchId)
    {
        if (BulkReceiverSupport.Decide''','''        ApplyAccessReviewItemDecision command, OperationProvenance provenance)
    {
        var batchId = command.DecisionBatchId;
        if (item.ProvisionalFor(batchId) is { } applied &&
            (applied.Intent != command.Intent || applied.Operation.RootOperationId != command.OperationId ||
                applied.Operation.CausationEventId != command.Source.EventId || applied.Operation.FirstOwner != provenance.FirstOwner ||
                AcceptedOperationBinding.Of(applied.Operation with { LogicalId = provenance.LogicalId }) != binding))
            return SourceUseReceiverSupport.Permanent("The applied decision has another exact native source binding.");
        if (BulkReceiverSupport.Decide''')
s=s.replace('    sealed record Decided(', '    sealed record PreparedDecisions(ImmutableContentRef Content);\n\n    sealed record Decided(')
(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/AccessReviews/FenceAccessReviewItemDecisionHandler.cs';s=(r/'base'/p).read_text().replace('using System.Globalization;','using System.Globalization;\nusing Bdgrz.Compliance.Features.Content;').replace('var bulk = await verifier.VerifyAsync(', 'var bulk = await verifier.ReadNativeAsync(')
a=s.index('        var intent = bulk.Intent!;');b=s.index('        for (var attempt',a)
s=s[:a]+'''        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(FenceAccessReviewItemDecision),
            command.Source.EventId, AccessReviewIntentBindings.HeaderOf(bulk.Admitted!.Operation), command.Target,
            clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewItem, PreparedFence>(reader,
            () => Open(tenant, command), owner => Decide(owner, binding, command, provenance),
            (_, token) => PrepareAsync(tenant, command, bulk, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        if (preparation.Value.Value!.Outcome is { } terminal)
            return terminal;
'''+s[b:]
s=s.replace('Decide(current, binding, command.DecisionBatchId)','Decide(current, binding, command, provenance)').replace('Decide(item, binding, command.DecisionBatchId)','Decide(item, binding, command, provenance)')
a=s.index('    static AccessReviewItem Open(')
s=s[:a]+'''    async ValueTask<Result<PreparedFence>> PrepareAsync(Uuid tenant, FenceAccessReviewItemDecision command,
        AccessReviewBulk native, CancellationToken ct)
    {
        var bulk = await verifier.PrepareAsync(tenant, native, ct).ConfigureAwait(false);
        if (bulk.Error is not null)
            return Result<PreparedFence>.Failure(bulk.Error);
        try
        {
            if (await verifier.ItemOfAsync(command.Target.Realm, bulk.Intent!, command.Target.Resource, ct).ConfigureAwait(false)
                    is not { } selected || selected.ItemId != command.ItemId)
                return Result<PreparedFence>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The fence differs from the frozen bulk decision selection.", false));
            var batch = await reader.HydrateAsync(new AccessReviewDecisionBatch(tenant, command.CampaignId,
                command.DecisionBatchId), ct).ConfigureAwait(false);
            if (batch.Published is { } published)
                return Result<PreparedFence>.Success(new PreparedFence(SourceUseReceiverSupport.Superseded(
                    "The batch already published; its decisions recover forward.", BulkReceiverSupport.Fact(batch.Stream, published))));
            return batch.CancellationAccepted is null
                ? Result<PreparedFence>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The batch cancellation is not visible yet.", true))
                : Result<PreparedFence>.Success(new PreparedFence(null));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedFence>.Failure(new RequestError(RequestErrorKind.Conflict,
                error.Message, error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
s=s.replace('''        if (BulkReceiverSupport.Decide(item.Acceptance''','''        var batchId = command.DecisionBatchId;
        if (item.FenceFor(batchId) is { } fenced &&
            (fenced.Intent != command.Intent || fenced.Operation.RootOperationId != command.OperationId ||
                fenced.Operation.CausationEventId != command.Source.EventId || fenced.Operation.FirstOwner != provenance.FirstOwner ||
                AcceptedOperationBinding.Of(fenced.Operation with { LogicalId = provenance.LogicalId }) != binding))
            return SourceUseReceiverSupport.Permanent("The fence has another exact native source binding.");
        if (BulkReceiverSupport.Decide(item.Acceptance''')
s=s.replace('''        Uuid batchId)
''','''        FenceAccessReviewItemDecision command, OperationProvenance provenance)
''')
s=s.replace('    sealed record Decided(', '    sealed record PreparedFence(Result<ReceiverOutcome>? Outcome);\n\n    sealed record Decided(')
(r/'work'/p).write_text(s)
