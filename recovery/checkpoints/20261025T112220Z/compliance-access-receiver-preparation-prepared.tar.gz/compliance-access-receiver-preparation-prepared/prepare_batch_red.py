from pathlib import Path
import re,json,hashlib,difflib
r=Path('/tmp/compliance-access-receiver-preparation-prepared');s=(r/'old-api-AccessItemReceiverPreparationTests.cs').read_text()
s=s.replace('AccessItemReceiverPreparationTests','AccessBatchReceiverPreparationTests').replace('MaterializeAccessReviewItem','MaterializeAccessReviewDecisionBatch').replace('AccessReviewItemCreationIntent','BulkAccessDecisionIntent').replace('ShouldReplayOpenedItemOrRequestedCancellationGivenWinnerBeforeCreationIntentReadFailure','ShouldReplayMaterializedBatchOrRequestedCancellationGivenWinnerBeforeBulkIntentReadFailure').replace('ShouldReplayOriginalItemWithoutCreationBodyGivenAcceptedExactIntentReference','ShouldReplayOriginalBatchWithoutBulkIntentBodyGivenAcceptedExactIntentReference')
s=s.replace('fixture.ItemAsync(context.Request.CampaignId, context.Request.ItemId)', 'fixture.BatchAsync(context.Request.CampaignId, context.Request.DecisionBatchId)').replace('owner.Opened','owner.Accepted')
# Missing bulk intent already classifies transient in existing verifier, so keep that as a later positive rather than a RED claim.
a=s.index('    [Fact]\n    public async Task ShouldWaitTransiently');b=s.index('    static MaterializeAccessReviewDecisionBatchHandler Handler',a);s=s[:a]+s[b:]
a=s.index('    static MaterializeAccessReviewDecisionBatchHandler Handler');b=s.index('    sealed class FaultStore',a)
s=s[:a]+'''    static MaterializeAccessReviewDecisionBatchHandler Handler(IServiceProvider services, IImmutableContentStore content)
    {
        var reader = services.GetRequiredService<IAggregateReader>();
        return new MaterializeAccessReviewDecisionBatchHandler(reader, services.GetRequiredService<IAggregateExecutor>(),
            new AccessReviewBulkVerifier(reader, content, new AccessReviewManifests(content)), services.GetRequiredService<TimeProvider>());
    }

    static async Task<Cntryl.Portia.RequestContext<MaterializeAccessReviewDecisionBatch>> SeedAsync(AccessReviewFixture fixture)
    {
        var (campaignId, selected) = await AccessReviewBulkDecisionTests.LaunchedAsync(fixture);
        var (request, _) = await fixture.AdmitBulkAsync(fixture.ReviewerUserId, campaignId, selected);
        var campaign = await fixture.CampaignAggregateAsync(campaignId, selectedRootId: request.DecisionBatchId);
        var admitted = campaign.AdmittedFor(request.DecisionBatchId)!;
        var command = new MaterializeAccessReviewDecisionBatch(Uuid.CreateVersion4(), NativeFactReference.Of(campaign.Stream, admitted),
            AccessReviewEffects.BatchStream(fixture.TenantId, campaignId, request.DecisionBatchId), request.DecisionBatchId,
            AccessReviewEffects.Generation, null, admitted.Intent, campaignId, request.DecisionBatchId);
        return new Cntryl.Portia.RequestContext<MaterializeAccessReviewDecisionBatch>(command, new RequestDispatchContext(RequestActor.System));
    }

''' +s[b:]
s=s.replace('actual item creation intent','actual bulk decision intent')
p='test/Compliance.Tests/Features/AccessReviews/AccessBatchReceiverPreparationTests.cs';(r/'work'/p).write_text(s);(r/'old-api-AccessBatchReceiverPreparationTests.cs').write_text(s);patch=f'diff --git a/{p} b/{p}\nnew file mode 100644\n'+''.join(difflib.unified_diff([],s.splitlines(True),fromfile='/dev/null',tofile='b/'+p));(r/'batch-preparation-red.patch').write_text(patch);m={'status':'FROZEN existing-API Access batch receiver RED3 candidate; parent runtime qualifies','patch':str(r/'batch-preparation-red.patch'),'patchSha256':hashlib.sha256(patch.encode()).hexdigest(),'source':str(r/'old-api-AccessBatchReceiverPreparationTests.cs'),'sourceSha256':hashlib.sha256(s.encode()).hexdigest(),'filter':'FullyQualifiedName~AccessBatchReceiverPreparationTests','rows':3,'qualification':'Real launch/materialized items, real preview+personal reviewer bulk admission, healthy actual batch commits before losing BulkAccessDecisionIntent read; receipt/cancellation2+accepted same Intent body-free1. Current ctor4/verifier3; no future symbols, no extra command proof ref.'};(r/'batch-preparation-red-handoff.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps(m,indent=2))
