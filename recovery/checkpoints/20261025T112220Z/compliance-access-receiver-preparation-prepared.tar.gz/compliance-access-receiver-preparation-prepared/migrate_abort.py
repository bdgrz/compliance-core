from pathlib import Path
r=Path('/tmp/compliance-access-receiver-preparation-prepared');p='src/Compliance.Core/Features/AccessReviews/AbortAccessReviewCampaignCompletionHandler.cs'
s=(r/'base'/p).read_text()
s=s.replace('using Bdgrz.Compliance.Features.Processes;','using Bdgrz.Compliance.Features.Processes;\nusing Bdgrz.Compliance.Features.Proofs;')
a=s.index('        ClosureIntent intent;');b=s.index('        for (var attempt',a)
s=s[:a]+'''        if (command.ExpectedRevision != accepted.Revision)
            return SourceUseReceiverSupport.Permanent("The abort differs from the frozen completion admission.");
        var header = AccessReviewIntentBindings.HeaderOf(accepted.Operation);
        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(AbortAccessReviewCampaignCompletion),
            accepted.Metadata.EventId, header, campaign.Stream, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewCampaign, AccessReviewPreparedCut>(reader,
            () => new AccessReviewCampaign(tenant, campaignId, command.CommandId, command.OperationId),
            owner => Decide(owner, binding, command, false), async (owner, token) =>
            {
                var verified = await PrepareAsync(tenant, campaign, accepted, command, token).ConfigureAwait(false);
                return verified.IsSuccess ? Result<AccessReviewPreparedCut>.Success(AccessReviewPreparedCut.Capture(owner))
                    : Result<AccessReviewPreparedCut>.Failure(verified.Error!);
            }, ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var preparedCut = preparation.Value.Value!;
'''+s[b:]
s=s.replace('Decide(current, binding, command.OperationId)','Decide(current, binding, command, true)').replace('Decide(fresh, binding, command.OperationId)','Decide(fresh, binding, command, true)')
a=s.index('    static Result<ReceiverOutcome>? Decide(')
s=s[:a]+'''    async ValueTask<Result<Verified>> PrepareAsync(Uuid tenant, AccessReviewCampaign campaign,
        AccessReviewCampaignCompletionAccepted accepted, AbortAccessReviewCampaignCompletion command, CancellationToken ct)
    {
        try
        {
            var intent = await AccessReviewContent.ReadAsync<ClosureIntent>(content, tenant, accepted.Intent, ct)
                .ConfigureAwait(false);
            var failure = await AccessReviewContent.ReadAsync<AccessReviewCompletionFailure>(content, tenant,
                command.FailureProof, ct).ConfigureAwait(false);
            AccessReviewIntentBindings.Require(intent.Header, accepted.Operation);
            if (intent.Header.RootOperationId != command.OperationId ||
                failure.Evidence != NativeFactReference.Of(campaign.Stream, accepted))
                return Result<Verified>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The abort differs from the frozen completion admission.", false));
            if (failure.ItemId is { } failedItem)
            {
                var requirements = await new AccessReviewManifests(content).RequirementsAsync(command.Target.Realm,
                    intent.SourceUses, ct).ConfigureAwait(false);
                if (!requirements.ContainsKey(AccessReviewEffects.ItemStream(tenant, campaign.Id, failedItem).Resource))
                    return Result<Verified>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The completion failure names an item outside its exact frozen selection.", false));
            }
            return Result<Verified>.Success(new Verified());
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<Verified>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen completion cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

    static Result<ReceiverOutcome>? Decide(AccessReviewCampaign campaign, AcceptedOperationBinding binding,
        AbortAccessReviewCampaignCompletion command, bool prepared)
    {
        var canceled = campaign.CanceledFor(command.OperationId);
        if (canceled is not null && canceled.SourceProofs != command.FailureProof)
            return SourceUseReceiverSupport.Permanent("The abort names another native cancellation failure proof.");
        switch (campaign.Acceptance.Decide(binding))
        {
            case NativeAcceptanceDecision.Replayed:
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(campaign.Stream,
                    campaign.Acceptance.SelectedFact!));
            case NativeAcceptanceDecision.Conflict:
                return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
        }
        if (canceled is not null)
            return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(campaign.Stream, canceled));
        return prepared && campaign.ClosedFor(command.OperationId) is { } closed
            ? SourceUseReceiverSupport.Superseded("The completion already closed the campaign; it recovers forward.",
                NativeFactReference.Of(campaign.Stream, closed)) : null;
    }

    sealed record Verified;

    sealed record Decided(Result<ReceiverOutcome> Outcome);
}
'''
(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/AccessReviews/AccessReviewIntentBindings.cs';s=(r/'base'/p).read_text();pos=s.index('    public static void Require(')
s=s[:pos]+'''    public static DurableIntentHeader HeaderOf(OperationProvenance operation) =>
        new(operation.RootOperationId, operation.FirstOwner ?? operation.Owner, operation.AffectedOwner,
            operation.ExpectedRevisionOwner, operation.Actor, operation.Episode, operation.OriginalExpectedRevision,
            operation.AuthoredIntentSha256, operation.AcceptedAt);

'''+s[pos:];(r/'work'/p).write_text(s)
