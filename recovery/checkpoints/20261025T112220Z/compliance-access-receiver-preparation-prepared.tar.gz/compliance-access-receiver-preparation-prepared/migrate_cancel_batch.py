from pathlib import Path
r=Path('/tmp/compliance-access-receiver-preparation-prepared');p='src/Compliance.Core/Features/AccessReviews/CancelAccessReviewDecisionBatchHandler.cs';s=(r/'base'/p).read_text()
a=s.index('        BulkAccessDecisionIntent intent;');b=s.index('        for (var attempt',a)
s=s[:a]+'''        if (command.ExpectedRevision != accepted.Revision)
            return SourceUseReceiverSupport.Permanent("The cancel differs from the materialized batch.");
        var campaign = await reader.HydrateAsync(new AccessReviewCampaign(tenant, command.CampaignId,
            selectedRootId: command.DecisionBatchId), ct).ConfigureAwait(false);
        if (campaign.AdmittedFor(command.DecisionBatchId) is not { } admitted)
            return SourceUseReceiverSupport.Transient("The admitted bulk decision is not visible yet.");
        if (admitted.Intent != accepted.Intent || accepted.Operation.RootOperationId != command.DecisionBatchId ||
            accepted.Operation.CausationEventId != admitted.Metadata.EventId)
            return SourceUseReceiverSupport.Permanent("The materialized batch belongs to another exact admitted bulk decision.");
        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(CancelAccessReviewDecisionBatch),
            accepted.Metadata.EventId, AccessReviewIntentBindings.HeaderOf(admitted.Operation), batch.Stream, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<AccessReviewDecisionBatch, Verified>(reader,
            () => new AccessReviewDecisionBatch(tenant, command.CampaignId, command.DecisionBatchId, command.CommandId),
            owner => Decide(owner, binding, command, false),
            (_, token) => PrepareAsync(tenant, campaign, admitted, command, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
'''+s[b:]
s=s.replace('Decide(current, binding)','Decide(current, binding, command, true)').replace('Decide(fresh, binding)','Decide(fresh, binding, command, true)')
a=s.index('    static Result<ReceiverOutcome>? Decide(')
s=s[:a]+'''    async ValueTask<Result<Verified>> PrepareAsync(Uuid tenant, AccessReviewCampaign campaign,
        AccessReviewDecisionBatchAdmitted admitted, CancelAccessReviewDecisionBatch command, CancellationToken ct)
    {
        try
        {
            var intent = await AccessReviewContent.ReadAsync<BulkAccessDecisionIntent>(content, tenant, admitted.Intent, ct)
                .ConfigureAwait(false);
            var failure = await AccessReviewContent.ReadAsync<AccessReviewBulkFailure>(content, tenant,
                command.FailureProof, ct).ConfigureAwait(false);
            AccessReviewIntentBindings.Require(intent.Header, admitted.Operation);
            if (intent.Header.RootOperationId != command.DecisionBatchId || intent.CampaignId != command.CampaignId ||
                failure.Evidence != NativeFactReference.Of(campaign.Stream, admitted))
                return Result<Verified>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The failure proof belongs to another admitted bulk decision.", false));
            if (failure.ItemId is { } failedItem)
            {
                var selected = await new AccessReviewManifests(content).BulkItemsAsync(command.Target.Realm,
                    intent.Items, ct).ConfigureAwait(false);
                if (!selected.Values.Any(item => item.ItemId == failedItem))
                    return Result<Verified>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The failure proof names an item outside the frozen selection.", false));
            }
            return Result<Verified>.Success(new Verified());
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<Verified>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen bulk decision cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

    static Result<ReceiverOutcome>? Decide(AccessReviewDecisionBatch batch, AcceptedOperationBinding binding,
        CancelAccessReviewDecisionBatch command, bool prepared)
    {
        if (!prepared && batch.CancellationAccepted?.SourceProofs != command.FailureProof)
            return null;
        if (BulkReceiverSupport.Decide(batch.Acceptance, batch.Stream, binding) is { } accepted)
            return accepted;
        if (batch.Published is { } published)
            return SourceUseReceiverSupport.Superseded("The batch already published; its decisions recover forward.",
                BulkReceiverSupport.Fact(batch.Stream, published));
        return batch.CancellationAccepted is { } canceled
            ? SourceUseReceiverSupport.Replayed(BulkReceiverSupport.Fact(batch.Stream, canceled))
            : null;
    }

    sealed record Verified;

    sealed record Decided(Result<ReceiverOutcome> Outcome);
}
'''
(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/AccessReviews/AbortAccessReviewCampaignCompletionHandler.cs';s=(r/'work'/p).read_text()
s=s.replace('''        if (canceled is not null && canceled.SourceProofs != command.FailureProof)
            return SourceUseReceiverSupport.Permanent("The abort names another native cancellation failure proof.");''','''        if (!prepared && canceled?.SourceProofs != command.FailureProof)
            return null;''')
(r/'work'/p).write_text(s)
