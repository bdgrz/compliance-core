from pathlib import Path
import json,os,re,subprocess,hashlib
p=Path('/tmp/compliance-engagement-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
changed=[f for f in (p/'work').rglob('*.cs') if not (p/'base'/f.relative_to(p/'work')).exists() or f.read_bytes()!=(p/'base'/f.relative_to(p/'work')).read_bytes()]
(p/'changed-csharp.txt').write_text('\n'.join(map(str,changed))+'\n')
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
q=Parser(Language(tree_sitter_c_sharp.language()));fs=[Path(x) for x in Path('/tmp/compliance-engagement-native-prepared/changed-csharp.txt').read_text().splitlines()];print(json.dumps({'files':len(fs),'errors':[str(f) for f in fs if q.parse(f.read_bytes()).root_node.has_error]}))'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314'))); assert not syntax['errors'],syntax
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()))
expected={'ServiceEngagementIndependence':(2,4),'ServiceEngagementCommands':(5,5),'MaterializePartnerIndependenceDecisionHandler':(4,4),'EngagementPersonalDecisionReactor':(4,4),'EngagementAcceptanceReactor':(4,4),'ServiceEngagementHistoryModel':(2,2),'ServiceEngagementAggregateReader':(2,2),'ServiceEngagementHistorySnapshot':(6,6),'EngagementPersonalDecisionRecord':(2,2)}
files={str(f.relative_to(repo)):f for part in ['src','test'] for f in (repo/part).rglob('*.cs')}
for prior in [Path('/tmp/compliance-professional-duty-native-prepared/work'),Path('/tmp/compliance-practice-native-prepared/work'),Path('/tmp/compliance-client-service-native-prepared/work'),Path('/tmp/compliance-engagement-external-prepared/work'),p/'work']:
 for f in prior.rglob('*.cs'):files[str(f.relative_to(prior))]=f
calls=[];issues=[]
for rel,f in files.items():
 data=f.read_bytes(); stack=[parser.parse(data).root_node]
 while stack:
  node=stack.pop(); stack.extend(node.children)
  if node.type=='implicit_object_creation_expression':
   at=node.parent
   while at and at.type not in ['property_declaration','method_declaration','variable_declaration']:at=at.parent
   if at:
    tp=at.child_by_field_name('type') or at.child_by_field_name('returns'); args=node.child_by_field_name('arguments') or next((c for c in node.named_children if c.type=='argument_list'),None)
    name=data[tp.start_byte:tp.end_byte].decode().split('.')[-1].rstrip('?') if tp else ''
    if name in expected and args:
     count=sum(c.type=='argument' for c in args.named_children);row={'path':rel,'type':name,'arguments':count,'implicit':True};calls.append(row)
     if not expected[name][0]<=count<=expected[name][1]:issues.append(row)
  if node.type!='object_creation_expression':continue
  typ=node.child_by_field_name('type');args=node.child_by_field_name('arguments')
  if not typ or not args:continue
  name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
  if name not in expected:continue
  count=sum(c.type=='argument' for c in args.named_children);row={'path':rel,'type':name,'arguments':count};calls.append(row)
  if not expected[name][0]<=count<=expected[name][1]:issues.append(row)
assert not issues,issues
preserved=[]
for after in changed:
 if not str(after.relative_to(p/'work')).startswith('test/'):continue
 before=p/'base'/after.relative_to(p/'work')
 if not before.exists():continue
 names=lambda f:set(re.findall(r'\b(Should\w+)\s*\(',f.read_text()))
 assert names(before)<=names(after),(str(before),names(before)-names(after))
 assert after.read_text().count('Assert.')>=before.read_text().count('Assert.'),str(before)
 preserved+=sorted(names(before))
report={'syntax':syntax,'constructors':calls,'preservedAcceptanceNames':preserved,'issues':issues,'runtime':'Not run; parent owns execution.'}
(p/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps({'syntax':syntax,'constructors':len(calls),'preserved':len(preserved),'issues':issues}))
