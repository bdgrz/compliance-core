from pathlib import Path
import json,hashlib,difflib,shutil,subprocess,re,sys,collections
r=Path('/tmp/compliance-readiness-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def diff(before,after,path):return ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+str(path) if before else '/dev/null',tofile='b/'+str(path)))
for p in (r/'work').rglob('*.cs'):
 text='\n'.join(x.rstrip() for x in p.read_text().splitlines())+'\n'
 while '\n\n\n' in text:text=text.replace('\n\n\n','\n\n')
 p.write_text(text)
manifest=[];patches={n:[] for n in ('full.patch','implementation.patch','tests.patch','behavioral-red.patch','after-red.patch')}
for p in sorted((r/'work').rglob('*.cs')):
 rel=p.relative_to(r/'work');b=r/'base'/rel;before=b.read_text() if b.exists() else '';after=p.read_text()
 if before==after:continue
 kind='test' if rel.parts[0]=='test' else 'implementation'
 part='gap-plan' if p.name in ('ReadinessGapPlan.cs','PlanReadinessGapHandler.cs','AnnotateReadinessGapHandler.cs') else 'history-read-composition' if p.name in ('ReadinessReader.cs','ReadinessHistory.cs') else 'program-decision' if kind=='implementation' else 'tests-and-fixtures'
 manifest.append({'path':str(rel),'kind':kind,'partition':part,'before_sha256':sha(b) if b.exists() else None,'after_sha256':sha(p),'baseline_matches_current_main':sha(b)==sha(repo/rel) if b.exists() and(repo/rel).exists() else not b.exists() and not(repo/rel).exists()})
 d=diff(before,after,rel);patches['full.patch'].append(d);patches['tests.patch' if kind=='test' else 'implementation.patch'].append(d)
 red=r/'red'/rel;rb=red.read_text() if red.exists() else before
 if rb!=after:patches['after-red.patch'].append(diff(rb,after,rel))
for p in sorted((r/'red').rglob('*.cs')):
 rel=p.relative_to(r/'red');b=r/'base'/rel;patches['behavioral-red.patch'].append(diff(b.read_text() if b.exists() else '',p.read_text(),rel))
for name,pieces in patches.items():(r/name).write_text(''.join(pieces))
recon=[]
for label,sequence in [('full',['full.patch']),('red-green',['behavioral-red.patch','after-red.patch']),('partitioned',['implementation.patch','tests.patch'])]:
 target=r/'verify'/label
 if target.exists():shutil.rmtree(target)
 shutil.copytree(r/'base',target)
 for patch in sequence:
  result=subprocess.run(['patch','--batch','-p1','-d',str(target),'-i',str(r/patch)],capture_output=True,text=True);assert result.returncode==0,result.stdout+result.stderr
 bad=[m['path'] for m in manifest if not(target/m['path']).exists() or sha(target/m['path'])!=m['after_sha256']];assert not bad,bad
 recon.append({'route':label,'mismatches':bad})
# Keep baseline acceptance declarations and every assertion count.
names=lambda s:set(re.findall(r'\b(Should\w+)\s*\(',s))
old=set();new=set();removed=[];drops=[]
for m in manifest:
 if m['kind']!='test':continue
 b=r/'base'/m['path'];before=b.read_text() if b.exists() else '';after=(r/'work'/m['path']).read_text();old|=names(before);new|=names(after);removed+=sorted(names(before)-names(after))
 if before.count('Assert.')>after.count('Assert.'):drops.append(m['path'])
sys.path.insert(0,'/tmp/compliance-csharp-syntax314');from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));syntax=[];tokens=[];ownercollections=[];defs={};uses=[]
watch={'ProgramReadiness','ReadinessGapPlan','ReadinessReader','ReadinessDecisionAdmission','PlanReadinessGapHandler','AnnotateReadinessGapHandler','AbortReadinessDecisionHandler','ReadinessDecisionFailureProof','ReadinessTestServices'}
combined={str(p.relative_to(repo)):p for d in ('src','test') for p in(repo/d).rglob('*.cs')};combined.update({str(p.relative_to(r/'work')):p for p in(r/'work').rglob('*.cs')});changed={m['path'] for m in manifest}
def walk(node):
 q=[node]
 while q:
  n=q.pop();yield n;q.extend(reversed(n.named_children))
def parameters(data,node):
 xs=[x for x in node.named_children if x.type=='parameter'];return {'min':sum(b'=' not in data[x.start_byte:x.end_byte] for x in xs),'max':len(xs)}
for path,p in combined.items():
 data=p.read_bytes()
 if path not in changed and not any(n.encode() in data for n in watch):continue
 tree=parser.parse(data)
 if path in changed and tree.root_node.has_error:syntax.append(path)
 for node in walk(tree.root_node):
  if node.type in ('class_declaration','record_declaration'):
   name=node.child_by_field_name('name');name=data[name.start_byte:name.end_byte].decode() if name else '';ps=next((x for x in node.named_children if x.type=='parameter_list'),None)
   if name in watch and ps:defs.setdefault(name,[]).append(parameters(data,ps))
   if name in ('ProgramReadiness','ReadinessGapPlan') and path in changed:
    for child in node.child_by_field_name('body').named_children:
     if child.type=='constructor_declaration':
      ps=child.child_by_field_name('parameters');defs.setdefault(name,[]).append(parameters(data,ps))
     if child.type=='field_declaration' and re.search(rb'\b(List|Dictionary|HashSet)<',data[child.start_byte:child.end_byte]):ownercollections.append({'path':path,'field':data[child.start_byte:child.end_byte].decode()})
  if path in changed and node.type=='parameter_list':
   ps=[x for x in node.named_children if x.type=='parameter']
   for i,x in enumerate(ps):
    if b'CancellationToken ' in data[x.start_byte:x.end_byte] and i!=len(ps)-1:tokens.append({'path':path,'line':data[:x.start_byte].count(b'\n')+1})
  if node.type=='object_creation_expression':
   typ=node.child_by_field_name('type');args=node.child_by_field_name('arguments')
   if typ and args:
    name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
    if name in watch:uses.append({'path':path,'type':name,'arity':sum(x.type=='argument' for x in args.named_children)})
ctorbad=[x for x in uses if x['type'] in defs and not any(d['min']<=x['arity']<=d['max'] for d in defs[x['type']])]
serializer=(repo/'src/Compliance.Core/ComplianceCoreJsonContext.cs').read_text();roots=['ReadinessAssessmentRequested','ReadinessAssessmentAdopted','ReadinessDecisionAccepted','TypeIEntryDecisionAccepted','ReadinessDecisionRecorded','TypeIEntryDecisionRecorded','ReadinessDecisionCanceled','ReadinessGapPlanned','ReadinessGapAnnotated','ReadinessGapPlanReadinessDecisionUseAuthorized','ReadinessGapPlanReadinessDecisionUseSettled','ReadinessDecisionFailureProof'];registered=[{'type':n,'registered':bool(re.search(r'typeof\((?:[^)]+\.)?'+n+r'\)',serializer))} for n in roots]
assert not any((syntax,tokens,ownercollections,ctorbad,removed,drops)),{'syntax':syntax,'tokens':tokens,'ownercollections':ownercollections,'ctors':ctorbad,'removed':removed,'assertions':drops}
assert all(x['registered'] for x in registered),registered
static={'syntax_errors':syntax,'constructor_definitions':defs,'constructor_calls':uses,'constructor_errors':ctorbad,'cancellation_token_order_errors':tokens,'owner_collection_fields':ownercollections,'removed_acceptance_methods':removed,'assertion_count_drops':drops,'serializer_roots':registered,'original_test_methods':len(old),'new_test_methods':len(new-old),'method_names_added':sorted(new-old)}
(r/'static-checks.json').write_text(json.dumps(static,indent=2)+'\n');(r/'reconstruction.json').write_text(json.dumps(recon,indent=2)+'\n');(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'paths':len(manifest),'source':sum(m['kind']=='implementation' for m in manifest),'test':sum(m['kind']=='test' for m in manifest),'baseline_drift':[m['path'] for m in manifest if not m['baseline_matches_current_main']],'old_methods':len(old),'new_methods':len(new-old),'ctors_checked':len(uses),'reconstruction':recon},indent=2))
