exec(open('/tmp/compliance-mapping-native-prepared/implement.py').read().split('# Retain old full')[0])
for reader,owner,rules,evs,proposal in [('ControlMappingReader','ControlCriterionMapping','ControlCriterionMappingRules',['ControlCriterionMappingProposed','ControlCriterionMappingReviewed','ControlCriterionMappingRetired'],'MappingId'),('ApplicabilityReader','CriterionApplicability','CriterionApplicabilityRules',['CriterionNotApplicableProposed','CriterionApplicabilityReviewed','CriterionNotApplicableWithdrawn'],'DecisionId')]:
 s=(B/(C+reader+'.cs')).read_text().replace('using Bdgrz.Compliance.Features.NativeOperations;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Content;')
 s=s.replace('(IAggregateReader reader, IDomainEventReader events)','(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)')
 start=s.index('        await reader.HydrateAsync');end=s.index(';',start)
 expr=s[start:end].strip().replace('await reader.HydrateAsync','await reader.HydrateAsync')
 s=s[:start]+'        '+expr+s[end:] # convert expression-bodied to block
 methodstart=s.index('    public async ValueTask<'+owner+'> ReadLineAsync'); methodend=s.index(';',methodstart)
 method=s[methodstart:methodend+1]; sig,body=method.split('=>',1)
 method=sig.rstrip()+'\n    {\n        var owner = '+body.strip()+'\n        _ = await MappingLineNativeHistory.ReadAsync(owner, events, ct).ConfigureAwait(false);\n        return owner;\n    }'
 s=s[:methodstart]+method+s[methodend+1:]
 # explicit rules composition at exact hydrated cut.
 args=('fact.TenantId, fact.ProgramId, fact.ControlId, fact.EditionId, fact.CriterionIdentifier' if owner=='ControlCriterionMapping' else 'fact.TenantId, fact.ProgramId, fact.EditionId, fact.CriterionIdentifier')
 newrules=('new '+rules+'(fact.TenantId, fact.ProgramId, fact.ControlId, fact.EditionId, fact.CriterionIdentifier)' if owner=='ControlCriterionMapping' else 'new '+rules+'(fact.TenantId, fact.ProgramId, fact.EditionId, fact.CriterionIdentifier)')
 pos=s.index('    /// <summary>\n    ///     Finds')
 comp='''    /// <summary>Composes full immutable history only at the owner's exact committed cut.</summary>
    public async Task<RULES> ComposeAsync(OWNER owner, CancellationToken ct = default)
    {
        RULES? rules = null;
        var facts = await MappingLineNativeHistory.ReadAsync(owner, events, ct).ConfigureAwait(false);
        foreach (var native in facts)
        {
            if (native is EV fact)
                rules ??= NEWRULES;
            if (rules is null)
                throw new ImmutableContentIntegrityException("A line history must begin with its proposal.");
            var decoded = await MappingLineContent.ReadAsync(content, native, ct).ConfigureAwait(false);
            rules.Apply(decoded.Change);
            MappingLineContent.ValidateCurrent(decoded.Current, MappingLineContent.Current(rules));
        }
        if (rules is not null)
            return rules;
        return new RULES(OWNERARGS);
    }

'''.replace('RULES',rules).replace('OWNER',owner).replace('EV',evs[0]).replace('NEWRULES',newrules)
 # replace accidental ownerargs placeholder afterOWNER substitution
 ownerargs='Uuid.Parse(owner.Stream.Realm), '+('owner.ProgramId, owner.ControlId, owner.EditionId, owner.CriterionIdentifier' if owner=='ControlCriterionMapping' else 'owner.ProgramId, owner.EditionId, owner.CriterionIdentifier')
 comp=comp.replace(owner+'ARGS',ownerargs)
 s=s[:pos]+comp+s[pos:]
 # view full composition
 old='return (await ReadLineAsync('
 start=s.index(old); end=s.index('.View;',start)+len('.View;')
 expr=s[start:end].replace('return (await','var owner = await').replace(')).View;',');')
 # ends ConfigureAwait(false)).View? inspect replace generic
 expr=s[start:end]; expr=expr[len('return ('):].removesuffix(').View;')
 s=s[:start]+'var owner = '+expr+';\n        return (await ComposeAsync(owner, ct).ConfigureAwait(false)).View;'+s[end:]
 # replace program method body with exact area-cut composition.
 start=s.index('        var order = new List<string>();');end=s.index('\n    static bool IsProgramFact',start)
 snap='ControlMappingSnapshot' if owner=='ControlCriterionMapping' else 'ApplicabilitySnapshot'
 body='''        var order = new List<string>();
        var lines = new Dictionary<string, RULES>(StringComparer.Ordinal);
        var headers = new Dictionary<string, MappingLineHeader>(StringComparer.Ordinal);
        var offsets = new Dictionary<string, ulong>(StringComparer.Ordinal);
        var ids = new HashSet<Uuid>();
        var logicalIds = new Dictionary<string, HashSet<Uuid>>(StringComparer.Ordinal);
        var facts = 0L;
        Uuid? last = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(tenantId.ToString(),
                           OWNER.Area), EventCursor.Start, ct).ConfigureAwait(false))
        {
            var key = record.Stream.Resource;
            var offset = offsets.GetValueOrDefault(key);
            if (record.ResourceOffset != offset)
                throw new ImmutableContentIntegrityException("The program line history has another physical prefix.");
            offsets[key] = offset + 1;
            if (record.Event.Metadata.IsAudit || !IsProgramFact(record.Event, programId))
                continue;
            var first = record.Event switch
            {
TUPLES
                _ => throw new ImmutableContentIntegrityException("The program line contains another fact."),
            };
            if (!lines.TryGetValue(key, out var current))
            {
                current = first;
                lines.Add(key, current);
                headers.Add(key, new MappingLineHeader(0, 0, Uuid.Empty, null, null, false));
                logicalIds.Add(key, []);
                order.Add(key);
            }
            var metadata = record.Event.Metadata;
            var owner = NEWOWNER;
            if (record.Stream != owner.Stream || metadata.AggregateId != owner.Id ||
                metadata.AggregateVersion != (ulong)current.Revision + 1 || metadata.EventId == Uuid.Empty ||
                !ids.Add(metadata.EventId) || !logicalIds[key].Add(((IMappingLineFact)record.Event).Operation.LogicalId))
                throw new ImmutableContentIntegrityException("A program line fact has another scope, version or operation identity.");
            headers[key] = MappingLineTransitions.Next(owner, headers[key], record.Event);
            var decoded = await MappingLineContent.ReadAsync(content, record.Event, ct).ConfigureAwait(false);
            current.Apply(decoded.Change);
            MappingLineContent.ValidateCurrent(decoded.Current, MappingLineContent.Current(current));
            facts++;
            last = metadata.EventId;
        }
        return new SNAP([.. order.Select(key => lines[key].View!)], new SourceFence(facts, last));
    }
'''.replace('RULES',rules).replace('OWNER',owner).replace('SNAP',snap)
 tuples=[]
 for n in evs:
  tuples.append('                '+n+' fact => '+newrules+',')
 body=body.replace('TUPLES','\n'.join(tuples))
 # Rules provides tuple access through full view only here; line always nonempty beforetransition asproposal? forinitial current.Viewnull needfirst properties onrules itself expose fields.
 a='current.TenantId, current.ProgramId, '+('current.ControlId, ' if owner=='ControlCriterionMapping' else '')+'current.EditionId, current.CriterionIdentifier'
 body=body.replace('NEW'+owner,'new '+owner+'('+a+')')
 s=s[:start]+body+s[end:]
 (W/(C+reader+'.cs')).write_text(s)
 # owner/rules tuple scalar properties for constructing empty transient state.
 for type in [owner,rules]:
  p=W/(C+type+'.cs');t=p.read_text();pos=t.index('    public long Revision') if type==owner else t.index('    public Uuid Id')
  if type==owner:
   # addpropertiesassigned in ctor
   props=['ProgramId','EditionId','CriterionIdentifier']+(['ControlId'] if owner=='ControlCriterionMapping' else [])
   for prop in props:
    arg=prop[0].lower()+prop[1:];typ='string' if prop=='CriterionIdentifier' else 'Uuid';t=t.replace('        Acceptance =','        '+prop+' = '+arg+';\n        Acceptance =',1)
   pos=t.index('    public long Revision');pr=''.join('    public '+('string' if x=='CriterionIdentifier' else 'Uuid')+' '+x+' { get; }\n' for x in props)
  else:
   props=['TenantId','ProgramId','EditionId','CriterionIdentifier']+(['ControlId'] if owner=='ControlCriterionMapping' else []);pr=''.join('    public '+('string' if x=='CriterionIdentifier' else 'Uuid')+' '+x+' => _'+x[0].lower()+x[1:]+';\n' for x in props)
  t=t[:pos]+pr+t[pos:];p.write_text(t)
