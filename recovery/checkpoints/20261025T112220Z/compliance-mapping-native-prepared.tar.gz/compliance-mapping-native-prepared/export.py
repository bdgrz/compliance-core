from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
r=Path('/tmp/compliance-mapping-native-prepared');w=r/'work';b=r/'base';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
redpath='test/Compliance.Tests/Features/ControlMappings/ControlMappingNativeBoundaryTests.cs';history='test/Compliance.Tests/Features/ControlMappings/ControlMappingNativeHistoryTests.cs';red=(r/'old-native-api-red.cs').read_bytes()
def sha(x):return hashlib.sha256(x).hexdigest()
def diff(p,a,z):return ''.join(difflib.unified_diff(a.decode().splitlines(True),z.decode().splitlines(True),fromfile='a/'+p if a else '/dev/null',tofile='b/'+p))
shared={'src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs'}
patches={n:[] for n in ['implementation.patch','shared.patch','migrated-tests.patch','native-tests.patch','full.patch','green-after-red.patch','native-tests-after-red.patch']};files={};manifest=[]
oldpro={x['path']:x for x in json.loads((r/'baselines.json').read_text())}
for f in sorted(w.rglob('*')):
 if not f.is_file():continue
 p=str(f.relative_to(w));base=b/p;before=base.read_bytes() if base.exists() else b'';after=f.read_bytes()
 if before==after:continue
 assert before or not(repo/p).exists(),('EXISTING_REPOSITORY_PATH_WITHOUT_ORIGINAL',p)
 phase='shared.patch' if p in shared else 'native-tests.patch' if p in [redpath,history] else 'migrated-tests.patch' if p.startswith('test/') else 'implementation.patch'
 files[p]={'before':before,'after':after};patches[phase].append(diff(p,before,after));patches['full.patch'].append(diff(p,before,after));patches['green-after-red.patch'].append(diff(p,red if p==redpath else before,after))
 if p in [redpath,history]:patches['native-tests-after-red.patch'].append(diff(p,red if p==redpath else before,after))
 manifest.append({'path':p,'beforeSha256':sha(before) if before else None,'afterSha256':sha(after),'beforeBytes':len(before),'afterBytes':len(after),'phase':phase,'baselineSource':str(repo/p) if before else None,'redBeforeSha256':sha(red) if p==redpath else None,'currentRepositorySha256AtExport':sha((repo/p).read_bytes()) if(repo/p).exists() else None})
for n,ds in patches.items():(r/n).write_text(''.join(ds))
# Baseline registry is the exact captured physical bytes, including fresh SourceUse test/shared overlays.
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(r/'changed-baselines.json').write_text(json.dumps([{k:x[k] for k in ['path','beforeSha256','baselineSource','currentRepositorySha256AtExport']} for x in manifest],indent=2)+'\n')
orders={'red-then-green':['behavioral-red.patch','green-after-red.patch'],'full':['full.patch'],'split':['implementation.patch','shared.patch','migrated-tests.patch','native-tests.patch'],'red-split':['behavioral-red.patch','implementation.patch','shared.patch','migrated-tests.patch','native-tests-after-red.patch']};verified={}
for mode,order in orders.items():
 t=Path(tempfile.mkdtemp(prefix='mapping-reconstruct-',dir=r))
 try:
  for p,x in files.items():
   if not x['before']:continue
   f=t/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(x['before'])
  for patch in order:
   v=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/patch)],cwd=t,capture_output=True,text=True);assert v.returncode==0,(mode,patch,v.stdout,v.stderr)
  assert all((t/p).read_bytes()==x['after'] for p,x in files.items()),mode
  verified[mode]={'exactFiles':len(files),'patchOrder':order}
 finally:shutil.rmtree(t)
(r/'reconstruction.json').write_text(json.dumps(verified,indent=2)+'\n')
a=json.loads((r/'audit.json').read_text())
for k in ['syntaxErrors','constructorErrors','cancellationTokenNotLast','duplicateUsings','potentialMissingProofsUsing','removedAcceptanceNames','assertionCountDrops','existingRepositoryPathsMissingBefore']:assert not a[k],(k,a[k])
counts={n:sum(x['phase']==n for x in manifest) for n in ['implementation.patch','shared.patch','migrated-tests.patch','native-tests.patch']}
required='src/Compliance.Core/Features/NativeOperations/NativeOwnerHistory.cs';helper=repo/required
identitypaths=['src/Compliance.Core/Features/ControlMappings/ControlCoverageDirectorySchema.cs','src/Compliance.Core/Features/Work/ControlCriterionMappingWorkItemDirectorySchema.cs','src/Compliance.Core/Features/Work/CriterionApplicabilityWorkItemDirectorySchema.cs']
protected=[]
for p in identitypaths:
 assert (w/p).read_bytes()==(b/p).read_bytes(),p
 protected.append({'path':p,'sha256':sha((b/p).read_bytes()),'preparedChanges':False})
h={'root':str(r),'status':'FROZEN offline mapping/applicability native boundary and consumer preparation. Parent owns compiler/analyzers/format/runtime/full suites/direct per-file Jev/Git/integration/delivery.','changedPaths':len(files),'existingPathsWithOriginals':sum(bool(x['beforeSha256']) for x in manifest),'newPaths':sum(x['beforeSha256'] is None for x in manifest),'phaseCounts':counts,'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in ['behavioral-red.patch',*patches]},'stages':orders,'oldApiRedFilter':'FullyQualifiedName~ControlMappingNativeBoundaryTests','focusedFilter':'FullyQualifiedName~ControlMappings|FullyQualifiedName~FitzControlMappingWorkItemDirectoryTests|FullyQualifiedName~FitzCriterionApplicabilityWorkItemDirectoryTests|FullyQualifiedName~OwnerScopedProjectionIdentityTests|FullyQualifiedName~ControlCriterionMappingTypeIBaselineSourceContributorTests|FullyQualifiedName~WorkQueueReadConsistencyTests|FullyQualifiedName~ReadinessAssessmentHandlerTests','suiteFilter':'Category!=BrokerIntegration','staticCSharpPaths':a['changedPaths'],'staticExplicitConstructorCalls':a['constructorCallsAcrossEffectiveTree'],'originalAcceptanceNamesRetained':a['originalAcceptanceNames'],'newAcceptanceMethods':len(a['newAcceptanceNames']),'audit':'audit.json','reconstruction':'reconstruction.json','readme':'README.md','qualifications':'LOCAL-QUALIFICATIONS.md','requiredSource':[{'path':required,'sha256':sha(helper.read_bytes()),'origin':'small3 helper; exact native own-root proof API used'}],'protectedIdentities':protected,'constructorDeltas':['ControlMappingReader(IAggregateReader,IDomainEventReader,IImmutableContentStore)','ApplicabilityReader(IAggregateReader,IDomainEventReader,IImmutableContentStore)','FitzControlMappingDirectoryV1(IKvClient,IImmutableContentStore)','FitzCriterionApplicabilityDirectoryV1(IKvClient,IImmutableContentStore)'],'noRuntimeOrJevClaims':True}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'changed':len(files),'existing':h['existingPathsWithOriginals'],'new':h['newPaths'],'counts':counts,'manifestSha256':h['manifestSha256'],'handoffSha256':sha((r/'handoff.json').read_bytes()),'patches':h['patches']},indent=2))
