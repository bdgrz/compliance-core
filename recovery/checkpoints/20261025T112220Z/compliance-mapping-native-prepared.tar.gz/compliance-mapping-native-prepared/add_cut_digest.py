from pathlib import Path
r=Path('/tmp/compliance-mapping-native-prepared');w=r/'work';c=w/'src/Compliance.Core/Features/ControlMappings';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
# Reuse the already-qualified byte framing and immutable metadata terms locally, with no new domain authority/protocol.
s=(repo/'src/Compliance.Core/Features/SourceUse/SourceUseHistoryDigest.cs').read_text().replace('namespace Bdgrz.Compliance.Features.SourceUse;', 'namespace Bdgrz.Compliance.Features.ControlMappings;').replace('SourceUseHistoryDigest','MappingLineReplayDigest')
(c/'MappingLineReplayDigest.cs').write_text(s)
for name in ['ControlCriterionMapping','CriterionApplicability']:
 p=c/(name+'.cs');s=p.read_text();pos=s.index('    void ApplyFact(');s=s[:pos]+'''    internal string ReplayDigest { get; private set; } = MappingLineReplayDigest.Empty;

    protected override void Apply(DomainEvent ev)
    {
        ReplayDigest = MappingLineReplayDigest.Append(ReplayDigest, ev);
        base.Apply(ev);
    }

'''+s[pos:];p.write_text(s)
p=c/'MappingLineNativeHistory.cs';s=p.read_text().replace('        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, owner, ct).ConfigureAwait(false);','''        var facts = new List<DomainEvent>();
        var eventIds = new HashSet<Uuid>();
        var digest = MappingLineReplayDigest.Empty;
        var physical = 0UL;
        var version = 0UL;
        var acceptance = owner switch
        {
            ControlCriterionMapping mapping => mapping.Acceptance,
            CriterionApplicability applicability => applicability.Acceptance,
            _ => throw new ArgumentException("The owner is not a mapping line.", nameof(owner)),
        };
        await foreach (var record in events.ReadAsync(owner.Stream, 0, ct).ConfigureAwait(false))
        {
            if (physical == owner.CommittedStreamPosition)
                break;
            var value = record.Event;
            var metadata = value.Metadata;
            if (record.Stream != owner.Stream || record.ResourceOffset != physical || metadata.EventId == Uuid.Empty ||
                metadata.AggregateId != owner.Id || !eventIds.Add(metadata.EventId))
                throw new ImmutableContentIntegrityException("The native line history has another exact physical/metadata source identity.");
            physical++;
            digest = MappingLineReplayDigest.Append(digest, value);
            if (metadata.IsAudit)
                continue;
            if (metadata.AggregateVersion != ++version || value is not IMappingLineFact native)
                throw new ImmutableContentIntegrityException("The native line history has another logical version or fact family.");
            if (native.Operation.LogicalId == acceptance.SelectedLogicalId &&
                (acceptance.SelectedFact is not { } selected || selected.GetType() != value.GetType() ||
                    !selected.Equals(value) || selected.Metadata != metadata))
                throw new ImmutableContentIntegrityException("The selected acceptance differs from its actual native payload and complete metadata.");
            facts.Add(value);
        }
        if (physical != owner.CommittedStreamPosition || version != owner.Version)
            throw new ImmutableContentUnavailableException("The exact hydrated line history cut is not visible yet.");
        var observedDigest = owner switch
        {
            ControlCriterionMapping mapping => mapping.ReplayDigest,
            CriterionApplicability applicability => applicability.ReplayDigest,
            _ => throw new ArgumentException("The owner is not a mapping line.", nameof(owner)),
        };
        if (digest != observedDigest)
            throw new ImmutableContentIntegrityException("The native line history differs from the complete payload/immutable-metadata prefix actually hydrated.");''')
s=s.replace('            if (metadata.AggregateVersion != ++version || value is not IMappingLineFact native)','            if (metadata.AggregateVersion != ++version || value is not IMappingLineFact native || native.Operation is null)')
s=s.replace('        return facts;','        ct.ThrowIfCancellationRequested();\n        return facts;');p.write_text(s)
# Expected malformed JSON produces typed integrity failures rather than NullReference/undefined JsonElement faults.
p=c/'MappingLineTransitions.cs';s=p.read_text().replace('if (fact is not IMappingLineFact native || native.Header is null || native.Content is null ||','if (fact is not IMappingLineFact native || native.Header is null || native.Content is null || native.Operation is null ||\n            native.Operation.AuthoredIntentSha256 is not { Length: 64 } ||')
s=s.replace('native.Content.Sha256.Length != 64 || !native.Content.Sha256.All(Uri.IsHexDigit)', 'native.Content.Sha256 is not { Length: 64 } || !native.Content.Sha256.All(Uri.IsHexDigit)')
s=s.replace('owner is not ControlCriterionMapping || ev.ControlId == Uuid.Empty ||', 'owner is not ControlCriterionMapping || string.IsNullOrWhiteSpace(ev.CriterionIdentifier) || ev.ControlId == Uuid.Empty ||').replace('owner is not CriterionApplicability || owner.Id', 'owner is not CriterionApplicability || string.IsNullOrWhiteSpace(ev.CriterionIdentifier) || owner.Id')
p.write_text(s)
p=c/'MappingLineContent.cs';s=p.read_text();needle='''        object change;
        try''';s=s.replace(needle,'''        if (mutation.Authored.ValueKind != JsonValueKind.Object || mutation.Change.ValueKind != JsonValueKind.Object ||
            mutation.Current.ValueKind != JsonValueKind.Object)
            throw new ImmutableContentIntegrityException("The immutable line mutation lacks complete authored/change/current objects.");
        object change;
        try''').replace('if (request is null || value.Operation.OriginalExpectedRevision is null ||','if (request is null || value.Operation is null || value.Operation.OriginalExpectedRevision is null ||');p.write_text(s)
# Portia with-expressions intentionally clear envelope metadata; every actual raw persisted modified fact is restamped.
p=w/'test/Compliance.Tests/Features/ControlMappings/ControlMappingNativeHistoryTests.cs';s=p.read_text();s=s.replace('''        var events = new InMemoryEventStore();
        await events.AppendAsync(seeded.Owner.Stream, 0, modified);''','''        for (var index = 0; index < modified.Length; index++)
            if (!ReferenceEquals(modified[index], seeded.Facts[index]))
                DomainEventSeed.Attach(modified[index], seeded.Owner.Id, (ulong)index + 1);
        var events = new InMemoryEventStore();
        await events.AppendAsync(seeded.Owner.Stream, 0, modified);''');p.write_text(s)
