exec(open('/tmp/compliance-mapping-native-prepared/implement.py').read().split('# Retain old full')[0])
# Header transition source is deliberately content-free: accepted retry and executor hydration validate all raw history.
s='''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

static class MappingLineTransitions
{
    public static MappingLineHeader Next(Aggregate owner, MappingLineHeader before, DomainEvent fact)
    {
        if (fact is not IMappingLineFact native || native.Header is null || native.Content is null ||
            native.FirstResponse is null || native.OperationResult is null || native.Revision != before.Revision + 1 ||
            native.Content.SchemaVersion != MappingLineContent.Schema ||
            native.Content.MediaType != "application/json" || native.Content.ByteLength <= 0)
            throw new ImmutableContentIntegrityException("A line fact lacks its complete native revision/content binding.");
        MappingLineHeader next;
        switch (fact)
        {
'''
# ImmutableContentRef actual properties checked later.
for n,owner,cmd,action,prop,actor,tm in [
('ControlCriterionMappingProposed','ControlCriterionMapping','ProposeControlCriterionMapping','propose','MappingId','ev.ActorMemberId','ProposedAt'),
('ControlCriterionMappingReviewed','ControlCriterionMapping','ReviewControlCriterionMapping','review','MappingId','ev.ActorMemberId','DecidedAt'),
('ControlCriterionMappingRetired','ControlCriterionMapping','RetireControlCriterionMapping','terminate','MappingId','ev.ActorMemberId','RetiredAt'),
('CriterionNotApplicableProposed','CriterionApplicability','ProposeCriterionNotApplicable','propose','DecisionId','ev.ProposerMemberId','ProposedAt'),
('CriterionApplicabilityReviewed','CriterionApplicability','ReviewCriterionApplicability','review','DecisionId','Reviewer(ev.Actor)','ReviewedAt'),
('CriterionNotApplicableWithdrawn','CriterionApplicability','WithdrawCriterionNotApplicable','terminate','DecisionId','Reviewer(ev.Actor)','WithdrawnAt')]:
 args='ev.TenantId, ev.ProgramId, '+('ev.ControlId, ' if owner=='ControlCriterionMapping' else '')+'ev.EditionId, ev.CriterionIdentifier'
 s+='            case '+n+' ev:\n'
 s+='                if (owner is not '+owner+' || owner.Id != '+owner+'.IdentityOf('+args+') ||\n'
 s+='                    owner.Stream.Realm != ev.TenantId.ToString() || ev.ProgramId == Uuid.Empty ||\n'
 s+='                    !NativeOwnerHistory.IsOwnRoot(owner, ev.Operation, nameof('+cmd+'), (ulong)before.Revision) ||\n'
 s+='                    ev.Operation.Actor != ev.Actor || ev.Operation.AcceptedAt != ev.'+tm+' || '+actor+' == Uuid.Empty)\n'
 s+='                    throw new ImmutableContentIntegrityException("A line fact has another tuple, actor or native root binding.");\n'
 if action=='propose':
  more=' || before.Active is not null' if owner=='CriterionApplicability' else ''
  s+='                if (before.Pending is not null'+more+' || ev.VersionNumber != before.VersionCount + 1 ||\n                    ev.Operation.LogicalId != ev.'+prop+' || ev.'+prop+' == Uuid.Empty)\n                    throw new ImmutableContentIntegrityException("A proposal does not follow its resolved line.");\n'
  s+='                next = before with { Revision = ev.Revision, VersionCount = ev.VersionNumber, FirstProposalId = before.VersionCount == 0 ? ev.'+prop+' : before.FirstProposalId, Pending = new MappingLineSlot(ev.'+prop+', ev.VersionNumber, '+actor+') };\n'
 elif action=='review':
  logid='DecisionId' if owner=='ControlCriterionMapping' else 'ReviewDecisionId'
  s+='                if (before.Pending is not { } pending'+n+' || pending'+n+'.ProposalId != ev.'+prop+' ||\n                    pending'+n+'.VersionNumber != ev.VersionNumber || ev.Operation.LogicalId != ev.'+logid+' ||\n                    ev.Outcome is not ("accept" or "reject") ||\n                    pending'+n+'.ProposerMemberId == '+actor+' && ev.SeparationOfDutiesWaiverId is null)\n                    throw new ImmutableContentIntegrityException("A review does not resolve its exact independent pending proposal.");\n'
  s+='                next = before with { Revision = ev.Revision, Pending = null, Active = ev.Outcome == "accept" ? before.Pending : before.Active };\n'
 else:
  s+='                if (before.Pending is not null || before.Active is not { } active'+n+' ||\n                    active'+n+'.ProposalId != ev.'+prop+' || active'+n+'.VersionNumber != ev.VersionNumber)\n                    throw new ImmutableContentIntegrityException("A termination does not name the exact accepted proposal.");\n'
  s+='                next = before with { Revision = ev.Revision, Active = null, EverTerminated = true };\n'
 s+='                break;\n'
s+='''            default: throw new ImmutableContentIntegrityException("The line contains another native fact family.");
        }
        if (next != native.Header)
            throw new ImmutableContentIntegrityException("The native line header does not match its complete transition.");
        return next;
    }

    static Uuid Reviewer(ActorReference actor) => actor.Kind == "member" && Uuid.TryParse(actor.Id, out var member)
        ? member : Uuid.Empty;
}
'''
(W/(C+'MappingLineTransitions.cs')).write_text(s)
# Finalizer replays all compact transitions transiently. Audit/offset/version checks come from small3.
(W/(C+'MappingLineNativeHistory.cs')).write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

static class MappingLineNativeHistory
{
    public static async Task<IReadOnlyList<DomainEvent>> ReadAsync(Aggregate owner, IDomainEventReader events,
        CancellationToken ct)
    {
        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, owner, ct).ConfigureAwait(false);
        var header = new MappingLineHeader(0, 0, Uuid.Empty, null, null, false);
        var proposals = new HashSet<Uuid>();
        var operations = new HashSet<Uuid>();
        foreach (var fact in facts)
        {
            header = MappingLineTransitions.Next(owner, header, fact);
            var native = (IMappingLineFact)fact;
            if (!operations.Add(native.Operation.LogicalId))
                throw new ImmutableContentIntegrityException("A logical operation occurs more than once on the line.");
            var proposed = fact switch
            {
                ControlCriterionMappingProposed mapping => mapping.MappingId,
                CriterionNotApplicableProposed applicability => applicability.DecisionId,
                _ => Uuid.Empty,
            };
            if (proposed != Uuid.Empty && !proposals.Add(proposed))
                throw new ImmutableContentIntegrityException("A historical proposal identity was reused on the line.");
        }
        var actual = owner switch
        {
            ControlCriterionMapping mapping => (mapping.Header, mapping.CurrentContent),
            CriterionApplicability applicability => (applicability.Header, applicability.CurrentContent),
            _ => throw new ArgumentException("The owner is not a mapping line.", nameof(owner)),
        };
        if (header != actual.Header || (facts.Count == 0 ? null : ((IMappingLineFact)facts[^1]).Content) != actual.CurrentContent)
            throw new ImmutableContentIntegrityException("The native history differs from the hydrated current line cut.");
        return facts;
    }
}
''')
(W/(C+'MappingLineAggregateReader.cs')).write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>Finalizes whole raw line history for explicit reads and executor-internal rehydration.</summary>
public sealed class MappingLineAggregateReader(IAggregateReader inner, IDomainEventReader events) : IAggregateReader
{
    public async ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate, CancellationToken ct = default)
        where TAggregate : Aggregate
    {
        var hydrated = await inner.HydrateAsync(aggregate, ct).ConfigureAwait(false);
        if (hydrated is ControlCriterionMapping or CriterionApplicability)
            _ = await MappingLineNativeHistory.ReadAsync(hydrated, events, ct).ConfigureAwait(false);
        return hydrated;
    }
}
''')
