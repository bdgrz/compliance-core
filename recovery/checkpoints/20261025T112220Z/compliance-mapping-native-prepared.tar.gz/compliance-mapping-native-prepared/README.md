# Frozen Mapping61 preparation

Offline-only preparation in `/tmp/compliance-mapping-native-prepared`. No main checkout mutation, .NET execution, Git/worktree/GitHub mutation, brokers, Jev call, or runtime pass claim. Parent owns actual compilation/analyzers/format, focused and full tests, direct per-file Jev review, integration and delivery.

The root reported both existing-API RED cases qualified against merged #1116: lifetime collections were retained, and a valid Unicode mapping produced 49,948 bytes against the 49,152-byte budget. `behavioral-red.patch` and `old-native-api-red.cs` preserve the submitted RED bytes. This preparation itself did not execute those tests.

## Physical handoff and stages

`handoff.json` is the machine-readable entry point; `manifest.json` records exact original/final SHA-256 for all 61 changed paths (37 existing originals, 24 new). Every changed existing repository path has a nonnull original baseline. `changed-baselines.json` also records the main source hash observed at export; `base/` and `work/` contain exact physical files. Initial scope inventory and prior shared baselines remain saved.

The final package has 42 implementation/documentation paths, two shared production paths, 15 migrated fixture/test/helper paths and two native test files. Apply delta patches, preserving unrelated parent overlays; do not overwrite whole shared files from the snapshots.

- Existing qualified RED evidence retained; all-final installation: `implementation.patch`, `shared.patch`, `migrated-tests.patch`, `native-tests.patch`.
- Fresh tests-first reconstruction: `behavioral-red.patch`, then `green-after-red.patch`.
- Split after RED: `behavioral-red.patch`, `implementation.patch`, `shared.patch`, `migrated-tests.patch`, `native-tests-after-red.patch`.
- `full.patch` reconstructs the same final files directly.

All four orders reconstruct the exact 61 final file byte streams in isolated temporary directories, recorded in `reconstruction.json`. These are patch integrity checks, not a runtime GREEN claim. Root's formatted RED copy may differ in whitespace from the saved original; use the preserved qualified evidence and all-final installation or compose the native test delta against that concrete copy.

## Authoritative state and read composition

`ControlCriterionMapping` and `CriterionApplicability` retain a bounded scalar `MappingLineHeader`, one immutable `CurrentContent` ref, one selected native acceptance, and a 64-character rolling replay commitment. Header state includes the first proposal identity, total proposal count, at most one pending and one accepted identity/proposer slot, and the terminal-status flag. Neither owner exposes or retains a lifetime `Facts`, `View`, `Contains`, version list, or history dictionary.

The six native business facts keep their existing semantic event names and move to discriminator v3. Their routing, work, identity, review/outcome/waiver, actor and decision-time scalars remain present. Authored rationale/explanation bytes and complete current values live in verified immutable `MappingLineMutation` content. That content contains the exact typed authored request, complete normalized business change, and bounded current public value with only pending/accepted versions. No text or history is truncated.

Pure transient `ControlCriterionMappingRules` / `CriterionApplicabilityRules` preserve the original guards, independent review and exact waiver rules, succession, exact-target retirement/withdrawal and full public history reducer behavior. `ComposeAsync(owner)` reads only that owner's exact committed cut and verifies all immutable bodies; `ReadProgramAsync` composes actual native area records with their original event-count/last-event-ID fences. Full version histories remain explicit read results, never command-owner state.

Raw finalization validates all proposal/logical identities transiently, including closed unselected history, exact tuple/root/actor/time/revision/header bindings, contiguous actual physical offsets, metadata event identities and logical versions, the selected fact's complete payload/metadata, and the complete payload/immutable-metadata prefix that was actually hydrated. The digest uses existing SourceUse digest framing locally and excludes save-stamped attribution; selected actual metadata is compared in full. Preparation binds owner revision, owner version, physical position and replay commitment before append. Source positions, metadata versions, business revisions and proposal version numbers are checked independently; no cross-family counter equivalence is assumed.

Accepted retries need raw native history and the frozen first response, with no mutation/current-body read. New admission and full history reads may scan lifetime raw facts and immutable mutation bodies transiently. This slice bounds returned live owner state, not total durable history, transient read cost, SDK internals or broker resource use.

## Existing behavior and consumers

All six public request IDs/DTOs/routes remain unchanged. Proposals retain their original typed 200 registration; review, retirement and withdrawal retain plain `IRequest` Unit/200 behavior and the existing parent native HTTP bridge. No Program route patch or second result callback is introduced.

Personal HTTP restrictions, current program-management authorization/licensing, exact selected edition/catalog checks, exact currently approved Control version observation, separation-of-duties waiver scope and personal actor attribution remain in place. Body/source reads and immutable freezes now run inside native asynchronous preparation so the already-frozen central equal-winner Prepare race recovery applies. Family boundaries catch only expected immutable integrity/unavailable failures; cancellation and unexpected programmer faults retain their meaning.

Public first MappingId/DecisionId and terminal status after a later rejection are preserved. Coverage projection schema names, owner-qualified keys and work-item IDs from #1112 are unchanged and explicitly hashed in `handoff.json`. Full read/projection values preserve exact text and source/as-of receipt semantics. Mapping Type-I source capture still hashes fully expanded version values, so those business bytes remain in the existing contributor/publisher/archive logical preimage; no new sidecar or source protocol is invented.

Native readers and both coverage projection stores now need `IImmutableContentStore`; exact constructor deltas are listed in the handoff. Coverage fixture factories and actual source/as-of/owner-scope fixtures publish real native immutable mutation and original-response content. Isolated scalar work-projector invalid-event fixtures retain their opaque reference purpose and existing malformed transition assertions.

## DI composition

The shared production delta adds Mapping as a separate opaque-key outer `IAggregateReader` decorator after the existing Calendar and SourceUse layers: original -> Calendar -> SourceUse -> Mapping. Each wrapper resolves its captured inner keyed registration, never itself. The registered aggregate executor resolves the current decorated `IAggregateReader`, so internal rehydration finalizes the same raw history.

The fixture delta is based on root's current `AddVerifiedSourceUseReader()` helper. New `VerifiedMappingLineServices.AddVerifiedMappingLineReader()` wraps the current last nonkey reader using another fresh opaque key after that call. Existing custom registration lifetimes/disposal and root's RiskMethod/catalog overloads remain in the exact baseline and delta. Shared JSON adds only Header, Slot, Mutation and the six plain change roots.

## Verification queued to parent

Static audit: 60 changed C# paths parsed, 144 explicit constructor calls checked against the effective source tree, zero syntax/arity/cancellation-token-order/duplicate-using/missing-Proofs findings. All 56 original acceptance names in changed existing test files and their assertion counts are preserved. Ten new/migrated acceptance methods cover the two qualified RED cases and 18 history/response/failure rows: both default and executor unselected duplicates, malformed accepted retry, real verified mutation/current-authority substitutions, projection row/checkpoint rollback, original response without mutation reads, typed unavailable admission without append, first identity/terminal history, same-header/intermediate-payload substitution at identical full metadata cut, and truncated exact cuts. All same-position `with` clones restore the original full metadata; added forged facts receive fresh versioned metadata.

Use the focused filter in `handoff.json`, then the parent full suite with `Category!=BrokerIntegration`. Do not start brokers. Run the compiler/analyzers/formatter and direct per-file Jev on the exact integrated files. See `LOCAL-QUALIFICATIONS.md` for the precise missing source-use/proof and persistence boundaries; none were replaced with invented authority.
