from pathlib import Path
import re,json
R=Path('/tmp/compliance-mapping-native-prepared'); W=R/'work'; B=R/'base'
C='src/Compliance.Core/Features/ControlMappings/'; M='src/Compliance.Common/Features/ControlMappings/'
names=['ControlCriterionMappingProposed','ControlCriterionMappingReviewed','ControlCriterionMappingRetired','CriterionNotApplicableProposed','CriterionApplicabilityReviewed','CriterionNotApplicableWithdrawn']
# Retain old full business changes solely as immutable content, no event/transport inheritance.
params={}
for n in names:
 s=(B/(M+n+'.cs')).read_text(); p=re.search(r'public sealed record '+n+r'\((.*?)\)\s*:',s,re.S).group(1); params[n]=p
 change=s[s.index('using '):]; change=re.sub(r'/// <summary>.*?</summary>\s*', '',change,flags=re.S)
 change=re.sub(r'\[Discriminator\([^\n]+\)\]\n','',change).replace('record '+n+'(','record '+n+'Change(')
 change=change.replace(' : DomainEvent, INativeOperationFact','').replace('\n    : DomainEvent, INativeOperationFact','')
 change=change.replace('using Cntryl.Portia;\n','')
 (W/(C+n+'Change.cs')).write_text(change)
 # Compact frame keeps all existing routing/work/provenance scalar fields, large authored text lives in content.
 p2=re.sub(r'\bstring (?:Rationale|ApplicabilityExplanation),?\s*','',p)
 p2=p2.replace('OperationProvenance Operation,','ImmutableContentRef Content, MappingLineHeader Header, OperationProvenance Operation,')
 frame=s.replace(', 2)]',', 3)]').replace(p,p2)
 frame=re.sub(r'/// <summary>.*?</summary>\s*','',frame,flags=re.S)
 (W/(M+n+'.cs')).write_text(frame)
# Pure transient rules preserve original guards, reducer and full public history. No aggregate registered.
for name,evs in [('ControlCriterionMapping',names[:3]),('CriterionApplicability',names[3:])]:
 s=(B/(C+name+'.cs')).read_text(); s=s.replace('public sealed class '+name+' : Aggregate','public sealed class '+name+'Rules')
 s=s.replace('public '+name+'(', 'public '+name+'Rules(')
 s=re.sub(r'\n        : base\(IdentityOf.*?\n    \{','\n    {',s,flags=re.S)
 s=re.sub(r'        Acceptance = new NativeAcceptance\(selectedLogicalId\);\n(?:        On<[^\n]+\n){3}','',s)
 s=s.replace('readonly List<DomainEvent> _facts','readonly List<object> _facts')
 s=re.sub(r'    /// <summary>Acceptance of.*?public NativeAcceptance Acceptance \{ get; \}\n\n','',s,flags=re.S)
 s=s.replace('IReadOnlyList<DomainEvent> Facts','IReadOnlyList<object> Facts').replace('Fold(DomainEvent ev)','Fold(object ev)')
 s=s.replace('        Acceptance.Observe(ev);\n','')
 for n in evs:s=s.replace(n,n+'Change')
 s=s.replace('RaiseEvent(', 'Apply(')
 # Apply exposed explicitly for verified read composition and test roundtrips.
 s=s.replace('    void Apply(', '    public void Apply(')
 pos=s.index('    /// <summary>The logical revision')
 fields='    public Uuid Id => IdentityOf('+ ('_tenantId, _programId, _controlId, _editionId, _criterionIdentifier' if name=='ControlCriterionMapping' else '_tenantId, _programId, _editionId, _criterionIdentifier')+');\n    public EventStreamAddress Stream => new(_tenantId.ToString(), Area, Id.ToString());\n\n'
 s=s[:pos]+fields+s[pos:]
 # One object dispatcher (plain immutable change, not event).
 pos=s.index('    void Fold(')
 dispatcher='    public void Apply(object change)\n    {\n        switch (change)\n        {\n'+''.join('            case '+n+'Change value: Apply(value); break;\n' for n in evs)+'            default: throw new InvalidOperationException("The immutable change has another mapping family.");\n        }\n    }\n\n'
 s=s[:pos]+dispatcher+s[pos:]
 (W/(C+name+'Rules.cs')).write_text(s)
 # reducers are plain content consumers.
 s=(B/(C+name+'Reducer.cs')).read_text().replace('DomainEvent domainEvent','object domainEvent')
 for n in evs:s=s.replace(n,n+'Change')
 (W/(C+name+'Reducer.cs')).write_text(s)
# Shared compact scalar header, no lifetime arrays/sets.
(W/(M+'MappingLineHeader.cs')).write_text('''namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>The bounded current identities of a mapping or applicability line.</summary>
public sealed record MappingLineHeader(long Revision, int VersionCount, Uuid FirstProposalId,
    MappingLineSlot? Pending, MappingLineSlot? Active, bool EverTerminated);
''')
(W/(M+'MappingLineSlot.cs')).write_text('''namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>The exact current proposal identity and proposing member.</summary>
public sealed record MappingLineSlot(Uuid ProposalId, int VersionNumber, Uuid ProposerMemberId);
''')
# Remove transport response material from pure changes/rules; native facts own the original response.
for n in names:
 p=W/(C+n+'Change.cs'); s=p.read_text(); s=re.sub(r',\s*ImmutableContentRef\? FirstResponse,\s*ImmutableContentRef\? OperationResult','',s); p.write_text(s)
for name in ['ControlCriterionMapping','CriterionApplicability']:
 p=W/(C+name+'Rules.cs'); s=p.read_text()
 s=re.sub(r',\s*ImmutableContentRef firstResponse,\s*ImmutableContentRef operationResult','',s)
 s=re.sub(r',\s*firstResponse,\s*operationResult','',s)
 s=s.replace(' || ev.FirstResponse is null','').replace('ev.FirstResponse is null || ','')
 p.write_text(s)
# Interface gives the exact bounded header/content of both native families.
(W/(M+'IMappingLineFact.cs')).write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>A native line transition with complete immutable authored/current content.</summary>
public interface IMappingLineFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid ProgramId { get; }
    long Revision { get; }
    int VersionNumber { get; }
    ImmutableContentRef Content { get; }
    MappingLineHeader Header { get; }
}
''')
for n in names:
 p=W/(M+n+'.cs'); p.write_text(p.read_text().replace('DomainEvent, INativeOperationFact','DomainEvent, IMappingLineFact'))
# Generate scalar transition checks from the actual six existing protocols.
for owner, evs, args, own in [('ControlCriterionMapping', names[:3], 'Uuid tenantId, Uuid programId, Uuid controlId, Uuid editionId, string criterionIdentifier', 'tenantId, programId, controlId, editionId, criterionIdentifier'),('CriterionApplicability', names[3:], 'Uuid tenantId, Uuid programId, Uuid editionId, string criterionIdentifier', 'tenantId, programId, editionId, criterionIdentifier')]:
 before=(B/(C+owner+'.cs')).read_text(); area=re.search(r'public const string Area = ([^;]+);',before).group(1); identity=re.search(r'    public static Uuid IdentityOf\(.*?;\n',before,re.S).group(0)
 code='''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>A bounded native line owner; full history is composed explicitly by its verified reader.</summary>
public sealed class OWNER : Aggregate
{
    public const string Area = AREA;
    public const int MaximumTextLength = 4000;
    public const string RegistrationSchema = "OWNER.Registration.v1";
    public OWNER(ARGS, Uuid selectedLogicalId = default)
        : base(IdentityOf(OWN), new EventStreamAddress(tenantId.ToString(), Area, IdentityOf(OWN).ToString()))
    {
        Acceptance = new NativeAcceptance(selectedLogicalId);
HANDLERS
    }
    public NativeAcceptance Acceptance { get; }
    public MappingLineHeader Header { get; private set; } = new(0, 0, Uuid.Empty, null, null, false);
    public ImmutableContentRef? CurrentContent { get; private set; }
    public long Revision => Header.Revision;
IDENTITY
    public Result Apply(MappingLinePrepared prepared, ImmutableContentRef firstResponse)
    {
        ArgumentNullException.ThrowIfNull(prepared);
        if (prepared.BeforeRevision != Revision || prepared.OwnerVersion != Version ||
            prepared.PhysicalPosition != CommittedStreamPosition || prepared.Fact is not IMappingLineFact)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The line changed while immutable content was prepared.", true));
        switch (prepared.Fact)
        {
APPEND
            default: throw new InvalidOperationException("The prepared fact belongs to another line family.");
        }
        return Result.Success;
    }

    void ApplyFact(DomainEvent fact)
    {
        var next = MappingLineTransitions.Next(this, Header, fact);
        Acceptance.Observe(fact);
        Header = next;
        CurrentContent = ((IMappingLineFact)fact).Content;
    }
}
'''.replace('OWNER',owner).replace('AREA',area).replace('ARGS',args).replace('OWN',own).replace('IDENTITY',identity)
 code=code.replace('HANDLERS','\n'.join('        On<'+n+'>(ev => ApplyFact(ev));' for n in evs))
 code=code.replace('APPEND','\n'.join('            case '+n+' ev: RaiseEvent(ev with { FirstResponse = firstResponse }); break;' for n in evs))
 (W/(C+owner+'.cs')).write_text(code)
(W/(C+'MappingLinePrepared.cs')).write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>The exact hydrated append cut and prepared immutable native fact.</summary>
public sealed record MappingLinePrepared(long BeforeRevision, ulong OwnerVersion, ulong PhysicalPosition, DomainEvent Fact);
''')
(W/(C+'MappingLineMutation.cs')).write_text('''using System.Text.Json;

namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>Complete authored intent, business change and bounded current authority of one native transition.</summary>
public sealed record MappingLineMutation(JsonElement Authored, JsonElement Change, JsonElement Current);
''')
