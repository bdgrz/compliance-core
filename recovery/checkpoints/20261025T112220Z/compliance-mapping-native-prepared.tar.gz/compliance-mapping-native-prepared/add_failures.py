from pathlib import Path
w=Path('/tmp/compliance-mapping-native-prepared/work');c=w/'src/Compliance.Core/Features/ControlMappings'
(c/'MappingLineFailures.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

static class MappingLineFailures
{
    public static async ValueTask<Result<T>> ExecuteAsync<T>(Func<ValueTask<Result<T>>> action, CancellationToken ct)
    {
        try { return await action().ConfigureAwait(false); }
        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return Result<T>.Failure(Error(exception));
        }
    }
    public static async ValueTask<Result> ExecuteAsync(Func<ValueTask<Result>> action, CancellationToken ct)
    {
        try { return await action().ConfigureAwait(false); }
        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return Result.Failure(Error(exception));
        }
    }
    static RequestError Error(ImmutableContentIntegrityException exception) => new(RequestErrorKind.Conflict,
        "The exact control mapping content cannot be verified: " + exception.Message,
        isTransient: exception is ImmutableContentUnavailableException);
}
''')
for cmd in ['ProposeControlCriterionMapping','ReviewControlCriterionMapping','RetireControlCriterionMapping','ProposeCriterionNotApplicable','ReviewCriterionApplicability','WithdrawCriterionNotApplicable']:
 p=c/(cmd+'Handler.cs');s=p.read_text();start=s.index('    public async ValueTask<Result');end=s.index('    {',start);signature=s[start:end]
 wrapper=signature.replace('public async','public').rstrip()+' =>\n        MappingLineFailures.ExecuteAsync(() => HandleCoreAsync(context, ct), ct);\n\n'+signature.replace('public async','async').replace('HandleAsync(', 'HandleCoreAsync(')
 s=s[:start]+wrapper+s[end:];p.write_text(s)
# Public prepared value can only be constructed at the internal verified preparation boundary.
(c/'MappingLinePrepared.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>The exact hydrated append cut and prepared immutable native fact.</summary>
public sealed class MappingLinePrepared
{
    internal MappingLinePrepared(long beforeRevision, ulong ownerVersion, ulong physicalPosition, DomainEvent fact) =>
        (BeforeRevision, OwnerVersion, PhysicalPosition, Fact) = (beforeRevision, ownerVersion, physicalPosition, fact);
    public long BeforeRevision { get; }
    public ulong OwnerVersion { get; }
    public ulong PhysicalPosition { get; }
    internal DomainEvent Fact { get; }
}
''')
p=c/'MappingLineContent.cs';s=p.read_text().replace('public static async Task<MappingLinePrepared>', 'internal static async Task<MappingLinePrepared>')
import re
s=re.sub(r'        (\w+) expected = new\(',r'        var expected = new \1(',s)
# Native directory validation reconstructs tuple owner without projection-derived authority.
pos=s.index('    static DomainEvent Frame')
method='''    internal static Aggregate Owner(DomainEvent frame) => frame switch
    {
'''
for n in ['ControlCriterionMappingProposed','ControlCriterionMappingReviewed','ControlCriterionMappingRetired','CriterionNotApplicableProposed','CriterionApplicabilityReviewed','CriterionNotApplicableWithdrawn']:
 owner='ControlCriterionMapping' if n.startswith('Control') else 'CriterionApplicability';args='value.TenantId, value.ProgramId, '+('value.ControlId, ' if n.startswith('Control') else '')+'value.EditionId, value.CriterionIdentifier';method+='        '+n+' value => new '+owner+'('+args+'),\n'
method+='        _ => throw new ImmutableContentIntegrityException("The native frame belongs to another line family."),\n    };\n\n';s=s[:pos]+method+s[pos:];p.write_text(s)
for typ in ['FitzControlMappingDirectoryV1','FitzCriterionApplicabilityDirectoryV1']:
 p=c/(typ+'.cs');s=p.read_text().replace('        var decoded = await MappingLineContent.ReadAsync','        _ = MappingLineTransitions.Next(MappingLineContent.Owner(domainEvent),\n            current is null ? new MappingLineHeader(0, 0, Uuid.Empty, null, null, false) : MappingLineContent.Header(current), domainEvent);\n        var decoded = await MappingLineContent.ReadAsync');p.write_text(s)
