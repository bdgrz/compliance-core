from pathlib import Path
r=Path('/tmp/compliance-mapping-native-prepared');w=r/'work';t=w/'test/Compliance.Tests';p=t/'Features/ControlMappings/ControlMappingNativeHistoryTests.cs'
p.write_text('''using System.Text.Json;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.ControlMappings;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.ControlMappings;

public sealed class ControlMappingNativeHistoryTests
{
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task ShouldRejectUnselectedHistoricalProposalReuseGivenDirectOrExecutorHydration(bool applicability,
        bool execute)
    {
        // Arrange
        await using var fixture = new NativeFixture();
        var seeded = await fixture.SeedAsync(applicability, "reject");
        var first = (IMappingLineFact)seeded.Facts[0];
        var repeatedHeader = first.Header with { Revision = 3, VersionCount = 2,
            Pending = first.Header.Pending! with { VersionNumber = 2 } };
        var provenance = first.Operation with { OriginalExpectedRevision = 2 };
        DomainEvent repeated = seeded.Facts[0] switch
        {
            ControlCriterionMappingProposed mapping => mapping with
                { Revision = 3, VersionNumber = 2, Header = repeatedHeader, Operation = provenance },
            CriterionNotApplicableProposed decision => decision with
                { Revision = 3, VersionNumber = 2, Header = repeatedHeader, Operation = provenance },
            _ => throw new InvalidOperationException(),
        };
        DomainEventSeed.Attach(repeated, seeded.Owner.Id, 3);
        await fixture.Events.AppendAsync(seeded.Owner.Stream, 2, [repeated]);
        var entered = false;

        // Act
        var failure = await Record.ExceptionAsync(async () =>
        {
            if (applicability)
            {
                var owner = (CriterionApplicability)MappingLineContent.Owner(repeated);
                if (execute)
                    await fixture.Executor.ExecuteAsync(owner, _ =>
                    { entered = true; return AggregateOutcome.Discard(Result.Success); }, new RequestDispatchContext(RequestActor.System));
                else
                    await fixture.Reader.HydrateAsync(owner);
            }
            else
            {
                var owner = (ControlCriterionMapping)MappingLineContent.Owner(repeated);
                if (execute)
                    await fixture.Executor.ExecuteAsync(owner, _ =>
                    { entered = true; return AggregateOutcome.Discard(Result.Success); }, new RequestDispatchContext(RequestActor.System));
                else
                    await fixture.Reader.HydrateAsync(owner);
            }
        });

        // Assert
        Assert.IsType<ImmutableContentIntegrityException>(failure);
        Assert.False(entered);
        Assert.Equal(3, await NativeFacts.CountAsync(fixture.Services, fixture.Tenant, seeded.Owner.Stream.Area));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldRollbackRowsAndCheckpointGivenVerifiedBodyWithSubstitutedBusinessChange(bool applicability)
    {
        // Arrange
        await using var fixture = new NativeFixture();
        var seeded = await fixture.SeedAsync(applicability, "accept");
        var review = (IMappingLineFact)seeded.Facts[1];
        var body = await NativeContent.ReadAsync<MappingLineMutation>(fixture.Content, fixture.Tenant, review.Content);
        var decoded = await MappingLineContent.ReadAsync(fixture.Content, seeded.Facts[1], CancellationToken.None);
        object wrong = decoded.Change switch
        {
            ControlCriterionMappingReviewedChange value => value with { Rationale = "Another review rationale." },
            CriterionApplicabilityReviewedChange value => value with { Rationale = "Another review rationale." },
            _ => throw new InvalidOperationException(),
        };
        var altered = body with { Change = JsonSerializer.SerializeToElement(wrong, wrong.GetType(), ComplianceCoreJsonContext.Default) };
        var reference = await NativeContent.WriteAsync(fixture.Content, fixture.Tenant, MappingLineContent.Schema, altered);
        DomainEvent malformed = seeded.Facts[1] switch
        {
            ControlCriterionMappingReviewed mapping => mapping with { Content = reference },
            CriterionApplicabilityReviewed decision => decision with { Content = reference },
            _ => throw new InvalidOperationException(),
        };
        var mappingDirectory = new FitzControlMappingDirectoryV1(new InMemoryKvClient(), fixture.Content);
        var applicabilityDirectory = new FitzCriterionApplicabilityDirectoryV1(new InMemoryKvClient(), fixture.Content);
        IProjectionStore directory = applicability ? applicabilityDirectory : mappingDirectory;
        Func<DomainEvent, CancellationToken, ValueTask> apply = applicability
            ? applicabilityDirectory.ApplyAsync : mappingDirectory.ApplyAsync;
        var name = applicability ? FitzCriterionApplicabilityDirectoryV1.ProjectorName : FitzControlMappingDirectoryV1.ProjectorName;
        var identity = new CheckpointIdentity(name, EventStreamPattern.ForPattern(fixture.Tenant.ToString(), seeded.Owner.Stream.Area));
        Exception? failure;

        // Act
        await using (var batch = await directory.BeginAsync(new ProjectionBatchContext(identity, ProjectionCheckpoint.Start)))
        {
            await apply(seeded.Facts[0], CancellationToken.None);
            failure = await Record.ExceptionAsync(async () => await apply(malformed, CancellationToken.None));
        }
        var checkpoint = applicability ? await applicabilityDirectory.LoadCheckpointAsync(fixture.Tenant)
            : await mappingDirectory.LoadCheckpointAsync(fixture.Tenant);
        var rows = applicability ? (await applicabilityDirectory.ListProgramAsync(fixture.Tenant, fixture.Program, 10, null)).Items.Count
            : (await mappingDirectory.ListProgramAsync(fixture.Tenant, fixture.Program, 10, null)).Items.Count;

        // Assert
        Assert.NotEqual(review.Content, reference);
        Assert.IsType<ImmutableContentIntegrityException>(failure);
        Assert.Equal(ProjectionCheckpoint.Start, checkpoint);
        Assert.Equal(0, rows);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldRejectCurrentAuthoritySubstitutionGivenQualifiedImmutableMutationReference(bool applicability)
    {
        // Arrange
        await using var fixture = new NativeFixture();
        var seeded = await fixture.SeedAsync(applicability, "accept");
        var original = (IMappingLineFact)seeded.Facts[1];
        var body = await NativeContent.ReadAsync<MappingLineMutation>(fixture.Content, fixture.Tenant, original.Content);
        var reference = await NativeContent.WriteAsync(fixture.Content, fixture.Tenant, MappingLineContent.Schema,
            body with { Current = MappingLineContent.Json(new UnitResult()) });
        var modified = seeded.Facts.Select(fact => fact switch
        {
            ControlCriterionMappingReviewed value => value with { Content = reference },
            CriterionApplicabilityReviewed value => value with { Content = reference },
            _ => fact,
        }).ToArray();
        var events = new InMemoryEventStore();
        await events.AppendAsync(seeded.Owner.Stream, 0, modified);

        // Act
        var failure = await Record.ExceptionAsync(async () =>
        {
            if (applicability)
                await new ApplicabilityReader(fixture.Reader, events, fixture.Content).ReadProgramAsync(fixture.Tenant, fixture.Program);
            else
                await new ControlMappingReader(fixture.Reader, events, fixture.Content).ReadProgramAsync(fixture.Tenant, fixture.Program);
        });

        // Assert
        Assert.NotEqual(original.Content, reference);
        Assert.IsType<ImmutableContentIntegrityException>(failure);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldReplayOriginalRegistrationWithoutCurrentMutationReadGivenAcceptedProposal(bool applicability)
    {
        // Arrange
        FaultingContent? content = null;
        var fixture = await ControlCriterionMappingHandlerTests.Fixture.CreateAsync(services =>
        {
            var original = (IImmutableContentStore)services.Last(item => item.ServiceType == typeof(IImmutableContentStore)).ImplementationInstance!;
            content = new FaultingContent(original);
            services.AddSingleton<IImmutableContentStore>(content);
        });
        await using var provider = fixture.Provider;
        var mapping = fixture.Propose("CC6.1");
        var decision = new ProposeCriterionNotApplicable(Uuid.CreateVersion4(), fixture.TenantId, fixture.ProgramId,
            mapping.EditionId, "CC6.2", 0, "Outside the selected environment.");
        object originalResponse;
        if (applicability)
        {
            originalResponse = (await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.AuthorUserId, decision)).Value;
            await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.ReviewerUserId,
                fixture.ReviewApplicability(decision.DecisionId, 1, "reject"));
        }
        else
        {
            originalResponse = await fixture.ProposeAsync(mapping);
            await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.ReviewerUserId,
                fixture.Review(mapping.MappingId, 1, "reject"));
        }
        content!.Fail = true;

        // Act
        object replay;
        Result changed;
        if (applicability)
        {
            replay = (await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.AuthorUserId, decision)).Value;
            changed = await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.AuthorUserId,
                decision with { Rationale = "Changed intent." }, RequestErrorKind.Conflict);
        }
        else
        {
            replay = await fixture.ProposeAsync(mapping);
            var result = await fixture.Scenario(fixture.AuthorUserId).When(mapping with { Rationale = "Changed intent." })
                .ExpectFailure(RequestErrorKind.Conflict);
            changed = Result.Failure(result.Error!);
        }

        // Assert
        Assert.Equal(originalResponse, replay);
        Assert.False(changed.IsSuccess);
        Assert.Equal(0, content.BlockedReads);
        Assert.Equal(2, await NativeFacts.CountAsync(provider, fixture.TenantId,
            applicability ? CriterionApplicability.Area : ControlCriterionMapping.Area));
    }

    sealed class FaultingContent(IImmutableContentStore inner) : IImmutableContentStore
    {
        public bool Fail { get; set; }
        public int BlockedReads { get; private set; }
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default) => inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default)
        {
            if (Fail && reference.Schema == MappingLineContent.Schema)
            {
                BlockedReads++;
                throw new ImmutableContentUnavailableException("The selected immutable mutation is unavailable.");
            }
            return inner.ReadVerifiedAsync(realm, reference, ct);
        }
    }

    sealed class NativeFixture : IAsyncDisposable
    {
        readonly ServiceProvider _provider;
        readonly AsyncServiceScope _scope;
        public Uuid Tenant { get; } = Uuid.CreateVersion4();
        public Uuid Program { get; } = Uuid.CreateVersion4();
        public Uuid Control { get; } = Uuid.CreateVersion4();
        public Uuid Edition { get; } = Uuid.CreateVersion4();
        public IImmutableContentStore Content { get; } = new FitzKvImmutableContentStore(new InMemoryKvClient());
        public InMemoryEventStore Events { get; } = new();
        public IServiceProvider Services => _scope.ServiceProvider;
        public IAggregateReader Reader => Services.GetRequiredService<IAggregateReader>();
        public IAggregateExecutor Executor => Services.GetRequiredService<IAggregateExecutor>();
        public NativeFixture()
        {
            var services = new ServiceCollection();
            services.AddSingleton<IEventStore>(Events);
            services.AddSingleton<IDomainEventReader>(Events);
            services.AddPortia();
            var original = services.Last(value => !value.IsKeyedService && value.ServiceType == typeof(IAggregateReader));
            var key = new object();
            services.Remove(original);
            if (original.ImplementationFactory is { } factory)
                services.Add(ServiceDescriptor.DescribeKeyed(typeof(IAggregateReader), key, (provider, _) => factory(provider), original.Lifetime));
            else
                services.Add(ServiceDescriptor.DescribeKeyed(typeof(IAggregateReader), key, original.ImplementationType!, original.Lifetime));
            services.Add(ServiceDescriptor.Describe(typeof(IAggregateReader), provider =>
                new MappingLineAggregateReader(provider.GetRequiredKeyedService<IAggregateReader>(key), Events), original.Lifetime));
            _provider = services.BuildServiceProvider();
            _scope = _provider.CreateAsyncScope();
        }
        public async Task<(Aggregate Owner, DomainEvent[] Facts)> SeedAsync(bool applicability, string outcome)
        {
            var author = Uuid.CreateVersion4();
            var reviewer = Uuid.CreateVersion4();
            var id = Uuid.CreateVersion4();
            Aggregate owner;
            if (applicability)
            {
                var rules = new CriterionApplicabilityRules(Tenant, Program, Edition, "CC6.1");
                Assert.True(rules.Propose(MappingRuleFacts.Root(rules, id, nameof(ProposeCriterionNotApplicable), 0, author),
                    "Outside the environment.", author, ActorReference.ForMember(author, "Author"), NativeFacts.Now).IsSuccess);
                Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(ReviewCriterionApplicability), 1, reviewer),
                    id, outcome, "Independent review.", reviewer, ActorReference.ForMember(reviewer, "Reviewer"), NativeFacts.Now, null).IsSuccess);
                owner = await MappingNativeSeeds.BuildAsync(rules, Content);
            }
            else
            {
                var rules = new ControlCriterionMappingRules(Tenant, Program, Control, Edition, "CC6.1");
                Assert.True(rules.Propose(MappingRuleFacts.Root(rules, id, nameof(ProposeControlCriterionMapping), 0, author),
                    Uuid.CreateVersion4(), "criterion", "Addresses criterion.", "All scoped systems.", author, "Author", NativeFacts.Now).IsSuccess);
                Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(ReviewControlCriterionMapping), 1, reviewer),
                    id, outcome, "Independent review.", reviewer, "Reviewer", NativeFacts.Now, null).IsSuccess);
                owner = await MappingNativeSeeds.BuildAsync(rules, Content);
            }
            var facts = owner is ControlCriterionMapping mapping ? NativeFacts.Raised(mapping) : NativeFacts.Raised((CriterionApplicability)owner);
            await Events.AppendAsync(owner.Stream, 0, facts);
            return (owner, facts);
        }
        public async ValueTask DisposeAsync() { await _scope.DisposeAsync(); await _provider.DisposeAsync(); }
    }
}
''')
# Add optional fixture overrides after actual normal fixture registrations, preserving prior setup.
p=t/'Features/ControlMappings/ControlCriterionMappingHandlerTests.cs';s=p.read_text().replace('public static async Task<Fixture> CreateAsync()', 'public static async Task<Fixture> CreateAsync(Action<IServiceCollection>? configure = null)')
s=s.replace('                services => services.AddSingleton<ICriteriaCatalog>(TestCatalog())','                services =>\n                {\n                    services.AddSingleton<ICriteriaCatalog>(TestCatalog())').replace('                    .AddCoverageProjections());','                    .AddCoverageProjections();\n                    configure?.Invoke(services);\n                });');p.write_text(s)
