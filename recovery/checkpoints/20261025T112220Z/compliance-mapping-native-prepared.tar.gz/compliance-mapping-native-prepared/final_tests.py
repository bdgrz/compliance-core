from pathlib import Path
r=Path('/tmp/compliance-mapping-native-prepared');w=r/'work';b=r/'base';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');p=w/'test/Compliance.Tests/Features/ControlMappings/ControlMappingNativeHistoryTests.cs';s=p.read_text()
needle='''        Assert.Equal(2, await NativeFacts.CountAsync(provider, fixture.TenantId,
            applicability ? CriterionApplicability.Area : ControlCriterionMapping.Area));
'''
addition='''        if (applicability)
        {
            var unavailable = await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.AuthorUserId,
                decision with { DecisionId = Uuid.CreateVersion4(), ExpectedRevision = 2 }, RequestErrorKind.Conflict);
            Assert.True(unavailable.Error!.IsTransient);
        }
        else
        {
            var unavailable = await fixture.Scenario(fixture.AuthorUserId).When(mapping with
                { MappingId = Uuid.CreateVersion4(), ExpectedRevision = 2 }).ExpectFailure(RequestErrorKind.Conflict);
            Assert.True(unavailable.Error!.IsTransient);
        }
        Assert.True(content.BlockedReads > 0);
        Assert.Equal(2, await NativeFacts.CountAsync(provider, fixture.TenantId,
            applicability ? CriterionApplicability.Area : ControlCriterionMapping.Area));
'''
s=s.replace(needle,needle+addition)
pos=s.index('    sealed class FaultingContent')
method='''    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldComposeFirstIdentityAndTerminalStatusGivenLaterRejectedProposal(bool applicability)
    {
        // Arrange
        await using var fixture = new NativeFixture();
        var author = Uuid.CreateVersion4();
        var reviewer = Uuid.CreateVersion4();
        var first = Uuid.CreateVersion4();
        var second = Uuid.CreateVersion4();
        var writer = fixture.Services.GetRequiredService<IAggregateWriter>();

        // Act
        if (applicability)
        {
            var rules = new CriterionApplicabilityRules(fixture.Tenant, fixture.Program, fixture.Edition, "CC6.1");
            Assert.True(rules.Propose(MappingRuleFacts.Root(rules, first, nameof(ProposeCriterionNotApplicable), 0, author),
                "Outside scope.", author, ActorReference.ForMember(author, "Author"), NativeFacts.Now).IsSuccess);
            Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(ReviewCriterionApplicability), 1, reviewer),
                first, "accept", "Independent acceptance.", reviewer, ActorReference.ForMember(reviewer, "Reviewer"), NativeFacts.Now, null).IsSuccess);
            Assert.True(rules.Withdraw(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(WithdrawCriterionNotApplicable), 2, author),
                first, "Now applicable.", ActorReference.ForMember(author, "Author"), NativeFacts.Now).IsSuccess);
            Assert.True(rules.Propose(MappingRuleFacts.Root(rules, second, nameof(ProposeCriterionNotApplicable), 3, author),
                "Another proposal.", author, ActorReference.ForMember(author, "Author"), NativeFacts.Now).IsSuccess);
            Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(ReviewCriterionApplicability), 4, reviewer),
                second, "reject", "Coverage required.", reviewer, ActorReference.ForMember(reviewer, "Reviewer"), NativeFacts.Now, null).IsSuccess);
            await MappingNativeSeeds.AppendAsync(fixture.Reader, writer, fixture.Content, rules);
            var reader = new ApplicabilityReader(fixture.Reader, fixture.Events, fixture.Content);
            var owner = await reader.ReadLineAsync(fixture.Tenant, fixture.Program, fixture.Edition, "CC6.1");
            var history = await reader.ComposeAsync(owner);
            var current = await NativeContent.ReadAsync<MappingLineMutation>(fixture.Content, fixture.Tenant, owner.CurrentContent!);
            var authority = current.Current.Deserialize(ComplianceCoreJsonContext.Default.CriterionApplicabilityView)!;

            // Assert
            Assert.Equal(first, history.View!.DecisionId);
            Assert.Equal("withdrawn", history.View.Status);
            Assert.Equal(["withdrawn", "rejected"], history.View.Versions.Select(static value => value.Status));
            Assert.Equal(5, owner.Revision);
            Assert.Equal(2, owner.Header.VersionCount);
            Assert.True(owner.Header.EverTerminated);
            Assert.Empty(authority.Versions);
            Assert.Null(owner.Header.Pending);
            Assert.Null(owner.Header.Active);
        }
        else
        {
            var rules = new ControlCriterionMappingRules(fixture.Tenant, fixture.Program, fixture.Control, fixture.Edition, "CC6.1");
            Assert.True(rules.Propose(MappingRuleFacts.Root(rules, first, nameof(ProposeControlCriterionMapping), 0, author),
                Uuid.CreateVersion4(), "criterion", "Addresses criterion.", "Scoped systems.", author, "Author", NativeFacts.Now).IsSuccess);
            Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(ReviewControlCriterionMapping), 1, reviewer),
                first, "accept", "Independent acceptance.", reviewer, "Reviewer", NativeFacts.Now, null).IsSuccess);
            Assert.True(rules.Retire(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(RetireControlCriterionMapping), 2, author),
                first, "Replaced.", author, "Author", NativeFacts.Now).IsSuccess);
            Assert.True(rules.Propose(MappingRuleFacts.Root(rules, second, nameof(ProposeControlCriterionMapping), 3, author),
                Uuid.CreateVersion4(), "criterion", "Another proposal.", "Scoped systems.", author, "Author", NativeFacts.Now).IsSuccess);
            Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), nameof(ReviewControlCriterionMapping), 4, reviewer),
                second, "reject", "Coverage required.", reviewer, "Reviewer", NativeFacts.Now, null).IsSuccess);
            await MappingNativeSeeds.AppendAsync(fixture.Reader, writer, fixture.Content, rules);
            var reader = new ControlMappingReader(fixture.Reader, fixture.Events, fixture.Content);
            var owner = await reader.ReadLineAsync(fixture.Tenant, fixture.Program, fixture.Control, fixture.Edition, "CC6.1");
            var history = await reader.ComposeAsync(owner);
            var current = await NativeContent.ReadAsync<MappingLineMutation>(fixture.Content, fixture.Tenant, owner.CurrentContent!);
            var authority = current.Current.Deserialize(ComplianceCoreJsonContext.Default.ControlCriterionMappingView)!;

            // Assert
            Assert.Equal(first, history.View!.MappingId);
            Assert.Equal("retired", history.View.Status);
            Assert.Equal(["retired", "rejected"], history.View.Versions.Select(static value => value.Status));
            Assert.Equal(5, owner.Revision);
            Assert.Equal(2, owner.Header.VersionCount);
            Assert.True(owner.Header.EverTerminated);
            Assert.Empty(authority.Versions);
            Assert.Null(owner.Header.Pending);
            Assert.Null(owner.Header.Active);
        }
    }

'''
s=s[:pos]+method+s[pos:];p.write_text(s)
# Update only the actual two owning inventory rows; generated command coverage stays parent-owned.
path='docs/product/aggregate-boundary-ledger.md';(b/path).parent.mkdir(parents=True,exist_ok=True);(b/path).write_bytes((repo/path).read_bytes());(w/path).parent.mkdir(parents=True,exist_ok=True);s=(b/path).read_text()
s=s.replace('state: versions (proposal id, status), revision, ordered facts; limits: `MaximumTextLength=4000`; payload bytes: bounded inline text','state: bounded current header (first proposal, count, pending/active identities, terminal flag), immutable current mutation ref, selected native acceptance; history: explicit verified transient reader/rules composition; limits: `MaximumTextLength=4000`; payload bytes: v3 native refs with complete immutable authored/change/current content')
s=s.replace('state: versions (decision id, status), revision, ordered facts; limits: `MaximumTextLength=4000`; payload bytes: bounded inline text','state: bounded current header (first decision, count, pending/active identities, terminal flag), immutable current mutation ref, selected native acceptance; history: explicit verified transient reader/rules composition; limits: `MaximumTextLength=4000`; payload bytes: v3 native refs with complete immutable authored/change/current content')
(w/path).write_text(s)
