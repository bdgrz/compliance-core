exec(open('/tmp/compliance-mapping-native-prepared/implement.py').read().split('# Retain old full')[0])
T='test/Compliance.Tests/';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def baseline(path):
 if not (B/path).exists():(B/path).parent.mkdir(parents=True,exist_ok=True);(B/path).write_bytes((repo/path).read_bytes())
 if not (W/path).exists():(W/path).parent.mkdir(parents=True,exist_ok=True);(W/path).write_bytes((B/path).read_bytes())
p=W/(T+'Testing/MappingNativeSeeds.cs');s=p.read_text().replace('new ImmutableFirstResponseStore(content).FreezeAsync(history.TenantId.ToString(), response, CancellationToken.None)','FirstResponses.FreezeAsync(content, history.TenantId.ToString(), response, CancellationToken.None)')
# source fixture needs a genuine native history with real immutable bodies, preserving original payload dates.
pos=s.index('    public static (object Change, JsonElement Authored) Rebind')
method='''    public static async Task<DomainEvent[]> RaisedAsync(ControlCriterionMappingRules history, IImmutableContentStore content)
    {
        var owner = new ControlCriterionMapping(history.TenantId, history.ProgramId, history.ControlId, history.EditionId, history.CriterionIdentifier);
        var rules = new ControlCriterionMappingRules(history.TenantId, history.ProgramId, history.ControlId, history.EditionId, history.CriterionIdentifier);
        foreach (var original in history.Facts)
        {
            var rebound = Rebind(original);
            rules.Apply(rebound.Change);
            var (response, result) = rebound.Change is ControlCriterionMappingProposedChange proposed
                ? await NativeContent.FreezeAsync(content, history.TenantId, ControlCriterionMapping.RegistrationSchema,
                    new ControlCriterionMappingRegistration(proposed.MappingId, proposed.Revision, proposed.VersionNumber))
                : await NativeContent.FreezeUnitAsync(content, history.TenantId);
            var prepared = await MappingLineContent.PrepareJsonAsync(content, owner, rebound.Authored, rebound.Change,
                MappingLineContent.Current(rules), MappingLineContent.Header(rules), result, CancellationToken.None);
            var first = await FirstResponses.FreezeAsync(content, history.TenantId.ToString(), response, CancellationToken.None);
            Assert.True(owner.Apply(prepared, first).IsSuccess);
        }
        return NativeFacts.Raised(owner);
    }

'''
s=s[:pos]+method+s[pos:];p.write_text(s)
p=W/(T+'Testing/MappingSeeds.cs');s=(B/(T+'Testing/MappingSeeds.cs')).read_text().replace('new ControlCriterionMapping(', 'new ControlCriterionMappingRules(').replace('new CriterionApplicability(', 'new CriterionApplicabilityRules(').replace('NativeFacts.Root(line,','MappingRuleFacts.Root(line,')
import re
s=re.sub(r',\s*NativeFacts.Ref\(\),\s*NativeFacts.Ref\(\)', '',s);p.write_text(s)
path=T+'Testing/ProgramManagementServices.cs';baseline(path);p=W/path;s=p.read_text();pos=s.index('    public static async Task SeedAsync<TAggregate>')
methods=''
for owner,reader,args in [('ControlCriterionMapping','ControlMappingReader','selected.TenantId, selected.ProgramId, selected.ControlId, selected.EditionId, selected.CriterionIdentifier'),('CriterionApplicability','ApplicabilityReader','selected.TenantId, selected.ProgramId, selected.EditionId, selected.CriterionIdentifier')]:
 methods+='''    public static async Task SeedAsync(IServiceProvider provider, OWNERParts selected,
        Func<OWNERParts, Result> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<READER>();
        var owner = await reader.ReadLineAsync(ARGS);
        var rules = await reader.ComposeAsync(owner);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await MappingNativeSeeds.AppendAsync(services.GetRequiredService<IAggregateReader>(),
            services.GetRequiredService<IAggregateWriter>(), services.GetRequiredService<IImmutableContentStore>(), rules);
    }

'''.replace('OWNERParts',owner+'Rules').replace('READER',reader).replace('ARGS',args)
s=s[:pos]+methods+s[pos:];p.write_text(s)
# Preserve native source receipt tests and exact as-of semantics, seeding immutable content instead of inline payloads.
path=T+'Features/Examinations/ControlCriterionMappingTypeIBaselineSourceContributorTests.cs';p=W/path;s=(B/path).read_text();s=s.replace('using Bdgrz.Compliance.Features.SourceFacts;','using Bdgrz.Compliance.Features.SourceFacts;\nusing Bdgrz.Compliance.Features.Content;\nusing Cntryl.Fitz.Testing;')
s=s.replace('var line = new ControlCriterionMapping(', 'var line = new ControlCriterionMappingRules(').replace('NativeFacts.Root(line,','MappingRuleFacts.Root(line,')
s=re.sub(r',\s*NativeFacts.Ref\(\),\s*NativeFacts.Ref\(\)', '',s)
s=s.replace('var events = new InMemoryEventStore();\n        await events.AppendAsync(line.Stream, 0, NativeFacts.Raised(line));\n        var mappingReader = new ControlMappingReader(new UnusedAggregateReader(), events);', 'var events = new InMemoryEventStore();\n        var content = new FitzKvImmutableContentStore(new InMemoryKvClient());\n        await events.AppendAsync(line.Stream, 0, await MappingNativeSeeds.RaisedAsync(line, content));\n        var mappingReader = new ControlMappingReader(new UnusedAggregateReader(), events, content);')
p.write_text(s)
# Existing count acceptance uses real owner logical revision, not an owner-side lifetime Facts list.
for fn in ['ControlCriterionMappingProtocolTests.cs','CriterionApplicabilityProtocolTests.cs']:
 p=W/(T+'Features/ControlMappings/'+fn);s=(B/(T+'Features/ControlMappings/'+fn)).read_text().replace('Task<int> FactsAsync','Task<long> FactsAsync').replace('.Facts.Count','.Revision');p.write_text(s)
# Projection content dependency supplied by the same provider that published the facts.
p=W/(T+'Testing/CoverageProjections.cs');s=(B/(T+'Testing/CoverageProjections.cs')).read_text().replace('using Bdgrz.Compliance.Features.ControlMappings;','using Bdgrz.Compliance.Features.ControlMappings;\nusing Bdgrz.Compliance.Features.Content;').replace('services.AddSingleton(new FitzControlMappingDirectoryV1(kv));','services.AddSingleton(provider => new FitzControlMappingDirectoryV1(kv, provider.GetRequiredService<IImmutableContentStore>()));').replace('services.AddSingleton(new FitzCriterionApplicabilityDirectoryV1(kv));','services.AddSingleton(provider => new FitzCriterionApplicabilityDirectoryV1(kv, provider.GetRequiredService<IImmutableContentStore>()));');p.write_text(s)
# Owner-qualified work identity regression uses full native content and exact tuple owners.
path=T+'Features/Work/OwnerScopedProjectionIdentityTests.cs';p=W/path;s=(B/path).read_text().replace('new ControlMappingReader(source.Reader, source.Events)','new ControlMappingReader(source.Reader, source.Events, source.Content)').replace('new ApplicabilityReader(source.Reader, source.Events)','new ApplicabilityReader(source.Reader, source.Events, source.Content)')
a=s.index('        public async Task<ControlCriterionMapping> ProposeMappingAsync');b=s.index('        public async Task<IReadOnlyList<DomainEvent>> FactsAsync',a)
s=s[:a]+'''        public async Task<ControlCriterionMapping> ProposeMappingAsync(Uuid tenant, Uuid program, Uuid control,
            Uuid edition, string criterion, Uuid id)
        {
            var rules = new ControlCriterionMappingRules(tenant, program, control, edition, criterion);
            var member = Uuid.CreateVersion4();
            Assert.True(rules.Propose(MappingRuleFacts.Root(rules, id, "ProposeControlCriterionMapping", 0, member),
                Uuid.CreateVersion4(), "security", "Addresses criterion", "Applies to the environment", member, "Proposer", Now).IsSuccess);
            await MappingNativeSeeds.AppendAsync(Reader, Writer, Content, rules);
            return await Reader.HydrateAsync(new ControlCriterionMapping(tenant, program, control, edition, criterion));
        }

        public async Task<DomainEvent> ReviewMappingAsync(ControlCriterionMapping owner, Uuid id)
        {
            var rules = await new ControlMappingReader(Reader, Events, Content).ComposeAsync(owner);
            var member = Uuid.CreateVersion4();
            Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), "ReviewControlCriterionMapping", 1, member),
                id, "accept", "Independent review", member, "Reviewer", Now.AddMinutes(1), null).IsSuccess);
            await MappingNativeSeeds.AppendAsync(Reader, Writer, Content, rules);
            return (await FactsAsync(rules.TenantId, ControlCriterionMapping.Area)).OfType<ControlCriterionMappingReviewed>().Single();
        }

        public async Task<CriterionApplicability> ProposeApplicabilityAsync(Uuid tenant, Uuid program,
            Uuid edition, string criterion, Uuid id)
        {
            var rules = new CriterionApplicabilityRules(tenant, program, edition, criterion);
            var member = Uuid.CreateVersion4();
            Assert.True(rules.Propose(MappingRuleFacts.Root(rules, id, "ProposeCriterionNotApplicable", 0, member),
                "Outside scope", member, ActorReference.ForMember(member, "Proposer"), Now).IsSuccess);
            await MappingNativeSeeds.AppendAsync(Reader, Writer, Content, rules);
            return await Reader.HydrateAsync(new CriterionApplicability(tenant, program, edition, criterion));
        }

        public async Task<DomainEvent> ReviewApplicabilityAsync(CriterionApplicability owner, Uuid id)
        {
            var rules = await new ApplicabilityReader(Reader, Events, Content).ComposeAsync(owner);
            var member = Uuid.CreateVersion4();
            Assert.True(rules.Review(MappingRuleFacts.Root(rules, Uuid.CreateVersion4(), "ReviewCriterionApplicability", 1, member),
                id, "accept", "Independent review", member, ActorReference.ForMember(member, "Reviewer"), Now.AddMinutes(1), null).IsSuccess);
            await MappingNativeSeeds.AppendAsync(Reader, Writer, Content, rules);
            return (await FactsAsync(rules.TenantId, CriterionApplicability.Area)).OfType<CriterionApplicabilityReviewed>().Single();
        }

'''+s[b:];p.write_text(s)
