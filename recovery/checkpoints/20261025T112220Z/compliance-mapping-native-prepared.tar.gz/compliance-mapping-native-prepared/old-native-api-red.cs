using System.Collections;
using System.Reflection;
using System.Text.Json;
using Bdgrz.Compliance.Features.ControlMappings;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.ControlMappings;

public sealed class ControlMappingNativeBoundaryTests
{
    [Fact]
    public void ShouldRetainOnlyCurrentAuthorityGivenManyMappingAndApplicabilityReviews()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var control = Uuid.CreateVersion4();
        var edition = Uuid.CreateVersion4();
        var author = Uuid.CreateVersion4();
        var reviewer = Uuid.CreateVersion4();
        var mapping = new ControlCriterionMapping(tenant, program, control, edition, "CC6.1");
        var applicability = new CriterionApplicability(tenant, program, edition, "CC6.1");

        // Act
        for (var index = 0; index < 105; index++)
        {
            var proposal = Uuid.CreateVersion4();
            Assert.True(mapping.Propose(NativeFacts.Root(mapping, proposal, nameof(ProposeControlCriterionMapping),
                mapping.Revision, author), Uuid.CreateVersion4(), "criterion", "Exact reason " + index,
                "All scoped systems", author, "Author", NativeFacts.Now, NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
            Assert.True(mapping.Review(NativeFacts.Root(mapping, Uuid.CreateVersion4(), nameof(ReviewControlCriterionMapping),
                mapping.Revision, reviewer), proposal, "reject", "Reconsider the mapping.", reviewer, "Reviewer",
                NativeFacts.Now, null, NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
            var decision = Uuid.CreateVersion4();
            Assert.True(applicability.Propose(NativeFacts.Root(applicability, decision, nameof(ProposeCriterionNotApplicable),
                applicability.Revision, author), "Not applicable " + index, author,
                Bdgrz.Compliance.Features.AccessControl.ActorReference.ForMember(author, "Author"), NativeFacts.Now,
                NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
            Assert.True(applicability.Review(NativeFacts.Root(applicability, Uuid.CreateVersion4(), nameof(ReviewCriterionApplicability),
                applicability.Revision, reviewer), decision, "reject", "Coverage remains required.", reviewer,
                Bdgrz.Compliance.Features.AccessControl.ActorReference.ForMember(reviewer, "Reviewer"), NativeFacts.Now,
                null, NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
        }
        var retained = new Aggregate[] { mapping, applicability }.SelectMany(owner => owner.GetType()
            .GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(owner) is ICollection { Count: > 2 })).ToArray();

        // Assert
        Assert.Equal(210, mapping.Revision);
        Assert.Equal(210, applicability.Revision);
        Assert.Empty(retained);
    }

    [Fact]
    public void ShouldBoundNativeFactGivenMaximumValidEscapedMappingTexts()
    {
        // Arrange
        var mapping = new ControlCriterionMapping(Uuid.CreateVersion4(), Uuid.CreateVersion4(), Uuid.CreateVersion4(),
            Uuid.CreateVersion4(), "CC6.1");
        var id = Uuid.CreateVersion4();
        var actor = Uuid.CreateVersion4();
        var text = new string('界', ControlCriterionMapping.MaximumTextLength);

        // Act
        var outcome = mapping.Propose(NativeFacts.Root(mapping, id, nameof(ProposeControlCriterionMapping), 0, actor),
            Uuid.CreateVersion4(), "criterion", text, text, actor, "Author", NativeFacts.Now,
            NativeFacts.Ref(), NativeFacts.Ref());
        var fact = Assert.Single(new AggregateScenario<ControlCriterionMapping>(mapping).PendingEvents);
        var bytes = JsonSerializer.SerializeToUtf8Bytes(fact, ComplianceCoreJsonContext.Default.GetTypeInfo(fact.GetType())!);

        // Assert
        Assert.True(outcome.IsSuccess, outcome.Error?.Message);
        Assert.True(bytes.Length <= 48 * 1024, $"The complete valid mapping produced a {bytes.Length}-byte native payload.");
    }
}
