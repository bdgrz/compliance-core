from pathlib import Path
import re
from tree_sitter import Parser,Language
import tree_sitter_c_sharp
r=Path('/tmp/compliance-mapping-native-prepared');W=r/'work';B=r/'base';parser=Parser(Language(tree_sitter_c_sharp.language()))
names=['ControlCriterionMappingProposed','ControlCriterionMappingReviewed','ControlCriterionMappingRetired','CriterionNotApplicableProposed','CriterionApplicabilityReviewed','CriterionNotApplicableWithdrawn']
params={n:[x.strip().split()[-1] for x in re.search(r'public sealed record '+n+r'\((.*?)\)\s*:',(B/('src/Compliance.Common/Features/ControlMappings/'+n+'.cs')).read_text(),re.S).group(1).split(',')] for n in names}
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
for fn in ['FitzControlMappingWorkItemDirectoryTests.cs','FitzCriterionApplicabilityWorkItemDirectoryTests.cs']:
 p=W/('test/Compliance.Tests/Features/Work/'+fn);text=p.read_bytes();edits=[]
 for node in walk(parser.parse(text).root_node):
  if node.type not in ['object_creation_expression','implicit_object_creation_expression']:continue
  typ=node.child_by_field_name('type')
  if typ:name=text[typ.start_byte:typ.end_byte].decode()
  else:
   par=node.parent
   while par and par.type!='method_declaration':par=par.parent
   if not par:continue
   typ=par.child_by_field_name('returns');name=text[typ.start_byte:typ.end_byte].decode() if typ else ''
  if name not in names:continue
  al=next((c for c in node.children if c.type=='argument_list'),None)
  args=[text[c.start_byte:c.end_byte].decode() for c in al.children if c.type=='argument']
  if len(args)!=len(params[name]):continue
  values=dict(zip(params[name],args));prop='MappingId' if name.startswith('Control') else 'DecisionId'
  actor=values.get('ActorMemberId',values.get('ProposerMemberId','Uuid.Parse('+values.get('Actor','reviewer')+'.Id)'))
  slot='new MappingLineSlot('+values[prop]+', '+values['VersionNumber']+', '+actor+')'
  proposal=name.endswith('Proposed');review=name.endswith('Reviewed');terminate=not(proposal or review)
  pending=slot if proposal else 'null';active='('+values['Outcome']+' == "accept" ? '+slot+' : null)' if review else 'null'
  header='new MappingLineHeader('+values['Revision']+', '+values['VersionNumber']+', '+values[prop]+', '+pending+', '+active+', '+str(terminate).lower()+')'
  result=[]
  for f,a in zip(params[name],args):
   if f in ['Rationale','ApplicabilityExplanation']:continue
   if f=='Operation':result+=['NativeFacts.Ref(MappingLineContent.Schema)',header]
   result.append(a)
  edits.append((al.start_byte,al.end_byte,'('+', '.join(result)+')'))
 for a,b,s in sorted(edits,reverse=True):text=text[:a]+s.encode()+text[b:]
 p.write_bytes(text)
 print(fn,len(edits))
