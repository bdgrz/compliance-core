from pathlib import Path
r=Path('/tmp/compliance-mapping-native-prepared');w=r/'work';b=r/'base';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');c=w/'src/Compliance.Core/Features/ControlMappings';t=w/'test/Compliance.Tests'
# Root's finalized SourceUse fixture helper is the new exact baseline. Add a separately keyed outer mapping layer.
p=t/'Testing/ProgramManagementServices.cs';old=p.read_text();a=old.index('    public static async Task SeedAsync(IServiceProvider provider, ControlCriterionMappingRules');z=old.index('    public static async Task SeedAsync<TAggregate>',a);methods=old[a:z]
new=(repo/'test/Compliance.Tests/Testing/ProgramManagementServices.cs').read_text();(b/'test/Compliance.Tests/Testing/ProgramManagementServices.cs').write_text(new)
new=new.replace('        collection.AddVerifiedSourceUseReader();','        collection.AddVerifiedSourceUseReader();\n        collection.AddVerifiedMappingLineReader();');pos=new.index('    public static async Task SeedAsync<TAggregate>');p.write_text(new[:pos]+methods+new[pos:])
helper=(repo/'test/Compliance.Tests/Testing/VerifiedSourceUseServices.cs').read_text().replace('Bdgrz.Compliance.Features.SourceUse','Bdgrz.Compliance.Features.ControlMappings').replace('VerifiedSourceUseServices','VerifiedMappingLineServices').replace('AddVerifiedSourceUseReader','AddVerifiedMappingLineReader').replace('SourceUseAggregateReader','MappingLineAggregateReader')
(t/'Testing/VerifiedMappingLineServices.cs').write_text(helper)
# Remove the final transport-only guard from pure changes.
p=c/'ControlCriterionMappingRules.cs';p.write_text(p.read_text().replace('ev.Operation.Owner != Stream ||\n            ev.FirstResponse is null','ev.Operation.Owner != Stream'))
# Selected corruption is a typed integrity failure, before NativeAcceptance's generic duplicate diagnostic.
for name in ['ControlCriterionMapping','CriterionApplicability']:
 p=c/(name+'.cs');s=p.read_text().replace('        Acceptance.Observe(fact);','        if (Acceptance.SelectedFact is not null &&\n            Acceptance.SelectedLogicalId == ((IMappingLineFact)fact).Operation.LogicalId)\n            throw new ImmutableContentIntegrityException("The selected native operation occurs more than once on its line.");\n        Acceptance.Observe(fact);');p.write_text(s)
p=c/'MappingLineTransitions.cs';s=p.read_text().replace('native.Content.MediaType != "application/json" || native.Content.Bytes <= 0)', 'native.Content.MediaType != "application/json" || native.Content.Bytes <= 0 ||\n            native.Content.ContentId == Uuid.Empty || native.Content.Sha256.Length != 64 || !native.Content.Sha256.All(Uri.IsHexDigit))')
s=s.replace('ev.ProgramId == Uuid.Empty ||','ev.TenantId == Uuid.Empty || ev.ProgramId == Uuid.Empty ||\n                    ev.EditionId == Uuid.Empty || string.IsNullOrWhiteSpace(ev.CriterionIdentifier) ||')
# Mapping proposal also binds nonempty exact control version; all mapping frame scopes bind the control.
s=s.replace('owner is not ControlCriterionMapping ||','owner is not ControlCriterionMapping || ev.ControlId == Uuid.Empty ||')
s=s.replace('if (before.Pending is not null || ev.VersionNumber != before.VersionCount + 1 ||','if (ev.ControlVersionId == Uuid.Empty || string.IsNullOrWhiteSpace(ev.CriterionKind) ||\n                    before.Pending is not null || ev.VersionNumber != before.VersionCount + 1 ||',1)
p.write_text(s)
# Area composition cannot hide a fact whose payload program/tuple differs from its actual stream.
for file in ['ControlMappingReader.cs','ApplicabilityReader.cs']:
 p=c/file;s=p.read_text();s=s.replace('            if (record.Event.Metadata.IsAudit || !IsProgramFact(record.Event, programId))','            if (!record.Event.Metadata.IsAudit && record.Event is IMappingLineFact)\n            {\n                var sourceOwner = MappingLineContent.Owner(record.Event);\n                if (record.Stream != sourceOwner.Stream || record.Event.Metadata.AggregateId != sourceOwner.Id)\n                    throw new ImmutableContentIntegrityException("A native area fact has another actual line identity.");\n            }\n            if (record.Event.Metadata.IsAudit || !IsProgramFact(record.Event, programId))')
 p.write_text(s)
# Correct generic proposal failure assertions without reading a failed Result.Value.
p=t/'Features/ControlMappings/ControlMappingNativeHistoryTests.cs';s=p.read_text();s=s.replace('            changed = await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.AuthorUserId,\n                decision with { Rationale = "Changed intent." }, RequestErrorKind.Conflict);','            var changedDecision = await PersonalMappingDecisionTransportTests.HttpAsync(provider, fixture.AuthorUserId,\n                decision with { Rationale = "Changed intent." }, RequestErrorKind.Conflict);\n            changed = Result.Failure(changedDecision.Error!);');p.write_text(s)
