exec(open('/tmp/compliance-mapping-native-prepared/implement.py').read().split('# Retain old full')[0])
items=[
('ProposeControlCriterionMapping','ControlCriterionMapping','mappings','new ControlCriterionMapping(request.TenantId, request.ProgramId, request.ControlId, request.EditionId, request.CriterionIdentifier, request.MappingId)','rules.Propose(provenance, request.ControlVersionId, criterionKind, request.Rationale, request.ApplicabilityExplanation, actor.MemberId, actor.Display, now)','ControlCriterionMappingRegistration'),
('ReviewControlCriterionMapping','ControlCriterionMapping','mappings','new ControlCriterionMapping(request.TenantId, request.ProgramId, tuple.ControlId, tuple.EditionId, tuple.CriterionIdentifier, request.CommandId)','rules.Review(provenance, request.MappingId, request.Outcome, request.Rationale, actor.MemberId, actor.Display, now, waiver)',None),
('RetireControlCriterionMapping','ControlCriterionMapping','mappings','new ControlCriterionMapping(request.TenantId, request.ProgramId, tuple.ControlId, tuple.EditionId, tuple.CriterionIdentifier, request.CommandId)','rules.Retire(provenance, request.MappingId, request.Rationale, actor.MemberId, actor.Display, now)',None),
('ProposeCriterionNotApplicable','CriterionApplicability','applicability','new CriterionApplicability(request.TenantId, request.ProgramId, request.EditionId, request.CriterionIdentifier, request.DecisionId)','rules.Propose(provenance, request.Rationale, actor.MemberId, member, now)','CriterionApplicabilityRegistration'),
('ReviewCriterionApplicability','CriterionApplicability','applicability','new CriterionApplicability(request.TenantId, request.ProgramId, criterion.EditionId, criterion.CriterionIdentifier, request.CommandId)','rules.Review(provenance, request.DecisionId, request.Outcome, request.Rationale, actor.MemberId, member, now, waiver)',None),
('WithdrawCriterionNotApplicable','CriterionApplicability','applicability','new CriterionApplicability(request.TenantId, request.ProgramId, criterion.EditionId, criterion.CriterionIdentifier, request.CommandId)','rules.Withdraw(provenance, request.DecisionId, request.Rationale, member, now)',None)]
for cmd,owner,reads,factory,apply,ret in items:
 s=(B/(C+cmd+'Handler.cs')).read_text()
 start=s.index('        SeparationOfDutiesWaiver? waiver') if cmd.startswith('Review') else s.index('        FirstResponseDescriptor? response')
 b=s.index('        if (line.Acceptance.Decide(binding)');end=s.index('\n        var outcome',b)
 block=s[b:end];block=block[block.index('{')+1:block.rfind('}')]
 # guard block now asynchronous native Prepare, all source/body freezes remain inside acceptance boundary.
 block=block.replace('line.View','rules.View').replace('line.Prepare','rules.Prepare').replace('ct)', 'token)')
 block=block.replace('var prepared =','var guard =').replace('!prepared.IsSuccess','!guard.IsSuccess').replace('prepared.Error','guard.Error').replace('return prepared;','return Result<FirstResponseDescriptor>.Failure(guard.Error!);')
 block=block.replace('Result<'+str(ret)+'>.Failure','Result<FirstResponseDescriptor>.Failure') if ret else block
 block=block.replace('return Result.Failure(', 'return Result<FirstResponseDescriptor>.Failure(')
 block=block.replace('return Failure(', 'return Result<FirstResponseDescriptor>.Failure(new RequestError(')
 # repair extraclosing for Failure calls simple twoline message: ends string);
 if 'return Result<FirstResponseDescriptor>.Failure(new RequestError(' in block:
  import re
  block=re.sub(r'(return Result<FirstResponseDescriptor>\.Failure\(new RequestError\(.*?"\))\s*;',r'\1);',block,flags=re.S)
 # non-success generic control source.
 block=block.replace('Result<ControlCriterionMappingRegistration>.Failure','Result<FirstResponseDescriptor>.Failure').replace('Result<CriterionApplicabilityRegistration>.Failure','Result<FirstResponseDescriptor>.Failure')
 declarations='                FirstResponseDescriptor? response = null;\n                ImmutableContentRef? result = null;\n'
 if cmd.startswith('Review'): declarations+='                SeparationOfDutiesWaiver? waiver = null;\n'
 if cmd=='ProposeControlCriterionMapping':declarations+='                var criterionKind = string.Empty;\n'
 # block indentation already12spaces, lambdainside16 desired
 block='\n'.join('    '+l if l.strip() else '' for l in block.strip('\n').splitlines())
 ending='''        MappingLinePrepared? prepared = null;
        var outcome = await operations.ExecuteAsync(new NativeOperation<OWNER>(binding,
            () => FACTORY, owner => owner.Acceptance,
            async (owner, token) =>
            {
                var rules = await READS.ComposeAsync(owner, token).ConfigureAwait(false);
DECLARATIONS
BLOCK
                var applied = APPLY;
                if (!applied.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(applied.Error!);
                prepared = await MappingLineContent.PrepareAsync(content, owner, request, rules.Facts[^1],
                    MappingLineContent.Current(rules), MappingLineContent.Header(rules), result!, token).ConfigureAwait(false);
                return Result<FirstResponseDescriptor>.Success(response!);
            }, (owner, frozen) => owner.Apply(prepared ?? throw new InvalidOperationException("The native line was not prepared."), frozen)),
            context, ct).ConfigureAwait(false);
RETURN
    }
'''.replace('OWNER',owner).replace('FACTORY',factory).replace('READS',reads).replace('DECLARATIONS',declarations.rstrip()).replace('BLOCK',block).replace('APPLY',apply)
 ending=ending.replace('RETURN', '        return await NativeContent.ResponseAsync<'+ret+'>(content, request.TenantId, outcome, ct).ConfigureAwait(false);' if ret else '        return NativeContent.UnitOutcome(outcome);')
 # retain outer initial validation Failure helper only for proposals.
 tail='\n    static Result<'+ret+'> Failure(RequestErrorKind kind, string message) =>\n        Result<'+ret+'>.Failure(new RequestError(kind, message));\n' if ret else ''
 s=s[:start]+ending+tail+'}\n'
 (W/(C+cmd+'Handler.cs')).write_text(s)
