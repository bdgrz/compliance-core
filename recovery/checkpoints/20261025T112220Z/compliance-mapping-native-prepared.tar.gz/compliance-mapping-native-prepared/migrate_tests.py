exec(open('/tmp/compliance-mapping-native-prepared/implement.py').read().split('# Retain old full')[0])
T='test/Compliance.Tests/'
# Pure business regressions now target explicit transient rules; every original acceptance/assertion retained.
for n in ['ControlCriterionMapping','CriterionApplicability']:
 p=W/(T+'Features/ControlMappings/'+n+'Tests.cs');s=(B/(T+'Features/ControlMappings/'+n+'Tests.cs')).read_text()
 s=s.replace(n+' line',n+'Rules line').replace('static '+n+' Line','static '+n+'Rules Line')
 s=s.replace('NativeFacts.Root(line,','MappingRuleFacts.Root(line,').replace('NativeFacts.Raised(', 'MappingRuleFacts.Raised(').replace('NativeFacts.Replay(', 'MappingRuleFacts.Replay(')
 import re
 s=re.sub(r',\s*NativeFacts.Ref\(\),\s*NativeFacts.Ref\(\)', '',s)
 p.write_text(s)
# Rules helper only handles pure values, with a real JSON roundtrip; native fixtures below publish complete stored content.
p=W/(T+'Testing/MappingRuleFacts.cs');p.write_text('''using System.Text.Json;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.ControlMappings;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

static class MappingRuleFacts
{
    public static OperationProvenance Root(ControlCriterionMappingRules rules, Uuid id, string kind, long? revision,
        Uuid? actor = null, DateTimeOffset? at = null) => Root(rules.Stream, id, kind, revision, actor, at);
    public static OperationProvenance Root(CriterionApplicabilityRules rules, Uuid id, string kind, long? revision,
        Uuid? actor = null, DateTimeOffset? at = null) => Root(rules.Stream, id, kind, revision, actor, at);
    static OperationProvenance Root(EventStreamAddress stream, Uuid id, string kind, long? revision, Uuid? actor,
        DateTimeOffset? at) => RootOperation.Provenance(id, kind, stream,
        ActorReference.ForMember(actor ?? Uuid.CreateVersion4(), "Tester"), revision, new string('b', 64), at ?? NativeFacts.Now);

    public static object[] Raised(ControlCriterionMappingRules rules) => RoundTrip(rules.Facts);
    public static object[] Raised(CriterionApplicabilityRules rules) => RoundTrip(rules.Facts);
    static object[] RoundTrip(IReadOnlyList<object> changes) => [.. changes.Select(change =>
        JsonSerializer.Deserialize(JsonSerializer.Serialize(change, change.GetType(), ComplianceCoreJsonContext.Default),
            change.GetType(), ComplianceCoreJsonContext.Default)!)];
    public static ControlCriterionMappingRules Replay(ControlCriterionMappingRules fresh, IEnumerable<object> changes)
    { foreach (var change in changes) fresh.Apply(change); return fresh; }
    public static CriterionApplicabilityRules Replay(CriterionApplicabilityRules fresh, IEnumerable<object> changes)
    { foreach (var change in changes) fresh.Apply(change); return fresh; }
}
''')
# Append helper constructs actual typed authored commands and freezes actual first-response/content bytes.
p=W/(T+'Testing/MappingNativeSeeds.cs');s='''using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.ControlMappings;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

static class MappingNativeSeeds
{
    public static async Task AppendAsync(IAggregateReader reader, IAggregateWriter writer,
        IImmutableContentStore content, ControlCriterionMappingRules history)
    {
        var rules = new ControlCriterionMappingRules(history.TenantId, history.ProgramId, history.ControlId, history.EditionId, history.CriterionIdentifier);
        foreach (var original in history.Facts)
        {
            var owner = await reader.HydrateAsync(new ControlCriterionMapping(history.TenantId, history.ProgramId,
                history.ControlId, history.EditionId, history.CriterionIdentifier));
            var rebound = Rebind(original);
            rules.Apply(rebound.Change);
            if (rules.Revision <= owner.Revision) continue;
            var (response, result) = rebound.Change is ControlCriterionMappingProposedChange proposed
                ? await NativeContent.FreezeAsync(content, history.TenantId, ControlCriterionMapping.RegistrationSchema,
                    new ControlCriterionMappingRegistration(proposed.MappingId, proposed.Revision, proposed.VersionNumber))
                : await NativeContent.FreezeUnitAsync(content, history.TenantId);
            var prepared = await MappingLineContent.PrepareJsonAsync(content, owner, rebound.Authored, rebound.Change,
                MappingLineContent.Current(rules), MappingLineContent.Header(rules), result, CancellationToken.None);
            var first = await new ImmutableFirstResponseStore(content).FreezeAsync(history.TenantId.ToString(), response, CancellationToken.None);
            Assert.True(owner.Apply(prepared, first).IsSuccess);
            await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System));
        }
    }

    public static async Task AppendAsync(IAggregateReader reader, IAggregateWriter writer,
        IImmutableContentStore content, CriterionApplicabilityRules history)
    {
        var rules = new CriterionApplicabilityRules(history.TenantId, history.ProgramId, history.EditionId, history.CriterionIdentifier);
        foreach (var original in history.Facts)
        {
            var owner = await reader.HydrateAsync(new CriterionApplicability(history.TenantId, history.ProgramId,
                history.EditionId, history.CriterionIdentifier));
            var rebound = Rebind(original);
            rules.Apply(rebound.Change);
            if (rules.Revision <= owner.Revision) continue;
            var (response, result) = rebound.Change is CriterionNotApplicableProposedChange proposed
                ? await NativeContent.FreezeAsync(content, history.TenantId, CriterionApplicability.RegistrationSchema,
                    new CriterionApplicabilityRegistration(proposed.DecisionId, proposed.Revision, proposed.VersionNumber))
                : await NativeContent.FreezeUnitAsync(content, history.TenantId);
            var prepared = await MappingLineContent.PrepareJsonAsync(content, owner, rebound.Authored, rebound.Change,
                MappingLineContent.Current(rules), MappingLineContent.Header(rules), result, CancellationToken.None);
            var first = await new ImmutableFirstResponseStore(content).FreezeAsync(history.TenantId.ToString(), response, CancellationToken.None);
            Assert.True(owner.Apply(prepared, first).IsSuccess);
            await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System));
        }
    }

    public static (object Change, JsonElement Authored) Rebind(object original) => original switch
    {
REBIND
        _ => throw new InvalidOperationException("The seed contains another business change."),
    };
HELPERS
}
'''
# Use typed canonical requests, including actual actor and decision time; no fabricated source authority.
rows=[
('ControlCriterionMappingProposed','ProposeControlCriterionMapping','new ProposeControlCriterionMapping(value.MappingId, value.TenantId, value.ProgramId, value.ControlId, value.ControlVersionId, value.EditionId, value.CriterionIdentifier, (long)value.Operation.OriginalExpectedRevision!, value.Rationale, value.ApplicabilityExplanation)','ProposedAt'),
('ControlCriterionMappingReviewed','ReviewControlCriterionMapping','new ReviewControlCriterionMapping(value.DecisionId, value.TenantId, value.ProgramId, value.MappingId, (long)value.Operation.OriginalExpectedRevision!, value.Outcome, value.Rationale, value.SeparationOfDutiesWaiverId)','DecidedAt'),
('ControlCriterionMappingRetired','RetireControlCriterionMapping','new RetireControlCriterionMapping(value.Operation.LogicalId, value.TenantId, value.ProgramId, value.MappingId, (long)value.Operation.OriginalExpectedRevision!, value.Rationale)','RetiredAt'),
('CriterionNotApplicableProposed','ProposeCriterionNotApplicable','new ProposeCriterionNotApplicable(value.DecisionId, value.TenantId, value.ProgramId, value.EditionId, value.CriterionIdentifier, (long)value.Operation.OriginalExpectedRevision!, value.Rationale)','ProposedAt'),
('CriterionApplicabilityReviewed','ReviewCriterionApplicability','new ReviewCriterionApplicability(value.ReviewDecisionId, value.TenantId, value.ProgramId, value.DecisionId, (long)value.Operation.OriginalExpectedRevision!, value.Outcome, value.Rationale, value.SeparationOfDutiesWaiverId)','ReviewedAt'),
('CriterionNotApplicableWithdrawn','WithdrawCriterionNotApplicable','new WithdrawCriterionNotApplicable(value.Operation.LogicalId, value.TenantId, value.ProgramId, value.DecisionId, (long)value.Operation.OriginalExpectedRevision!, value.Rationale)','WithdrawnAt')]
s=s.replace('REBIND','\n'.join('        '+n+'Change value => Bind(value, '+construct+'),' for n,req,construct,tm in rows))
s=s.replace('HELPERS','\n'.join('    static (object, JsonElement) Bind('+n+'Change value, '+req+' request) =>\n        (value with { Operation = value.Operation with { AuthoredIntentSha256 = AuthoredIntentDigest.Compute(request), Actor = value.Actor, AcceptedAt = value.'+tm+' } }, MappingLineContent.Json(request));\n' for n,req,construct,tm in rows))
p.write_text(s)
# Add JSON-prepared overload while keeping handlers typed authored serializer.
p=W/(C+'MappingLineContent.cs');s=p.read_text();start=s.index('        var mutation = new MappingLineMutation(Json(request),');s=s[:start]+s[start:].replace('        var mutation = new MappingLineMutation(Json(request),','        return await PrepareJsonAsync(content, owner, Json(request), change, current, header, result, ct).ConfigureAwait(false);\n    }\n\n    public static async Task<MappingLinePrepared> PrepareJsonAsync(IImmutableContentStore content, Aggregate owner,\n        JsonElement authored, object change, object current, MappingLineHeader header, ImmutableContentRef result,\n        CancellationToken ct)\n    {\n        var mutation = new MappingLineMutation(authored,',1);p.write_text(s)
