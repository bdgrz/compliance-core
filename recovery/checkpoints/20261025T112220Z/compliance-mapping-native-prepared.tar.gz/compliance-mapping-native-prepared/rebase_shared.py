from pathlib import Path
R=Path('/tmp/compliance-mapping-native-prepared');B=R/'base';W=R/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
# Preserve prior baselines for provenance; active exact baselines now include merged/installed SourceUse wrappers.
for path in ['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs']:
 prior=R/'prior-base'/path;prior.parent.mkdir(parents=True,exist_ok=True);prior.write_bytes((B/path).read_bytes())
 oldwork=(W/path).read_text();new=(repo/path).read_text();(B/path).write_text(new)
 if path.startswith('src/'):
  new=new.replace('using Bdgrz.Compliance.Features.Operations;','using Bdgrz.Compliance.Features.Operations;\nusing Bdgrz.Compliance.Features.ControlMappings;')
  pos=new.index('        Decorate<IRequestBus>');new=new[:pos]+'''        Decorate<IAggregateReader>(services, (provider, inner) =>
            new MappingLineAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));
'''+new[pos:]
 else:
  start=oldwork.index('    public static async Task SeedAsync(IServiceProvider provider, ControlCriterionMappingRules')
  end=oldwork.index('    public static async Task SeedAsync<TAggregate>',start)
  methods=oldwork[start:end]
  pos=new.index('    public static async Task SeedAsync<TAggregate>');new=new[:pos]+methods+new[pos:]
  pos=new.index('        return collection.BuildServiceProvider')
  wrapper='''        var mappingReaderRegistration = collection.Last(descriptor => !descriptor.IsKeyedService &&
            descriptor.ServiceType == typeof(IAggregateReader));
        var mappingReaderKey = new object();
        collection.Remove(mappingReaderRegistration);
        if (mappingReaderRegistration.ImplementationInstance is { } mappingReaderInstance)
            collection.Add(ServiceDescriptor.KeyedSingleton(typeof(IAggregateReader), mappingReaderKey, mappingReaderInstance));
        else if (mappingReaderRegistration.ImplementationFactory is { } mappingReaderFactory)
            collection.Add(ServiceDescriptor.DescribeKeyed(typeof(IAggregateReader), mappingReaderKey,
                (provider, _) => mappingReaderFactory(provider), mappingReaderRegistration.Lifetime));
        else
            collection.Add(ServiceDescriptor.DescribeKeyed(typeof(IAggregateReader), mappingReaderKey,
                mappingReaderRegistration.ImplementationType!, mappingReaderRegistration.Lifetime));
        collection.Add(ServiceDescriptor.Describe(typeof(IAggregateReader), provider =>
            new MappingLineAggregateReader(provider.GetRequiredKeyedService<IAggregateReader>(mappingReaderKey),
                provider.GetRequiredService<IDomainEventReader>()), mappingReaderRegistration.Lifetime));
'''
  new=new[:pos]+wrapper+new[pos:]
 (W/path).write_text(new)
# Native facts explicitly carry mutation-result refs in addition to INativeOperationFact response descriptor.
p=W/'src/Compliance.Common/Features/ControlMappings/IMappingLineFact.cs';s=p.read_text().replace('    MappingLineHeader Header { get; }','    MappingLineHeader Header { get; }\n    ImmutableContentRef? OperationResult { get; }');p.write_text(s)
for n in ['ControlCriterionMapping','CriterionApplicability']:
 p=W/('src/Compliance.Core/Features/ControlMappings/'+n+'.cs');s=p.read_text().replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;');p.write_text(s)
# Pure current/rule value declarations no longer need content-reference namespaces.
for p in (W/'src/Compliance.Core/Features/ControlMappings').glob('*Change.cs'):
 p.write_text(p.read_text().replace('using Bdgrz.Compliance.Features.Proofs;\n',''))
for n in ['ControlCriterionMappingRules','CriterionApplicabilityRules']:
 p=W/('src/Compliance.Core/Features/ControlMappings/'+n+'.cs');p.write_text(p.read_text().replace('using Bdgrz.Compliance.Features.Proofs;\n',''))
