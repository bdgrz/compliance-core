exec(open('/tmp/compliance-mapping-native-prepared/implement.py').read().split('# Retain old full')[0])
p=W/(C+'MappingLineContent.cs');s=p.read_text();s=s.replace('Current(ControlCriterionMappingRules rules) => rules.View! with\n    { Versions = [.. rules.View!.Versions.', 'Current(ControlCriterionMappingRules rules) => Current(rules.View!);\n\n    public static ControlCriterionMappingView Current(ControlCriterionMappingView view) => view with\n    { Versions = [.. view.Versions.')
s=s.replace('Current(CriterionApplicabilityRules rules) => rules.View! with\n    { Versions = [.. rules.View!.Versions.', 'Current(CriterionApplicabilityRules rules) => Current(rules.View!);\n\n    public static CriterionApplicabilityView Current(CriterionApplicabilityView view) => view with\n    { Versions = [.. view.Versions.')
s=s.replace('Header(ControlCriterionMappingRules rules)\n    {\n        var view = rules.View!;', 'Header(ControlCriterionMappingRules rules) => Header(rules.View!);\n\n    public static MappingLineHeader Header(ControlCriterionMappingView view)\n    {')
s=s.replace('Header(CriterionApplicabilityRules rules)\n    {\n        var view = rules.View!;', 'Header(CriterionApplicabilityRules rules) => Header(rules.View!);\n\n    public static MappingLineHeader Header(CriterionApplicabilityView view)\n    {')
s=s.replace('AuthoredIntentDigest.Compute(request) != value.Operation.AuthoredIntentSha256)', 'AuthoredIntentDigest.Compute(request) != value.Operation.AuthoredIntentSha256 ||\n            string.IsNullOrWhiteSpace(request.Rationale) || request.Rationale.Trim().Length > 4000)')
s=s.replace('ProposeControlCriterionMapping expected =', 'if (string.IsNullOrWhiteSpace(request.ApplicabilityExplanation) || request.ApplicabilityExplanation.Trim().Length > 4000)\n            return false;\n        ProposeControlCriterionMapping expected =')
p.write_text(s)
for typ,owner in [('FitzControlMappingDirectoryV1','ControlCriterionMapping'),('FitzCriterionApplicabilityDirectoryV1','CriterionApplicability')]:
 p=W/(C+typ+'.cs');s=(B/(C+typ+'.cs')).read_text().replace('using Cntryl.Fitz;','using Bdgrz.Compliance.Features.Content;\nusing Cntryl.Fitz;').replace('(IKvClient client)','(IKvClient client, IImmutableContentStore content)')
 reducer=owner+'Reducer'
 s=s.replace('var next = '+reducer+'.Apply(current, domainEvent);','var decoded = await MappingLineContent.ReadAsync(content, domainEvent, ct).ConfigureAwait(false);\n        var next = '+reducer+'.Apply(current, decoded.Change);\n        MappingLineContent.ValidateCurrent(decoded.Current, MappingLineContent.Current(next));\n        if (((IMappingLineFact)domainEvent).Header != MappingLineContent.Header(next))\n            throw new ImmutableContentIntegrityException("The projected current authority has another native header.");')
 p.write_text(s)
# Shared files baseline read directly at fresh exact source; preserve unrelated overlays by hunks.
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
for path in ['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs']:
 if not (B/path).exists():(B/path).parent.mkdir(parents=True,exist_ok=True);(B/path).write_bytes((repo/path).read_bytes())
 if not (W/path).exists():(W/path).parent.mkdir(parents=True,exist_ok=True);(W/path).write_bytes((B/path).read_bytes())
p=W/'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.Operations;','using Bdgrz.Compliance.Features.Operations;\nusing Bdgrz.Compliance.Features.ControlMappings;')
pos=s.index('        Decorate<IRequestBus>');s=s[:pos]+'''        Decorate<IAggregateReader>(services, (provider, inner) =>
            new MappingLineAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));
'''+s[pos:];p.write_text(s)
p=W/'src/Compliance.Core/ComplianceCoreJsonContext.cs';s=p.read_text();types=['MappingLineHeader','MappingLineSlot','MappingLineMutation','ControlCriterionMappingProposedChange','ControlCriterionMappingReviewedChange','ControlCriterionMappingRetiredChange','CriterionNotApplicableProposedChange','CriterionApplicabilityReviewedChange','CriterionNotApplicableWithdrawnChange'];idx=s.index('[JsonSerializable(typeof(ProposeControlCriterionMapping))]');s=s[:idx]+''.join('[JsonSerializable(typeof('+t+'))]\n' for t in types)+s[idx:];p.write_text(s)
