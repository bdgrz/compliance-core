exec(open('/tmp/compliance-mapping-native-prepared/implement.py').read().split('# Retain old full')[0])
names=['ControlCriterionMappingProposed','ControlCriterionMappingReviewed','ControlCriterionMappingRetired','CriterionNotApplicableProposed','CriterionApplicabilityReviewed','CriterionNotApplicableWithdrawn']
import re
params={n:re.search(r'public sealed record '+n+r'Change\((.*?)\)\s*(?:\{|;)',(W/(C+n+'Change.cs')).read_text(),re.S).group(1) for n in names}
code='''using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.ControlMappings;

/// <summary>Verified complete immutable content for the two native line protocols.</summary>
public static class MappingLineContent
{
    public const string Schema = "control-mapping-line-mutation.v1";

    public static JsonElement Json<T>(T value) where T : notnull => JsonSerializer.SerializeToElement(value,
        typeof(T), ComplianceCoreJsonContext.Default);

    public static async Task<MappingLinePrepared> PrepareAsync<TRequest>(IImmutableContentStore content,
        Aggregate owner, TRequest request, object change, object current, MappingLineHeader header,
        ImmutableContentRef result, CancellationToken ct) where TRequest : notnull
    {
        var mutation = new MappingLineMutation(Json(request), JsonSerializer.SerializeToElement(change,
            change.GetType(), ComplianceCoreJsonContext.Default), JsonSerializer.SerializeToElement(current,
            current.GetType(), ComplianceCoreJsonContext.Default));
        var tenant = Uuid.Parse(owner.Stream.Realm);
        var reference = await NativeContent.WriteAsync(content, tenant, Schema, mutation, ct).ConfigureAwait(false);
        var frame = Frame(change, reference, header, null, result);
        ValidateAuthored(mutation.Authored, change);
        return new MappingLinePrepared(header.Revision - 1, owner.Version, owner.CommittedStreamPosition, frame);
    }

    public static async Task<(object Change, JsonElement Current)> ReadAsync(IImmutableContentStore content,
        DomainEvent frame, CancellationToken ct)
    {
        if (frame is not IMappingLineFact native || native.Content is null || native.Content.Schema != Schema)
            throw new ImmutableContentIntegrityException("The line fact lacks its declared immutable content.");
        var mutation = await NativeContent.ReadAsync<MappingLineMutation>(content, native.TenantId, native.Content, ct)
            .ConfigureAwait(false);
        object change;
        try
        {
            change = frame switch
            {
READ
                _ => throw new ImmutableContentIntegrityException("The line has another native fact type."),
            };
            ValidateAuthored(mutation.Authored, change);
        }
        catch (JsonException exception)
        {
            throw new ImmutableContentIntegrityException("The line mutation JSON cannot be decoded: " + exception.Message);
        }
        if (!Bound(frame, change))
            throw new ImmutableContentIntegrityException("The immutable business change has another native header binding.");
        return (change, mutation.Current);
    }

    public static void ValidateCurrent(JsonElement expected, object current)
    {
        var actual = JsonSerializer.SerializeToElement(current, current.GetType(), ComplianceCoreJsonContext.Default);
        if (!JsonElement.DeepEquals(expected, actual))
            throw new ImmutableContentIntegrityException("The immutable current authority does not match the full verified transition history.");
    }

    public static ControlCriterionMappingView Current(ControlCriterionMappingRules rules) => rules.View! with
    { Versions = [.. rules.View!.Versions.Where(static version => version.Status is "proposed" or "accepted")] };

    public static CriterionApplicabilityView Current(CriterionApplicabilityRules rules) => rules.View! with
    { Versions = [.. rules.View!.Versions.Where(static version => version.Status is "proposed" or "accepted")] };

    public static MappingLineHeader Header(ControlCriterionMappingRules rules)
    {
        var view = rules.View!;
        var pending = view.Versions.SingleOrDefault(static value => value.Status == "proposed");
        var active = view.Versions.SingleOrDefault(static value => value.Status == "accepted");
        return new MappingLineHeader(view.Revision, view.Versions.Count, view.MappingId,
            pending is null ? null : new MappingLineSlot(pending.MappingId, pending.VersionNumber, Uuid.Parse(pending.ProposedBy.Id)),
            active is null ? null : new MappingLineSlot(active.MappingId, active.VersionNumber, Uuid.Parse(active.ProposedBy.Id)),
            view.Versions.Any(static value => value.Status == "retired"));
    }

    public static MappingLineHeader Header(CriterionApplicabilityRules rules)
    {
        var view = rules.View!;
        var pending = view.Versions.SingleOrDefault(static value => value.Status == "proposed");
        var active = view.Versions.SingleOrDefault(static value => value.Status == "accepted");
        return new MappingLineHeader(view.Revision, view.Versions.Count, view.DecisionId,
            pending is null ? null : new MappingLineSlot(pending.DecisionId, pending.VersionNumber, Uuid.Parse(pending.ProposedBy.Id)),
            active is null ? null : new MappingLineSlot(active.DecisionId, active.VersionNumber, Uuid.Parse(active.ProposedBy.Id)),
            view.Versions.Any(static value => value.Status == "withdrawn"));
    }

    static DomainEvent Frame(object change, ImmutableContentRef content, MappingLineHeader header,
        ImmutableContentRef? firstResponse, ImmutableContentRef result) => change switch
    {
FRAME
        _ => throw new ImmutableContentIntegrityException("The content has another business change type."),
    };

    static bool Bound(DomainEvent frame, object change) => (frame, change) switch
    {
BOUND
        _ => false,
    };

    static void ValidateAuthored(JsonElement authored, object change)
    {
        var valid = change switch
        {
AUTH
            _ => false,
        };
        if (!valid)
            throw new ImmutableContentIntegrityException("The immutable authored intent does not match its native acceptance and business change.");
    }
HELPERS
}
'''
code=code.replace('READ','\n'.join('                '+n+' => mutation.Change.Deserialize(ComplianceCoreJsonContext.Default.'+n+'Change) ?? throw new ImmutableContentIntegrityException("The business change is JSON null."),' for n in names))
frames=[];bounds=[]
for n in names:
 p=re.search(r'public sealed record '+n+r'\((.*?)\)\s*:',(W/(M+n+'.cs')).read_text(),re.S).group(1)
 fields=[i.strip().split()[-1] for i in p.split(',')]
 frames.append('        '+n+'Change value => new '+n+'('+', '.join({'Content':'content','Header':'header','FirstResponse':'firstResponse','OperationResult':'result'}.get(f,'value.'+f) for f in fields)+'),')
 binds=[f for f in fields if f not in ['Content','Header','FirstResponse','OperationResult']]
 bounds.append('        ('+n+' frameValue, '+n+'Change value) =>\n            '+' &&\n            '.join('frameValue.'+f+' == value.'+f for f in binds)+',')
code=code.replace('FRAME','\n'.join(frames)).replace('BOUND','\n'.join(bounds))
# Typed request reconstruction verifies every authored field, including original revision and whitespace-normalized texts.
requests={
names[0]:('ProposeControlCriterionMapping','new(value.MappingId, value.TenantId, value.ProgramId, value.ControlId, value.ControlVersionId, value.EditionId, value.CriterionIdentifier, (long)value.Operation.OriginalExpectedRevision!, value.Rationale, value.ApplicabilityExplanation)'),
names[1]:('ReviewControlCriterionMapping','new(value.DecisionId, value.TenantId, value.ProgramId, value.MappingId, (long)value.Operation.OriginalExpectedRevision!, value.Outcome, value.Rationale, value.SeparationOfDutiesWaiverId)'),
names[2]:('RetireControlCriterionMapping','new(value.Operation.LogicalId, value.TenantId, value.ProgramId, value.MappingId, (long)value.Operation.OriginalExpectedRevision!, value.Rationale)'),
names[3]:('ProposeCriterionNotApplicable','new(value.DecisionId, value.TenantId, value.ProgramId, value.EditionId, value.CriterionIdentifier, (long)value.Operation.OriginalExpectedRevision!, value.Rationale)'),
names[4]:('ReviewCriterionApplicability','new(value.ReviewDecisionId, value.TenantId, value.ProgramId, value.DecisionId, (long)value.Operation.OriginalExpectedRevision!, value.Outcome, value.Rationale, value.SeparationOfDutiesWaiverId)'),
names[5]:('WithdrawCriterionNotApplicable','new(value.Operation.LogicalId, value.TenantId, value.ProgramId, value.DecisionId, (long)value.Operation.OriginalExpectedRevision!, value.Rationale)')}
auth=[];helpers=[]
for n,(req,construct) in requests.items():
 auth.append('            '+n+'Change value => Valid'+req+'(authored, value),')
 normal='request with { Rationale = request.Rationale.Trim()'+(', ApplicabilityExplanation = request.ApplicabilityExplanation.Trim()' if n==names[0] else '')+' }'
 helpers.append('    static bool Valid'+req+'(JsonElement authored, '+n+'Change value)\n    {\n        var request = authored.Deserialize(ComplianceCoreJsonContext.Default.'+req+');\n        if (request is null || value.Operation.OriginalExpectedRevision is null ||\n            AuthoredIntentDigest.Compute(request) != value.Operation.AuthoredIntentSha256)\n            return false;\n        '+req+' expected = '+construct+';\n        return '+normal+' == expected;\n    }\n')
code=code.replace('AUTH','\n'.join(auth)).replace('HELPERS','\n'.join(helpers))
(W/(C+'MappingLineContent.cs')).write_text(code)
# Correct actual immutable ref property names.
p=W/(C+'MappingLineTransitions.cs');s=p.read_text().replace('.SchemaVersion','.Schema').replace('.ByteLength','.Bytes');p.write_text(s)
