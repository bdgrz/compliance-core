exec(open('/tmp/compliance-operating-history-prepared/prepare.py').read().split('files=')[0])
p='src/Compliance.Core/Features/Operations/ControlOccurrenceFanOut.cs';s=own(p).read_text();a=s.index('        ControlOccurrenceSelectionManifest manifest;');b=s.index('\n        var target = ',a)
s=s[:a]+'''        var manifest = await store.ReadJsonAsync<ControlOccurrenceSelectionManifest>(realm, record.Intent, ct)
            .ConfigureAwait(false);
        if (manifest.Selections is null)
            throw new ImmutableContentIntegrityException("The selected occurrence manifest is incomplete.");
        var selection = manifest.Selections.SingleOrDefault(candidate => candidate.OccurrenceId == occurrenceId);
        if (selection is null)
            throw new ImmutableContentIntegrityException("The process target is outside its exact frozen selection.");
        var intent = await store.ReadJsonAsync<ControlOccurrenceCreationIntent>(realm, selection.Intent, ct)
            .ConfigureAwait(false);
'''+s[b:];s=s.replace('using Bdgrz.Compliance.Features.SourceFacts;\n','');write(p,s)
p='src/Compliance.Core/Features/Operations/ControlOccurrenceFanOutReactor.cs';s=own(p).read_text();s=s.replace('''        var selected = context.Trigger;
''','''        var selected = context.Trigger;
        if (selected.Operation.Owner != context.Source.Stream ||
            context.Source.Stream.Realm != selected.TenantId.ToString() || context.Source.Stream.Area != TypeIIPeriod.Area ||
            context.Source.Stream.Resource != selected.SubjectId.ToString() ||
            selected.Operation.RootOperationId != selected.Operation.LogicalId ||
            selected.Operation.CommandKind != nameof(GenerateDueControlOccurrences))
            throw new ReactionCommandFailedException(new RequestError(RequestErrorKind.Conflict,
                "The occurrence selection belongs to another exact source owner or root operation.", false));
''')
s=s.replace('''                context.Source.Stream.Realm, selected.CreationIntentManifest, ct).ConfigureAwait(false);''','''                context.Source.Stream.Realm, selected.CreationIntentManifest, ct).ConfigureAwait(false);
            if (manifest.Selections is null)
                throw new ImmutableContentIntegrityException("The occurrence selection manifest is incomplete.");''')
s=s.replace('$"The selection manifest cannot be verified yet: {exception.Message}", true)', '$"The selection manifest cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException)');write(p,s)
p='src/Compliance.Core/Features/Operations/ControlOccurrenceFold.cs';s=(work/p).read_text().replace('        var intent = await ControlOperatingContent.ReadAsync', '        var facts = await ControlOccurrenceHistory.ReadAsync(events, occurrence, ct).ConfigureAwait(false);\n        var intent = await ControlOperatingContent.ReadAsync',1).replace('intent.PlanProof.Stream !=', 'intent.PlanProof is null || intent.PlanProof.Stream !=').replace('foreach (var fact in await ControlOccurrenceHistory.ReadAsync(events, occurrence, ct).ConfigureAwait(false))', 'foreach (var fact in facts)');write(p,s)
