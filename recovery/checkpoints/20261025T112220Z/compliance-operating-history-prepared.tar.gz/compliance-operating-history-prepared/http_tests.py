exec(open('/tmp/compliance-operating-history-prepared/prepare.py').read().split('files=')[0])
p='test/Compliance.Tests/Features/Operations/ControlOperatingTransportTests.cs';s=own(p).read_text().replace('using Bdgrz.Compliance.Features.Controls;','using Bdgrz.Compliance.Features.Controls;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;')
s=s.replace('''        Assert.Equal(plan.ToString(), document.RootElement.GetProperty("plan_version_id").GetString());''','''        Assert.Equal(plan.ToString(), document.RootElement.GetProperty("plan_version_id").GetString());
        await AssertFrozenResponseAsync(factory, fixture, nameof(ProposeControlOperatingPlan), proposed);
        await AssertFrozenResponseAsync(factory, fixture, nameof(ApproveControlOperatingPlan), approved);''')
s=s.replace('''        Assert.Equal("returned", JsonDocument.Parse(reviewedText).RootElement.GetProperty("state").GetString());''','''        Assert.Equal("returned", JsonDocument.Parse(reviewedText).RootElement.GetProperty("state").GetString());
        var occurrenceId = Uuid.Parse(occurrence, CultureInfo.InvariantCulture);
        await AssertFrozenResponseAsync(factory, fixture, nameof(AttestControlOccurrence), attested, occurrenceId);
        await AssertFrozenResponseAsync(factory, fixture, nameof(ReviewControlOccurrence), reviewed, occurrenceId);
        await AssertFrozenResponseAsync(factory, fixture, nameof(CorrectControlAttestation), corrected, occurrenceId);''')
s=s.replace('''        return new Arranged($"/api/v1/tenants/{tenant}/programs/{program}/controls/{controlId}", controlId,
            ownerMember, otherMember, effectiveFrom);''','''        return new Arranged($"/api/v1/tenants/{tenant}/programs/{program}/controls/{controlId}", tenant, program, controlId,
            ownerMember, otherMember, effectiveFrom);''')
s=s.replace('''    static WebApplicationFactory<Program> Factory() =>''','''    static WebApplicationFactory<Program> Factory(IPermissionAuthorizer? permissions = null) =>''').replace('new PermissionBackedAccessGrantPermissionAuthorizer(new RecordingPermissionAuthorizer(true))','new PermissionBackedAccessGrantPermissionAuthorizer(permissions ?? new RecordingPermissionAuthorizer(true))')
s=s.replace('''    sealed record Arranged(string ControlPath, Uuid ControlId, Uuid OwnerMember, Uuid ReviewerMember,''','''    sealed record Arranged(string ControlPath, Uuid TenantId, Uuid ProgramId, Uuid ControlId, Uuid OwnerMember, Uuid ReviewerMember,''')
idx=s.index('    static async Task<Arranged> ArrangeAsync(')
extra='''    [Fact]
    public async Task ShouldRequireCurrentGrantBeforeFrozenReplayGivenProductionOperatingPlanRoute()
    {
        // Arrange
        var permissions = new MutablePermissions();
        await using var factory = Factory(permissions);
        using var owner = factory.CreateClient();
        using var approver = factory.CreateClient();
        var fixture = await ArrangeAsync(factory, owner, approver);
        var route = $"{fixture.ControlPath}/operating-plan/proposals/{Uuid.CreateVersion4()}";
        var json = fixture.Proposal(0, "Original scoped proposal.");
        using var first = await owner.PutAsync(route, Json(json));
        Assert.Equal(HttpStatusCode.OK, first.StatusCode);
        await AssertFrozenResponseAsync(factory, fixture, nameof(ProposeControlOperatingPlan), first);
        permissions.Allowed = false;

        // Act
        using var denied = await owner.PutAsync(route, Json(json));
        using var anonymous = factory.CreateClient();
        using var unauthorized = await anonymous.PutAsync(route, Json(json));
        await using var scope = factory.Services.CreateAsyncScope();
        var retained = await scope.ServiceProvider.GetRequiredService<IAggregateReader>().HydrateAsync(
            new ControlOperatingPlan(fixture.TenantId, fixture.ProgramId, fixture.ControlId));

        // Assert
        Assert.Equal(HttpStatusCode.Forbidden, denied.StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, unauthorized.StatusCode);
        Assert.Equal(1, retained.Revision);
    }

    static async Task AssertFrozenResponseAsync(WebApplicationFactory<Program> factory, Arranged fixture,
        string commandKind, HttpResponseMessage response, Uuid? occurrenceId = null)
    {
        await using var scope = factory.Services.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var stream = occurrenceId is { } id
            ? new ControlOccurrence(fixture.TenantId, fixture.ProgramId, fixture.ControlId, id).Stream
            : new ControlOperatingPlan(fixture.TenantId, fixture.ProgramId, fixture.ControlId).Stream;
        var matches = new List<INativeOperationFact>();
        await foreach (var record in services.GetRequiredService<IDomainEventReader>().ReadAsync(stream, 0, CancellationToken.None))
            if (!record.Event.Metadata.IsAudit && record.Event is INativeOperationFact native && native.Operation.CommandKind == commandKind)
                matches.Add(native);
        var fact = Assert.Single(matches);
        var content = services.GetRequiredService<IImmutableContentStore>();
        var descriptor = await FirstResponses.ReplayAsync(content, fixture.TenantId.ToString(), fact.FirstResponse!);
        var frozen = await content.ReadVerifiedAsync(fixture.TenantId.ToString(), Assert.IsType<StandardResponseBody>(descriptor.Body).Content);
        Assert.Equal(200, descriptor.HttpStatus);
        Assert.Equal(descriptor.HttpStatus, (int)response.StatusCode);
        Assert.Equal(frozen.ToArray(), await response.Content.ReadAsByteArrayAsync());
        Assert.Equal(descriptor.ContentType, response.Content.Headers.ContentType?.ToString());
    }

    sealed class MutablePermissions : IPermissionAuthorizer
    {
        public bool Allowed { get; set; } = true;
        public ValueTask<bool> IsAllowedAsync(Uuid tenantId, Uuid userId, Uuid memberId, string permission,
            CancellationToken ct = default) => ValueTask.FromResult(Allowed);
    }

'''
s=s[:idx]+extra+s[idx:];write(p,s)
