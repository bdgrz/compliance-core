from pathlib import Path
import shutil,json
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core');out=Path('/tmp/compliance-operating-history-prepared');base=out/'base';work=out/'work'
byte=Path('/tmp/compliance-source-byte-closure-prepared/work')
def own(p):
 q=work/p
 if q.exists():return q
 src=byte/p if p=='src/Compliance.Core/Features/Operations/TypeIIPeriodCloseReconciliation.cs' else root/p
 q.parent.mkdir(parents=True,exist_ok=True)
 if src.exists():(base/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,base/p);shutil.copy2(src,q)
 return q
def write(p,s):own(p).write_text(s)
files=['ControlOperatingPlan.cs','ControlOccurrence.cs','ControlOperatingPlanLine.cs','ControlOccurrenceFold.cs','ControlOperationsReader.cs','MaterializeControlOccurrenceHandler.cs','ProposeControlOperatingPlanHandler.cs','ApproveControlOperatingPlanHandler.cs','OpenControlOccurrenceHandler.cs','AttestControlOccurrenceHandler.cs','CorrectControlAttestationHandler.cs','ReviewControlOccurrenceHandler.cs','OccurrenceProofs.cs','ControlOperationsSource.cs','TypeIIPeriodCloseReconciliation.cs']
for name in files:own('src/Compliance.Core/Features/Operations/'+name)
own('test/Compliance.Tests/Testing/ControlOperatingSeed.cs')
for name in ['ControlOperatingPlan','ControlOccurrence']:
 p='src/Compliance.Core/Features/Operations/'+name+'.cs';s=(work/p).read_text().replace('readonly List<DomainEvent> _facts = [];','DomainEvent? _latest;').replace('public IReadOnlyList<DomainEvent> Facts => _facts;','public DomainEvent? Latest => _latest;').replace('Every fact of the line in order.','The latest exact native fact at this command cut.').replace('Every fact of the occurrence in order.','The latest exact native fact at this command cut.').replace('_facts.Add(ev);','_latest = ev;')
 idx=s.index('    /// <summary>The program')
 s=s[:idx]+'''    /// <summary>The tenant of this exact owner.</summary>
    public Uuid TenantId => _tenantId;

'''+s[idx:];write(p,s)
 p='src/Compliance.Core/Features/Operations/'+name+'History.cs'
 typename=name
 types=['ControlOperatingPlanProposed','ControlOperatingPlanApproved'] if name=='ControlOperatingPlan' else ['ControlOccurrenceOpened','ControlOccurrenceAttested','ControlOccurrenceReviewed']
 scope='fact.TenantId == owner.TenantId && fact.ProgramId == owner.ProgramId && fact.ControlId == owner.ControlId'
 cases=[]
 for typ in types:
  cond=scope+' && fact.Revision == index + 1'
  if name=='ControlOccurrence':cond+=' && fact.OccurrenceId == owner.Id'
  cases.append('                '+typ+' fact => '+cond+',')
 write(p,'''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Verified immutable history at a compact command owner's exact hydrated native and physical cut.</summary>
public static class NAMEHistory
{
    /// <summary>Reads complete history outside command authority, including audit-aware physical accounting.</summary>
    public static async Task<IReadOnlyList<DomainEvent>> ReadAsync(IDomainEventReader events, NAME owner,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(owner);
        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, owner, ct).ConfigureAwait(false);
        if (facts.Count != owner.Revision || facts.Count > 0 && (owner.Latest is null ||
            ContentDigest.Sha256(facts[^1], facts[^1].GetType()) !=
            ContentDigest.Sha256(owner.Latest, owner.Latest.GetType())))
            throw new ImmutableContentIntegrityException("The operating history differs from its exact hydrated command cut.");
        var logicalIds = new HashSet<Uuid>();
        for (var index = 0; index < facts.Count; index++)
        {
            if (facts[index] is not INativeOperationFact native || native.Operation.LogicalId == Uuid.Empty ||
                native.Operation.Owner != owner.Stream || !logicalIds.Add(native.Operation.LogicalId))
                throw new ImmutableContentIntegrityException("The operating history repeats an operation or names another exact owner.");
            var valid = facts[index] switch
            {
CASES
                _ => false,
            };
            if (!valid)
                throw new ImmutableContentIntegrityException("The operating history contains another tenant, program, control or predecessor.");
        }
        return facts;
    }
}
'''.replace('NAME',name).replace('CASES','\n'.join(cases)))
# Existing folds are immutable read models, not Aggregate history retention.
for name,owner,history in [('ControlOperatingPlanLine.cs','plan','ControlOperatingPlanHistory'),('ControlOccurrenceFold.cs','occurrence','ControlOccurrenceHistory')]:
 p='src/Compliance.Core/Features/Operations/'+name;s=(work/p).read_text().replace('IImmutableContentStore content, Uuid tenantId, CancellationToken ct)', 'IDomainEventReader events, IImmutableContentStore content, Uuid tenantId, CancellationToken ct)').replace('foreach (var fact in '+owner+'.Facts)', 'foreach (var fact in await '+history+'.ReadAsync(events, '+owner+', ct).ConfigureAwait(false))')
 anchor='        ArgumentNullException.ThrowIfNull(content);';s=s.replace(anchor,anchor+'\n        if (tenantId != '+owner+'.TenantId)\n            throw new ImmutableContentIntegrityException("The operating composition belongs to another tenant.");')
 write(p,s)
p='src/Compliance.Core/Features/Operations/ControlOperationsReader.cs';s=(work/p).read_text().replace('ReadAsync(plan, content,', 'ReadAsync(plan, events, content,').replace('ReadAsync(occurrence, content,', 'ReadAsync(occurrence, events, content,');write(p,s)
p='src/Compliance.Core/Features/Operations/MaterializeControlOccurrenceHandler.cs';s=(work/p).read_text().replace('MaterializeControlOccurrenceHandler(IAggregateReader reader, IAggregateExecutor executor,', 'MaterializeControlOccurrenceHandler(IAggregateReader reader, IDomainEventReader events, IAggregateExecutor executor,').replace('ReadAsync(plan, content,', 'ReadAsync(plan, events, content,');write(p,s)
p='test/Compliance.Tests/Testing/ControlOperatingSeed.cs';s=(work/p).read_text().replace(')), content, tenantId,',')), services.GetRequiredService<IDomainEventReader>(), content, tenantId,').replace('                current.OccurrenceId)), content, current.TenantId,','                current.OccurrenceId)), services.GetRequiredService<IDomainEventReader>(), content, current.TenantId,').replace('            services.GetRequiredService<IImmutableContentStore>(), tenantId,', '            services.GetRequiredService<IDomainEventReader>(), services.GetRequiredService<IImmutableContentStore>(), tenantId,');write(p,s)
p='src/Compliance.Core/Features/Operations/TypeIIPeriodCloseReconciliation.cs';s=(work/p).read_text()
s=s.replace('if (owner.Facts.OfType<INativeOperationFact>()', 'var ownerFacts = await ControlOccurrenceHistory.ReadAsync(events, owner, ct).ConfigureAwait(false);\n                    if (ownerFacts.OfType<INativeOperationFact>()').replace('foreach (var fact in owner.Facts)', 'foreach (var fact in ownerFacts)')
s=s.replace('if (line.Facts.OfType<INativeOperationFact>()', 'var lineFacts = await ControlOperatingPlanHistory.ReadAsync(events, line, ct).ConfigureAwait(false);\n                if (lineFacts.OfType<INativeOperationFact>()').replace('foreach (var fact in line.Facts)', 'foreach (var fact in lineFacts)');write(p,s)
p='src/Compliance.Core/Features/Operations/ControlOperationsSource.cs';s=(work/p).read_text().replace('intentDigest, acceptedAt, owner, owner);','intentDigest, acceptedAt, owner, owner, owner);');write(p,s)
