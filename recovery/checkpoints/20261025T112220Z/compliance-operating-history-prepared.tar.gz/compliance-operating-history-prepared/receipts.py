exec(open('/tmp/compliance-operating-history-prepared/prepare.py').read().split('files=')[0])
p='src/Compliance.Core/Features/Operations/TypeIIPeriodCloseReconciliation.cs';s=(work/p).read_text().replace('using Bdgrz.Compliance.Features.Snapshots;', 'using Bdgrz.Compliance.Features.Snapshots;\nusing Bdgrz.Compliance.Features.SourceFacts;').replace('TypeIIPeriodCloseHistory history, TypeIIPeriodCloseSourcePublication publication)', 'TypeIIPeriodCloseHistory history, TypeIIPeriodCloseSourcePublication publication, RecordedSourceReceiptCutFactory receiptCuts)')
s=s.replace('''        try
        {
            var engagement =''','''        try
        {
            var operatingReceipts = receiptCuts.Create(current.TenantId, operation.AcceptedAt);
            var engagement =''',1)
import re
s=re.sub(r'                    if \(ownerFacts\.OfType<INativeOperationFact>\(\)\.Any\(fact => fact\.Operation\.AcceptedAt > operation\.AcceptedAt\)\)\n                        throw new ImmutableContentUnavailableException\("[^"]+"\);','                    await RequireOperatingReceiptCutAsync(operatingReceipts, owner.Stream, ownerFacts, ct).ConfigureAwait(false);',s)
s=re.sub(r'                if \(lineFacts\.OfType<INativeOperationFact>\(\)\.Any\(fact => fact\.Operation\.AcceptedAt > operation\.AcceptedAt\)\)\n                    throw new ImmutableContentUnavailableException\("[^"]+"\);','                await RequireOperatingReceiptCutAsync(operatingReceipts, line.Stream, lineFacts, ct).ConfigureAwait(false);',s)
idx=s.index('    static ')
s=s[:idx]+'''    static async Task RequireOperatingReceiptCutAsync(RecordedSourceReceiptCut cut, EventStreamAddress stream,
        IReadOnlyList<DomainEvent> facts, CancellationToken ct)
    {
        var prefix = await cut.ReadAsync(stream, ct).ConfigureAwait(false);
        if (facts.Any(fact => !prefix.Includes(fact)) || prefix.Included.Count() != facts.Count)
            throw new ImmutableContentUnavailableException("The exact operating native source is not a complete committed prefix at the frozen close receipt cutoff.");
    }

'''+s[idx:];write(p,s)
# Existing fixture ctor variants migrate to the existing installed receipt-cut factory.
p='test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseSources.cs';s=(work/p).read_text().replace('new TypeIIPeriodCloseSourcePublication(artifacts, fixture.Host.Content));','new TypeIIPeriodCloseSourcePublication(artifacts, fixture.Host.Content),\n                new RecordedSourceReceiptCutFactory(fixture.Events, fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>()));');write(p,s)
p='test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseSourceBusinessBytes.cs';s=(work/p).read_text().replace('fixture.Host.Services.GetRequiredService<FindingReader>(), families, history, publisher);','fixture.Host.Services.GetRequiredService<FindingReader>(), families, history, publisher,\n                new RecordedSourceReceiptCutFactory(fixture.Events, fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>()));');
if 'using Bdgrz.Compliance.Features.SourceFacts;' not in s:s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
write(p,s)
p='test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.OperatingReceipts.cs'
test='''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Tests.Features.Changes;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Operations;

public sealed partial class TypeIIPeriodCommandHandlerTests
{
    [Fact]
    public async Task ShouldRefuseLateOperatingCommitGivenOlderAcceptedTimestampBeforeFrozenCloseCut()
    {
        // Arrange
        await using var fixture = new Fixture();
        await fixture.SeedSelectedPeriodAsync();
        var boundary = Uuid.CreateVersion4();
        await SeedCloseEngagementAsync(fixture, boundary);
        var period = await fixture.Periods.ReadAsync(fixture.TenantId, fixture.ProgramId, fixture.PeriodId);
        var request = await CloseRequestAsync(fixture);
        var operation = RootOperation.Provenance(request.CommandId, nameof(RecordTypeIIPeriodCloseValidation), period.Stream,
            ActorReference.ForMember(fixture.ActorMemberId, "Close validator"), period.Revision, new string('a', 64),
            fixture.CloseClock.GetUtcNow());
        var broker = Assert.IsType<ReceiptTrackingEventStore>(fixture.Host.Services.GetRequiredService<IEventStore>());
        broker.Clock = new FixedTimeProvider(operation.AcceptedAt.AddMilliseconds(1));
        var previous = await ControlOperatingSeed.CurrentPlanAsync(fixture.Host.Provider, fixture.TenantId,
            fixture.ProgramId, fixture.ControlId);
        await ControlOperatingSeed.ProposeAsync(fixture.Host.Provider, fixture.TenantId, fixture.ProgramId,
            fixture.ControlId, fixture.ControlVersionId, previous.ExpectedEvidence, Uuid.CreateVersion4(), previous.Owner,
            previous.BackupOwner, previous.ReviewerMemberId, previous.Cadence, previous.EffectiveFrom.AddDays(1),
            "Prepared earlier but committed after this close cutoff.", fixture.ProposerMemberId, "Past preparer", StartedAt);
        var directory = Path.Combine(Path.GetTempPath(), "bdgrz-operating-close-receipt-" + Guid.NewGuid().ToString("N"));
        try
        {
            var artifacts = new LocalArtifactContentStore(new ArtifactContentStoreOptions(directory, new byte[32],
                ArtifactContentLimits.MaxContentLength), fixture.CloseClock);
            var families = new PublishedTypeIBaselinePreviewReader(new TypeIBaselinePreviewReader(
                TypeIBaselineSourceFamilies.Required.Select(family => new CloseFamily(family, boundary)).ToArray()), artifacts,
                fixture.Host.Content);
            var history = new TypeIIPeriodCloseHistory(fixture.Reader, fixture.Events,
                new RestrictedComplianceRecordVisibility(new RecordingPermissionAuthorizer(true)),
                new SignificantChangeReader(fixture.Reader, fixture.Events, fixture.Host.Content,
                    fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>()), fixture.Host.Content,
                fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>());
            var source = new TypeIIPeriodCloseReconciliation(CTOR);

            // Act
            var result = await source.ReadAsync(period, fixture.Context(request).Actor, fixture.ActorUserId,
                operation, CancellationToken.None);
            var retained = await fixture.Periods.ReadAsync(fixture.TenantId, fixture.ProgramId, fixture.PeriodId);

            // Assert
            Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
            Assert.True(result.Error!.IsTransient);
            Assert.Null(retained.View!.CloseValidation);
            Assert.Equal(period.Owner.CommittedStreamPosition, retained.Owner.CommittedStreamPosition);
        }
        finally
        {
            if (Directory.Exists(directory))
                Directory.Delete(directory, recursive: true);
        }
    }
}
'''
oldctor='''fixture.Reader, fixture.Host.Content,
                fixture.Host.Services.GetRequiredService<ControlOperationsReader>(), fixture.Host.Services.GetRequiredService<FindingReader>(),
                families, history, new TypeIIPeriodCloseSourcePublication(artifacts, fixture.Host.Content)'''
newctor='''fixture.Reader, fixture.Events, fixture.Host.Content,
                fixture.Host.Services.GetRequiredService<ControlOperationsReader>(), fixture.Host.Services.GetRequiredService<FindingReader>(),
                families, history, new TypeIIPeriodCloseSourcePublication(artifacts, fixture.Host.Content),
                new RecordedSourceReceiptCutFactory(fixture.Events, broker)'''
write(p,test.replace('CTOR',newctor));red=out/'red'/p;red.parent.mkdir(parents=True,exist_ok=True);red.write_text(test.replace('CTOR',oldctor))
(out/'receipt-behavioral-red-filter.txt').write_text('FullyQualifiedName~ShouldRefuseLateOperatingCommitGivenOlderAcceptedTimestampBeforeFrozenCloseCut\n')
