from pathlib import Path
import json,hashlib,difflib,re,shutil,subprocess,sys,collections
r=Path('/tmp/compliance-operating-history-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def delta(a,b,path):return ''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+str(path) if a else '/dev/null',tofile='b/'+str(path)))
# Only normalize whitespace; root owns final dotnet-format after all coordinated overlays.
for p in (r/'work').rglob('*.cs'):
 s='\n'.join(x.rstrip() for x in p.read_text().splitlines())+'\n'
 while '\n\n\n' in s:s=s.replace('\n\n\n','\n\n')
 p.write_text(s)
manifest=[];patches={n:[] for n in ['full.patch','implementation.patch','tests.patch','behavioral-red.patch','after-red.patch','operating-receipt-behavioral-red.patch','compaction-behavioral-red.patch','close-consumer.patch']}
plan={'ControlOperatingPlan.cs','ControlOperatingPlanHistory.cs','ControlOperatingPlanLine.cs','ProposeControlOperatingPlanHandler.cs','ApproveControlOperatingPlanHandler.cs'}
for p in sorted((r/'work').rglob('*.cs')):
 rel=p.relative_to(r/'work');b=r/'base'/rel;before=b.read_text() if b.exists() else '';after=p.read_text();kind='test' if rel.parts[0]=='test' else 'implementation'
 if before==after:continue
 part='plan' if p.name in plan else 'operating-close-receipt-bytes' if p.name.startswith('TypeIIPeriodCloseReconciliation') or p.name.startswith('TypeIIPeriodCommandHandlerTests.') else 'shared-read-seed' if p.name in ['ControlOperationsReader.cs','ControlOperationsSource.cs','ControlOperatingSeed.cs'] else 'occurrence'
 manifest.append({'path':str(rel),'kind':kind,'partition':part,'before_sha256':sha(b) if b.exists() else None,'after_sha256':sha(p),'baseline_matches_current_main':sha(b)==sha(repo/rel) if b.exists() and (repo/rel).exists() else not b.exists() and not(repo/rel).exists()})
 patch=delta(before,after,rel);patches['full.patch'].append(patch);patches['tests.patch' if kind=='test' else 'implementation.patch'].append(patch)
 if part=='operating-close-receipt-bytes':patches['close-consumer.patch'].append(patch)
 red=r/'red'/rel;rb=red.read_text() if red.exists() else before
 if rb!=after:patches['after-red.patch'].append(delta(rb,after,rel))
for p in sorted((r/'red').rglob('*.cs')):
 rel=p.relative_to(r/'red');b=r/'base'/rel;d=delta(b.read_text() if b.exists() else '',p.read_text(),rel);patches['behavioral-red.patch'].append(d);patches['operating-receipt-behavioral-red.patch' if p.name.endswith('.OperatingReceipts.cs') else 'compaction-behavioral-red.patch'].append(d)
for n,parts in patches.items():(r/n).write_text(''.join(parts))
recon=[]
for name,sequence in [('full',['full.patch']),('red-green',['behavioral-red.patch','after-red.patch']),('partitioned',['implementation.patch','tests.patch'])]:
 d=r/'verify'/name
 if d.exists():shutil.rmtree(d)
 shutil.copytree(r/'base',d)
 for patch in sequence:
  x=subprocess.run(['patch','--batch','-p1','-d',str(d),'-i',str(r/patch)],capture_output=True,text=True);assert x.returncode==0,x.stdout+x.stderr
 bad=[m['path'] for m in manifest if not(d/m['path']).exists() or sha(d/m['path'])!=m['after_sha256']];assert not bad,bad
 recon.append({'route':name,'mismatches':bad})
old=set();new=set();removed=[];assertdrop=[]
names=lambda s:set(re.findall(r'\b(Should\w+)\s*\(',s))
for m in manifest:
 if m['kind']!='test':continue
 b=r/'base'/m['path'];before=b.read_text() if b.exists() else '';after=(r/'work'/m['path']).read_text();old|=names(before);new|=names(after);removed+=sorted(names(before)-names(after))
 if before.count('Assert.')>after.count('Assert.'):assertdrop.append(m['path'])
sys.path.insert(0,'/tmp/compliance-csharp-syntax314');from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));syntax=[];token=[];ownercollections=[];defs={};uses=[];methoddefs={};methoduses=[]
watch={'ControlOperatingPlan','ControlOccurrence','ControlOperationsReader','MaterializeControlOccurrenceHandler','TypeIIPeriodCloseReconciliation','ProposeControlOperatingPlanHandler','ApproveControlOperatingPlanHandler','OpenControlOccurrenceHandler','AttestControlOccurrenceHandler','CorrectControlAttestationHandler','ReviewControlOccurrenceHandler','PreparedOccurrenceReview'}
methodwatch={'ControlOperatingPlanLine.ReadAsync','ControlOccurrenceFold.ReadAsync','OccurrenceProofs.AttestAsync','OccurrenceProofs.ReviewAsync'}
changed=set(m['path'] for m in manifest);combined={str(p.relative_to(repo)):p for d in ['src','test'] for p in (repo/d).rglob('*.cs')};combined.update({str(p.relative_to(r/'work')):p for p in (r/'work').rglob('*.cs')})
def walk(n):
 q=[n]
 while q:
  x=q.pop();yield x;q.extend(reversed(x.named_children))
def params(data,node):
 args=[c for c in node.named_children if c.type=='parameter'];return {'min':sum(b'=' not in data[c.start_byte:c.end_byte] for c in args),'max':len(args)}
for path,p in combined.items():
 data=p.read_bytes()
 if path not in changed and not any(n.encode() in data for n in watch|{'ControlOperatingPlanLine','ControlOccurrenceFold','OccurrenceProofs'}):continue
 tree=parser.parse(data)
 if path in changed and tree.root_node.has_error:syntax.append(path)
 for node in walk(tree.root_node):
  if node.type in ['class_declaration','record_declaration']:
   n=node.child_by_field_name('name');name=data[n.start_byte:n.end_byte].decode() if n else '';ps=next((x for x in node.named_children if x.type=='parameter_list'),None)
   if name in watch and ps:defs.setdefault(name,[]).append(params(data,ps))
   if name in {'ControlOccurrence','ControlOperatingPlan'} and path in changed:
    for child in node.child_by_field_name('body').named_children:
     if child.type=='constructor_declaration':
      ps=child.child_by_field_name('parameters') or next((x for x in child.named_children if x.type=='parameter_list'),None)
      if ps:defs.setdefault(name,[]).append(params(data,ps))
     if child.type=='field_declaration' and re.search(rb'\b(List|Dictionary|HashSet)<',data[child.start_byte:child.end_byte]):ownercollections.append({'path':path,'field':data[child.start_byte:child.end_byte].decode()})
  if path in changed and node.type=='parameter_list':
   ps=[x for x in node.named_children if x.type=='parameter']
   for i,pn in enumerate(ps):
    if b'CancellationToken ' in data[pn.start_byte:pn.end_byte] and i!=len(ps)-1:token.append({'path':path,'line':data[:pn.start_byte].count(b'\n')+1})
  if node.type=='object_creation_expression':
   typ=node.child_by_field_name('type');args=node.child_by_field_name('arguments')
   if typ and args:
    name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
    if name in watch:uses.append({'path':path,'type':name,'arity':sum(x.type=='argument' for x in args.named_children)})
  if path in changed and node.type=='method_declaration':
   name=node.child_by_field_name('name');ps=node.child_by_field_name('parameters')
   if name and ps:
    key=p.stem+'.'+data[name.start_byte:name.end_byte].decode()
    if key in methodwatch:methoddefs[key]=params(data,ps)
  if node.type=='invocation_expression':
   fn=node.child_by_field_name('function');args=node.child_by_field_name('arguments')
   if fn and args:
    key=data[fn.start_byte:fn.end_byte].decode()
    if key in methodwatch:methoduses.append({'path':path,'method':key,'arity':sum(x.type=='argument' for x in args.named_children)})
ctorbad=[u for u in uses if u['type'] in defs and not any(d['min']<=u['arity']<=d['max'] for d in defs[u['type']])]
methodbad=[u for u in methoduses if u['method'] in methoddefs and not methoddefs[u['method']]['min']<=u['arity']<=methoddefs[u['method']]['max']]
assert not any([syntax,token,ownercollections,ctorbad,methodbad,removed,assertdrop]),{'syntax':syntax,'tokens':token,'ownercollections':ownercollections,'constructors':ctorbad,'methods':methodbad,'removed':removed,'assertions':assertdrop}
serializer=(repo/'src/Compliance.Core/ComplianceCoreJsonContext.cs').read_text();roots=['ControlOperatingPlanProposed','ControlOperatingPlanApproved','ControlOccurrenceOpened','ControlOccurrenceAttested','ControlOccurrenceReviewed','ControlOccurrenceCreationIntent','ControlOccurrenceSelectionManifest','ControlOperatingPlanView','ControlOccurrenceView','ControlAttestationView','ControlOccurrenceReviewView'];registered=[{'type':n,'registered':bool(re.search(r'typeof\((?:[^)]+\.)?'+n+r'\)',serializer))} for n in roots]
static={'syntax_errors':syntax,'constructor_definitions':defs,'constructor_uses':uses,'constructor_errors':ctorbad,'method_definitions':methoddefs,'method_uses':methoduses,'method_errors':methodbad,'token_errors':token,'owner_collection_fields':ownercollections,'existing_acceptance_methods':len(old),'new_acceptance_methods':sorted(new-old),'removed_acceptance_methods':removed,'assertion_count_regressions':assertdrop,'serializer_registrations':registered,'runtime':'Parent qualified standalone receipt RED2 on old actual source; no .NET/build/test executed by preparing agent. Root owns compiler/analyzers/format/focused/full/HTTP/Jev/Git.'}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(r/'static-checks.json').write_text(json.dumps(static,indent=2)+'\n');(r/'reconstruction.json').write_text(json.dumps(recon,indent=2)+'\n')
(r/'focused-filter.txt').write_text('FullyQualifiedName~ControlOperatingHistoryCompactionTests|FullyQualifiedName~ControlOperatingNativeHistoryTests|FullyQualifiedName~ControlOperatingPlanTests|FullyQualifiedName~ControlOccurrenceTests|FullyQualifiedName~ControlOperatingIdentifiedOperationTests|FullyQualifiedName~ControlOccurrenceFanOutTests|FullyQualifiedName~PersonalOccurrenceProofTransportTests|FullyQualifiedName~PersonalOperatingPlanApprovalTransportTests|FullyQualifiedName~TypeIIPeriodCommandHandlerTests|FullyQualifiedName~ConcurrentOccurrenceSubmissionTests|FullyQualifiedName~NotApplicableOccurrenceReviewTests|FullyQualifiedName~OwnerScopedProjectionIdentityTests\n')
(r/'web-filter.txt').write_text('FullyQualifiedName~ControlOperatingTransportTests\n')
(r/'behavioral-red-filter.txt').write_text('FullyQualifiedName~ControlOperatingHistoryCompactionTests|FullyQualifiedName~ShouldHonorAuthenticatedOperatingReceiptGivenContradictoryAcceptedTimestamp\n')
dep=Path('/tmp/compliance-small-history-compactions-prepared/work/src/Compliance.Core/Features/NativeOperations/NativeOwnerHistory.cs')
(r/'prerequisites.json').write_text(json.dumps([{'artifact':'/tmp/compliance-small-history-compactions-prepared/handoff.json','source':'src/Compliance.Core/Features/NativeOperations/NativeOwnerHistory.cs','frozen_sha256':sha(dep),'policy':'Use actual installed root-refined helper, no duplicate implementation.'},{'artifact':'/tmp/compliance-source-byte-closure-prepared/handoff.json','source':'src/Compliance.Core/Features/Operations/TypeIIPeriodCloseReconciliation.cs','policy':'Close baseline layers frozen ByteClosure10 (currently identical main at capture); preserve CaptureOperatingAsync/PhysicalContentBlobs plus concurrent Finding/Incident/Change branches.'},{'policy':'Root-owned NativeOperationExecutor expected prepare/read/write/descriptor failure recheck; no shared executor edits.'},{'policy':'Installed authenticated INativeEventReceiptReader + RecordedSourceReceiptCutFactory/Prefix; existing source receipt/factory services resolve through DI. No new receipt protocol.'}],indent=2)+'\n')
(r/'shared-deltas.json').write_text(json.dumps({'DI':'No shared registration changes. Existing IDomainEventReader and RecordedSourceReceiptCutFactory registrations supply new constructor dependencies.','constructor_changes':{'MaterializeControlOccurrenceHandler':'(IAggregateReader,IDomainEventReader,IAggregateExecutor,IImmutableContentStore,TimeProvider)','TypeIIPeriodCloseReconciliation':'(IAggregateReader,IDomainEventReader,IImmutableContentStore,ControlOperationsReader,FindingReader,PublishedTypeIBaselinePreviewReader,TypeIIPeriodCloseHistory,TypeIIPeriodCloseSourcePublication,RecordedSourceReceiptCutFactory)','AttestControlOccurrenceHandler':'(NativeOperationExecutor,ControlOperationsReader,ControlReader,OperatingAuthority,IImmutableContentStore,TimeProvider)','CorrectControlAttestationHandler':'same six dependency types as Attest; removed unused IAggregateReader'},'public_read_APIs':'ControlOperationsReader existing public ctor/read signatures unchanged; ComposeLineAsync(owner,ct) added. Static PlanLine/Fold ReadAsync now(owner,IDomainEventReader,content,tenant,ct). All actual callers migrated. Owners remove Facts and add Latest/TenantId; static History.ReadAsync(events,owner,ct) supplies exact verified full history outside Aggregate.','JSON_HTTP':'Five unchanged native fact payloads retain actual occupied v2 tags; no new durable CLR roots, public DTO/route/MCP/wire status/result schema changes. Existing production-host HTTP tests now compare actual200 to frozen descriptor/bytes and current/anonymous auth. PreparedOccurrenceReview is ephemeral, not serialized.','close_source':'Only operating fact selection gates switch from AcceptedAt to exact authenticated complete receipt prefix at original RecordedThrough; exact effective-window/expected selection checks and CaptureOperatingAsync byte closure preserved. No time-based source authority or new callback.','source_consumers':'Parent inventory_worktrees owns RaiseOccurrenceFindingHandler and ControlOccurrenceFindingReactor; public ControlOperationsReader signatures remain stable, event schemas unchanged. Do not overwrite its concurrent Finding changes.','audit_and_clone_qualification':'Installed Portia0.9.1 audits use independent audit-session resource streams. Test uses actual AuditEvent emitter+writer, never same-owner audit hydration. Deliberate payload clones reattach exact original Metadata before tuple/body-hash contradictions.'},indent=2)+'\n')
(r/'LOCAL-QUALIFICATION.md').write_text('''No new GitHub issues, public callback/route/permit, global operation lookup or migration authority. Preparation touched only this /tmp tree; root owns runtime and integration.

The five operating native facts were already externalized and occupy v2. Their complete payloads, fields, schemas and v2 tags are unchanged. Final target-event catalog still selects preliminary v1: root explicitly chose preserving occupied unchanged payload versions and owns metadata reconciliation. No downgrade or occupied-tag reuse is included.

Current Control source-use acquire/settle pair remains absent from selected catalogs (docs/product/audits/2026-10-24/control-source-use-qualification.json). Existing current approved-control, exact version, holders, SoD/waiver/effective-date gates remain for new writes. No foreign current-at-append held-source guarantee is fabricated. Existing TypeII calendar/range selection and materialization protocols remain authoritative.

Close operating selection now uses existing authenticated per-resource receipt prefix at frozen RecordedThrough, independent of body AcceptedAt/OccurredOn. A selected source missing from that exact cut, an eligible prefix advancing beyond the hydrated source, or unavailable receipt remains pending. Contradictory tuple, corruption or non-prefix receipt selection is permanent. Body effective/window/source identities and archive bytes remain original. Parent has qualified both standalone old-API clock contradiction rows as true RED; other runtime validation is pending.

NativeOwnerHistory is reused from small3 and root runtime refinements. Generic helper raw physical/audit handling is not a claim that installed Portia allows audits in state streams: the new test emits actual independent audit sessions via Aggregate.AuditEvent and IAggregateWriter. Typed DomainEvent clones explicitly reattach original Metadata in tamper fixtures.

Native root binding remains per first owner. No bare/global operation query, realm-wide UUID guarantee, old URL/assignment alias or persisted legacy event converter is introduced. Exact accepted retries still require current request authorization before returning original frozen200 bytes. Materializer source/intent proofs remain exact and unknown append outcomes propagate for retry; accepted native replay precedes unrelated archived plan reads, and equivalent other-generator windows retain canonical convergence.

All native bodies and physical source publication remain complete. Read/rules composition may retain complete historical arrays outside Aggregate; command owners retain only scalar/current refs and selected acceptance. Static syntax/constructor/method/token/collection/acceptance/serializer and exact patch reconstruction are not compiler, tests, broker or deployment evidence.
''')
(r/'README.md').write_text('''# Operating plan and occurrence command history compaction

Frozen offline coherent slice: 28 paths (20 source/8 test). Root owns runtime, direct Jev, Git and integration. Owners were already native; this removes the remaining lifetime Facts lists and moves exact history into static verified readers without changing existing native payloads/tags.

Apply behavioral-red.patch and run behavioral-red-filter.txt against old source, then after-red.patch. Four declaration-level compaction/retry RED methods cover seven rows: actual long plan histories, corrections/reviews, original result after holder/reviewer reassignment, and replay despite an unrelated missing historical plan body. Standalone operating-receipt-behavioral-red.patch covers two more rows using only current old API: actual late receipt with older AcceptedAt must refuse; timely receipt with later AcceptedAt must include. Root has already confirmed both receipt rows fail for the intended old behavior. Green fixture constructor/import variants are explicit, no shipped compatibility path.

Full.patch or implementation.patch+tests.patch are exact alternative reconstruction routes; close-consumer.patch is a review subset, not an additional layer. Manifest records exact before/after hashes and partitions. Root may currently have the standalone old-API receipt RED test installed; after-red includes its final new constructor variant.

The two Aggregate owners retain only latest native source, scalar revision/generation/current pending/header refs and selected NativeAcceptance. NativeOwnerHistory verifies exact native/physical cuts and last body hash, with full source scope and logical ID checks. Immutable PlanLine/Fold compose full history outside command state and verify plan/view identity, creation intent, native original actors and exact attestation/review lineage. All actual reader/materializer/seed and close-capture callers migrate; no Facts/Current compatibility collection is left on owners.

All new-write Control/holder/waiver/rule/immutable preparation runs inside native async Prepare after original acceptance. Attestation, correction and review use lazy typed source factories, exact captured occurrence revision checks and one server clock. Existing personal HTTP, current program auth, reviewer independence, current holders, exact approved version and effective/cadence/window rules remain. Root failure recheck helper is reused, no executor copy.

Materialization verifies original trusted source/intent, then resolves its native acceptance before unrelated archived plan reads; causal root/first-owner/source event binding is compared explicitly. Equivalent window creation by another generator still converges, and unknown append propagates for forward retry. Missing source content is transient, corruption permanent; fan-out factory/reactor classify that distinction correctly.

Operating close gates use authenticated broker receipt prefix at sealed RecordedThrough and verify the whole selected hydrated prefix, preserving actual effective/window checks and frozen source bytes. ByteClosure10 CaptureOperatingAsync/PhysicalContentBlobs and the existing real archive roundtrip test remain. No source bytes, logical source preimages or native fact schemas change.

Existing acceptance names/assertions are retained. New tests include native missing/contradictory cuts, exact old-cut readers, wrong-owner immutable content, actual independent audit sessions, genuine materializer replay/content failures/factory classification, actual host frozen200 descriptor/bytes and current auth. No .NET/build/runtime work was done by this preparing agent; see static-checks.json and LOCAL-QUALIFICATION.md for exact evidence boundaries.
''')
art={n:{'sha256':sha(r/n),'bytes':(r/n).stat().st_size} for n in patches}
hand={'root':str(r),'status':'frozen offline; root runtime/review/integration pending','paths':len(manifest),'source_paths':sum(m['kind']=='implementation' for m in manifest),'test_paths':sum(m['kind']=='test' for m in manifest),'partitions':dict(collections.Counter(m['partition'] for m in manifest)),'manifest_sha256':sha(r/'manifest.json'),'patches':art,'prerequisites':'prerequisites.json','shared_deltas':'shared-deltas.json','existing_acceptance_methods':len(old),'new_acceptance_methods':len(new-old),'new_rows':31,'removed_acceptance_methods':removed,'static_issues':{'syntax':syntax,'ctors':ctorbad,'methods':methodbad,'tokens':token,'owner_collections':ownercollections,'assertions':assertdrop},'reconstruction':recon,'runtime_evidence':'Root confirmed operating receipt standalone old-API RED2 genuine; green and other runtime checks pending.'};(r/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(hand,indent=2))
