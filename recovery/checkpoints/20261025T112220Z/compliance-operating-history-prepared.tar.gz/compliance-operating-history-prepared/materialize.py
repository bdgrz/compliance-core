exec(open('/tmp/compliance-operating-history-prepared/prepare.py').read().split('files=')[0])
p='src/Compliance.Core/Features/Operations/MaterializeControlOccurrenceHandler.cs';s=(work/p).read_text()
s=s.replace('''            return SourceUseReceiverSupport.Permanent($"The frozen creation intent cannot be verified: {exception.Message}");''','''            return ContentFailure("The frozen creation intent cannot be verified.", exception);''')
a=s.index('        var planStream = ')
insert='''        var now = clock.GetUtcNow();
        var provenance = SourceUseReceiverSupport.Child(command.CommandId, nameof(MaterializeControlOccurrence),
            command.Source.EventId, intent.Header, target, now);
        var binding = AcceptedOperationBinding.Of(provenance);
        var acceptedOwner = await reader.HydrateAsync(new ControlOccurrence(tenant, command.ProgramId,
            command.ControlId, canonical, command.CommandId), ct).ConfigureAwait(false);
        if (Decide(acceptedOwner, binding, provenance) is { } accepted)
            return accepted;
'''
s=s[:a]+insert+s[a:]
s=s.replace('''        var now = clock.GetUtcNow();
        var periodEnd''','''        var periodEnd''')
# Remove the old provenance block that followed fresh plan composition.
a=s.index('        var provenance = SourceUseReceiverSupport.Child',s.index('        var periodEnd'));b=s.index('        for (var attempt',a);s=s[:a]+s[b:]
s=s.replace('Decide(current, binding)', 'Decide(current, binding, provenance)').replace('Decide(occurrence, binding)', 'Decide(occurrence, binding, provenance)')
a=s.index('    static Result<ReceiverOutcome>? Decide(');b=s.index('    /// <summary>The selection',a)
s=s[:a]+'''    static Result<ReceiverOutcome>? Decide(ControlOccurrence occurrence, AcceptedOperationBinding binding,
        OperationProvenance candidate)
    {
        switch (occurrence.Acceptance.Decide(binding))
        {
            case NativeAcceptanceDecision.Conflict:
                return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
            case NativeAcceptanceDecision.Replayed:
                var selected = occurrence.Acceptance.SelectedProvenance!;
                if (selected.RootOperationId != candidate.RootOperationId ||
                    selected.CausationEventId != candidate.CausationEventId ||
                    (selected.FirstOwner ?? selected.Owner) != (candidate.FirstOwner ?? candidate.Owner))
                    return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
                return SourceUseReceiverSupport.Replayed(Fact(occurrence.Stream, occurrence.Acceptance.SelectedFact!));
            default:
                return null;
        }
    }

'''+s[b:]
s=s.replace('''            return SourceUseReceiverSupport.Transient($"The selection manifest cannot be verified yet: {exception.Message}");''','''            return ContentFailure("The exact selection manifest cannot be verified.", exception);''')
s=s.replace('''            return SourceUseReceiverSupport.Permanent(
                $"The materialized creation intent cannot be verified: {exception.Message}");''','''            return ContentFailure("The materialized creation intent cannot be verified.", exception);''')
idx=s.index('    static NativeFactReference Fact(')
s=s[:idx]+'''    static Result<ReceiverOutcome> ContentFailure(string message, ImmutableContentIntegrityException failure) =>
        Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict, message,
            failure is ImmutableContentUnavailableException));

'''+s[idx:];write(p,s)
