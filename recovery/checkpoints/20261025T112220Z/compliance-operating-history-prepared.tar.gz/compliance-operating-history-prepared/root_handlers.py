exec(open('/tmp/compliance-operating-history-prepared/prepare.py').read().split('files=')[0])
p='src/Compliance.Core/Features/Operations/ControlOperationsReader.cs';s=(work/p).read_text();i=s.index('    /// <summary>The materialized occurrence')
s=s[:i]+'''    /// <summary>Composes only the exact native/physical cut already hydrated for admission.</summary>
    public Task<ControlOperatingPlanLine> ComposeLineAsync(ControlOperatingPlan plan, CancellationToken ct = default) =>
        ControlOperatingPlanLine.ReadAsync(plan, events, content, plan.TenantId, ct);

'''+s[i:];write(p,s)
for kind in ['Propose','Approve','Open']:
 name=kind+'ControlOperatingPlanHandler.cs' if kind!='Open' else 'OpenControlOccurrenceHandler.cs';p='src/Compliance.Core/Features/Operations/'+name;s=(work/p).read_text()
 outside=''
 if kind=='Approve':
  a=s.index('        var control = await ControlOperationsSource.LoadControlAsync');b=s.index('        var actor = OperationsActor.From',a);outside=s[a:b];s=s[:a]+s[b:]
 if kind=='Open':
  a=s.index('        var control = await ControlOperationsSource.LoadControlAsync');b=s.index('        var now = clock.GetUtcNow();',a)
  outside=s[a:b];s=s[:a]+s[b:]
  # Actor identity is immutable input; current holder/source checks remain lazy.
  actorline='        var actor = OperationsActor.From(context.Actor, request.TenantId);\n';outside=outside.replace(actorline,'');idx=s.index('        var now = clock.GetUtcNow();');s=s[:idx]+actorline+s[idx:]
 if kind!='Open':
  a=s.index('        var (current, line) = await operatingReader.ReadLineAsync');b=s.index('\n\n',a);s=s[:a]+s[b+1:]
 else:
  a=s.index('        var (current, _) = await operatingReader.ReadStateAsync');b=s.index('\n\n',a);s=s[:a]+s[b+1:]
 a=s.index('        if (current.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');bstart=s.index('        {\n',a)+len('        {\n');b=s.index('\n        }\n\n        var outcome',bstart);body=s[bstart:b]
 s=s[:a]+s[b+len('\n        }\n'):]
 if kind!='Open':
  body='''            var line = await operatingReader.ComposeLineAsync(current, token).ConfigureAwait(false);
'''+outside+body
 else:body=outside+body
 body=body.replace('ct)', 'token)').replace('return Result<ControlOperatingPlanView>.Failure(', 'return Result<FirstResponseDescriptor>.Failure(').replace('return Result<ControlOccurrenceView>.Failure(', 'return Result<FirstResponseDescriptor>.Failure(')
 import textwrap,re
 body=textwrap.indent(textwrap.dedent(body.rstrip()),'                    ')
 cb='''async (current, token) =>
            {
                try
                {
BODY
                    return Result<FirstResponseDescriptor>.Success(response!);
                }
                catch (ImmutableContentIntegrityException failure)
                {
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The exact operating source content cannot be verified.", failure is ImmutableContentUnavailableException));
                }
            }'''.replace('BODY',body)
 if kind=='Propose':s=s.replace('plan => Prepare(plan, request.ExpectedRevision, response)',cb)
 elif kind=='Approve':s=s.replace('plan => Prepare(plan, request, response)',cb)
 else:s=s.replace('occurrence => Prepare(occurrence, request.ExpectedRevision, response)',cb)
 # No candidate is prepared before NativeOperationExecutor resolves accepted native facts.
 idx=s.index('\n    static Result<FirstResponseDescriptor> Prepare(');s=s[:idx]+'\n}\n'
 write(p,s)
