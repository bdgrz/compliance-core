exec(open('/tmp/compliance-operating-history-prepared/prepare.py').read().split('files=')[0])
p='src/Compliance.Core/Features/Operations/OccurrenceProofs.cs';old=(work/p).read_text();tail=old[old.index('    static async Task<(FirstResponseDescriptor Response,'):old.index('    static Result<FirstResponseDescriptor> Prepare(')]
tail=tail.replace('proof.Owner, proof.Owner);','proof.Owner, proof.Owner, proof.Owner);')
head='''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Admits native occurrence proofs before fresh sources, preserving original results and complete immutable bodies.</summary>
static class OccurrenceProofs
{
    public static async ValueTask<Result<ControlOccurrenceView>> AttestAsync(NativeOperationExecutor operations,
        IImmutableContentStore content, IExecutionContext context, string commandKind, Uuid commandId,
        long expectedRevision, string intentDigest, Uuid tenantId, Uuid programId, Uuid controlId, Uuid occurrenceId,
        OperationsActor actor, Func<CancellationToken, ValueTask<Result<PreparedOccurrenceProof>>> prepare,
        Func<PreparedOccurrenceProof, AttestationInput> inputOf, string? correctionReason,
        DateTimeOffset now, CancellationToken ct)
    {
        var correcting = correctionReason is not null;
        var stream = new ControlOccurrence(tenantId, programId, controlId, occurrenceId).Stream;
        var provenance = ControlOperationsSource.Provenance(commandId, commandKind, stream, actor,
            expectedRevision, intentDigest, now);
        ImmutableContentRef? attestation = null;
        ImmutableContentRef? result = null;
        ControlOccurrenceMaterialization? materialization = null;
        var outcome = await operations.ExecuteAsync(new NativeOperation<ControlOccurrence>(AcceptedOperationBinding.Of(provenance),
            () => new ControlOccurrence(tenantId, programId, controlId, occurrenceId, commandId), owner => owner.Acceptance,
            async (owner, token) =>
            {
                try
                {
                    var gate = owner.PrepareProof(expectedRevision, !correcting);
                    if (!gate.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(gate.Error!);
                    var prepared = await prepare(token).ConfigureAwait(false);
                    if (!prepared.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(prepared.Error!);
                    var source = prepared.Value!;
                    var current = source.Current;
                    if (current.TenantId != tenantId || current.ProgramId != programId || current.ControlId != controlId ||
                        current.OccurrenceId != occurrenceId || source.Actor.MemberId != actor.MemberId || current.Revision != owner.Revision)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The occurrence source changed while its exact native proof was prepared.", true));
                    var input = inputOf(source);
                    var failure = correcting
                        ? ControlOperationRules.CheckCorrection(current, expectedRevision, input, correctionReason!, source.Plan.ExpectedEvidence, now)
                        : ControlOperationRules.CheckAttestation(current, expectedRevision, input, source.Plan.ExpectedEvidence, now);
                    if (failure is not null)
                        return Result<FirstResponseDescriptor>.Failure(failure.ToRequestError());
                    if (current.Revision == 0)
                        materialization = await MaterializationAsync(content, source, provenance, now, token).ConfigureAwait(false);
                    var view = ControlOperationRules.BuildAttestation(current.OccurrenceId, current.Attestations.Count + 1,
                        input, source.Plan, current.PeriodStart, current.PeriodEnd, correctionReason?.Trim(),
                        correcting ? current.Attestations[^1].AttestationId : null, actor.MemberId, actor.Display, now);
                    attestation = await ControlOperatingContent.WriteAsync(content, tenantId,
                        ControlOperatingContent.AttestationSchema, view, token).ConfigureAwait(false);
                    var frozen = await FreezeAsync(content, tenantId, ControlOccurrenceFold.WithAttestation(current, view,
                        current.Revision == 0 ? 2 : current.Revision + 1), token).ConfigureAwait(false);
                    result = frozen.Result;
                    return Result<FirstResponseDescriptor>.Success(frozen.Response);
                }
                catch (ImmutableContentIntegrityException failure)
                {
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The exact occurrence proof source cannot be verified.", failure is ImmutableContentUnavailableException));
                }
            }, (owner, frozen) => owner.Attest(provenance, attestation!, frozen, result!, materialization)), context, ct)
            .ConfigureAwait(false);
        return await ControlOperatingContent.ResponseAsync<ControlOccurrenceView>(content, tenantId, outcome, ct).ConfigureAwait(false);
    }

    public static async ValueTask<Result<ControlOccurrenceView>> ReviewAsync(NativeOperationExecutor operations,
        IImmutableContentStore content, IExecutionContext context, ReviewControlOccurrence request, string intentDigest,
        OperationsActor actor, Func<CancellationToken, ValueTask<Result<PreparedOccurrenceReview>>> prepare,
        DateTimeOffset now, CancellationToken ct)
    {
        var (tenantId, programId, controlId) = (request.TenantId, request.ProgramId, request.ControlId);
        var stream = new ControlOccurrence(tenantId, programId, controlId, request.OccurrenceId).Stream;
        var provenance = ControlOperationsSource.Provenance(request.CommandId, nameof(ReviewControlOccurrence), stream,
            actor, request.ExpectedRevision, intentDigest, now);
        ImmutableContentRef? review = null;
        ImmutableContentRef? result = null;
        var outcome = await operations.ExecuteAsync(new NativeOperation<ControlOccurrence>(AcceptedOperationBinding.Of(provenance),
            () => new ControlOccurrence(tenantId, programId, controlId, request.OccurrenceId, request.CommandId), owner => owner.Acceptance,
            async (owner, token) =>
            {
                try
                {
                    var gate = owner.PrepareProof(request.ExpectedRevision, false);
                    if (!gate.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(gate.Error!);
                    var prepared = await prepare(token).ConfigureAwait(false);
                    if (!prepared.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(prepared.Error!);
                    var current = prepared.Value!.Current;
                    if (current.TenantId != tenantId || current.ProgramId != programId || current.ControlId != controlId ||
                        current.OccurrenceId != request.OccurrenceId || current.Revision != owner.Revision)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The occurrence changed while its exact native review was prepared.", true));
                    var waiver = prepared.Value.Waiver;
                    var actions = request.RequestedActions ?? [];
                    var failure = ControlOperationRules.CheckReview(current, tenantId, request.ExpectedRevision,
                        request.AttestationId, request.Outcome, request.Rationale, actions, actor.MemberId, now, waiver);
                    if (failure is not null)
                        return Result<FirstResponseDescriptor>.Failure(failure.ToRequestError());
                    var attestation = current.Attestations[^1];
                    var view = new ControlOccurrenceReviewView(request.CommandId, request.AttestationId, attestation.Version,
                        request.Outcome, request.Rationale.Trim(), actions.Select(static item => item.Trim()).ToArray(),
                        actor.MemberId, ActorReference.ForMember(actor.MemberId, actor.Display), now, waiver?.Id);
                    review = await ControlOperatingContent.WriteAsync(content, tenantId,
                        ControlOperatingContent.ReviewSchema, view, token).ConfigureAwait(false);
                    var frozen = await FreezeAsync(content, tenantId,
                        ControlOccurrenceFold.WithReview(current, view, current.Revision + 1), token).ConfigureAwait(false);
                    result = frozen.Result;
                    return Result<FirstResponseDescriptor>.Success(frozen.Response);
                }
                catch (ImmutableContentIntegrityException failure)
                {
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The exact occurrence review source cannot be verified.", failure is ImmutableContentUnavailableException));
                }
            }, (owner, frozen) => owner.Review(provenance, review!, frozen, result!)), context, ct).ConfigureAwait(false);
        return await ControlOperatingContent.ResponseAsync<ControlOccurrenceView>(content, tenantId, outcome, ct).ConfigureAwait(false);
    }

'''
write(p,head+tail+'}\n')
write('src/Compliance.Core/Features/Operations/PreparedOccurrenceReview.cs','''using Bdgrz.Compliance.Features.AccessControl;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>The fresh exact occurrence and optional independent-review waiver checked only after native retry resolution.</summary>
sealed record PreparedOccurrenceReview(ControlOccurrenceView Current, SeparationOfDutiesWaiver? Waiver);
''')
for kind in ['AttestControlOccurrence','CorrectControlAttestation']:
 p='src/Compliance.Core/Features/Operations/'+kind+'Handler.cs';s=(work/p).read_text().replace('ControlOperationsReader operatingReader, IAggregateReader reader, ControlReader', 'ControlOperationsReader operatingReader, ControlReader')
 a=s.index('        var prepared = await OccurrenceAttestation.PrepareAsync');b=s.index('\n    }',a)
 correction='request.CorrectionReason ?? string.Empty' if kind=='CorrectControlAttestation' else 'null'
 replacement='''        var actor = OperationsActor.From(context.Actor, request.TenantId);
        return await OccurrenceProofs.AttestAsync(operations, content, context, "KIND", request.CommandId,
            request.ExpectedRevision, AuthoredIntentDigest.Compute(request), request.TenantId, request.ProgramId,
            request.ControlId, request.OccurrenceId, actor,
            token => OccurrenceAttestation.PrepareAsync(controlSources, operatingReader, authority, request.TenantId,
                request.ProgramId, request.ControlId, request.OccurrenceId, request.PerformedByPersonId,
                context.Actor, now, token),
            prepared => new AttestationInput(request.Result, request.PerformedAt, request.CoveredFrom,
                request.CoveredUntil, request.Notes, request.Rationale, request.Evidence ?? [], prepared.Performer),
            CORRECTION, now, ct).ConfigureAwait(false);'''.replace('KIND',kind).replace('CORRECTION',correction)
 s=s[:a]+replacement+s[b:];write(p,s)
p='src/Compliance.Core/Features/Operations/ReviewControlOccurrenceHandler.cs';s=(work/p).read_text();a=s.index('        var today = DateOnly.FromDateTime');b=s.index('\n    }',a);body=s[a:b]
a1=body.index('        var actor = OperationsActor.From');b1=body.index('\n',a1)+1;actorline=body[a1:b1];body=body[:a1]+body[b1:]
final=body.index('        return await OccurrenceProofs.ReviewAsync');body=body[:final]
body=body.replace('ct)', 'token)').replace('return Result<ControlOccurrenceView>.Failure(', 'return Result<PreparedOccurrenceReview>.Failure(')
import textwrap
body=textwrap.indent(textwrap.dedent(body.rstrip()),'                ')
s=s[:a]+actorline+'''        return await OccurrenceProofs.ReviewAsync(operations, content, context, request,
           AuthoredIntentDigest.Compute(request), actor, async token =>
           {
BODY
               return Result<PreparedOccurrenceReview>.Success(new PreparedOccurrenceReview(occurrence, waiver));
           }, now, ct).ConfigureAwait(false);'''.replace('BODY',body)+s[b:];write(p,s)
