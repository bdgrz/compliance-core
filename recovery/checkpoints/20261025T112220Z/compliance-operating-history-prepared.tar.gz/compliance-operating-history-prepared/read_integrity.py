exec(open('/tmp/compliance-operating-history-prepared/prepare.py').read().split('files=')[0])
p='src/Compliance.Core/Features/Operations/ControlOperatingPlanLine.cs';s=(work/p).read_text();s=s.replace('''                    line._plans.Add(await ControlOperatingContent.ReadAsync<ControlOperatingPlanView>(content,
                        tenantId, proposed.PlanContent, ct).ConfigureAwait(false));''','''                    var body = await ControlOperatingContent.ReadAsync<ControlOperatingPlanView>(content,
                        tenantId, proposed.PlanContent, ct).ConfigureAwait(false);
                    if (proposed.PlanContent.Schema != ControlOperatingContent.PlanSchema || body.TenantId != tenantId ||
                        body.ProgramId != plan.ProgramId || body.ControlId != plan.ControlId ||
                        body.PlanVersionId != proposed.Operation.LogicalId || body.Revision != proposed.Revision ||
                        body.Status != ControlOperationStates.PendingApproval || body.ProposedBy != proposed.Operation.Actor ||
                        body.ProposedAt != proposed.Operation.AcceptedAt || body.ProposerMemberId.ToString() != proposed.Operation.Actor.Id ||
                        body.ExpectedEvidence is null || line._plans.Any(value => value.PlanVersionId == body.PlanVersionId))
                        throw new ImmutableContentIntegrityException("The immutable operating plan differs from its native source scope, identity or original attribution.");
                    line._plans.Add(body);''')
s=s.replace('''                case ControlOperatingPlanApproved approved:
                    line.Approve''','''                case ControlOperatingPlanApproved approved:
                    if (approved.ReassignmentsManifest.Schema != ControlOperatingContent.ReassignmentsSchema ||
                        line.Pending?.PlanVersionId != approved.PlanVersionId || approved.ApprovedBy != approved.Operation.Actor ||
                        approved.ApproverMemberId.ToString() != approved.Operation.Actor.Id)
                        throw new ImmutableContentIntegrityException("The operating approval differs from its exact pending native version or actor.");
                    line.Approve''');write(p,s)
p='src/Compliance.Core/Features/Operations/ControlOccurrenceFold.cs';s=(work/p).read_text();s=s.replace('''        var attestations = new List<ControlAttestationView>();''','''        var intent = await ControlOperatingContent.ReadAsync<ControlOccurrenceCreationIntent>(content, tenantId,
            opened.CreationIntent, ct).ConfigureAwait(false);
        if (opened.CreationIntent.Schema != ControlOccurrenceCreationIntent.Schema || opened.Intent != opened.CreationIntent ||
            intent.TenantId != tenantId || intent.ProgramId != occurrence.ProgramId || intent.ControlId != occurrence.ControlId ||
            intent.OccurrenceId != occurrence.Id || intent.Window != opened.BusinessWindow || intent.PlanVersionId != opened.PlanVersionId ||
            intent.Header is null || intent.Header.RootOperationId != opened.Operation.RootOperationId ||
            intent.Header.FirstOwner != (opened.Operation.FirstOwner ?? opened.Operation.Owner) ||
            intent.Header.OriginalActor != opened.Operation.Actor || intent.Header.Episode != opened.Operation.Episode ||
            intent.Header.OriginalExpectedRevision != opened.Operation.OriginalExpectedRevision ||
            intent.Header.AuthoredIntentSha256 != opened.Operation.AuthoredIntentSha256 ||
            intent.PlanProof.Stream != new ControlOperatingPlan(tenantId, occurrence.ProgramId, occurrence.ControlId).Stream ||
            intent.PlanProof.EventId == Uuid.Empty || intent.PlanProof.AggregateVersion == 0 ||
            opened.OpenedBy != opened.Operation.Actor || opened.OpenedAt != opened.Operation.AcceptedAt)
            throw new ImmutableContentIntegrityException("The opening terms differ from their exact frozen creation intent and original source authority.");
        var attestations = new List<ControlAttestationView>();''')
s=s.replace('''                    attestations.Add(await ControlOperatingContent.ReadAsync<ControlAttestationView>(content,
                        tenantId, attested.AttestationContent, ct).ConfigureAwait(false));''','''                    var attestation = await ControlOperatingContent.ReadAsync<ControlAttestationView>(content,
                        tenantId, attested.AttestationContent, ct).ConfigureAwait(false);
                    if (attested.AttestationContent.Schema != ControlOperatingContent.AttestationSchema ||
                        attestation.Version != attestations.Count + 1 || attestation.AttestationId != Uuid.CreateVersion5(occurrence.Id,
                            "attestation-" + attestation.Version.ToString(System.Globalization.CultureInfo.InvariantCulture)) ||
                        attestation.PlanVersionId != opened.PlanVersionId || attestation.ControlVersionId != opened.ControlVersionId ||
                        attestation.RecordedBy != attested.Operation.Actor || attestation.RecordedAt != attested.Operation.AcceptedAt ||
                        attestation.RecorderMemberId.ToString() != attested.Operation.Actor.Id || attestation.Evidence is null ||
                        attestation.ExpectedEvidence is null)
                        throw new ImmutableContentIntegrityException("The immutable attestation differs from its exact occurrence version or original recorder.");
                    attestations.Add(attestation);''')
s=s.replace('''                    reviews.Add(review);''','''                    if (reviewed.ReviewContent.Schema != ControlOperatingContent.ReviewSchema || attestations.Count == 0 ||
                        review.DecisionId != reviewed.Operation.LogicalId || review.AttestationId != attestations[^1].AttestationId ||
                        review.AttestationVersion != attestations[^1].Version || review.ReviewedBy != reviewed.Operation.Actor ||
                        review.ReviewedAt != reviewed.Operation.AcceptedAt || review.ReviewerMemberId.ToString() != reviewed.Operation.Actor.Id ||
                        review.RequestedActions is null)
                        throw new ImmutableContentIntegrityException("The immutable review differs from its exact attestation or original reviewer.");
                    reviews.Add(review);''');write(p,s)
