from pathlib import Path
import re,json
import prepare as p

COMMON='src/Compliance.Common/Features/Policies/'
CORE='src/Compliance.Core/Features/Policies/'
EVENTS=['PolicyDraftCreated','PolicyDraftRevised','PolicyReviewed','PolicyApproved','PolicyPeriodicReviewConfirmed','PolicyRetirementProposed','PolicyRetired','PolicyDraftDiscarded']
KINDS=['CreatePolicyDraft','RevisePolicyDraft','ReviewPolicyDraft','ApprovePolicy','ConfirmPolicyReview','ProposePolicySuccessor','ProposePolicyRetirement','ApprovePolicyRetirement','DiscardPolicyDraft']

def put(name,text):p.put(name,text)
def new(name,text):put(name,text.strip()+'\n')
def source(name):return p.original(name)

envelope='''
    public OperationProvenance Operation { get; init; } = default!;
    public ImmutableContentRef? FirstResponse { get; init; }
    public ImmutableContentRef? OperationResult { get; init; }
    public PolicyAuthorityHeader Header { get; init; } = default!;
    public ImmutableContentRef Change { get; init; } = default!;
    public ImmutableContentRef Authority { get; init; } = default!;
    public long NativeSequence { get; init; }
'''
for name in EVENTS:
    old=source(COMMON+name+'.cs')
    # Preserve the exact original scalar and authored-body contract separately from the native receipt.
    match=re.search(r'public sealed record '+name+r'\((.*?)\)\s*:\s*DomainEvent',old,re.S);assert match,name
    params=match.group(1)
    new(COMMON+name+'Content.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public sealed record '''+name+'Content('+params+') : IPolicyMutationContent;')
    native=old[:match.start()]+f'public sealed record {name}('+params.replace('PolicyContent Content','ImmutableContentRef Content')+') : DomainEvent, IPolicyFact\n{'+envelope+'}\n'
    native=re.sub(r'using System.Text.Json.Serialization;\n','',native)
    if 'using Bdgrz.Compliance.Features.NativeOperations;' not in native:native='using Bdgrz.Compliance.Features.NativeOperations;\n'+native
    native='using Bdgrz.Compliance.Features.Proofs;\n'+native
    native=re.sub(r'(\[Discriminator\([^\n]*), 1\)\]',r'\1, 2)]',native)
    put(COMMON+name+'.cs',native)

for name in KINDS:
    if name in ['ReviewPolicyDraft','ApprovePolicy']:continue
    old=source(COMMON+name+'.cs')
    idname='PolicyId' if name=='CreatePolicyDraft' else 'CommandId'
    old=old.replace('record '+name+'(Uuid TenantId',f'record {name}(Uuid {idname}, Uuid TenantId')
    old=old.replace('IClientManagementMutationRequest, ICallable;',f'IClientManagementMutationRequest, IIdentifiedRequest, ICallable\n{{\n    Uuid IIdentifiedRequest.RequestId => {idname};\n}}')
    old=re.sub(r'(\[Discriminator\([^\n]*), 1\)\]',r'\1, 2)]',old)
    put(COMMON+name+'.cs',old)

new(COMMON+'IPolicyMutationContent.cs','''using System.Text.Json.Serialization;

namespace Bdgrz.Compliance.Features.Policies;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "$policy_change")]
'''+''.join(f'[JsonDerivedType(typeof({n}Content), "{n}")]\n' for n in EVENTS)+'''public interface IPolicyMutationContent { }''')
new(COMMON+'PolicyMutationContent.cs','''using Bdgrz.Compliance.Features.AccessControl;

namespace Bdgrz.Compliance.Features.Policies;

public sealed record PolicyMutationContent(IPolicyMutationContent Change,
    SeparationOfDutiesWaiverProof? Waiver = null);''')
new(COMMON+'IPolicyFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public interface IPolicyFact : INativeOperationFact
{
    Uuid TenantId { get; }
    PolicyAuthorityHeader Header { get; }
    ImmutableContentRef Change { get; }
    ImmutableContentRef Authority { get; }
    ImmutableContentRef? OperationResult { get; }
    long NativeSequence { get; }
}''')
new(COMMON+'PolicyAuthorityHeader.cs','''using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

/// <summary>Compact current gates; authored content, author sets and all version/decision history are immutable content.</summary>
public sealed record PolicyAuthorityHeader(Uuid TenantId, Uuid ProgramId, Uuid PolicyId, string Identifier,
    long Revision, bool IsCreated, bool IsVisible, bool IsRetired, bool HasOpenDraft,
    long? DraftPredecessorVersion, Uuid? AcceptedReviewDecisionId, Uuid? AcceptedReviewerMemberId,
    string? LatestReviewOutcome, long? CurrentVersion, DateOnly? CurrentVersionEffectiveFrom,
    long? PendingRetirementVersion, DateOnly? PendingRetirementEffectiveUntil, DateOnly? LastReviewedOn,
    bool EverReviewed, ImmutableContentRef Content);''')
new(COMMON+'PolicyAuthorityContent.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public sealed record PolicyAuthorityContent(PolicyAuthorityHeader Header, IReadOnlyList<Uuid> PendingAuthorMemberIds,
    int CurrentApplicabilityCount, bool HasAccountableOwner);''')

rules=source(CORE+'Policy.cs')
rules=rules.replace('public sealed class Policy : Aggregate','public sealed class PolicyRules')
a=rules.index('    public NativeAcceptance ReplayAcceptance');b=rules.index('    // Fitz stream frames',a)
rules=rules[:a]+'''    readonly Dictionary<Type, Action<IPolicyMutationContent>> _reducers = [];
    readonly List<IPolicyMutationContent> _pendingChanges = [];
    readonly List<IPolicyMutationContent> _appliedChanges = [];
    public Uuid Id { get; }
    public Uuid TenantId => _tenantId;
    public ulong SourcePhysicalPosition { get; internal set; }
    public IReadOnlyList<IPolicyMutationContent> PendingChanges => _pendingChanges.AsReadOnly();
    internal IReadOnlyList<IPolicyMutationContent> AppliedChanges => _appliedChanges.AsReadOnly();
    public void ClearPendingChanges() => _pendingChanges.Clear();
    void On<T>(Action<T> reducer) where T : IPolicyMutationContent =>
        _reducers.Add(typeof(T), value => reducer((T)value));
    void RaiseEvent<T>(T value) where T : IPolicyMutationContent
    {
        Apply(value);
        _pendingChanges.Add(value);
    }
    public void Apply(IPolicyMutationContent value)
    {
        if (!_reducers.TryGetValue(value.GetType(), out var reducer))
            throw new InvalidOperationException("The Policy change has another content kind.");
        reducer(value);
        _appliedChanges.Add(value);
    }

'''+rules[b:]
a=rules.index('    public Policy(Uuid');b=rules.index('        _tenantId = tenantId;',a)
rules=rules[:a]+'''    public PolicyRules(Uuid tenantId, Uuid policyId)
    {
        Id = policyId;
'''+rules[b:]
for name in sorted(EVENTS,key=len,reverse=True):rules=re.sub(r'\b'+name+r'\b',name+'Content',rules)
rules=re.sub(r'            AuthoredCommandReplay.Observe\([^\n]*\);\n','',rules)
rules=rules.replace('''            if (ev.Operation?.LogicalId == ReplayAcceptance.SelectedLogicalId)
                ReplayedApproval = _versions[^1];
''','')
rules=re.sub(r'''        if \(AuthoredCommandReplay.TryReplay\(ReplayAcceptance, operation, out var replayFailure\)\)\n            return replayFailure;\n        _pendingOperation = operation;\n''','',rules)
rules=rules.replace('SeparationOfDutiesWaiver? waiver = null,\n        OperationProvenance? operation = null','SeparationOfDutiesWaiverProof? waiver = null')
rules=rules.replace('SeparationOfDutiesWaiver? waiver','SeparationOfDutiesWaiverProof? waiver').replace('waiver?.Id','waiver?.WaiverId')
rules=rules.replace('waiver.Allows(scope, memberId, at)','PolicyWaiverProof.Allows(waiver, _tenantId, scope, memberId, at)')
rules=rules.replace('''        { Operation = _pendingOperation });''',''');''')
rules=re.sub(r'''        if \(Size\(created, ComplianceCoreJsonContext.Default.PolicyDraftCreatedContent\) >\n            MaximumEventPayloadBytes\)\n            return Result<PolicyRegistration>.Failure\(new RequestError\(RequestErrorKind.Validation,\n                "The policy draft exceeds the bounded event payload size."\)\);\n''','',rules)
rules=re.sub(r'''        if \(Size\(revised, ComplianceCoreJsonContext.Default.PolicyDraftRevisedContent\) >\n            MaximumEventPayloadBytes\)\n            return CommandFailure.InvalidContent\(\n                "The policy draft exceeds the bounded event payload size."\);\n''','',rules)
rules=rules.replace('''    static int Size<T>(T value, System.Text.Json.Serialization.Metadata.JsonTypeInfo<T> info) =>
        JsonSerializer.SerializeToUtf8Bytes(value, info).Length;
''','''    internal PolicyContent? CurrentContent => _draft;
    internal bool IsCreated => _created;
    internal PolicyAuthorityHeader Header(Bdgrz.Compliance.Features.Proofs.ImmutableContentRef content) => new(
        TenantId, ProgramId, Id, _identifier ?? string.Empty, Revision, IsCreated, IsVisible, IsRetired,
        IsVisible && !_retired && _draftOpen, DraftPredecessorVersion, _acceptedReview?.DecisionId,
        _acceptedReview?.ReviewerMemberId, _latestReviewOutcome, CurrentVersion?.Version, CurrentVersion?.EffectiveFrom,
        _pendingRetirement?.Version, _pendingRetirement?.EffectiveUntil, _lastReviewedOn, _everReviewed, content);
    internal PolicyAuthorityContent Authority(PolicyAuthorityHeader header) => new(header,
        _pendingAuthors.OrderBy(id => id.ToString(), StringComparer.Ordinal).ToArray(), _draft?.Applicability?.Count ?? 0,
        !string.IsNullOrWhiteSpace(_draft?.OwnerReference));
''')
assert 'ReplayAcceptance' not in rules and '_pendingOperation' not in rules and 'ReplayedApproval' not in rules
put(CORE+'PolicyRules.cs',rules)
new(CORE+'PolicyWaiverProof.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

static class PolicyWaiverProof
{
    public static bool Allows(SeparationOfDutiesWaiverProof proof, Uuid tenant,
        SeparationOfDutiesWaiverScope scope, Uuid actor, DateTimeOffset at) =>
        proof.TenantId == tenant && proof.WaiverId != Uuid.Empty && proof.SubjectId == actor && proof.ActorId == actor &&
        proof.Action == scope.Action && proof.TargetType == scope.RecordType && proof.TargetId == scope.RecordId &&
        proof.TargetVersionId == scope.VersionId && proof.TargetRevision == scope.Revision &&
        proof.ApprovalFact.Source == new EventStreamAddress(tenant.ToString(), "separation-of-duties-waivers", proof.WaiverId.ToString()) &&
        proof.ApprovalFact.EventId != Uuid.Empty && proof.ApprovalFact.ResourcePosition == 1 && proof.ApprovalFact.AggregateVersion == 2 &&
        proof.ApprovalFact.PayloadSha256 is { Length: 64 } hash && hash.All(character => character is >= '0' and <= '9' or >= 'a' and <= 'f') &&
        at >= proof.ValidFrom && at < proof.ValidUntil;
}''')

if __name__=='__main__':p.emit()

# Generated compact receipt factories preserve all original small metadata without copying authored bodies.
factory='''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public static class PolicyFactFactory
{
    public static DomainEvent Create(string kind, PolicyAuthorityHeader header, long sequence, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result,
        PolicyMutationContent mutation) => kind switch
    {
'''
mapk=dict(zip(KINDS,['PolicyDraftCreated','PolicyDraftRevised','PolicyReviewed','PolicyApproved','PolicyPeriodicReviewConfirmed','PolicyDraftRevised','PolicyRetirementProposed','PolicyRetired','PolicyDraftDiscarded']))
for kind,event in mapk.items():factory+=f'        nameof({kind}) => {event}(header, sequence, operation, change, authority, first, result, mutation),\n'
factory+='''        _ => throw new InvalidOperationException("The Policy command kind is not selected."),
    };
'''
for event in EVENTS:
    original=source(COMMON+event+'.cs');match=re.search(r'public sealed record '+event+r'\((.*?)\)\s*:\s*DomainEvent',original,re.S);params=match.group(1)
    names=[part.strip().split()[-1] for part in params.split(',')]
    args=['header.Content' if n=='Content' else 'data.'+n for n in names]
    factory+=f'''    static DomainEvent {event}(PolicyAuthorityHeader header, long sequence, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result,
        PolicyMutationContent mutation)
    {{
        if (mutation.Change is not {event}Content data)
            throw new InvalidOperationException("The Policy command has another exact mutation kind.");
        return new {event}({', '.join(args)})
        {{
            Operation = operation, Header = header, Change = change, Authority = authority,
            NativeSequence = sequence, FirstResponse = first, OperationResult = result,
        }};
    }}
'''
factory+='}\n';put(CORE+'PolicyFactFactory.cs',factory)

new(CORE+'PolicyContentStore.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public static class PolicyContentStore
{
    public static async ValueTask<FrozenPolicyMutation> FreezeAsync(IImmutableContentStore content, PolicyRules after,
        PolicyMutationContent mutation, CancellationToken ct = default)
    {
        if (after.CurrentContent is not { } current || PolicyRules.ValidateContent(current) is not null)
            throw new ImmutableContentIntegrityException("The prepared Policy has no valid current content.");
        var realm = after.TenantId.ToString();
        var body = await content.WriteJsonAsync(realm, Uuid.CreateVersion5(after.Id,
            PolicyFactContent.ContentSchema + ":" + AuthoredIntentDigest.Compute(current)),
            PolicyFactContent.ContentSchema, current, ct).ConfigureAwait(false);
        var header = after.Header(body);
        var state = after.Authority(header);
        var authority = await content.WriteJsonAsync(realm, Uuid.CreateVersion5(after.Id,
            PolicyFactContent.AuthoritySchema + ":" + AuthoredIntentDigest.Compute(state)),
            PolicyFactContent.AuthoritySchema, state, ct).ConfigureAwait(false);
        var change = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), PolicyFactContent.ChangeSchema,
            mutation, ct).ConfigureAwait(false);
        return new FrozenPolicyMutation(header, change, authority);
    }
}''')
new(CORE+'FrozenPolicyMutation.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Policies;

public sealed record FrozenPolicyMutation(PolicyAuthorityHeader Header, ImmutableContentRef Change, ImmutableContentRef Authority);''')

scopes='\n'.join(f'        {n}Content item => item.TenantId == header.TenantId && item.ProgramId == header.ProgramId && item.PolicyId == header.PolicyId,' for n in EVENTS)
new(CORE+'PolicyFactContent.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public static class PolicyFactContent
{
    public const string ContentSchema = "policy-authored-content.v1";
    public const string ChangeSchema = "policy-mutation-change.v1";
    public const string AuthoritySchema = "policy-current-authority.v1";

    public static async ValueTask<PolicyMutationContent> ReadChangeAsync(IImmutableContentStore content,
        IPolicyFact fact, CancellationToken ct = default)
    {
        ValidateScope(fact);
        if (fact.Change.Schema != ChangeSchema || fact.FirstResponse is null || fact.OperationResult is null)
            throw new ImmutableContentIntegrityException("The Policy mutation has another content or response schema.");
        var mutation = await content.ReadJsonAsync<PolicyMutationContent>(fact.TenantId.ToString(), fact.Change, ct).ConfigureAwait(false);
        if (mutation.Change is null || !InScope(mutation.Change, fact.Header))
            throw new ImmutableContentIntegrityException("The Policy mutation has another exact owner scope.");
        DomainEvent expected;
        try
        {
            expected = PolicyFactFactory.Create(fact.Operation.CommandKind, fact.Header, fact.NativeSequence,
                fact.Operation, fact.Change, fact.Authority, fact.FirstResponse, fact.OperationResult, mutation);
        }
        catch (InvalidOperationException)
        {
            throw new ImmutableContentIntegrityException("The Policy mutation has no exact selected native receipt.");
        }
        if (fact is not DomainEvent original || original.GetType() != expected.GetType() ||
            ContentDigest.Sha256(original, original.GetType()) != ContentDigest.Sha256(expected, expected.GetType()))
            throw new ImmutableContentIntegrityException("The native Policy fact differs from its original immutable receipt.");
        var authored = mutation.Change switch
        {
            PolicyDraftCreatedContent created => created.Content,
            PolicyDraftRevisedContent revised => revised.Content,
            _ => null,
        };
        if (authored is not null && (PolicyRules.ValidateContent(authored) is not null || PolicyRules.Hash(authored) != fact.Header.Content.Sha256))
            throw new ImmutableContentIntegrityException("The Policy authored body differs from its native content reference.");
        return mutation;
    }

    public static ValueTask<PolicyContent> ReadDraftAsync(IImmutableContentStore content, IPolicyFact fact,
        CancellationToken ct = default) => ReadContentAsync(content, fact, ct);

    public static async ValueTask<PolicyContent> ReadContentAsync(IImmutableContentStore content, IPolicyFact fact,
        CancellationToken ct = default)
    {
        ValidateScope(fact);
        if (fact.Header.Content.Schema != ContentSchema)
            throw new ImmutableContentIntegrityException("The Policy content has another schema.");
        var body = await content.ReadJsonAsync<PolicyContent>(fact.TenantId.ToString(), fact.Header.Content, ct).ConfigureAwait(false);
        if (PolicyRules.ValidateContent(body) is not null)
            throw new ImmutableContentIntegrityException("The Policy body violates its authored content contract.");
        return body;
    }

    static void ValidateScope(IPolicyFact fact)
    {
        if (fact.Header is not { } header || fact.Operation is null || header.TenantId != fact.TenantId ||
            header.PolicyId == Uuid.Empty || header.ProgramId == Uuid.Empty ||
            fact.Operation.Owner != new EventStreamAddress(header.TenantId.ToString(), Policy.Area, header.PolicyId.ToString()))
            throw new ImmutableContentIntegrityException("The native Policy fact has another exact owner scope.");
    }

    internal static bool InScope(IPolicyMutationContent change, PolicyAuthorityHeader header) => change switch
    {
'''+scopes+'''
        _ => false,
    };
}''')

# Preserve the baseline-compatible RED byte artifact; add implementation files in the same offline manifest.
put(CORE+'Policy.cs',(p.OUT/'templates/Policy.cs').read_text())
fixed=(p.OUT/'after'/CORE/'PolicyRules.cs').read_text().replace('waiver?.WaiverId)\n);','waiver?.WaiverId));')
put(CORE+'PolicyRules.cs',fixed)

discard=(p.OUT/'after'/COMMON/'DiscardPolicyDraft.cs').read_text().replace('using Bdgrz.Compliance.Features.AccessControl;','using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.NativeOperations;').replace(': IRequest,',': IRequest<UnitResult>,')
put(COMMON+'DiscardPolicyDraft.cs',discard)

if __name__=='__main__':p.emit()

for file in ['PolicyReader','PolicyReadSnapshot','PolicyOperations']:
    template=(p.OUT/'templates'/f'{file}.cs').read_text().replace('descriptor.StatusCode','descriptor.HttpStatus')
    put(CORE+file+'.cs',template)
new(CORE+'PolicyReadFailure.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

static class PolicyReadFailure
{
    public static RequestError Of(ImmutableContentIntegrityException error) => new(RequestErrorKind.Conflict,
        "The Policy immutable content cannot be verified.", error is ImmutableContentUnavailableException);
}''')
new(CORE+'PolicySource.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public static class PolicySource
{
    public static async ValueTask<Result<PolicyReadSnapshot>> ReadAsync(PolicyReader reader,
        Uuid tenantId, Uuid programId, Uuid policyId, CancellationToken ct)
    {
        try
        {
            var policy = await reader.ReadAsync(tenantId, programId, policyId, ct).ConfigureAwait(false);
            return policy.IsVisible ? Result<PolicyReadSnapshot>.Success(policy)
                : Result<PolicyReadSnapshot>.Failure(new RequestError(RequestErrorKind.NotFound, "The policy was not found."));
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<PolicyReadSnapshot>.Failure(PolicyReadFailure.Of(failure));
        }
    }
    public static DateOnly Today(TimeProvider clock) => DateOnly.FromDateTime(clock.GetUtcNow().UtcDateTime);
}''')
new(CORE+'PolicyResponses.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

public static class PolicyResponses
{
    public const string Registration = "policy-registration.v1";
    public const string Decision = "policy-decision.v1";
    public const string Version = "policy-version.v1";
    public static string Schema(string kind) => kind switch
    {
        nameof(CreatePolicyDraft) or nameof(RevisePolicyDraft) or nameof(ProposePolicySuccessor) or nameof(ProposePolicyRetirement) => Registration,
        nameof(ReviewPolicyDraft) or nameof(ConfirmPolicyReview) or nameof(ApprovePolicyRetirement) => Decision,
        nameof(ApprovePolicy) => Version,
        nameof(DiscardPolicyDraft) => UnitResult.Schema,
        _ => throw new InvalidOperationException("The Policy result schema is not selected."),
    };
    public static ValueTask<FirstResponseDescriptor> FreezeAsync(IImmutableContentStore content, PolicyRules rules,
        string kind, Uuid command, CancellationToken ct = default) => kind switch
    {
        nameof(CreatePolicyDraft) or nameof(RevisePolicyDraft) or nameof(ProposePolicySuccessor) or nameof(ProposePolicyRetirement) =>
            FreezeAsync(content, rules.TenantId.ToString(), Registration,
                new PolicyRegistration(rules.Id, rules.Identifier!, rules.Revision), ct),
        nameof(ReviewPolicyDraft) or nameof(ConfirmPolicyReview) or nameof(ApprovePolicyRetirement) =>
            FreezeAsync(content, rules.TenantId.ToString(), Decision, rules.FindDecision(command)!, ct),
        nameof(ApprovePolicy) => FreezeAsync(content, rules.TenantId.ToString(), Version, rules.CurrentVersion!, ct),
        nameof(DiscardPolicyDraft) => FreezeAsync(content, rules.TenantId.ToString(), UnitResult.Schema, new UnitResult(), ct),
        _ => throw new InvalidOperationException("The Policy result schema is not selected."),
    };
    static async ValueTask<FirstResponseDescriptor> FreezeAsync<T>(IImmutableContentStore content, string realm,
        string schema, T value, CancellationToken ct) where T : notnull
    {
        var body = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), schema, value, ct).ConfigureAwait(false);
        return new FirstResponseDescriptor(200, ImmutableContentStoreExtensions.JsonMediaType, schema, new StandardResponseBody(body));
    }
}''')

mutations={
'CreatePolicyDraft':('PolicyRegistration','null','rules.Create(request.ProgramId, request.PolicyId, request.Identifier, request.Content, actor.Reference, actor.MemberId, at)',None),
'RevisePolicyDraft':('PolicyRegistration','request.ExpectedRevision','rules.Revise(request.ProgramId, request.ExpectedRevision, request.Content, actor.Reference, actor.MemberId, at)',None),
'DiscardPolicyDraft':('UnitResult','request.ExpectedRevision','rules.Discard(request.ProgramId, request.ExpectedRevision, request.Rationale, actor.Reference, at)',None),
'ConfirmPolicyReview':('PolicyDecisionView','request.ExpectedVersion','rules.ConfirmPeriodicReview(request.ProgramId, request.ExpectedVersion, request.CommandId, request.Rationale, actor.Reference, actor.MemberId, at)',None),
'ProposePolicySuccessor':('PolicyRegistration','request.ExpectedVersion','rules.ProposeSuccessor(request.ProgramId, request.ExpectedVersion, request.Content, actor.Reference, actor.MemberId, at)',None),
'ProposePolicyRetirement':('PolicyRegistration','request.ExpectedVersion','rules.ProposeRetirement(request.ProgramId, request.ExpectedVersion, request.EffectiveUntil, request.Rationale, actor.Reference, actor.MemberId, at)',None),
'ReviewPolicyDraft':('PolicyDecisionView','request.ExpectedRevision','rules.Review(request.ProgramId, request.ExpectedRevision, request.CommandId, request.Outcome, request.Rationale, actor.Reference, actor.MemberId, at, proof)','Review'),
'ApprovePolicy':('PolicyVersionView','request.ExpectedRevision','rules.Approve(request.ProgramId, request.ExpectedRevision, request.CommandId, request.AcceptedReviewDecisionId, request.EffectiveFrom, request.Major, request.Rationale, request.ImpactDigest, actor.Reference, actor.MemberId, at, proof)','Approve'),
'ApprovePolicyRetirement':('PolicyDecisionView','request.ExpectedRevision','rules.ApproveRetirement(request.ProgramId, request.ExpectedRevision, request.CommandId, request.AcceptedReviewDecisionId, request.Rationale, actor.Reference, actor.MemberId, at, proof)','Approve')}
for kind,(result,gate,call,waiverAction) in mutations.items():
    personal=kind in ['ReviewPolicyDraft','ApprovePolicy','ApprovePolicyRetirement','ConfirmPolicyReview']
    ctor='PolicyOperations operations'+(', PolicyImpactService impact' if kind=='ApprovePolicy' else '')
    body='''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Policies;

'''+f'''public sealed class {kind}Handler({ctor}) : IRequestHandler<{kind}, {result}>
{{
    public ValueTask<Result<{result}>> HandleAsync(IRequestContext<{kind}> context, CancellationToken ct)
    {{
'''
    if personal:body+=f'''        if (context.Invocation is not HttpInvocation || RequestActor.IsSystem(context.Actor) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out _))
            return ValueTask.FromResult(Result<{result}>.Failure(new RequestError(RequestErrorKind.Forbidden,
                "Policy sign-off requires personal HTTP submission.")));
'''
    body+='        var request = context.Request;\n'
    if kind=='CreatePolicyDraft':body+=f'''        if (request.PolicyId != Policy.IdFor(request.TenantId, request.ProgramId, request.Identifier))
            return ValueTask.FromResult(Result<{result}>.Failure(new RequestError(RequestErrorKind.Validation,
                "The authored PolicyId must equal the deterministic normalized identifier identity.")));
'''
    if waiverAction:body+='        SeparationOfDutiesWaiverProof? proof = null;\n'
    idexpr='request.PolicyId' if kind=='CreatePolicyDraft' else 'request.CommandId'
    body+=f'''        return operations.ExecuteAsync<{kind}, {result}>(context, request.TenantId, request.ProgramId,
            request.PolicyId, {idexpr}, nameof({kind}), {gate},
'''
    if not waiverAction:body+='            (_, _, _, _) => PolicyOperations.Ready(),\n'
    else:
        body+='            async (snapshot, actor, at, token) =>\n            {\n'
        if kind=='ApprovePolicy':body+='''                if (snapshot.DraftPredecessorVersion is not null)
                {
                    var preview = await impact.PreviewAsync(request.TenantId, request.ProgramId, request.PolicyId,
                        request.ExpectedRevision, token).ConfigureAwait(false);
                    if (!preview.IsSuccess)
                        return Result.Failure(preview.Error!);
                    if (!StringComparer.Ordinal.Equals(preview.Value.Digest, request.ImpactDigest))
                        return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The impact preview changed. Reload it before approving."));
                }
'''
        body+=f'''                var resolved = await operations.ResolveWaiverAsync(request.TenantId, request.SeparationOfDutiesWaiverId,
                    actor.MemberId, request.PolicyId, snapshot.Revision, SeparationOfDutiesActions.{waiverAction}, at, token).ConfigureAwait(false);
                if (!resolved.IsSuccess)
                    return Result.Failure(resolved.Error!);
                proof = resolved.Value;
                return Result.Success;
            }},
'''
    if kind=='CreatePolicyDraft':body+=f'''            (rules, actor, at) =>
            {{
                var result = {call};
                return result.IsSuccess ? Result.Success : Result.Failure(result.Error!);
            }}, null, ct);
'''
    else:body+=f'''            (rules, actor, at) => PolicyOperations.Outcome({call}), {('() => proof' if waiverAction else 'null')}, ct);
'''
    body+='    }\n}\n';put(CORE+kind+'Handler.cs',body)

if __name__=='__main__':p.emit()

# Waiver proofs stay in transient preparation and immutable mutation content, never in the compact owner.
rules=(p.OUT/'after'/CORE/'PolicyRules.cs').read_text()
rules=rules.replace('    readonly List<IPolicyMutationContent> _pendingChanges = [];','    readonly List<IPolicyMutationContent> _pendingChanges = [];\n    readonly Dictionary<Uuid, SeparationOfDutiesWaiverProof> _waivers = [];')
for name in ['PolicyReviewedContent','PolicyApprovedContent','PolicyRetiredContent']:
    token='        RaiseEvent(new '+name+'('
    rules=rules.replace(token,'        if (waiver is not null)\n            _waivers[waiver.WaiverId] = waiver;\n'+token)
rules=rules.replace('    internal PolicyContent? CurrentContent => _draft;','''    internal SeparationOfDutiesWaiverProof? WaiverFor(IPolicyMutationContent change)
    {
        var id = change switch
        {
            PolicyReviewedContent review => review.SeparationOfDutiesWaiverId,
            PolicyApprovedContent approval => approval.SeparationOfDutiesWaiverId,
            PolicyRetiredContent retired => retired.SeparationOfDutiesWaiverId,
            _ => null,
        };
        return id is { } waiver ? _waivers.GetValueOrDefault(waiver) : null;
    }
    internal PolicyContent? CurrentContent => _draft;''')
put(CORE+'PolicyRules.cs',rules)
put('test/Compliance.Tests/Testing/PolicySeeds.cs',(p.OUT/'templates/PolicySeeds.cs').read_text())
if __name__=='__main__':p.emit()

# Fixture API overload keeps the sixth cancellation token shape used by malformed projection adapters.
seeds=(p.OUT/'after/test/Compliance.Tests/Testing/PolicySeeds.cs').read_text().replace('    public static async Task<DomainEvent> FreezeAsync(','''    public static Task<DomainEvent> FreezeAsync(IImmutableContentStore content, PolicyRules after,
        IPolicyMutationContent change, OperationProvenance operation, long nativeSequence, CancellationToken ct) =>
        FreezeAsync(content, after, change, operation, nativeSequence, null, ct);

    public static async Task<DomainEvent> FreezeAsync(''').replace('Metadata(change, current)','Metadata(change)').replace('Metadata(IPolicyMutationContent change, PolicyRules before)','Metadata(IPolicyMutationContent change)')
put('test/Compliance.Tests/Testing/PolicySeeds.cs',seeds)
ops=(p.OUT/'after'/CORE/'PolicyOperations.cs').read_text().replace('    public async ValueTask<Result<TOut>> ExecuteAsync','    public IAggregateReader Sources => reader;\n    public TimeProvider Clock => clock;\n\n    public async ValueTask<Result<TOut>> ExecuteAsync')
put(CORE+'PolicyOperations.cs',ops)

fixture=Path('/tmp/compliance-control-owners-prepared/work/test/Compliance.Tests/Testing/ControlSourceFixture.cs').read_text()
for old,newname in [('ControlSourceFixture','PolicySourceFixture'),('ControlReader','PolicyReader'),('ControlOperations','PolicyOperations'),('ControlRules','PolicyRules'),('ControlSeeds','PolicySeeds'),('ControlDraft','Policy'),('Controls','Policies'),('Features.Controls','Features.Policies')]:fixture=fixture.replace(old,newname)
put('test/Compliance.Tests/Testing/PolicySourceFixture.cs',fixture)

personal_path='test/Compliance.Tests/Features/Policies/PersonalPolicyDecisionTransportTests.cs'
personal=(p.OUT/'after'/personal_path).read_text()
personal=personal.replace('new Policy(', 'new PolicyRules(').replace('public Task<Policy> ReadAsync()', 'public Task<PolicyRules> ReadAsync()').replace('.CommittedStreamPosition','.SourcePhysicalPosition')
personal=personal.replace('public Uuid PolicyId { get; } = Uuid.CreateVersion4();','public Uuid PolicyId => Policy.IdFor(Tenant, Program, "POL-TRANSPORT");')
for kind in ['ConfirmPolicyReview','RevisePolicyDraft','ApprovePolicyRetirement']:
    personal=personal.replace('new '+kind+'(', 'new '+kind+'(Uuid.CreateVersion4(), ')
personal=personal.replace('new CreatePolicyDraft(fixture.Tenant, fixture.Program, "POL-ESCAPED",','new CreatePolicyDraft(Policy.IdFor(fixture.Tenant, fixture.Program, "POL-ESCAPED"), fixture.Tenant, fixture.Program, "POL-ESCAPED",')
marker='''        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<IRequestBus>().DispatchAsync(request,'''
replacement='''        request = request switch
        {
            ConfirmPolicyReview confirm => (IRequest<T>)(object)(confirm with { CommandId = commandId }),
            RevisePolicyDraft revise => (IRequest<T>)(object)(revise with { CommandId = commandId }),
            _ => request,
        };
        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<IRequestBus>().DispatchAsync(request,'''
assert marker in personal;personal=personal.replace(marker,replacement)
put(personal_path,personal)

life_path='test/Compliance.Tests/Features/Policies/PolicyLifecycleTests.cs';life=source(life_path)
# Pure content/state rule scenarios stay explicit pure preparations; persistence scenario below uses real native facts and immutable store.
life=re.sub(r'\bPolicy\b','PolicyRules',life)
life='using Bdgrz.Compliance.Tests.Testing;\n'+life
life=life.replace('new PolicyRules(TenantId, Uuid.CreateVersion4())','new PolicyRules(TenantId, Policy.IdFor(TenantId, ProgramId, "POL-REL"))',1)
life=life.replace('new PolicyRules(TenantId, Uuid.CreateVersion4())','new PolicyRules(TenantId, Policy.IdFor(TenantId, ProgramId, "POL-REV"))',1)
life=life.replace('public void ShouldReplaySameVersionsAndDecisionsGivenRoundTrippedEvents()','public async Task ShouldReplaySameVersionsAndDecisionsGivenRoundTrippedEvents()')
old='''        var events = new AggregateScenario<PolicyRules>(source).PendingEvents;
        var seeded = events.Select((ev, index) =>
            DomainEventSeed.Attach(RoundTrip(ev), source.Id, (ulong)index + 1)).ToArray();

        // Act
        var replayed = new AggregateScenario<PolicyRules>(new PolicyRules(TenantId, source.Id))
            .Given(seeded).Aggregate;'''
newtext='''        await using var fixture = new PolicySourceFixture();
        await fixture.SeedAsync(source);
        var events = await fixture.FactsAsync(TenantId, source.Id);
        var seeded = events.Select((ev, index) =>
            DomainEventSeed.Attach(RoundTrip(ev), source.Id, (ulong)index + 1)).ToArray();

        // Act
        var owner = new AggregateScenario<Policy>(new Policy(TenantId, source.Id)).Given(seeded).Aggregate;
        var replayed = await fixture.Policies.ReadAsync(TenantId, ProgramId, source.Id);
        Assert.Equal(owner.Header, replayed.Owner.Header);
        Assert.Equal(events.Count, owner.NativeSequence);'''
assert old in life;life=life.replace(old,newtext)
life=life.replace('static SeparationOfDutiesWaiver CreateWaiver','static SeparationOfDutiesWaiverProof CreateWaiver').replace('        return waiver;','        return ControlTestWaivers.Proof(waiver);').replace('Assert.Equal(valid.Id,','Assert.Equal(valid.WaiverId,')
put(life_path,life)
p.changes[life_path]['phase']='migrated-tests'
p.changes['test/Compliance.Tests/Testing/PolicySeeds.cs']['phase']='migrated-tests'
p.changes['test/Compliance.Tests/Testing/PolicySourceFixture.cs']['phase']='migrated-tests'

if __name__=='__main__':p.emit()

put('test/Compliance.Tests/Features/Policies/PolicyNativeContentTests.cs',(p.OUT/'templates/PolicyNativeContentTests.cs').read_text())
p.changes['test/Compliance.Tests/Features/Policies/PolicyNativeContentTests.cs']['phase']='migrated-tests'
if __name__=='__main__':p.emit()

ops=(p.OUT/'after'/CORE/'PolicyOperations.cs').read_text().replace('using Bdgrz.Compliance.Features.Proofs;','using Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Features.Versioning;').replace('mutation = new PolicyMutationContent(', 'mutation = new(')
put(CORE+'PolicyOperations.cs',ops)
owner=(p.OUT/'after'/CORE/'Policy.cs').read_text().replace('Acceptance = new NativeAcceptance(selectedCommandId);','Acceptance = new(selectedCommandId);').replace('using Bdgrz.Compliance.Features.Versioning;\n','')
owner=owner.replace('var decision = mutation.Change switch','(Uuid Actor, string Action, Uuid? Waiver, bool Approval) decision = mutation.Change switch')
put(CORE+'Policy.cs',owner)
rules=(p.OUT/'after'/CORE/'PolicyRules.cs').read_text().replace('using Bdgrz.Compliance.Features.NativeOperations;\n','')
put(CORE+'PolicyRules.cs',rules)
# Keep production wiring reviewable as separate deltas; parent owns the shared files.
program=source('src/Compliance.App/Program.cs');program_after=program
routes={
'CreatePolicyDraft':('PolicyRegistration','/api/v1/tenants/{tenant_id}/programs/{program_id}/policies/{policy_id}'),
'DiscardPolicyDraft':('UnitResult','/api/v1/tenants/{tenant_id}/programs/{program_id}/policies/{policy_id}/draft/discards/{command_id}'),
'ProposePolicySuccessor':('PolicyRegistration','/api/v1/tenants/{tenant_id}/programs/{program_id}/policies/{policy_id}/successors/{command_id}'),
'ConfirmPolicyReview':('PolicyDecisionView','/api/v1/tenants/{tenant_id}/programs/{program_id}/policies/{policy_id}/periodic-reviews/{command_id}'),
'ProposePolicyRetirement':('PolicyRegistration','/api/v1/tenants/{tenant_id}/programs/{program_id}/policies/{policy_id}/retirement-proposals/{command_id}'),
'ApprovePolicyRetirement':('PolicyDecisionView','/api/v1/tenants/{tenant_id}/programs/{program_id}/policies/{policy_id}/retirements/{command_id}'),
}
for kind,(result,route) in routes.items():
 pattern=r'app\.MapPortiaPost<'+kind+r'(?:, [^>]+)?>\(\s*"[^"]+"\)'
 program_after,count=re.subn(pattern,f'app.MapPortiaPut<{kind}, {result}>(\n            "{route}")',program_after)
 assert count==1,(kind,count)
(p.OUT/'shared-program-routes.patch').write_text(p.diff('src/Compliance.App/Program.cs',program,program_after))
context=source('src/Compliance.Core/ComplianceCoreJsonContext.cs')
newtypes=['PolicyAuthorityHeader','PolicyAuthorityContent','PolicyMutationContent','IPolicyMutationContent']+[n+'Content' for n in EVENTS]
context_after=context
anchor='[JsonSerializable(typeof(PolicyDraftCreated))]'
assert anchor in context
context_after=context.replace(anchor,''.join(f'[JsonSerializable(typeof({n}))]\n' for n in newtypes)+anchor)
(p.OUT/'shared-json-contracts.patch').write_text(p.diff('src/Compliance.Core/ComplianceCoreJsonContext.cs',context,context_after))
(p.OUT/'shared-wiring-required.json').write_text(json.dumps({'sourceDI':'Peer owns separate registration delta: AddScoped<PolicyReader>(); AddScoped<PolicyOperations>(); directory ctor changes in peer artifact.', 'json':newtypes,'routes':routes,'retainedRoute':'Existing RevisePolicyDraft PUT .../policies/{policy_id}/draft remains with body CommandId; accepted catalog does not select a replacement URI.', 'unitWire':'DiscardPolicyDraft is IRequest<UnitResult>; actual mapper must use MapPortiaPut<DiscardPolicyDraft,UnitResult> for200{}.'},indent=2)+'\n')
if __name__=='__main__':p.emit()

owner=(p.OUT/'after'/CORE/'Policy.cs').read_text()
needle='''        Require(actor == businessActor, "The original Policy actor differs from its native admission actor.");'''
replacement=needle+'''
        var snapshot = value switch
        {
            PolicyDraftCreated item => item.Actor,
            PolicyDraftRevised item => item.Actor,
            PolicyReviewed item => item.Actor,
            PolicyApproved item => item.Actor,
            PolicyPeriodicReviewConfirmed item => item.Actor,
            PolicyRetirementProposed item => item.Actor,
            PolicyRetired item => item.Actor,
            PolicyDraftDiscarded item => item.Actor,
            _ => null,
        };
        Require(snapshot is not null && (snapshot.Kind == "member" ? snapshot.Id == operation.Actor.Id :
            snapshot.Kind == "system_process" && value is PolicyDraftCreated or PolicyDraftRevised or PolicyDraftDiscarded),
            "The original Policy actor snapshot has another personal identity.");'''
assert needle in owner;owner=owner.replace(needle,replacement)
put(CORE+'Policy.cs',owner)

native=(p.OUT/'after/test/Compliance.Tests/Features/Policies/PolicyNativeContentTests.cs').read_text().replace('[InlineData("actor")]','[InlineData("actor")]\n    [InlineData("actor_snapshot")]')
native=native.replace('''        if (defect == "actor")
            fact = fact with { ActorMemberId = actor };''','''        if (defect == "actor")
            fact = fact with { ActorMemberId = actor };
        if (defect == "actor_snapshot")
            fact = fact with { Actor = ActorReference.ForMember(actor, "Another member") };''')
marker='    static PolicyContent Content(string title)'
extra='''    [Fact]
    public async Task ShouldRejectAuthoredPolicyIdGivenIdentifierIdentityMismatch()
    {
        // Arrange
        await using var source = new PolicySourceFixture();
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var authored = Uuid.CreateVersion4();
        var request = new CreatePolicyDraft(authored, tenant, program, "NORMALIZED-ID", Content("Exact identity"));

        // Act
        var result = await new CreatePolicyDraftHandler(source.Operations()).HandleAsync(
            PolicySourceFixture.Context(request, Uuid.CreateVersion4()), CancellationToken.None);
        var owner = await source.Reader.HydrateAsync(new Policy(tenant, authored));

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Validation, result.Error!.Kind);
        Assert.False(owner.IsCreated);
        Assert.Empty(await source.FactsAsync(tenant, authored));
    }

'''
assert marker in native;native=native.replace(marker,extra+marker)
put('test/Compliance.Tests/Features/Policies/PolicyNativeContentTests.cs',native)
if __name__=='__main__':p.emit()

rules=(p.OUT/'after'/CORE/'PolicyRules.cs').read_text().replace('    static string? ValidateIdentifier(string identifier)', '    internal static string? ValidateIdentifier(string identifier)')
put(CORE+'PolicyRules.cs',rules)
owner=(p.OUT/'after'/CORE/'Policy.cs').read_text().replace('header.Identifier == NormalizeIdentifier(header.Identifier) && header.IsCreated',
    'header.Identifier == NormalizeIdentifier(header.Identifier) && PolicyRules.ValidateIdentifier(header.Identifier) is null && header.IsCreated')
put(CORE+'Policy.cs',owner)
if __name__=='__main__':p.emit()

owner=(p.OUT/'after'/CORE/'Policy.cs').read_text().replace('PolicyDraftDiscarded item when item.Actor.Kind == "member" && Uuid.TryParse(item.Actor.Id, out var id) => id,',
    'PolicyDraftDiscarded item when item.Actor is { Kind: "member" } snapshot && Uuid.TryParse(snapshot.Id, out var id) => id,')
owner=owner.replace('created.PolicyId == Id && created.Identifier == header.Identifier && created.ContentSha256 == header.Content.Sha256 &&',
    'created.PolicyId == Id && created.Identifier == header.Identifier && created.Content == header.Content && created.ContentSha256 == header.Content.Sha256 &&')
owner=owner.replace('revised.Revision == before.Revision + 1 && revised.ContentSha256 == header.Content.Sha256,',
    'revised.Revision == before.Revision + 1 && revised.Content == header.Content && revised.ContentSha256 == header.Content.Sha256,')
put(CORE+'Policy.cs',owner)
facts=(p.OUT/'after'/CORE/'PolicyFactContent.cs').read_text().replace('header.PolicyId == Uuid.Empty || header.ProgramId == Uuid.Empty ||',
    'header.PolicyId == Uuid.Empty || header.ProgramId == Uuid.Empty || header.Content is null || fact.Change is null || fact.Authority is null ||')
put(CORE+'PolicyFactContent.cs',facts)
if __name__=='__main__':p.emit()

owner=(p.OUT/'after'/CORE/'Policy.cs').read_text().replace('item.Actor is { Kind: "member" } snapshot && Uuid.TryParse(snapshot.Id, out var id)',
    'item.Actor is { Kind: "member" } discardActor && Uuid.TryParse(discardActor.Id, out var id)').replace('snapshot.Kind == "system_process" && value is PolicyDraftCreated or PolicyDraftRevised or PolicyDraftDiscarded)',
    'snapshot.Kind == "system_process" && (value is PolicyDraftCreated or PolicyDraftRevised or PolicyDraftDiscarded))')
put(CORE+'Policy.cs',owner)
if __name__=='__main__':p.emit()

native=(p.OUT/'after/test/Compliance.Tests/Features/Policies/PolicyNativeContentTests.cs').read_text()
marker='    [Fact]\n    public async Task ShouldRejectAuthoredPolicyIdGivenIdentifierIdentityMismatch()'
extra='''    [Fact]
    public async Task ShouldConflictWithoutAppendGivenPreparationBeforeSameRevisionPolicyReview()
    {
        // Arrange
        await using var source = new PolicySourceFixture();
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var author = Uuid.CreateVersion4();
        var id = Policy.IdFor(tenant, program, "NATIVE-CUT");
        var rules = new PolicyRules(tenant, id);
        Assert.True(rules.Create(program, id, "NATIVE-CUT", Content("Exact cut"), ActorReference.ForMember(author, "Author"),
            author, source.Clock.Now).IsSuccess);
        await source.SeedAsync(rules);
        var preparedOwner = await source.Reader.HydrateAsync(new Policy(tenant, id));
        rules = await source.Policies.RulesAsync(tenant, program, id);
        var before = rules.Authority(preparedOwner.Header!);
        var reviewer = Uuid.CreateVersion4();
        var command = Uuid.CreateVersion4();
        Assert.Null(rules.Review(program, 1, command, "accept", "Prepared", ActorReference.ForMember(reviewer, "Reviewer"),
            reviewer, source.Clock.Now));
        var mutation = new PolicyMutationContent(rules.PendingChanges[0]);
        var operation = OwnerProvenance.For(preparedOwner, command, nameof(ReviewPolicyDraft),
            ActorReference.ForMember(reviewer, reviewer.ToString()), id.ToString(), 1,
            AuthoredIntentDigest.Compute(new ReviewPolicyDraft(command, tenant, program, id, 1, "accept", "Prepared")), source.Clock.Now);
        var fact = await PolicySeeds.FreezeAsync(source.Content, rules, mutation.Change, operation, 2);
        var after = rules.Authority(((IPolicyFact)fact).Header);
        var concurrent = await source.Policies.RulesAsync(tenant, program, id);
        var other = Uuid.CreateVersion4();
        Assert.Null(concurrent.Review(program, 1, Uuid.CreateVersion4(), "request_changes", "Concurrent",
            ActorReference.ForMember(other, "Other reviewer"), other, source.Clock.Now));
        await source.SeedAsync(concurrent);
        var current = await source.Reader.HydrateAsync(new Policy(tenant, id));
        var physical = current.CommittedStreamPosition;

        // Act
        var result = current.Append(fact, preparedOwner.NativeSequence, preparedOwner.CommittedStreamPosition, mutation, before, after);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error!.Kind);
        Assert.True(result.Error.IsTransient);
        Assert.Equal(1, current.Revision);
        Assert.Equal(2, current.NativeSequence);
        Assert.Equal(physical, current.CommittedStreamPosition);
        Assert.Equal(2, (await source.FactsAsync(tenant, id)).Count);
    }

'''
assert marker in native;native=native.replace(marker,extra+marker)
put('test/Compliance.Tests/Features/Policies/PolicyNativeContentTests.cs',native)
if __name__=='__main__':p.emit()

owner=(p.OUT/'after'/CORE/'Policy.cs').read_text()
owner='using System.Diagnostics.CodeAnalysis;\nusing System.Globalization;\n'+owner
owner=owner.replace('Uuid.Parse(operation.Actor.Id)','Uuid.Parse(operation.Actor.Id, CultureInfo.InvariantCulture)')
owner=owner.replace('snapshot.Kind == "member" ? snapshot.Id == operation.Actor.Id :',
    'snapshot.Kind == "member" ? Uuid.TryParse(snapshot.Id, out var snapshotId) && snapshotId == actor :')
owner=owner.replace('static void Require(bool condition, string message)','static void Require([DoesNotReturnIf(false)] bool condition, string message)')
needle='''        if (_header is null)
        {
            Require(value is PolicyDraftCreated'''
replacement='''        var recordedAt = value switch
        {
            PolicyDraftCreated item => item.ChangedAt,
            PolicyDraftRevised item => item.ChangedAt,
            PolicyReviewed item => item.DecidedAt,
            PolicyApproved item => item.DecidedAt,
            PolicyPeriodicReviewConfirmed item => item.DecidedAt,
            PolicyRetirementProposed item => item.ProposedAt,
            PolicyRetired item => item.DecidedAt,
            PolicyDraftDiscarded item => item.DiscardedAt,
            _ => DateTimeOffset.MinValue,
        };
        Require(recordedAt == operation.AcceptedAt, "The Policy receipt must retain its original native acceptance instant.");
        if (_header is null)
        {
            Require(value is PolicyDraftCreated'''
assert needle in owner;owner=owner.replace(needle,replacement)
put(CORE+'Policy.cs',owner)
factory=(p.OUT/'after'/CORE/'PolicyFactFactory.cs').read_text()
for event in EVENTS:
 factory=factory.replace(f'    static DomainEvent {event}(',f'    static {event} {event}(').replace(f'        return new {event}(', '        return new(')
put(CORE+'PolicyFactFactory.cs',factory)
seeds=(p.OUT/'after/test/Compliance.Tests/Testing/PolicySeeds.cs').read_text()
seeds='using System.Globalization;\n'+seeds
seeds=seeds.replace('Uuid.Parse(item.Actor.Id)','Uuid.Parse(item.Actor.Id, CultureInfo.InvariantCulture)')
put('test/Compliance.Tests/Testing/PolicySeeds.cs',seeds)
fixture=(p.OUT/'after/test/Compliance.Tests/Testing/PolicySourceFixture.cs').read_text().replace('public static RequestContext<T> Context<T>', 'public static Cntryl.Portia.RequestContext<T> Context<T>')
put('test/Compliance.Tests/Testing/PolicySourceFixture.cs',fixture)
if __name__=='__main__':p.emit()
