from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path('/Users/jrepanich/Code/bdgrz/compliance-core')
OUT = Path('/tmp/compliance-s32-policy-prepared')
CONTROL = Path('/tmp/compliance-control-consumers-prepared')
changes = {}


def original(path):
    target = OUT / 'before' / path
    if target.exists():
        return target.read_text()
    current = (ROOT / path).read_text()
    control = CONTROL / 'after' / path
    if control.exists():
        row = next(row for row in json.loads((CONTROL / 'manifest.json').read_text()) if row['path'] == path)
        digest = hashlib.sha256(current.encode()).hexdigest()
        if digest == row['beforeSha256']:
            current = control.read_text()
        elif digest != row['afterSha256']:
            raise AssertionError('Control baseline changed: ' + path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(current)
    return current


def put(path, text, phase='implementation'):
    if path not in changes:
        before = original(path) if (ROOT / path).exists() else None
        changes[path] = dict(before=before, phase=phase)
    target = OUT / 'after' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)


def diff(path, before, after):
    head = f'diff --git a/{path} b/{path}\n'
    if before is None:
        head += 'new file mode 100644\n'
    return head + ''.join(difflib.unified_diff((before or '').splitlines(True), after.splitlines(True),
        fromfile='/dev/null' if before is None else 'a/' + path, tofile='b/' + path))


test_path = 'test/Compliance.Tests/Features/Policies/PersonalPolicyDecisionTransportTests.cs'
before = original(test_path)
regressions = '''    [Fact]
    public async Task ShouldReturnOriginalPeriodicReviewGivenExactHandlerRetry()
    {
        // Arrange
        await using var fixture = await Fixture.CreateAsync("periodic_review");
        var source = await fixture.ReadAsync();
        var commandId = Uuid.CreateVersion4();
        var request = new ConfirmPolicyReview(fixture.Tenant, fixture.Program, fixture.PolicyId,
            source.CurrentVersion!.Version, "The approved policy remains current.");
        var first = await IdentifiedHttpAsync(fixture.Provider, fixture.Reviewer, request, commandId);
        Assert.True(first.IsSuccess, first.Error?.Message);
        var accepted = await fixture.ReadAsync();

        // Act
        var replay = await IdentifiedHttpAsync(fixture.Provider, fixture.Reviewer, request, commandId);
        var retained = await fixture.ReadAsync();

        // Assert
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(first.Value, replay.Value);
        Assert.Equal(accepted.CommittedStreamPosition, retained.CommittedStreamPosition);
        Assert.Equal(accepted.ReadDecisions().Count, retained.ReadDecisions().Count);
    }

    [Fact]
    public async Task ShouldReturnOriginalRevisionRegistrationGivenHandlerRetryAfterLaterEdit()
    {
        // Arrange
        await using var fixture = await Fixture.CreateAsync("review");
        var source = await fixture.ReadAsync();
        var commandId = Uuid.CreateVersion4();
        var request = new RevisePolicyDraft(fixture.Tenant, fixture.Program, fixture.PolicyId, 1,
            source.DraftContent! with { Body = "First revised policy body." });
        var first = await IdentifiedHttpAsync(fixture.Provider, fixture.Author, request, commandId);
        Assert.True(first.IsSuccess, first.Error?.Message);
        var later = await IdentifiedHttpAsync(fixture.Provider, fixture.Author,
            new RevisePolicyDraft(fixture.Tenant, fixture.Program, fixture.PolicyId, 2,
                request.Content with { Body = "A later independent edit." }), Uuid.CreateVersion4());
        Assert.True(later.IsSuccess, later.Error?.Message);
        var advanced = await fixture.ReadAsync();

        // Act
        var replay = await IdentifiedHttpAsync(fixture.Provider, fixture.Author, request, commandId);
        var retained = await fixture.ReadAsync();

        // Assert
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(first.Value, replay.Value);
        Assert.Equal(2, replay.Value.Revision);
        Assert.Equal(3, retained.Revision);
        Assert.Equal("A later independent edit.", retained.DraftContent!.Body);
        Assert.Equal(advanced.CommittedStreamPosition, retained.CommittedStreamPosition);
    }

    [Fact]
    public async Task ShouldAcceptLegalEscapedBodyGivenCreatePolicyHandler()
    {
        // Arrange
        await using var fixture = await Fixture.CreateAsync("review");
        var body = new string('<', Policy.MaximumBodyLength);
        var request = new CreatePolicyDraft(fixture.Tenant, fixture.Program, "POL-ESCAPED",
            new PolicyContent("Escaped body", "Preserve complete authored material", PolicyAudience.CoreSecurity,
                null, 12, body, null, "Security owner", []));

        // Act
        var result = await SendHttpAsync(fixture.Provider, fixture.Author, request);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        var retained = await ProgramManagementServices.HydrateAsync(fixture.Provider,
            new Policy(fixture.Tenant, result.Value.PolicyId));
        Assert.Equal(body, retained.DraftContent!.Body);
        Assert.Equal(1, retained.Revision);
    }

    static async Task<Result<T>> IdentifiedHttpAsync<T>(IServiceProvider provider, Uuid user,
        IRequest<T> request, Uuid commandId)
    {
        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<IRequestBus>().DispatchAsync(request,
            new RequestDispatchContext(ProgramManagementServices.Actor(user),
                new HttpInvocation("POST", "/synthetic/policy/decision", "/synthetic/policy/decision", "synthetic"),
                new RequestMetadata(commandId, commandId)), CancellationToken.None);
    }

'''
marker = '    [Fact]\n    public async Task ShouldReturnFirstApprovalBodyGivenExactRetryAfterPolicyRetirement()'
assert before.count(marker) == 1
red = before.replace(marker, regressions + marker)
put(test_path, red, 'tests')
changes[test_path]['red'] = red


def emit():
    phases = {'tests': [], 'implementation': [], 'migrated-tests': []}
    manifest = []
    for path, row in sorted(changes.items()):
        after = (OUT / 'after' / path).read_text()
        if 'red' in row:
            phases['tests'].append(diff(path, row['before'], row['red']))
            if row['red'] != after:
                phases['migrated-tests'].append(diff(path, row['red'], after))
        else:
            phases[row['phase']].append(diff(path, row['before'], after))
        manifest.append(dict(path=path, phase=row['phase'], hasBehavioralRedStage='red' in row,
            beforeSha256=hashlib.sha256(row['before'].encode()).hexdigest() if row['before'] is not None else None,
            afterSha256=hashlib.sha256(after.encode()).hexdigest()))
    for phase, parts in phases.items():
        (OUT / (phase + '.patch')).write_text(''.join(parts))
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print('Prepared files:', len(manifest))


if __name__ == '__main__':
    emit()
