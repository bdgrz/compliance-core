from pathlib import Path
import tree_sitter,tree_sitter_c_sharp,json,collections,hashlib,subprocess,tempfile
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core');out=Path('/tmp/compliance-s32-policy-prepared');after=out/'after';parser=tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()));known={};errors=[];calls=0;syntax=[];parsergaps=[]
def descend(n):
 yield n
 for c in n.children:yield from descend(c)
def sig(t,p):
 ps=[c for c in p.children if c.type=='parameter'];return(sum(b'=' not in t[c.start_byte:c.end_byte] for c in ps),len(ps))
for f in after.rglob('*.cs'):
 t=f.read_bytes();ast=parser.parse(t)
 for n in descend(ast.root_node):
  if n.type in ['record_declaration','class_declaration','constructor_declaration']:
   name=n.child_by_field_name('name');pars=next((c for c in n.children if c.type=='parameter_list'),None)
   if name and pars:known.setdefault(bytes(name.text).decode(),[]).append(sig(t,pars))
  if n.type=='ERROR':
   (parsergaps if bytes(n.text)==b',' else syntax).append({'path':str(f.relative_to(after)),'line':n.start_point.row+1,'text':bytes(n.text).decode()[:160]})
  elif n.is_missing or n.has_error and not any(c.has_error for c in n.children):
   bef=t[max(0,n.start_byte-8):n.start_byte];aft=t[n.start_byte:n.start_byte+4]
   (parsergaps if aft.startswith(b']') and bef.endswith(b'[') else syntax).append({'path':str(f.relative_to(after)),'line':n.start_point.row+1,'text':repr(bef+aft)})
for f in after.rglob('*.cs'):
 t=f.read_bytes()
 for n in descend(parser.parse(t).root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((c for c in n.children if c.type=='argument_list'),None)
  if typ is None or args is None:continue
  name=bytes(typ.text).decode().split('.')[-1]
  if name not in known:continue
  count=sum(c.type=='argument' for c in args.children);calls+=1
  if not any(lo<=count<=hi for lo,hi in known[name]):errors.append({'path':str(f.relative_to(after)),'line':n.start_point.row+1,'type':name,'arguments':count,'accepted':known[name]})
# Every original acceptance method stays in the owning two test classes, including the actual-handler RED additions.
removed=[];acceptance=[]
for rel in ['test/Compliance.Tests/Features/Policies/PolicyLifecycleTests.cs','test/Compliance.Tests/Features/Policies/PersonalPolicyDecisionTransportTests.cs']:
 def names(path):
  b=path.read_bytes();return [bytes(n.child_by_field_name('name').text).decode() for n in descend(parser.parse(b).root_node) if n.type=='method_declaration' and n.child_by_field_name('name') and bytes(n.child_by_field_name('name').text).decode().startswith('Should')]
 old=names(out/'before'/rel);new=names(after/rel);removed.extend((rel,n) for n in old if n not in new);acceptance.append({'path':rel,'original':len(old),'prepared':len(new)})
# Apply staged tests, implementation, then migrated tests into a plain directory and compare every prepared file.
validation=Path(tempfile.mkdtemp(prefix='compliance-policy-owner-verify-')).resolve()
manifest=json.loads((out/'manifest.json').read_text())
for row in manifest:
 baseline=out/'before'/row['path']
 if baseline.exists():
  dest=validation/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(baseline.read_bytes())
patches=[]
for name in ['tests.patch','implementation.patch','migrated-tests.patch']:
 result=subprocess.run(['git','apply','--unsafe-paths','--directory='+str(validation),str(out/name)],cwd=root,capture_output=True,text=True);patches.append({'patch':name,'exit':result.returncode,'error':result.stderr});assert result.returncode==0,result.stderr
mismatches=[]
for row in manifest:
 actual=(validation/row['path']).read_bytes()
 if actual!=(after/row['path']).read_bytes():mismatches.append(row['path'])
report={'files':len(manifest),'syntaxErrors':syntax,'knownParserGrammarFlags':parsergaps,'constructorsChecked':calls,'constructorArityErrors':errors,'originalAcceptanceNamesRemoved':removed,'acceptance':acceptance,'patchApplyChecks':patches,'reconstructedByteMismatches':mismatches,'validationDirectory':str(validation)}
(out/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='knownParserGrammarFlags'},indent=2));assert not errors and not syntax and not removed and not mismatches
