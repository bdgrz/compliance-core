from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
r=Path('/tmp/compliance-calendar-history-validation-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');s=Path('/tmp/compliance-source-use-reservations-prepared');shared='src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';test='test/Compliance.Tests/Features/Operations/TypeIICalendarMalformedHistoryTests.cs'
def sha(x):return hashlib.sha256(x).hexdigest()
def diff(p,a,b):return ''.join(difflib.unified_diff((a or b'').decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p if a is not None else '/dev/null',tofile='b/'+p))
pro={x['path']:x for x in json.loads((r/'baselines.json').read_text())};manifest=[];files={};groups={'implementation.patch':[],'shared-current.patch':[]}
for f in sorted((r/'work').rglob('*.cs')):
 p=str(f.relative_to(r/'work'));b=r/'base'/p;before=b.read_bytes() if b.exists() else None;after=f.read_bytes()
 assert not(repo/p).exists() or before is not None,('Missing original before for existing repository path',p)
 if before is not None:assert sha(before)==pro[p]['beforeSha256']
 files[p]={'before':before,'after':after}
 phase='already-integrated-red-test' if p==test else 'shared-current.patch' if p==shared else 'implementation.patch'
 if before!=after:groups[phase].append(diff(p,before,after))
 manifest.append({'path':p,'phase':phase,'beforeSha256':sha(before) if before is not None else None,'afterSha256':sha(after),'baselineSource':pro[p]['baselineSource'] if p in pro else None,'changedAfterParentRed':before!=after,'newAtRedPreparation':p==test})
for n,parts in groups.items():(r/n).write_text(''.join(parts))
future=(r/'future-work'/shared).read_bytes();sourceUseBefore=(s/'work'/shared).read_bytes();calendarBefore=(r/'work'/shared).read_bytes()
(r/'shared-after-source-use.patch').write_text(diff(shared,sourceUseBefore,future));(r/'source-use-after-calendar.patch').write_text(diff(shared,calendarBefore,future))
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');verified={}
orders={'parent-red-already-integrated':['implementation.patch','shared-current.patch'],'tests-first':['tests-red.patch','tests-format.patch','implementation.patch','shared-current.patch'],'all-final':['tests-final-addition.patch','implementation.patch','shared-current.patch']}
for mode,order in orders.items():
 t=Path(tempfile.mkdtemp(prefix='calendar-validate-reconstruction-',dir=r))
 try:
  for p,x in files.items():
   if x['before'] is not None and (mode=='parent-red-already-integrated' or p!=test):
    f=t/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(x['before'])
  for n in order:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/n)],cwd=t,capture_output=True,text=True);assert x.returncode==0,(mode,n,x.stdout,x.stderr)
  assert all((t/p).read_bytes()==x['after'] for p,x in files.items()),mode
  verified[mode]={'exactFiles':len(files),'patchOrder':order}
 finally:shutil.rmtree(t)
for mode,base,patches in [('calendar-then-source-use',(r/'base'/shared).read_bytes(),[r/'shared-current.patch',r/'source-use-after-calendar.patch']),('source-use-then-calendar',(s/'base'/shared).read_bytes(),[s/'shared.patch',r/'shared-after-source-use.patch'])]:
 t=Path(tempfile.mkdtemp(prefix='calendar-reader-composition-',dir=r))
 try:
  f=t/shared;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(base)
  for p in patches:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(p)],cwd=t,capture_output=True,text=True);assert x.returncode==0,(mode,str(p),x.stdout,x.stderr)
  assert f.read_bytes()==future,mode
  verified[mode]={'exactFiles':1,'combinedSharedSha256':sha(future),'patchOrder':[str(p) for p in patches]}
 finally:shutil.rmtree(t)
(r/'reconstruction.json').write_text(json.dumps(verified,indent=2)+'\n')
a=json.loads((r/'audit.json').read_text())
for k in ['syntaxErrors','constructorErrors','cancellationTokenNotLast','duplicateUsings','potentialMissingProofsUsing','removedAcceptanceNames','assertionCountDrops','existingRepositoryPathsMissingBefore']:assert not a[k],(k,a[k])
patches=['tests-red.patch','tests-format.patch','tests-final-addition.patch','implementation.patch','shared-current.patch','shared-after-source-use.patch','source-use-after-calendar.patch']
h={'root':str(r),'status':'FROZEN offline adversarial Calendar28 follow-on. Parent has executed six real pre-fix RED cases and owns runtime GREEN/build/analyzers/full tests/Jev/integration.','reviewPaths':len(files),'sourceChangesAfterParentRed':sum(x['before']!=x['after'] for x in files.values()),'newSourcePaths':sum(x['before'] is None for p,x in files.items() if p.startswith('src/')),'sharedFiles':1,'redTestPath':test,'redTestAlreadyInParent':True,'originalRedPatchSha256':sha((r/'tests-red.patch').read_bytes()),'parentRedLog':'/tmp/compliance-calendar-history-red-tests.log','parentReportedRedCases':6,'focusedFilter':'FullyQualifiedName~TypeIICalendarMalformedHistoryTests|FullyQualifiedName~TypeIICalendarNativeHistoryTests|FullyQualifiedName~TypeIIObservationCalendarTests|FullyQualifiedName~TypeIIRangeProcessTests','suiteFilter':'Category!=BrokerIntegration','currentParentApplyOrder':orders['parent-red-already-integrated'],'testsFirstOrder':orders['tests-first'],'allFinalOrder':orders['all-final'],'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'patches':{p:{'sha256':sha((r/p).read_bytes()),'bytes':(r/p).stat().st_size} for p in patches},'exactReconstruction':'reconstruction.json','staticAudit':'audit.json','originalAcceptanceNames':a['originalAcceptanceNames'],'explicitConstructorCalls':a['constructorCallsAcrossEffectiveTree'],'readme':'README.md','wiring':'wiring.json','notes':['Existing current/selected read, accepted acquire/settle retry and executor internal hydration all reject malformed full native history before returning/deciding.','Raw actual transitions use guarded Rules.Authorize/Settle, not bypass Apply; all unselected roots are validated transiently. Returned owner/snapshot state remains compact.','Separate actual physical ResourceOffset/CommittedStreamPosition, metadata AggregateVersion/Version, NativeSequence and header/business revision checks. Audit-session streams are not mistaken for raised owner records.','Current immutable live and selected terminal bodies compare against the complete transient native state; selected full actual native acceptance metadata remains checked. No all-old-authority body reads and no content dependency on the aggregate-reader wrapper.','Current standalone shared wiring has only Calendar wrapper. Future combined variants produce original -> Calendar -> SourceUse with separate opaque keyed registrations and no recursion or bypass; both composition orders reconstruct exact combined file.','Parent current formatted Reader and formatted already-integrated RED test are saved as exact nonnull originals. Original pre-format RED patch retained unchanged for evidence.','Frozen Calendar28 and SourceUse53 trees remain untouched. No new wire or JSON contracts.'],'noPreparerRuntimeOrJevClaims':True}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'reviewPaths':h['reviewPaths'],'sourceChanges':h['sourceChangesAfterParentRed'],'manifestSha256':h['manifestSha256'],'handoffSha256':sha((r/'handoff.json').read_bytes()),'patches':h['patches']},indent=2))
