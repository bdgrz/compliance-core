from pathlib import Path
import json,hashlib
r=Path('/tmp/compliance-calendar-history-validation-prepared');c=Path('/tmp/compliance-calendar-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths={'src/Compliance.Core/Features/Operations/TypeIICalendarReader.cs':c/'work/src/Compliance.Core/Features/Operations/TypeIICalendarReader.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs':repo/'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs'}
b=[]
for path,source in paths.items():
 data=source.read_bytes()
 for tree in ['base','work']:
  p=r/tree/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 b.append({'path':path,'baselineSource':str(source),'beforeSha256':hashlib.sha256(data).hexdigest()})
(r/'baselines.json').write_text(json.dumps(b,indent=2)+'\n')
p=r/'work/test/Compliance.Tests/Features/Operations/TypeIICalendarMalformedHistoryTests.cs';p.parent.mkdir(parents=True,exist_ok=True)
