from pathlib import Path
r=Path('/tmp/compliance-work-digest-prepared/work/src/Compliance.Core/Features/Work')
(r/'WorkDigestReplayCut.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>Bounded complete replay commitment and exact finalized native/physical append cut.</summary>
sealed class WorkDigestReplayCut
{
    bool _verified;
    ulong _version;
    ulong _position;
    public string Digest { get; private set; } = WorkDigestReplayDigest.Empty;
    public void Observe(DomainEvent fact)
    {
        Digest = WorkDigestReplayDigest.Append(Digest, fact);
        _verified = false;
    }
    public void Confirm(Aggregate owner, string digest)
    {
        if (Digest != digest)
            throw new ImmutableContentIntegrityException("The digest raw source differs from its actual hydrated payload/metadata prefix.");
        (_verified, _version, _position) = (true, owner.Version, owner.CommittedStreamPosition);
    }
    public bool Allows(Aggregate owner) => owner.Version == 0 && owner.CommittedStreamPosition == 0 &&
        Digest == WorkDigestReplayDigest.Empty || _verified && _version == owner.Version && _position == owner.CommittedStreamPosition;
}
''')
s=Path('/tmp/compliance-audit-package-history-prepared/work/src/Compliance.Core/Features/AuditPackages/AuditPackageReplayDigest.cs').read_text().replace('Bdgrz.Compliance.Features.AuditPackages','Bdgrz.Compliance.Features.Work').replace('AuditPackageReplayDigest','WorkDigestReplayDigest')
(r/'WorkDigestReplayDigest.cs').write_text(s)
old=(r/'WorkDigestDispatch.cs').read_text();a=old.index('    public const string Scheduled');b=old.index('    readonly Uuid',a);constants=old[a:b]
s='''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>Bounded latest/explicit selected member-week authority; complete dispatch history is external.</summary>
public sealed class WorkDigestDispatch : Aggregate
{
CONSTANTS    public const string Area = "work-digest-dispatches";
    readonly Uuid _tenant;
    readonly DateOnly _selectedWeek;
    WorkDigestDispatchState? _latest;
    WorkDigestDispatchState? _selected;
    public WorkDigestDispatch(Uuid tenantId, Uuid memberId, DateOnly selectedWeek = default)
        : base(memberId, new EventStreamAddress(tenantId.ToString(), Area, memberId.ToString()))
    {
        (_tenant, _selectedWeek) = (tenantId, selectedWeek);
        On<WorkDigestDispatchScheduled>(ApplyFact);
        On<WorkDigestDispatchAttemptStarted>(ApplyFact);
        On<WorkDigestDispatchOutcomeRecorded>(ApplyFact);
        On<WorkDigestUnknownRetryAuthorized>(ApplyFact);
    }
    public Uuid TenantId => _tenant;
    public DateOnly SelectedWeek => _selectedWeek;
    internal WorkDigestDispatchState? LatestState => _latest;
    internal WorkDigestDispatchState? SelectedState => _selectedWeek == _latest?.WeekOf ? _latest : _selected;
    public DomainEvent? Latest { get; private set; }
    internal WorkDigestReplayCut ReplayCut { get; } = new();
    internal bool Schedule(WorkDigestScheduleWindow window, Uuid messageId, TimeSpan retryWindow, DateTimeOffset recordedAt)
    {
        if (_latest is { } latest && latest.WeekOf >= window.WeekOf || !ReplayCut.Allows(this))
            return false;
        var rules = new WorkDigestDispatchRules(_tenant, Id);
        if (!rules.Schedule(window, messageId, retryWindow, recordedAt))
            return false;
        RaiseEvent(rules.PendingEvents.Single());
        return true;
    }
    WorkDigestDispatchState? State(DateOnly week)
    {
        if (_latest?.WeekOf == week)
            return _latest;
        if (_selectedWeek == week)
            return _selected;
        if (_latest is not null && week < _latest.WeekOf)
            throw new InvalidOperationException("Historical dispatch authority requires explicit selected-week hydration.");
        return null;
    }
    public WorkDigestDispatchStatusView Read(DateOnly week) => State(week)?.View(_tenant, Id) ??
        new WorkDigestDispatchStatusView(_tenant, Id, week, "UTC", DateTimeOffset.MinValue, "not_scheduled", 0,
            null, Uuid.Empty, DateTimeOffset.MinValue, null, null, null, null, null);
    internal DateTimeOffset RetryDeadline(DateOnly week) => State(week)?.RetryDeadline ?? DateTimeOffset.MinValue;
    bool Change(DateOnly week, Func<WorkDigestDispatchRules, bool> change)
    {
        if (!ReplayCut.Allows(this) || State(week) is not { } state)
            return false;
        var rules = new WorkDigestDispatchRules(_tenant, Id);
        rules.Restore(state);
        if (!change(rules))
            return false;
        RaiseEvent(rules.PendingEvents.Single());
        return true;
    }
    public bool StartAttempt(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.StartAttempt(week, at));
    public bool RecordSent(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordSent(week, at));
    public bool RecordSkipped(DateOnly week, DateTimeOffset at, string reason) => Change(week, rules => rules.RecordSkipped(week, at, reason));
    public bool RecordPermanentRejection(DateOnly week, DateTimeOffset at, string code) => Change(week, rules => rules.RecordPermanentRejection(week, at, code));
    public bool RecordUnknown(DateOnly week, DateTimeOffset at, string code) => Change(week, rules => rules.RecordUnknown(week, at, code));
    public bool RecordInterruptedAttempt(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordInterruptedAttempt(week, at));
    public bool AuthorizeUnknownRetry(DateOnly week, Uuid by, string evidence, string rationale, DateTimeOffset at, int maximumAttempts) =>
        Change(week, rules => rules.AuthorizeUnknownRetry(week, by, evidence, rationale, at, maximumAttempts));
    public bool RecordTransientRejection(DateOnly week, DateTimeOffset at, int maximumAttempts, TimeSpan delay) =>
        Change(week, rules => rules.RecordTransientRejection(week, at, maximumAttempts, delay));
    public bool RecordRetryWindowExpired(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordRetryWindowExpired(week, at));
    public bool RecordMissedWeek(DateOnly week, DateTimeOffset at) => Change(week, rules => rules.RecordMissedWeek(week, at));
    void ApplyFact(DomainEvent fact)
    {
        var (tenant, member, week) = WorkDigestDispatchHistory.Scope(fact);
        if (tenant != _tenant || member != Id)
            throw new ImmutableContentIntegrityException("The dispatch fact belongs to another member or tenant.");
        if (fact is WorkDigestDispatchScheduled scheduled)
        {
            if (_latest is { } latest && week <= latest.WeekOf)
                throw new ImmutableContentIntegrityException("A dispatch schedule cannot repeat or precede its latest week.");
            var rules = new WorkDigestDispatchRules(_tenant, Id);
            rules.Replay(scheduled);
            _latest = rules.States[week];
            if (week == _selectedWeek)
                _selected = _latest;
        }
        else
        {
            if (_latest?.WeekOf == week)
                _latest = Updated(_latest, fact);
            if (_selectedWeek == week && _selected is not null && _latest?.WeekOf != week)
                _selected = Updated(_selected, fact);
            else if (_selectedWeek == week && _latest?.WeekOf == week)
                _selected = _latest;
        }
        Latest = fact;
        ReplayCut.Observe(fact);
    }
    WorkDigestDispatchState Updated(WorkDigestDispatchState state, DomainEvent fact)
    {
        var rules = new WorkDigestDispatchRules(_tenant, Id);
        rules.Restore(state);
        rules.Replay(fact);
        return rules.States[state.WeekOf];
    }
}
'''.replace('CONSTANTS',constants)
(r/'WorkDigestDispatch.cs').write_text(s)
old=(r/'WeeklyWorkDigestRules.cs').read_text();a=old.index('    public static Uuid IdFor');b=old.index('    public WeeklyWorkDigestView Read()',a);identity=old[a:b]
(r/'WeeklyWorkDigest.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>Bounded current and explicit selected attempt authority; full attempts remain external immutable history.</summary>
public sealed class WeeklyWorkDigest : Aggregate
{
    public const string SchedulerProcessId = WeeklyWorkDigestRules.SchedulerProcessId;
    public const string DeliveryProcessId = WeeklyWorkDigestRules.DeliveryProcessId;
    public const string Area = "weekly-work-digests";
    readonly Uuid _tenant;
    readonly int _selectedAttempt;
    WorkDigestDeliveryAttemptView? _latest;
    WorkDigestDeliveryAttemptView? _selected;
    public WeeklyWorkDigest(Uuid tenantId, Uuid digestId, int selectedAttempt = 0)
        : base(digestId, new EventStreamAddress(tenantId.ToString(), Area, digestId.ToString()))
    {
        (_tenant, _selectedAttempt) = (tenantId, selectedAttempt);
        On<WeeklyWorkDigestScheduled>(ApplyFact);
        On<WeeklyWorkDigestDeliveryRequested>(ApplyFact);
        On<WeeklyWorkDigestDeliveryRecorded>(ApplyFact);
        On<WeeklyWorkDigestDeliverySuppressed>(ApplyFact);
    }
    public Uuid TenantId => _tenant;
    public WeeklyWorkDigestHeader? Header { get; private set; }
    public long Revision => Header?.Revision ?? 0;
    public string Status => Header?.Status ?? "missing";
    public Uuid MemberId => Header?.MemberId ?? Uuid.Empty;
    public DateOnly WeekStarting => Header?.WeekStarting ?? default;
    public WorkDigestDeliveryAttemptView? LatestAttempt => _latest;
    public WorkDigestDeliveryAttemptView? SelectedAttempt => _selectedAttempt == _latest?.Number ? _latest : _selected;
    public int SelectedAttemptNumber => _selectedAttempt;
    public DomainEvent? Latest { get; private set; }
    internal WorkDigestReplayCut ReplayCut { get; } = new();
IDENTITY    WeeklyWorkDigestRules Rules()
    {
        var rules = new WeeklyWorkDigestRules(_tenant, Id);
        if (Header is { } header)
            rules.Restore(header, _selected, _latest);
        return rules;
    }
    Result Change(Func<WeeklyWorkDigestRules, Result> operation)
    {
        if (!ReplayCut.Allows(this))
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact weekly digest source cut is not finalized; retry.", true));
        var rules = Rules();
        var result = operation(rules);
        if (result.IsSuccess && rules.PendingEvents.Count > 0)
            RaiseEvent(rules.PendingEvents.Single());
        return result;
    }
    public Result Schedule(Uuid memberId, DateOnly weekStarting, string key, ActorReference by, DateTimeOffset at) =>
        Change(rules => rules.Schedule(memberId, weekStarting, key, by, at));
    public Result RequestDelivery(long expected, int attempt, string key, ActorReference by, DateTimeOffset at) =>
        Change(rules => rules.RequestDelivery(expected, attempt, key, by, at));
    public Result SuppressDelivery(long expected, string reason, ActorReference by, DateTimeOffset at) =>
        Change(rules => rules.SuppressDelivery(expected, reason, by, at));
    public Result RecordDeliveryResult(long expected, int attempt, string key, string outcome, string? code,
        ActorReference by, DateTimeOffset at) => Change(rules => rules.RecordDeliveryResult(expected, attempt, key, outcome, code, by, at));
    void ApplyFact(DomainEvent fact)
    {
        var rules = Rules();
        rules.Replay(fact);
        var view = rules.Read();
        Header = new WeeklyWorkDigestHeader(view.MemberId, view.WeekStarting, view.ScheduleKey, view.ScheduledAt,
            view.ScheduledBy, view.Status, view.Revision, view.SuppressionReason);
        _latest = view.DeliveryAttempts.LastOrDefault();
        if (_selectedAttempt > 0 && view.DeliveryAttempts.FirstOrDefault(item => item.Number == _selectedAttempt) is { } selected)
            _selected = selected;
        Latest = fact;
        ReplayCut.Observe(fact);
    }
}
'''.replace('IDENTITY',identity))
