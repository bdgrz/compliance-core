from pathlib import Path
import json,re
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-work-digest-prepared');parser=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
def methods(f):
 t=f.read_bytes();out={}
 for n in walk(parser.parse(t).root_node):
  if n.type!='method_declaration':continue
  name=tx(t,n.child_by_field_name('name'));params=n.child_by_field_name('parameters');key=name+tx(t,params)
  body=n.child_by_field_name('body');body=body or next((c for c in n.children if c.type=='arrow_expression_clause'),None)
  if body:out[key]=tx(t,body)
 return out
reports=[]
for owner in ['WorkDigestDispatch','WeeklyWorkDigest']:
 path='src/Compliance.Core/Features/Work/'+owner+'.cs';before=methods(r/'base'/path);after=methods(r/'work'/path.replace('.cs','Rules.cs'));rows=[]
 for key,body in before.items():
  if key not in after:
   rows.append({'method':key,'classification':'expected extracted nested State.View' if key.startswith('View(') else 'MISSING'});continue
  expected=body.replace('DispatchState','WorkDigestDispatchState')
  if owner=='WeeklyWorkDigest':expected=expected.replace('_attempts.Count + 1','_attemptCount + 1')
  if key.startswith('Apply(WeeklyWorkDigestDeliveryRequested '):expected=expected.replace('        _attempts.Add(','        _attemptCount = ev.AttemptNumber;\n        _attempts.Add(')
  normalize=lambda s:re.sub(r'\s+','',s)
  rows.append({'method':key,'equivalent':normalize(expected)==normalize(after[key]),'approvedAdaptations':['non-Aggregate rule composition','scalar total-attempt counter instead of selected list count'] if owner=='WeeklyWorkDigest' else ['nested state record extracted without payload change']})
 reports.append({'owner':owner,'methods':rows})
(r/'rules-equivalence.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps([{'owner':p['owner'],'unexpected':[x for x in p['methods'] if x.get('equivalent') is False or x.get('classification')=='MISSING']} for p in reports],indent=2))
