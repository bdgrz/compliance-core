# Frozen digest history and claimed-attempt layer (35 paths)

This package compacts the actual lifetime histories of WorkDigestDispatch and WeeklyWorkDigest while retaining unchanged compact technical fact payloads/tags. It is a structural/protocol-safety layer, not completion of the selected identified command/result migration. Root owns all compiler, analyzer, behavioral RED/GREEN, full-suite, HTTP, Jev, Git, and integration execution. No main files, .NET commands, Git, issues, worktrees, or external transport were touched by this preparer.

WorkDigestDispatch now retains latest and one explicitly selected member-week state. WeeklyWorkDigest retains a scalar header, latest attempt and one explicitly selected historical attempt. Complete dictionaries/lists exist only in transient Rules and explicit History/Snapshot composition. Installed WorkDigestAggregateReader verifies every raw native fact, identity/physical prefix, complete rolling payload/metadata commitment, and current/selected authority before mutations or retry. NativeOwnerHistory from the earlier small-three package is an already-installed prerequisite.

The live processor still durably claims before transport. A returned transport result now settles only its exact claimed attempt number, last-attempt time, and stable message ID. A delayed response from an older unknown attempt cannot settle a later authorized attempt. Cancellation remains observable; interrupted attempts become Unknown, never automatic resend. The original frozen timezone, current-week/deadline/attempt-budget rules and deterministic message/key identities are unchanged. Weekly failure attempts retain their actual unlimited-repeat policy; no invented cap or deadline was added. Later Unknown episodes may still reuse the same external evidence text.

All original business rule method bodies compare exactly against their extracted Rules implementations after only the explicit state-record rename and scalar total-attempt counter adaptation (rules-equivalence.json). All 41 original acceptance method names and assertion counts remain. Nine additional methods cover 17 rows: actual history growth, historical exact replay, two pending timezone windows, repeated evidence, hidden historical-prefix substitution/scope/physical/missing cuts, delayed transport result, unknown append claim with no send, and cancellation/ambiguous transport recovery. These are prepared tests, not an agent claim of runtime green.

## Evidence and patch order

- Root genuinely qualified behavioral-red.patch (2 failing tests): 52 actual completed member weeks retain 52 entries; 128 actual allowed failed attempts retain 128 entries. Original SHA is preserved exactly. Root archived evidence under recovery/import-digest-abort-qualified-red.
- attempt-behavioral-red.patch is a separate executable existing-API real-processor regression with only a fake transport. It commits first-attempt lease recovery, operator authorization and a second claim before returning the old Accepted result. Root has its filter and must qualify this RED before applying the result guard.
- Full installation: full.patch.
- Partitioned installation: tests.patch then implementation.patch.
- After the already-qualified history RED: after-red.patch.
- After only the attempt RED: after-attempt-red.patch.
- After both RED files: combined-behavioral-red.patch then after-combined-red.patch.
- shared-deltas.patch duplicates the three shared hunks for composition convenience; do not apply it in addition to a full/partitioned patch.

All five reconstruction sequences match the exact 35 manifest hashes. Two shared baseline files drifted while root integrated Examination: Core DI and PersistenceServiceCollectionExtensions. Compose their narrow Work import/HistoryReader registration/WorkDigestAggregateReader decorator additions, preserving all current wrappers. ProgramManagementServices is the sole test composition delta. No App/Common/JSON/routes/package or event discriminator changes are included in this layer.

## Selected command follow-on

Source inspection corrected the initial identity qualification: remaining-command-identities.json:2442 already selects CommandId, ExpectedRevision, logicalIdentity CommandId and the identified PUT route for AuthorizeWorkDigestUnknownRetry. Therefore the current DTO's missing identity is an INTERNAL implementation gap, not missing authority. Root explicitly assigned the separate native admission/result follow-on. A fresh CommandId permits legal repeated same-evidence authorization in a later Unknown episode; an exact retry must return its original status/result and changed intent must conflict. This layer preserves current behavior while that selected migration is prepared separately; it does not derive permanent evidence IDs or claim original native response persistence.

The same remaining-command catalog selects identified weekly commands. Current ScheduleWeeklyWorkDigest is a membership-page fan-out whose page response is not owned/frozen by one current digest, and no weekly actual transport producer/reactor is present (the actual sender is the separate dispatch processor). Those source facts require explicit follow-on protocol/producer qualification; this layer does not manufacture a parent owner, callback, alias route, or sender and does not mark the whole selected family complete.

## Validation boundary

Static modern C# parse, 238 explicit constructor calls across the effective source tree, token-last checks, duplicate imports, 36 tracked fixture member shapes, extracted-rule equivalence, original acceptance preservation, and exact patch reconstruction pass. No C# compilation or runtime test was run by this agent. See static-audit.json, member-audit.json, rules-equivalence.json, manifest.json, reconstruction.json and handoff.json.
