from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-work-digest-prepared/work/test/Compliance.Tests/Features/Work');parser=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
for filename,kind,events in [('WeeklyWorkDigestCommandHandlerTests.cs','WeeklyWorkDigest','fixture.Events'),('WorkDigestDispatchProcessorTests.cs','WorkDigestDispatch','scope.ServiceProvider.GetRequiredService<IDomainEventReader>()')]:
 p=r/filename;t=p.read_bytes();edits=[]
 for n in walk(parser.parse(t).root_node):
  if n.type!='invocation_expression':continue
  head=n.child_by_field_name('function');args=next((c for c in n.children if c.type=='argument_list'),None)
  if not head or not args or b'HydrateAsync' not in t[head.start_byte:head.end_byte]:continue
  aa=[c for c in args.children if c.type=='argument']
  if not aa:continue
  value=aa[0];ctor=next((c for c in walk(value) if c.type=='object_creation_expression'),None)
  if not ctor:continue
  typ=ctor.child_by_field_name('type');ca=next((c for c in ctor.children if c.type=='argument_list'),None)
  if not typ or not ca or t[typ.start_byte:typ.end_byte].decode()!=kind:continue
  # InspectingDelivery has no service scope: its exact one queried week is explicitly selected instead.
  if filename=='WorkDigestDispatchProcessorTests.cs' and t[ca.start_byte:ca.end_byte].decode()=='(tenantId, memberId)':
   edits.append((ca.end_byte-1,ca.end_byte-1,', new DateOnly(2026, 10, 5)'));continue
  cargs=[t[c.start_byte:c.end_byte].decode() for c in ca.children if c.type=='argument']
  reader=t[head.start_byte:head.end_byte].decode().rsplit('.HydrateAsync',1)[0]
  readmethod='ReadWeeklyAsync' if kind=='WeeklyWorkDigest' else'ReadDispatchAsync'
  call=f'new WorkDigestHistoryReader({reader}, {events}).{readmethod}('+', '.join(cargs)+')'
  edits.append((n.start_byte,n.end_byte,call))
 for a,b,s in sorted(edits,reverse=True):t=t[:a]+s.encode()+t[b:]
 s=t.decode()
 if filename=='WeeklyWorkDigestCommandHandlerTests.cs':
  # All transformed local digest variables now hold explicit snapshots; keep the full public View outside owner.
  s=s.replace('digest.DeliveryAttempts','digest.View.DeliveryAttempts').replace('digest.Status','digest.View.Status').replace('digest.Revision','digest.View.Revision').replace('digest.Read().SuppressionReason','digest.View.SuppressionReason')
  # Two expression-only status assertions also use the explicit history snapshot.
  s=s.replace('digestId))).Status','digestId))).View.Status')
 p.write_text(s)
