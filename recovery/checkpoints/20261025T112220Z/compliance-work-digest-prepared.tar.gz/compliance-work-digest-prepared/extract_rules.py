from pathlib import Path
r=Path('/tmp/compliance-work-digest-prepared/work/src/Compliance.Core/Features/Work')
p=r/'WorkDigestDispatch.cs';s=p.read_text().replace('public sealed class WorkDigestDispatch : Aggregate','public sealed class WorkDigestDispatchRules').replace('readonly Dictionary<DateOnly, DispatchState> _dispatches','readonly Dictionary<DateOnly, WorkDigestDispatchState> _dispatches').replace('new DispatchState(','new WorkDigestDispatchState(')
a=s.index('    public WorkDigestDispatch(');b=s.index('\n    internal bool Schedule',a)
s=s[:a]+'''    readonly List<DomainEvent> _pending = [];
    public Uuid Id { get; }
    public IReadOnlyList<DomainEvent> PendingEvents => _pending;
    internal IReadOnlyDictionary<DateOnly, WorkDigestDispatchState> States => _dispatches;

    public WorkDigestDispatchRules(Uuid tenantId, Uuid memberId)
    {
        (_tenantId, Id) = (tenantId, memberId);
    }

    internal void Restore(WorkDigestDispatchState state) => _dispatches.Add(state.WeekOf, state);
    internal void Replay(DomainEvent fact)
    {
        switch (fact)
        {
            case WorkDigestDispatchScheduled scheduled: Apply(scheduled); break;
            case WorkDigestDispatchAttemptStarted started: Apply(started); break;
            case WorkDigestDispatchOutcomeRecorded outcome: Apply(outcome); break;
            case WorkDigestUnknownRetryAuthorized authorized: Apply(authorized); break;
            default: throw new InvalidOperationException("The dispatch rules source kind is unsupported.");
        }
    }
    void RaiseEvent(DomainEvent fact)
    {
        Replay(fact);
        _pending.Add(fact);
    }
''' + s[b:]
a=s.index('    sealed record DispatchState(')
state=s[a:s.rfind('\n}')].replace('    sealed record DispatchState','sealed record WorkDigestDispatchState')
s=s[:a]+'}\n'
(r/'WorkDigestDispatchRules.cs').write_text(s)
(r/'WorkDigestDispatchState.cs').write_text('using Cntryl.Portia;\n\nnamespace Bdgrz.Compliance.Features.Work;\n\n'+state+'\n')
p=r/'WeeklyWorkDigest.cs';s=p.read_text().replace('public sealed class WeeklyWorkDigest : Aggregate','public sealed class WeeklyWorkDigestRules');a=s.index('    public WeeklyWorkDigest(');b=s.index('\n    public static Uuid IdFor',a)
s=s[:a]+'''    readonly List<DomainEvent> _pending = [];
    int _attemptCount;
    public Uuid Id { get; }
    public IReadOnlyList<DomainEvent> PendingEvents => _pending;

    public WeeklyWorkDigestRules(Uuid tenantId, Uuid digestId)
    {
        (_tenantId, Id) = (tenantId, digestId);
    }

    internal void Replay(DomainEvent fact)
    {
        switch (fact)
        {
            case WeeklyWorkDigestScheduled scheduled: Apply(scheduled); break;
            case WeeklyWorkDigestDeliveryRequested requested: Apply(requested); break;
            case WeeklyWorkDigestDeliveryRecorded recorded: Apply(recorded); break;
            case WeeklyWorkDigestDeliverySuppressed suppressed: Apply(suppressed); break;
            default: throw new InvalidOperationException("The weekly rules source kind is unsupported.");
        }
    }
    void RaiseEvent(DomainEvent fact)
    {
        Replay(fact);
        _pending.Add(fact);
    }

    internal void Restore(WeeklyWorkDigestHeader header, WorkDigestDeliveryAttemptView? selected,
        WorkDigestDeliveryAttemptView? latest)
    {
        (_memberId, _weekStarting, _scheduleKey, _scheduledAt, _scheduledBy, _status, Revision, _suppressionReason) =
            (header.MemberId, header.WeekStarting, header.ScheduleKey, header.ScheduledAt, header.ScheduledBy,
                header.Status, header.Revision, header.SuppressionReason);
        _attemptCount = latest?.Number ?? 0;
        if (selected is not null && selected.Number != latest?.Number)
            _attempts.Add(selected);
        if (latest is not null)
            _attempts.Add(latest);
    }
''' + s[b:]
s=s.replace('_attempts.Count + 1','_attemptCount + 1').replace('        _attempts.Add(new WorkDigestDeliveryAttemptView(ev.AttemptNumber','        _attemptCount = ev.AttemptNumber;\n        _attempts.Add(new WorkDigestDeliveryAttemptView(ev.AttemptNumber')
(r/'WeeklyWorkDigestRules.cs').write_text(s)
(r/'WeeklyWorkDigestHeader.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>One weekly digest's scalar current authority; complete attempts are external read history.</summary>
public sealed record WeeklyWorkDigestHeader(Uuid MemberId, DateOnly WeekStarting, string? ScheduleKey,
    DateTimeOffset? ScheduledAt, ActorReference? ScheduledBy, string Status, long Revision, string? SuppressionReason);
''')
