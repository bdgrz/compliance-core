from pathlib import Path
import difflib,hashlib,json,subprocess,tempfile,shutil,re
r=Path('/tmp/compliance-work-digest-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
expected='5f3b52a10f3b0bd2b59ebd1712a48c78f022ba4ff5242d24647f8a7681851933'
assert sha((r/'behavioral-red.patch').read_bytes())==expected,'Qualified old RED2 changed unexpectedly'
changed=sorted(str(f.relative_to(r/'work')) for f in (r/'work').rglob('*') if f.is_file() and (not (r/'base'/f.relative_to(r/'work')).exists() or f.read_bytes()!=(r/'base'/f.relative_to(r/'work')).read_bytes()))
def before(p):return (r/'base'/p).read_bytes() if (r/'base'/p).exists() else b''
def diff(paths,overrides=None):
 out=''
 for p in paths:
  b=(overrides or {}).get(p,before(p));a=(r/'work'/p).read_bytes()
  out+=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+p if b else '/dev/null',tofile='b/'+p))
 return out
sources=[p for p in changed if p.startswith('src/')];tests=[p for p in changed if p.startswith('test/')]
shared=['src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs']
redcases={}
for patch in ['behavioral-red.patch','attempt-behavioral-red.patch']:
 with tempfile.TemporaryDirectory(prefix='digest-red-baseline-') as d:
  q=Path(d);proc=subprocess.run(['patch','--batch','-p1','-d',d,'-i',str(r/patch)],capture_output=True,text=True)
  if proc.returncode:raise SystemExit((patch,proc.stdout,proc.stderr))
  redcases[patch]={str(f.relative_to(q)):f.read_bytes() for f in q.rglob('*') if f.is_file()}
(r/'combined-behavioral-red.patch').write_bytes((r/'behavioral-red.patch').read_bytes()+(r/'attempt-behavioral-red.patch').read_bytes())
combined={**redcases['behavioral-red.patch'],**redcases['attempt-behavioral-red.patch']}
for name,paths,overrides in [('full.patch',changed,None),('implementation.patch',sources,None),('tests.patch',tests,None),('shared-deltas.patch',shared,None),('after-red.patch',changed,redcases['behavioral-red.patch']),('after-attempt-red.patch',changed,redcases['attempt-behavioral-red.patch']),('after-combined-red.patch',changed,combined)]:
 (r/name).write_text(diff(paths,overrides))
manifest=[]
for p in changed:
 b=before(p) if (r/'base'/p).exists() else None;a=(r/'work'/p).read_bytes()
 manifest.append({'path':p,'before':sha(b) if b is not None else None,'after':sha(a),'kind':'source' if p.startswith('src/') else 'test','shared':p in shared,'currentMainMatchesBefore':((repo/p).read_bytes()==b) if (repo/p).exists() else b is None})
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checks=[]
for label,seq in [('full',['full.patch']),('partitioned',['tests.patch','implementation.patch']),('qualified-red2-then-green',['behavioral-red.patch','after-red.patch']),('attempt-red-then-green',['attempt-behavioral-red.patch','after-attempt-red.patch']),('combined-red-then-green',['combined-behavioral-red.patch','after-combined-red.patch'])]:
 with tempfile.TemporaryDirectory(prefix='digest-reconstruct-') as d:
  q=Path(d)
  for p in changed:
   b=r/'base'/p
   if b.exists():(q/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b,q/p)
  for patch in seq:
   proc=subprocess.run(['patch','--batch','-p1','-d',d,'-i',str(r/patch)],capture_output=True,text=True)
   if proc.returncode:raise SystemExit((label,patch,proc.stdout,proc.stderr))
  bad=[p for p in changed if not(q/p).exists() or (q/p).read_bytes()!=(r/'work'/p).read_bytes()]
  if bad:raise SystemExit((label,bad))
  checks.append({'sequence':label,'exactFiles':len(changed),'passed':True})
(r/'reconstruction.json').write_text(json.dumps(checks,indent=2)+'\n')
report={'changed':len(changed),'source':len(sources),'tests':len(tests),'shared':shared,'driftedBaseline':[m['path'] for m in manifest if not m['currentMainMatchesBefore']],'patchHashes':{p:sha((r/p).read_bytes()) for p in ['behavioral-red.patch','attempt-behavioral-red.patch','implementation.patch','tests.patch','shared-deltas.patch','after-red.patch','after-attempt-red.patch','combined-behavioral-red.patch','after-combined-red.patch','full.patch']},'manifestSha256':sha((r/'manifest.json').read_bytes()),'reconstruction':checks}
(r/'export-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
