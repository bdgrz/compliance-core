from pathlib import Path
import hashlib,difflib,json,subprocess,shutil,re
p=Path('/tmp/compliance-auditor-request-prepared');base=p/'base';work=p/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
source=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')]
rednames=['AuditorRequestUnboundCancellationTests','AuditorRequestNativeBoundaryTests','AuditorRequestPreparationRaceTests','AuditorChildMaterializationReplayTests','AuditorSelectionIdentityTests']
red=[r for r in tests if Path(r).stem in rednames];post=[r for r in tests if r not in red]
def export(name,selected):
 chunks=[]
 for r in selected:
  a=base/r;b=work/r;chunks+=difflib.unified_diff(a.read_text().splitlines(True) if a.exists() else [],b.read_text().splitlines(True),fromfile='a/'+r if a.exists() else '/dev/null',tofile='b/'+r)
 f=p/name;f.write_text(''.join(chunks));return {'path':str(f),'sha256':sha(f),'paths':selected}
arts={k:export(k,v) for k,v in [('implementation.patch',source),('tests.patch',tests),('behavioral-red.patch',red),('green-after-red.patch',source+post),('full.patch',paths)]}
checks=[]
for name,sequence in [('full',['full.patch']),('split',['tests.patch','implementation.patch']),('staged',['behavioral-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/name;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest)
 for patch in sequence:
  run=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,text=True,capture_output=True);assert run.returncode==0,run.stdout+run.stderr
 assert all(sha(dest/r)==sha(work/r) for r in paths);checks.append({'sequence':sequence,'exact':True})
static=json.loads((p/'static-checks.json').read_text())
report={
 'paths':[{'path':r,'before':sha(base/r),'after':sha(work/r),'mainStillMatchesBaseline':sha(repo/r)==sha(base/r)} for r in paths],
 'artifacts':arts,'reconstruction':checks,'static':static,'runtime':'Not run; root owns format/build/test/Jev/runtime. Cancellation old-API RED already root-qualified unsafe success.',
 'scope':'AuditorRequest compact native authority, all seven owning admission/term/lifecycle producers, independent child materialization replay/full frozen header checks, resolution acceptance/verifier/completion/cancellation/fences and all four reactors. Complete native request/response/selection reader composition. Scoped public reads/routes/HTTP acceptance are disjoint child package /tmp/compliance-auditor-request-reads-prepared; both packages are needed for whole family.',
 'authority':'No retained child/fact/root dictionaries. Current terms/record/latest/pending/resolved/scalar response count and one explicitly selected historical resolution+terminal remain bounded. Full history and exact response universe/sample amendment membership are transient at a certified exact hydrated native+physical cut. Certificate cannot validate another current cut.',
 'retry':'All owning root mutable guards/foreign reads/byte freeze inside native Prepare; actor/current dispatch authorization precedes retry. Root FirstOwner explicit. Fresh pre-admission sample population/row IDs avoid cross-first-owner collisions and orphan poisoning. Accepted child/terminal receiver command replay precedes body reads and verifies original native source/generation/intent/proof tuple; no new public lookup contract.',
 'protocol':'FailureProof schema2 includes exact admission/root/generation/intent and selected response membership; raw unbound historical proof fails permanent. Terminal original proof reused before settlement. Missing immutable content transient, corrupt permanent. Native use pairs/frozen source manifests and drain/hold/append/settle ordering preserved.',
 'wire':'Existing DTOs and occupied event discriminator tags/versions unchanged. Failure proof internal content schema v1→v2; already accepted native receiver replay preserves old refs. Unit/202 first descriptors and MutationResultContent envelopes retain existing wire behavior; selected public native transport bridge prerequisite already merged.',
 'sharedDeltas':'No owning shared Program/DI/JSON edits. Existing failure-proof serializer registration automatically covers expanded record. Read child owns sole AuditorRequestReader/directory/handler/projector DI and GET route deltas.',
 'constructors':'See static-checks.json, all explicit calls checked over current main + owner + read-child source. Fresh own handlers gain IDomainEventReader, remove unused IAggregateReader where applicable. Materialization handlers gain events; Abort/Complete/Verifier gain events; four reactors gain content/source resolver; WorkStatusReader takes AuditorRequestReader. Fixture registers Reader and exposes Requests/RequestHistoryAsync.',
 'qualification':['Bare/global operation-result routes remain disabled under existing #1042/#1055 ledger; no global atomic mutation identity is claimed. Existing 202 status URL shape retained, no new route invented.','Personal current scoped program authorization remains the public boundary. No external-auditor or Attest disclosure permission added.','No broker/runtime/delivery qualification is claimed by static checks. Real root gates required before merge.'],
 'newTests':{r:re.findall(r'\b(Should\w+)\s*\(',(work/r).read_text()) for r in tests if not (base/r).exists()}}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n');(p/'behavioral-red-filter.txt').write_text('|'.join('FullyQualifiedName~'+n for n in rednames)+'\n');(p/'focused-filter.txt').write_text('FullyQualifiedName~AuditorRequest|FullyQualifiedName~AuditorResponse|FullyQualifiedName~SampleSelection|FullyQualifiedName~SourceUse\n');(p/'owned-paths.txt').write_text('\n'.join(paths)+'\n')
print(json.dumps({'changed':len(paths),'source':len(source),'tests':len(tests),'redFiles':len(red),'mainDrift':[r['path'] for r in report['paths'] if not r['mainStillMatchesBaseline']],'artifacts':{k:v['sha256'] for k,v in arts.items()},'reconstruction':checks},indent=2))
