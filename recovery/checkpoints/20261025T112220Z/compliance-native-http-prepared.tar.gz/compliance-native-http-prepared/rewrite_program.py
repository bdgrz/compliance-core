from pathlib import Path
import sys
import tree_sitter,tree_sitter_c_sharp
sys.path.insert(0,str(Path(__file__).parent));import prepare as p
path='src/Compliance.App/Program.cs';s=p.original(path).replace('.OnResult(','.OnNativeResult(');parser=tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()));b=s.encode();changes=[];rows=[]
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
for n in walk(parser.parse(b).root_node):
 if n.type!='invocation_expression':continue
 function=n.child_by_field_name('function')
 if not function or function.type!='member_access_expression':continue
 name=function.child_by_field_name('name')
 if not name or name.type!='generic_name':continue
 ident=name.child_by_field_name('name') or name.children[0];method=ident.text.decode()
 if method not in ['MapPortiaPost','MapPortiaPut','MapPortiaDelete','MapPortiaPatch']:continue
 types=next(c for c in name.children if c.type=='type_argument_list');request=next(c for c in types.named_children).text.decode()
 args=next(c for c in n.children if c.type=='argument_list');parts=[c for c in args.children if c.type=='argument'];assert len(parts) in [1,2],(method,len(parts))
 if len(parts)==1:changes.append((args.end_byte-1,args.end_byte-1,', config => config.OnNativeResult()'))
 elif b'.OnNativeResult(' not in parts[1].text:
  assert parts[1].named_children[0].type=='lambda_expression'
  body=parts[1].named_children[0].child_by_field_name('body');assert body.type!='block',parts[1].text
  changes.append((body.end_byte,body.end_byte,'.OnNativeResult()'))
 changes.append((n.end_byte,n.end_byte,'.WithNativeFirstResponse<'+request+'>()'))
 rows.append({'request':request,'method':method,'line':n.start_point.row+1,'customCallback':len(parts)==2 and b'.OnNativeResult(' in parts[1].text})
for a,z,repl in sorted(changes,reverse=True):b=b[:a]+repl.encode()+b[z:]
s=b.decode();s='using Bdgrz.Compliance.Hosting.NativeResponses;\n'+s
anchor='    builder.Services.AddHttpContextAccessor();';assert anchor in s
s=s.replace(anchor,anchor+'''\n    builder.Services.AddSingleton<INativeOperationTransportObserver, NativeOperationHttpObserver>();
    builder.Services.AddHostedService<NativeFirstResponseEndpointValidation>();''',1)
p.put(path,s,'shared-program');p.emit();(p.OUT/'endpoint-inventory.json').write_text(__import__('json').dumps(rows,indent=2)+'\n');print(len(rows),'mutation maps')
