from pathlib import Path
import difflib,hashlib,json
ROOT=Path('/Users/jrepanich/Code/bdgrz/compliance-core');OUT=Path('/tmp/compliance-native-http-prepared');COMMITMENT=Path('/tmp/compliance-s32-commitment-prepared');changes={};red_bases={}
def original(path):
 target=OUT/'before'/path
 if target.exists():return target.read_text()
 current=(ROOT/path).read_text()
 queued=COMMITMENT/'after'/path
 if False:current=queued.read_text()
 target.parent.mkdir(parents=True,exist_ok=True);target.write_text(current);return current
def put(path,text,phase='implementation'):
 if path not in changes:changes[path]={'before':original(path) if (ROOT/path).exists() else None,'phase':phase}
 if phase=='tests':red_bases[path]=text
 changes[path]['phase']=phase
 target=OUT/'after'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
def diff(path,before,after):return f'diff --git a/{path} b/{path}\n'+('new file mode 100644\n' if before is None else '')+''.join(difflib.unified_diff((before or '').splitlines(True),after.splitlines(True),fromfile='/dev/null' if before is None else 'a/'+path,tofile='b/'+path))
def emit():
 groups={};manifest=[]
 for path,row in changes.items():
  after=(OUT/'after'/path).read_text();baseline=row['before']
  if path in red_bases and row['phase']!='tests':
   groups.setdefault('tests',[]).append(diff(path,baseline,red_bases[path]));baseline=red_bases[path]
  groups.setdefault(row['phase'],[]).append(diff(path,baseline,after));manifest.append({'path':path,'phase':row['phase'],'beforeSha256':hashlib.sha256(row['before'].encode()).hexdigest() if row['before'] is not None else None,'afterSha256':hashlib.sha256(after.encode()).hexdigest()})
 for group,patches in groups.items():(OUT/(group+'.patch')).write_text(''.join(patches))
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(OUT/'newfiles.json').write_text(json.dumps([r['path'] for r in manifest if r['beforeSha256'] is None],indent=2)+'\n')
