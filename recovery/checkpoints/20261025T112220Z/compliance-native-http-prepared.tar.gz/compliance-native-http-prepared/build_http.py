from pathlib import Path
import re,json
import prepare as p
K='src/Compliance.Core/Features/NativeOperations/';A='src/Compliance.App/Hosting/NativeResponses/'
def put(path,text,phase='implementation'):p.put(path,text,phase)
def new(path,text,phase='implementation'):put(path,text.strip()+'\n',phase)
path='test/Compliance.Tests/Features/Tenants/PlatformOperatorTransportTests.cs';red=p.original(path)
point='    [Theory]\n    [InlineData(false)]'
method='''    [Fact]
    public async Task ShouldReturnDeclaredUnitBodyGivenPlatformGrantHttpSuccessAndRetry()
    {
        // Arrange
        await using var factory = Factory();
        using var client = factory.CreateClient();
        await LoginAndSeedAsync(factory, client);
        var command = Uuid.CreateVersion4();
        var body = new { user_id = Uuid.CreateVersion4(), expected_revision = 1, reason = "Cover operations" };
        var route = $"/api/v1/platform/operator-grants/{command}";

        // Act
        using var first = await client.PutAsJsonAsync(route, body);
        using var retry = await client.PutAsJsonAsync(route, body);

        // Assert
        Assert.Equal(HttpStatusCode.OK, first.StatusCode);
        Assert.Equal(HttpStatusCode.OK, retry.StatusCode);
        Assert.Equal("{}", await first.Content.ReadAsStringAsync());
        Assert.Equal(await first.Content.ReadAsByteArrayAsync(), await retry.Content.ReadAsByteArrayAsync());
        Assert.Equal("application/json", first.Content.Headers.ContentType?.MediaType);
    }

'''
red=red.replace(point,method+point,1);put(path,red,'tests')
for template in (p.OUT/'templates').glob('*.cs.txt'):
 name=template.name.removesuffix('.txt');dest=('test/Compliance.Tests/Features/NativeOperations/' if name.startswith('NativeFirstResponseProductionHttpTests') or name.startswith('NativeFirstResponseBridgeTests') or name.startswith('NativeFirstResponseEndpointTests') or name.startswith('NativeHttp') else A)+name
 put(dest,template.read_text(),'tests' if name.startswith('NativeFirstResponseProductionHttpTests') else 'implementation')
p.emit()
new(K+'INativeOperationTransportObserver.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.NativeOperations;

/// <summary>Observes a real committed/replayed native first response without reading or deciding domain authority.</summary>
public interface INativeOperationTransportObserver
{
    void Observe(AcceptedOperationBinding binding, IExecutionContext context, AcceptedAppendResult accepted);
}''')
path=K+'NativeOperationExecutor.cs';text=p.original(path)
text=text.replace('    IImmutableContentStore content)', '    IImmutableContentStore content, INativeOperationTransportObserver? transport = null)',1)
point='    /// <summary>Executes the operation and returns its closed acceptance outcome.</summary>'
a=text.index(point);b=text.index('        ArgumentNullException.ThrowIfNull(operation);',a)
text=text[:a]+'''    /// <summary>Executes admission, then exposes only a successful committed/replayed first response to the optional transport.</summary>
    public async ValueTask<Result<AcceptedAppendResult>> ExecuteAsync<TAggregate>(
        NativeOperation<TAggregate> operation, IExecutionContext context, CancellationToken ct = default)
        where TAggregate : Aggregate
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(context);
        var result = await ExecuteCoreAsync(operation, context, ct).ConfigureAwait(false);
        if (result.IsSuccess && result.Value is AcceptedAppendResult.Committed or AcceptedAppendResult.Replayed)
            transport?.Observe(operation.Binding, context, result.Value);
        return result;
    }

    async ValueTask<Result<AcceptedAppendResult>> ExecuteCoreAsync<TAggregate>(
        NativeOperation<TAggregate> operation, IExecutionContext context, CancellationToken ct)
        where TAggregate : Aggregate
    {
'''+text[b:]
put(path,text)
p.emit()
# A descriptor read on an exact HTTP replay can fail before the success observer runs.
path=K+'INativeOperationTransportObserver.cs';text=(p.OUT/'after'/path).read_text().replace('using Cntryl.Portia;', 'using Cntryl.Portia;\nusing Bdgrz.Compliance.Features.Content;')
text=text.replace('    void Observe(', '''    RequestError? ClassifyFailure(AcceptedOperationBinding binding, IExecutionContext context,
        ImmutableContentIntegrityException error) => null;
    void Observe(''');put(path,text)
path=K+'NativeOperationExecutor.cs';text=(p.OUT/'after'/path).read_text()
text=text.replace('        var result = await ExecuteCoreAsync(operation, context, ct).ConfigureAwait(false);', '''        Result<AcceptedAppendResult> result;
        try
        {
            result = await ExecuteCoreAsync(operation, context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            var classified = transport?.ClassifyFailure(operation.Binding, context, error);
            if (classified is null)
                throw;
            return Result<AcceptedAppendResult>.Failure(classified);
        }''');put(path,text)
# Existing fixed legacy Unit transport expectations intentionally follow their selected 200 contract.
path='test/Compliance.Tests/Features/Tenants/PlatformOperatorTransportTests.cs';text=red.replace('HttpStatusCode.NoContent','HttpStatusCode.OK');put(path,text,'migrated-tests')
p.emit()
# These existing transport fixtures cover only explicit catalog-selected immediate Unit200 commands.
for path in ['test/Compliance.Tests/Features/AccessControl/RbacContentTransportTests.cs',
    'test/Compliance.Tests/Features/AccessControl/TeamRoleTransportTests.cs',
    'test/Compliance.Tests/Features/Tenants/TenantInvitationTransportTests.cs']:
    text=p.original(path).replace('HttpStatusCode.NoContent','HttpStatusCode.OK')
    put(path,text,'migrated-tests')
p.emit()

# Keep endpoint rewriting in this process so the complete manifest retains every baseline path.
import rewrite_program
p.emit()
