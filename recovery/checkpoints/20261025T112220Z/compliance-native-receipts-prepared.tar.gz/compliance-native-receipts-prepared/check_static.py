from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,re,json,subprocess,os
r=Path('/tmp/compliance-native-receipts-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');p=Parser(Language(tree_sitter_c_sharp.language()))
files=list((r/'work').rglob('*.cs'))+list((r/'shared-work').rglob('*.cs'))
def walk(n):
 stack=[n]
 while stack:
  current=stack.pop();yield current;stack.extend(reversed(current.children))
def text(b,n):return b[n.start_byte:n.end_byte].decode()
def signature(b,n):
 params=[x for x in n.named_children if x.type=='parameter'];return(sum('=' not in text(b,q) and 'params ' not in text(b,q) for q in params),len(params))
types={};syntax=[];errors=[];removed=[];assertdrops=[];missing=[];newNames=[];oldNames=0;calls=0;targetTyped=[]
for f in files:
 b=f.read_bytes();tree=p.parse(b);root=tree.root_node
 if root.has_error:syntax.append(str(f.relative_to(r)))
 if '/src/' not in str(f):continue
 for n in walk(root):
  if n.type not in {'class_declaration','record_declaration','struct_declaration'}:continue
  name=n.child_by_field_name('name');pl=next((c for c in n.children if c.type=='parameter_list'),None)
  if name is None:continue
  key=text(b,name)
  if pl:types.setdefault(key,set()).add(signature(b,pl))
  body=n.child_by_field_name('body')
  if body:
   for c in body.named_children:
    if c.type=='constructor_declaration':
     cp=c.child_by_field_name('parameters');
     if cp is not None:types.setdefault(key,set()).add(signature(b,cp))
# Relevant changed external constructors, resolving through effective main + work.
known={k:v for k,v in types.items() if k in {'SignificantChangeReader','TypeIIPeriodCloseHistory','FitzNativeEventReceiptReader','ReceiptTrackingEventStore'}}
for f in files:
 b=f.read_bytes();tree=p.parse(b);root=tree.root_node;aliases={a.split(' = ')[0].strip():a.split(' = ')[1].rstrip(';').split('.')[-1] for a in re.findall(r'using (\w+ = [^;]+;)',b.decode())}
 for n in walk(root):
  if n.type=='implicit_object_creation_expression':targetTyped.append({'path':str(f.relative_to(r)),'line':n.start_point.row+1,'text':text(b,n)[:140]});continue
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((c for c in n.children if c.type=='argument_list'),None)
  if typ is None or args is None:continue
  key=text(b,typ).split('.')[-1];key=aliases.get(key,key)
  if key not in known:continue
  count=sum(c.type=='argument' for c in args.children);calls+=1
  if not any(lo<=count<=hi for lo,hi in known[key]):errors.append({'path':str(f.relative_to(r)),'line':n.start_point.row+1,'type':key,'count':count,'expected':sorted(known[key])})
for b in (r/'base/test').rglob('*.cs'):
 rel=b.relative_to(r/'base');f=r/'work'/rel
 if not f.exists():missing.append(str(rel));continue
 old=set(re.findall(r'\b(Should\w+)\s*\(',b.read_text()));new=set(re.findall(r'\b(Should\w+)\s*\(',f.read_text()));oldNames+=len(old)
 removed.extend({'path':str(rel),'name':name} for name in sorted(old-new));newNames.extend({'path':str(rel),'name':name} for name in sorted(new-old))
 if f.read_text().count('Assert.')<b.read_text().count('Assert.'):assertdrops.append({'path':str(rel),'before':b.read_text().count('Assert.'),'after':f.read_text().count('Assert.')})
for f in (r/'work/test').rglob('*.cs'):
 if not (r/'base'/f.relative_to(r/'work')).exists():newNames.extend({'path':str(f.relative_to(r/'work')),'name':name} for name in sorted(set(re.findall(r'\b(Should\w+)\s*\(',f.read_text()))))
syntax_program = "from pathlib import Path;from tree_sitter import Language,Parser;import tree_sitter_c_sharp,json;p=Parser(Language(tree_sitter_c_sharp.language()));r=Path('/tmp/compliance-native-receipts-prepared');files=list((r/'work').rglob('*.cs'))+list((r/'shared-work').rglob('*.cs'));print(json.dumps([str(f.relative_to(r)) for f in files if p.parse(f.read_bytes()).root_node.has_error]))"
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',syntax_program],env={**os.environ,'PYTHONPATH':'/tmp/compliance-csharp-syntax314'},text=True))
report={'qualification' :'Static only; modern C# syntax parse, constructor arity via stable Python binding, no compiler/runtime/Jev qualification.','csharpFilesParsed':len(files),'syntaxErrors':syntax,'explicitRelevantConstructorCalls':calls,'explicitConstructorArityErrors':errors,'existingAcceptanceNames':oldNames,'removedAcceptanceNames':removed,'perFileAssertionCountDrops':assertdrops,'missingOriginalTestPaths':missing,'newAcceptanceNames':newNames,'targetTypedConstructorsForManualAudit':targetTyped,'knownRelevantConstructors':{k:sorted(v) for k,v in known.items()}}
(r/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in {'targetTypedConstructorsForManualAudit','knownRelevantConstructors','newAcceptanceNames'}},indent=2))
