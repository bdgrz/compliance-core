from pathlib import Path
P=Path('/tmp/compliance-native-receipts-prepared/work');T='test/Compliance.Tests/Features/SourceFacts/'
def put(rel,s):p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(T+'FitzNativeEventReceiptReaderTests.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Tests.Hosting.Persistence;
using Cntryl.Fitz;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.SourceFacts;

public sealed class FitzNativeEventReceiptReaderTests
{
    static readonly EventStreamAddress Stream = new("receipt-tenant","tenants","acme");
    static readonly DateTimeOffset Receipt = new(2026,10,24,12,0,0,TimeSpan.Zero);
    [Fact]
    public async Task ShouldReturnVerifiedBrokerMillisecondsGivenOccurrenceTimePrecedesCommit()
    {
        // Arrange
        await using var provider = EventPersistenceFrameTests.Compose();var serializer = provider.GetRequiredService<IDomainEventSerializer>();
        var value = Source();var raw = Raw(serializer.Serialize(value));var client = new ResolverStreamClient((_,_,_,_) => Page(raw));
        var reader = new FitzNativeEventReceiptReader(client,serializer);

        // Act
        var actual = await reader.RecordedAtAsync(new(Stream,value,1,EventCursor.Start));

        // Assert
        Assert.Equal(Receipt,actual);Assert.NotEqual(value.Metadata.OccurredOn,actual);
        var request = Assert.Single(client.Requests);Assert.Equal(Stream.ToString(),request.Route);Assert.Equal(1UL,request.Start);
    }
    [Theory]
    [InlineData("route")]
    [InlineData("offset")]
    [InlineData("event_id")]
    [InlineData("aggregate_version")]
    [InlineData("aggregate_id")]
    [InlineData("occurrence_metadata")]
    [InlineData("payload")]
    [InlineData("timestamp_absent")]
    [InlineData("timestamp_overflow")]
    public async Task ShouldRefuseReceiptGivenExactNativeTupleOrPayloadDiffers(string changed)
    {
        // Arrange
        await using var provider = EventPersistenceFrameTests.Compose();var serializer = provider.GetRequiredService<IDomainEventSerializer>();
        var value = Source();var actual = value with { Name = changed == "payload" ? "Different owner payload" : value.Name };
        actual.AttachMetadata(value.Metadata with
        {
            EventId = changed == "event_id" ? Uuid.CreateVersion4() : value.Metadata.EventId,
            AggregateVersion = changed == "aggregate_version" ? 3UL : value.Metadata.AggregateVersion,
            AggregateId = changed == "aggregate_id" ? Uuid.CreateVersion4() : value.Metadata.AggregateId,
            OccurredOn = changed == "occurrence_metadata" ? value.Metadata.OccurredOn.AddSeconds(1) : value.Metadata.OccurredOn,
        });
        var raw = Raw(serializer.Serialize(actual)) with
        {
            Route = changed == "route" ? "stream://foreign-tenant/tenants/acme" : Stream.ToString(),
            Offset = changed == "offset" ? 2UL : 1UL,
            Timestamp = changed == "timestamp_absent" ? 0UL : changed == "timestamp_overflow" ? ulong.MaxValue : checked((ulong)Receipt.ToUnixTimeMilliseconds()),
        };
        var reader = new FitzNativeEventReceiptReader(new ResolverStreamClient((_,_,_,_) => Page(raw)),serializer);

        // Act
        var failure = await Record.ExceptionAsync(async () => await reader.RecordedAtAsync(new(Stream,value,1,EventCursor.Start)));

        // Assert
        Assert.IsType<ImmutableContentIntegrityException>(failure);
    }
    [Fact]
    public async Task ShouldRemainPendingGivenExactBrokerReceiptIsAbsent()
    {
        // Arrange
        await using var provider = EventPersistenceFrameTests.Compose();
        var client = new ResolverStreamClient((_,_,_,_) => new StreamReadPage([],new(0,null,null,null,11,100,false)));
        var reader = new FitzNativeEventReceiptReader(client,provider.GetRequiredService<IDomainEventSerializer>());

        // Act
        var failure = await Record.ExceptionAsync(async () => await reader.RecordedAtAsync(new(Stream,Source(),1,EventCursor.Start)));

        // Assert
        Assert.IsType<ImmutableContentUnavailableException>(failure);
    }
    static TenantRegistered Source()
    {
        var value = new TenantRegistered(Uuid.CreateVersion4(),Uuid.CreateVersion4(),"Acme","acme");
        value.AttachMetadata(new(Uuid.CreateVersion4(),Uuid.CreateVersion4(),2,Receipt.AddDays(-10)));return value;
    }
    static StreamRecord Raw(ReadOnlyMemory<byte> bytes) => new(Stream.ToString(),1,null,null,null,bytes,null,checked((ulong)Receipt.ToUnixTimeMilliseconds()));
    static StreamReadPage Page(StreamRecord value) => new([new(value.Route,StreamReadItemKind.Event,value,0,0,0,null)],new(value.Offset,null,null,null,11,100,false));
}
''')
put(T+'FitzNativeEventReceiptReaderBrokerTests.cs','''using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Tests.E2E;
using Cntryl.Fitz;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.SourceFacts;

[Collection(BrokerCollectionDefinition.Name)]
[Trait("Category","BrokerIntegration")]
public sealed class FitzNativeEventReceiptReaderBrokerTests(BrokerStackFixture broker) : IClassFixture<BrokerStackFixture>
{
    [Fact]
    public async Task ShouldExposeActualBrokerCommitMillisecondsGivenOldOccurrenceAndPreparationCut()
    {
        // Arrange
        await using var factory = E2EAppFactory.Create(broker);using var http = factory.CreateClient();
        var stream = new EventStreamAddress("receipt-"+Guid.NewGuid().ToString("N"),"tenants","acme");
        var events = factory.Services.GetRequiredService<IEventStore>();var serializer = factory.Services.GetRequiredService<IDomainEventSerializer>();
        var before = DateTimeOffset.UtcNow;var cutoff = before.AddMinutes(-1);
        var value = new TenantRegistered(Uuid.CreateVersion4(),Uuid.CreateVersion4(),"Acme","acme");
        value.AttachMetadata(new(Uuid.CreateVersion4(),Uuid.CreateVersion4(),1,cutoff.AddDays(-1)));
        await events.AppendAsync(stream,0,[value]);var after = DateTimeOffset.UtcNow;
        var records = new List<DomainEventRecord>();await foreach (var record in events.ReadAsync(stream,0,CancellationToken.None))records.Add(record);
        var source = Assert.Single(records);
        await using var fitz = new Client(new ClientConfig(new Uri(broker.WebSocketEndpoint,UriKind.Absolute),Timeout:TimeSpan.FromSeconds(10)));
        await fitz.ConnectWhenReadyAsync(new ConnectWhenReadyOptions(TimeSpan.FromSeconds(15)));
        var reader = new FitzNativeEventReceiptReader(fitz.Stream,serializer);

        // Act
        var recordedAt = await reader.RecordedAtAsync(source);var raw = await fitz.Stream.ReadPageAsync(stream.ToString(),0,1);

        // Assert
        var committed = Assert.Single(raw.Items).Record!;
        Assert.Equal(DateTimeOffset.FromUnixTimeMilliseconds(checked((long)committed.Timestamp)),recordedAt);
        Assert.True(recordedAt > cutoff);Assert.Equal(value.Metadata.OccurredOn,source.Event.Metadata.OccurredOn);
        Assert.InRange(recordedAt,before.AddSeconds(-5),after.AddSeconds(5));
        Assert.Equal(0,recordedAt.Ticks % TimeSpan.TicksPerMillisecond);
        Assert.Equal(source.Stream.ToString(),committed.Route);Assert.Equal(source.ResourceOffset,committed.Offset);
    }
}
''')
