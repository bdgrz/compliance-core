from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
P=Path('/tmp/compliance-native-receipts-prepared')
def sha(b):return hashlib.sha256(b).hexdigest()
def fs(root):return {str(f.relative_to(root)):f for f in root.rglob('*') if f.is_file()}
a=fs(P/'base');b=fs(P/'work');groups={'implementation':[],'tests':[],'shared':[]};rows=[]
for path in sorted(a.keys()|b.keys()):
 before=a[path].read_bytes() if path in a else None;after=b[path].read_bytes() if path in b else None
 if before==after:continue
 group='shared' if path=='src/Compliance.Core/ComplianceServiceCollectionExtensions.cs' else 'tests' if path.startswith('test/') else 'implementation'
 groups[group].append(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True) if before else [],after.decode().splitlines(keepends=True) if after else [],fromfile='a/'+path if before is not None else '/dev/null',tofile='b/'+path if after is not None else '/dev/null')))
 rows.append({'path':path,'group':group,'beforeSha256':sha(before) if before is not None else None,'afterSha256':sha(after) if after is not None else None})
artifacts=[]
for group,parts in groups.items():
 f=P/(group+'.patch');f.write_text(''.join(parts));artifacts.append({'file':f.name,'sha256':sha(f.read_bytes()),'paths':sum(x['group']==group for x in rows)})
artifacts.append({'file':'behavioral-red.patch','sha256':sha((P/'behavioral-red.patch').read_bytes()),'paths':2})
r=P/'reconstruction';shutil.rmtree(r,ignore_errors=True);shutil.copytree(P/'base',r);logs=[]
for group in groups:
 p=subprocess.run(['patch','-p1','-E','--batch','-i',str(P/(group+'.patch'))],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stdout+p.stderr;logs.append(p.stdout)
for item in rows:assert sha((r/item['path']).read_bytes())==item['afterSha256'],item['path']
r=P/'red-reconstruction';shutil.rmtree(r,ignore_errors=True);shutil.copytree(P/'base',r);p=subprocess.run(['patch','-p1','--batch','-i',str(P/'behavioral-red.patch')],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stdout+p.stderr
for name,artifact in [('SignificantChangeNativeTests.cs','red-native-tests.cs'),('SignificantChangeNativeFixture.cs','red-native-fixture.cs')]:assert (r/'test/Compliance.Tests/Features/Changes'/name).read_bytes()==(P/artifact).read_bytes()
(P/'manifest.json').write_text(json.dumps({'qualification':'offline; parent runtime/Jev pending','artifacts':artifacts,'paths':rows},indent=2)+'\n');(P/'reconstruction.json').write_text(json.dumps({'exactPaths':len(rows),'standaloneRedExact':True,'patchLogs':logs},indent=2)+'\n')
(P/'handoff.json').write_text(json.dumps({'status':'frozen-offline','paths':len(rows),'artifacts':artifacts,'documentation':'README.md','static':'static-checks.json','manifest':'manifest.json','reconstruction':'reconstruction.json','unitFilter':'FullyQualifiedName~SignificantChangeNativeTests|FullyQualifiedName~FitzNativeEventReceiptReaderTests|FullyQualifiedName~TypeIIPeriodCommandHandlerTests','brokerFilter':'Category=BrokerIntegration&FullyQualifiedName~FitzNativeEventReceiptReaderBrokerTests.ShouldExposeActualBrokerCommitMillisecondsGivenOldOccurrenceAndPreparationCut'},indent=2)+'\n');print((P/'handoff.json').read_text())
