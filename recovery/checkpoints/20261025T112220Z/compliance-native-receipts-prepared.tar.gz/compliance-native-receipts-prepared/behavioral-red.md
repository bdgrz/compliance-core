Tests-only RED applies to the current Change owner surface without the new receipt interface/constructor dependency:

- `FullyQualifiedName~SignificantChangeNativeTests.ShouldReadHistoryGivenPreparationTimestampRegressesAcrossValidNativeAppends`
- `FullyQualifiedName~SignificantChangeNativeTests.ShouldExcludePreparedBeforeCutGivenNativeAppendCommitsAfterRecordedThrough`

The first reproduces a valid link/description history whose preparation times descend. The second advances the controlled clock at immutable publication, after operation preparation and before the actual append, so old AcceptedAt filtering wrongly includes the late commit. Its fixture-only synchronous write hook compiles with old and new sources. Reverse standalone RED before full source/tests. Additional new-interface tests exercise non-prefix refusal, missing authority, no receipt calls on ordinary reads, and the authenticated Fitz tuple/commit timestamp adapter.
