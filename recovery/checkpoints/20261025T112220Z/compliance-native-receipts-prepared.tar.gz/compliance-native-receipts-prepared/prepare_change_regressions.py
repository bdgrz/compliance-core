from pathlib import Path
import difflib,re
P=Path('/tmp/compliance-native-receipts-prepared');T='test/Compliance.Tests/Features/Changes/';name='SignificantChangeNativeTests.cs'
mono='''    [Fact]
    public async Task ShouldReadHistoryGivenPreparationTimestampRegressesAcrossValidNativeAppends()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();
        var rules = new SignificantChangeRules(fixture.Tenant,fixture.Program,fixture.Change);
        var work = Uuid.CreateVersion4();var assessor = Uuid.CreateVersion4();var member = Uuid.CreateVersion4();var started = fixture.Clock.Now;
        Assert.Null(rules.Record(fixture.Body(),member,"Recorder",started));
        Assert.Null(rules.Assess(1,new SignificantChangeImpactContent("significant","Reviewed material system boundary and description impact.",
            true,false,false,false,["scope","system_description"],[new("control",Uuid.CreateVersion4(),Uuid.CreateVersion4(),1)],
            [work],[],[],[],true),assessor,"Assessor",started.AddMinutes(1)));
        Assert.Null(rules.LinkReviewWork(2,[work],member,"Work linker",started.AddMinutes(3)));
        Assert.Null(rules.RecordSystemDescriptionDecision(3,"no_change",Uuid.CreateVersion4(),"Exact independent decision.",
            member,"Decision maker",started.AddMinutes(2)));
        await ChangeSeeds.WriteAsync(fixture.Writer,fixture.Content,rules);

        // Act
        var current = await fixture.Changes.ReadAsync(fixture.Tenant,fixture.Program,fixture.Change);

        // Assert
        Assert.Equal(4,current.View!.Revision);Assert.True(current.View.PeriodCloseEligible);
        var facts = await fixture.FactsAsync();Assert.True(((ISignificantChangeFact)facts[3]).Operation.AcceptedAt < ((ISignificantChangeFact)facts[2]).Operation.AcceptedAt);
    }

'''
late='''    [Fact]
    public async Task ShouldExcludePreparedBeforeCutGivenNativeAppendCommitsAfterRecordedThrough()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();var original = fixture.Body();await fixture.RecordAsync(original);
        var cutoff = fixture.Clock.Now.AddMinutes(1);
        fixture.Content.BeforeWrite = () => fixture.Clock.Now = cutoff.AddMinutes(1);
        var request = new ReviseSignificantChange(Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Change,1,
            original with { Title = "Prepared before cut but committed later" },"Later append");
        Assert.True((await new ReviseSignificantChangeHandler(fixture.Operations).HandleAsync(fixture.Context(request),CancellationToken.None)).IsSuccess);

        // Act
        var historical = await fixture.Changes.ReadThroughAsync(fixture.Tenant,fixture.Program,fixture.Change,cutoff);
        var current = await fixture.Changes.ReadAsync(fixture.Tenant,fixture.Program,fixture.Change);

        // Assert
        Assert.Equal(original.Title,historical.View!.Current!.Content.Title);Assert.Equal(1,historical.View.Revision);
        Assert.Equal("Prepared before cut but committed later",current.View!.Current!.Content.Title);
        Assert.True(((ISignificantChangeFact)(await fixture.FactsAsync())[^1]).Operation.AcceptedAt < cutoff);
    }

'''
p=P/'base'/T/name;base=p.read_text();red=base.replace('    [Fact]\n',mono+late+'    [Fact]\n',1);(P/'red-native-tests.cs').write_text(red)
fp='SignificantChangeNativeFixture.cs';fb=(P/'base'/T/fp).read_text()
def hook(s):
 s=s.replace('        public Func<Task>? BeforeRead { get; set; }','        public Func<Task>? BeforeRead { get; set; }\n        public Action? BeforeWrite { get; set; }')
 s=re.sub(r'(public Task<ImmutableContentRef> WriteVerifiedAsync\([^;]+?CancellationToken ct = default\))\s*=>\s*inner.WriteVerifiedAsync\(([^;]+)\);',r'''\1
        {
            if (BeforeWrite is { } before) { BeforeWrite = null;before(); }
            return inner.WriteVerifiedAsync(\2);
        }''',s,flags=re.S)
 return s
fr=hook(fb);assert 'BeforeWrite = null' in fr;(P/'red-native-fixture.cs').write_text(fr)
patch=''.join(difflib.unified_diff(base.splitlines(keepends=True),red.splitlines(keepends=True),fromfile='a/'+T+name,tofile='b/'+T+name))+''.join(difflib.unified_diff(fb.splitlines(keepends=True),fr.splitlines(keepends=True),fromfile='a/'+T+fp,tofile='b/'+T+fp));(P/'behavioral-red.patch').write_text(patch)
p=P/'work'/T/fp;full=hook(p.read_text());full=re.sub(r'new SignificantChangeReader\(Reader,\s*Events,\s*Content\)','new SignificantChangeReader(Reader,Events,Content,Receipts)',full);p.write_text(full)
p=P/'work'/T/name;s=p.read_text().replace('    [Fact]\n',mono+late+'    [Fact]\n',1);s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
needle='    static async Task ProjectAsync';more='''    [Fact]
    public async Task ShouldRefuseNonPrefixReceiptCutGivenBrokerTimestampsDoNotOrderCausally()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();var body = fixture.Body();await fixture.RecordAsync(body);
        var cutoff = fixture.Clock.Now;
        Assert.True((await new ReviseSignificantChangeHandler(fixture.Operations).HandleAsync(fixture.Context(new ReviseSignificantChange(Uuid.CreateVersion4(),
            fixture.Tenant,fixture.Program,fixture.Change,1,body with { Title = "Later causal event" },"Correction")),CancellationToken.None)).IsSuccess);
        var receipts = new ChosenReceipts(source => ((ISignificantChangeFact)source.Event).NativeSequence == 1 ? cutoff.AddMinutes(1) : cutoff.AddMinutes(-1));
        var reader = new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Content,receipts);

        // Act
        var failure = await Record.ExceptionAsync(async () => await reader.ReadThroughAsync(fixture.Tenant,fixture.Program,fixture.Change,cutoff));

        // Assert
        Assert.IsType<ImmutableContentIntegrityException>(failure);Assert.Equal(2,receipts.Reads);
    }
    [Fact]
    public async Task ShouldNotReadReceiptAuthorityGivenOrdinaryCurrentHistoryQuery()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();await fixture.RecordAsync();
        var receipts = new ChosenReceipts(_ => throw new InvalidOperationException("Current reads never require receipt network calls."));
        var reader = new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Content,receipts);

        // Act
        var current = await reader.ReadAsync(fixture.Tenant,fixture.Program,fixture.Change);

        // Assert
        Assert.NotNull(current.View);Assert.Equal(0,receipts.Reads);
    }
    [Fact]
    public async Task ShouldRemainPendingGivenRecordedThroughReaderHasNoReceiptAuthority()
    {
        // Arrange
        await using var fixture = new SignificantChangeNativeFixture();await fixture.RecordAsync();
        var reader = new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Content);

        // Act
        var failure = await Record.ExceptionAsync(async () => await reader.ReadThroughAsync(fixture.Tenant,fixture.Program,fixture.Change,fixture.Clock.Now));

        // Assert
        Assert.IsType<ImmutableContentUnavailableException>(failure);
    }
    sealed class ChosenReceipts(Func<DomainEventRecord,DateTimeOffset> at) : INativeEventReceiptReader
    {
        public int Reads { get; private set; }
        public ValueTask<DateTimeOffset> RecordedAtAsync(DomainEventRecord source,CancellationToken ct = default)
        { Reads++;return ValueTask.FromResult(at(source)); }
    }

''';assert needle in s;s=s.replace(needle,more+needle);p.write_text(s)
(P/'behavioral-red.md').write_text('''Tests-only RED applies to the current Change owner surface without the new receipt interface/constructor dependency:

- `FullyQualifiedName~SignificantChangeNativeTests.ShouldReadHistoryGivenPreparationTimestampRegressesAcrossValidNativeAppends`
- `FullyQualifiedName~SignificantChangeNativeTests.ShouldExcludePreparedBeforeCutGivenNativeAppendCommitsAfterRecordedThrough`

The first reproduces a valid link/description history whose preparation times descend. The second advances the controlled clock at immutable publication, after operation preparation and before the actual append, so old AcceptedAt filtering wrongly includes the late commit. Its fixture-only synchronous write hook compiles with old and new sources. Reverse standalone RED before full source/tests. Additional new-interface tests exercise non-prefix refusal, missing authority, no receipt calls on ordinary reads, and the authenticated Fitz tuple/commit timestamp adapter.
''')
