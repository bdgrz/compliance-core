# Remaining recorded-through consumers

Read-only inventory: 21 Type I source families feed close reconciliation. The 20 contributor files (Commitment reader serves two families) currently use preparation/occurrence timestamps or ignore the extra recorded cutoff. ControlEvaluationReader and TypeII close-material discovery also have direct incorrect receipt claims. No source changes were made by this inventory.

The frozen Change receipt delta and queued Incident migration are separate from these remaining family gaps. Current main is on independent Roster integration; exact source SHAs/evidence are in the JSON artifact.

| Source | Current selector | Required follow-on |
|---|---|---|
| `BoundaryTypeIBaselineSourceContributor.cs` | version.ChangedAt | native effective-version reader; select source native facts by broker receipt while preserving the effective-date dimension |
| `ControlTypeIBaselineSourceContributor.cs` | version.ApprovedAt | native ControlReader exact approval proof available; broker receipt belongs to that committed fact |
| `CommitmentTypeIBaselineSourceReader.cs` | view.Approval.DecidedAt / view.Decision.DecidedAt; retirement.OccurredAt | native Commitment version/decision facts; preserve selected effective dates and original logical digest preimages |
| `PolicyTypeIBaselineSourceContributor.cs` | version.ApprovedAt; retirement/periodic_review.DecidedAt | PolicyReadSnapshot verified history exists; gate each relevant native fact by verified receipt |
| `FindingTypeIBaselineSourceContributor.cs` | native.Operation.AcceptedAt && fact.Metadata.OccurredOn | direct native remediation facts; replace receipt predicates, retaining source/revision/content validation |
| `ControlEvaluationTypeIBaselineSourceContributor.cs` | delegates through to ControlEvaluationReader.ReadStatesAsync | own reader has incorrect committed-time claim; keep business StartedAt/RecordedAt/conclusion timing rules separately |
| `ControlEvaluationReader.cs` | record.Event.Metadata.OccurredOn | doc line69 explicitly says committed-at-or-before; use receipt port and causal-prefix checks per source stream |
| `AccessExpectationsTypeIBaselineSourceContributor.cs` | occurredAt && metadata.OccurredOn; priorRecordedAt metadata monotonicity | direct expectation, approvals, exception and population-exception native records |
| `AccessReviewCampaignsTypeIBaselineSourceContributor.cs` | at && metadata.OccurredOn; priorRecordedAt metadata monotonicity | campaign/item and completion selections; do not conflate business chronology validation with broker receipt order |
| `EvidenceGovernanceTypeIBaselineSourceContributor.cs` | link.OccurredAt / metadata.OccurredOn; policy.AssignedAt; retention.RecordedAt/hold times | support/artifact/handling/retention/related-governance paths all need exact recorded cut plus separate effective policy times |
| `RiskTypeIBaselineSourceContributor.cs` | occurredAt && metadata.OccurredOn; native.Operation.AcceptedAt; priorRecordedAt metadata monotonicity | draft/evaluation/methodology/governance histories; peer Risk cutover is active so coordinate its latest reader APIs |
| `ProviderTypeIBaselineSourceContributor.cs` | recordedAt && metadata.OccurredOn | provider assurance/report/review/gap native histories; dependency.EffectiveFrom/Until remains business validity |
| `PolicyCommunicationTypeIBaselineSourceContributor.cs` | AcknowledgedAt / Completed.RecordedAt / ApprovedAt / AmendedAt / ClosedAt / requirement.ChangedAt | launch effective-date dimension is independent; receipt-gate each decision fact while retaining original content hashes |
| `ControlCriterionMappingTypeIBaselineSourceContributor.cs` | ProposedAt / ReviewedAt / RetiredAt | mapping version reconstruction currently selects decisions using business timestamps only |
| `ApplicationTypeIBaselineSourceContributor.cs` | revision.LastChangedAt | carry exact receipt alongside native history rows; preserve retirement.EffectiveAt behavior and current restricted visibility |
| `ReviewedSystemTypeIBaselineSourceContributor.cs` | state.ChangedAt | registered/revised/retired history rows need receipt identity; legacy declared-source qualification remains explicit |
| `TechnologyComponentTypeIBaselineSourceContributor.cs` | revision.ChangedAt | native history is mapped into revision rows; carry receipt separately from canonical source DTO |
| `InformationAssetTypeIBaselineSourceContributor.cs` | revision.ChangedAt | native history is mapped into revision rows; carry receipt separately from canonical source DTO |
| `DataFlowTypeIBaselineSourceContributor.cs` | revision.ChangedAt | retain effective-from/range checks while using independent commit selection |
| `CriteriaTypeIBaselineSourceContributor.cs` | ignores context.RecordedThrough; CriteriaSelectionAt(effectiveThrough), overlay.RecordedAt | receipt-check program criteria selection and license-overlay facts; static edition content keeps its original canonical preimage |
| `WorkforceTypeIBaselineSourceContributor.cs` | ignores context.RecordedThrough; snapshot.FrozenAt | pin exact snapshot native freeze receipt; preserve verified full rows/Merkle identity and physical descriptor |
| `TypeIIPeriodCloseMaterialReader.cs` | payload.occurred_at else INativeOperationFact.Operation.AcceptedAt | current and frozen SD version both have this receipt claim; apply shared receipt seam to scoped native discovery, with current authorization and source fences |

Keep each family’s effective-date rules distinct from broker receipt selection. Preserve default-null TypeI behavior and exact existing canonical digest preimages. Remove only unsupported receipt/monotonicity assumptions; do not weaken real business chronology or current restricted authorization. The implementation order and concrete regressions are in the JSON report.
