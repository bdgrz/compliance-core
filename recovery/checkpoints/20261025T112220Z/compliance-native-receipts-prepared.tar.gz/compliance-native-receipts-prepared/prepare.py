from pathlib import Path
import shutil,json,hashlib
R=Path('/Users/jrepanich/Code/bdgrz/compliance-core');P=Path('/tmp/compliance-native-receipts-prepared');W=P/'work'
paths=['src/Compliance.Core/Features/Changes/SignificantChangeReader.cs','src/Compliance.Core/Features/Operations/TypeIIPeriodCloseHistory.cs','src/Compliance.Core/Features/Operations/TypeIIPeriodCloseNativeSource.cs','test/Compliance.Tests/Testing/TypeIIRangeHost.cs','test/Compliance.Tests/Features/Changes/SignificantChangeNativeFixture.cs','test/Compliance.Tests/Features/Changes/SignificantChangeNativeTests.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseSources.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseArchive.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs']
for rel in paths:
 for folder in ['base','work']:
  f=P/folder/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,f)
def put(rel,s):
 p=W/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put('src/Compliance.Core/Features/SourceFacts/INativeEventReceiptReader.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceFacts;

/// <summary>Verifies the exact committed native record and returns its broker-assigned receipt time; never occurrence/preparation time.</summary>
public interface INativeEventReceiptReader
{
    ValueTask<DateTimeOffset> RecordedAtAsync(DomainEventRecord source,CancellationToken ct = default);
}
''')
put('src/Compliance.Core/Features/SourceFacts/FitzNativeEventReceiptReader.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Fitz;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceFacts;

/// <summary>Retains Fitz's broker commit timestamp discarded by Portia0.9.1, bound to the complete exact native source tuple and payload.</summary>
sealed class FitzNativeEventReceiptReader(IStreamClient streams,IDomainEventSerializer serializer) : INativeEventReceiptReader
{
    public async ValueTask<DateTimeOffset> RecordedAtAsync(DomainEventRecord source,CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(source);
        if (source.Event.Metadata is not { IsAudit: false } expected || expected.EventId == Uuid.Empty || expected.AggregateVersion == 0)
            throw new ImmutableContentIntegrityException("A receipt requires an exact committed non-audit native event identity and version.");
        var page = await streams.ReadPageAsync(source.Stream.ToString(),source.ResourceOffset,1,new StreamFilterSet(),ct:ct).ConfigureAwait(false);
        if (page.Items.Count == 0 || page.Items.Count == 1 && page.Items[0].Kind != StreamReadItemKind.Event)
            throw new ImmutableContentUnavailableException("The exact native event receipt is not readable from the broker yet.");
        if (page.Items.Count != 1 || page.Items[0].Record is not { } record || record.Route != source.Stream.ToString() || record.Offset != source.ResourceOffset)
            throw new ImmutableContentIntegrityException("The broker receipt resolved on another concrete stream or resource offset.");
        DomainEvent actual;
        try { actual = serializer.Deserialize(record.Body); }
        catch (Exception exception) when (exception is not OperationCanceledException)
        { throw new ImmutableContentIntegrityException("The broker receipt payload cannot be decoded as its exact native event."); }
        if (actual.GetType() != source.Event.GetType() || actual.Metadata is not { IsAudit: false } observed ||
            observed.EventId != expected.EventId || observed.AggregateId != expected.AggregateId || observed.AggregateVersion != expected.AggregateVersion ||
            EventKind.Of(actual) != EventKind.Of(source.Event) || ContentDigest.Sha256(actual,actual.GetType()) != ContentDigest.Sha256(source.Event,source.Event.GetType()))
            throw new ImmutableContentIntegrityException("The broker receipt differs from the exact native event identity, version, kind or payload digest.");
        if (record.Timestamp == 0 || record.Timestamp > 253402300799999UL)
            throw new ImmutableContentIntegrityException("The broker receipt has no supported commit timestamp.");
        return DateTimeOffset.FromUnixTimeMilliseconds(checked((long)record.Timestamp));
    }
}
''')
put('test/Compliance.Tests/Testing/ReceiptTrackingEventStore.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

/// <summary>Explicit test commit authority: records its controlled clock only after a successful append, independently of event/operation timestamps.</summary>
sealed class ReceiptTrackingEventStore(IEventStore inner,TimeProvider clock) : IEventStore,INativeEventReceiptReader
{
    readonly object _gate = new();
    readonly Dictionary<(EventStreamAddress Stream,ulong Offset),(Uuid Event,ulong Version,string Kind,string Sha256,DateTimeOffset At)> _receipts = [];
    public TimeProvider Clock { get; set; } = clock;
    public IAsyncEnumerable<DomainEventRecord> ReadAsync(EventStreamAddress stream,ulong offset,CancellationToken ct) => inner.ReadAsync(stream,offset,ct);
    public IAsyncEnumerable<DomainEventRecord> ReadAsync(EventStreamPattern pattern,EventCursor cursor,CancellationToken ct) => inner.ReadAsync(pattern,cursor,ct);
    public async ValueTask AppendAsync(EventStreamAddress stream,ulong expected,IReadOnlyList<DomainEvent> events,CancellationToken ct = default)
    {
        await inner.AppendAsync(stream,expected,events,ct).ConfigureAwait(false);
        var at = Clock.GetUtcNow();
        lock (_gate)
            for (var index = 0; index < events.Count; index++)
            {
                var value = events[index];
                _receipts.Add((stream,checked(expected+(ulong)index)),(value.Metadata.EventId,value.Metadata.AggregateVersion,
                    EventKind.Of(value),ContentDigest.Sha256(value,value.GetType()),at));
            }
    }
    public ValueTask<DateTimeOffset> RecordedAtAsync(DomainEventRecord source,CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        lock (_gate)
        {
            if (!_receipts.TryGetValue((source.Stream,source.ResourceOffset),out var value))
                throw new ImmutableContentUnavailableException("The test commit receipt is absent.");
            if (source.Event.Metadata.IsAudit || source.Event.Metadata.EventId != value.Event || source.Event.Metadata.AggregateVersion != value.Version ||
                EventKind.Of(source.Event) != value.Kind || ContentDigest.Sha256(source.Event,source.Event.GetType()) != value.Sha256)
                throw new ImmutableContentIntegrityException("The test source differs from its exact recorded commit receipt.");
            return ValueTask.FromResult(value.At);
        }
    }
}
''')
# Normal reads do not assume any ordering of preparation/occurrence timestamps. As-of reads independently resolve every broker receipt.
p=W/paths[0];s=p.read_text();s=s.replace('using Bdgrz.Compliance.Features.Kernel;','using Bdgrz.Compliance.Features.Kernel;\nusing Bdgrz.Compliance.Features.SourceFacts;')
s=s.replace('IImmutableContentStore content)','IImmutableContentStore content,INativeEventReceiptReader? receipts = null)',1)
s=s.replace('        DateTimeOffset? previousReceipt = null;','        var observedSequence = 0L;\n        var excluded = false;')
s=s.replace('fact.NativeSequence != sequence + 1','fact.NativeSequence != observedSequence + 1').replace(' ||\n                previousReceipt is { } receipt && fact.Operation.AcceptedAt < receipt','')
s=s.replace('            if (fact.NativeSequence > owner.NativeSequence || through is { } cutoff && fact.Operation.AcceptedAt > cutoff)\n                break;','''            if (fact.NativeSequence > owner.NativeSequence) break;
            observedSequence = fact.NativeSequence;
            if (through is { } cutoff)
            {
                if (receipts is null) throw new ImmutableContentUnavailableException("The exact broker receipt reader is not configured for this recorded-through query.");
                var recordedAt = await receipts.RecordedAtAsync(record,ct).ConfigureAwait(false);
                if (recordedAt > cutoff) { excluded = true;continue; }
                if (excluded) throw new ImmutableContentIntegrityException("The broker receipt cutoff does not select a complete causal prefix of the owner history.");
            }''')
s=s.replace('            previousReceipt = fact.Operation.AcceptedAt;\n','')
s=s.replace('        if (through is null &&','        if (observedSequence != owner.NativeSequence)\n            throw new ImmutableContentUnavailableException("The complete captured native source cut is not readable yet.");\n        if (through is null &&')
p.write_text(s)
# Area discovery seals exact broker receipt times; no ordering assumptions. Full as-of reader rejects a non-prefix cut.
p=W/paths[1];s=p.read_text().replace('SignificantChangeReader changes, IImmutableContentStore content)','SignificantChangeReader changes, IImmutableContentStore content,INativeEventReceiptReader receipts)')
s=s.replace('            if (state.Value.Program != program || state.Value.At > through)','            if (state.Value.Program != program)')
needle='            if (state.Value.Tenant != tenant';at=s.index(needle);s=s[:at]+'''            var recordedAt = await receipts.RecordedAtAsync(record,ct).ConfigureAwait(false);
            if (recordedAt > through) continue;
'''+s[at:]
s=s.replace('var captured = Capture(record.Stream,record.Event);','var captured = Capture(record.Stream,record.Event) with { RecordedAt = recordedAt };')
s=s.replace('pair.First.EventKind == pair.Second.EventKind &&','pair.First.EventKind == pair.Second.EventKind && pair.First.RecordedAt == pair.Second.RecordedAt &&');p.write_text(s)
p=W/paths[2];s=p.read_text().replace('using System.Text.Json;','using System.Text.Json;\nusing System.Text.Json.Serialization;');at=s.rfind('}');assert at>0;s=s[:at]+'''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public DateTimeOffset? RecordedAt { get; init; }
'''+s[at:];p.write_text(s)
# Explicit fake commit receipts for normal fixture writes; no event timestamp fallback.
p=W/paths[3];s=p.read_text().replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.SourceFacts;')
s=s.replace('        var events = new InMemoryEventStore();','        var events = new ReceiptTrackingEventStore(new InMemoryEventStore(),clock ?? TimeProvider.System);\n        services.AddSingleton<INativeEventReceiptReader>(events);');p.write_text(s)
p=W/paths[4];s=p.read_text();s='using Bdgrz.Compliance.Tests.Testing;\n'+s
s=s.replace('        services.AddSingleton<IEventStore>(Events);','        Receipts = new ReceiptTrackingEventStore(Events,Clock);\n        services.AddSingleton<IEventStore>(Receipts);')
s=s.replace('new SignificantChangeReader(Reader,Events,Content)','new SignificantChangeReader(Reader,Events,Content,Receipts)')
s=s.replace('    public InMemoryEventStore Events { get; } = new();','    public InMemoryEventStore Events { get; } = new();\n    public ReceiptTrackingEventStore Receipts { get; }');p.write_text(s)
for path in paths[6:8]:
 p=W/path;s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
 s=s.replace('new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Host.Content),fixture.Host.Content)','new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Host.Content,fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>()),fixture.Host.Content,fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>())')
 p.write_text(s)
p=W/paths[8];s=p.read_text();needle='        services.AddScoped<ISourceFactResolver, FitzSourceFactResolver>();';assert needle in s;s=s.replace(needle,needle+'\n        services.AddScoped<INativeEventReceiptReader,FitzNativeEventReceiptReader>();');p.write_text(s)
print('receipt adapter and owning source/test seam deltas saved')
