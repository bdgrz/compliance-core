from prep_common import *
core='src/Compliance.Core/Features/Examinations/'
p=copy(core+'TypeIBaselineSourceReadContext.cs');s=p.read_text().replace('    IReadOnlyList<TypeIBaselineSourceReference> PreviouslyCapturedSources);','''    IReadOnlyList<TypeIBaselineSourceReference> PreviouslyCapturedSources)
{
    /// <summary>Optional server-frozen receipt cutoff for a close; the engagement date remains the effective cutoff.</summary>
    public DateTimeOffset? RecordedThrough { get; init; }
}
''');p.write_text(s)
for q in (repo/core).glob('*TypeIBaselineSourceContributor.cs'):
 raw=q.read_text()
 if 'TypeIBaselineSourceReadContext context' not in raw or 'var through = new DateTimeOffset'not in raw:continue
 p=copy(q.relative_to(repo).as_posix());s=p.read_text().replace('var through = new DateTimeOffset(engagement.PeriodStart.ToDateTime(TimeOnly.MaxValue,','var through = context.RecordedThrough ?? new DateTimeOffset(engagement.PeriodStart.ToDateTime(TimeOnly.MaxValue,');p.write_text(s)
p=copy(core+'TypeIBaselinePreviewReader.cs');s=p.read_text();s=s.replace('''    public async ValueTask<Result<TypeIBaselinePreview>> ReadAsync(
        ExaminationEngagementView engagement, Uuid requesterUserId, CancellationToken ct = default)
    {''','''    public ValueTask<Result<TypeIBaselinePreview>> ReadAsync(ExaminationEngagementView engagement,
        Uuid requesterUserId, CancellationToken ct = default) => ReadAsync(engagement, requesterUserId, null, ct);

    /// <summary>Separates the selected effective date from an explicit server-frozen close receipt cutoff.</summary>
    public async ValueTask<Result<TypeIBaselinePreview>> ReadAsync(ExaminationEngagementView engagement,
        Uuid requesterUserId, DateTimeOffset? recordedThrough, CancellationToken ct = default)
    {''');s=s.replace('''                Array.AsReadOnly(sources.ToArray()));''','''                Array.AsReadOnly(sources.ToArray())) { RecordedThrough = recordedThrough };''');p.write_text(s)
p=copy(core+'PublishedTypeIBaselinePreviewReader.cs');s=p.read_text();s=s.replace('''    public async ValueTask<Result<TypeIBaselinePreview>> ReadAsync(ExaminationEngagementView engagement,
        Uuid requesterUserId, CancellationToken ct = default)
    {''','''    public ValueTask<Result<TypeIBaselinePreview>> ReadAsync(ExaminationEngagementView engagement,
        Uuid requesterUserId, CancellationToken ct = default) => ReadCoreAsync(engagement, requesterUserId, null, ct);

    /// <summary>Publishes end-of-period effective sources while recording exact late source facts through the close decision.</summary>
    public ValueTask<Result<TypeIBaselinePreview>> ReadClosingAsync(ExaminationEngagementView engagement,
        Uuid requesterUserId, DateTimeOffset recordedThrough, CancellationToken ct = default) =>
        ReadCoreAsync(engagement, requesterUserId, recordedThrough, ct);

    async ValueTask<Result<TypeIBaselinePreview>> ReadCoreAsync(ExaminationEngagementView engagement,
        Uuid requesterUserId, DateTimeOffset? recordedThrough, CancellationToken ct)
    {''');s=s.replace('sources.ReadAsync(engagement, requesterUserId, ct)', 'sources.ReadAsync(engagement, requesterUserId, recordedThrough, ct)');s=s.replace('''                engagement.ProgramId, engagement.ExaminationEngagementId, entries), ct)''','''                engagement.ProgramId, engagement.ExaminationEngagementId, entries) { RecordedThrough = recordedThrough }, ct)''');p.write_text(s)
p=copy('src/Compliance.Common/Features/Snapshots/SnapshotSourcePublicationManifest.cs');s=p.read_text();s='using System.Text.Json.Serialization;\n'+s;s=s.replace('''    public const string Schema = "snapshot-source-publication-manifest.v1";''','''    public const string Schema = "snapshot-source-publication-manifest.v1";

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public DateTimeOffset? RecordedThrough { get; init; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Uuid? ClosePeriodId { get; init; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Uuid? CloseOperationId { get; init; }''');p.write_text(s)
for name in ['TypeIIPeriodCloseValidationContent','TypeIIPeriodCloseValidationView']:
 p=root/'work/src/Compliance.Common/Features/Operations'/(name+'.cs');s=p.read_text().replace('''    /// <summary>Complete source-family''','''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public DateTimeOffset? RecordedThrough { get; init; }

    /// <summary>Complete source-family''');p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Operations/TypeIIPeriod.cs';s=p.read_text().replace('SourceContentManifest = normalized.SourceContentManifest, SourceBlockers = normalized.SourceBlockers','SourceContentManifest = normalized.SourceContentManifest, SourceBlockers = normalized.SourceBlockers, RecordedThrough = normalized.RecordedThrough');s=s.replace('''        left.UnresolvedMaterialItemIds.SequenceEqual(right.UnresolvedMaterialItemIds) &&''','''        left.UnresolvedMaterialItemIds.SequenceEqual(right.UnresolvedMaterialItemIds) &&
        left.SourceContentManifest == right.SourceContentManifest && left.SourceBlockers.SequenceEqual(right.SourceBlockers) &&
        left.RecordedThrough == right.RecordedThrough &&''');s=s.replace('existing.SourceContentManifest == content.SourceContentManifest &&','existing.RecordedThrough == content.RecordedThrough && existing.SourceContentManifest == content.SourceContentManifest &&');p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Operations/ITypeIIPeriodCloseReconciliation.cs';s=p.read_text().replace('using System.Security.Claims;','using System.Security.Claims;\nusing Bdgrz.Compliance.Features.NativeOperations;').replace('Uuid requesterUserId, DateTimeOffset decisionAt','Uuid requesterUserId, OperationProvenance operation');p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Operations/TypeIIPeriodCloseValidationChange.cs';s=p.read_text().replace('namespace ', 'using Bdgrz.Compliance.Features.NativeOperations;\n\nnamespace ',1).replace('TypeIIPeriodCloseValidationChange(TypeIIPeriodCloseValidationContent Content)', 'TypeIIPeriodCloseValidationChange(DurableIntentHeader Header, TypeIIPeriodCloseValidationContent Content)');p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Operations/RecordTypeIIPeriodCloseValidationHandler.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.Proofs;','using Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Features.Versioning;');s=s.replace('sources.ReadAsync(period, context.Actor, user, operation.AcceptedAt, token)','sources.ReadAsync(period, context.Actor, user, operation, token)');s=s.replace('''                    reconciliation = read.Value;
                    if (period.Prepare''','''                    reconciliation = read.Value;
                    if (reconciliation.RecordedThrough != operation.AcceptedAt || reconciliation.SourceContentManifest is null)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict, "The exact close receipt cutoff and published source proof are required."));
                    if (period.Prepare''');s=s.replace('new TypeIIPeriodCloseValidationChange(reconciliation)','''new TypeIIPeriodCloseValidationChange(new DurableIntentHeader(operation.RootOperationId, owner.Stream,
                            owner.Stream, owner.Stream, operation.Actor, operation.Episode, operation.OriginalExpectedRevision,
                            operation.AuthoredIntentSha256, operation.AcceptedAt), reconciliation)''');p.write_text(s)
