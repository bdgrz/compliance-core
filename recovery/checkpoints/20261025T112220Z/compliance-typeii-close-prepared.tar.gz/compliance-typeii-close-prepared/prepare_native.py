from prep_common import *
common='src/Compliance.Common/Features/Operations/'
core='src/Compliance.Core/Features/Operations/'
put(common+'RecordTypeIIPeriodCloseValidation.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Programs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Records the server-reconciled exact source population at the completed observation interval.</summary>
[Discriminator("bdgrz.operations.record-type-ii-period-close-validation", 1)]
public sealed record RecordTypeIIPeriodCloseValidation(Uuid CommandId, Uuid TenantId, Uuid ProgramId,
    Uuid PeriodId, long ExpectedRevision) : IRequest, IIdentifiedRequest, IProgramScopedRequest,
    IClientManagementMutationRequest, ICallable
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}
''')
for name in ['TypeIIPeriodCloseValidationContent','TypeIIPeriodCloseValidationView']:
 p=copy(common+name+'.cs');s=p.read_text();pos=s.rfind('}')
 s=s[:pos]+'''    /// <summary>Complete source-family capture failures that prohibit a ready close.</summary>
    public IReadOnlyList<string> SourceBlockers { get; init; } = [];
'''+s[pos:];p.write_text(s)
put(core+'TypeIIPeriodCloseValidationChange.cs','''namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Complete immutable server reconciliation, separate from the native acceptance envelope.</summary>
public sealed record TypeIIPeriodCloseValidationChange(TypeIIPeriodCloseValidationContent Content)
{
    public const string Schema = "type-ii-period-close-validation-change.v1";
}
''')
put('src/Compliance.Common/Features/AuditPopulations/ObservationPeriodCloseProposed.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPopulations;

/// <summary>Accepts the exact server-derived close reconciliation and its immutable original result.</summary>
[Discriminator("bdgrz.auditpopulations.observation-period-close-proposed", 3)]
public sealed record ObservationPeriodCloseProposed(Uuid TenantId, Uuid SubjectId, long Revision,
    Uuid? ActorMemberId, TypeIIPeriodView State, DateTimeOffset OccurredAt, ImmutableContentRef Change,
    OperationProvenance Operation, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult)
    : DomainEvent, INativeOperationFact;
''')
p=copy(core+'TypeIIPeriod.cs');s=p.read_text()
a=s.index('    public CommandFailure? RecordCloseValidation(');b=s.index('    public CommandFailure? ApproveClose(',a)
s=s[:a]+'''    /// <summary>Checks the full close reconciliation without raising an event.</summary>
    public CommandFailure? PrepareCloseValidation(long expectedRevision, TypeIIPeriodCloseValidationContent content,
        Uuid validatorMemberId, string validatorDisplay, DateTimeOffset validatedAt, out TypeIIPeriodView? state)
    {
        state = null;
        if (_current is not { } current)
            return CommandFailure.MissingRecord("The Type II period was not found.");
        if (expectedRevision != Revision)
            return StaleRevision();
        if (_pending is not null)
            return CommandFailure.StateConflict("An opening or amendment is still being applied; validate the close after it ends.");
        if (current.Status is not ("active" or "close_blocked" or "close_ready"))
            return CommandFailure.StateConflict("Close validation is only allowed before executive approval.");
        if (DateOnly.FromDateTime(validatedAt.UtcDateTime) <= current.PeriodEnd)
            return CommandFailure.StateConflict("The complete observation interval must end before its close can be reconciled.");
        if (!ValidActor(validatorMemberId, validatorDisplay, validatedAt) || validatedAt < current.UpdatedAt ||
            NormalizeValidation(content, current.ExpectedOccurrences) is not { } normalized)
            return Invalid("Close validation must reconcile this period's exact expected population and source versions.");
        var ready = normalized.ExpectedOccurrenceIds.SequenceEqual(normalized.ActualOccurrenceIds) &&
            normalized.DuplicateOccurrenceIds.Count == 0 && normalized.MissingWorkIds.Count == 0 && normalized.SourceBlockers.Count == 0;
        var validation = new TypeIIPeriodCloseValidationView(ready ? "ready" : "blocked",
            normalized.SourceReferences, normalized.ExpectedOccurrenceIds, normalized.ActualOccurrenceIds,
            normalized.DuplicateOccurrenceIds, normalized.MissingWorkIds, normalized.UnresolvedMaterialItemIds,
            validatorMemberId, validatorDisplay.Trim(), validatedAt)
        { SourceContentManifest = normalized.SourceContentManifest, SourceBlockers = normalized.SourceBlockers };
        state = current with
        {
            Status = ready ? "close_ready" : "close_blocked",
            Revision = Revision + 1,
            CloseValidation = validation,
            CloseApprovals = [],
            ActorMemberId = validatorMemberId,
            ActorDisplay = validatorDisplay.Trim(),
            UpdatedAt = validatedAt,
        };
        return ValidateState(state) is not null || !ValidTransition(current, state, validatorMemberId, "validation")
            ? Invalid("The Type II close reconciliation transition is invalid.") : null;
    }

    /// <summary>Accepts one immutable close validation at the exact expected period revision.</summary>
    public CommandFailure? RecordCloseValidation(OperationProvenance operation, TypeIIPeriodCloseValidationContent content,
        ImmutableContentRef change, ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        if (operation.Owner != Stream || operation.AffectedOwner != Stream || operation.ExpectedRevisionOwner != Stream ||
            operation.LogicalId == Uuid.Empty || operation.RootOperationId != operation.LogicalId ||
            operation.CommandKind != nameof(RecordTypeIIPeriodCloseValidation) || operation.Actor.Kind != "member" ||
            !Uuid.TryParse(operation.Actor.Id, System.Globalization.CultureInfo.InvariantCulture, out var actor) || actor == Uuid.Empty ||
            operation.OriginalExpectedRevision is not { } expected || expected > long.MaxValue ||
            change.Schema != TypeIIPeriodCloseValidationChange.Schema || operationResult.Schema != "mutation-result-content.v1")
            return CommandFailure.StateConflict("The close reconciliation differs from its exact native operation authority.");
        var failure = PrepareCloseValidation((long)expected, content, actor, operation.Actor.Display, operation.AcceptedAt, out var state);
        if (failure is not null)
            return failure;
        var fact = new ObservationPeriodCloseProposed(_tenantId, Id, state!.Revision, actor, Freeze(state), operation.AcceptedAt,
            change, operation, firstResponse, operationResult);
        if (DomainEventPayload.Size(fact) > MaximumEventBytes)
            return Invalid("The complete Type II period state exceeds the bounded event payload.");
        RaiseEvent(fact);
        return null;
    }

'''+s[b:]
a=s.index('    void Apply(ObservationPeriodCloseProposed ev)');b=s.index('    void Apply(TypeIIPeriodCloseApproved ev)',a)
s=s[:a]+'''    void Apply(ObservationPeriodCloseProposed ev)
    {
        if (ev.Operation.Owner != Stream || ev.Operation.AffectedOwner != Stream || ev.Operation.ExpectedRevisionOwner != Stream ||
            ev.Operation.CommandKind != nameof(RecordTypeIIPeriodCloseValidation) || ev.Operation.LogicalId != ev.Operation.RootOperationId ||
            ev.Operation.OriginalExpectedRevision != (ulong)Revision || ev.Operation.AcceptedAt != ev.OccurredAt ||
            ev.Operation.Actor.Id != ev.ActorMemberId?.ToString() || ev.Change.Schema != TypeIIPeriodCloseValidationChange.Schema ||
            ev.FirstResponse is null || ev.OperationResult is null || ev.OperationResult.Schema != "mutation-result-content.v1")
            throw new InvalidOperationException("The native Type II close reconciliation acceptance is invalid.");
        Acceptance.Observe(ev);
        ApplyState(ev.TenantId, ev.SubjectId, ev.Revision, ev.ActorMemberId, ev.State, ev.OccurredAt, false, "validation");
        _facts.Add(ev);
    }
'''+s[b:]
s=s.replace('NormalizeIds(content.UnresolvedMaterialItemIds) is not { } unresolved ||','NormalizeIds(content.UnresolvedMaterialItemIds) is not { } unresolved ||\n            NormalizeSourceBlockers(content.SourceBlockers) is not { } blockers ||')
s=s.replace('            UnresolvedMaterialItemIds = unresolved,','            UnresolvedMaterialItemIds = unresolved,\n            SourceBlockers = blockers,')
s=s.replace('''    static bool ValidValidation(TypeIIPeriodCloseValidationView? validation,''','''    static IReadOnlyList<string>? NormalizeSourceBlockers(IReadOnlyList<string>? values) => values is null || values.Count > 1000 ||
        values.Any(value => string.IsNullOrWhiteSpace(value) || value.Length > 2000) ? null :
        Array.AsReadOnly(values.Select(value => value.Trim()).Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray());

    static bool ValidValidation(TypeIIPeriodCloseValidationView? validation,''')
s=s.replace('''        ValidActor(validation.ValidatorMemberId, validation.ValidatorDisplay, validation.ValidatedAt) &&
        validation.Status == (expectedIds.SequenceEqual(actual) && duplicates.Length == 0 && missing.Length == 0''','''        ValidActor(validation.ValidatorMemberId, validation.ValidatorDisplay, validation.ValidatedAt) &&
        NormalizeSourceBlockers(validation.SourceBlockers) is { } blockers && blockers.SequenceEqual(validation.SourceBlockers) &&
        validation.Status == (expectedIds.SequenceEqual(actual) && duplicates.Length == 0 && missing.Length == 0 && blockers.Count == 0''')
s=s.replace('''            UnresolvedMaterialItemIds = Freeze(validation.UnresolvedMaterialItemIds.ToArray()),''','''            UnresolvedMaterialItemIds = Freeze(validation.UnresolvedMaterialItemIds.ToArray()),
            SourceBlockers = Freeze(validation.SourceBlockers.ToArray()),''')
# Equality of retained validation includes the new complete blocker disposition.
s=s.replace('''existing.SourceContentManifest == content.SourceContentManifest &&''','''existing.SourceContentManifest == content.SourceContentManifest && existing.SourceBlockers.SequenceEqual(content.SourceBlockers) &&''')
s=s.replace('''left.SourceContentManifest == right.SourceContentManifest &&''','''left.SourceContentManifest == right.SourceContentManifest && left.SourceBlockers.SequenceEqual(right.SourceBlockers) &&''')
p.write_text(s)
put(core+'ITypeIIPeriodCloseReconciliation.cs','''using System.Security.Claims;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Server-derived complete source population and physically verified bytes for a period close.</summary>
public interface ITypeIIPeriodCloseReconciliation
{
    ValueTask<Result<TypeIIPeriodCloseValidationContent>> ReadAsync(TypeIIPeriod period, ClaimsPrincipal actor,
        Uuid requesterUserId, DateTimeOffset decisionAt, CancellationToken ct);
}
''')
put(core+'RecordTypeIIPeriodCloseValidationHandler.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Native identified close reconciliation; exact retry replays before time, revision or live source checks.</summary>
public sealed class RecordTypeIIPeriodCloseValidationHandler(NativeOperationExecutor operations,
    ITypeIIPeriodCloseReconciliation sources, IImmutableContentStore content, TimeProvider clock)
    : IRequestHandler<RecordTypeIIPeriodCloseValidation>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<RecordTypeIIPeriodCloseValidation> context, CancellationToken ct)
    {
        var request = context.Request;
        if (!ExaminationCommandActor.TryGet(context.Actor, context.Invocation, request.TenantId, out var member, out var display) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var user))
            return Result.Failure(new RequestError(RequestErrorKind.Forbidden, "Recording a period close requires a personal HTTP actor."));
        if (request.CommandId == Uuid.Empty || request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty ||
            request.PeriodId == Uuid.Empty || request.ExpectedRevision <= 0)
            return Result.Failure(new RequestError(RequestErrorKind.Validation, "A close reconciliation requires exact identities and a positive expected revision."));
        var owner = new TypeIIPeriod(request.TenantId, request.ProgramId, request.PeriodId, request.CommandId);
        var operation = RootOperation.Provenance(request.CommandId, nameof(RecordTypeIIPeriodCloseValidation), owner.Stream,
            ActorReference.ForMember(member, display), request.ExpectedRevision, AuthoredIntentDigest.Compute(request), clock.GetUtcNow());
        TypeIIPeriodCloseValidationContent? reconciliation = null;
        ImmutableContentRef? change = null;
        ImmutableContentRef? result = null;
        var outcome = await operations.ExecuteAsync(new NativeOperation<TypeIIPeriod>(AcceptedOperationBinding.Of(operation),
            () => new TypeIIPeriod(request.TenantId, request.ProgramId, request.PeriodId, request.CommandId), period => period.Acceptance,
            async (period, token) =>
            {
                if (period.Current is not { } current)
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The observation period was not found."));
                if (period.Revision != request.ExpectedRevision || period.PendingOperationId is not null ||
                    current.Status is not ("active" or "close_blocked" or "close_ready"))
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict, "The close reconciliation requires the current eligible period revision."));
                if (DateOnly.FromDateTime(operation.AcceptedAt.UtcDateTime) <= current.PeriodEnd)
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict, "The complete observation interval must end before close reconciliation."));
                try
                {
                    var read = await sources.ReadAsync(period, context.Actor, user, operation.AcceptedAt, token).ConfigureAwait(false);
                    if (!read.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(read.Error!);
                    reconciliation = read.Value;
                    if (period.PrepareCloseValidation(request.ExpectedRevision, reconciliation, member, display, operation.AcceptedAt, out _) is { } failure)
                        return Result<FirstResponseDescriptor>.Failure(failure.ToRequestError());
                    change = await content.WriteJsonAsync(owner.Stream.Realm, Uuid.CreateVersion4(), TypeIIPeriodCloseValidationChange.Schema,
                        new TypeIIPeriodCloseValidationChange(reconciliation), token).ConfigureAwait(false);
                    var frozen = await NativeContent.FreezeUnitAsync(content, request.TenantId, token).ConfigureAwait(false);
                    result = frozen.Result;
                    return Result<FirstResponseDescriptor>.Success(frozen.Response);
                }
                catch (ImmutableContentUnavailableException)
                {
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict, "Exact close source bytes are not available yet.", true));
                }
                catch (ImmutableContentIntegrityException)
                {
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict, "Exact close source content cannot be verified."));
                }
            }, (period, response) => period.RecordCloseValidation(operation, reconciliation!, change!, response, result!) is { } invalid
                ? Result.Failure(invalid.ToRequestError()) : Result.Success), context, ct).ConfigureAwait(false);
        return NativeContent.UnitOutcome(outcome);
    }
}
''')
