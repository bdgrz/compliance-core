from pathlib import Path
root=Path('/tmp/compliance-typeii-close-prepared')
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
publisher=Path('/tmp/compliance-s29-publisher-prepared/work')
def put(rel,s):
 p=root/'work'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 q=publisher/rel if (publisher/rel).exists() else repo/rel;b=root/'base'/rel
 if q.exists() and not b.exists():b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(q.read_bytes())
 p.write_text(s)
def copy(rel):
 p=root/'work'/rel
 if not p.exists():
  q=publisher/rel if (publisher/rel).exists() else repo/rel
  put(rel,q.read_text())
 return p
