from prep_common import *
import difflib,hashlib,json,re,subprocess
files=[]
for p in (root/'work').rglob('*'):
 if not p.is_file():continue
 f=p.relative_to(root/'work').as_posix();b=root/'base'/f
 if not b.exists() or b.read_bytes()!=p.read_bytes():files.append(f)
files.sort()
for name,pred in [('implementation.patch',lambda f:f.startswith('src/')),('tests.patch',lambda f:f.startswith('test/'))]:
 out=[]
 for f in files:
  if not pred(f):continue
  b=root/'base'/f;w=root/'work'/f
  out.extend(difflib.unified_diff(b.read_text().splitlines(True) if b.exists() else [],w.read_text().splitlines(True),fromfile='a/'+f if b.exists() else '/dev/null',tofile='b/'+f))
 (root/name).write_text(''.join(out))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'stage':'1 native close reconciliation and source publication; period State compaction remains stage2','qualified':False,'validation':{'syntax':'all prepared C# files tree-sitter parsed without errors','existingAcceptanceNames':'no original Should* method removed','runtime':'NOT RUN; parent owns build/test/Jev'},'dependencies':['merged S29 publisher #1099 API and sidecar refs','Current TypeIIPeriod original expectedrevision/clock replay fix preserved'],'files':[{'path':f,'baseSha256':sha(root/'base'/f) if(root/'base'/f).exists() else None,'sha256':sha(root/'work'/f),'baseMatchesCurrentMain':not(root/'base'/f).exists() or not(repo/f).exists() or sha(root/'base'/f)==sha(repo/f)}for f in files]}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shared={'jsonRoots':['Bdgrz.Compliance.Features.Operations.RecordTypeIIPeriodCloseValidation','Bdgrz.Compliance.Features.Operations.TypeIIPeriodCloseValidationChange','Bdgrz.Compliance.Features.Operations.TypeIIPeriodCloseSourceEnvelope'],'autoReachableJsonTypes':['TypeIIPeriodCloseNativeSource','TypeIIPeriodCloseOccurrenceMatch','SnapshotSourcePublicationManifest added optional RecordedThrough/ClosePeriodId/CloseOperationId/SourceCoverage; defaultnull TypeI encoding preserved'],'services':['services.AddScoped<PublishedTypeIBaselinePreviewReader>(); (keep existing ITypeIBaselinePreviewReader registration)','services.AddScoped<TypeIIPeriodCloseHistory>();','services.AddScoped<TypeIIPeriodCloseSourcePublication>();','services.AddScoped<ITypeIIPeriodCloseReconciliation, TypeIIPeriodCloseReconciliation>();','.AddRequestHandler<RecordTypeIIPeriodCloseValidationHandler>()'],'http':{'method':'MapPortiaPut<RecordTypeIIPeriodCloseValidation>','path':'/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/close-validations/{command_id}','authorization':'ComplianceAuthorizationPolicies.ApiUser; existing IProgramScopedRequest + IClientManagementMutationRequest authorizers; explicit personal HTTP handler gate','mcp':False},'resultSchemaRegistry':'UnitResult.Schema already registered; all results use MutationResultContent envelope','event':'ObservationPeriodCloseProposed advances existing2→3 for native provenance/Change/FirstResponse/OperationResult; omitted retained close fact not presumed removed by finalcatalog','focusedFilter':'FullyQualifiedName~TypeIIPeriodTests|FullyQualifiedName~TypeIIPeriodCommandHandlerTests|FullyQualifiedName~SnapshotSourcePublicationTests','behavioralRedFilter':'FullyQualifiedName~TypeIIPeriodTests.ShouldRejectPrematureCloseValidationGivenObservationPeriodStillOpen'}
(root/'shared-wiring-deltas.json').write_text(json.dumps(shared,indent=2)+'\n')
print('changed',len(files),'source',sum(f.startswith('src/')for f in files),'tests',sum(f.startswith('test/')for f in files))
print('base drift', [e['path']for e in manifest['files']if not e['baseMatchesCurrentMain']])
