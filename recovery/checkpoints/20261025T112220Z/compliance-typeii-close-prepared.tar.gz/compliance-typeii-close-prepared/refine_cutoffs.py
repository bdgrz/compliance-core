from prep_common import *
core='src/Compliance.Core/Features/Examinations/'
for name in ['AccessExpectationsTypeIBaselineSourceContributor','AccessReviewCampaignsTypeIBaselineSourceContributor','ApplicationTypeIBaselineSourceContributor','ReviewedSystemTypeIBaselineSourceContributor','ProviderTypeIBaselineSourceContributor','PolicyCommunicationTypeIBaselineSourceContributor']:
 p=root/'work'/core/(name+'.cs');s=p.read_text();s=s.replace('''        var through = context.RecordedThrough ?? new DateTimeOffset(engagement.PeriodStart.ToDateTime(TimeOnly.MaxValue,
            DateTimeKind.Utc));''','''        var effectiveThrough = new DateTimeOffset(engagement.PeriodStart.ToDateTime(TimeOnly.MaxValue, DateTimeKind.Utc));
        var through = context.RecordedThrough ?? effectiveThrough;''')
 if name=='AccessExpectationsTypeIBaselineSourceContributor':s=s.replace('HasEffectiveExpectation(history.Value.Expectations, through)', 'HasEffectiveExpectation(history.Value.Expectations, effectiveThrough)')
 if name=='AccessReviewCampaignsTypeIBaselineSourceContributor':s=s.replace('summary.LaunchedAt > through','summary.LaunchedAt > effectiveThrough')
 if name=='ApplicationTypeIBaselineSourceContributor':s=s.replace('revision.Retirement!.EffectiveAt <= through', 'revision.Retirement!.EffectiveAt <= effectiveThrough').replace('retirement.Retirement!.EffectiveAt > through','retirement.Retirement!.EffectiveAt > effectiveThrough')
 if name=='ReviewedSystemTypeIBaselineSourceContributor':s=s.replace('retirement.EffectiveAt > through','retirement.EffectiveAt > effectiveThrough')
 if name=='ProviderTypeIBaselineSourceContributor':s=s.replace('IsInScope(provider.Content, engagement.ProgramId, through)', 'IsInScope(provider.Content, engagement.ProgramId, effectiveThrough)')
 if name=='PolicyCommunicationTypeIBaselineSourceContributor':s=s.replace('item.LaunchedAt > through', 'item.LaunchedAt > effectiveThrough').replace('launch.LaunchedAt > through','launch.LaunchedAt > effectiveThrough')
 p.write_text(s)
# A point selection has no independently backdated receipt cutoff; refuse a concurrent source accepted after the chosen close instant.
for name,needle,condition in [('BoundaryTypeIBaselineSourceContributor','''            else
            {
                try''','version.ChangedAt'),('ControlTypeIBaselineSourceContributor','''                if (!IsValidEffectiveVersion(version, engagement, control, item.Identifier))''','version.ApprovedAt')]:
 p=copy(core+name+'.cs');s=p.read_text();s=s.replace('''    public async ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(
        ExaminationEngagementView engagement, CancellationToken ct)
    {''','''    public ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(ExaminationEngagementView engagement, CancellationToken ct) =>
        ReadAsync(engagement, new TypeIBaselineSourceReadContext(Uuid.Empty, []), ct);

    public async ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(ExaminationEngagementView engagement,
        TypeIBaselineSourceReadContext context, CancellationToken ct)
    {''')
 if name.startswith('Boundary'):
  s=s.replace(needle,'''            else
            {
                if (context.RecordedThrough is { } cutoff && version.ChangedAt > cutoff)
                    return Result<TypeIBaselineSourceContribution>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The effective boundary changed after the frozen close receipt cutoff.", true));
                try''')
 else:
  s=s.replace(needle,'''                if (context.RecordedThrough is { } cutoff && version.ApprovedAt > cutoff)
                    return Result<TypeIBaselineSourceContribution>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "An effective control changed after the frozen close receipt cutoff.", true));
'''+needle)
 p.write_text(s)
