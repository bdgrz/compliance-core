from prep_common import *
common='src/Compliance.Common/Features/Operations/'
for name in ['TypeIIPeriodCloseValidationContent','TypeIIPeriodCloseValidationView']:
 p=root/'work'/common/(name+'.cs');s=p.read_text();idx=s.rfind('}');s=s[:idx]+'''    /// <summary>Retained source scope differences that do not themselves assert a blocking condition.</summary>
    public IReadOnlyList<string> SourceDifferences { get; init; } = [];
'''+s[idx:];p.write_text(s)
p=root/'work/src/Compliance.Common/Features/Snapshots/SnapshotSourcePublicationManifest.cs';s=p.read_text().replace('using System.Text.Json.Serialization;','using System.Text.Json.Serialization;\nusing Bdgrz.Compliance.Features.Examinations;');idx=s.rfind('}');s=s[:idx]+'''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public IReadOnlyList<TypeIBaselineSourceCoverage>? SourceCoverage { get; init; }
'''+s[idx:];p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Operations/TypeIIPeriod.cs';s=p.read_text();s=s.replace('RecordedThrough = normalized.RecordedThrough }','RecordedThrough = normalized.RecordedThrough, SourceDifferences = normalized.SourceDifferences }');s=s.replace('''NormalizeSourceBlockers(content.SourceBlockers) is not { } blockers ||''','''NormalizeSourceBlockers(content.SourceBlockers) is not { } blockers ||
            NormalizeSourceBlockers(content.SourceDifferences) is not { } differences ||''');s=s.replace('''            SourceBlockers = blockers,''','''            SourceBlockers = blockers,
            SourceDifferences = differences,''');s=s.replace('''NormalizeSourceBlockers(validation.SourceBlockers) is { } blockers && blockers.SequenceEqual(validation.SourceBlockers) &&''','''NormalizeSourceBlockers(validation.SourceBlockers) is { } blockers && blockers.SequenceEqual(validation.SourceBlockers) &&
        NormalizeSourceBlockers(validation.SourceDifferences) is { } differences && differences.SequenceEqual(validation.SourceDifferences) &&''');s=s.replace('''left.SourceContentManifest == right.SourceContentManifest && left.SourceBlockers.SequenceEqual(right.SourceBlockers) &&''','''left.SourceContentManifest == right.SourceContentManifest && left.SourceBlockers.SequenceEqual(right.SourceBlockers) &&
        left.SourceDifferences.SequenceEqual(right.SourceDifferences) &&''');s=s.replace('''existing.SourceBlockers.SequenceEqual(content.SourceBlockers) &&''','''existing.SourceBlockers.SequenceEqual(content.SourceBlockers) && existing.SourceDifferences.SequenceEqual(content.SourceDifferences) &&''');s=s.replace('''            SourceBlockers = Freeze(validation.SourceBlockers.ToArray()),''','''            SourceBlockers = Freeze(validation.SourceBlockers.ToArray()),
            SourceDifferences = Freeze(validation.SourceDifferences.ToArray()),''');p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Operations/TypeIIPeriodCloseSourcePublication.cs';s=p.read_text().replace('''        IReadOnlyList<SnapshotSourcePublicationEntry> sources, CancellationToken ct)''','''        IReadOnlyList<SnapshotSourcePublicationEntry> sources, CancellationToken ct,
        IReadOnlyList<TypeIBaselineSourceCoverage>? coverage = null)''').replace('''            RecordedThrough = operation.AcceptedAt,
        }, ct);''','''            RecordedThrough = operation.AcceptedAt,
            SourceCoverage = coverage,
        }, ct);''');p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Operations/TypeIIPeriodCloseReconciliation.cs';s=p.read_text().replace('''var blockers = read.Value.Blockers.Concat(read.Value.ScopeDifferences).ToList();''','''var blockers = read.Value.Blockers.ToList();
            if (!TypeIBaselineSourceFamilies.Required.All(family => read.Value.SourceCoverage.Count(row => row.Family == family) == 1))
                blockers.Add("The close source proof does not cover every required family exactly once.");''');s=s.replace('publication.SealAsync(current, operation, publicationEntries, ct)', 'publication.SealAsync(current, operation, publicationEntries, ct, read.Value.SourceCoverage)');s=s.replace('''                SourceBlockers = blockers.Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray(),''','''                SourceBlockers = blockers.Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray(),
                SourceDifferences = read.Value.ScopeDifferences.Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal).ToArray(),''');p.write_text(s)
