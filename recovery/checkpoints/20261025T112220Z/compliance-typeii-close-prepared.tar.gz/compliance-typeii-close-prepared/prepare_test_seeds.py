from prep_common import *
p=copy('test/Compliance.Tests/Testing/TypeIIPeriodTestExtensions.cs');s=p.read_text();at=s.index('    static OperationProvenance Provenance(')
s=s[:at]+'''    /// <summary>Seeds the native close fact for pure owner-rule tests; the production handler derives/publishes its sources.</summary>
    public static CommandFailure? RecordCloseValidation(this TypeIIPeriod period, long expectedRevision,
        TypeIIPeriodCloseValidationContent content, Uuid validatorMemberId, string validatorDisplay, DateTimeOffset at)
    {
        var operation = RootOperation.Provenance(Uuid.CreateVersion4(), nameof(RecordTypeIIPeriodCloseValidation), period.Stream,
            ActorReference.ForMember(validatorMemberId, validatorDisplay), expectedRevision, new string('e', 64), at);
        return period.RecordCloseValidation(operation, content, Synthetic with { Schema = TypeIIPeriodCloseValidationChange.Schema },
            Synthetic with { Schema = FirstResponses.Schema }, Synthetic with { Schema = "mutation-result-content.v1" });
    }

'''+s[at:];p.write_text(s)
for q in (repo/'test').rglob('*.cs'):
 text=q.read_text()
 if '.RecordCloseValidation(' not in text:continue
 rel=q.relative_to(repo).as_posix();p=copy(rel);s=p.read_text()
 if 'using Bdgrz.Compliance.Tests.Testing;'not in s and 'namespace Bdgrz.Compliance.Tests.Testing;'not in s:
  p.write_text('using Bdgrz.Compliance.Tests.Testing;\n'+s)
# Preserve exact RED acceptance name on the migrated test surface.
p=root/'work/test/Compliance.Tests/Features/Operations/TypeIIPeriodTests.cs';s=p.read_text();old=(repo/'test/Compliance.Tests/Features/Operations/TypeIIPeriodTests.cs').read_text();red=(root/'behavioral-red.patch').read_text();start=red.index('+    [Fact]');lines=[]
for line in red[start:].splitlines():
 if line.startswith('+') and not line.startswith('+++'):lines.append(line[1:]+'\n')
 else:break
method=''.join(lines)
at=s.index('    [Fact]');s=s[:at]+method+s[at:];p.write_text(s)
