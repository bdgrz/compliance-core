from pathlib import Path
import shutil
root=Path('/tmp/compliance-s29-publisher-prepared')
paths=list(Path('src/Compliance.Core/Features/Examinations').glob('*TypeIBaselineSource*.cs'))
paths += [Path(p) for p in ['src/Compliance.Core/Features/Snapshots/SnapshotContentIdentity.cs','src/Compliance.Core/Features/Snapshots/PopulationSnapshotContent.cs','src/Compliance.Core/Features/Examinations/TypeIBaselineContentIdentity.cs','src/Compliance.Common/Features/Examinations/TypeIBaselineSourceReference.cs','src/Compliance.Common/Features/Examinations/ExaminationContentReference.cs','src/Compliance.Common/Features/AuditPackages/AuditPackageSelectionEntry.cs','src/Compliance.Core/Features/AuditPackages/AuditPackageSourceBuilder.cs','src/Compliance.Core/Features/AuditPackages/AuditPackageArchiveBuilder.cs','src/Compliance.Core/Features/AuditPackages/AuditPackageArchiveVerifier.cs','src/Compliance.Core/Features/AuditPackages/AuditPackageRules.cs','src/Compliance.Core/Features/Operations/StartTypeIIObservationPeriodHandler.cs']]
for p in paths:
 for area in ['base','work']:
  dest=root/area/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
def write(path,text):
 p=root/'work'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n')
write('src/Compliance.Common/Features/Snapshots/SnapshotSourceBlob.cs','''namespace Bdgrz.Compliance.Features.Snapshots;

/// <summary>Exact physical bytes of a logical frozen source; a Merkle identity is not the physical file hash.</summary>
public sealed record SnapshotSourceBlob(string Sha256, long Bytes, string MediaType, string FileExtension,
    string Description);
''')
for rel in ['src/Compliance.Common/Features/Examinations/TypeIBaselineSourceReference.cs','src/Compliance.Common/Features/Examinations/ExaminationContentReference.cs']:
 p=root/'work'/rel;s=p.read_text();s='using System.Text.Json.Serialization;\nusing Bdgrz.Compliance.Features.Snapshots;\n'+s
 s=s.replace('string ContentSha256);','''string ContentSha256,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] SnapshotSourceBlob? Content = null);''');p.write_text(s)
p=root/'work/src/Compliance.Common/Features/AuditPackages/AuditPackageSelectionEntry.cs';s=p.read_text();s='using System.Text.Json.Serialization;\nusing Bdgrz.Compliance.Features.Snapshots;\n'+s
s=s.replace('Uuid SourceVersionId = default);','''Uuid SourceVersionId = default,
    [property: JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)] SnapshotSourceBlob? SourceContent = null);''');p.write_text(s)
write('src/Compliance.Core/Features/Snapshots/SnapshotSourceCapture.cs','''using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Snapshots;

/// <summary>
/// Explicit capture scope for a source-freeze read. Existing digest algorithms remain unchanged; only the exact
/// material they hash is observed. Full population rows use an independent physical envelope because their logical
/// digest is a Merkle identity. Candidate files are private temporary data and are removed on every exit path.
/// </summary>
static class SnapshotSourceCapture
{
    static readonly AsyncLocal<Scope?> Current = new();

    public static Scope Begin(Uuid tenant) => new(tenant);

    public static byte[] HashData(ReadOnlySpan<byte> material)
    {
        var digest = SHA256.HashData(material);
        Current.Value?.Flat(Convert.ToHexStringLower(digest), material);
        return digest;
    }

    public static void Population(string kind, IReadOnlyList<PopulationRow> rows, string logicalSha256)
    {
        if (Current.Value is { } scope)
            scope.Population(kind, rows, logicalSha256);
    }

    internal sealed class Scope : IDisposable
    {
        readonly Scope? _parent;
        readonly string _directory = Directory.CreateTempSubdirectory("bdgrz-source-capture-").FullName;
        readonly Dictionary<string, Material> _materials = new(StringComparer.Ordinal);
        readonly object _gate = new();
        bool _disposed;

        public Scope(Uuid tenant)
        {
            Tenant = tenant;
            _parent = Current.Value;
            Current.Value = this;
        }

        public Uuid Tenant { get; }
        public bool TryGet(string logicalSha256, out Material? material)
        {
            lock (_gate)
                return _materials.TryGetValue(logicalSha256, out material);
        }

        public void Flat(string logicalSha256, ReadOnlySpan<byte> bytes)
        {
            lock (_gate)
            {
                if (_materials.ContainsKey(logicalSha256))
                    return;
                var path = Path.Combine(_directory, logicalSha256 + ".source");
                using (var output = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    output.Write(bytes);
                var separator = bytes.IndexOf((byte)0);
                var domain = separator is > 0 and < 256 ? Encoding.UTF8.GetString(bytes[..separator]) : null;
                var prefixed = domain?.StartsWith("bdgrz.", StringComparison.Ordinal) == true;
                var json = !prefixed && IsJson(bytes);
                var descriptor = new SnapshotSourceBlob(logicalSha256, bytes.Length,
                    prefixed ? "application/vnd.bdgrz.canonical-snapshot-source.v1" :
                        json ? "application/json" : "application/octet-stream",
                    prefixed ? "snapshot" : json ? "json" : "bin",
                    prefixed ? $"Canonical snapshot source proof bytes ({domain}, NUL delimiter, exact payload)." :
                        "Exact canonical source bytes.");
                _materials.Add(logicalSha256, new Material(path, descriptor));
            }
        }

        public void Population(string kind, IReadOnlyList<PopulationRow> rows, string logicalSha256)
        {
            var identity = PopulationContentIdentity.Compute(kind, rows);
            if (!identity.IsSuccess || identity.Value.Sha256 != logicalSha256)
                throw new SnapshotContentException("A population export must retain its verified complete logical identity.");
            lock (_gate)
            {
                if (_materials.ContainsKey(logicalSha256))
                    return;
                var path = Path.Combine(_directory, logicalSha256 + ".source");
                using (var output = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new Utf8JsonWriter(output, SnapshotContentIdentity.CanonicalWriterOptions))
                {
                    writer.WriteStartObject();
                    writer.WriteNumber("format_version", 1);
                    writer.WriteString("kind", kind);
                    writer.WriteString("logical_content_sha256", logicalSha256);
                    writer.WriteNumber("row_count", identity.Value.RowCount);
                    writer.WriteNumber("logical_chunk_count", identity.Value.ChunkCount);
                    writer.WriteStartArray("rows");
                    foreach (var row in rows)
                    {
                        writer.WriteStartObject();
                        writer.WriteString("key", SnapshotContentIdentity.NormalizeText(row.Key));
                        writer.WritePropertyName("content");
                        SnapshotContentIdentity.WriteCanonical(writer, row.Content);
                        writer.WriteEndObject();
                    }
                    writer.WriteEndArray();
                    writer.WriteEndObject();
                }
                using var input = File.OpenRead(path);
                var physical = Convert.ToHexStringLower(SHA256.HashData(input));
                var descriptor = new SnapshotSourceBlob(physical, input.Length,
                    "application/vnd.bdgrz.population-snapshot-source.v1+json", "json",
                    "Complete canonical population rows and their verified logical Merkle identity.");
                _materials.Add(logicalSha256, new Material(path, descriptor));
            }
        }

        public void Dispose()
        {
            lock (_gate)
            {
                if (_disposed)
                    return;
                _disposed = true;
                if (ReferenceEquals(Current.Value, this))
                    Current.Value = _parent;
                Directory.Delete(_directory, recursive: true);
            }
        }

        static bool IsJson(ReadOnlySpan<byte> bytes)
        {
            try
            {
                using var value = JsonDocument.Parse(bytes.ToArray());
                return value.RootElement.ValueKind is JsonValueKind.Array or JsonValueKind.Object;
            }
            catch (JsonException)
            {
                return false;
            }
        }
    }

    internal sealed record Material(string Path, SnapshotSourceBlob Blob);
}
''')
write('src/Compliance.Core/Features/Examinations/PublishedTypeIBaselinePreviewReader.cs','''using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Snapshots;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>Publishes every complete canonical source body before a production baseline can freeze its references.</summary>
public sealed class PublishedTypeIBaselinePreviewReader(TypeIBaselinePreviewReader sources,
    IArtifactContentStore artifacts) : ITypeIBaselinePreviewReader
{
    public ValueTask<Result<TypeIBaselinePreview>> ReadAsync(ExaminationEngagementView engagement,
        CancellationToken ct = default) => ReadAsync(engagement, Uuid.Empty, ct);

    public async ValueTask<Result<TypeIBaselinePreview>> ReadAsync(ExaminationEngagementView engagement,
        Uuid requesterUserId, CancellationToken ct = default)
    {
        using var capture = SnapshotSourceCapture.Begin(engagement.TenantId);
        var read = await sources.ReadAsync(engagement, requesterUserId, ct).ConfigureAwait(false);
        if (!read.IsSuccess)
            return read;
        var published = new List<TypeIBaselineSourceReference>(read.Value.Sources.Count);
        foreach (var source in read.Value.Sources)
        {
            if (!capture.TryGet(source.ContentSha256, out var material) || material is null)
                return Failure("A complete canonical source body was not captured for " + source.Kind + ".", false);
            await using var bytes = new FileStream(material.Path, FileMode.Open, FileAccess.Read, FileShare.Read,
                81920, FileOptions.Asynchronous);
            var stored = await artifacts.StoreIfAbsentAsync(engagement.TenantId, bytes, ct).ConfigureAwait(false);
            if (stored.Content.TenantId != engagement.TenantId || stored.Content.Sha256 != material.Blob.Sha256 ||
                stored.Content.Length != material.Blob.Bytes)
                return Failure("A published source differs from its exact captured bytes.", false);
            await using var verified = await artifacts.OpenVerifiedAsync(stored.Content, ct).ConfigureAwait(false);
            if (verified is null)
                return Failure("A complete canonical source is unavailable in verified tenant storage.", true);
            published.Add(source with { Content = material.Blob });
        }
        return Result<TypeIBaselinePreview>.Success(TypeIBaselinePreview.Create(read.Value.TenantId,
            read.Value.ProgramId, read.Value.ExaminationEngagementId, published, read.Value.Blockers,
            read.Value.ScopeDifferences, read.Value.SourceCoverage));
    }

    static Result<TypeIBaselinePreview> Failure(string message, bool transient) =>
        Result<TypeIBaselinePreview>.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
# Observe the exact existing digest input; do not replace any canonicalization/ordering algorithm.
for p in (root/'work/src/Compliance.Core/Features/Examinations').glob('*TypeIBaselineSource*.cs'):
 s=p.read_text()
 if 'SHA256.HashData(' not in s:continue
 s=s.replace('SHA256.HashData(', 'SnapshotSourceCapture.HashData(')
 if 'using Bdgrz.Compliance.Features.Snapshots;' not in s:s='using Bdgrz.Compliance.Features.Snapshots;\n'+s
 p.write_text(s)
for name in ['src/Compliance.Core/Features/Snapshots/SnapshotContentIdentity.cs','src/Compliance.Core/Features/Examinations/TypeIBaselineContentIdentity.cs']:
 p=root/'work'/name;s=p.read_text().replace('SHA256.HashData(', 'SnapshotSourceCapture.HashData(')
 if 'Features/Examinations/' in name and 'using Bdgrz.Compliance.Features.Snapshots;' not in s:s='using Bdgrz.Compliance.Features.Snapshots;\n'+s
 p.write_text(s)
# Population identity is Merkle: capture all verified rows instead of pretending its root preimage is the content.
p=root/'work/src/Compliance.Core/Features/Snapshots/PopulationSnapshotContent.cs';s=p.read_text()
s=s.replace('''        if (snapshot.StoredChunkCount == 0)
            return snapshot.HasIntactContent
                ? Result<PopulationSnapshotContent>.Success(new(snapshot, snapshot.Rows))
                : Corrupt();''','''        if (snapshot.StoredChunkCount == 0)
        {
            if (!snapshot.HasIntactContent)
                return Corrupt();
            SnapshotSourceCapture.Population(kind, snapshot.Rows, snapshot.ContentSha256);
            return Result<PopulationSnapshotContent>.Success(new(snapshot, snapshot.Rows));
        }''')
s=s.replace('''        return digest.IsSuccess && digest.Value.Sha256 == snapshot.ContentSha256 &&''','''        var intact = digest.IsSuccess && digest.Value.Sha256 == snapshot.ContentSha256 &&''')
s=s.replace('''               snapshot.StorageManifestSha256
            ? Result<PopulationSnapshotContent>.Success(new(snapshot, rows))
            : Corrupt();''','''               snapshot.StorageManifestSha256;
        if (!intact)
            return Corrupt();
        SnapshotSourceCapture.Population(kind, rows, snapshot.ContentSha256);
        return Result<PopulationSnapshotContent>.Success(new(snapshot, rows));''')
p.write_text(s)
print('publisher/capture/source descriptors and unchanged-digest observation hooks prepared offline')
