from pathlib import Path
import difflib
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-s29-publisher-prepared');rel=Path('test/Compliance.Tests/Features/AuditPackages/SnapshotSourcePublicationTests.cs');p=r/'work'/rel
s=p.read_text();s=s.replace('''        var sha = Convert.ToHexStringLower(SHA256.HashData(expected));''','''        var sha = Convert.ToHexStringLower(SHA256.HashData(expected));
        Assert.Equal(preview.Value.Sources.Single(source => source.Kind == "approved_boundary").ContentSha256, sha);''')
p.write_text(s)
parser=Parser(Language(tree_sitter_c_sharp.language()));data=s.encode();tree=parser.parse(data);drops=[]
def walk(n):
 if n.type=='method_declaration':
  name=n.child_by_field_name('name')
  if name and data[name.start_byte:name.end_byte].decode().startswith('Should') and data[name.start_byte:name.end_byte].decode() != 'ShouldPublishExactSourceBytesGivenProductionContributorAndBaselineFreeze':
   drops.append((n.start_byte,n.end_byte))
 for c in n.children:walk(c)
walk(tree.root_node)
red=data
for a,b in sorted(drops,reverse=True):red=red[:a]+red[b:]
red=red.decode();red=red.replace('''        var saved = await fixture.Reader.HydrateAsync(new ExaminationEngagement(fixture.TenantId,
            fixture.ProgramId, fixture.ExaminationId));
        Assert.NotNull(saved.Baseline!.SourceContentManifest);
        Assert.All(saved.Baseline.Sources, source => Assert.Null(source.Content));
''','')
(r/'behavioral-red.patch').write_text(''.join(difflib.unified_diff([],red.splitlines(True),fromfile='/dev/null',tofile='b/'+str(rel))))
(r/'behavioral-red-instructions.md').write_text('''Apply only behavioral-red.patch to current production code. Run FullyQualifiedName~SnapshotSourcePublicationTests.ShouldPublishExactSourceBytesGivenProductionContributorAndBaselineFreeze. It resolves ITypeIBaselinePreviewReader through actual AddCompliance production registration, uses real boundary/workforce contributors and a real stored population, freezes the baseline, then asks the real artifact store for the exact boundary digest preimage. Current source leaves those bytes absent, so Assert.NotNull(bytes) must fail after successful freeze. No new production APIs are used by this standalone RED file.

Reverse behavioral-red.patch before applying tests.patch; the same named regression is retained with full metadata assertions in the complete test file. No dotnet build/test was run by this child.
''')
print('meaningful standalone old-surface publisher RED prepared')
