from pathlib import Path
import shutil
r=Path('/tmp/compliance-s29-publisher-prepared');w=r/'work'
def ensure(rel):
 p=Path(rel)
 if not (r/'base'/p).exists():
  for a in ['base','work']:
   d=r/a/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
 return w/p
p=w/'src/Compliance.Core/Features/Snapshots/SnapshotSourcePublicationReader.cs'
p.write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Snapshots;

/// <summary>Reads one complete publication proof; a physical pointer never replaces its logical source identity.</summary>
static class SnapshotSourcePublicationReader
{
    public static async Task<SnapshotSourcePublicationManifest> ReadAsync(IImmutableContentStore content,
        Uuid tenant, Uuid program, Uuid examination, ImmutableContentRef reference, CancellationToken ct)
    {
        if (reference.Schema != SnapshotSourcePublicationManifest.Schema)
            throw new ImmutableContentIntegrityException("The source publication has another declared schema.");
        var manifest = await content.ReadJsonAsync<SnapshotSourcePublicationManifest>(tenant.ToString(), reference, ct)
            .ConfigureAwait(false);
        if (manifest.TenantId != tenant || manifest.ProgramId != program || manifest.ExaminationId != examination ||
            manifest.Sources is null || manifest.Sources.Select(source => (source.SourceType, source.RecordId,
                source.VersionId, source.Version, source.LogicalSha256)).Distinct().Count() != manifest.Sources.Count ||
            manifest.Sources.Any(source => source.Content is null || source.Content.Bytes <= 0 ||
                !Sha256(source.Content.Sha256) || string.IsNullOrWhiteSpace(source.Content.MediaType) ||
                string.IsNullOrWhiteSpace(source.Content.FileExtension)))
            throw new ImmutableContentIntegrityException("The complete publication differs from its exact source scope or byte proof.");
        return manifest;
    }

    static bool Sha256(string value) => value is { Length: 64 } && value.All(character =>
        character is >= '0' and <= '9' or >= 'a' and <= 'f');
}
''')
p=w/'src/Compliance.Core/Features/AuditPackages/AuditPackageSourceBuilder.cs';s=p.read_text()
start=s.index('''            published = await content.ReadJsonAsync<SnapshotSourcePublicationManifest>''');end=s.index('''        }
        var normalized''',start)
s=s[:start]+'''            published = await SnapshotSourcePublicationReader.ReadAsync(content, tenantId, programId,
                requested.ExaminationId, publication, ct).ConfigureAwait(false);
'''+s[end:];p.write_text(s)
p=ensure('src/Compliance.Core/Features/Examinations/GetTypeIBaselineHandler.cs');s=p.read_text()
s='using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Snapshots;\n'+s
s=s.replace('GetTypeIBaselineHandler(IExaminationEngagementDirectoryReader directory)','GetTypeIBaselineHandler(IExaminationEngagementDirectoryReader directory,\n    IImmutableContentStore? content = null)')
start=s.index('''        return baseline is''');end=s.index('''    }
}''',start)
s=s[:start]+'''        if (baseline is not { } view || view.TenantId != request.TenantId ||
            view.ProgramId != request.ProgramId || view.TypeIBaselineId != request.TypeIBaselineId)
            return Result<TypeIBaselineView>.Failure(new RequestError(RequestErrorKind.NotFound,
                "The Type I baseline was not found."));
        if (view.SourceContentManifest is null)
            return Result<TypeIBaselineView>.Success(view);
        if (content is null)
            return Result<TypeIBaselineView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The frozen source byte proof cannot be verified."));
        try
        {
            var publication = await SnapshotSourcePublicationReader.ReadAsync(content, request.TenantId,
                request.ProgramId, view.ExaminationEngagementId, view.SourceContentManifest, ct).ConfigureAwait(false);
            if (publication.Sources.Count != view.Sources.Count)
                throw new ImmutableContentIntegrityException("The baseline source publication is incomplete.");
            var enriched = new List<TypeIBaselineSourceReference>(view.Sources.Count);
            foreach (var source in view.Sources)
            {
                var physical = publication.Sources.SingleOrDefault(item => item.SourceType == source.Kind &&
                    item.RecordId == source.RecordId && item.VersionId == source.VersionId && item.Version == source.Revision &&
                    item.LogicalSha256 == source.ContentSha256)?.Content;
                if (physical is null)
                    throw new ImmutableContentIntegrityException("The baseline omits an exact physical source proof.");
                enriched.Add(source with { Content = physical });
            }
            return Result<TypeIBaselineView>.Success(view with { Sources = enriched });
        }
        catch (ImmutableContentUnavailableException exception)
        {
            return Result<TypeIBaselineView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The source byte proof is unavailable: " + exception.Message, true));
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<TypeIBaselineView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The source byte proof does not verify: " + exception.Message, false));
        }
'''+s[end:];p.write_text(s)
# Preserve publication proof identity in each close/opening transition and retry guard.
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriod.cs';s=p.read_text()
s=s.replace('''            next.OpeningSnapshotSha256 != prior.OpeningSnapshotSha256 ||''','''            next.OpeningSnapshotSha256 != prior.OpeningSnapshotSha256 ||
            next.OpeningSourceContentManifest != prior.OpeningSourceContentManifest ||''')
s=s.replace('''        state.OpeningSnapshotSha256 == normalized.OpeningSnapshotSha256 &&''','''        state.OpeningSnapshotSha256 == normalized.OpeningSnapshotSha256 &&
        state.OpeningSourceContentManifest == normalized.SourceContentManifest &&''')
s=s.replace('''        SameReferences(existing.SourceReferences, refs) && existing.ExpectedOccurrenceIds''','''        existing.SourceContentManifest == content.SourceContentManifest &&
        SameReferences(existing.SourceReferences, refs) && existing.ExpectedOccurrenceIds''')
s=s.replace('''            !SameReferences(normalized.SourceReferences, validation.SourceReferences) ||''','''            normalized.SourceContentManifest != (validation.SourceContentManifest ?? current.OpeningSourceContentManifest) ||
            !SameReferences(normalized.SourceReferences, validation.SourceReferences) ||''')
p.write_text(s)
p=w/'src/Compliance.Core/Features/Operations/FreezeTypeIIPeriodCloseHandler.cs';s=p.read_text().replace('''        snapshot.Version == 1 &&''','''        snapshot.Version == 1 && snapshot.SourceContentManifest == content.SourceContentManifest &&''');p.write_text(s)
p=w/'src/Compliance.Core/Features/Examinations/ExaminationEngagement.cs';s=p.read_text().replace('oldSource with { Content = null } != newSource with { Content = null }','(oldSource with { Content = null }) != (newSource with { Content = null })');p.write_text(s)
print('frozen publication proof read composition and transition invariants prepared')
