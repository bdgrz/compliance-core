# Faithful canonical source publication follow-on

Existing logical digests stay byte-for-byte unchanged. Flat source bodies publish their exact existing hash input, with accurate custom binary media/extension when a domain/NUL prefix exists. Workforce populations publish a complete canonical row envelope whose independent physical digest is sealed alongside the logical Merkle identity.

A complete immutable sidecar records physical metadata for the frozen scope. Baselines retain one digest-bound sidecar reference; they do not inflate every bounded event with descriptors. Preview identities exclude random candidate content IDs and bind the sidecar bytes. Persisted source refs stay compact; baseline reads enrich them from verified sidecar content. Package selections and manifest identity bind the exact physical descriptor, while source membership continues to use the original logical identity. ZIP byte verification uses physical hashes and lengths.

Meaningful standalone old-surface RED and exact application sequence are documented in behavioral-red-instructions.md. Full tests cover production DI/contributors -> baseline freeze, stable repeated publication, a complete workforce envelope through native package admission and real ZIP verification, and refused physical-pointer substitution. Source syntax and patch reconstruction are checked; no dotnet validation has run yet.

TypeII opening/close preserve publication references. The existing missing RecordCloseValidation production command remains an internal workflow gap; do not claim newly added closing source families are produced until that handler exists. No new GitHub issue was created.

Use work/ and the exported patches. Preparation scripts are historical and must not be rerun.
