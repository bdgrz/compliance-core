from pathlib import Path
r=Path('/tmp/compliance-s29-publisher-prepared');w=r/'work'
p=w/'src/Compliance.Core/Features/AuditPackages/AuditPackageSourceBuilder.cs';s=p.read_text()
s='using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Features.Snapshots;\n'+s
s=s.replace('AuditPackageSourceBuilder(IAggregateReader reader)', 'AuditPackageSourceBuilder(IAggregateReader reader, IImmutableContentStore? content = null)')
s=s.replace('''        Func<AuditPackageSelectionEntry, bool> isFrozenSource;''','''        Func<AuditPackageSelectionEntry, bool> isFrozenSource;
        ImmutableContentRef? publication = null;''')
s=s.replace('''            isFrozenSource = selected => baseline.Sources.Any''','''            publication = baseline.SourceContentManifest;
            isFrozenSource = selected => baseline.Sources.Any''')
s=s.replace('''            isFrozenSource = selected => snapshot.SourceReferences.Any''','''            publication = snapshot.SourceContentManifest ?? closed.OpeningSourceContentManifest;
            isFrozenSource = selected => snapshot.SourceReferences.Any''')
start=s.index('        foreach (var selected in requested.SelectedContent)');end=s.index('    static Result<AuditPackageContent> Invalid(',start)
s=s[:start]+'''        SnapshotSourcePublicationManifest? published = null;
        if (publication is not null)
        {
            if (content is null || publication.Schema != SnapshotSourcePublicationManifest.Schema)
                return Conflict("The frozen source publication cannot be verified.");
            published = await content.ReadJsonAsync<SnapshotSourcePublicationManifest>(tenantId.ToString(), publication, ct)
                .ConfigureAwait(false);
            if (published.TenantId != tenantId || published.ProgramId != programId ||
                published.ExaminationId != requested.ExaminationId || published.Sources is null ||
                published.Sources.Select(source => (source.SourceType, source.RecordId, source.VersionId,
                    source.Version, source.LogicalSha256)).Distinct().Count() != published.Sources.Count)
                return Conflict("The source publication differs from its frozen tenant, program or examination.");
        }
        var normalized = new List<AuditPackageSelectionEntry>(requested.SelectedContent.Count);
        foreach (var selected in requested.SelectedContent)
        {
            if (selected is null || selected.SourceVersionId == Uuid.Empty || !isFrozenSource(selected))
                return Conflict("Every selected package record must match an exact source version in the frozen examination snapshot.");
            var physical = published?.Sources.SingleOrDefault(source => source.SourceType == selected.SourceType &&
                source.RecordId == selected.SourceRecordId && source.VersionId == selected.SourceVersionId &&
                source.Version == selected.SourceVersion && StringComparer.OrdinalIgnoreCase.Equals(
                    source.LogicalSha256, selected.ContentSha256))?.Content;
            if (published is not null && physical is null)
                return Conflict("The frozen logical source has no complete physical publication proof.");
            if (physical is not null)
            {
                if (selected.SourceContent is not null && selected.SourceContent != physical)
                    return Conflict("The selected physical source differs from its immutable publication proof.");
                if (selected.ByteLength != physical.Bytes || !StringComparer.OrdinalIgnoreCase.Equals(
                        selected.Extension, physical.FileExtension))
                    return Invalid("Use the frozen source's exact byte length and declared file extension.");
                normalized.Add(selected with { SourceContent = physical });
            }
            else
            {
                if (selected.SourceContent is not null)
                    return Conflict("A physical source descriptor requires a frozen publication proof.");
                normalized.Add(selected);
            }
        }
        return Result<AuditPackageContent>.Success(requested with { SelectedContent = normalized });
    }

'''+s[end:];p.write_text(s)
# The package manifest explicitly binds physical metadata; absent descriptors retain the original hash algorithm.
p=w/'src/Compliance.Core/Features/AuditPackages/AuditPackageRules.cs';s=p.read_text()
s=s.replace('''                !AuthorshipKinds.Contains(entry.Authorship))''','''                !AuthorshipKinds.Contains(entry.Authorship) || entry.SourceContent is { } blob &&
                (!Sha256(blob.Sha256) || blob.Bytes != entry.ByteLength ||
                 !StringComparer.OrdinalIgnoreCase.Equals(blob.FileExtension, entry.Extension) ||
                 !Bounded(blob.MediaType, 1, 200) || !Bounded(blob.Description, 1, 1024)))''')
s=s.replace('''                .Append(source.Authorship).Append('\\n');''','''                .Append(source.Authorship);
            if (source.SourceContent is { } physical)
                builder.Append("|source_content_v1|").Append(Convert.ToHexStringLower(SHA256.HashData(
                    JsonSerializer.SerializeToUtf8Bytes(physical, ComplianceCoreJsonContext.Default.SnapshotSourceBlob))));
            builder.Append('\\n');''');p.write_text(s)
# Every byte gate uses the physical digest; logical source membership stays independently pinned above.
for file in ['AuditPackageArchiveBuilder.cs','AuditPackageArchiveVerifier.cs']:
 p=w/('src/Compliance.Core/Features/AuditPackages/'+file);s=p.read_text()
 if file=='AuditPackageArchiveBuilder.cs':
  s=s.replace('item.Source.ContentSha256, item.Source.ByteLength','item.Source.SourceContent?.Sha256 ?? item.Source.ContentSha256, item.Source.ByteLength')
  s=s.replace('Convert.ToHexStringLower(digest.GetHashAndReset()) != item.Source.ContentSha256','Convert.ToHexStringLower(digest.GetHashAndReset()) !=\n                        (item.Source.SourceContent?.Sha256 ?? item.Source.ContentSha256)')
  s=s.replace('''entry.Source.ByteLength < 0 || !Sha256(entry.Source.ContentSha256)))''','''entry.Source.ByteLength < 0 || !Sha256(entry.Source.ContentSha256) ||
                entry.Source.SourceContent is { } physical && (physical.Bytes != entry.Source.ByteLength ||
                    !Sha256(physical.Sha256) || !StringComparer.OrdinalIgnoreCase.Equals(physical.FileExtension,
                        entry.Source.Extension))))''')
 else:s=s.replace('''StringComparer.Ordinal.Equals(digest, expected.Source.ContentSha256)''','''StringComparer.Ordinal.Equals(digest,
                        expected.Source.SourceContent?.Sha256 ?? expected.Source.ContentSha256)''')
 p.write_text(s)
# The logical source-change report excludes transient publication metadata shown in preview reads.
p=w/'src/Compliance.Core/Features/Examinations/ExaminationEngagement.cs';s=p.read_text().replace('''!next.TryGetValue(key, out var newSource) || oldSource != newSource)''','''!next.TryGetValue(key, out var newSource) ||
                          oldSource with { Content = null } != newSource with { Content = null })''');p.write_text(s)
print('logical/physical package binding and actual-byte verification prepared')
