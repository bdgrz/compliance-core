from pathlib import Path
import shutil
r=Path('/tmp/compliance-s29-publisher-prepared');w=r/'work'
def ensure(rel):
 p=Path(rel)
 if not (r/'base'/p).exists():
  for area in ['base','work']:
   out=r/area/p;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
 return w/p
def write(rel,s):
 p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s.strip()+'\n')
# Publication metadata is externalized once; the business baseline keeps one digest-bound immutable reference.
for rel in ['src/Compliance.Core/Features/Examinations/TypeIBaselinePreview.cs','src/Compliance.Common/Features/Examinations/TypeIBaselineView.cs']:
 p=ensure(rel);s=p.read_text();s='using System.Text.Json.Serialization;\nusing Bdgrz.Compliance.Features.Proofs;\n'+s
 anchor='    public IReadOnlyList<TypeIBaselineSourceCoverage> SourceCoverage'
 i=s.index(anchor)
 s=s[:i]+'''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public ImmutableContentRef? SourceContentManifest { get; init; }

'''+s[i:];p.write_text(s)
# No inline metadata is needed on closing source refs: closing protocols reuse the single frozen publication manifest.
p=w/'src/Compliance.Common/Features/Examinations/ExaminationContentReference.cs';p.write_text((r/'base/src/Compliance.Common/Features/Examinations/ExaminationContentReference.cs').read_text())
write('src/Compliance.Common/Features/Snapshots/SnapshotSourcePublicationEntry.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Snapshots;

/// <summary>One exact logical source version and the independently verified physical bytes representing it.</summary>
public sealed record SnapshotSourcePublicationEntry(string SourceType, Uuid RecordId, Uuid VersionId,
    long Version, string LogicalSha256, SnapshotSourceBlob Content);
''')
write('src/Compliance.Common/Features/Snapshots/SnapshotSourcePublicationManifest.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Snapshots;

/// <summary>Complete source-body publication proof, stored outside the bounded baseline fact and sealed by its digest.</summary>
public sealed record SnapshotSourcePublicationManifest(Uuid TenantId, Uuid ProgramId, Uuid ExaminationId,
    IReadOnlyList<SnapshotSourcePublicationEntry> Sources)
{
    public const string Schema = "snapshot-source-publication-manifest.v1";
}
''')
p=w/'src/Compliance.Core/Features/Examinations/PublishedTypeIBaselinePreviewReader.cs';s=p.read_text()
s='using Bdgrz.Compliance.Features.Content;\n'+s
s=s.replace('IArtifactContentStore artifacts) : ITypeIBaselinePreviewReader','IArtifactContentStore artifacts, IImmutableContentStore content) : ITypeIBaselinePreviewReader')
s=s.replace('''        using var capture = SnapshotSourceCapture.Begin(engagement.TenantId);''','''        if (engagement is null)
            return Result<TypeIBaselinePreview>.Failure(new RequestError(RequestErrorKind.Validation,
                "A baseline source publication requires an engagement."));
        using var capture = SnapshotSourceCapture.Begin(engagement.TenantId);''')
s=s.replace('''        return Result<TypeIBaselinePreview>.Success(TypeIBaselinePreview.Create(read.Value.TenantId,
            read.Value.ProgramId, read.Value.ExaminationEngagementId, published, read.Value.Blockers,
            read.Value.ScopeDifferences, read.Value.SourceCoverage));''','''        var entries = published.OrderBy(source => source.Kind, StringComparer.Ordinal)
            .ThenBy(source => source.RecordId.ToString(), StringComparer.Ordinal)
            .ThenBy(source => source.VersionId.ToString(), StringComparer.Ordinal)
            .Select(source => new SnapshotSourcePublicationEntry(source.Kind, source.RecordId, source.VersionId,
                source.Revision, source.ContentSha256, source.Content!)).ToArray();
        var manifest = await content.WriteJsonAsync(engagement.TenantId.ToString(), Uuid.CreateVersion4(),
            SnapshotSourcePublicationManifest.Schema, new SnapshotSourcePublicationManifest(engagement.TenantId,
                engagement.ProgramId, engagement.ExaminationEngagementId, entries), ct).ConfigureAwait(false);
        return Result<TypeIBaselinePreview>.Success(TypeIBaselinePreview.Create(read.Value.TenantId,
            read.Value.ProgramId, read.Value.ExaminationEngagementId, published, read.Value.Blockers,
            read.Value.ScopeDifferences, read.Value.SourceCoverage) with { SourceContentManifest = manifest });''');p.write_text(s)
p=w/'src/Compliance.Core/Features/Examinations/TypeIBaselineContentIdentity.cs';s=p.read_text()
anchor='''            writer.WritePropertyName("blockers");'''
assert s.count(anchor)==1
s=s.replace(anchor,'''            if (preview.SourceContentManifest is { } publication)
            {
                writer.WritePropertyName("source_content_manifest");
                writer.WriteStartObject();
                writer.WriteString("schema", publication.Schema);
                writer.WriteString("sha256", publication.Sha256);
                writer.WriteNumber("bytes", publication.Bytes);
                writer.WriteEndObject();
            }
'''+anchor);p.write_text(s)
p=ensure('src/Compliance.Core/Features/Examinations/ExaminationEngagement.cs');s=p.read_text()
s=s.replace('''            SourceCoverage = FreezeCoverage(preview.SourceCoverage),''','''            SourceCoverage = FreezeCoverage(preview.SourceCoverage),
            SourceContentManifest = preview.SourceContentManifest,''')
s=s.replace('''                baseline.SourceCoverage);
            return preview.ContentSha256''','''                baseline.SourceCoverage) with { SourceContentManifest = baseline.SourceContentManifest };
            return preview.ContentSha256''')
s=s.replace('''.OrderBy(static source => source.Kind, StringComparer.Ordinal)
        .ThenBy(static source => source.RecordId.ToString(), StringComparer.Ordinal).ToArray());''','''.Select(static source => source with { Content = null })
        .OrderBy(static source => source.Kind, StringComparer.Ordinal)
        .ThenBy(static source => source.RecordId.ToString(), StringComparer.Ordinal).ToArray());''')
p.write_text(s)
p=ensure('src/Compliance.Core/Features/Examinations/FreezeTypeIBaselineHandler.cs');s=p.read_text().replace('''            baseline.SourceCoverage);''','''            baseline.SourceCoverage) with { SourceContentManifest = baseline.SourceContentManifest };''');p.write_text(s)
print('single immutable publication sidecar proof prepared; baseline events retain original compact source refs')
