from pathlib import Path
import shutil
r=Path('/tmp/compliance-s29-publisher-prepared');w=r/'work'
def ensure(rel):
 p=Path(rel)
 if not (r/'base'/p).exists():
  for a in ['base','work']:
   d=r/a/p;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
 return w/p
for rel,prop in [
 ('src/Compliance.Common/Features/Operations/TypeIIPeriodOpeningContent.cs','SourceContentManifest'),
 ('src/Compliance.Common/Features/Operations/TypeIIPeriodView.cs','OpeningSourceContentManifest'),
 ('src/Compliance.Common/Features/Operations/TypeIIPeriodCloseValidationContent.cs','SourceContentManifest'),
 ('src/Compliance.Common/Features/Operations/TypeIIPeriodCloseValidationView.cs','SourceContentManifest'),
 ('src/Compliance.Common/Features/Operations/TypeIIPeriodCloseSnapshotContent.cs','SourceContentManifest'),
 ('src/Compliance.Common/Features/Operations/TypeIIPeriodCloseSnapshotView.cs','SourceContentManifest')]:
 p=ensure(rel);s=p.read_text();s='using System.Text.Json.Serialization;\nusing Bdgrz.Compliance.Features.Proofs;\n'+s
 if s.rstrip().endswith(');'):
  s=s.rstrip()[:-2]+''')
{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public ImmutableContentRef? '''+prop+''' { get; init; }
}
'''
 else:
  anchor=s.index('\n{',s.index('public sealed record'))+2
  s=s[:anchor]+'''
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public ImmutableContentRef? '''+prop+''' { get; init; }
'''+s[anchor:]
 p.write_text(s)
p=w/'src/Compliance.Core/Features/Operations/StartTypeIIObservationPeriodHandler.cs';s=p.read_text()
s=s.replace('''            sourceReferences, acknowledgedGaps);''','''            sourceReferences, acknowledgedGaps) with { SourceContentManifest = baseline.SourceContentManifest };''',1)
s=s.replace('''            Digest(openingManifest), sourceReferences, acknowledgedGaps);''','''            Digest(openingManifest), sourceReferences, acknowledgedGaps)
            { SourceContentManifest = baseline.SourceContentManifest };''')
s=s.replace('''        IReadOnlyList<Uuid> AcknowledgedGapIds);''','''        IReadOnlyList<Uuid> AcknowledgedGapIds)
    {
        [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
        public ImmutableContentRef? SourceContentManifest { get; init; }
    }''');p.write_text(s)
p=ensure('src/Compliance.Core/Features/Operations/TypeIIPeriod.cs');s=p.read_text()
s=s.replace('''            actorMemberId, actorDisplay.Trim(), startedAt);''','''            actorMemberId, actorDisplay.Trim(), startedAt)
            { OpeningSourceContentManifest = normalizedOpening.SourceContentManifest };''',1)
s=s.replace('''            validatorMemberId, validatorDisplay.Trim(), validatedAt);''','''            validatorMemberId, validatorDisplay.Trim(), validatedAt)
            { SourceContentManifest = normalized.SourceContentManifest };''',1)
s=s.replace('''        changed, affected, actor, role, display, at);''','''        changed, affected, actor, role, display, at)
        { SourceContentManifest = content.SourceContentManifest };''',1)
p.write_text(s)
p=ensure('src/Compliance.Core/Features/Operations/FreezeTypeIIPeriodCloseHandler.cs');s=p.read_text()
s=s.replace('''            approval.AcknowledgedMaterialItemIds);''','''            approval.AcknowledgedMaterialItemIds)
            { SourceContentManifest = validation.SourceContentManifest ?? current.OpeningSourceContentManifest };''',1)
p.write_text(s)
print('Type II opening/close immutable publication-reference propagation prepared; existing null preimages remain unchanged')
