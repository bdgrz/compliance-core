from pathlib import Path
import hashlib,json,re
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');r=Path('/tmp/compliance-access-source-use-preparation-prepared');paths=set()
for folder in ['src/Compliance.Common/Features/AccessReviews','src/Compliance.Core/Features/AccessReviews','test/Compliance.Tests/Features/AccessReviews','src/Compliance.Common/Features/SourceUse','src/Compliance.Core/Features/SourceUse','test/Compliance.Tests/Features/SourceUse']:
 paths.update(str(p.relative_to(repo)) for p in (repo/folder).rglob('*.cs'))
paths.add('src/Compliance.Core/Features/NativeOperations/NativeReceiverPreparation.cs');rows=[]
for p in sorted(paths):
 t=(repo/p).read_bytes()
 for tree in ['base','work']:
  f=r/tree/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t)
 rows.append({'path':p,'baselineSource':str(repo/p),'beforeSha256':hashlib.sha256(t).hexdigest(),'acceptanceNames':re.findall(r'\b(Should\w+)\s*\(',t.decode()) if p.startswith('test/') else[]})
(r/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows))
