from pathlib import Path
r=Path('/tmp/compliance-access-source-use-preparation-prepared');p='src/Compliance.Core/Features/SourceUse/AuthorizeSourceUseHandler.cs';s=(r/'base'/p).read_text();a=s.index('        var verified = await VerifyAsync(');b=s.index('        for (var attempt',a)
s=s[:a]+'''        var selection = ReceiptSelection(request);
        AuthorizationPrepared prepared;
        if (selection is not null)
        {
            var preparation = await NativeReceiverPreparation.PrepareAsync<TOwner, AuthorizationPrepared>(reader,
                () => Open(request, request.CommandId).ForSourceUses(selection),
                (owner, token) => DecideReceiptAsync(request, owner, selection, token),
                (_, token) => PrepareAsync(request, true, token), ct).ConfigureAwait(false);
            if (!preparation.IsSuccess)
                return Result<ReceiverOutcome>.Failure(preparation.Error!);
            if (preparation.Value!.Outcome is { } known)
                return known;
            prepared = preparation.Value.Value!;
        }
        else
        {
            var preparation = await PrepareAsync(request, false, ct).ConfigureAwait(false);
            if (!preparation.IsSuccess)
                return Result<ReceiverOutcome>.Failure(preparation.Error!);
            prepared = preparation.Value!;
        }
        if (prepared.Outcome is { } terminal)
            return terminal;
        var (source, intent) = (prepared.Source!, prepared.Intent!);
        var provenance = SourceUseReceiverSupport.Child(request.CommandId, source.CommandKind,
            request.Source.EventId, source.Header, request.Target, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var grant = GrantOperation();
'''+s[b:]
a=s.index('                var owner = await reader.HydrateAsync(');b=s.index('                var step = await executor.ExecuteAsync(',a)
s=s[:a]+'''                Result<ReceiverOutcome>? Early(TOwner owner) => Decide(owner, binding, source.Key) ??
                    (FencedReason(owner, source.Key) is { } fenced
                        ? SourceUseReceiverSupport.Superseded(fenced, null) : null);
                var pinnedPreparation = await NativeReceiverPreparation.PrepareAsync<TOwner, PinnedPrepared>(reader,
                    () => Open(request, request.CommandId).ForSourceUses(source.Key), Early, async (owner, token) =>
                    {
                        try
                        {
                            var pinned = await VerifyPinnedAsync(owner, source.Requirement, token).ConfigureAwait(false);
                            if (!pinned.IsSuccess)
                            {
                                if (pinned.Error!.IsTransient)
                                    return Result<PinnedPrepared>.Failure(pinned.Error);
                                var refused = await RefuseAsync(request, source, pinned.Error.Message, context, token)
                                    .ConfigureAwait(false);
                                return refused.IsSuccess ? Result<PinnedPrepared>.Success(new PinnedPrepared(refused))
                                    : Result<PinnedPrepared>.Failure(refused.Error!);
                            }
                            return Result<PinnedPrepared>.Success(new PinnedPrepared(null));
                        }
                        catch (ImmutableContentIntegrityException error)
                        {
                            token.ThrowIfCancellationRequested();
                            return Result<PinnedPrepared>.Failure(new RequestError(RequestErrorKind.Conflict,
                                error.Message, error is ImmutableContentUnavailableException));
                        }
                    }, ct).ConfigureAwait(false);
                if (!pinnedPreparation.IsSuccess)
                    return Result<ReceiverOutcome>.Failure(pinnedPreparation.Error!);
                if (pinnedPreparation.Value!.Outcome is { } known)
                    return known;
                if (pinnedPreparation.Value.Value!.Outcome is { } refused)
                    return refused;

'''+s[b:]
a=s.index('    /// <summary>Opens the target owner')
s=s[:a]+'''    /// <summary>An optional exact historical key selected only as a locator before native receipt verification.</summary>
    protected virtual ReservationKey? ReceiptSelection(TRequest request) => null;

    /// <summary>
    /// A pair may bind a selected native receipt's original immutable terms to its actual authoritative parent.
    /// Null retains full verification; a recorded grant intent is never inferred from absence.
    /// </summary>
    protected virtual ValueTask<Result<SourceUseSource>?> VerifyReceiptSourceAsync(TRequest request, TOwner owner,
        CancellationToken ct) => ValueTask.FromResult<Result<SourceUseSource>?>(null);

    async ValueTask<Result<ReceiverOutcome>?> DecideReceiptAsync(TRequest request, TOwner owner, ReservationKey selection,
        CancellationToken ct)
    {
        var receipt = await VerifyReceiptSourceAsync(request, owner, ct).ConfigureAwait(false);
        if (receipt is null)
            return null;
        var result = receipt.Value;
        if (!result.IsSuccess)
            return Result<ReceiverOutcome>.Failure(result.Error!);
        var source = result.Value!;
        if (source.SupersededReason is { } reason)
            return Superseded(source, reason);
        if (source.Key != selection || source.Key.Target != request.Target ||
            source.Key.RootOperationId != request.OperationId || source.Requirement.SourceOwner != request.Target)
            return SourceUseReceiverSupport.Permanent("The authorization differs from the frozen source use requirement.");
        var provenance = SourceUseReceiverSupport.Child(request.CommandId, source.CommandKind,
            request.Source.EventId, source.Header, request.Target, clock.GetUtcNow());
        return Decide(owner, AcceptedOperationBinding.Of(provenance), source.Key);
    }

    async ValueTask<Result<AuthorizationPrepared>> PrepareAsync(TRequest request, bool classify, CancellationToken ct)
    {
        try
        {
            var verified = await VerifyAsync(request, ct).ConfigureAwait(false);
            if (!verified.IsSuccess)
                return Result<AuthorizationPrepared>.Failure(verified.Error!);
            var source = verified.Value!;
            if (source.SupersededReason is { } reason)
                return Result<AuthorizationPrepared>.Success(new AuthorizationPrepared(null, null, Superseded(source, reason)));
            if (source.Key.Target != request.Target || source.Key.RootOperationId != request.OperationId ||
                source.Requirement.SourceOwner != request.Target)
                return Result<AuthorizationPrepared>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The authorization differs from the frozen source use requirement.", false));
            var intent = await Content.WriteJsonAsync(request.Target.Realm,
                Uuid.CreateVersion5(request.CommandId, "source-use-authorization-intent"),
                SourceUseAuthorizationIntent.Schema, new SourceUseAuthorizationIntent(source.Header, source.ParentIntent,
                    source.Key, source.Requirement, null, null), ct).ConfigureAwait(false);
            return Result<AuthorizationPrepared>.Success(new AuthorizationPrepared(source, intent, null));
        }
        catch (ImmutableContentIntegrityException error) when (classify)
        {
            ct.ThrowIfCancellationRequested();
            return Result<AuthorizationPrepared>.Failure(new RequestError(RequestErrorKind.Conflict,
                error.Message, error is ImmutableContentUnavailableException));
        }
    }

    static Result<ReceiverOutcome> Superseded(SourceUseSource source, string reason) => source.RequiresAbort
        ? Result<ReceiverOutcome>.Success(new ReceiverOutcome.Rejected(reason, null))
        : SourceUseReceiverSupport.Superseded(reason, null);

'''+s[a:]
a=s.index('    abstract record Step;');s=s[:a]+'''    sealed record AuthorizationPrepared(SourceUseSource? Source, ImmutableContentRef? Intent, Result<ReceiverOutcome>? Outcome);

    sealed record PinnedPrepared(Result<ReceiverOutcome>? Outcome);

'''+s[a:];(r/'work'/p).write_text(s)
