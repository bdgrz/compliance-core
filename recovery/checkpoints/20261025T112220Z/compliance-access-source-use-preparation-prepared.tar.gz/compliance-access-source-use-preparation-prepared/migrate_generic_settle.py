from pathlib import Path
r=Path('/tmp/compliance-access-source-use-preparation-prepared');p='src/Compliance.Core/Features/SourceUse/SettleSourceUseHandler.cs';s=(r/'base'/p).read_text();a=s.index('        var verified = await VerifyAsync(');b=s.index('        var provenance = ',a)
s=s[:a]+'''        var selection = ReceiptSelection(request);
        SourceUseSource source;
        if (selection is not null)
        {
            var preparation = await NativeReceiverPreparation.PrepareAsync<TOwner, SourceUseSource>(reader,
                () => Open(request, request.CommandId).ForSourceUses(selection),
                (owner, token) => DecideReceiptAsync(request, owner, selection, token),
                (_, token) => PrepareAsync(request, true, token), ct).ConfigureAwait(false);
            if (!preparation.IsSuccess)
                return Result<ReceiverOutcome>.Failure(preparation.Error!);
            if (preparation.Value!.Outcome is { } known)
                return known;
            source = preparation.Value.Value!;
        }
        else
        {
            var preparation = await PrepareAsync(request, false, ct).ConfigureAwait(false);
            if (!preparation.IsSuccess)
                return Result<ReceiverOutcome>.Failure(preparation.Error!);
            source = preparation.Value!;
        }
        var required = source.Disposition!.Value;
'''+s[b:]
a=s.index('                var owner = await reader.HydrateAsync(');b=s.index('                var step = await executor.ExecuteAsync(',a)
s=s[:a]+'''                var preparation = await NativeReceiverPreparation.PrepareAsync<TOwner, SettlementPrepared>(reader,
                    () => Open(request, request.CommandId).ForSourceUses(source.Key),
                    owner => Decide(owner, binding, source.Key), async (owner, token) =>
                    {
                        try
                        {
                            var held = owner.Uses.GrantOf(source.Key);
                            var intent = await Content.WriteJsonAsync(request.Target.Realm,
                                Uuid.CreateVersion5(request.CommandId, $"source-use-settlement-intent:{held?.ReservationGeneration ?? 0}"),
                                SourceUseAuthorizationIntent.Schema, new SourceUseAuthorizationIntent(source.Header,
                                    source.ParentIntent, source.Key, source.Requirement, held, required), token).ConfigureAwait(false);
                            return Result<SettlementPrepared>.Success(new SettlementPrepared(intent, held));
                        }
                        catch (ImmutableContentIntegrityException error) when (selection is not null)
                        {
                            token.ThrowIfCancellationRequested();
                            return Result<SettlementPrepared>.Failure(new RequestError(RequestErrorKind.Conflict,
                                error.Message, error is ImmutableContentUnavailableException));
                        }
                    }, ct).ConfigureAwait(false);
                if (!preparation.IsSuccess)
                    return Result<ReceiverOutcome>.Failure(preparation.Error!);
                if (preparation.Value!.Outcome is { } known)
                    return known;
                var (intent, held) = (preparation.Value.Value!.Intent, preparation.Value.Value.Grant);
'''+s[b:]
a=s.index('    /// <summary>Opens the target owner')
s=s[:a]+'''    /// <summary>An optional exact historical key selected only as a locator before native receipt verification.</summary>
    protected virtual ReservationKey? ReceiptSelection(TRequest request) => null;

    /// <summary>Optionally binds an actual selected settlement and its stored terms to its native terminal source.</summary>
    protected virtual ValueTask<Result<SourceUseSource>?> VerifyReceiptSourceAsync(TRequest request, TOwner owner,
        CancellationToken ct) => ValueTask.FromResult<Result<SourceUseSource>?>(null);

    async ValueTask<Result<ReceiverOutcome>?> DecideReceiptAsync(TRequest request, TOwner owner, ReservationKey selection,
        CancellationToken ct)
    {
        var receipt = await VerifyReceiptSourceAsync(request, owner, ct).ConfigureAwait(false);
        if (receipt is null)
            return null;
        var result = receipt.Value;
        if (!result.IsSuccess)
            return Result<ReceiverOutcome>.Failure(result.Error!);
        var source = result.Value!;
        if (source.Key != selection || source.Key.Target != request.Target || source.Key.RootOperationId != request.OperationId ||
            source.Disposition is not { } required)
            return SourceUseReceiverSupport.Permanent("The settlement differs from the frozen source use requirement.");
        if (request.Disposition != required)
            return SourceUseReceiverSupport.Permanent("The disposition does not match the verified terminal source event kind.");
        var provenance = SourceUseReceiverSupport.Child(request.CommandId, source.CommandKind,
            request.Source.EventId, source.Header, request.Target, clock.GetUtcNow());
        return Decide(owner, AcceptedOperationBinding.Of(provenance), source.Key);
    }

    async ValueTask<Result<SourceUseSource>> PrepareAsync(TRequest request, bool classify, CancellationToken ct)
    {
        try
        {
            var verified = await VerifyAsync(request, ct).ConfigureAwait(false);
            if (!verified.IsSuccess)
                return Result<SourceUseSource>.Failure(verified.Error!);
            var source = verified.Value!;
            if (source.Key.Target != request.Target || source.Key.RootOperationId != request.OperationId ||
                source.Disposition is not { } required)
                return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The settlement differs from the frozen source use requirement.", false));
            return request.Disposition != required
                ? Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The disposition does not match the verified terminal source event kind.", false))
                : verified;
        }
        catch (ImmutableContentIntegrityException error) when (classify)
        {
            ct.ThrowIfCancellationRequested();
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                error.Message, error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
a=s.index('    abstract record Step;');s=s[:a]+'''    sealed record SettlementPrepared(ImmutableContentRef Intent, ReservationGrant? Grant);

'''+s[a:];(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/SourceUse/AuthorizeSourceUseHandler.cs';s=(r/'work'/p).read_text().replace('var refused = await RefuseAsync(request, source, pinned.Error.Message, context, token)','var refusal = await RefuseAsync(request, source, pinned.Error.Message, context, token)').replace('return refused.IsSuccess ? Result<PinnedPrepared>.Success(new PinnedPrepared(refused))','return refusal.IsSuccess ? Result<PinnedPrepared>.Success(new PinnedPrepared(refusal))').replace('Result<PinnedPrepared>.Failure(refused.Error!);','Result<PinnedPrepared>.Failure(refusal.Error!);');(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/AccessReviews/AccessReviewSourceUseReceipts.cs';s=(r/'work'/p).read_text().replace('using Bdgrz.Compliance.Features.NativeOperations;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;').replace('Features.Proofs.ImmutableContentRef parentIntent','ImmutableContentRef parentIntent').replace('''                intent.Requirement.ContentEvent.Stream != owner.Stream || intent.Requirement.Purpose != purpose)''','''                intent.Requirement.ContentEvent is null || intent.Requirement.RequiredFacts is null ||
                intent.Requirement.ContentEvent.Stream != owner.Stream || intent.Requirement.Purpose != purpose)''');(r/'work'/p).write_text(s)
