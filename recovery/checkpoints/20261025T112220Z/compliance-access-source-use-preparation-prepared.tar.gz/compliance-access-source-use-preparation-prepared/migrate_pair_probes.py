from pathlib import Path
r=Path('/tmp/compliance-access-source-use-preparation-prepared');folder='src/Compliance.Core/Features/AccessReviews'
for name,bulk,settle in [('ReserveAccessReviewItemDecisionHandler',True,False),('SettleAccessReviewItemDecisionHandler',True,True),('AuthorizeAccessReviewItemCampaignCompletionUseHandler',False,False),('SettleAccessReviewItemCampaignCompletionUseHandler',False,True)]:
 p=folder+'/'+name+'.cs';s=(r/'base'/p).read_text();request=name.removesuffix('Handler');a=s.index('    protected override async ValueTask<Result<SourceUseSource>> VerifyAsync(')
 if bulk:
  native='''        var native = await verifier.ReadNativeAsync(tenant, request.CampaignId, request.Source, request.Intent,
            request.OperationId, ct).ConfigureAwait(false);
        if (native.Error is not null)
            return Result<SourceUseSource>.Failure(native.Error);
        var campaign = native.Campaign!;
        var parent = native.Admitted!.Operation;
'''
 else:
  native='''        var native = await verifier.ReadNativeAsync(tenant, request.CampaignId, request.Source, request.Intent,
            request.OperationId, Uuid.Empty, ct).ConfigureAwait(false);
        if (native.Error is not null)
            return Result<SourceUseSource>.Failure(native.Error);
        var campaign = native.Campaign!;
        var parent = native.Accepted!.Operation;
'''
 purpose='BulkDecision' if bulk else'CampaignCompletion'
 key='AccessReviewEffects.BulkUseKey(request.OperationId, AccessReviewEffects.CampaignStream(Tenant(request.Target), request.CampaignId), request.Target)' if bulk else'new ReservationKey(request.OperationId, AccessReviewEffects.CampaignStream(Tenant(request.Target), request.CampaignId), (ulong)AccessReviewEffects.Generation, request.Target, SourceUseReservations.PurposeName(SourceUsePurpose.CampaignCompletion))'
 # Completion settlement had no Tenant helper; add one routine scope parser.
 if not bulk and settle:
  s=s.replace('new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture),','new(Tenant(request.Target),')
  pos=s.rfind('\n}')
  s=s[:pos]+'''\n    static Uuid Tenant(EventStreamAddress stream) => Uuid.Parse(stream.Realm, CultureInfo.InvariantCulture);\n'''+s[pos:]
 common='''        var key = ReceiptSelection(request)!;
        var recorded = await AccessReviewSourceUseReceipts.ReadAsync(Content, owner, key, parent, request.Source,
            request.Intent, SourceUsePurpose.PURPOSE, SETTLE, PRIOR, ct).ConfigureAwait(false);
        if (recorded is null)
            return null;
        var result = recorded.Value;
        if (!result.IsSuccess)
            return Result<SourceUseSource>.Failure(result.Error!);
        var intent = result.Value!;
'''.replace('PURPOSE',purpose).replace('SETTLE','true' if settle else'false').replace('PRIOR','true' if not bulk and not settle else'false')
 if not settle:
  common+='''        if (intent.Requirement.ContentEvent.EventId != request.SourceContentEventId ||
            intent.Requirement.ResourceRevision != request.ExpectedContentRevision)
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The authorization differs from its exact recorded source use requirement.", false));
'''
 if bulk:
  common+='''        var batch = await _reader.HydrateAsync(new AccessReviewDecisionBatch(tenant, request.CampaignId,
            request.DecisionBatchId), ct).ConfigureAwait(false);
'''
  if settle:
   common+='''        var disposition = batch.Published is not null ? SourceUseSettlementDisposition.IrreversibleDecision
            : batch.Canceled is not null ? SourceUseSettlementDisposition.Canceled : (SourceUseSettlementDisposition?)null;
        if (disposition is null)
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                "Neither the published batch nor its completed cancellation is visible yet.", true));
        if (disposition == SourceUseSettlementDisposition.IrreversibleDecision && owner.ProvisionalFor(request.DecisionBatchId) is null)
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The published batch has no applied decision on this item.", false));
'''
  else:
   common+='''        var superseded = batch.CancellationAccepted is not null ? "The bulk decision was canceled."
            : batch.Published is not null ? "The bulk decision already published." : null;
'''
 elif settle:
  common+='''        var disposition = campaign.ClosedFor(request.OperationId) is not null ? SourceUseSettlementDisposition.ParentClosed
            : campaign.CanceledFor(request.OperationId) is not null ? SourceUseSettlementDisposition.Canceled
            : (SourceUseSettlementDisposition?)null;
        if (disposition is null)
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                "Neither the closed campaign nor the cancellation fence is visible yet.", true));
'''
 else:
  common+='''        var superseded = campaign.CanceledFor(request.OperationId) is not null ? "The completion was canceled."
            : campaign.ClosedFor(request.OperationId) is not null ? "The completion already closed the campaign." : null;
'''
 common+='''        return Result<SourceUseSource>.Success(new SourceUseSource(intent.Header, intent.ParentIntent, key,
            intent.Requirement, nameof(REQUEST), DISP, SUPER));
'''.replace('REQUEST',request).replace('DISP','disposition' if settle else'null').replace('SUPER','null' if settle else'superseded')
 guard='''        if (request.Generation != AccessReviewEffects.Generation || request.SourceOwnerId != owner.ItemIdBULK)
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The request differs from its selected Access source-use owner or generation.", false));
'''.replace('BULK',' || request.DecisionBatchId != request.OperationId' if bulk else'')
 probe='''    protected override ReservationKey ReceiptSelection(REQUEST request) =>
        KEY;

    protected override async ValueTask<Result<SourceUseSource>?> VerifyReceiptSourceAsync(REQUEST request,
        AccessReviewItem owner, CancellationToken ct)
    {
        var tenant = Tenant(request.Target);
GUARDNATIVECOMMON    }

'''.replace('REQUEST',request).replace('KEY',key).replace('GUARD',guard).replace('NATIVE',native).replace('COMMON',common)
 a=s.index('    protected override async ValueTask<Result<SourceUseSource>> VerifyAsync(')
 s=s[:a]+probe+s[a:]
 (r/'work'/p).write_text(s)
