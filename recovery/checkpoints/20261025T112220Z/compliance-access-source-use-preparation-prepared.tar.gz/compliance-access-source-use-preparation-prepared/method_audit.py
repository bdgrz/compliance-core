from pathlib import Path
import json
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));r=Path('/tmp/compliance-access-source-use-preparation-prepared')
def walk(n):
 stack=[n]
 while stack:
  n=stack.pop();yield n;stack.extend(reversed(n.children))
def txt(t,n):return t[n.start_byte:n.end_byte].decode()
def sig(t,n):
 ps=[x for x in n.children if x.type=='parameter'];return sum('=' not in txt(t,p) for p in ps),len(ps)
paths=[p for p in (r/'work').rglob('*.cs') if not (r/'base'/p.relative_to(r/'work')).exists() or p.read_bytes()!=(r/'base'/p.relative_to(r/'work')).read_bytes()]
errors=[];calls=0
for p in paths:
 t=p.read_bytes();tree=parser.parse(t)
 for cl in tree.root_node.children:
  if cl.type!='file_scoped_namespace_declaration':continue
 for cl in [n for n in walk(tree.root_node) if n.type=='class_declaration']:
  body=cl.child_by_field_name('body');defs={}
  if not body:continue
  for m in body.children:
   if m.type!='method_declaration':continue
   name=m.child_by_field_name('name');params=m.child_by_field_name('parameters') or next((x for x in m.children if x.type=='parameter_list'),None)
   if name and params:defs.setdefault(txt(t,name),[]).append(sig(t,params))
  for inv in walk(body):
   if inv.type!='invocation_expression':continue
   function=inv.child_by_field_name('function');args=inv.child_by_field_name('arguments')
   if not function or not args or function.type!='identifier':continue
   name=txt(t,function)
   if name not in defs:continue
   count=sum(x.type=='argument' for x in args.children);calls+=1
   if not any(a<=count<=b for a,b in defs[name]):errors.append({'path':str(p.relative_to(r/'work')),'method':name,'count':count,'expected':defs[name],'line':t[:inv.start_byte].count(b'\n')+1})
res={'qualification':'Static unqualified per-class method invocation arities; not a compiler.','checkedCalls':calls,'errors':errors};(r/'method-audit.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res))
