from pathlib import Path
r=Path('/tmp/compliance-access-source-use-preparation-prepared');p='src/Compliance.Core/Features/NativeOperations/NativeReceiverPreparation.cs';s=(r/'base'/p).read_text();start=s.index('    public static async ValueTask<Result<Prepared<TPrepared>>> PrepareAsync<TOwner, TPrepared>(')
wrapper='''    public static ValueTask<Result<Prepared<TPrepared>>> PrepareAsync<TOwner, TPrepared>(IAggregateReader reader,
        Func<TOwner> open, Func<TOwner, Result<ReceiverOutcome>?> decide,
        Func<TOwner, CancellationToken, ValueTask<Result<TPrepared>>> prepare, CancellationToken ct)
        where TOwner : Aggregate where TPrepared : class
    {
        ArgumentNullException.ThrowIfNull(reader);
        ArgumentNullException.ThrowIfNull(open);
        ArgumentNullException.ThrowIfNull(decide);
        ArgumentNullException.ThrowIfNull(prepare);
        return PrepareAsync(reader, open, (owner, _) => ValueTask.FromResult(decide(owner)), prepare, ct);
    }

    /// <summary>The same recovery boundary when receipt terms require a verified asynchronous selected-body bind.</summary>
'''
s=s[:start]+wrapper+s[start:]
s=s.replace('''        Func<TOwner> open, Func<TOwner, Result<ReceiverOutcome>?> decide,
        Func<TOwner, CancellationToken, ValueTask<Result<TPrepared>>> prepare, CancellationToken ct)
        where TOwner : Aggregate where TPrepared : class
    {
        ArgumentNullException.ThrowIfNull(reader);''','''        Func<TOwner> open, Func<TOwner, CancellationToken, ValueTask<Result<ReceiverOutcome>?>> decide,
        Func<TOwner, CancellationToken, ValueTask<Result<TPrepared>>> prepare, CancellationToken ct)
        where TOwner : Aggregate where TPrepared : class
    {
        ArgumentNullException.ThrowIfNull(reader);''',1 if False else 0) if False else s
# Replace only async overload and the shared recheck signature; synchronous adapter stays source compatible.
a=s.index('    public static async ValueTask<Result<Prepared<TPrepared>>> PrepareAsync<TOwner, TPrepared>(')
part=s[a:].replace('Func<TOwner> open, Func<TOwner, Result<ReceiverOutcome>?> decide,','Func<TOwner> open, Func<TOwner, CancellationToken, ValueTask<Result<ReceiverOutcome>?>> decide,',1).replace('var known = decide(owner);','var known = await decide(owner, ct).ConfigureAwait(false);').replace('Func<TOwner, Result<ReceiverOutcome>?> decide, CancellationToken ct)','Func<TOwner, CancellationToken, ValueTask<Result<ReceiverOutcome>?>> decide, CancellationToken ct)').replace('var outcome = decide(owner);','var outcome = await decide(owner, ct).ConfigureAwait(false);');s=s[:a]+part
(r/'work'/p).write_text(s)
