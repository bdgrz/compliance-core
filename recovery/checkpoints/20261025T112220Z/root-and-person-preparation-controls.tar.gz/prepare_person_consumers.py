exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
old=(repo/s/'PersonReadConsistency.cs').read_text();old=old.replace('using Cntryl.Portia;','using Bdgrz.Compliance.Features.Content;\nusing Cntryl.Portia;');old=old.replace('IAggregateReader reader, IDomainEventReader events)','IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)')
a=old.index('        var source = await reader.HydrateAsync(');b=old.index('        var view = await directory.GetAsync',a)
old=old[:a]+'''        PersonReadSnapshot snapshot;
        try
        {
            snapshot = await new PersonReader(reader, events, content).ReadAsync(tenantId, personId, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            return Result<PersonView>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The exact person source values do not verify: {error.Message}", error is ImmutableContentUnavailableException));
        }
        var source = snapshot.Owner;
        if (!source.IsCreated)
            return Result<PersonView>.Failure(new RequestError(RequestErrorKind.NotFound, "The person was not found."));
'''+old[b:]
old=old.replace('return Result<PersonView>.Success(view);','return Result<PersonView>.Success(snapshot.View!);')
write(s+'PersonReadConsistency.cs',old)
old=(repo/s/'FitzPersonDirectory.cs').read_text().replace('sealed class FitzPersonDirectory(IKvClient client)','sealed class FitzPersonDirectory(IKvClient client, PersonReader? people = null)')
needle='''            case PersonRecorded recorded:
'''
new='''            case IPersonNativeFact native:
                if (people is null)
                    throw new InvalidOperationException("Native person projection requires its verified historical source reader.");
                var verified = await people.ReadFactAsync(domainEvent, ct).ConfigureAwait(false);
                var prior = await PersonDirectorySchema.People.GetAsync(Transaction, verified.PersonId, ct).ConfigureAwait(false);
                if (prior is null)
                {
                    if (domainEvent is not PersonRegistrationRecorded || verified.Revision != 1)
                        throw new InvalidOperationException("A native person revision cannot project before its creation.");
                    await PersonDirectorySchema.People.InsertAsync(Transaction, verified, ct).ConfigureAwait(false);
                }
                else
                {
                    if (prior.TenantId != verified.TenantId || verified.Revision != prior.Revision + (native.Changed ? 1 : 0) ||
                        !native.Changed && prior != verified)
                        throw new InvalidOperationException("A native person projection requires its exact preceding revision.");
                    if (native.Changed)
                        await PersonDirectorySchema.People.ReplaceAsync(Transaction, prior, verified, ct).ConfigureAwait(false);
                }
                break;
'''
assert needle in old;old=old.replace(needle,new+needle);write(s+'FitzPersonDirectory.cs',old)
old=(repo/s/'PersonDirectoryProjector.cs').read_text();old=old.replace('IProjectorHandler<PersonMembershipCorrelated>','IProjectorHandler<PersonMembershipCorrelated>, IProjectorHandler<PersonRegistrationRecorded>,\n      IProjectorHandler<PersonDetailsRevised>, IProjectorHandler<PersonMembershipCorrelationRecorded>');idx=old.rindex('\n}');old=old[:idx]+'''
    public ValueTask HandleAsync(PersonRegistrationRecorded ev, IProjectorContext context, CancellationToken ct) => projection.ApplyAsync(ev, ct);
    public ValueTask HandleAsync(PersonDetailsRevised ev, IProjectorContext context, CancellationToken ct) => projection.ApplyAsync(ev, ct);
    public ValueTask HandleAsync(PersonMembershipCorrelationRecorded ev, IProjectorContext context, CancellationToken ct) => projection.ApplyAsync(ev, ct);
'''+old[idx:];write(s+'PersonDirectoryProjector.cs',old)
# Add source generators and services only by bounded delta; root composes all current wrappers.
r='src/Compliance.Core/ComplianceCoreJsonContext.cs';old=(repo/r).read_text();idx=old.index('[JsonSerializable(typeof(PersonRecorded))]');roots=['PersonHeader','PersonRegistrationRecorded','PersonDetailsRevised','PersonMembershipCorrelationRecorded','PersonChangeContent'];old=old[:idx]+''.join('[JsonSerializable(typeof('+v+'))]\n' for v in roots)+old[idx:];write(r,old)
r='src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';old=(repo/r).read_text();needle='        services.AddScoped<PersonReadConsistency>();';assert needle in old;old=old.replace(needle,needle+'\n        services.AddScoped<PersonReader>();\n        services.AddScoped<PersonOperations>();');write(r,old)
r='src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';old=(repo/r).read_text();needle='        Decorate<IRequestBus>(services,';idx=old.index(needle);old=old[:idx]+'''        Decorate<IAggregateReader>(services, (provider, inner) =>
            new Bdgrz.Compliance.Features.Workforce.PersonAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));
'''+old[idx:];write(r,old)
# Pure domain acceptance tests retain original names and exact assertions against the detached rule events.
r='test/Compliance.Tests/Features/Workforce/PersonTests.cs';old=(repo/r).read_text().replace('new Person(','new PersonRules(')
import re
old=re.sub(r'new AggregateScenario<Person>\((person)\)\.PendingEvents',r'\1.PendingEvents',old)
write(r,old)
print('Prepared verified owning reads, legacy/native projection consumers, JSON/DI wrapper and original pure rule tests.')
