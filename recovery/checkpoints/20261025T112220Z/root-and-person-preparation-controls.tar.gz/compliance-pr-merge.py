import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = '/tmp/compliance-core-pr1067'
PRS = {p['number']: p for p in json.loads(Path('/tmp/compliance-pr-merge-originals.json').read_text())}
ORDER = [1065,1066,1069,1071,1073,1068,1079,1070,1072,1074,1075,1083,1076,1078,1080,1077,1081,1082,1084,1086,1085]

def call(*args, allow_failure=False):
    p = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if p.returncode and not allow_failure:
        print(p.stdout[-6000:], flush=True)
        raise SystemExit(p.returncode)
    return p

def live(n):
    return json.loads(call('gh','pr','view',str(n),'--json','state,headRefOid,baseRefName,mergeCommit').stdout)

def finish(n):
    original = PRS[n]
    info = live(n)
    if info['state'] == 'MERGED':
        return
    head = call('git','rev-parse','HEAD').stdout.strip()
    if info['headRefOid'] not in (original['headRefOid'], head):
        raise SystemExit(f'PR #{n} changed concurrently: {info["headRefOid"]}')
    if info['headRefOid'] != head:
        call('git','push',f'--force-with-lease=refs/heads/{original["headRefName"]}:{original["headRefOid"]}', 'origin',f'HEAD:refs/heads/{original["headRefName"]}')
    if info['baseRefName'] != 'develop':
        call('gh','pr','edit',str(n),'--base','develop')
    for attempt in range(5):
        merged = call('gh','pr','merge',str(n),'--squash','--admin','--match-head-commit',head,allow_failure=True)
        if merged.returncode == 0:
            break
        if not any(s in merged.stdout for s in ['not mergeable', 'has merge conflicts']) or attempt == 4:
            print(merged.stdout,flush=True)
            raise SystemExit(merged.returncode)
        call('gh','pr','view',str(n),'--json','mergeable,mergeStateStatus')
        time.sleep(1)
    info = live(n)
    if info['state'] != 'MERGED':
        raise SystemExit(f'PR #{n} not merged: {info}')
    print(f'MERGED #{n} {info["mergeCommit"]["oid"]}', flush=True)

if len(sys.argv)>1 and sys.argv[1]=='finish':
    finish(int(sys.argv[2]))

for n in ORDER:
    if live(n)['state'] == 'MERGED':
        continue
    if call('git','rev-parse','--verify','CHERRY_PICK_HEAD',allow_failure=True).returncode == 0:
        raise SystemExit('Resolve the active cherry-pick and run finish for its PR before resuming.')
    call('git','fetch','origin','develop')
    call('git','reset','--hard','origin/develop')
    result = call('git','cherry-pick',PRS[n]['headRefOid'],allow_failure=True)
    if result.returncode:
        conflicts = call('git','diff','--name-only','--diff-filter=U').stdout.strip().splitlines()
        json_conflicts = [p for p in conflicts if p.endswith('.json')]
        if json_conflicts:
            call('python3','/tmp/compliance-merge-json-conflicts.py','--repo',ROOT,*json_conflicts)
            call('git','add',*json_conflicts)
        if 'tools/validate-aggregate-spec.mjs' in conflicts:
            call('git','checkout','--ours','tools/validate-aggregate-spec.mjs')
            call('git','add','tools/validate-aggregate-spec.mjs')
        remaining = call('git','diff','--name-only','--diff-filter=U').stdout.strip()
        if not remaining:
            call('git','-c','core.editor=true','cherry-pick','--continue')
            print(f'RESOLVED catalog conflicts for #{n}',flush=True)
            finish(n)
            continue
        Path('/tmp/compliance-pr-current').write_text(str(n))
        print(f'CONFLICT #{n}\n'+call('git','diff','--name-only','--diff-filter=U').stdout,flush=True)
        raise SystemExit(result.returncode)
    print(f'APPLIED #{n}',flush=True)
    finish(n)
