import json,pathlib,hashlib
root=pathlib.Path.cwd(); audit=root/'docs/product/audits/2026-10-24'; recovery=pathlib.Path(pathlib.Path('/tmp/compliance-recovery-dir').read_text().strip())
m=json.loads((recovery/'typeii-close-file-reviews/manifest.json').read_text())
rows=[]
for r in m['records']:
 assert hashlib.sha256((root/r['path']).read_bytes()).hexdigest()==r['sha256'],r['path']
 for d in r['dependency_sha256']:assert hashlib.sha256((root/d['path']).read_bytes()).hexdigest()==d['sha256'],d['path']
 signals={k:v['noul'] for k,v in r.get('answers',{}).items()}
 if max(signals.values(),default=0)<.65:continue
 name=pathlib.Path(r['path']).stem
 if name=='TypeIIPeriod':
  classification='native_close_receipt_and_source_lineage_verified_retained_owner_followup_explicit'
  evidence='Native close preparation runs after selected receipt recovery; original actor/revision/intent/cutoff and immutable Unit response are checked. Lost-response and equal-winner-after-preparation-failure regressions pass. Real publication/archive regression found missing SourceContentManifest in reconstructed snapshot digest and fixed it. Additional RED proved opening/closing versions of one source were rejected; exact version tuples now normalize and changed-record comparison uses grouped reference sets. The retained complete period State and old approve/freeze/amend producers remain explicit next compact-owner work, not represented as finished.'
 elif name=='TypeIIPeriodCloseHistory':
  classification='read_only_native_capture_with_exact_scope_visibility_and_stable_cutoff'
  evidence='Scans require exact realm/area/native event identity and program scope, bound complete population, retain full typed fact payloads through accepted cutoff, and confirm the same captured history on a second scan. Current restricted visibility is checked before content publication; a direct regression denies the historical change when current visibility is absent. The enclosing reconciliation maps unavailable content to transient Conflict and integrity failures to permanent Conflict before accepting any close.'
 elif name=='PublishedTypeIBaselinePreviewReader':
  classification='physical_publication_under_trusted_scoped_source_pipeline'
  evidence='Reader receives scoped engagement/requester from existing source pipeline; it is not the request authorizer. It publishes only exact captured canonical bytes, verifies tenant/digest/length and verified reopen, and writes a scope-bound immutable manifest. Close handler validates exact period/root/cutoff, complete21-family coverage including empty scans, and exact physical descriptor for every selected reference before native append. Missing/corrupt source and foreign manifest regressions pass; no mutation authority is assigned to the publication helper.'
 else:
  classification='read_only_source_cutoff_preserving_existing_source_fences'
  evidence='This source contributor keeps existing native history/source checkpoint/scope and missing-content handling. The change separates server RecordedThrough from effective-date selection so closing sources can include facts recorded after period end without admitting later-than-cutoff facts. Read-only composition needs no operation receipt; its enclosing production close handler resolves original receipts before re-reading sources and returns typed unavailable/integrity failures before append. Existing TypeI source/publication tests and native TypeII source/replay tests pass.'
 rows.append({'path':r['path'],'sha256':r['sha256'],'signals':signals,'classification':classification,'evidence':evidence})
(audit/'typeii-close-file-reviews.json').write_text(json.dumps(m,indent=2)+'\n')
(audit/'typeii-close-file-triage.json').write_text(json.dumps({'reviewed':m['reviewed'],'blockedReviews':m['blocked'],'signalsTriaged':len(rows),'rows':rows},indent=2)+'\n')
print(json.dumps({'reviewed':m['reviewed'],'signalsTriaged':len(rows),'currentHashes':True}))
