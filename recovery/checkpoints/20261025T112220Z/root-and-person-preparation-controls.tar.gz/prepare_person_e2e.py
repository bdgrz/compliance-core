exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
def edit(r,fn):
 f=p/'work'/r;text=f.read_text() if f.exists() else (repo/r).read_text();write(r,fn(text))
# The exact same explicit creation identity is kept through all authorization polling attempts.
for r in ['test/Compliance.Tests/E2E/BoundaryE2ETests.cs','test/Compliance.Tests/E2E/ApplicationInventoryE2ETests.cs']:
 def helper(text):
  a=text.index('    static async Task<Guid> RecordPersonAsync(');b=text.index('\n    }',a)+6;part=text[a:b]
  part=part.replace('        var deadline =','        var personId = Guid.NewGuid();\n        var deadline =',1).replace('owner.PostAsJsonAsync(peoplePath,','owner.PutAsJsonAsync($"{peoplePath}/{personId}",');return text[:a]+part+text[b:]
 edit(r,helper)
r='test/Compliance.Tests/E2E/WorkforceSourceE2ETests.cs'
def source(text):
 a=text.index('    static async Task<string> RecordPersonAsync(');b=text.index('\n    }',a)+6;part=text[a:b].replace('        var deadline =','        var requestedPersonId = Guid.NewGuid();\n        var deadline =',1).replace('client.PostAsJsonAsync($"{root}/people",','client.PutAsJsonAsync($"{root}/people/{requestedPersonId}",');return text[:a]+part+text[b:]
edit(r,source)
r='test/Compliance.Tests/E2E/PersonE2ETests.cs'
def person(text):
 text=text.replace('owner.PutAsJsonAsync(personPath,','owner.PutAsJsonAsync($"{personPath}/revisions/{Guid.NewGuid():D}",')
 text=text.replace('owner.PostAsJsonAsync(path,','owner.PutAsJsonAsync($"{path}/{Guid.NewGuid():D}",').replace('outsider.PostAsJsonAsync(path,','outsider.PutAsJsonAsync($"{path}/{Guid.NewGuid():D}",')
 text=text.replace('Assert.Equal(HttpStatusCode.NoContent, revised.StatusCode);','Assert.Equal(HttpStatusCode.OK, revised.StatusCode);')
 a=text.index('    static async Task<string> RecordWhenAuthorizedAsync(');b=text.index('\n    }',a)+6;part=text[a:b].replace('        var deadline =','        var personId = Guid.NewGuid();\n        var deadline =',1).replace('owner.PutAsJsonAsync($"{path}/{Guid.NewGuid():D}", body)','owner.PutAsJsonAsync($"{path}/{personId:D}", body)');text=text[:a]+part+text[b:]
 needle='''            _ = await mcp.When("bdgrz.workforce.person.record", new Dictionary<string, object?>
            {
''';text=text.replace(needle,needle+'                ["person_id"] = Guid.NewGuid(),\n')
 needle='''            _ = await mcp.When("bdgrz.workforce.person.revise", new Dictionary<string, object?>
            {
''';text=text.replace(needle,needle+'                ["command_id"] = Guid.NewGuid(),\n');return text
edit(r,person)
r='test/Compliance.Tests/E2E/MemberPresentationE2ETests.cs'
def presentation(text):
 text=text.replace('owner.PostAsJsonAsync($"{root}/people",','owner.PutAsJsonAsync($"{root}/people/{Guid.NewGuid():D}",')
 text=text.replace('$"{personPath}/membership-correlation"','$"{personPath}/membership-correlations/{Guid.NewGuid():D}"')
 # These selected Unit mutations now truthfully return200{}.
 text=text.replace('Assert.Equal(HttpStatusCode.NoContent, correlated.StatusCode);','Assert.Equal(HttpStatusCode.OK, correlated.StatusCode);').replace('Assert.Equal(HttpStatusCode.NoContent, unlinked.StatusCode);','Assert.Equal(HttpStatusCode.OK, unlinked.StatusCode);');return text
edit(r,presentation)
r='test/Compliance.Tests/E2E/WorkforceServiceIdentityE2ETests.cs'
def identity(text):
 a=text.index('    static async Task<string> PostWhenAuthorizedAsync(');b=text.index('\n    }',a)+6;part=text[a:b];part=part.replace('        var deadline =','        var personId = Guid.NewGuid();\n        var deadline =',1)
 import re
 m=re.search(r'using var (\w+) = await (\w+)\.PostAsJsonAsync\((\w+), body\);',part);assert m,part
 var,client,path=m.groups();replacement=f'''using var {var} = {path}.EndsWith("/people", StringComparison.Ordinal)
                ? await {client}.PutAsJsonAsync($"{{{path}}}/{{personId:D}}", body)
                : await {client}.PostAsJsonAsync({path}, body);''';part=part[:m.start()]+replacement+part[m.end():];return text[:a]+part+text[b:]
edit(r,identity)
print('Prepared all six existing owning backend E2E transport consumers, preserving acceptance names/assert count.')
