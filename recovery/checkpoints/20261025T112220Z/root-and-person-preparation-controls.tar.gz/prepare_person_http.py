exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
write('src/Compliance.App/Features/Workforce/PersonHttp.cs','''using System.Globalization;
using System.Text.Json;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Selected tenant/person/operation identities come only from canonical route segments.</summary>
static class PersonHttp
{
    public sealed record RecordBody(string DisplayName, string? WorkEmail = null, PersonalContactDetails? PersonalContact = null);
    public sealed record ReviseBody(long ExpectedRevision, string DisplayName, string? WorkEmail = null, PersonalContactDetails? PersonalContact = null);
    public sealed record CorrelateBody(long ExpectedRevision, Uuid? UserId = null);
    public static async ValueTask<RecordPerson> BindRecordAsync(HttpContext context, CancellationToken ct)
    {
        using var document = await PortiaHttpBinding.ReadJsonBodyAsync(context, true, ct).ConfigureAwait(false);
        var body = document.RootElement;
        var tenant = Identity(context, body, "tenant_id");
        var person = Identity(context, body, "person_id");
        var options = PortiaHttpBinding.GetJsonOptions(context);
        return new RecordPerson(person, tenant,
            PortiaHttpBinding.ReadBody<RecordPerson, string>(body, options, 2, "DisplayName", "display_name", false, false, default!),
            PortiaHttpBinding.ReadBody<RecordPerson, string?>(body, options, 3, "WorkEmail", "work_email", true, true, default),
            PortiaHttpBinding.ReadBody<RecordPerson, PersonalContactDetails?>(body, options, 4, "PersonalContact", "personal_contact", true, true, default));
    }
    public static async ValueTask<RevisePerson> BindReviseAsync(HttpContext context, CancellationToken ct)
    {
        using var document = await PortiaHttpBinding.ReadJsonBodyAsync(context, true, ct).ConfigureAwait(false);
        var body = document.RootElement;
        var tenant = Identity(context, body, "tenant_id");
        var person = Identity(context, body, "person_id");
        var command = Identity(context, body, "command_id");
        var options = PortiaHttpBinding.GetJsonOptions(context);
        return new RevisePerson(command, tenant, person,
            PortiaHttpBinding.ReadBody<RevisePerson, long>(body, options, 3, "ExpectedRevision", "expected_revision", false, false, default),
            PortiaHttpBinding.ReadBody<RevisePerson, string>(body, options, 4, "DisplayName", "display_name", false, false, default!),
            PortiaHttpBinding.ReadBody<RevisePerson, string?>(body, options, 5, "WorkEmail", "work_email", true, true, default),
            PortiaHttpBinding.ReadBody<RevisePerson, PersonalContactDetails?>(body, options, 6, "PersonalContact", "personal_contact", true, true, default));
    }
    public static async ValueTask<CorrelatePersonMembership> BindCorrelateAsync(HttpContext context, CancellationToken ct)
    {
        using var document = await PortiaHttpBinding.ReadJsonBodyAsync(context, true, ct).ConfigureAwait(false);
        var body = document.RootElement;
        var tenant = Identity(context, body, "tenant_id");
        var person = Identity(context, body, "person_id");
        var command = Identity(context, body, "command_id");
        var options = PortiaHttpBinding.GetJsonOptions(context);
        return new CorrelatePersonMembership(command, tenant, person,
            PortiaHttpBinding.ReadBody<CorrelatePersonMembership, long>(body, options, 3, "ExpectedRevision", "expected_revision", false, false, default),
            PortiaHttpBinding.ReadBody<CorrelatePersonMembership, Uuid?>(body, options, 4, "UserId", "user_id", true, true, default));
    }
    static Uuid Identity(HttpContext context, JsonElement body, string name)
    {
        if (!Uuid.TryParse(context.Request.RouteValues[name]?.ToString(), CultureInfo.InvariantCulture, out var value) || value == Uuid.Empty)
            throw new BadHttpRequestException("Invalid person route identity.");
        if (body.TryGetProperty(name, out var supplied) && (supplied.ValueKind != JsonValueKind.String ||
            !Uuid.TryParse(supplied.GetString(), CultureInfo.InvariantCulture, out var parsed) || parsed != value))
            throw new BadHttpRequestException("The body identity conflicts with the canonical person route.");
        return value;
    }
}
''')
r='src/Compliance.App/Program.cs';old=(repo/r).read_text().replace('.AddMcpTool<RecordPerson>()','.AddMcpTool<RecordPerson>(tool => tool.Idempotent())');a=old.index('    app.MapPortiaPost<RecordPerson, PersonRegistration>');b=old.index('    app.MapPortiaGet<GetPerson, PersonView>',a)
old=old[:a]+'''    app.MapPortiaPut<RecordPerson, PersonRegistration>(
            "/api/v1/tenants/{tenant_id}/people/{person_id}", config => config
                .OnBind(PersonHttp.BindRecordAsync)
                .Accepts<PersonHttp.RecordBody>("application/json", isOptional: false)
                .Parameter<Uuid>("tenant_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("person_id", PortiaHttpParameterLocation.Route, required: true)
                .OnNativeResult()).WithNativeFirstResponse<RecordPerson>()
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Workforce");
    app.MapPortiaPut<RevisePerson, UnitResult>(
            "/api/v1/tenants/{tenant_id}/people/{person_id}/revisions/{command_id}", config => config
                .OnBind(PersonHttp.BindReviseAsync)
                .Accepts<PersonHttp.ReviseBody>("application/json", isOptional: false)
                .Parameter<Uuid>("tenant_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("person_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("command_id", PortiaHttpParameterLocationRoute, required: true)
                .OnNativeResult()).WithNativeFirstResponse<RevisePerson>()
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Workforce");
    app.MapPortiaPut<CorrelatePersonMembership, UnitResult>(
            "/api/v1/tenants/{tenant_id}/people/{person_id}/membership-correlations/{command_id}", config => config
                .OnBind(PersonHttp.BindCorrelateAsync)
                .Accepts<PersonHttp.CorrelateBody>("application/json", isOptional: false)
                .Parameter<Uuid>("tenant_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("person_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("command_id", PortiaHttpParameterLocation.Route, required: true)
                .OnNativeResult()).WithNativeFirstResponse<CorrelatePersonMembership>()
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Workforce");
'''.replace('PortiaHttpParameterLocationRoute','PortiaHttpParameterLocation.Route')+old[b:];write(r,old)
print('Prepared canonical Person3 routes and strict route/body identity binders.')
