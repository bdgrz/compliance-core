import json,os,subprocess,urllib.request
from pathlib import Path
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core'); out=Path('/tmp/compliance-full-boundary-audit-20261023'); key=os.environ['TYPESAFE_API_KEY']
files=sorted((root/'src/Compliance.Core').rglob('*Reactor.cs'))
rows=[]
for p in files:
 rel=str(p.relative_to(root)); name=p.stem
 tests=subprocess.run(['rg','-l',name,'test/Compliance.Tests'],cwd=root,text=True,capture_output=True).stdout.splitlines()
 code=p.read_text()
 rows.append({'name':name,'source':rel,'currentImplementation':code,'testReferences':[str(Path(x)) for x in tests[:8]]})
questions={}
for i,r in enumerate(rows):
 questions[f'{i:02d}_{r["name"]}']={'type':'noul','instructions':f"Does the current {r['name']} implementation have a materially unsafe boundary/choreography: it owns state that belongs to another aggregate, makes a cross-owner decision without exact source proof, emits/retries an effect without a stable business identity, can permanently lose or duplicate an accepted obligation, or treats transient/unknown outcomes as terminal? Answer no if its trigger, owner command/effect key, and failure/replay behavior are coherent. Focus on a concrete issue evidenced by this source; do not infer failure merely because this is a reactor.",'criteria':{'yes':'A specific unsafe authority, retry, lifecycle, or recovery gap is evidenced in the implementation.','no':'The reactor is a coherent reaction; no material boundary/recovery defect is evidenced here.'}}
payload={'model':'jev-latest','state':{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'count':len(rows),'reactors':rows},'questions':questions}
rq=out/'current-reactors-request.json'; rs=out/'current-reactors-response.json'; rq.write_text(json.dumps(payload,separators=(',',':'))+'\n')
req=urllib.request.Request('https://api.typesafe.ai/v1/systemone',data=rq.read_bytes(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
with urllib.request.urlopen(req,timeout=90) as response: result=json.load(response)
rs.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'model':result.get('model'),'usage':result.get('usage'),'reactors':len(rows),'signals':[(k,a.get('noul')) for k,a in result.get('answers',{}).items() if a.get('noul',0)>=.5]}))
