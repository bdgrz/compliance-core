import pathlib,re,json,hashlib,collections
root=pathlib.Path.cwd();rec=pathlib.Path(pathlib.Path('/tmp/compliance-recovery-dir').read_text().strip());hashes={};owners=[]
for p in (root/'src').rglob('*.cs'):
 if 'obj' in p.parts or 'bin' in p.parts:continue
 path=str(p.relative_to(root));b=p.read_bytes();hashes[path]=hashlib.sha256(b).hexdigest();s=b.decode();k=[]
 if path.startswith('src/Compliance.Core/'):
  if re.search(r'\bclass\s+\w+[^;{]*:\s*(?:[\w.]+\.)?Aggregate\b',s,re.S):k.append('aggregate')
  if path.endswith('Handler.cs') or 'IRequestHandler<' in s:k.append('handler')
  if path.endswith('Reactor.cs') or re.search(r'\bclass\s+\w+Reactor\b',s):k.append('reactor')
  if k:owners.append({'path':path,'sha256':hashes[path],'kinds':k})
by=collections.defaultdict(list)
for p in rec.glob('*file-reviews/manifest.json'):
 try:m=json.loads(p.read_text())
 except Exception:continue
 for r in m.get('records',[]):
  if r.get('status')=='reviewed':by[r['path']].append((str(p),r))
stale=[]
for row in owners:
 candidates=[(p,r) for p,r in by[row['path']] if r['sha256']==row['sha256'] and all(hashes.get(d['path'])==d['sha256'] for d in r.get('dependency_sha256',[]))]
 if candidates:
  p,r=max(candidates,key=lambda x:x[1].get('reviewed_at',''));row.update({'status':'fresh_reviewed','manifest':p,'review_key':r['review_key']})
 else:row['status']='needs_review';stale.append(row['path'])
m={'total':len(owners),'freshReviewed':len(owners)-len(stale),'needsReview':len(stale),'kinds':dict(collections.Counter(k for r in owners for k in r['kinds'])),'files':sorted(owners,key=lambda r:r['path'])};pathlib.Path('/tmp/compliance-current-owner-review-inventory.json').write_text(json.dumps(m,indent=2)+'\n');pathlib.Path('/tmp/compliance-current-review-refresh-3-files.json').write_text(json.dumps(stale,indent=2)+'\n');print(json.dumps({k:v for k,v in m.items() if k!='files'}))
