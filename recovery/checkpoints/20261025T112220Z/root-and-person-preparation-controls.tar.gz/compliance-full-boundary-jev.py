import json, os, subprocess, urllib.request, hashlib
from pathlib import Path
base=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
audit=json.load(open(base/'docs/product/audits/2026-10-22/audit.json'))
choreo=json.load(open(base/'docs/product/audits/2026-10-22/choreography.json'))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()
changed=set(subprocess.check_output(['git','diff','--name-only','4c255f56bfec727ac1f6e841c09935a4ce69ec4c..HEAD'],cwd=base,text=True).splitlines())
key=os.environ['TYPESAFE_API_KEY']
outdir=Path('/tmp/compliance-full-boundary-audit-20261023'); outdir.mkdir(exist_ok=True)
rule='Evaluate aggregate boundary design, not whether a command route or test is complete. One owner per independently changing identity/lifecycle unless a named invariant requires atomic shared state. Keep cross-owner decisions in handlers using exact proofs; never rely on projections as authority. Avoid unbounded unrelated history or invented lifetime caps. A split is sound only when its coordinator/reservations preserve the invariant and have durable retry/recovery.'
def request(name, items, kind):
 state={'currentHead':head,'baselineSourceCommit':audit['sourceCommit'],'currentChangesRelevantToRows':sorted(changed),'acceptanceRules':rule,'rows':items}
 qs={}
 for i,item in enumerate(items):
  label=item.get('name',item.get('name'))
  qs[f'{i:03d}_{label}']={'type':'noul','instructions':f"Does the evidence for {label} indicate the current/proposed boundary is materially incomplete or incorrectly placed? Answer yes when independent lifecycles are unnecessarily coupled, necessary atomic conflict authority is split without safe coordination, retained command state/history is unbounded or blocked by an arbitrary lifetime cap, or a cross-owner invariant is delegated to a projection/live read without exact proof. Answer no when the current boundary is sound under the stated invariant even if implementation gaps remain. If source evidence is too thin, treat that as a reason for yes only when the missing evidence prevents validating the boundary.", 'criteria':{'yes':'Material boundary risk or missing boundary proof is present.','no':'Boundary is justified by the named invariant and evidence; remaining gaps are implementation or wiring only.'}}
 payload={'model':'jev-latest','state':state,'questions':qs}
 reqpath=outdir/f'{name}-request.json'; respath=outdir/f'{name}-response.json'
 reqpath.write_text(json.dumps(payload,separators=(',',':'))+'\n')
 req=urllib.request.Request('https://api.typesafe.ai/v1/systemone',data=reqpath.read_bytes(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=90) as r: result=json.load(r)
 respath.write_text(json.dumps(result,indent=2)+'\n')
 answers=result.get('answers',{})
 probs=[]
 for q,a in answers.items():
  p=a.get('noul') if isinstance(a,dict) else None
  if p is not None: probs.append((q,p))
 print(json.dumps({'batch':name,'rows':len(items),'model':result.get('model'),'usage':result.get('usage'),'yesCountOver0_5':sum(p>=.5 for _,p in probs),'highYesOver0_8':sum(p>=.8 for _,p in probs),'lowest':sorted(probs,key=lambda x:x[1])[:5],'highest':sorted(probs,key=lambda x:x[1],reverse=True)[:8]}))
rows=audit['aggregates']
for start in range(0,len(rows),26):
 batch=[]
 for a in rows[start:start+26]:
  batch.append({k:a.get(k) for k in ['name','feature','sourceFiles','invariant','splitTest','identity','stateAndGrowth','contention','events','crossOwner','disposition','findingIds','decisionStatus']})
  batch[-1]['currentSourceTouchedSinceBaseline']=any(p in changed for p in a.get('sourceFiles',[]))
 request(f'aggregates-{start+1:03d}-{start+len(batch):03d}',batch,'aggregate')
items=[]
for r in choreo['reactors']:
 items.append({k:r.get(k) for k in ['name','source','triggerFacts','targetOwnerCommands','stableCorrelationRequestId','checkpointFailureRetry','verdict','findingIds','directAggregateMutation']})
request('reactors',items,'reactors')
