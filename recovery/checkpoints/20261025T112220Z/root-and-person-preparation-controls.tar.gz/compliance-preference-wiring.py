exec(open('/tmp/compliance-prepare-preference.py').read())
p='src/Compliance.Core/ComplianceCoreJsonContext.cs';s=current(p);anchor='[JsonSerializable(typeof(SetWorkDigestPreference))]';assert anchor in s;save(p,s.replace(anchor,anchor+'\n[JsonSerializable(typeof(WorkDigestPreferenceRecorded))]'))
p='src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=current(p);anchor='        Decorate<IRequestBus>';assert anchor in s;s=s.replace(anchor,'''        Decorate<IAggregateReader>(services, (provider, inner) =>
            new WorkPreferenceAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));
'''+anchor,1);save(p,s)
p='src/Compliance.App/Program.cs';s=current(p);old='"/api/v1/tenants/{tenant_id}/work-digest-preference", config => config.OnNativeResult()).WithNativeFirstResponse<SetWorkDigestPreference>()';new='"/api/v1/tenants/{tenant_id}/work-digest-preference/changes/{command_id}", config => config.OnNativeResult()).WithNativeFirstResponse<SetWorkDigestPreference>()';assert old in s;save(p,s.replace(old,new,1))
p='test/Compliance.Tests/Testing/VerifiedWorkPreferenceServices.cs';s=current('test/Compliance.Tests/Testing/VerifiedWorkAssignmentServices.cs').replace('VerifiedWorkAssignmentServices','VerifiedWorkPreferenceServices').replace('AddVerifiedWorkAssignmentReader','AddVerifiedWorkPreferenceReader').replace('WorkAssignmentAggregateReader','WorkPreferenceAggregateReader');save(p,s)
p='test/Compliance.Tests/Testing/ProgramManagementServices.cs';s=current(p);anchor='        collection.AddVerifiedWorkAssignmentReader();';assert anchor in s;save(p,s.replace(anchor,anchor+'\n        collection.AddVerifiedWorkPreferenceReader();'))
p='test/Compliance.Tests/Features/Work/WorkReminderTests.cs';s=current(p);old='new SetWorkDigestPreference(fixture.TenantId, false)';assert old in s;save(p,s.replace(old,'new SetWorkDigestPreference(Uuid.CreateVersion4(), fixture.TenantId, false)'))
p='test/Compliance.Tests/Features/Work/WorkDigestPreferenceNativeTests.cs';s=(pkg/'red'/p).read_text();s=s.replace('using System.Text.Json;','using System.Text.Json;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;')
anchor='    static SetWorkDigestPreference Request';s=s.replace(anchor,'''    [Fact]
    public async Task ShouldRefuseOwnOriginalReceiptGivenCanonicalMembershipSuspended()
    {
        // Arrange
        var fixture = await OperationsFixture.CreateAsync();
        var request = Request(Uuid.CreateVersion4(), fixture.TenantId, false, "UTC");
        await fixture.AsAsync(fixture.OwnerUserId, request);
        await fixture.SuspendAsync(fixture.OwnerUserId);
        await using var scope = fixture.Provider.CreateAsyncScope();

        // Act
        var refused = await scope.ServiceProvider.GetRequiredService<IRequestBus>().SendAsync(request,
            ProgramManagementServices.Actor(fixture.OwnerUserId));

        // Assert
        Assert.False(refused.IsSuccess);
        Assert.Equal(RequestErrorKind.Forbidden, refused.Error?.Kind);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldClassifyUnavailableOrCorruptOriginalReceiptGivenAcceptedPreference(bool corrupt)
    {
        // Arrange
        ReceiptFault content = null!;
        var fixture = await OperationsFixture.CreateAsync(configureContent: inner => content = new ReceiptFault(inner));
        var request = Request(Uuid.CreateVersion4(), fixture.TenantId, false, "UTC");
        await fixture.AsAsync(fixture.OwnerUserId, request);
        content.Fail = true;
        content.Corrupt = corrupt;
        await using var scope = fixture.Provider.CreateAsyncScope();

        // Act
        var refused = await scope.ServiceProvider.GetRequiredService<IRequestBus>().SendAsync(request,
            ProgramManagementServices.Actor(fixture.OwnerUserId));
        var current = await scope.ServiceProvider.GetRequiredService<IAggregateReader>()
            .HydrateAsync(new WorkDigestPreference(fixture.TenantId, fixture.OwnerMemberId));

        // Assert
        Assert.False(refused.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, refused.Error?.Kind);
        Assert.Equal(!corrupt, refused.Error?.IsTransient);
        Assert.Equal(1UL, current.CommittedStreamPosition);
        Assert.False(current.Read().EmailDigestEnabled);
    }

    sealed class ReceiptFault(IImmutableContentStore inner) : IImmutableContentStore
    {
        public bool Fail { get; set; }
        public bool Corrupt { get; set; }
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid id, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm, id, schema, mediaType, bytes, ct);
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default)
        {
            if (Fail && reference.Schema == FirstResponses.Schema)
                throw Corrupt ? new ImmutableContentIntegrityException("Corrupt original preference descriptor.")
                    : new ImmutableContentUnavailableException("Missing original preference descriptor.");
            return inner.ReadVerifiedAsync(realm, reference, ct);
        }
    }

'''+anchor);save(p,s)
# Refuse invalid deserialized receipt values as integrity errors, before dereferencing them.
p='src/Compliance.Core/Features/Work/WorkDigestPreference.cs';s=(work/p).read_text();s=s.replace('            var expected = Decide(Read(), fact.EmailDigestEnabled, fact.AuthoredTimeZoneId, fact.Operation.AcceptedAt);','''            if (fact.Operation is null || fact.Preference is null || !WorkDigestSchedule.IsValidTimeZone(fact.AuthoredTimeZoneId))
                throw new ImmutableContentIntegrityException("The preference receipt has invalid authored values.");
            var expected = Decide(Read(), fact.EmailDigestEnabled, fact.AuthoredTimeZoneId, fact.Operation.AcceptedAt);''');save(p,s)
p='src/Compliance.Core/Features/Work/WorkPreferenceAggregateReader.cs';s=(work/p).read_text();s=s.replace('if (native.TenantId != preference.TenantId', 'if (native.Operation is null || native.Preference is null || native.TenantId != preference.TenantId');save(p,s)
paths=sorted(str(p.relative_to(work)) for p in work.rglob('*') if p.is_file());(pkg/'manifest.json').write_text(json.dumps({'paths':paths,'status':'WIP_OFFLINE_NO_RUNTIME','qualifiedRed':3,'newRegressions':3},indent=2)+'\n');print('Preference offline complete source/fixture paths',len(paths))
