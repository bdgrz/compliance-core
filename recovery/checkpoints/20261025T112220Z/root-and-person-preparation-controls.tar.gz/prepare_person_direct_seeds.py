exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
helper=p/'work/test/Compliance.Tests/Testing/PersonSeeds.cs';text=helper.read_text().replace('AuthoredIntentDigest.Compute(change)','ContentDigest.Sha256(change, change.GetType())');idx=text.index('    public static async Task AppendAsync(IAggregateReader')
text=text[:idx]+'''    public static async Task AppendAsync(IServiceProvider provider, PersonRules source, CancellationToken ct = default)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        await AppendAsync(services.GetRequiredService<IAggregateReader>(), services.GetRequiredService<IAggregateWriter>(),
            services.GetRequiredService<IDomainEventReader>(), services.GetRequiredService<IImmutableContentStore>(), source, ct);
    }
'''+text[idx:];text='using Microsoft.Extensions.DependencyInjection;\n'+text;helper.write_text(text)
# Explicit broker-free fixture ports + installed wrapper for bare Portia test hosts.
orig=Path('/tmp/compliance-tenant-manager-native-prepared/work/test/Compliance.Tests/Testing/VerifiedTenantManagerServices.cs').read_text()
orig=orig.replace('using Bdgrz.Compliance.Features.AccessControl;','using Bdgrz.Compliance.Features.Workforce;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Hosting.Persistence;\nusing Cntryl.Fitz.Testing;\nusing Microsoft.Extensions.DependencyInjection.Extensions;')
orig=orig.replace('VerifiedTenantManagerServices','VerifiedPersonServices').replace('AddVerifiedTenantManagerReader','AddPersonNativeFixtures').replace('new TenantManagerGuardAggregateReader','new PersonAggregateReader')
orig=orig.replace('''provider.GetRequiredService<IDomainEventReader>(), provider.GetRequiredService<Bdgrz.Compliance.Features.Content.IImmutableContentStore>(),
                provider.GetRequiredService<TimeProvider>()),''','''provider.GetRequiredService<IDomainEventReader>()),''')
needle='''        var originalReader = services.Last''';orig=orig.replace(needle,'''        services.TryAddSingleton<IDomainEventReader>(provider => (IDomainEventReader)provider.GetRequiredService<IEventStore>());
        services.TryAddSingleton<IImmutableContentStore>(_ => new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient())));
        var originalReader = services.Last''')
write('test/Compliance.Tests/Testing/VerifiedPersonServices.cs',orig)
def edit(r,fn):
 f=p/'work'/r;text=f.read_text() if f.exists() else (repo/r).read_text();write(r,fn(text))
# Remaining constructors occur in explicit local rule+save fixture blocks.
selected={
 'test/Compliance.Tests/Testing/ApplicationInventoryHost.cs':('person','Writer','_scope.ServiceProvider'),
 'test/Compliance.Tests/Features/Applications/ApplicationRevisionGovernanceTests.cs':('person','Writer','_scope.ServiceProvider'),
 'test/Compliance.Tests/Features/Applications/ApplicationRevisionPreviewContractTests.cs':('person','Writer','_scope.ServiceProvider'),
 'test/Compliance.Tests/Features/Applications/ApplicationInventoryHttpTests.cs':('owner','writer','scope.ServiceProvider'),
 'test/Compliance.Tests/Features/Applications/ApplicationRevisionFieldPresenceHttpTests.cs':('owner','writer','scope.ServiceProvider'),
 'test/Compliance.Tests/Features/Work/FitzPolicyCampaignWorkItemDirectoryTests.cs':('person','writer','sourceScope.ServiceProvider'),
 'test/Compliance.Tests/Features/Work/PolicyCampaignWorkTests.cs':('person','writer','scope.ServiceProvider'),
 'test/Compliance.Tests/Features/Workforce/RecordWorkRelationshipHandlerTests.cs':('person','scenario.Writer','scenario._scope.ServiceProvider'),
}
import re
for r,(var,writer,provider) in selected.items():
 def transform(text):
  text=text.replace('var '+var+' = new Person(','var '+var+' = new PersonRules(')
  pattern=r'await '+re.escape(writer)+r'\.SaveAsync\('+var+r',\s*(?:new RequestDispatchContext\(RequestActor.System\)|dispatch)(?:,\s*CancellationToken.None)?\);'
  text,n=re.subn(pattern,'await PersonSeeds.AppendAsync('+provider+', '+var+');',text)
  assert n==1,(r,n)
  if 'using Bdgrz.Compliance.Tests.Testing;' not in text:text='using Bdgrz.Compliance.Tests.Testing;\n'+text
  if 'Features/Workforce/RecordWorkRelationshipHandlerTests.cs' in r:text=text.replace('            services.AddPortia();','            services.AddPortia();\n            services.AddPersonNativeFixtures();')
  return text
 edit(r,transform)
# Application owner fixture has three explicit sources in different scopes.
r='test/Compliance.Tests/Features/Applications/ApplicationOwnerTests.cs'
def owners(text):
 text=text.replace('var person = new Person(','var person = new PersonRules(').replace('var foreignOwner = new Person(','var foreignOwner = new PersonRules(')
 text=text.replace('await scenario.Writer.SaveAsync(person, new RequestDispatchContext(RequestActor.System));','await PersonSeeds.AppendAsync(scenario._scope.ServiceProvider, person);')
 text=text.replace('await scenario.Writer.SaveAsync(foreignOwner, new RequestDispatchContext(RequestActor.System));','await PersonSeeds.AppendAsync(scenario._scope.ServiceProvider, foreignOwner);')
 text=text.replace('await Writer.SaveAsync(person, new RequestDispatchContext(RequestActor.System));','await PersonSeeds.AppendAsync(_scope.ServiceProvider, person);')
 if 'using Bdgrz.Compliance.Tests.Testing;' not in text:text='using Bdgrz.Compliance.Tests.Testing;\n'+text
 return text
edit(r,owners)
# Direct executor fixture calls become explicit pure-rule helper calls with all original assertions retained.
r='test/Compliance.Tests/Testing/NamedRecordHost.cs'
def named(text):
 a=text.index('        var executor = Provider.GetRequiredService<IAggregateExecutor>();',text.index('public async Task SeedOwnerAsync'))
 b=text.index('\n    }',a)
 text=text[:a]+'''        var rules = new PersonRules(TenantId, OwnerPersonId);
        var result = rules.Record("Owner", null, ActorReference.ForMember(Uuid.CreateVersion4(), "Seed"), DateTimeOffset.UtcNow);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await PersonSeeds.AppendAsync(Provider, rules);'''+text[b:];return text
edit(r,named)
r='test/Compliance.Tests/Features/TechnologyInventory/InventoryRetryTests.cs'
def inventory(text):
 a=text.index('            var result = await host._provider.GetRequiredService<IAggregateExecutor>().ExecuteAsync(')
 b=text.index('\n            return host;',a)
 old=text[a:b]
 text=text[:a]+'''            var person = new PersonRules(host.TenantId, host.OwnerId);
            var result = person.Record("Owner", null, ActorReference.ForMember(Uuid.CreateVersion4(), "Author"), DateTimeOffset.UtcNow);
            Assert.True(result.IsSuccess, result.Error?.Message);
            await PersonSeeds.AppendAsync(host._provider, person);'''+text[b:]
 text=text.replace('            services.AddPortia();','            services.AddPortia();\n            services.AddPersonNativeFixtures();')
 if 'using Bdgrz.Compliance.Tests.Testing;' not in text:text='using Bdgrz.Compliance.Tests.Testing;\n'+text
 return text
edit(r,inventory)
print('Prepared explicit direct native seed migrations.')
