exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
write(s+'PersonHistory.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Complete transient native/legacy history, with exact raw prefix before any selected receipt escapes.</summary>
public static class PersonHistory
{
    public static async Task<IReadOnlyList<DomainEvent>> ReadAsync(Person owner, IDomainEventReader events,
        CancellationToken ct = default)
    {
        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, owner, ct).ConfigureAwait(false);
        PersonHeader? header = null;
        Bdgrz.Compliance.Features.Proofs.ImmutableContentRef? current = null;
        var logical = new HashSet<Uuid>();
        var digest = FirmIndependenceReplayDigest.Empty;
        foreach (var fact in facts)
        {
            if (fact is IPersonNativeFact native)
            {
                header = NextNative(owner.TenantId, owner.Id, owner.Stream, header, fact);
                current = native.Content;
                if (!logical.Add(native.Operation.LogicalId)) throw Invalid("A person history repeats an unselected native operation.");
                if (native.Operation.LogicalId == owner.Acceptance.SelectedLogicalId &&
                    (owner.Acceptance.SelectedFact is not { } selected || !selected.Equals(fact) || selected.Metadata != fact.Metadata))
                    throw Invalid("The selected person receipt differs from its actual payload and full metadata.");
            }
            else
            {
                if (current is not null) throw Invalid("Read-only legacy person history cannot follow native content authority.");
                header = NextLegacy(owner.TenantId, owner.Id, header, fact);
            }
            digest = FirmIndependenceReplayDigest.Append(digest, fact);
        }
        if (header != owner.Header || current != owner.CurrentContent)
            throw Invalid("The person authority differs from its exact complete native prefix.");
        owner.ReplayCut.Confirm(owner, digest);
        return facts;
    }
    internal static PersonHeader NextLegacy(Uuid tenant, Uuid person, PersonHeader? before, DomainEvent fact)
    {
        switch (fact)
        {
            case PersonRecorded value when before is null && value.TenantId == tenant && value.PersonId == person:
                RequireValues(tenant, person, value.DisplayName, value.WorkEmail, value.PersonalContact, value.Actor, value.ChangedAt);
                return new(tenant, person, 1, null, value.Actor, value.ChangedAt);
            case PersonRevised value when before is not null && value.TenantId == tenant && value.PersonId == person && value.Revision == before.Revision + 1:
                RequireValues(tenant, person, value.DisplayName, value.WorkEmail, value.PersonalContact, value.Actor, value.ChangedAt);
                return before with { Revision = value.Revision, LastChangedBy = value.Actor, LastChangedAt = value.ChangedAt };
            case PersonMembershipCorrelated value when before is not null && value.TenantId == tenant && value.PersonId == person &&
                value.Revision == before.Revision + 1 && value.UserId != Uuid.Empty && value.UserId != before.CorrelatedUserId && value.Actor is not null && value.ChangedAt != default:
                return before with { Revision = value.Revision, CorrelatedUserId = value.UserId, LastChangedBy = value.Actor, LastChangedAt = value.ChangedAt };
            default: throw Invalid("The read-only legacy person source has another identity, revision or values transition.");
        }
    }
    internal static PersonHeader NextNative(Uuid tenant, Uuid person, EventStreamAddress stream, PersonHeader? before, DomainEvent fact)
    {
        if (fact is not IPersonNativeFact native || native.Header is not { } header || header.TenantId != tenant || header.PersonId != person ||
            header.CorrelatedUserId == Uuid.Empty || native.FirstResponse is null || native.OperationResult is null ||
            !PersonContent.Reference(native.Content, PersonContent.ViewSchema) || !PersonContent.Reference(native.Change, PersonContent.ChangeSchema) ||
            !PersonContent.Reference(native.FirstResponse, FirstResponses.Schema) || !PersonContent.Reference(native.OperationResult, "mutation-result-content.v1"))
            throw Invalid("The native person fact has another bounded source identity or immutable content reference.");
        var command = fact switch
        {
            PersonRegistrationRecorded => nameof(RecordPerson),
            PersonDetailsRevised => nameof(RevisePerson),
            PersonMembershipCorrelationRecorded => nameof(CorrelatePersonMembership),
            _ => throw Invalid("Another native person transition kind."),
        };
        if (native.Operation.Owner != stream || !NativeOwnerHistory.IsOwnRoot(new Person(tenant, person), native.Operation, command,
                command == nameof(RecordPerson) ? null : (ulong?)before?.Revision) ||
            command == nameof(RecordPerson) && (before is not null || native.Operation.LogicalId != person || !native.Changed || header.Revision != 1 || header.CorrelatedUserId is not null) ||
            command != nameof(RecordPerson) && (before is null || header.Revision != before.Revision + (native.Changed ? 1 : 0)) ||
            command == nameof(RevisePerson) && (!native.Changed || header.CorrelatedUserId != before!.CorrelatedUserId) ||
            command == nameof(CorrelatePersonMembership) && native.Changed == (header.CorrelatedUserId == before!.CorrelatedUserId) ||
            native.Changed && (header.LastChangedBy != native.Operation.Actor || header.LastChangedAt != native.Operation.AcceptedAt) ||
            !native.Changed && header != before)
            throw Invalid("The native person fact differs from its exact original root, revision or correlation transition.");
        return header;
    }
    static void RequireValues(Uuid tenant, Uuid person, string name, string? email, PersonalContactDetails? contact,
        ActorReference actor, DateTimeOffset at)
    {
        var rules = new PersonRules(tenant, person);
        if (actor is null || at == default || !rules.Record(name, email, contact, actor, at).IsSuccess ||
            rules.Current!.DisplayName != name || rules.Current.WorkEmail != email || rules.Current.PersonalContact != contact)
            throw Invalid("The legacy person values are not the original normalized source values.");
    }
    static ImmutableContentIntegrityException Invalid(string message) => new(message);
}
''')
write(s+'PersonAggregateReader.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Finalizes full raw prefix validation for direct reads and executor hydration, without old body reads.</summary>
public sealed class PersonAggregateReader(IAggregateReader inner, IDomainEventReader events) : IAggregateReader
{
    public async ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate, CancellationToken ct = default) where TAggregate : Aggregate
    {
        var hydrated = await inner.HydrateAsync(aggregate, ct).ConfigureAwait(false);
        if (hydrated is Person person) _ = await PersonHistory.ReadAsync(person, events, ct).ConfigureAwait(false);
        return hydrated;
    }
}
''')
write(s+'PersonContent.cs','''using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

public static class PersonContent
{
    public const string ViewSchema = "person-values.v1";
    public const string ChangeSchema = "person-native-change.v1";
    public const string RegistrationSchema = "person-registration.v1";
    public static PersonHeader Header(PersonView value) => new(value.TenantId, value.PersonId, value.Revision,
        value.CorrelatedUserId, value.LastChangedBy, value.LastChangedAt);
    public static async Task<PersonPrepared> FreezeAsync(IImmutableContentStore store, PersonReadSnapshot before,
        PersonRules after, OperationProvenance operation, CancellationToken ct = default)
    {
        var view = after.Current ?? throw new ImmutableContentIntegrityException("The person mutation has no resulting values.");
        var changed = after.PendingEvents.Count != 0;
        var body = await NativeContent.WriteAsync(store, before.Owner.TenantId, ViewSchema, view, ct).ConfigureAwait(false);
        var mutation = new PersonChangeContent(before.Owner.Header, before.Owner.CurrentContent, Header(view), body, operation.CommandKind, changed);
        var change = await NativeContent.WriteAsync(store, before.Owner.TenantId, ChangeSchema, mutation, ct).ConfigureAwait(false);
        var frozen = operation.CommandKind == nameof(RecordPerson)
            ? await NativeContent.FreezeAsync(store, before.Owner.TenantId, RegistrationSchema, new PersonRegistration(before.Owner.Id), ct).ConfigureAwait(false)
            : await NativeContent.FreezeUnitAsync(store, before.Owner.TenantId, ct).ConfigureAwait(false);
        var prepared = new PersonPrepared(before.Owner.Version, before.Owner.CommittedStreamPosition, before.Owner.ReplayCut.Digest,
            before.Owner.Header, before.Owner.CurrentContent, view, body, mutation, change, changed, frozen.Response, frozen.Result);
        if (!Verify(prepared, operation)) throw new ImmutableContentIntegrityException("The person mutation does not match its exact prepared source values.");
        return prepared;
    }
    public static bool Verify(PersonPrepared value, OperationProvenance operation) =>
        value.Mutation.Before == value.Before && value.Mutation.BeforeContent == value.BeforeContent &&
        value.Mutation.After == Header(value.View) && value.Mutation.Content == value.Content && value.Mutation.CommandKind == operation.CommandKind &&
        value.Mutation.Changed == value.Changed && Matches(value.Content, value.View, ViewSchema) && Matches(value.Change, value.Mutation, ChangeSchema) &&
        value.View.SourceKind == "manual" && !value.View.RestrictedFieldsRedacted && value.Response.StatusCode == 200 &&
        value.Response.ResultSchema == (operation.CommandKind == nameof(RecordPerson) ? RegistrationSchema : UnitResult.Schema) &&
        Matches(value.Result, new MutationResultContent(value.Response.ResultSchema, value.Response.Body), "mutation-result-content.v1");
    public static DomainEvent Fact(PersonPrepared value, OperationProvenance operation, ImmutableContentRef frozen) => operation.CommandKind switch
    {
        nameof(RecordPerson) => new PersonRegistrationRecorded(Header(value.View), value.Content, value.Change, value.Changed, operation, frozen, value.Result),
        nameof(RevisePerson) => new PersonDetailsRevised(Header(value.View), value.Content, value.Change, value.Changed, operation, frozen, value.Result),
        nameof(CorrelatePersonMembership) => new PersonMembershipCorrelationRecorded(Header(value.View), value.Content, value.Change, value.Changed, operation, frozen, value.Result),
        _ => throw new ImmutableContentIntegrityException("Another person native command kind."),
    };
    public static bool Reference(ImmutableContentRef? value, string schema) => value is not null && value.ContentId != Uuid.Empty &&
        value.Schema == schema && value.MediaType == ImmutableContentStoreExtensions.JsonMediaType && value.Bytes >= 0 &&
        value.Sha256 is { Length: 64 } && value.Sha256.All(Uri.IsHexDigit);
    public static bool Matches<T>(ImmutableContentRef reference, T value, string schema) where T : notnull
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(value, typeof(T), ComplianceCoreJsonContext.Default);
        return Reference(reference, schema) && reference.Bytes == bytes.LongLength && reference.Sha256 == ContentDigest.Sha256(bytes);
    }
}
''')
write(s+'PersonReader.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Verified current or exact historical producing values; never a projection or live replacement for a source version.</summary>
public sealed class PersonReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async Task<PersonReadSnapshot> ReadAsync(Uuid tenant, Uuid id, CancellationToken ct = default) =>
        await ReadAsync(await reader.HydrateAsync(new Person(tenant, id), ct).ConfigureAwait(false), ct).ConfigureAwait(false);
    public async Task<PersonReadSnapshot> ReadAsync(Person owner, CancellationToken ct = default)
    {
        var facts = await PersonHistory.ReadAsync(owner, events, ct).ConfigureAwait(false);
        if (!owner.IsCreated) return new(owner, null);
        var view = facts[^1] is IPersonNativeFact ? await ReadNativeAsync(facts, facts[^1], ct).ConfigureAwait(false) : Legacy(owner, facts);
        if (view is null || PersonContent.Header(view) != owner.Header)
            throw new ImmutableContentIntegrityException("The current person values differ from their exact native header.");
        return new(owner, view);
    }
    public async Task<PersonView> ReadFactAsync(DomainEvent fact, CancellationToken ct = default)
    {
        if (fact is not IPersonNativeFact native) throw new ImmutableContentIntegrityException("The source is not a native person fact.");
        var owner = await reader.HydrateAsync(new Person(native.Header.TenantId, native.Header.PersonId, native.Operation.LogicalId), ct).ConfigureAwait(false);
        var facts = await PersonHistory.ReadAsync(owner, events, ct).ConfigureAwait(false);
        var actual = facts.FirstOrDefault(value => value.Metadata.EventId == fact.Metadata.EventId);
        if (actual is null) throw new ImmutableContentUnavailableException("The exact producing person fact is not visible.");
        if (!actual.Equals(fact) || actual.Metadata != fact.Metadata)
            throw new ImmutableContentIntegrityException("The person producing source differs from actual payload/full metadata.");
        return await ReadNativeAsync(facts, actual, ct).ConfigureAwait(false);
    }
    async Task<PersonView> ReadNativeAsync(IReadOnlyList<DomainEvent> facts, DomainEvent fact, CancellationToken ct)
    {
        var native = (IPersonNativeFact)fact;
        var realm = native.Header.TenantId.ToString();
        var view = await content.ReadJsonAsync<PersonView>(realm, native.Content, ct).ConfigureAwait(false);
        var mutation = await content.ReadJsonAsync<PersonChangeContent>(realm, native.Change, ct).ConfigureAwait(false);
        var index = facts.ToList().IndexOf(fact);
        PersonHeader? before = null;
        Bdgrz.Compliance.Features.Proofs.ImmutableContentRef? prior = null;
        foreach (var value in facts.Take(index))
        {
            if (value is IPersonNativeFact previous) { before = previous.Header; prior = previous.Content; }
            else before = PersonHistory.NextLegacy(native.Header.TenantId, native.Header.PersonId, before, value);
        }
        if (mutation.Before != before || mutation.BeforeContent != prior || mutation.After != native.Header || mutation.Content != native.Content ||
            mutation.CommandKind != native.Operation.CommandKind || mutation.Changed != native.Changed || PersonContent.Header(view) != native.Header ||
            view.SourceKind != "manual" || view.RestrictedFieldsRedacted)
            throw new ImmutableContentIntegrityException("The immutable person body/mutation differs from its exact producing transition.");
        return view;
    }
    static PersonView? Legacy(Person owner, IReadOnlyList<DomainEvent> facts)
    {
        var rules = new PersonRules(owner.TenantId, owner.Id);
        foreach (var fact in facts) rules.Observe(fact);
        return rules.Current;
    }
}
''')
print('Prepared exact history, reader, content and installed prefix adapter.')
