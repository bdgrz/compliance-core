from pathlib import Path
import shutil
p=Path('/tmp/compliance-person-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def write(r,s):
 b=p/'base'/r;w=p/'work'/r
 if (repo/r).exists() and not b.exists():b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/r,b)
 w.parent.mkdir(parents=True,exist_ok=True);w.write_text(s)
c='src/Compliance.Common/Features/Workforce/';s='src/Compliance.Core/Features/Workforce/'
for name in ['RecordPerson','RevisePerson','CorrelatePersonMembership']:
 f=p/'work'/c/(name+'.cs');text=f.read_text().replace(', 1)]',', 2)]')
 if name=='RecordPerson':text=text.replace('RecordPerson(Uuid TenantId,','RecordPerson(Uuid PersonId, Uuid TenantId,').replace('IRequest<PersonRegistration>,','IRequest<PersonRegistration>, IIdentifiedRequest,');text=text.replace('ICallable;','ICallable\n{\n    public Uuid RequestId => PersonId;\n}')
 else:
  text=text.replace(name+'(Uuid TenantId,',name+'(Uuid CommandId, Uuid TenantId,').replace(': IRequest,',': IRequest<UnitResult>, IIdentifiedRequest,')
  text=text.replace('ICallable;','ICallable\n{\n    public Uuid RequestId => CommandId;\n}')
 write(c+name+'.cs',text)
write(c+'PersonHeader.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Bounded identity, revision and current correlation; private values remain verified immutable content.</summary>
public sealed record PersonHeader(Uuid TenantId, Uuid PersonId, long Revision, Uuid? CorrelatedUserId,
    ActorReference LastChangedBy, DateTimeOffset LastChangedAt);
''')
write(c+'IPersonNativeFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Workforce;

public interface IPersonNativeFact : INativeOperationFact
{
    PersonHeader Header { get; }
    ImmutableContentRef Content { get; }
    ImmutableContentRef Change { get; }
    ImmutableContentRef OperationResult { get; }
    bool Changed { get; }
}
''')
for name,tag in [('PersonRegistrationRecorded','recorded'),('PersonDetailsRevised','revised'),('PersonMembershipCorrelationRecorded','membership-correlated')]:
 write(c+name+'.cs',f'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Native identified person receipt; complete values and mutation proof are immutable content.</summary>
[Discriminator("bdgrz.workforce.person.{tag}", 2)]
public sealed record {name}(PersonHeader Header, ImmutableContentRef Content, ImmutableContentRef Change,
    bool Changed, OperationProvenance Operation, ImmutableContentRef FirstResponse, ImmutableContentRef OperationResult)
    : DomainEvent, IPersonNativeFact;
''')
# Keep the original domain behavior as a transient rules model, never an Aggregate or persisted writer.
old=(p/'base'/s/'Person.cs').read_text();start=old.index('    public Result<PersonRegistration> Record(');end=old.rindex('\n}')
methods=old[start:end]
head='''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Versioning;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Complete detached person values and pure rules; never native command authority.</summary>
public sealed class PersonRules
{
    readonly Uuid _tenantId;
    readonly List<DomainEvent> _pending = [];
    bool _created;
    long _revision;
    string? _initialDisplayName;
    string? _initialWorkEmail;
    PersonalContactDetails? _initialPersonalContact;
    PersonalContactDetails? _personalContact;
    Uuid? _correlatedUserId;
    public PersonRules(Uuid tenantId, Uuid personId, PersonView? current = null)
    {
        _tenantId = tenantId;
        Id = personId;
        Current = current;
        _created = current is not null;
        _revision = current?.Revision ?? 0;
        _correlatedUserId = current?.CorrelatedUserId;
        _personalContact = current?.PersonalContact;
        _initialDisplayName = current?.DisplayName;
        _initialWorkEmail = current?.WorkEmail;
        _initialPersonalContact = current?.PersonalContact;
    }
    public Uuid TenantId => _tenantId;
    public Uuid Id { get; }
    public EventStreamAddress Stream => new(_tenantId.ToString(), "people", Id.ToString());
    public bool IsCreated => _created;
    public long Revision => _revision;
    public Uuid? CorrelatedUserId => _correlatedUserId;
    public PersonView? Current { get; private set; }
    public IReadOnlyList<DomainEvent> PendingEvents => _pending;
    void RaiseEvent(DomainEvent value)
    {
        Observe(value);
        _pending.Add(value);
    }
    public void Observe(DomainEvent value)
    {
        switch (value)
        {
            case PersonRecorded ev:
                _created = true;
                _revision = 1;
                _initialDisplayName = ev.DisplayName;
                _initialWorkEmail = ev.WorkEmail;
                _initialPersonalContact = Normalize(ev.PersonalContact);
                _personalContact = _initialPersonalContact;
                Current = new PersonView(_tenantId, Id, 1, ev.DisplayName, ev.WorkEmail, "manual", ev.Actor, ev.ChangedAt,
                    PersonalContact: _personalContact);
                break;
            case PersonRevised ev:
                if (Current is null) throw new InvalidOperationException("The person revision has no creation.");
                _revision = ev.Revision;
                _personalContact = ev.PersonalContact;
                Current = Current with { Revision = ev.Revision, DisplayName = ev.DisplayName, WorkEmail = ev.WorkEmail,
                    PersonalContact = ev.PersonalContact, LastChangedBy = ev.Actor, LastChangedAt = ev.ChangedAt };
                break;
            case PersonMembershipCorrelated ev:
                if (Current is null) throw new InvalidOperationException("The person correlation has no creation.");
                _revision = ev.Revision;
                _correlatedUserId = ev.UserId;
                Current = Current with { Revision = ev.Revision, CorrelatedUserId = ev.UserId,
                    LastChangedBy = ev.Actor, LastChangedAt = ev.ChangedAt };
                break;
            default: throw new InvalidOperationException("Another person values mutation kind.");
        }
    }
'''
write(s+'PersonRules.cs',head+methods+'\n}\n')
write(s+'Person.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>One native person: bounded current header/reference and one selected receipt; full values/history are external.</summary>
public sealed class Person : Aggregate
{
    public Person(Uuid tenantId, Uuid personId, Uuid selectedLogicalId = default)
        : base(personId, new EventStreamAddress(tenantId.ToString(), "people", personId.ToString()))
    {
        TenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<PersonRecorded>(ObserveLegacy);
        On<PersonRevised>(ObserveLegacy);
        On<PersonMembershipCorrelated>(ObserveLegacy);
        On<PersonRegistrationRecorded>(ObserveNative);
        On<PersonDetailsRevised>(ObserveNative);
        On<PersonMembershipCorrelationRecorded>(ObserveNative);
    }
    public Uuid TenantId { get; }
    public NativeAcceptance Acceptance { get; }
    public PersonHeader? Header { get; private set; }
    public ImmutableContentRef? CurrentContent { get; private set; }
    public bool IsCreated => Header is not null;
    public long Revision => Header?.Revision ?? 0;
    public Uuid? CorrelatedUserId => Header?.CorrelatedUserId;
    internal FirmIndependenceReplayCut ReplayCut { get; } = new();
    public Result Append(PersonPrepared prepared, OperationProvenance operation, ImmutableContentRef frozen)
    {
        var ready = ReplayCut.Require(this, Acceptance, operation);
        if (!ready.IsSuccess) return ready;
        if (prepared.Version != Version || prepared.Position != CommittedStreamPosition || prepared.PrefixSha256 != ReplayCut.Digest ||
            prepared.Before != Header || prepared.BeforeContent != CurrentContent || !PersonContent.Verify(prepared, operation))
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The exact prepared person values or native prefix changed.", true));
        RaiseEvent(PersonContent.Fact(prepared, operation, frozen));
        return Result.Success;
    }
    void ObserveLegacy(DomainEvent fact)
    {
        if (CurrentContent is not null)
            throw new ImmutableContentIntegrityException("A read-only legacy person fact cannot follow native content authority.");
        Header = PersonHistory.NextLegacy(TenantId, Id, Header, fact);
    }
    void ObserveNative<T>(T value) where T : DomainEvent, IPersonNativeFact
    {
        Header = PersonHistory.NextNative(TenantId, Id, Stream, Header, value);
        CurrentContent = value.Content;
        Acceptance.Observe(value);
    }
    protected override void Apply(DomainEvent ev)
    {
        if (!ev.Metadata.IsAudit) ReplayCut.Observe(ev);
        base.Apply(ev);
    }
}
''')
write(s+'PersonChangeContent.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Exact producing native transition and prior values; historical bodies are never selected from live current state.</summary>
public sealed record PersonChangeContent(PersonHeader? Before, ImmutableContentRef? BeforeContent,
    PersonHeader After, ImmutableContentRef Content, string CommandKind, bool Changed);
''')
write(s+'PersonPrepared.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Workforce;

public sealed record PersonPrepared(ulong Version, ulong Position, string PrefixSha256,
    PersonHeader? Before, ImmutableContentRef? BeforeContent, PersonView View, ImmutableContentRef Content,
    PersonChangeContent Mutation, ImmutableContentRef Change, bool Changed,
    FirstResponseDescriptor Response, ImmutableContentRef Result);
''')
write(s+'PersonReadSnapshot.cs','''namespace Bdgrz.Compliance.Features.Workforce;

/// <summary>Explicit verified person values at one exact owner cut.</summary>
public sealed record PersonReadSnapshot(Person Owner, PersonView? View)
{
    public PersonRules Rules => new(Owner.TenantId, Owner.Id, View);
}
''')
print('Prepared DTOs, native facts, compact owner and detached rules.')
