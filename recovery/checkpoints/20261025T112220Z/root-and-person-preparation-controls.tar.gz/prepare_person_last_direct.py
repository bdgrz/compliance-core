exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
def edit(r,fn):
 f=p/'work'/r;text=f.read_text() if f.exists() else (repo/r).read_text();write(r,fn(text))
import re
r='test/Compliance.Tests/Features/Applications/ApplicationOwnerTests.cs'
def owner(text):
 for writer,var in [('scenario.Writer','person'),('scenario.Writer','foreignOwner'),('Writer','person')]:
  pattern=r'await '+re.escape(writer)+r'\.SaveAsync\('+var+r',\s*new RequestDispatchContext\(RequestActor.System\),\s*CancellationToken.None\);'
  provider='scenario._scope.ServiceProvider' if writer.startswith('scenario') else '_scope.ServiceProvider'
  text,n=re.subn(pattern,'await PersonSeeds.AppendAsync('+provider+', '+var+');',text)
  assert n==1,(writer,var,n)
 return text
edit(r,owner)
r='test/Compliance.Tests/Features/TechnologyInventory/InventoryRetryTests.cs';edit(r,lambda text:text.replace('ActorReference.ForMember(Uuid.CreateVersion4(), "Author"), DateTimeOffset.UtcNow);','ActorReference.ForMember(Uuid.CreateVersion4(), "Seed"), Now);'))
r='test/Compliance.Tests/Features/AccessControl/InventoryManagementIndependenceTests.cs'
def independence(text):
 a=text.index('            var person = await Executor.ExecuteAsync(new Person(Tenant, PersonId), source =>')
 b=text.index('\n            Assert.True(person.IsSuccess);',a)
 text=text[:a]+'''            var rules = new PersonRules(Tenant, PersonId);
            var person = rules.Record("Synthetic owner", null,
                ActorReference.ForMember(RbacIds.Member(Tenant, _administrator), "Client administrator"), DateTimeOffset.UtcNow);
            await PersonSeeds.AppendAsync(_scope.ServiceProvider, rules);'''+text[b:]
 return text
edit(r,independence)
r='test/Compliance.Tests/Features/NamedRecords/NamedRecordTransportTests.cs'
def named(text):
 a=text.index('        var result = await scope.ServiceProvider.GetRequiredService<IAggregateExecutor>().ExecuteAsync(',text.index('static async Task<Uuid> SeedOwnerAsync'))
 b=text.index('\n        Assert.True(result.IsSuccess, result.Error?.Message);',a)
 text=text[:a]+'''        var rules = new PersonRules(tenant, owner);
        var result = rules.Record("Owner", null, ActorReference.ForMember(Uuid.CreateVersion4(), "Seed"), DateTimeOffset.UtcNow);
        await PersonSeeds.AppendAsync(scope.ServiceProvider, rules);'''+text[b:]
 return text
edit(r,named)
r='test/Compliance.Tests/Features/PolicyDistribution/CampaignTransportTests.cs'
def campaign(text):
 a=text.index('        await ControlOperationE2ETests.SeedAsync(factory, new Person(')
 b=text.index('\n        return new Arranged',a)
 text=text[:a]+'''        await ProgramManagementServices.SeedAsync(factory.Services, new PersonRules(tenant, person), item =>
        {
            Assert.True(item.Record("Campaign member", null, actor, DateTimeOffset.UtcNow).IsSuccess);
            Assert.Null(item.CorrelateMembership(1, user, actor, DateTimeOffset.UtcNow));
            return Result.Success;
        });'''+text[b:]
 if 'using Bdgrz.Compliance.Tests.Testing;' not in text:text='using Bdgrz.Compliance.Tests.Testing;\n'+text
 return text
edit(r,campaign)
# Selected DTO constructor calls and canonical member fixture source.
r='test/Compliance.Tests/Features/Workforce/AttestWorkforceManagementWallTests.cs'
def wall(text):
 text=text.replace('new RecordPerson(TenantId,','new RecordPerson(Uuid.CreateVersion4(), TenantId,').replace('new RevisePerson(TenantId,','new RevisePerson(Uuid.CreateVersion4(), TenantId,').replace('new CorrelatePersonMembership(TenantId,','new CorrelatePersonMembership(Uuid.CreateVersion4(), TenantId,')
 text=text.replace('"person_revise" => BusAsync(', '"person_revise" => SendAsync(').replace('"person_correlate" => BusAsync(', '"person_correlate" => SendAsync(')
 needle='''            await ProgramManagementServices.SeedAsync(Provider, new PersonRules(TenantId, PersonId), person =>'''
 assert needle in text
 text=text.replace(needle,'''            await ProgramManagementServices.SeedAsync(Provider, new Member(TenantId, UserId), member => member.Register());
'''+needle)
 text=text.replace('record.Event is PersonRecorded or PersonRevised or PersonMembershipCorrelated or','record.Event is PersonRecorded or PersonRevised or PersonMembershipCorrelated or PersonRegistrationRecorded or PersonDetailsRevised or PersonMembershipCorrelationRecorded or')
 return text
edit(r,wall)
r='test/Compliance.Tests/Features/Workforce/WorkforceAuthorizerTests.cs';edit(r,lambda text:text.replace('new RecordPerson(tenantId,','new RecordPerson(Uuid.CreateVersion4(), tenantId,'))
# Existing bare roster harness owns explicit immutable content now needed by verified owning GET.
r='test/Compliance.Tests/Features/Workforce/WorkforceRosterSnapshotTests.cs'
def roster(text):
 if 'using Bdgrz.Compliance.Features.Content;' not in text:text='using Bdgrz.Compliance.Features.Content;\n'+text
 text=text.replace('            services.AddPortia();','            services.AddPortia();\n            services.AddPersonNativeFixtures();')
 text=text.replace('new PersonReadConsistency(_people, Reader, events)','new PersonReadConsistency(_people, Reader, events, _provider.GetRequiredService<IImmutableContentStore>())')
 return text
edit(r,roster)
print('Prepared remaining direct seeds, all3 DTO callsites, canonical wall membership and owning source consistency fixture.')
