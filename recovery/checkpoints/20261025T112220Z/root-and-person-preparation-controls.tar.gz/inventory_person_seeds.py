from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
q=Parser(Language(tree_sitter_c_sharp.language()));repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');rows=[]
for f in (repo/'test').rglob('*.cs'):
 data=f.read_bytes();todo=[q.parse(data).root_node]
 while todo:
  n=todo.pop();todo.extend(n.children)
  if n.type!='object_creation_expression':continue
  t=n.child_by_field_name('type')
  if not t or data[t.start_byte:t.end_byte]!=b'Person':continue
  a=n.parent;chain=[]
  while a and len(chain)<7:
   if a.type in ['invocation_expression','local_declaration_statement','return_statement','method_declaration','assignment_expression','field_declaration']:
    chain.append({'type':a.type,'text':data[a.start_byte:min(a.end_byte,a.start_byte+180)].decode()})
   a=a.parent
  rows.append({'path':str(f.relative_to(repo)),'line':n.start_point[0]+1,'start':n.start_byte,'end':n.end_byte,'parents':chain})
Path('/tmp/compliance-person-native-prepared/test-person-callsites.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 print(row['path']+':'+str(row['line'])+' '+(row['parents'][0]['text'].replace('\n',' ') if row['parents'] else 'none'))
