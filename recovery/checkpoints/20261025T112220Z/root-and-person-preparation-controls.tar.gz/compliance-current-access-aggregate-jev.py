import json,os,subprocess,urllib.request
from pathlib import Path
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core'); out=Path('/tmp/compliance-full-boundary-audit-20261023'); key=os.environ['TYPESAFE_API_KEY']
audit=json.load(open(root/'docs/product/audits/2026-10-22/audit.json'))
rows=[]
for name in ['AccessGrant','Member','RolePermission','TeamMember','TeamRole','PlatformOperatorRoster','UserIdentity']:
 a=next(x for x in audit['aggregates'] if x['name']==name)
 rel=a['sourceFiles'][0]; code=(root/rel).read_text()
 test_files=[]
 for p in (root/'test/Compliance.Tests').rglob('*.cs'):
  try: t=p.read_text()
  except: continue
  if name in t: test_files.append({'path':str(p.relative_to(root)),'lines':t.count('\n')+1})
 rows.append({'name':name,'currentSource':rel,'currentSourceCode':code,'previousInvariantReview':a.get('invariant'),'currentBoundaryRecommendation':a.get('disposition'),'priorFindings':a.get('findingIds'),'testReferences':test_files[:12]})
questions={}
for i,r in enumerate(rows):
 questions[f'{i:02d}_{r["name"]}']={'type':'noul','instructions':f"Considering the current source code for {r['name']} and the prior invariant review, is its aggregate boundary itself materially wrong or unproven? Focus on whether it combines independently changing lifecycles or splits an invariant that must be atomic; distinguish these boundary problems from command/retry/reactor implementation gaps that can be repaired without changing this aggregate boundary.",'criteria':{'yes':'Current code gives concrete evidence of a wrongly placed owner or a necessary aggregate-boundary proof missing.','no':'The current owner is appropriate for its atomic invariant; remaining defects are command, identity, authorization, or reactor recovery implementation gaps.'}}
payload={'model':'jev-latest','state':{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'rows':rows},'questions':questions}
rq=out/'current-access-aggregates-request.json'; rs=out/'current-access-aggregates-response.json'; rq.write_text(json.dumps(payload,separators=(',',':'))+'\n')
req=urllib.request.Request('https://api.typesafe.ai/v1/systemone',data=rq.read_bytes(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
with urllib.request.urlopen(req,timeout=90) as response: result=json.load(response)
rs.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'model':result.get('model'),'usage':result.get('usage'),'answers':result.get('answers')}))
