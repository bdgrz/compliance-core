#!/usr/bin/env python3
"""Merge unmerged JSON files from git stages 1/2/3 without staging them.

Usage: python3 /tmp/compliance-merge-json-conflicts.py [--repo PATH] FILE ...
       --dry-run reports planned writes; --stdout emits one merged document.

Stable keyed rows are merged recursively. Nonunique/unknown identities fall back
to exact-value membership merging, preserving distinct objects instead of
silently coalescing them. Genuine scalar/delete-versus-edit conflicts prefer
incoming (stage 3). Named numeric counts combine both changes from stage 1.
"""

import argparse
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile


MISSING = object()


def equal(left, right):
    if left is MISSING or right is MISSING:
        return left is right
    return left == right


def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def count_path(path):
    if not path:
        return False
    leaf = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", str(path[-1])).lower()
    words = set(re.split(r"[^a-z0-9]+", leaf))
    if words.intersection({"version", "revision", "index", "epoch", "timestamp"}):
        return False
    if words.intersection({"count", "counts", "total", "totals"}):
        return True
    return any(str(part).lower() in {"counts", "totals", "statistics", "stats"} for part in path[:-1])


def token(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def row_key(fields, row):
    return tuple(token(row[field]) for field in fields)


def key_is_safe(fields, groups):
    for rows in groups:
        seen = set()
        for row in rows:
            if not isinstance(row, dict) or any(field not in row for field in fields):
                return False
            if any(isinstance(row[field], (dict, list)) or row[field] is None for field in fields):
                return False
            identity = row_key(fields, row)
            if identity in seen:
                return False
            seen.add(identity)
    return True


def stable_key(path, groups):
    label = str(path[-1]) if path else ""
    if label == "unwiredAggregateProducers":
        fields = ("fact", "aggregate", "method")
        return fields if key_is_safe(fields, groups) else None
    preferred = {
        "facts": [("fact",)],
        "aggregates": [("aggregate",)],
        "requests": [("request",)],
        "applicationAdapters": [("request",)],
        "factReplayGuards": [("fact", "aggregate")],
        "commands": [("command",)],
        "events": [("event",)],
        "reactors": [("reactor",)],
        "processes": [("process",)],
        "receivers": [("receiver",)],
        "stages": [("stage",)],
    }.get(label, [])
    candidates = preferred + [
        ("id",), ("qualifiedName",), ("request",), ("aggregate",),
        ("fact",), ("reactor",), ("process",), ("receiver",),
        ("command",), ("event",), ("name",), ("key",),
    ]
    for fields in candidates:
        if key_is_safe(fields, groups):
            return fields
    return None


def ordered_unique(values):
    seen = set()
    for value in values:
        if value not in seen:
            seen.add(value)
            yield value


def merge_list(base, ours, theirs, path):
    groups = [base, ours, theirs]
    fields = stable_key(path, groups)
    if fields:
        maps = [{row_key(fields, row): row for row in rows} for rows in groups]
        order = ordered_unique(list(maps[1]) + list(maps[2]) + list(maps[0]))
        result = []
        for identity in order:
            row = merge(*(mapping.get(identity, MISSING) for mapping in maps), path + (str(identity),))
            if row is not MISSING:
                result.append(row)
        return result
    # Exact identity avoids collapsing objects whose apparent keys are duplicated.
    maps = [{token(row): row for row in rows} for rows in groups]
    order = ordered_unique(list(maps[1]) + list(maps[2]) + list(maps[0]))
    result = []
    for identity in order:
        present = merge(*(identity in mapping for mapping in maps), path + ("membership",))
        if present:
            result.append(maps[2].get(identity, maps[1].get(identity, maps[0].get(identity))))
    return result


def merge(base, ours, theirs, path=()):
    # Count additions can be independent even when the resulting counts match.
    if (all(numeric(value) for value in (base, ours, theirs)) and count_path(path)
            and not equal(base, ours) and not equal(base, theirs)):
        return ours + theirs - base
    if equal(ours, theirs):
        return ours
    if equal(ours, base):
        return theirs
    if equal(theirs, base):
        return ours
    if ours is MISSING or theirs is MISSING:
        return theirs
    if isinstance(ours, dict) and isinstance(theirs, dict) and (base is MISSING or isinstance(base, dict)):
        original = {} if base is MISSING else base
        result = {}
        for key in ordered_unique(list(ours) + list(theirs) + list(original)):
            value = merge(original.get(key, MISSING), ours.get(key, MISSING), theirs.get(key, MISSING), path + (key,))
            if value is not MISSING:
                result[key] = value
        return result
    if isinstance(ours, list) and isinstance(theirs, list) and (base is MISSING or isinstance(base, list)):
        return merge_list([] if base is MISSING else base, ours, theirs, path)
    return theirs


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], text=True, capture_output=True)


def read_stage(repo, stage, relative):
    result = git(repo, "show", ":{}:{}".format(stage, relative))
    if result.returncode:
        return MISSING
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError as error:
        raise ValueError("{} stage {} is invalid JSON: {}".format(relative, stage, error))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default=".")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--stdout", action="store_true")
    parser.add_argument("files", nargs="+")
    args = parser.parse_args()
    if args.stdout and len(args.files) != 1:
        parser.error("--stdout requires exactly one file")
    result = git(args.repo, "rev-parse", "--show-toplevel")
    if result.returncode:
        parser.error(result.stderr.strip())
    repo = Path(result.stdout.strip()).resolve()
    planned = []
    for filename in args.files:
        candidate = Path(filename)
        absolute = candidate.resolve() if candidate.is_absolute() else (Path(args.repo) / candidate).resolve()
        try:
            relative = absolute.relative_to(repo).as_posix()
        except ValueError:
            parser.error("file is outside repository: {}".format(filename))
        if not git(repo, "ls-files", "--unmerged", "--", relative).stdout:
            parser.error("file has no unmerged index stages: {}".format(relative))
        merged = merge(*(read_stage(repo, stage, relative) for stage in (1, 2, 3)))
        if merged is MISSING:
            parser.error("merge chooses deletion for {}; handle deletion explicitly".format(relative))
        output = json.dumps(merged, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
        planned.append((absolute, relative, output))
    if args.stdout:
        sys.stdout.write(planned[0][2])
        return
    for absolute, relative, output in planned:
        if args.dry_run:
            print("would merge {} ({} bytes)".format(relative, len(output.encode("utf-8"))))
            continue
        mode = stat.S_IMODE(absolute.stat().st_mode) if absolute.exists() else 0o644
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", dir=str(absolute.parent), delete=False) as temporary:
            temporary.write(output)
            temporary_path = temporary.name
        os.chmod(temporary_path, mode)
        os.replace(temporary_path, absolute)
        print("merged {} (not staged)".format(relative))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        sys.exit(str(error))
