import sys,json,pathlib,subprocess,shutil
out=pathlib.Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
repo=pathlib.Path.cwd();conflicts=[];records={}
if (out/'composition.json').exists():
 records={r['path']:r for r in json.loads((out/'composition.json').read_text())['paths']}
for name in sys.argv[2:]:
 pkg=pathlib.Path(name)
 data=json.loads((pkg/('manifest.json' if (pkg/'manifest.json').exists() else 'handoff.json')).read_text())
 rows=data if isinstance(data,list) else data['paths']
 for row in rows:
  path=row if isinstance(row,str) else row['path']
  target=out/'work'/path
  base=pkg/'base'/path;after=pkg/'work'/path
  if not after.exists(): raise RuntimeError('Missing prepared source '+str(after))
  current=target if target.exists() else repo/path
  before=base.read_bytes() if base.exists() else b''
  old=current.read_bytes() if current.exists() else b''
  new=after.read_bytes()
  if path not in records:
   saved=out/'base'/path;saved.parent.mkdir(parents=True,exist_ok=True)
   if current.exists():saved.write_bytes(old)
   records[path]={'path':path,'existed':current.exists(),'packages':[]}
  records[path]['packages'].append(str(pkg))
  target.parent.mkdir(parents=True,exist_ok=True)
  if old in (before,new):target.write_bytes(new)
  elif new==before:target.write_bytes(old)
  else:
   temp=out/'merge';temp.mkdir(exist_ok=True)
   (temp/'current').write_bytes(old);(temp/'base').write_bytes(before);(temp/'incoming').write_bytes(new)
   r=subprocess.run(['git','merge-file','-p','--diff3',str(temp/'current'),str(temp/'base'),str(temp/'incoming')],capture_output=True)
   target.write_bytes(r.stdout)
   if r.returncode:conflicts.append({'path':path,'package':str(pkg),'code':r.returncode})
(out/'composition.json').write_text(json.dumps({'paths':list(records.values()),'conflicts':conflicts},indent=2)+'\n')
print(json.dumps({'paths':len(records),'conflicts':conflicts}))
