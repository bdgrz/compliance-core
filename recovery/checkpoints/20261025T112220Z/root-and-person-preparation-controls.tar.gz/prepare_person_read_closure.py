exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
f=p/'work'/s/'PersonReadConsistency.cs';text=f.read_text().replace('(minimumRevision is null || view.Revision >= minimumRevision))','(minimumRevision is null || view.Revision >= minimumRevision && source.Revision >= minimumRevision))');f.write_text(text)
f=p/'work'/s/'FitzPersonDirectory.cs';text=f.read_text().replace('var verified = await people.ReadFactAsync(domainEvent, ct).ConfigureAwait(false);','''var actual = await people.ReadFactAsync(domainEvent, ct).ConfigureAwait(false);
                // The directory is bounded discovery. Authorized detail reads load private values from the verified owner body.
                var verified = actual with { PersonalContact = null, RestrictedFieldsRedacted = true };''');text=text.replace('!native.Changed && prior != verified','!native.Changed && (prior with { PersonalContact = null, RestrictedFieldsRedacted = true }) != verified').replace('if (native.Changed)\n                        await PersonDirectorySchema.People.ReplaceAsync','if (prior != verified)\n                        await PersonDirectorySchema.People.ReplaceAsync');f.write_text(text)
r=s+'ListPeopleHandler.cs';text=(repo/r).read_text();text=text.replace('var ready = await consistency.EnsureListCaughtUpAsync','var ready = await consistency.CaptureListFenceAsync');a=text.index('        return page.Items.Any(');text=text[:a]+'''        if (page.Items.Any(item => item.TenantId != request.TenantId))
            return Result<Page<PersonView>>.Failure(new RequestError(RequestErrorKind.NotFound, "The people were not found."));
        var verified = new List<PersonView>();
        foreach (var item in page.Items)
        {
            var source = await consistency.GetAsync(request.TenantId, item.PersonId, item.Revision, ct).ConfigureAwait(false);
            if (!source.IsSuccess) return Result<Page<PersonView>>.Failure(source.Error!);
            verified.Add(source.Value with { PersonalContact = null, RestrictedFieldsRedacted = true });
        }
        var held = await consistency.EnsureFenceHeldAsync(request.TenantId, ready.Value, ct).ConfigureAwait(false);
        return held.IsSuccess
            ? Result<Page<PersonView>>.Success(new Page<PersonView>(verified, page.NextCursor))
            : Result<Page<PersonView>>.Failure(held.Error!);
    }
}
''';write(r,text)
r=s+'WorkforceRosterSnapshotter.cs';text=(repo/r).read_text();needle='''        // Fence: pages are read in separate transactions''';idx=text.index(needle);text=text[:idx]+'''        var verifiedRoster = new List<PersonView>();
        foreach (var person in roster)
        {
            if (person.TenantId != tenantId)
                return Result<SnapshotRegistration>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The roster projection returned content outside the tenant."));
            var source = await peopleConsistency.GetAsync(tenantId, person.PersonId, person.Revision, ct).ConfigureAwait(false);
            if (!source.IsSuccess) return Result<SnapshotRegistration>.Failure(source.Error!);
            verifiedRoster.Add(source.Value);
        }
'''+text[idx:];text=text.replace('WorkforceRosterSnapshotContent.Rows(roster, jobs)','WorkforceRosterSnapshotContent.Rows(verifiedRoster, jobs)');write(r,text)
# Existing roster fixtures now provide actual person source evidence for their projected identities.
r='test/Compliance.Tests/Features/Workforce/WorkforceRosterSnapshotTests.cs';f=p/'work'/r;text=f.read_text();needle='''        {
            await using (var batch = await _people.BeginAsync''';assert needle in text;text=text.replace(needle,'''        {
            var rows = people.ToArray();
            foreach (var person in rows)
            {
                var rules = new PersonRules(person.TenantId, person.PersonId);
                Assert.True(rules.Record(person.DisplayName, person.WorkEmail, person.PersonalContact,
                    person.LastChangedBy, person.LastChangedAt).IsSuccess);
                await PersonSeeds.AppendAsync(_provider, rules);
            }
            await using (var batch = await _people.BeginAsync''',1);text=text.replace('foreach (var person in people)\n                    await _people.ApplyAsync','foreach (var person in rows)\n                    await _people.ApplyAsync');f.write_text(text)
print('Prepared verified bounded Get/List/roster consumers, redacted native identity index and actual source-backed roster fixtures.')
