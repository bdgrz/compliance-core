from pathlib import Path
import json,shutil
root=Path.cwd();pkg=Path('/tmp/compliance-work-preference-native-prepared');base=pkg/'base';work=pkg/'work'
def save(path,source):
 p=work/path;p.parent.mkdir(parents=True,exist_ok=True)
 if (root/path).exists() and not (base/path).exists():q=base/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((root/path).read_bytes())
 p.write_text(source)
def current(path):return (root/path).read_text()
save('src/Compliance.Common/Features/Work/SetWorkDigestPreference.cs',current('src/Compliance.Common/Features/Work/SetWorkDigestPreference.cs').replace('digest_preference.set", 1','digest_preference.set", 2').replace('SetWorkDigestPreference(Uuid TenantId','SetWorkDigestPreference(Uuid CommandId, Uuid TenantId').replace('ITenantAccessRequest, ICallable;','ITenantAccessRequest, ICallable, IIdentifiedRequest\n{\n    public Uuid RequestId => CommandId;\n}'))
save('src/Compliance.Common/Features/Work/WorkDigestPreferenceRecorded.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>A member's authored preference receipt, including an accepted no-change decision.</summary>
[Discriminator("bdgrz.work.digest_preference.recorded", 1)]
public sealed record WorkDigestPreferenceRecorded(Uuid TenantId, Uuid MemberId,
    bool EmailDigestEnabled, string? AuthoredTimeZoneId, bool NoChange,
    WorkDigestPreferenceView Preference, OperationProvenance Operation,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult) : DomainEvent, INativeOperationFact;
''')
# The cut records actual immutable metadata, including the known prefix before emitted suffix stamping.
s=current('src/Compliance.Core/Features/Evidence/EvidenceRedactionReplayCut.cs').replace('namespace Bdgrz.Compliance.Features.Evidence;', 'namespace Bdgrz.Compliance.Features.Work;').replace('EvidenceRedactionReplayCut','WorkPreferenceReplayCut').replace('redaction','preference')
save('src/Compliance.Core/Features/Work/WorkPreferenceReplayCut.cs',s)
p='src/Compliance.Core/Features/Work/WorkDigestPreference.cs';s=current(p).replace('using Cntryl.Portia;', 'using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;\nusing Cntryl.Portia;').replace('    string _timeZoneId = "UTC";', '    string _timeZoneId = "UTC";\n    bool _emitting;\n    internal NativeAcceptance Acceptance { get; }\n    internal WorkPreferenceReplayCut ReplayCut { get; } = new();\n    internal Uuid TenantId => _tenantId;').replace('WorkDigestPreference(Uuid tenantId, Uuid memberId)','WorkDigestPreference(Uuid tenantId, Uuid memberId, Uuid commandId = default)').replace('        _tenantId = tenantId;', '        _tenantId = tenantId;\n        Acceptance = new NativeAcceptance(commandId);\n        On<WorkDigestPreferenceRecorded>(fact =>\n        {\n            var expected = Decide(Read(), fact.EmailDigestEnabled, fact.AuthoredTimeZoneId, fact.Operation.AcceptedAt);\n            if (fact.TenantId != _tenantId || fact.MemberId != Id || fact.Preference != expected ||\n                fact.NoChange != (expected == Read()))\n                throw new ImmutableContentIntegrityException("The preference receipt differs from its current scalar authority.");\n            Acceptance.Observe(fact);\n            (_emailDigestEnabled, _changedAt, _timeZoneId) = (expected.EmailDigestEnabled, expected.ChangedAt, expected.TimeZoneId);\n        });')
anchor='    /// <summary>Records a change; setting the current value again records nothing.</summary>'
s=s.replace(anchor,'''    internal static WorkDigestPreferenceView Decide(WorkDigestPreferenceView before, bool enabled, string? zone, DateTimeOffset at)
    {
        var normalized = zone is null ? before.TimeZoneId : WorkDigestSchedule.NormalizeTimeZoneId(zone);
        return before.EmailDigestEnabled == enabled && before.TimeZoneId == normalized ? before
            : new WorkDigestPreferenceView(enabled, at) { TimeZoneId = normalized };
    }

    internal Result Record(WorkDigestPreferenceRecorded fact, ulong preparedVersion, ulong preparedPosition)
    {
        var verified = ReplayCut.Require(this);
        if (!verified.IsSuccess)
            return verified;
        if (Version != preparedVersion || CommittedStreamPosition != preparedPosition ||
            Acceptance.SelectedLogicalId != fact.Operation.LogicalId || Acceptance.SelectedFact is not null ||
            !NativeOwnerHistory.IsOwnRoot(this, fact.Operation, nameof(SetWorkDigestPreference), null) ||
            fact.FirstResponse is null || fact.OperationResult is null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "Reload the exact current preference cut.", true));
        _emitting = true;
        try { RaiseEvent(fact); }
        finally { _emitting = false; }
        return Result.Success;
    }

    protected override void Apply(DomainEvent ev)
    {
        base.Apply(ev);
        ReplayCut.Observe(ev, _emitting);
    }

'''+anchor)
save(p,s)
save('src/Compliance.Core/Features/Work/WorkPreferenceAggregateReader.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>Checks the complete actual preference prefix before a read, retry or scalar append.</summary>
public sealed class WorkPreferenceAggregateReader(IAggregateReader inner, IDomainEventReader events) : IAggregateReader
{
    public async ValueTask<T> HydrateAsync<T>(T aggregate, CancellationToken ct = default) where T : Aggregate
    {
        var owner = await inner.HydrateAsync(aggregate, ct).ConfigureAwait(false);
        if (owner is not WorkDigestPreference preference)
            return owner;
        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, preference, ct).ConfigureAwait(false);
        var view = new WorkDigestPreferenceView(true, null) { TimeZoneId = "UTC" };
        var logical = new HashSet<Uuid>();
        var digest = WorkPreferenceReplayCut.Empty;
        var metadata = WorkPreferenceReplayCut.Empty;
        var known = WorkPreferenceReplayCut.Empty;
        var nativeStarted = false;
        foreach (var fact in facts)
        {
            digest = WorkPreferenceReplayCut.Append(digest, fact);
            metadata = WorkPreferenceReplayCut.Append(metadata, fact, true);
            if (fact.Metadata.AggregateVersion <= preference.ReplayCut.KnownThroughVersion)
                known = WorkPreferenceReplayCut.Append(known, fact, true);
            switch (fact)
            {
                case WorkDigestPreferenceChanged legacy when !nativeStarted:
                    if (legacy.TenantId != preference.TenantId || legacy.MemberId != preference.Id ||
                        !WorkDigestSchedule.IsValidTimeZone(legacy.TimeZoneId))
                        throw Invalid();
                    view = new WorkDigestPreferenceView(legacy.EmailDigestEnabled, legacy.ChangedAt)
                    { TimeZoneId = WorkDigestSchedule.NormalizeTimeZoneId(legacy.TimeZoneId) };
                    break;
                case WorkDigestPreferenceRecorded native:
                    nativeStarted = true;
                    if (native.TenantId != preference.TenantId || native.MemberId != preference.Id ||
                        !WorkDigestSchedule.IsValidTimeZone(native.AuthoredTimeZoneId) ||
                        !logical.Add(native.Operation.LogicalId) || native.Operation.Actor.Kind != "member" ||
                        native.Operation.Actor.Id != preference.Id.ToString() ||
                        !NativeOwnerHistory.IsOwnRoot(preference, native.Operation, nameof(SetWorkDigestPreference), null) ||
                        native.Operation.AuthoredIntentSha256 != AuthoredIntentDigest.Compute(new SetWorkDigestPreference(
                            native.Operation.LogicalId, preference.TenantId, native.EmailDigestEnabled, native.AuthoredTimeZoneId)) ||
                        native.FirstResponse is null || native.OperationResult is not { Schema: "mutation-result-content.v1" })
                        throw Invalid();
                    var next = WorkDigestPreference.Decide(view, native.EmailDigestEnabled, native.AuthoredTimeZoneId, native.Operation.AcceptedAt);
                    if (next != native.Preference || native.NoChange != (next == view))
                        throw Invalid();
                    if (native.Operation.LogicalId == preference.Acceptance.SelectedLogicalId &&
                        (preference.Acceptance.SelectedFact is not { } selected || !selected.Equals(native) || selected.Metadata != native.Metadata))
                        throw Invalid();
                    view = next;
                    break;
                default:
                    throw Invalid();
            }
        }
        if (view != preference.Read())
            throw Invalid();
        preference.ReplayCut.Confirm(preference, digest, metadata, known);
        return owner;
    }
    static ImmutableContentIntegrityException Invalid() => new("The preference differs from its complete actual owner prefix.");
}
''')
save('src/Compliance.Core/Features/Work/SetWorkDigestPreferenceHandler.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

/// <summary>Records and replays the acting member's own authored weekly digest preference.</summary>
public sealed class SetWorkDigestPreferenceHandler(NativeOperationExecutor operations, IAggregateReader reader,
    IImmutableContentStore content, TimeProvider clock) : IRequestHandler<SetWorkDigestPreference, WorkDigestPreferenceView>
{
    const string Schema = "work-digest-preference-view.v1";
    public async ValueTask<Result<WorkDigestPreferenceView>> HandleAsync(IRequestContext<SetWorkDigestPreference> context, CancellationToken ct)
    {
        var request = context.Request;
        if (request.CommandId == Uuid.Empty || request.TenantId == Uuid.Empty || !WorkDigestSchedule.IsValidTimeZone(request.TimeZoneId))
            return Result<WorkDigestPreferenceView>.Failure(new RequestError(RequestErrorKind.Validation,
                "A typed command, tenant and valid optional time_zone_id are required."));
        if (!UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var user))
            return Result<WorkDigestPreferenceView>.Failure(new RequestError(RequestErrorKind.Unauthorized, "A personal member identity is required."));
        var member = await reader.HydrateAsync(new Member(request.TenantId, user), ct).ConfigureAwait(false);
        if (!member.IsAccessEligibleOn(DateOnly.FromDateTime(clock.GetUtcNow().UtcDateTime)) || member.UserId != user || member.Affiliation == "firm_staff")
            return Result<WorkDigestPreferenceView>.Failure(new RequestError(RequestErrorKind.Forbidden, "Current active client membership is required."));
        var actor = ActorReference.ForMember(member.Id, UserIdentityClaims.BdgrzDisplay(context.Actor, user));
        var stream = new WorkDigestPreference(request.TenantId, member.Id).Stream;
        var operation = new OperationProvenance(request.CommandId, request.CommandId, null, nameof(SetWorkDigestPreference),
            actor, stream, RootOperation.InitialEpisode, null, AuthoredIntentDigest.Compute(request), clock.GetUtcNow(),
            stream, stream, FirstOwner: stream);
        WorkDigestPreferenceRecorded? prepared = null;
        ulong version = 0;
        ulong position = 0;
        try
        {
            var result = await operations.ExecuteAsync(new NativeOperation<WorkDigestPreference>(AcceptedOperationBinding.Of(operation),
                () => new WorkDigestPreference(request.TenantId, member.Id, request.CommandId), owner => owner.Acceptance,
                async (owner, token) =>
                {
                    var at = clock.GetUtcNow();
                    var view = WorkDigestPreference.Decide(owner.Read(), request.EmailDigestEnabled, request.TimeZoneId, at);
                    var body = await content.WriteJsonAsync(stream.Realm, Uuid.CreateVersion4(), Schema, view, token).ConfigureAwait(false);
                    var response = new FirstResponseDescriptor(200, ImmutableContentStoreExtensions.JsonMediaType, Schema, new StandardResponseBody(body));
                    var mutation = await content.WriteJsonAsync(stream.Realm, Uuid.CreateVersion4(), "mutation-result-content.v1",
                        new MutationResultContent(Schema, new StandardResponseBody(body)), token).ConfigureAwait(false);
                    (version, position) = (owner.Version, owner.CommittedStreamPosition);
                    prepared = new WorkDigestPreferenceRecorded(request.TenantId, member.Id, request.EmailDigestEnabled,
                        request.TimeZoneId, view == owner.Read(), view, operation with { AcceptedAt = at }, null, mutation);
                    return Result<FirstResponseDescriptor>.Success(response);
                }, (owner, first) => owner.Record((prepared ?? throw new InvalidOperationException("Missing prepared preference.")) with
                    { FirstResponse = first }, version, position)), context, ct).ConfigureAwait(false);
            return await IndependenceContent.ReadOutcomeAsync<WorkDigestPreferenceView>(content, stream.Realm, result, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<WorkDigestPreferenceView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The original preference receipt cannot be verified.", error is ImmutableContentUnavailableException));
        }
    }
}
''')
paths=sorted(str(p.relative_to(work)) for p in work.rglob('*') if p.is_file());(pkg/'manifest.json').write_text(json.dumps({'paths':paths,'status':'WIP_OFFLINE_NO_RUNTIME'},indent=2)+'\n');print('Preference offline source files',len(paths))
