exec(open('/tmp/prepare_person_core.py').read().split("for name in ['RecordPerson'")[0])
write('test/Compliance.Tests/Testing/PersonSeeds.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Workforce;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

/// <summary>Pure rule fixtures publish actual identified native facts; no legacy aggregate writer is retained.</summary>
static class PersonSeeds
{
    public static async Task AppendAsync(IAggregateReader reader, IAggregateWriter writer, IDomainEventReader events,
        IImmutableContentStore content, PersonRules source, CancellationToken ct = default)
    {
        foreach (var change in source.PendingEvents)
        {
            var logical = change is PersonRecorded ? source.Id : Uuid.CreateVersion4();
            var owner = await reader.HydrateAsync(new Person(source.TenantId, source.Id, logical), ct);
            var snapshot = await new PersonReader(reader, events, content).ReadAsync(owner, ct);
            var rules = snapshot.Rules;
            ActorReference actor;
            DateTimeOffset at;
            string kind;
            Result result;
            switch (change)
            {
                case PersonRecorded value:
                    actor = value.Actor; at = value.ChangedAt; kind = nameof(RecordPerson);
                    var created = rules.Record(value.DisplayName, value.WorkEmail, value.PersonalContact, actor, at);
                    result = created.IsSuccess ? Result.Success : Result.Failure(created.Error!);
                    break;
                case PersonRevised value:
                    actor = value.Actor; at = value.ChangedAt; kind = nameof(RevisePerson);
                    var revised = rules.Revise(value.Revision - 1, value.DisplayName, value.WorkEmail, value.PersonalContact, actor, at);
                    result = revised is null ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict, revised.Message!));
                    break;
                case PersonMembershipCorrelated value:
                    actor = value.Actor; at = value.ChangedAt; kind = nameof(CorrelatePersonMembership);
                    var correlated = rules.CorrelateMembership(value.Revision - 1, value.UserId, actor, at);
                    result = correlated is null ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict, correlated.Message!));
                    break;
                default: throw new InvalidOperationException("Another pure person fixture mutation.");
            }
            Assert.True(result.IsSuccess, result.Error?.Message);
            var operation = RootOperation.Provenance(logical, kind, owner.Stream, actor,
                change is PersonRecorded ? null : owner.Revision, AuthoredIntentDigest.Compute(change), at) with { FirstOwner = owner.Stream };
            var prepared = await PersonContent.FreezeAsync(content, snapshot, rules, operation, ct);
            var frozen = await FirstResponses.FreezeAsync(content, owner.Stream.Realm, prepared.Response, ct);
            var appended = owner.Append(prepared, operation, frozen);
            Assert.True(appended.IsSuccess, appended.Error?.Message);
            await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
        }
    }
}
''')
r='test/Compliance.Tests/Testing/ProgramManagementServices.cs';old=(repo/r).read_text();needle='    public static async Task SeedAsync<TAggregate>(IServiceProvider provider, TAggregate aggregate,';idx=old.index(needle);old=old[:idx]+'''    public static async Task SeedAsync(IServiceProvider provider, PersonRules selected, Func<PersonRules, Result> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var events = services.GetRequiredService<IDomainEventReader>();
        var content = services.GetRequiredService<IImmutableContentStore>();
        var rules = (await new PersonReader(reader, events, content).ReadAsync(selected.TenantId, selected.Id)).Rules;
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await PersonSeeds.AppendAsync(reader, services.GetRequiredService<IAggregateWriter>(), events, content, rules);
    }

    public static async Task SeedAsync<TOut>(IServiceProvider provider, PersonRules selected, Func<PersonRules, Result<TOut>> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var events = services.GetRequiredService<IDomainEventReader>();
        var content = services.GetRequiredService<IImmutableContentStore>();
        var rules = (await new PersonReader(reader, events, content).ReadAsync(selected.TenantId, selected.Id)).Rules;
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await PersonSeeds.AppendAsync(reader, services.GetRequiredService<IAggregateWriter>(), events, content, rules);
    }

    public static Task SeedAsync(IServiceProvider provider, PersonRules selected, Func<PersonRules, Bdgrz.Compliance.Features.Versioning.CommandFailure?> operation) =>
        SeedAsync(provider, selected, person =>
        {
            var failure = operation(person);
            return failure is null ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict, failure.Message!));
        });

'''+old[idx:]
if 'using Bdgrz.Compliance.Features.Workforce;' not in old:old='using Bdgrz.Compliance.Features.Workforce;\n'+old
write(r,old)
# Migrate constructor arguments for the shared explicit pure-rule seed overload only.
import json
rows=json.loads((p/'test-person-callsites.json').read_text());byfile={}
for row in rows:
 parent=row['parents'][0]['text'] if row['parents'] else ''
 if parent.startswith('ProgramManagementServices.SeedAsync'):
  byfile.setdefault(row['path'],[]).append(row)
for r,values in byfile.items():
 f=p/'work'/r;data=f.read_bytes() if f.exists() else (repo/r).read_bytes()
 # Source offsets refer to original current main; no prior edits except wall fixture copied unchanged.
 for row in sorted(values,key=lambda x:x['start'],reverse=True):
  assert data[row['start']:row['start']+10]==b'new Person',(r,row['line'])
  data=data[:row['start']]+data[row['start']:row['end']].replace(b'new Person(',b'new PersonRules(',1)+data[row['end']:]
 text=data.decode().replace('ProgramManagementServices.SeedAsync<Person, PersonRegistration>','ProgramManagementServices.SeedAsync')
 write(r,text)
print('Prepared native seed helper + shared overloads and migrated',len(byfile),'shared seed files.')
