using Bdgrz.Compliance.Features.Processes;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AccessControl;

/// <summary>
///     Starts <c>ClientIndependencePreviewProcess</c> from a committed evaluation admission. The process record, with
///     its frozen intent, exists before the source checkpoint advances; the sweep resumes it if this reactor stops.
/// </summary>
sealed partial class ClientIndependencePreviewReactor(IProjectionCheckpointStore checkpoints,
    ProcessRootReaction process)
    : Reactor(checkpoints, EventStreamPattern.ForTenant(ClientServiceIndependence.Area), WorkloadName),
        IReactorHandler<ClientIndependenceEvaluationAdmitted>
{
    public const string WorkloadName = "ClientIndependencePreviewV1";

    public async ValueTask HandleAsync(IReactorContext<ClientIndependenceEvaluationAdmitted> context,
        CancellationToken ct) => _ = await process.StartAsync(ClientIndependencePreviewEffects.ProcessName, context,
        context.Trigger.Intent, [], $"reactor:{WorkloadName}", ct).ConfigureAwait(false);
}
