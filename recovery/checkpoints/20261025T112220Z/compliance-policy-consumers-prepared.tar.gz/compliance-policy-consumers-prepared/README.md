# Policy native consumer/read cutover

Offline preparation only: no main edits, builds, runtime tests, Git mutations, GitHub writes or Jev calls. Parent owns actual RED/GREEN, strict analyzers, full unit/HTTP tests, final-file Jev and integration.

This consumer half is coordinated with the frozen55-file owner package at `/tmp/compliance-s32-policy-prepared/handoff.json`. No owner bytes were regenerated. The combined source/test candidate reconstructs exactly103 changed paths.

## Integration

1. Run the owner's three existing-API behavioral RED tests using its `tests.patch` and documented filter.
2. Apply owner implementation + owning migrated tests + its shared JSON and Program route patches.
3. Apply consumer `migrated-tests.patch`, `implementation-red.patch`, `shared-di.patch`. These are executable native consumers with the two previously missing result-boundary/cutoff behaviors absent. They contain no temporary throwing query stubs.
4. Apply `consumer-behavior.tests.patch`. Run the six new consumer cases (four methods): `PolicyNativeDirectoryReadTests`, `ShouldReturnTypedSourceFailureGivenUnreadableNativePolicy`, `ShouldExcludeLaterApprovalGivenExactRecordedThroughCutoff`. The cross-program cursor/isolation case is positive; the two unreadable-page rows, two unreadable-baseline rows and recorded-cutoff case demonstrate the missing behavior.
5. Apply `source-boundaries.patch` then `recorded-cutoff.patch`; rerun those cases plus existing consumer/read/projector tests. `reconstruction-audit.json` proves exact final bytes for this staged sequence.
6. Alternative one-step consumer apply: `tests.patch` + `implementation.patch` + `shared-di.patch`. Do not also apply the staged alternatives.

The source baseline includes frozen Control native consumers and the queued TypeII-close stage1 changes where relevant, followed by two actual Control integration test fixes. TypeII close stage1 must precede this package: the Policy baseline context overload uses its `RecordedThrough` field. The existing PolicyCommunication contributor's distinct effective-date and recorded-time cutoffs are retained. Its SnapshotSourceCapture.HashData hook and the PolicyTypeI contributor's same source-byte capture hook are retained.

`shared-di.patch` adds only PolicyReader and PolicyOperations registrations. Existing projector registrations already use their type constants, so the new projection names flow through those constants. Owner shared JSON/Program deltas remain separate. Apply patches, not whole older source snapshots, to retain parent's unrelated current changes.

## Final behavior

All outside consumers use PolicyReader/PolicyReadSnapshot, not a live Policy aggregate containing history. Within Policies, every existing scoped Get/List/version/decision/effective-version query and impact preview remains implemented. Bounded consumer result paths classify missing content as transient Conflict and corrupt content as permanent Conflict, catching only the expected immutable-content exception family. Projector/apply failures propagate so checkpoints cannot advance over failed content.

Policy discovery stores compact tenant/program/id/identifier/header/native-sequence rows at a new V2 route/checkpoint and composes current native source views per bounded page. Discarded identities remain compact tombstones so duplicate source replay cannot recreate or forget the terminal cut; they are hidden from returned pages. Retired policies remain listed. The directory never publishes stale projected content/status as current authority. Pages fail as a whole when any selected source is unreadable, and the existing stable caught-up source fence remains around list composition. Index cursors retain their tenant/program query binding.

The application reverse index freezes/reads exact Policy mutation bodies before applying the existing relationship rules, preserving malformed/out-of-order rollback tests using an explicit test-only native envelope factory. It uses V2 storage/checkpoint. Policy decision work uses V3 and reads actual native policy authority. Policy WorkQueueReader constructors and outside fixtures propagate PolicyReader explicitly while retaining prior ControlReader dependencies.

ProgramManagementServices gains test-only PolicyRules Seed/Hydrate overloads and real native services. PolicySeeds/PolicySourceFixture remain owned by the frozen owner package. Existing consumer tests keep their acceptance names and exercise actual native stores/readers or explicit malformed projection payloads; no production dual-read, aggregate `.Current` shim or manufactured accepted owner exists. The existing Policy version wire-roundtrip test now replays compact native facts and composes verified immutable source content.

Public creation tests and E2E routes carry the selected deterministic PolicyId; mutations gaining CommandId carry it. Actual Policy distribution E2E creation/review paths and MCP revision input were migrated. This is preparation, not an E2E pass claim.

No automatic persisted-v1 envelope migration or deployment qualification is claimed. No new external contract blocker was discovered in this consumer scope.
