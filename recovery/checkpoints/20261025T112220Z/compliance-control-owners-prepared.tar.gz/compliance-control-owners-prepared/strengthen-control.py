from pathlib import Path
p=Path('/tmp/compliance-control-owners-prepared/work/src/Compliance.Core/Features/Controls/ControlDraft.cs')
s=p.read_text().replace('OwnerProvenance.RequireOwn(this, fact.Operation.LogicalId, fact.Operation);','Require(fact.Operation is not null && fact.Operation.Actor is not null, "A native control mutation requires its operation and actor.");\n        OwnerProvenance.RequireOwn(this, fact.Operation.LogicalId, fact.Operation);')
s=s.replace('            return;\n        }\n        if (value is ControlDraftCreated', '            ValidateTransition(value, fact, actor);\n            return;\n        }\n        if (value is ControlDraftCreated',1)
s=s.replace('            throw new InvalidOperationException("A successor must preserve its deterministic line and exact approved predecessor.");','            throw new InvalidOperationException("A successor must preserve its deterministic line and exact approved predecessor.");\n        ValidateTransition(value, fact, actor);')
s=s.replace('new ResponsibilityRevoked(TenantId, assignment.AssignmentId, scope, revoked,\n                    assignment.RevokedByMemberId,', 'new ResponsibilityRevoked(TenantId, assignment.AssignmentId, scope, assignment.RevokedByMemberId,\n                    revoked,')
s=s.replace('            return set.AssignAuthorized(assigned.AssignmentId, assigned.MemberId, assigned.Type,', '            return supplied.Select(proof => proof.WaiverId).OrderBy(id => id.ToString(), StringComparer.Ordinal)\n                    .SequenceEqual(assigned.SeparationOfDutiesWaiverIds.OrderBy(id => id.ToString(), StringComparer.Ordinal)) &&\n                set.AssignAuthorized(assigned.AssignmentId, assigned.MemberId, assigned.Type,')
mark='    bool PreparedAuthority('
block='''    void ValidateTransition(DomainEvent value, IControlFact fact, Uuid actor)
    {
        var after = fact.Header;
        var member = value switch
        {
            ControlDraftCreated item => item.ActorMemberId,
            ControlDraftRevised item => item.ActorMemberId,
            ControlDraftDiscarded item => item.ActorMemberId,
            ControlReviewed item => item.ActorMemberId,
            ControlApproved item => item.ActorMemberId,
            ControlSuccessorProposed item => item.ActorMemberId,
            ControlRetirementProposed item => item.ActorMemberId,
            ControlRetired item => item.ActorMemberId,
            ControlProposalWithdrawn item => item.ActorMemberId,
            ControlOwnerPersonDesignated item => item.ActorMemberId,
            ResponsibilityAssigned item => item.AssignedByMemberId,
            ResponsibilityRevoked item => item.RevokedByMemberId,
            _ => Uuid.Empty,
        };
        Require(member == actor, "The original business actor differs from the native operation actor.");
        var logical = value switch
        {
            ControlReviewed item => item.DecisionId,
            ControlApproved item => item.ApprovalDecisionId,
            ControlRetired item => item.DecisionId,
            ControlProposalWithdrawn item => item.DecisionId,
            ControlOwnerPersonDesignated item => item.DesignationId,
            ResponsibilityAssigned item => item.AssignmentId,
            _ => fact.Operation.LogicalId,
        };
        Require(logical != Uuid.Empty && logical == fact.Operation.LogicalId,
            "The original business decision differs from the native logical identity.");
        if (value is ControlDraftCreated created)
        {
            var initial = new ControlAuthorityHeader(TenantId, created.ProgramId, Id, created.Identifier,
                1, true, true, false, false, true, ControlVersionIds.Initial(Id), ControlVersionIds.Initial(Id),
                null, null, member, null, null, null, created.ChangedAt, 0, null, null, false, false, after.Content);
            Require(fact.ChangeCount == 1 && after == initial && created.Identifier == NormalizeIdentifier(created.Identifier),
                "Creation requires the exact first local authority.");
            return;
        }
        var before = _header!;
        var expectedRevision = value is ControlSuccessorProposed or ControlRetirementProposed
            ? (ulong?)null : unchecked((ulong)before.Revision);
        Require(fact.Operation.OriginalExpectedRevision == expectedRevision,
            "The native operation must retain the original logical revision gate.");
        if (fact.ChangeCount == 0)
        {
            Require(value is ControlDraftRevised or ControlOwnerPersonDesignated or ResponsibilityAssigned or ResponsibilityRevoked &&
                before.IsVisible && !before.IsRetired && after == before,
                "Only a valid unchanged owner-local operation may accept without a business change.");
            return;
        }
        Require(before.IsVisible && !before.IsRetired, "Terminal control authority cannot change.");
        ControlAuthorityHeader expected;
        switch (value)
        {
            case ControlDraftRevised revised:
                Require(before.HasOpenDraft && revised.Revision == before.Revision + 1,
                    "Revision requires the exact open draft and next content revision.");
                expected = before with { Revision = revised.Revision, Content = after.Content,
                    PendingAuthorMemberId = actor, AcceptedReviewDecisionId = null, AcceptedReviewerMemberId = null,
                    LatestReviewDecisionId = null, PendingDecisionChangedAt = revised.ChangedAt };
                break;
            case ControlReviewed review:
                Require(before.PendingTargetId == review.VersionId && review.Revision == before.Revision &&
                    review.Outcome is "accept" or "request_changes" && Rationale(review.Rationale) &&
                    review.SupersedesDecisionId == before.LatestReviewDecisionId,
                    "Review must answer the current exact pending revision and latest decision.");
                expected = before with { EverReviewed = true, LatestReviewDecisionId = review.DecisionId,
                    AcceptedReviewDecisionId = review.Outcome == "accept" ? review.DecisionId : null,
                    AcceptedReviewerMemberId = review.Outcome == "accept" ? actor : null,
                    PendingDecisionChangedAt = review.DecidedAt };
                break;
            case ControlApproved approved:
                Require(before.HasOpenDraft && before.PendingTargetId == approved.VersionId &&
                    approved.Revision == before.Revision && before.AcceptedReviewDecisionId is not null &&
                    approved.AcceptedReviewDecisionId == before.AcceptedReviewDecisionId &&
                    approved.OwnerAssignmentId != Uuid.Empty && approved.EffectiveFrom != default && Rationale(approved.Rationale) &&
                    approved.PredecessorVersionId == before.ApprovedVersionId &&
                    (before.ApprovedVersionId is null || !string.IsNullOrWhiteSpace(approved.ImpactDigest) &&
                        approved.EffectiveFrom > before.ApprovedEffectiveFrom),
                    "Approval must preserve the exact reviewed draft, owner, predecessor and effective interval.");
                expected = before with { HasOpenDraft = false, IsApproved = true, PendingTargetId = null,
                    PendingAuthorMemberId = null, AcceptedReviewDecisionId = null, AcceptedReviewerMemberId = null,
                    PendingDecisionChangedAt = null, ApprovedVersionCount = before.ApprovedVersionCount + 1,
                    ApprovedVersionId = approved.VersionId, ApprovedEffectiveFrom = approved.EffectiveFrom };
                break;
            case ControlSuccessorProposed successor:
                Require(before.IsApproved && !before.HasOpenDraft && successor.Revision == before.Revision + 1 &&
                    successor.PredecessorVersionId == before.ApprovedVersionId &&
                    successor.VersionId == ControlVersionIds.Sequence(Id, before.ApprovedVersionCount + 1),
                    "A successor requires its exact approved predecessor and deterministic next version.");
                expected = before with { Revision = successor.Revision, Content = after.Content, HasOpenDraft = true,
                    DraftVersionId = successor.VersionId, PendingTargetId = successor.VersionId,
                    PendingRetirementId = null, PendingRetirementEffectiveUntil = null, PendingAuthorMemberId = actor,
                    AcceptedReviewDecisionId = null, AcceptedReviewerMemberId = null, LatestReviewDecisionId = null,
                    PendingDecisionChangedAt = successor.ChangedAt };
                break;
            case ControlRetirementProposed retirement:
                Require(before.IsApproved && !before.HasOpenDraft && before.PendingRetirementId is null &&
                    retirement.VersionId == before.ApprovedVersionId && retirement.Revision == before.Revision &&
                    retirement.RetirementId == ControlVersionIds.Retirement(Id, retirement.VersionId) &&
                    retirement.EffectiveUntil > before.ApprovedEffectiveFrom && Rationale(retirement.Rationale),
                    "Retirement requires the exact current version and a later exclusive effective end.");
                expected = before with { PendingTargetId = retirement.RetirementId,
                    PendingRetirementId = retirement.RetirementId, PendingRetirementEffectiveUntil = retirement.EffectiveUntil,
                    PendingAuthorMemberId = actor, AcceptedReviewDecisionId = null, AcceptedReviewerMemberId = null,
                    LatestReviewDecisionId = null, PendingDecisionChangedAt = retirement.ChangedAt };
                break;
            case ControlRetired retired:
                Require(before.PendingRetirementId == retired.RetirementId && before.PendingTargetId == retired.RetirementId &&
                    retired.VersionId == before.ApprovedVersionId && retired.Revision == before.Revision &&
                    before.AcceptedReviewDecisionId is not null && retired.AcceptedReviewDecisionId == before.AcceptedReviewDecisionId &&
                    retired.EffectiveUntil == before.PendingRetirementEffectiveUntil && Rationale(retired.Rationale) &&
                    !string.IsNullOrWhiteSpace(retired.ImpactDigest),
                    "Retirement approval must answer the exact reviewed proposal and frozen effective end.");
                expected = before with { IsRetired = true, PendingTargetId = null, PendingRetirementId = null,
                    PendingRetirementEffectiveUntil = null, PendingAuthorMemberId = null, AcceptedReviewDecisionId = null,
                    AcceptedReviewerMemberId = null, PendingDecisionChangedAt = null };
                break;
            case ControlProposalWithdrawn withdrawn:
                Require(before.IsApproved && before.PendingTargetId == withdrawn.TargetId &&
                    withdrawn.CurrentVersionId == before.ApprovedVersionId && withdrawn.Revision == before.Revision &&
                    withdrawn.Kind == (before.HasOpenDraft ? "successor" : "retirement") && Rationale(withdrawn.Rationale),
                    "Withdrawal must name the exact pending proposal and retained approved version.");
                expected = before with { Revision = before.Revision + 1, Content = after.Content, HasOpenDraft = false,
                    DraftVersionId = before.ApprovedVersionId!.Value, PendingTargetId = null,
                    PendingRetirementId = null, PendingRetirementEffectiveUntil = null, PendingAuthorMemberId = null,
                    AcceptedReviewDecisionId = null, AcceptedReviewerMemberId = null, LatestReviewDecisionId = null,
                    PendingDecisionChangedAt = null };
                break;
            case ControlOwnerPersonDesignated designated:
                Require(before.HasOpenDraft && designated.VersionId == before.DraftVersionId && designated.Revision == before.Revision &&
                    designated.PersonId != Uuid.Empty && (designated.PersonId is not null || designated.CorrelatedMemberId is null) &&
                    Rationale(designated.Rationale), "Person designation requires the exact open draft revision and original intent.");
                expected = before;
                break;
            case ResponsibilityAssigned assigned:
                Require(IsCurrentResponsibilityScope(assigned.Scope), "Assignment requires the exact current pending scope.");
                expected = before with { ResponsibilityEverAssigned = true };
                break;
            case ResponsibilityRevoked revoked:
                Require(IsCurrentResponsibilityScope(revoked.Scope), "Revocation requires the exact current pending scope.");
                expected = before;
                break;
            case ControlDraftDiscarded discarded:
                Require(before.HasOpenDraft && !before.IsApproved && !before.EverReviewed && !before.ResponsibilityEverAssigned &&
                    discarded.Revision == before.Revision && !string.IsNullOrWhiteSpace(discarded.Rationale),
                    "Discard requires an unused, unreviewed, unapproved initial draft.");
                expected = before with { IsVisible = false, HasOpenDraft = false, PendingTargetId = null,
                    PendingAuthorMemberId = null, PendingDecisionChangedAt = null };
                break;
            default:
                throw new InvalidOperationException("The native control transition is not selected.");
        }
        Require(after == expected, "The native control header differs from its exact local business transition.");
    }

    static bool Rationale(string? value) => !string.IsNullOrWhiteSpace(value) && value.Length <= 4000;

'''
s=s.replace(mark,block+mark)
p.write_text(s)
