using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Responsibilities;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Controls;

/// <summary>One deterministic control identity and compact current authority; full bodies/history never enter command state.</summary>
public sealed class ControlDraft : Aggregate, ISourceUseOwner
{
    public const string Area = "controls";
    public const string OrganizationAuthored = "organization_authored";
    public const int MaximumDraftEventPayloadBytes = 48 * 1024;
    readonly Uuid _tenantId;
    ControlAuthorityHeader? _header;

    public ControlDraft(Uuid tenantId, Uuid controlId, Uuid selectedCommandId = default)
        : base(controlId, new EventStreamAddress(tenantId.ToString(), Area, controlId.ToString()))
    {
        _tenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedCommandId);
        Uses = new SourceUseReservations(Stream);
        On<ControlDraftCreated>(ApplyFact);
        On<ControlDraftRevised>(ApplyFact);
        On<ControlDraftDiscarded>(ApplyFact);
        On<ControlReviewed>(ApplyFact);
        On<ControlApproved>(ApplyFact);
        On<ControlSuccessorProposed>(ApplyFact);
        On<ControlRetirementProposed>(ApplyFact);
        On<ControlRetired>(ApplyFact);
        On<ControlProposalWithdrawn>(ApplyFact);
        On<ControlOwnerPersonDesignated>(ApplyFact);
        On<ResponsibilityAssigned>(ApplyFact);
        On<ResponsibilityRevoked>(ApplyFact);
    }

    public NativeAcceptance Acceptance { get; }
    public SourceUseReservations Uses { get; }
    public long NativeSequence { get; private set; }
    public ImmutableContentRef? CurrentAuthority { get; private set; }
    public ControlAuthorityHeader? Header => _header;
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _header?.ProgramId ?? Uuid.Empty;
    public long Revision => _header?.Revision ?? 0;
    public bool IsCreated => _header?.IsCreated ?? false;
    public bool IsVisible => _header?.IsVisible ?? false;
    public bool IsApproved => _header?.IsApproved ?? false;
    public bool IsRetired => _header?.IsRetired ?? false;
    public bool HasOpenDraft => _header?.HasOpenDraft ?? false;
    public Uuid DraftVersionId => _header?.DraftVersionId ?? ControlVersionIds.Initial(Id);
    public Uuid? PendingTargetId => _header?.PendingTargetId;
    public Uuid? PendingRetirementId => _header?.PendingRetirementId;
    public DateOnly? PendingRetirementEffectiveUntil => _header?.PendingRetirementEffectiveUntil;
    public Uuid? PendingAuthorMemberId => _header?.PendingAuthorMemberId;
    public Uuid? AcceptedReviewDecisionId => _header?.AcceptedReviewDecisionId;
    public Uuid? AcceptedReviewerMemberId => _header?.AcceptedReviewerMemberId;
    public Uuid? LatestReviewDecisionId => _header?.LatestReviewDecisionId;
    public DateTimeOffset? PendingDecisionChangedAt => _header?.PendingDecisionChangedAt;

    public static Uuid IdFor(Uuid tenantId, Uuid programId, string identifier) => ControlIds.For(tenantId, programId, identifier);
    public static string NormalizeIdentifier(string? identifier) => ControlIds.NormalizeIdentifier(identifier);
    internal static RequestError? ValidateContent(ControlDraftContent? content) => ControlRules.ValidateContent(content);
    internal static RequestError? ValidateCreateInput(string? identifier, ControlDraftContent? content) =>
        ControlRules.ValidateCreateInput(identifier, content);

    public bool IsCurrentResponsibilityScope(ResponsibilityScope scope) => scope.RecordType == SeparationOfDutiesRecordTypes.Control &&
        scope.RecordId == Id && PendingTargetId == scope.VersionId && Revision == scope.Revision;

    public Result Prepare(Uuid programId, long? expectedRevision, bool creating = false)
    {
        if (Uses.HasActiveUse)
            return Fail(RequestErrorKind.Conflict, "The control is held by an accepted source use.", true);
        if (creating)
            return IsCreated ? Fail(RequestErrorKind.Conflict, "The control identifier already exists.") : Result.Success;
        if (!IsVisible || ProgramId != programId)
            return Fail(RequestErrorKind.NotFound, "The control was not found.");
        return expectedRevision is { } expected && expected != Revision
            ? Fail(RequestErrorKind.Conflict, "The control content revision is stale.") : Result.Success;
    }

    /// <summary>The exact preparation cut is checked inside the owning OCC append, including same-content-revision decisions.</summary>
    public Result Append(DomainEvent value, long preparedSequence, ulong preparedPhysicalPosition,
        ControlMutationContent? preparedMutation = null, ControlAuthorityContent? beforeAuthority = null,
        ControlAuthorityContent? afterAuthority = null)
    {
        if (NativeSequence != preparedSequence || CommittedStreamPosition != preparedPhysicalPosition)
            return Fail(RequestErrorKind.Conflict, "The control changed while its exact content and authority were prepared.", true);
        if (Uses.HasActiveUse)
            return Fail(RequestErrorKind.Conflict, "The control is held by an accepted source use.", true);
        if (value is not IControlFact fact || fact.Header is null)
            return Fail(RequestErrorKind.Validation, "A control mutation requires a compact native fact.");
        Validate(value, fact);
        RaiseEvent(value);
        return Result.Success;
    }

    void ApplyFact(DomainEvent value)
    {
        var fact = (IControlFact)value;
        Validate(value, fact);
        _header = fact.Header;
        CurrentAuthority = fact.Authority;
        NativeSequence = fact.NativeSequence;
        Acceptance.Observe(value);
    }

    void Validate(DomainEvent value, IControlFact fact)
    {
        OwnerProvenance.RequireOwn(this, fact.Operation.LogicalId, fact.Operation);
        var after = fact.Header;
        if (after is null || fact.NativeSequence != NativeSequence + 1 || fact.TenantId != _tenantId ||
            after.TenantId != _tenantId || after.ControlId != Id || after.ProgramId == Uuid.Empty ||
            Id != IdFor(_tenantId, after.ProgramId, after.Identifier) || after.Revision < 1 || !after.IsCreated ||
            fact.Change is null || fact.Authority is null || fact.FirstResponse is null || fact.OperationResult is null ||
            fact.ChangeCount < 0 || fact.Operation.RootOperationId != fact.Operation.LogicalId ||
            fact.Operation.CausationEventId is not null || fact.Operation.Episode != Id.ToString() ||
            fact.Operation.AffectedOwner != Stream || fact.Operation.ExpectedRevisionOwner != Stream ||
            fact.Operation.Actor.Kind != "member" || !Uuid.TryParse(fact.Operation.Actor.Id, out var actor) || actor == Uuid.Empty ||
            after.IsApproved != (after.ApprovedVersionCount > 0) ||
            after.IsRetired && (after.HasOpenDraft || after.PendingTargetId is not null) ||
            after.HasOpenDraft && after.PendingTargetId != after.DraftVersionId)
            throw new InvalidOperationException("The control fact has an invalid exact native owner or authority binding.");
        if (_header is null)
        {
            if (value is not ControlDraftCreated || after.Revision != 1 || !after.IsVisible || after.IsApproved ||
                after.DraftVersionId != ControlVersionIds.Initial(Id) || fact.Operation.LogicalId != Id ||
                fact.Operation.CommandKind != nameof(CreateControlDraft) || fact.Operation.OriginalExpectedRevision is not null)
                throw new InvalidOperationException("A control begins with its deterministic own creation and first draft.");
            return;
        }
        if (value is ControlDraftCreated || after.ProgramId != _header.ProgramId || after.Identifier != _header.Identifier ||
            after.Revision < Revision || after.Revision > Revision + 1 ||
            after.ApprovedVersionCount < _header.ApprovedVersionCount || after.ApprovedVersionCount > _header.ApprovedVersionCount + 1 ||
            !_header.IsVisible && fact.ChangeCount > 0 || _header.IsRetired && fact.ChangeCount > 0)
            throw new InvalidOperationException("A control mutation cannot change its identity or rewrite terminal authority.");
        var kind = value switch
        {
            ControlDraftRevised => nameof(ReviseControlDraft),
            ControlDraftDiscarded => nameof(DiscardControlDraft),
            ControlReviewed => nameof(ReviewControl),
            ControlApproved => nameof(ApproveControl),
            ControlSuccessorProposed => nameof(ProposeControlSuccessor),
            ControlRetirementProposed => nameof(ProposeControlRetirement),
            ControlRetired => nameof(RetireControl),
            ControlProposalWithdrawn => nameof(WithdrawControlProposal),
            ControlOwnerPersonDesignated => nameof(DesignateControlOwnerPerson),
            ResponsibilityAssigned => nameof(AssignResponsibility),
            ResponsibilityRevoked => nameof(RevokeResponsibility),
            _ => throw new InvalidOperationException("The control native mutation has another business kind."),
        };
        if (fact.Operation.CommandKind != kind)
            throw new InvalidOperationException("The control's native operation kind differs from its accepted business fact.");
        if (value is ControlApproved approved &&
            (PendingTargetId != approved.VersionId || AcceptedReviewDecisionId != approved.AcceptedReviewDecisionId ||
             after.ApprovedVersionId != approved.VersionId || after.HasOpenDraft ||
             after.ApprovedVersionCount != _header.ApprovedVersionCount + 1))
            throw new InvalidOperationException("Control approval must answer the exact current draft and accepted review.");
        if (value is ControlSuccessorProposed successor &&
            (successor.PredecessorVersionId != _header.ApprovedVersionId ||
             successor.VersionId != ControlVersionIds.Sequence(Id, _header.ApprovedVersionCount + 1)))
            throw new InvalidOperationException("A successor must preserve its deterministic line and exact approved predecessor.");
    }

    static Result Fail(RequestErrorKind kind, string message, bool transient = false) =>
        Result.Failure(new RequestError(kind, message, transient));
}
