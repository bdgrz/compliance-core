from pathlib import Path
p=Path('/tmp/compliance-control-owners-prepared/work/src/Compliance.Core/Features/Controls/ControlDraft.cs')
s=p.read_text()
s=s.replace('fact.ChangeCount < 0 || fact.Operation.RootOperationId', 'fact.ChangeCount < 0 || !Hex(fact.Operation.AuthoredIntentSha256) || fact.Operation.RootOperationId')
# Check exact field name below before finalizing.
s=s.replace('            .Concat(mutation.Changes.OfType<ControlApprovedContent>().Select(change => change.Content)).LastOrDefault();', '''            .Concat(mutation.Changes.OfType<ControlApprovedContent>().Select(change => change.Content))
            .Concat(mutation.Receipt is ControlDraftRevisedContent unchanged ? [unchanged.Content] : []).LastOrDefault();''')
s=s.replace('''            if (approval.OwnerPersonId is { } person)
                return before!.PersonOwnerBinding is { } binding && binding.PersonId == person &&
                    binding.DesignationId == approval.OwnerAssignmentId &&
                    (binding.CorrelatedMemberId ?? Uuid.Empty) == approval.OwnerMemberId;''','''            if (approval.OwnerPersonId is { } person)
                return before!.PersonOwnerBinding is { } binding && binding.PersonId == person &&
                    binding.DesignationId == approval.OwnerAssignmentId &&
                    (approval.SeparationOfDutiesWaiverId is not null || approval.OwnerMemberId != approval.ActorMemberId);''')
s=s.replace('''                supplied.All(proof => assigned.SeparationOfDutiesWaiverIds.Contains(proof.WaiverId) && LocatorValid(proof));''','''                supplied.All(proof => assigned.SeparationOfDutiesWaiverIds.Contains(proof.WaiverId) && LocatorValid(proof)) &&
                (fact.ChangeCount != 0 || Matches(CurrentAuthority!, before with { Assignments = set.ReadAssignments() },
                    ControlFactContent.AuthoritySchema));''')
s=s.replace('''        if (value is ResponsibilityRevoked revoked)
            return supplied.Count == 0 && Set(before!).Revoke(revoked.AssignmentId, revoked.RevokedByMemberId,
                revoked.RevokedByDisplay, revoked.RevokedAt, revoked.Reason) is null;
        return supplied.Count == 0;''','''        if (value is ResponsibilityRevoked revoked)
        {
            var set = Set(before!);
            return supplied.Count == 0 && set.Revoke(revoked.AssignmentId, revoked.RevokedByMemberId,
                revoked.RevokedByDisplay, revoked.RevokedAt, revoked.Reason) is null &&
                (fact.ChangeCount != 0 || Matches(CurrentAuthority!, before! with { Assignments = set.ReadAssignments() },
                    ControlFactContent.AuthoritySchema));
        }
        if (fact.ChangeCount == 0 && value is ControlOwnerPersonDesignated designated)
            return supplied.Count == 0 && before!.PersonOwnerBinding?.PersonId == designated.PersonId &&
                before.PersonOwnerBinding?.CorrelatedMemberId == designated.CorrelatedMemberId;
        return supplied.Count == 0;''')
s=s.replace('''            Require(value is ControlDraftRevised or ControlOwnerPersonDesignated or ResponsibilityAssigned or ResponsibilityRevoked &&''','''            Require((value is ControlDraftRevised or ControlOwnerPersonDesignated or ResponsibilityAssigned or ResponsibilityRevoked) &&''')
p.write_text(s)
