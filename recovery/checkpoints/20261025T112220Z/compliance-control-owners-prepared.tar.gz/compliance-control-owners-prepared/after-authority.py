from pathlib import Path
p=Path('/tmp/compliance-control-owners-prepared/work/src/Compliance.Core/Features/Controls/ControlDraft.cs')
s=p.read_text().replace('ControlMutationContent? preparedMutation = null, ControlAuthorityContent? beforeAuthority = null)','ControlMutationContent? preparedMutation = null, ControlAuthorityContent? beforeAuthority = null,\n        ControlAuthorityContent? afterAuthority = null)')
s=s.replace('PreparedAuthority(value, fact, preparedMutation, beforeAuthority)','PreparedAuthority(value, fact, preparedMutation, beforeAuthority, afterAuthority)')
s=s.replace('ControlAuthorityContent? before)\n    {\n        if (mutation is null', 'ControlAuthorityContent? before, ControlAuthorityContent? after)\n    {\n        if (after is null || after.Header != fact.Header || !Matches(fact.Authority, after, ControlFactContent.AuthoritySchema))\n            return false;\n        if (mutation is null')
s=s.replace('''        if (value is ControlProposalWithdrawn &&''', '''        if (!Matches(fact.Authority, ExpectedAuthority(value, fact.Header, before, contentChange), ControlFactContent.AuthoritySchema))
            return false;
        if (value is ControlProposalWithdrawn &&''')
mark='    bool DecisionAllowed('
block='''    ControlAuthorityContent ExpectedAuthority(DomainEvent value, ControlAuthorityHeader header,
        ControlAuthorityContent? before, ControlDraftContent? content)
    {
        var expected = before is null
            ? new ControlAuthorityContent(header, [], [], null, CurrentApplicabilityCount: content?.Applicability?.Count ?? 0)
            : before with { Header = header };
        if (((IControlFact)value).ChangeCount == 0)
            return expected;
        if (value is ControlDraftRevised or ControlSuccessorProposed or ControlRetirementProposed or
            ControlProposalWithdrawn or ControlDraftDiscarded or ControlApproved or ControlRetired)
            expected = expected with { Assignments = [], DecisionConstraints = [], PersonOwner = null, PersonOwnerBinding = null };
        if (content is not null)
            expected = expected with { CurrentApplicabilityCount = content.Applicability?.Count ?? 0 };
        if (value is ControlApproved)
            expected = expected with { ApprovedContentSha256 = header.Content.Sha256 };
        if (value is ControlReviewed review)
            expected = expected with { DecisionConstraints = expected.DecisionConstraints.Append(new ControlDecisionConstraint(
                review.ActorMemberId, ResponsibilityType.AssignedReviewer, review.DecidedAt, review.SeparationOfDutiesWaiverId)).ToArray() };
        if (value is ControlOwnerPersonDesignated designated)
            expected = expected with
            {
                PersonOwner = designated.PersonId is { } person
                    ? new ControlPersonOwnerDesignationView(person, designated.DesignationId, designated.Rationale,
                        designated.Actor, designated.DesignatedAt) : null,
                PersonOwnerBinding = designated.PersonId is { } binding
                    ? new ControlPersonOwner(binding, designated.CorrelatedMemberId, designated.DesignationId) : null,
            };
        if (value is ResponsibilityAssigned assigned)
        {
            var set = Set(before!);
            set.Apply(assigned);
            expected = expected with { Assignments = set.ReadAssignments() };
        }
        if (value is ResponsibilityRevoked revoked)
        {
            var set = Set(before!);
            set.Apply(revoked);
            expected = expected with { Assignments = set.ReadAssignments() };
        }
        return expected;
    }

'''
s=s.replace(mark,block+mark)
p.write_text(s)
p=Path('/tmp/compliance-control-owners-prepared/work/test/Compliance.Tests/Features/Controls/ControlAuthorityBoundaryTests.cs')
s=p.read_text()
s=s.replace('physical, mutation, before);','physical, mutation, before, rules.Authority(fact.Header));')
s=s.replace('preparedOwner.CommittedStreamPosition, mutation, before);','preparedOwner.CommittedStreamPosition, mutation, before, preparedRules.Authority(((IControlFact)fact).Header));')
s=s.replace('owner.CommittedStreamPosition, mutation, before);','owner.CommittedStreamPosition, mutation, before, rules.Authority(((IControlFact)fact).Header));')
s=s.replace('[InlineData("header")]','[InlineData("header")]\n    [InlineData("operation")]')
s=s.replace('''        if (defect == "header")
            fact = fact with { Header = fact.Header with { PendingAuthorMemberId = reviewer } };''','''        if (defect == "header")
            fact = fact with { Header = fact.Header with { PendingAuthorMemberId = reviewer } };
        if (defect == "operation")
            fact = fact with { Operation = null! };''')
mark='    [Fact]\n    public async Task ShouldRejectChangedNoOpReceipt'
extra='''    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldRejectPoisonedAfterAuthorityGivenVerifiedNativeChange(bool substituteBody)
    {
        // Arrange
        await using var scenario = await Scenario.CreateAsync();
        var owner = await scenario.OwnerAsync();
        var rules = await scenario.RulesAsync();
        var before = rules.Authority(owner.Header!);
        var reviewer = Uuid.CreateVersion4();
        var decision = Uuid.CreateVersion4();
        Assert.Null(rules.Review(scenario.Program, 1, decision, "accept", "Verified", reviewer, "Reviewer", scenario.Source.Clock.Now));
        var mutation = new ControlMutationContent(rules.PendingChanges.ToArray());
        var fact = Assert.IsType<ControlReviewed>(await ControlSeeds.FreezeAsync(scenario.Source.Content, rules, mutation.Changes,
            scenario.Operation(owner, decision, nameof(ReviewControl), reviewer, 1), 2));
        var after = rules.Authority(fact.Header);
        if (substituteBody)
        {
            after = after with { DecisionConstraints = [] };
            var poison = await scenario.Source.Content.WriteJsonAsync(scenario.Tenant.ToString(), Uuid.CreateVersion4(),
                ControlFactContent.AuthoritySchema, after);
            fact = fact with { Authority = poison };
        }
        else
            fact = fact with { Authority = owner.CurrentAuthority! };

        // Act
        var result = owner.Append(fact, owner.NativeSequence, owner.CommittedStreamPosition, mutation, before, after);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Validation, result.Error!.Kind);
        Assert.Equal(1, owner.NativeSequence);
        Assert.Single(await scenario.Source.FactsAsync(scenario.Tenant, scenario.Id));
    }

'''
s=s.replace(mark,extra+mark).replace('using Bdgrz.Compliance.Features.Controls;','using Bdgrz.Compliance.Features.Controls;\nusing Bdgrz.Compliance.Features.Content;')
p.write_text(s)
