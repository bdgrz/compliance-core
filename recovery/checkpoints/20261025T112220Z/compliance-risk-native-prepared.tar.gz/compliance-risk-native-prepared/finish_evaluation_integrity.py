from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');d=r/'src/Compliance.Core/Features/Risks'
p=d/'RiskEvaluationContent.cs';s=p.read_text();s=s.replace('''=> header is not null && value switch
''','''=> header is not null && (value switch
''');start=s.index('    public static bool InScope(');end=s.index('    public static bool BindingMatches(',start);piece=s[start:end];piece=piece.replace('''        _ => false,
    };''','''        _ => false,
    });''');s=s[:start]+piece+s[end:];p.write_text(s)
p=d/'RiskEvaluationNativeFact.cs';s=p.read_text();s=s.replace('''            candidate.Metadata.EventId == stored.Metadata.EventId && candidate.Metadata.AggregateId == stored.Metadata.AggregateId &&
            candidate.Metadata.AggregateVersion == stored.Metadata.AggregateVersion && candidate.Metadata.OccurredOn == stored.Metadata.OccurredOn;''','''            candidate.Metadata == stored.Metadata;''');p.write_text(s)
p=d/'RiskEvaluationReader.cs';s=p.read_text();s=s.replace('''        var stored = snapshot.Facts.SingleOrDefault''','''        if (snapshot.Owner.Header is not null && snapshot.ProgramId != fact.ProgramId)
            throw new ImmutableContentIntegrityException("The evaluation projection names another native program scope.");
        var stored = snapshot.Facts.SingleOrDefault''');s=s.replace('''        var logicalIds = new HashSet<Uuid>();''','''        var logicalIds = new HashSet<Uuid>();
        var eventIds = new HashSet<Uuid>();''');s=s.replace('''            if (record.Event.Metadata is not { } metadata)
                throw new ImmutableContentIntegrityException("The evaluation source carries no committed event metadata.");''','''            if (record is null || record.Stream != owner.Stream || record.Event?.Metadata is not { } metadata ||
                metadata.EventId == Uuid.Empty || metadata.AggregateId != owner.Id || !eventIds.Add(metadata.EventId))
                throw new ImmutableContentIntegrityException("The evaluation source carries another committed event identity or stream.");''');p.write_text(s)
p=r/'test/Compliance.Tests/Features/Risks/RiskEvaluationNativeSourceTests.cs';s=p.read_text();s='using System.Runtime.CompilerServices;\nusing System.Text.Json;\nusing Bdgrz.Compliance.Features.NativeOperations;\n'+s
needle='''    sealed class UnreadableContent'''
insert='''    [Theory]
    [InlineData("first_owner")]
    [InlineData("metadata_owner")]
    [InlineData("metadata_event")]
    [InlineData("header")]
    public async Task ShouldRollBackCurrentAndHistoryGivenAnotherExactEvaluationProjectionSource(string change)
    {
        // Arrange
        await using var source = new RiskEvaluationSourceFixture();
        var (tenant, program, risk, facts) = await HistoryAsync(source);
        var directory = new FitzRiskEvaluationDirectory(source.Kv, source.Evaluations);
        var identity = new CheckpointIdentity(FitzRiskEvaluationDirectory.ProjectorName,
            EventStreamPattern.ForPattern(tenant.ToString(), RiskEvaluation.Area));

        // Act
        await using (var batch = await directory.BeginAsync(new ProjectionBatchContext(identity, ProjectionCheckpoint.Start)))
        {
            await directory.ApplyAsync(facts[0]);
            await Assert.ThrowsAsync<ImmutableContentIntegrityException>(async () =>
                await directory.ApplyAsync(Alter(facts[1], change)));
        }
        var current = await directory.GetAsync(tenant, risk);
        var history = await directory.ListHistoryAsync(tenant, risk, 10, null);
        var checkpoint = await directory.LoadCheckpointAsync(identity);

        // Assert
        Assert.Null(current);
        Assert.Empty(history.Items);
        Assert.Equal(ProjectionCheckpoint.Start, checkpoint);
        Assert.Equal(program, (await source.Evaluations.ReadAsync(tenant, program, risk)).ProgramId);
    }

    [Theory]
    [InlineData("first_owner")]
    [InlineData("metadata_owner")]
    [InlineData("metadata_version")]
    [InlineData("null_header")]
    public async Task ShouldRejectMalformedNativeIdentityGivenEvaluationHistoryReader(string change)
    {
        // Arrange
        await using var source = new RiskEvaluationSourceFixture();
        var (tenant, program, risk, _) = await HistoryAsync(source);
        var reader = new RiskEvaluationReader(source.Reader,
            new AlteredEvents(source.Events, value => value is IRiskEvaluationFact { Revision: 1 } ? Alter(value, change) : value), source.Content);

        // Act
        var failure = await Record.ExceptionAsync(async () => await reader.ReadAsync(tenant, program, risk));

        // Assert
        Assert.IsType<ImmutableContentIntegrityException>(failure);
        Assert.False(RiskEvaluationReadFailure.Of((ImmutableContentIntegrityException)failure!).IsTransient);
    }

    [Fact]
    public async Task ShouldClassifyMissingNestedAssessmentGivenExactImmutableEvaluationBody()
    {
        // Arrange
        await using var source = new RiskEvaluationSourceFixture();
        var (tenant, _, _, facts) = await HistoryAsync(source);
        var original = Assert.IsType<RiskAssessmentRecorded>(facts[0]);
        var body = Assert.IsType<RiskAssessmentRecordedBody>(await RiskEvaluationContent.ReadMutationAsync(source.Content, original));
        var reference = await NativeContent.WriteAsync(source.Content, tenant, RiskEvaluationContent.AssessmentSchema,
            body with { Assessment = null! });
        var malformed = original with { ChangeContent = reference };

        // Act
        var failure = await Record.ExceptionAsync(async () => await RiskEvaluationContent.ReadMutationAsync(source.Content, malformed));

        // Assert
        Assert.IsType<ImmutableContentIntegrityException>(failure);
        Assert.False(RiskEvaluationReadFailure.Of((ImmutableContentIntegrityException)failure!).IsTransient);
    }

    static async Task<(Uuid Tenant, Uuid Program, Uuid Risk, IReadOnlyList<DomainEvent> Facts)> HistoryAsync(RiskEvaluationSourceFixture source)
    {
        var tenant = Uuid.CreateVersion4(); var program = Uuid.CreateVersion4(); var risk = Uuid.CreateVersion4(); var actor = Uuid.CreateVersion4();
        var method = new RiskMethod(tenant, program);
        Assert.Null(method.Publish(program, 0, RiskMethodTests.Scale(), RiskMethodTests.Scale(), 12,
            ActorReference.ForMember(actor, "Lead"), source.Clock.Now));
        var rules = new RiskEvaluationRules(tenant, risk);
        Assert.Null(rules.RecordAssessment(program, 0, Uuid.CreateVersion4(), method.Current!, "inherent", 2, 2,
            "Original assessment", actor, "Assessor", source.Clock.Now));
        Assert.Null(rules.ChooseTreatment(program, 1, "accept", "Chosen treatment", actor, "Assessor", source.Clock.Now));
        await source.SeedAsync(rules);
        return (tenant, program, risk, await source.FactsAsync(tenant, risk));
    }

    static DomainEvent Alter(DomainEvent original, string change)
    {
        var value = (DomainEvent)JsonSerializer.Deserialize(JsonSerializer.SerializeToUtf8Bytes(original,
            original.GetType(), ComplianceCoreJsonContext.Default), original.GetType(), ComplianceCoreJsonContext.Default)!;
        var fact = (IRiskEvaluationFact)value;
        var operation = fact.Operation with { FirstOwner = new EventStreamAddress(Uuid.CreateVersion4().ToString(), RiskEvaluation.Area, fact.RiskId.ToString()) };
        var header = change == "null_header" ? null! : fact.Header with { ViewSha256 = new string('a', 64) };
        if (change is "first_owner" or "header" or "null_header")
            value = value switch
            {
                RiskAssessmentRecorded item => item with { Operation = change == "first_owner" ? operation : item.Operation,
                    Header = change == "first_owner" ? item.Header : header },
                RiskTreatmentChosen item => item with { Operation = change == "first_owner" ? operation : item.Operation,
                    Header = change == "first_owner" ? item.Header : header },
                _ => throw new InvalidOperationException("Unexpected native test source kind."),
            };
        var metadata = original.Metadata;
        value.AttachMetadata(metadata with
        {
            AggregateId = change == "metadata_owner" ? Uuid.CreateVersion4() : metadata.AggregateId,
            EventId = change == "metadata_event" ? Uuid.CreateVersion4() : metadata.EventId,
            AggregateVersion = change == "metadata_version" ? metadata.AggregateVersion + 1 : metadata.AggregateVersion,
        });
        return value;
    }

    sealed class AlteredEvents(IDomainEventReader inner, Func<DomainEvent, DomainEvent> alter) : IDomainEventReader
    {
        public async IAsyncEnumerable<DomainEventRecord> ReadAsync(EventStreamAddress stream, ulong offset = 0,
            [EnumeratorCancellation] CancellationToken ct = default)
        {
            await foreach (var record in inner.ReadAsync(stream, offset, ct)) yield return record with { Event = alter(record.Event) };
        }
        public async IAsyncEnumerable<DomainEventRecord> ReadAsync(EventStreamPattern pattern, EventCursor cursor = default,
            [EnumeratorCancellation] CancellationToken ct = default)
        {
            await foreach (var record in inner.ReadAsync(pattern, cursor, ct)) yield return record with { Event = alter(record.Event) };
        }
    }

'''
assert needle in s;s=s.replace(needle,insert+needle);p.write_text(s)
