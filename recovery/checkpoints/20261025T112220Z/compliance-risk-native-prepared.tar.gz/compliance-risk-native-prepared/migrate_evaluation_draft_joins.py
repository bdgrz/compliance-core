from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');p=r/'src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs';s=p.read_text();a=s.index('        var stream = new EventStreamAddress(tenantId.ToString(), "risks",',s.index('ReadDraftHistoryAsync'));b=s.index('    async ValueTask<Result<EvaluationHistory>>',a)
s=s[:a]+'''        var stream = new EventStreamAddress(tenantId.ToString(), RiskDraft.Area, summary.RiskId.ToString());
        var asOfEvents = new List<RiskSourceEvent>();
        RiskDraftRevisionView? currentContent = null;
        IRiskDraftFact? last = null;
        var currentRevision = 0L;
        var asOfRevision = 0L;
        var expectedVersion = 1UL;
        DateTimeOffset? priorRecordedAt = null;
        var excluded = false;
        var count = 0;
        try
        {
            await foreach (var record in events.ReadAsync(stream, 0, ct).ConfigureAwait(false))
            {
                if (++count > MaximumEventsPerStream || record.Stream != stream || record.Event?.Metadata is not { } metadata ||
                    !ValidMetadata(metadata, summary.RiskId, expectedVersion, seenEventIds) ||
                    priorRecordedAt is { } prior && metadata.OccurredOn < prior)
                    return InvalidHistory<DraftHistory>();
                expectedVersion++;
                priorRecordedAt = metadata.OccurredOn;
                if (metadata.IsAudit) continue;
                if (record.Event is not IRiskDraftFact fact || fact.Header.TenantId != tenantId || fact.Header.ProgramId != programId ||
                    fact.Header.RiskId != summary.RiskId || fact.NativeSequence != currentRevision + 1 || fact.Header.Revision != currentRevision + 1 ||
                    record.Event is RiskDraftCreated && currentRevision != 0 || record.Event is RiskDraftRevised && currentRevision == 0 ||
                    record.Event is not (RiskDraftCreated or RiskDraftRevised))
                    return InvalidHistory<DraftHistory>();
                var version = await RiskDraftFactContent.ReadAsync(content, fact, ct).ConfigureAwait(false);
                if (version.Identifier != RiskDraft.NormalizeIdentifier(version.Identifier) ||
                    RiskDraft.IdFor(tenantId, programId, version.Identifier) != summary.RiskId || !ValidDraftContent(version.Content) ||
                    version.ChangedByMemberId == Uuid.Empty || !ValidText(version.ChangedByDisplay, 200) || version.ChangedAt == default)
                    return InvalidHistory<DraftHistory>();
                currentRevision = version.Revision;
                currentContent = version;
                last = fact;
                var isAsOf = version.ChangedAt <= through && metadata.OccurredOn <= through;
                if (isAsOf && excluded) return InvalidHistory<DraftHistory>();
                if (isAsOf)
                {
                    if (asOfRevision + 1 != currentRevision) return InvalidHistory<DraftHistory>();
                    asOfRevision = currentRevision;
                    asOfEvents.Add(SerializeEvent(record.Event, "risks", summary.RiskId, metadata));
                }
                else excluded = true;
            }
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<DraftHistory>.Failure(RiskDraftReadFailure.Of(failure));
        }
        var current = await reader.HydrateAsync(new RiskDraft(tenantId, summary.RiskId), ct).ConfigureAwait(false);
        if (last is null || currentContent is null || currentRevision != summary.Revision || !current.IsCreated ||
            current.Id != summary.RiskId || current.ProgramId != programId || current.Revision != currentRevision ||
            current.Header != last.Header || current.CurrentContent != last.Content || current.NativeSequence != last.NativeSequence ||
            summary.Content != currentContent.Content || summary.LastChangedAt != currentContent.ChangedAt ||
            summary.LastChangedByMemberId != currentContent.ChangedByMemberId || summary.LastChangedByDisplay != currentContent.ChangedByDisplay)
            return InvalidHistory<DraftHistory>();
        return Result<DraftHistory>.Success(new DraftHistory(asOfRevision, asOfEvents));
    }

'''+s[b:];p.write_text(s)
p=r/'test/Compliance.Tests/Features/Examinations/RiskTypeIBaselineSourceContributorTests.cs';s=p.read_text().replace('var risk = new RiskDraft(TenantId, RiskId);','var risk = new RiskDraftRules(TenantId, RiskId);').replace('risk.Create(ProgramId, Uuid.CreateVersion4(), "R-01",','risk.Create(ProgramId, RiskId, "R-01",');s=s.replace('        await store.AppendAsync(stream, 0, new AggregateScenario<RiskDraft>(risk).PendingEvents\n            .ToArray());','        var riskOwner = await RiskDraftSeeds.OwnerAsync(content, risk);\n        await store.AppendAsync(stream, 0, new AggregateScenario<RiskDraft>(riskOwner).PendingEvents.ToArray());');s=s.replace('static RiskDraftView Summary(RiskDraft risk)','static RiskDraftView Summary(RiskDraftRules risk)');p.write_text(s)
p=r/'test/Compliance.Tests/Features/Work/RiskAcceptanceWorkAuthorityTests.cs';s=p.read_text().replace('            var riskId = Uuid.CreateVersion4();\n            var residualId', '            var riskId = RiskDraft.IdFor(Operations.TenantId, Operations.ProgramId, "R-AUTH");\n            var residualId');s=s.replace('new RiskDraft(Operations.TenantId, riskId), risk => risk.Create(Operations.ProgramId,\n                    Uuid.CreateVersion4(), "R-AUTH",','new RiskDraftRules(Operations.TenantId, riskId), risk => risk.Create(Operations.ProgramId,\n                    riskId, "R-AUTH",');p.write_text(s)
