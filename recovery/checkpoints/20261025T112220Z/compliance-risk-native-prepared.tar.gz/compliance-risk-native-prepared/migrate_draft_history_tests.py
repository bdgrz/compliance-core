from pathlib import Path
p=Path('/tmp/compliance-risk-native-prepared/work/test/Compliance.Tests/Features/Risks/FitzRiskDraftHistoryDirectoryV1Tests.cs');s=p.read_text();s='using Bdgrz.Compliance.Tests.Testing;\n'+s
# First fixture publishes real native immutable revisions.
a=s.index('        var created = new RiskDraftCreated(');b=s.index('\n        // Act',a)
s=s[:a]+'''        await using var native = new RiskDraftSourceFixture();
        var firstRules = new RiskDraftRules(tenantId, riskId);
        Assert.True(firstRules.Create(programId, riskId, "R-01", Content("Initial"), authorId, "Author", now).IsSuccess);
        Assert.Null(firstRules.Revise(programId, 1, Content("Second"), editorId, "Editor", now.AddMinutes(1)));
        Assert.Null(firstRules.Revise(programId, 2, Content("Third"), editorId, "Editor", now.AddMinutes(2)));
        var firstFacts = await native.PublishAsync(firstRules);
        var otherRules = new RiskDraftRules(tenantId, otherRiskId);
        Assert.True(otherRules.Create(programId, otherRiskId, "R-02", Content("Other"), authorId, "Author", now).IsSuccess);
        var otherFacts = await native.PublishAsync(otherRules);
        var directory = new FitzRiskDraftHistoryDirectoryV1(new InMemoryKvClient(), native.Content);
        await ProjectAsync(directory, tenantId, firstFacts.Concat(otherFacts).ToArray());
'''+s[b:]
# Cursor fixture exact sources and compact metadata owners.
a=s.index('        var firstSource = CreateSource(',s.index('ShouldRejectMalformedAndCrossRecordCursors'));b=s.index('        var handler = new ListRiskDraftRevisionsHandler',a)
s=s[:a]+'''        await using var native = new RiskDraftSourceFixture();
        var firstRules = CreateSource(tenantId, programId, "R-01");
        var secondRules = CreateSource(tenantId, programId, "R-02");
        Assert.Null(firstRules.Revise(programId, 1, Content("Second"), Uuid.CreateVersion4(), "Editor", DateTimeOffset.UtcNow));
        var facts = (await native.PublishAsync(firstRules)).Concat(await native.PublishAsync(secondRules)).ToArray();
        var firstSource = await native.Reader.HydrateAsync(new RiskDraft(tenantId, firstRules.Id));
        var secondSource = await native.Reader.HydrateAsync(new RiskDraft(tenantId, secondRules.Id));
        var directory = new FitzRiskDraftHistoryDirectoryV1(new InMemoryKvClient(), native.Content);
        await ProjectAsync(directory, tenantId, facts);
        var consistency = new RiskDraftHistoryReadConsistency(directory, new SourceReader(firstSource, secondSource));
'''+s[b:]
# Source advance remains real; only projection application is delayed.
a=s.index('        var risk = CreateSource(',s.index('ShouldReportLagAndHideOtherProgramOrTenant'));b=s.index('        var directory = new TrackingDirectory(projected);',a)
s=s[:a]+'''        await using var native = new RiskDraftSourceFixture();
        var rules = CreateSource(tenantId, programId, "R-01");
        Assert.Null(rules.Revise(programId, 1, Content("Revised"), Uuid.CreateVersion4(), "Editor", DateTimeOffset.UtcNow));
        var facts = await native.PublishAsync(rules);
        var risk = await native.Reader.HydrateAsync(new RiskDraft(tenantId, rules.Id));
        var projected = new FitzRiskDraftHistoryDirectoryV1(new InMemoryKvClient(), native.Content);
'''+s[b:]
s=s.replace('await ProjectAsync(projected, tenantId, created, revised);','await ProjectAsync(projected, tenantId, facts.ToArray());')
s=s.replace('static RiskDraft CreateSource(', 'static RiskDraftRules CreateSource(').replace('var source = new RiskDraft(tenantId, RiskDraft.IdFor', 'var source = new RiskDraftRules(tenantId, RiskDraft.IdFor')
s=s.replace('new("RiskDraftHistoryDirectoryV1",', 'new(FitzRiskDraftHistoryDirectoryV1.ProjectorName,')
p.write_text(s)
