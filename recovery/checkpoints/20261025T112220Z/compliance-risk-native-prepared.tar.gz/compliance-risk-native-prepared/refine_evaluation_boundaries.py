from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work/src/Compliance.Core/Features/Risks')
p=r/'RiskEvaluationContent.cs';s=p.read_text();s=s.replace('        var rules = RiskEvaluationRules.FromView(frozen.Before);','''        if (!InScope(frozen.Mutation, frozen.Header) || LogicalId(frozen.Mutation) == Uuid.Empty ||
            Actor(frozen.Mutation) is not { Kind: "member" } member || !Uuid.TryParse(member.Id, out var parsedMember) || parsedMember == Uuid.Empty ||
            At(frozen.Mutation) == default)
            return false;
        var rules = RiskEvaluationRules.FromView(frozen.Before);''');s=s.replace('Uuid.Parse(value.Assessment.Assessor.Id)','parsedMember').replace('Uuid.Parse(value.Treatment.ChosenBy.Id)','parsedMember');p.write_text(s)
p=r/'FitzRiskEvaluationDirectory.cs';s=p.read_text();s='using System.Globalization;\n'+s;s=s.replace('    public const string ProjectorName = "RiskEvaluationDirectoryV2";','''    public const string ProjectorName = "RiskEvaluationDirectoryV2";
    Uuid? _batchTenant;
    public new ValueTask<IProjectionBatch> BeginAsync(ProjectionBatchContext context, CancellationToken ct = default) => BeginEvaluationBatchAsync(context, ct);
    ValueTask<IProjectionBatch> IProjectionStore.BeginAsync(ProjectionBatchContext context, CancellationToken ct) => BeginEvaluationBatchAsync(context, ct);
    async ValueTask<IProjectionBatch> BeginEvaluationBatchAsync(ProjectionBatchContext context, CancellationToken ct)
    {
        if (!Uuid.TryParse(context.Identity.Pattern.Realm, CultureInfo.InvariantCulture, out var tenant) || tenant == Uuid.Empty)
            throw new InvalidOperationException("An evaluation projection batch requires its exact tenant scope.");
        var batch = await base.BeginAsync(context, ct).ConfigureAwait(false);
        _batchTenant = tenant;
        return batch;
    }''').replace('        if (fact.TenantId == Uuid.Empty ||','        if (_batchTenant != fact.TenantId || fact.TenantId == Uuid.Empty ||');p.write_text(s)
