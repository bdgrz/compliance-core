from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work/src/Compliance.Core/Features/Risks')
(r/'RiskDraftDirectoryIdentity.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Risks;

public sealed record RiskDraftDirectoryIdentity(RiskDraftAuthorityHeader Header, ImmutableContentRef Content,
    long NativeSequence, NativeFactReference Source);
''')
# Keep the public reader interfaces/wire views; store bounded exact source references.
for name in ['RiskDraftDirectorySchema','RiskDraftHistoryDirectoryV1Schema']:
 p=r/(name+'.cs');s=p.read_text().replace('RiskDraftRevisionView','RiskDraftDirectoryIdentity').replace('RiskDraftView','RiskDraftDirectoryIdentity')
 s=s.replace('risk.ProgramId','risk.Header.ProgramId').replace('risk.Identifier','risk.Header.Identifier').replace('risk.RiskId','risk.Header.RiskId').replace('revision.RiskId','revision.Header.RiskId').replace('revision.Revision','revision.Header.Revision')
 p.write_text(s)
(r/'RiskDraftProjectionStore.cs').write_text('''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Fitz;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

abstract class RiskDraftProjectionStore(IKvClient client, IImmutableContentStore content, string address, string name)
    : FitzKvProjectionStore(client, address, name)
{
    Uuid _tenant;
    public new async ValueTask<IProjectionBatch> BeginAsync(ProjectionBatchContext context, CancellationToken ct = default)
    {
        if (!Uuid.TryParse(context.Identity.Pattern.Realm, CultureInfo.InvariantCulture, out var tenant) || tenant == Uuid.Empty)
            throw new InvalidOperationException("A risk draft projection requires its bound tenant.");
        var batch = await base.BeginAsync(context, ct).ConfigureAwait(false); _tenant = tenant; return batch;
    }
    async ValueTask<IProjectionBatch> IProjectionStore.BeginAsync(ProjectionBatchContext context, CancellationToken ct) =>
        await BeginAsync(context, ct).ConfigureAwait(false);
    protected async ValueTask<RiskDraftDirectoryIdentity> IdentityAsync(DomainEvent value, CancellationToken ct)
    {
        if (value is not IRiskDraftFact fact || fact.Header.TenantId != _tenant)
            throw new InvalidOperationException("The risk draft native projection source has another tenant or kind.");
        await RiskDraftFactContent.ReadAsync(content, fact, ct).ConfigureAwait(false);
        return new(fact.Header, fact.Content, fact.NativeSequence, NativeFactReference.Of(
            new EventStreamAddress(fact.Header.TenantId.ToString(), RiskDraft.Area, fact.Header.RiskId.ToString()), value));
    }
    protected async ValueTask<RiskDraftRevisionView> ReadAsync(Uuid tenant, RiskDraftDirectoryIdentity row, CancellationToken ct)
    {
        if (row.Header.TenantId != tenant || row.Source.Stream != new EventStreamAddress(tenant.ToString(), RiskDraft.Area, row.Header.RiskId.ToString()) ||
            row.Content.Schema != RiskDraftFactContent.Schema)
            throw new ImmutableContentIntegrityException("The risk draft row has another exact native source scope.");
        var revision = await content.ReadJsonAsync<RiskDraftRevisionView>(tenant.ToString(), row.Content, ct).ConfigureAwait(false);
        if (RiskDraftFactContent.Header(revision) != row.Header || RiskDraftRules.Validate(revision.Identifier, revision.Content) is not null)
            throw new ImmutableContentIntegrityException("The risk draft row differs from its exact immutable revision.");
        return revision;
    }
}
''')
(r/'FitzRiskDraftDirectory.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Cntryl.Fitz;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

sealed class FitzRiskDraftDirectory(IKvClient client, IImmutableContentStore content)
    : RiskDraftProjectionStore(client, content, "kv://bdgrz/risk-draft-directory-v2/projection", ProjectorName),
        IRiskDraftDirectoryReader, IRiskDraftDirectoryProjection
{
    public const string ProjectorName = "RiskDraftDirectoryV2";
    public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId, CancellationToken ct = default) =>
        base.LoadCheckpointAsync(new CheckpointIdentity(ProjectorName, EventStreamPattern.ForPattern(tenantId.ToString(), RiskDraft.Area)), ct);
    public async ValueTask ApplyAsync(DomainEvent value, CancellationToken ct = default)
    {
        var row = await IdentityAsync(value, ct).ConfigureAwait(false);
        var current = await RiskDraftDirectorySchema.Risks.GetAsync(Transaction, row.Header.RiskId, ct).ConfigureAwait(false);
        if (value is RiskDraftCreated ? current is not null || row.Header.Revision != 1 || row.NativeSequence != 1 :
            value is not RiskDraftRevised || current is null || current.Header.TenantId != row.Header.TenantId ||
            current.Header.ProgramId != row.Header.ProgramId || current.Header.Identifier != row.Header.Identifier ||
            current.Header.Revision + 1 != row.Header.Revision || current.NativeSequence + 1 != row.NativeSequence)
            throw new InvalidOperationException("A risk draft mutation cannot project before its exact predecessor.");
        if (current is null) await RiskDraftDirectorySchema.Risks.InsertAsync(Transaction, row, ct).ConfigureAwait(false);
        else await RiskDraftDirectorySchema.Risks.ReplaceAsync(Transaction, current, row, ct).ConfigureAwait(false);
        await RiskDraftDirectorySchema.Revisions.InsertAsync(Transaction, row, ct).ConfigureAwait(false);
    }
    public async ValueTask<RiskDraftView?> GetAsync(Uuid tenantId, Uuid riskId, CancellationToken ct = default)
    {
        RiskDraftDirectoryIdentity? row;
        await using (var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false))
            row = await RiskDraftDirectorySchema.Risks.GetAsync(tx, riskId, ct).ConfigureAwait(false);
        return row is null ? null : RiskDraftFactContent.View(await ReadAsync(tenantId, row, ct).ConfigureAwait(false));
    }
    public async ValueTask<Page<RiskDraftView>> ListProgramAsync(Uuid tenantId, Uuid programId, int limit, string? cursor, CancellationToken ct = default)
    {
        Page<RiskDraftDirectoryIdentity> page;
        await using (var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false))
            page = await RiskDraftDirectorySchema.Risks.QueryAsync(tx, RiskDraftDirectorySchema.ByProgramIdentifier.Query()
                .WithPrefix(programId.ToString()).Take(Math.Clamp(limit, 1, 200)).After(cursor), ct).ConfigureAwait(false);
        var values = new List<RiskDraftView>(page.Items.Count);
        foreach (var row in page.Items)
        {
            if (row.Header.ProgramId != programId) throw new ImmutableContentIntegrityException("The risk draft list has another program scope.");
            values.Add(RiskDraftFactContent.View(await ReadAsync(tenantId, row, ct).ConfigureAwait(false)));
        }
        return new(values, page.NextCursor);
    }
    public async ValueTask<RiskDraftRevisionView?> GetRevisionAsync(Uuid tenantId, Uuid riskId, long revision, CancellationToken ct = default)
    {
        RiskDraftDirectoryIdentity? row;
        await using (var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false))
            row = await RiskDraftDirectorySchema.Revisions.GetAsync(tx, RiskDraftDirectorySchema.RevisionKey(riskId, revision), ct).ConfigureAwait(false);
        return row is null ? null : await ReadAsync(tenantId, row, ct).ConfigureAwait(false);
    }
}
''')
(r/'FitzRiskDraftHistoryDirectoryV1.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Cntryl.Fitz;
using Cntryl.Fitz.Extensions;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

sealed class FitzRiskDraftHistoryDirectoryV1(IKvClient client, IImmutableContentStore content)
    : RiskDraftProjectionStore(client, content, "kv://bdgrz/risk-draft-history-v2/projection", ProjectorName),
        IRiskDraftHistoryDirectoryReader, IRiskDraftHistoryDirectoryProjection
{
    public const string ProjectorName = "RiskDraftHistoryDirectoryV2";
    public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId, CancellationToken ct = default) =>
        base.LoadCheckpointAsync(new CheckpointIdentity(ProjectorName, EventStreamPattern.ForPattern(tenantId.ToString(), RiskDraft.Area)), ct);
    public async ValueTask ApplyAsync(DomainEvent value, CancellationToken ct = default)
    {
        var row = await IdentityAsync(value, ct).ConfigureAwait(false);
        if (value is RiskDraftCreated)
        {
            if (row.Header.Revision != 1 || row.NativeSequence != 1) throw new InvalidOperationException("A risk draft history requires its exact creation.");
        }
        else
        {
            var previous = await RiskDraftHistoryDirectoryV1Schema.Revisions.GetAsync(Transaction,
                RiskDraftHistoryDirectoryV1Schema.RevisionKey(row.Header.RiskId, row.Header.Revision - 1), ct).ConfigureAwait(false);
            if (value is not RiskDraftRevised || row.Header.Revision < 2 || previous is null ||
                previous.Header.TenantId != row.Header.TenantId || previous.Header.ProgramId != row.Header.ProgramId ||
                previous.Header.Identifier != row.Header.Identifier || previous.NativeSequence + 1 != row.NativeSequence)
                throw new InvalidOperationException("A risk draft history revision cannot project before its exact predecessor.");
        }
        await RiskDraftHistoryDirectoryV1Schema.Revisions.InsertAsync(Transaction, row, ct).ConfigureAwait(false);
    }
    public async ValueTask<RiskDraftRevisionView?> GetRevisionAsync(Uuid tenantId, Uuid riskId, long revision, CancellationToken ct = default)
    {
        RiskDraftDirectoryIdentity? row;
        await using (var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false))
            row = await RiskDraftHistoryDirectoryV1Schema.Revisions.GetAsync(tx, RiskDraftHistoryDirectoryV1Schema.RevisionKey(riskId, revision), ct).ConfigureAwait(false);
        return row is null ? null : await ReadAsync(tenantId, row, ct).ConfigureAwait(false);
    }
    public async ValueTask<Page<RiskDraftRevisionView>> ListRevisionsAsync(Uuid tenantId, Uuid riskId, int limit, string? cursor, CancellationToken ct = default)
    {
        Page<RiskDraftDirectoryIdentity> page;
        await using (var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false))
            page = await RiskDraftHistoryDirectoryV1Schema.Revisions.QueryAsync(tx, RiskDraftHistoryDirectoryV1Schema.ByRiskRevision.Query()
                .WithPrefix(riskId.ToString()).Take(Math.Clamp(limit, 1, 200)).After(cursor), ct).ConfigureAwait(false);
        var values = new List<RiskDraftRevisionView>(page.Items.Count);
        foreach (var row in page.Items) values.Add(await ReadAsync(tenantId, row, ct).ConfigureAwait(false));
        return new(values, page.NextCursor);
    }
}
''')
for name in ['RiskDraftDirectoryProjector','RiskDraftHistoryProjectorV1']:
 p=r/(name+'.cs');s=p.read_text().replace('"RiskDraftDirectory"','FitzRiskDraftDirectory.ProjectorName').replace('"RiskDraftHistoryDirectoryV1"','FitzRiskDraftHistoryDirectoryV1.ProjectorName');p.write_text(s)
