from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');d=r/'src/Compliance.Core/Features/Risks'
(d/'RiskEvaluationNativeFact.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Validates one native source envelope without trusting its read or projection caller.</summary>
static class RiskEvaluationNativeFact
{
    public static IRiskEvaluationFact Require(DomainEvent value, bool committed = false)
    {
        if (value is not IRiskEvaluationFact fact || fact.Header is not { } header || fact.Operation is not { } op ||
            fact.TenantId == Uuid.Empty || fact.ProgramId == Uuid.Empty || fact.RiskId == Uuid.Empty || fact.Revision < 1 || fact.NativeSequence < 1 ||
            header.TenantId != fact.TenantId || header.ProgramId != fact.ProgramId || header.RiskId != fact.RiskId || header.Revision != fact.Revision ||
            header.AssessmentCount < 0 || header.AcceptanceCount < 0 || !Digest(header.ViewSha256))
            throw Invalid();
        var kind = value switch
        {
            RiskAssessmentRecorded => nameof(RecordRiskAssessment),
            RiskTreatmentChosen => nameof(ChooseRiskTreatment),
            RiskAccepted => nameof(AcceptRisk),
            _ => string.Empty,
        };
        var schema = value is RiskAssessmentRecorded ? RiskEvaluationContent.AssessmentSchema :
            value is RiskTreatmentChosen ? RiskEvaluationContent.TreatmentSchema : RiskEvaluationContent.AcceptanceSchema;
        var stream = new EventStreamAddress(fact.TenantId.ToString(), RiskEvaluation.Area, fact.RiskId.ToString());
        if (kind.Length == 0 || !Reference(fact.ChangeContent, schema) || !Reference(fact.CurrentAuthorityContent, RiskEvaluationContent.AuthoritySchema) ||
            !Reference(fact.FirstResponse, FirstResponses.Schema) || !Reference(fact.OperationResult, "mutation-result-content.v1") ||
            op.LogicalId == Uuid.Empty || op.LogicalId != op.RootOperationId || op.CausationEventId is not null || op.CommandKind != kind ||
            op.Owner != stream || op.FirstOwner != stream || op.AffectedOwner != stream || op.ExpectedRevisionOwner != stream ||
            op.Episode != fact.RiskId.ToString() || op.OriginalExpectedRevision != unchecked((ulong)(fact.Revision - 1)) ||
            op.Actor is not { Kind: "member" } actor || !Uuid.TryParse(actor.Id, out var member) || member == Uuid.Empty ||
            op.AcceptedAt == default || !Digest(op.AuthoredIntentSha256))
            throw Invalid();
        if (committed && (value.Metadata is not { } metadata || metadata.IsAudit || metadata.EventId == Uuid.Empty ||
            metadata.AggregateId != fact.RiskId || metadata.AggregateVersion != unchecked((ulong)fact.Revision) || metadata.OccurredOn == default))
            throw Invalid();
        return fact;
    }

    public static bool SameSource(DomainEvent candidate, DomainEvent stored)
    {
        var left = Require(candidate, true);
        var right = Require(stored, true);
        return candidate.GetType() == stored.GetType() && left.TenantId == right.TenantId && left.ProgramId == right.ProgramId &&
            left.RiskId == right.RiskId && left.Revision == right.Revision && left.NativeSequence == right.NativeSequence &&
            left.Header == right.Header && left.ChangeContent == right.ChangeContent && left.CurrentAuthorityContent == right.CurrentAuthorityContent &&
            left.Operation == right.Operation && left.FirstResponse == right.FirstResponse && left.OperationResult == right.OperationResult &&
            candidate.Metadata.EventId == stored.Metadata.EventId && candidate.Metadata.AggregateId == stored.Metadata.AggregateId &&
            candidate.Metadata.AggregateVersion == stored.Metadata.AggregateVersion && candidate.Metadata.OccurredOn == stored.Metadata.OccurredOn;
    }

    static bool Reference(ImmutableContentRef? value, string schema) => value is not null && value.ContentId != Uuid.Empty && value.Bytes >= 0 &&
        value.Schema == schema && value.MediaType == ImmutableContentStoreExtensions.JsonMediaType && Digest(value.Sha256);
    static bool Digest(string? value) => value is { Length: 64 } && value.All(Uri.IsHexDigit);
    static ImmutableContentIntegrityException Invalid() => new("The evaluation source has another exact native owner, metadata, actor, intent or result binding.");
}
''')
p=d/'RiskEvaluation.cs';s=p.read_text();s=s.replace('''        if (value is not IRiskEvaluationFact fact || frozen.Before.TenantId''','''        IRiskEvaluationFact fact;
        try { fact = RiskEvaluationNativeFact.Require(value); }
        catch (ImmutableContentIntegrityException) { return Failure("The evaluation native provenance is invalid."); }
        if (!RiskEvaluationContent.WellFormed(frozen.Mutation) || frozen.Before.TenantId''');s=s.replace('''        catch (InvalidOperationException)
''','''        catch (ImmutableContentIntegrityException)
''');start=s.index('        var kind = value switch',s.index('    void Validate('));end=s.index('\n    static Result Failure',start)
s=s[:start]+'''        RiskEvaluationNativeFact.Require(value);
        if (fact.TenantId != TenantId || fact.RiskId != Id || Header is not null && fact.ProgramId != Header.ProgramId ||
            fact.Revision != Revision + 1 || fact.NativeSequence != NativeSequence + 1 ||
            fact.Header.AssessmentCount != (Header?.AssessmentCount ?? 0) + (value is RiskAssessmentRecorded ? 1 : 0) ||
            fact.Header.AcceptanceCount != (Header?.AcceptanceCount ?? 0) + (value is RiskAccepted ? 1 : 0))
            throw new ImmutableContentIntegrityException("A native evaluation fact requires its exact owner revision and current authority counts.");
    }
'''+s[end:];p.write_text(s)
p=d/'RiskEvaluationContent.cs';s=p.read_text();s=s.replace('''        var fact = value as IRiskEvaluationFact ?? throw new ImmutableContentIntegrityException("The source is not one native evaluation fact.");
        return value switch''','''        var fact = RiskEvaluationNativeFact.Require(value);
        object body = value switch''');needle='''            _ => throw new ImmutableContentIntegrityException("The evaluation source has another exact change schema."),
        };
''';replacement=needle+'''        if (!WellFormed(body) || !InScope(body, fact.Header) || !BindingMatches(body, fact.Operation) ||
            LogicalId(body) != fact.Operation.LogicalId || Actor(body) != fact.Operation.Actor || At(body) != fact.Operation.AcceptedAt)
            throw new ImmutableContentIntegrityException("The evaluation immutable change has incomplete or mismatched native rule inputs.");
        return body;
''';assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('''        if (!InScope(frozen.Mutation, frozen.Header)''','''        if (!WellFormed(frozen.Mutation) || !InScope(frozen.Mutation, frozen.Header)''')
s=s.replace('''    public static bool InScope(object value, RiskEvaluationAuthorityHeader header) => value switch''','''    public static bool WellFormed(object value) => value switch
    {
        RiskAssessmentRecordedBody { Assessment: { Assessor: not null }, Method: { LikelihoodScale: not null, ImpactScale: not null, PublishedBy: not null } } => true,
        RiskTreatmentChosenBody { Treatment: { ChosenBy: not null } } => true,
        RiskAcceptedBody { Acceptance: { Approver: not null }, Method: { LikelihoodScale: not null, ImpactScale: not null, PublishedBy: not null } } item =>
            item.WaiverProof is null || item.WaiverProof.ApprovalFact is { Source: not null },
        _ => false,
    };
    public static bool InScope(object value, RiskEvaluationAuthorityHeader header) => header is not null && value switch''')
p.write_text(s)
p=d/'RiskEvaluationReader.cs';s=p.read_text();s=s.replace('''        var native = (IRiskEvaluationFact)fact;''','''        var native = RiskEvaluationNativeFact.Require(fact, true);''')
s=s.replace('''            if (record.Event.Metadata.IsAudit)
                continue;
            if (record.Event is not IRiskEvaluationFact fact || record.Stream != owner.Stream || fact.NativeSequence != sequence + 1 ||''','''            if (record.Event.Metadata is not { } metadata)
                throw new ImmutableContentIntegrityException("The evaluation source carries no committed event metadata.");
            if (metadata.IsAudit)
                continue;
            var fact = RiskEvaluationNativeFact.Require(record.Event, true);
            if (record.Stream != owner.Stream || fact.NativeSequence != sequence + 1 || fact.Revision != rules.Revision + 1 ||''')
insert='''    internal async ValueTask ValidateFactAsync(DomainEvent value, CancellationToken ct)
    {
        var fact = RiskEvaluationNativeFact.Require(value, true);
        var snapshot = await ReadAsync(fact.TenantId, fact.ProgramId, fact.RiskId, ct).ConfigureAwait(false);
        var stored = snapshot.Facts.SingleOrDefault(candidate => candidate is IRiskEvaluationFact native &&
            native.Revision == fact.Revision && native.NativeSequence == fact.NativeSequence)
            ?? throw new ImmutableContentUnavailableException("The exact evaluation projection source is not visible yet.");
        if (!RiskEvaluationNativeFact.SameSource(value, stored))
            throw new ImmutableContentIntegrityException("The projected evaluation differs from its exact committed native fact.");
    }
'''
s=s.replace('''    internal async ValueTask<RiskEvaluationReadSnapshot> ReadAsync''',insert+'''    internal async ValueTask<RiskEvaluationReadSnapshot> ReadAsync''');p.write_text(s)
p=d/'FitzRiskEvaluationDirectory.cs';s=p.read_text();start=s.index('        if (_batchTenant != fact.TenantId');end=s.index('        var prior =',start)
s=s[:start]+'''        RiskEvaluationNativeFact.Require(value, true);
        if (_batchTenant != fact.TenantId)
            throw new ImmutableContentIntegrityException("An evaluation projection requires its bound tenant.");
        await sources.ValidateFactAsync(value, ct).ConfigureAwait(false);
'''+s[end:];p.write_text(s)
