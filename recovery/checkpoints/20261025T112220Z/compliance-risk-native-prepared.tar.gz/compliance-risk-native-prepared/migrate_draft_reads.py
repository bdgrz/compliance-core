from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work/src/Compliance.Core/Features/Risks')
p=r/'RiskDraftProjectionStore.cs';s=p.read_text().replace(': FitzKvProjectionStore(client, address, name)',': FitzKvProjectionStore(client, address, name), IProjectionStore');p.write_text(s)
# Projectors expose existing APIs; expected immutable failures stop at the request result boundary.
for name,method,result in [('RiskDraftReadConsistency','GetAsync','RiskDraftView'),('RiskDraftHistoryReadConsistency','EnsureAsync',None),('GetRiskDraftRevisionHandler','HandleAsync','RiskDraftRevisionView'),('ListRiskDraftsHandler','HandleAsync','Page<RiskDraftView>'),('ListRiskDraftRevisionsHandler','HandleAsync','Page<RiskDraftRevisionView>')]:
 p=r/(name+'.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s
 a=s.index('    {',s.index(method))+5;b=s.rfind('\n    }');body=s[a:b]
 s=s[:a]+'\n        try\n        {'+''.join('\n    '+line for line in body.split('\n')[1:])+'\n        }\n        catch (ImmutableContentIntegrityException failure)\n        {\n            return '+('Result' if result is None else 'Result<'+result+'>')+'.Failure(RiskDraftReadFailure.Of(failure));\n        }'+s[b:]
 if name=='RiskDraftReadConsistency':s=s.replace('view.Revision >= source.Revision','view.Revision == source.Revision')
 if name=='GetRiskDraftRevisionHandler':s=s.replace('revision.ProgramId == request.ProgramId && revision.RiskId == request.RiskId','revision.ProgramId == request.ProgramId && revision.RiskId == request.RiskId && revision.Revision == request.Revision')
 p.write_text(s)
