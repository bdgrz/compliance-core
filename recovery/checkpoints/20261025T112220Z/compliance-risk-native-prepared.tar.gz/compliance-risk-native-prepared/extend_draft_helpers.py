from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work')
p=r/'src/Compliance.Core/Features/Risks/RiskDraftReader.cs';s=p.read_text();a=s.index('    public async ValueTask<RiskDraftReadSnapshot> ReadAsync');s=s[:a]+'''    public async ValueTask<RiskDraftReadSnapshot> ReadAsync(Uuid tenant, Uuid risk, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new RiskDraft(tenant, risk), ct).ConfigureAwait(false);
        return await ReadAsync(owner, owner.ProgramId, ct).ConfigureAwait(false);
    }
    public async ValueTask<RiskDraftRules> RulesAsync(Uuid tenant, Uuid risk, CancellationToken ct = default) =>
        (await ReadAsync(tenant, risk, ct).ConfigureAwait(false)).Rules;
    public async ValueTask<RiskDraftRules> RulesAsync(Uuid tenant, Uuid program, Uuid risk, CancellationToken ct = default) =>
        (await ReadAsync(tenant, program, risk, ct).ConfigureAwait(false)).Rules;
'''+s[a:];p.write_text(s)
p=r/'test/Compliance.Tests/Testing/RiskDraftSeeds.cs';s=p.read_text().replace('foreach (var change in source.PendingChanges.ToArray())','foreach (var change in (reader is null ? source.AppliedChanges : source.PendingChanges).ToArray())');p.write_text(s)
p=r/'test/Compliance.Tests/Testing/RiskDraftSourceFixture.cs';s=p.read_text();a=s.index('    public async Task<IReadOnlyList<DomainEvent>> FactsAsync');s=s[:a]+'''    public async Task<IReadOnlyList<DomainEvent>> PublishAsync(RiskDraftRules rules)
    {
        var before = (await FactsAsync(rules.TenantId, rules.Id)).Count;
        await RiskDraftSeeds.AppendAsync(Reader, Writer, Content, rules);
        return (await FactsAsync(rules.TenantId, rules.Id)).Skip(before).ToArray();
    }
'''+s[a:];p.write_text(s)
p=r/'test/Compliance.Tests/Testing/ProgramManagementServices.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.Risks;\n'+s;s=s.replace('        collection.AddScoped<BoundaryOperations>();','        collection.AddScoped<BoundaryOperations>();\n        collection.AddScoped<RiskDraftReader>();\n        collection.AddScoped<RiskDraftOperations>();\n        collection.AddScoped<RiskEvaluationReader>();\n        collection.AddScoped<RiskEvaluationOperations>();')
a=s.index('    public static ClaimsPrincipal Actor(')
for typ in ['RiskDraft','RiskEvaluation']:
 block=''
 for generic in [False,True]:
  block+='''    public static async Task SeedAsync'''+('<TOut>' if generic else '')+'''(IServiceProvider provider, '''+typ+'''Rules selected,
        Func<'''+typ+'''Rules, Result'''+('<TOut>' if generic else '')+'''> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var rules = await services.GetRequiredService<'''+typ+'''Reader>().RulesAsync(selected.TenantId, selected.Id);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await '''+typ+'''Seeds.AppendAsync(reader, services.GetRequiredService<IAggregateWriter>(), '''+('services.GetRequiredService<IDomainEventReader>(), ' if typ=='RiskEvaluation' else '')+'''services.GetRequiredService<IImmutableContentStore>(), rules);
    }

'''
 block+='''    public static async Task<'''+typ+'''Rules> HydrateAsync(IServiceProvider provider, '''+typ+'''Rules selected)
    {
        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<'''+typ+'''Reader>().RulesAsync(selected.TenantId, selected.Id);
    }

'''
 s=s[:a]+block+s[a:];a+=len(block)
p.write_text(s)
