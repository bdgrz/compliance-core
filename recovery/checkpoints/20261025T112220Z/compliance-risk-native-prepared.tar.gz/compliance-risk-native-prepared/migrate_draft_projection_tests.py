from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work/test/Compliance.Tests/Features/Risks')
p=r/'RiskDraftActorSnapshotTests.cs';s=p.read_text().replace('using System.Text.Json;','using System.Text.Json;\nusing Bdgrz.Compliance.Tests.Testing;')
s=s.replace('public void ShouldSnapshotEachActorDisplayGivenDisplayChangesBetweenEvents()','public async Task ShouldSnapshotEachActorDisplayGivenDisplayChangesBetweenEvents()').replace('        var risk = new RiskDraft(TenantId, riskId);','        await using var native = new RiskDraftSourceFixture();\n        var risk = new RiskDraftRules(TenantId, riskId);',1)
s=s.replace('var events = new AggregateScenario<RiskDraft>(risk).PendingEvents;','await RiskDraftSeeds.WriteAsync(native.Writer, native.Content, risk);\n        var events = await native.FactsAsync(TenantId, riskId);')
s=s.replace('public void ShouldReplayLegacyEventsWithMemberActorGivenEventsWithoutActor()','public async Task ShouldReplayLegacyEventsWithMemberActorGivenEventsWithoutActor()').replace('Deserialize<RiskDraftCreated>','Deserialize<RiskDraftCreatedContent>').replace('Deserialize<RiskDraftRevised>','Deserialize<RiskDraftRevisedContent>')
a=s.index('        var replayed = new AggregateScenario<RiskDraft>');b=s.index('\n\n        // Assert',a)
s=s[:a]+'''        await using var native = new RiskDraftSourceFixture();
        var rules = new RiskDraftRules(TenantId, riskId);
        rules.Apply(created); rules.Apply(revised);
        await RiskDraftSeeds.WriteAsync(native.Writer, native.Content, rules);
        var replayed = await native.Reader.HydrateAsync(new RiskDraft(TenantId, riskId));'''+s[b:];p.write_text(s)
p=r/'RiskDraftActorProjectionTests.cs';s=p.read_text().replace('using System.Text.Json;','using System.Text.Json;\nusing Bdgrz.Compliance.Tests.Testing;')
s=s.replace('var directory = new FitzRiskDraftDirectory(new InMemoryKvClient());','await using var native = new RiskDraftSourceFixture();\n        var directory = new FitzRiskDraftDirectory(new InMemoryKvClient(), native.Content);')
s=s.replace('var directory = new FitzRiskDraftHistoryDirectoryV1(new InMemoryKvClient());','await using var native = new RiskDraftSourceFixture();\n        var directory = new FitzRiskDraftHistoryDirectoryV1(new InMemoryKvClient(), native.Content);')
s=s.replace('"RiskDraftDirectory", LegacyCreated()', 'FitzRiskDraftDirectory.ProjectorName, await NativeCreatedAsync(native, LegacyCreated())').replace('"RiskDraftDirectory",\n            LegacyCreated() with { StoredActor = Process }','FitzRiskDraftDirectory.ProjectorName,\n            await NativeCreatedAsync(native, LegacyCreated() with { StoredActor = Process })')
s=s.replace('"RiskDraftHistoryDirectoryV1", LegacyCreated()', 'FitzRiskDraftHistoryDirectoryV1.ProjectorName, await NativeCreatedAsync(native, LegacyCreated())').replace('"RiskDraftHistoryDirectoryV1",\n            LegacyCreated() with { StoredActor = Process }','FitzRiskDraftHistoryDirectoryV1.ProjectorName,\n            await NativeCreatedAsync(native, LegacyCreated() with { StoredActor = Process })')
s=s.replace('static RiskDraftCreated LegacyCreated() => Assert.IsType<RiskDraftCreated>(', 'static RiskDraftCreatedContent LegacyCreated() => Assert.IsType<RiskDraftCreatedContent>(').replace('ComplianceCoreJsonContext.Default.RiskDraftCreated)', 'ComplianceCoreJsonContext.Default.RiskDraftCreatedContent)')
a=s.index('    static RiskDraftCreatedContent LegacyCreated()');s=s[:a]+'''    static async Task<DomainEvent> NativeCreatedAsync(RiskDraftSourceFixture native, RiskDraftCreatedContent created)
    {
        var rules = new RiskDraftRules(created.TenantId, created.RiskId);
        rules.Apply(created);
        await RiskDraftSeeds.WriteAsync(native.Writer, native.Content, rules);
        return Assert.Single(await native.FactsAsync(created.TenantId, created.RiskId));
    }

'''+s[a:];p.write_text(s)
p=r/'FitzRiskDraftDirectoryTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Tests.Testing;\nusing Cntryl.Portia.Testing;\n'+s;s=s.replace('var directory = new FitzRiskDraftDirectory(new InMemoryKvClient());','await using var native = new RiskDraftSourceFixture();\n        var directory = new FitzRiskDraftDirectory(new InMemoryKvClient(), native.Content);')
s=s.replace('directory.ApplyAsync(Created(tenantId, programId, $"R-{index:D3}"))','directory.ApplyAsync(await CreatedAsync(native, tenantId, programId, $"R-{index:D3}"))').replace('directory.ApplyAsync(Created(tenantId, otherProgramId, "OTHER"))','directory.ApplyAsync(await CreatedAsync(native, tenantId, otherProgramId, "OTHER"))')
a=s.index('        RiskDraftCreated created =');b=s.index('\n        // Act',a)
s=s[:a]+'''        var created = await CreatedAsync(native, tenantId, programId, "R-01");
        var rules = (await native.Drafts.ReadAsync(tenantId, programId, created.RiskId)).Rules;
        var change = new RiskDraftRevisedContent(tenantId, programId, created.RiskId, 3,
            new RiskDraftContent("Provider outage", "Changed", "Service outage", "Management observation"),
            created.ActorMemberId, "Editor", created.ChangedAt.AddMinutes(1));
        rules.Apply(change);
        var invalid = DomainEventSeed.Attach(await RiskDraftSeeds.FreezeAsync(native.Content, rules, change, 3), created.RiskId, 3);
'''+s[b:]
a=s.index('    static CheckpointIdentity Identity');s=s[:a]+'''    static CheckpointIdentity Identity(Uuid tenantId) => new(FitzRiskDraftDirectory.ProjectorName,
        EventStreamPattern.ForPattern(tenantId.ToString(), RiskDraft.Area));

    static async Task<RiskDraftCreated> CreatedAsync(RiskDraftSourceFixture native, Uuid tenantId, Uuid programId, string identifier)
    {
        var rules = new RiskDraftRules(tenantId, RiskDraft.IdFor(tenantId, programId, identifier));
        Assert.True(rules.Create(programId, rules.Id, identifier, new RiskDraftContent("Provider outage", "Provider unavailable",
            "Service outage", "Management observation"), Uuid.CreateVersion4(), "Author",
            new DateTimeOffset(2026, 9, 20, 12, 0, 0, TimeSpan.Zero)).IsSuccess);
        return Assert.IsType<RiskDraftCreated>(Assert.Single(await native.PublishAsync(rules)));
    }
}
''';p.write_text(s)
