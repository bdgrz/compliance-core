using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.Risks;

public sealed class RiskDraftNativePayloadTests
{
    [Fact]
    public void ShouldAcceptMaximumValidEscapedNarrativeGivenCompactRiskDraftStorage()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var risk = new RiskDraft(tenant, RiskDraft.IdFor(tenant, program, "R-ESCAPED"));
        var content = new RiskDraftContent(new string('t', 200), new string('\u0001', 8000), new string('\u0001', 8000), new string('\u0001', 4000));

        // Act
        var result = risk.Create(program, risk.Id, "R-ESCAPED", content, Uuid.CreateVersion4(), "Author", DateTimeOffset.UtcNow);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(1, risk.Revision);
    }
}
