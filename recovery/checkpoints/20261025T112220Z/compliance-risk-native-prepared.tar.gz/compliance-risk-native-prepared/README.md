# Frozen combined native Risk handoff

`handoff.json` is the entry point. `manifest.json` identifies all109 final changed paths, their exact saved-original/final hashes, staged RED hashes and baseline provenance. All70 existing changed paths have nonnull physical originals in `base/`;39 paths are new. Review/integration bytes are in `work/`.

RiskDraft now retains only bounded current identity/actor authority, the immutable current narrative reference, native sequence and one selected native acceptance. RiskEvaluation retains compact current authority and selected acceptance; full assessment/treatment/acceptance history is read composition over real immutable source bodies. Pure transient Rules preserve business validation. No mutable owner history or Aggregate.Current compatibility shim is introduced.

The existing identified command fields remain the wire protocol. Create/revise and assess/treat/accept freeze their original200 typed or plain Unit responses, resolve accepted logical retries before current body/source selection, and preserve current runtime access-grant authorization. Existing provider gap202 protocol remains in place. No Program route patch is needed; keep parent's existing OnNativeResult().WithNativeFirstResponse<T>() hooks exactly once.

Current/history projections store compact identities and immutable refs. Projection admission verifies native root provenance, real committed metadata and actual selected source event/body identity. History readers validate every native source scope and version cut before reading its tenant realm. Missing immutable content remains transient Conflict; malformed verified content is permanent Conflict. Projection rollback, same-owner sequence, exact proof, tenant/program isolation and list fence assertions are retained or expanded. Physical metadata/tail checks stay separate from native/business sequence; see `evaluation-metadata-cuts.json` for selected Portia0.9.1 audit-session semantics and the unrun durable regression.

## Parent execution order

1. Apply `tests-red.patch` to the old Risk API. Run `FullyQualifiedName~RiskDraftNativePayloadTests|FullyQualifiedName~RiskEvaluationCompactionTests` and record the expected actual failures: maximum valid escaped Draft text rejected by the old raw event byte cap; old Evaluation owner retains history/raw narrative facts.
2. Apply `implementation.patch`, `shared.patch`, `migrated-tests.patch`, then `native-tests.patch`. Run focused filters from `handoff.json`, including actual production-host `RiskDraftHttpTests`, then the required backend suite with `Category!=BrokerIntegration`.
3. Parent runs format/build/analyzers, direct per-file Jev review of exact final hashes, fixes any actual failures and performs Git/GitHub delivery. No such checks were run by this preparation agent.

If RED has already been captured on the exact old API, `implementation.patch`, `shared.patch`, `tests-full.patch` reconstruct the same109 final files. Both sequences were independently applied with the system patch tool in isolated `/tmp` trees and matched final bytes exactly; see `reconstruction.json`.

Apply only shared delta hunks. Their saved originals snapshot parent's dirty HTTP/TypeII/Commitment/Boundary integration. Keep all newer parent branches while composing these three files. The latest combined reserved fixture bytes include both Evaluation and Draft migrations; do not substitute eval-only snapshots.

`wiring.json` records constructor deltas, scoped services, JSON roots and V2 projector names. `audit.json` records static C# parsing,191 explicit constructor calls, token-last signatures, duplicate/import checks,119 preserved original acceptance names and no per-file assertion drops. The sole syntax flag is byte-equivalent preexisting tree-sitter grammar around the dynamic `[field]` initializer in DraftReadLeakMatrixE2ETests. Compiler/runtime qualification remains parent-owned.

No main checkout, build, broker, Git, worktree, GitHub, Jev, issue or memory mutations were performed. Native facts explicitly use v2 discriminators; persisted v1 upgrade/replay and broker qualification are not asserted. Remaining evidence boundaries and selected out-of-scope source-use contracts are recorded locally in `LOCAL-BLOCKERS.md`.
