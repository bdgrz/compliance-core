from pathlib import Path
import json,re,hashlib
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-risk-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()))
paths=(r/'evaluation-owned-paths.txt').read_text().splitlines()
new=[str(f.relative_to(r/'work')) for d in ['src/Compliance.Common/Features/Risks','src/Compliance.Core/Features/Risks','test/Compliance.Tests/Testing','test/Compliance.Tests/Features/Risks'] for f in (r/'work'/d).glob('*.cs') if f.name.startswith(('RiskEvaluation','RiskAssessmentRecordedBody','RiskTreatmentChosenBody','RiskAcceptedBody','FrozenRiskEvaluation','IRiskEvaluationFact'))]
new += ['src/Compliance.Common/Features/Risks/'+name+'.cs' for name in ['RecordRiskAssessment','ChooseRiskTreatment','AcceptRisk']]
paths=list(dict.fromkeys(paths+new));(r/'evaluation-owned-paths.txt').write_text('\n'.join(paths)+'\n')
def walk(n):
 pending=[n]
 while pending:
  x=pending.pop();yield x;pending.extend(reversed(x.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
def signature(t,n):
 ps=[x for x in n.children if x.type=='parameter'];return(sum('=' not in tx(t,x) for x in ps),len(ps))
def defs(t):
 out={}
 for n in walk(parser.parse(t).root_node):
  if n.type not in {'class_declaration','record_declaration','struct_declaration'}:continue
  nm=n.child_by_field_name('name');pl=next((x for x in n.children if x.type=='parameter_list'),None)
  if nm and pl:out.setdefault(tx(t,nm),[]).append(signature(t,pl))
  body=n.child_by_field_name('body')
  if nm and body:
   for c in body.children:
    if c.type=='constructor_declaration':
     pl=next((x for x in c.children if x.type=='parameter_list'),None)
     if pl:out.setdefault(tx(t,nm),[]).append(signature(t,pl))
 return out
sources={}
for root in [repo,Path('/tmp/compliance-s32-commitment-prepared/after'),Path('/tmp/compliance-commitment-consumers-prepared/after'),Path('/tmp/compliance-s32-boundary-prepared/after'),Path('/tmp/compliance-boundary-consumers-prepared/after'),Path('/tmp/compliance-system-description-prepared/work'),r/'work']:
 for d in ['src','test']:
  for f in (root/d).rglob('*.cs'):
   if not {'bin','obj'}.intersection(f.parts):sources[str(f.relative_to(root))]=f
selected={'RiskEvaluation','RiskEvaluationRules','RiskEvaluationReadSnapshot','RiskEvaluationReader','RiskEvaluationOperations','RiskEvaluationCurrentAuthority','RiskEvaluationAuthorityHeader','RiskEvaluationDirectoryIdentity','RecordRiskAssessmentHandler','ChooseRiskTreatmentHandler','AcceptRiskHandler','FitzRiskEvaluationDirectory','RiskEvaluationReadConsistency','GetRiskGovernanceHandler','LinkFindingAcceptanceHandler','LinkProviderCoverageGapRiskAcceptanceHandler','RiskAcceptanceWorkItemDirectory','RiskAssessmentRecorded','RiskTreatmentChosen','RiskAccepted'}
known={}
for p,f in sources.items():
 if p.startswith('src/'):
  t=f.read_bytes()
  if any(n.encode() in t for n in selected):known.update({n:sig for n,sig in defs(t).items() if n in selected})
syntax=[];removed=[];drops=[];baseline=[];originalNames=0;newNames=[];tokenOrder=[]
for p in paths:
 f=r/'work'/p
 if not f.exists():continue
 t=f.read_bytes();b=r/'base'/p
 if parser.parse(t).root_node.has_error:syntax.append(p)
 for node in walk(parser.parse(t).root_node):
  if node.type != 'parameter_list':continue
  parameters=[x for x in node.children if x.type=='parameter']
  for index,parameter in enumerate(parameters):
   typ=parameter.child_by_field_name('type')
   if typ and tx(t,typ).split('.')[-1]=='CancellationToken' and index != len(parameters)-1:
    tokenOrder.append({'path':p,'line':t[:parameter.start_byte].count(b'\n')+1})
 if (repo/p).exists() and not b.exists():baseline.append(p)
 if b.exists() and p.startswith('test/'):
  old=b.read_text();names=re.findall(r'\b(Should\w+)\s*\(',old);originalNames+=len(names);now=re.findall(r'\b(Should\w+)\s*\(',t.decode());removed.extend({'path':p,'name':n} for n in names if n not in now);newNames.extend({'path':p,'name':n} for n in now if n not in names)
  if t.count(b'Assert.')<old.count('Assert.'):drops.append({'path':p,'before':old.count('Assert.'),'after':t.count(b'Assert.')})
 elif p.startswith('test/'):newNames.extend({'path':p,'name':n} for n in re.findall(r'\b(Should\w+)\s*\(',t.decode()))
errors=[];count=0
for p,f in sources.items():
 t=f.read_bytes()
 if not any(n.encode() in t for n in selected):continue
 tree=parser.parse(t);local=defs(t)
 aliasRules=b'using RiskEvaluation = Bdgrz.Compliance.Features.Risks.RiskEvaluationRules;' in t
 for n in walk(tree.root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((c for c in n.children if c.type=='argument_list'),None)
  if not typ or not args:continue
  name=tx(t,typ).split('.')[-1]
  if aliasRules and name=='RiskEvaluation':name='RiskEvaluationRules'
  if name not in known:continue
  num=sum(c.type=='argument' for c in args.children);count+=1;expected=local.get(name,known[name])
  if not any(a<=num<=b for a,b in expected):errors.append({'path':p,'line':t[:n.start_byte].count(b'\n')+1,'type':name,'args':num,'expected':expected})
a={'qualification':'Static C# syntax, explicit constructor arity and original acceptance names/assertion counts only. No compiler, runtime, HTTP or Jev proof.','paths':len(paths),'syntaxErrors':syntax,'constructorCallsAcrossEffectiveTree':count,'constructorErrors':errors,'cancellationTokenNotLast':tokenOrder,'originalAcceptanceNames':originalNames,'removedAcceptanceNames':removed,'assertionCountDrops':drops,'existingRepositoryPathsMissingBefore':baseline,'newAcceptanceNames':newNames}
(r/'evaluation-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))
