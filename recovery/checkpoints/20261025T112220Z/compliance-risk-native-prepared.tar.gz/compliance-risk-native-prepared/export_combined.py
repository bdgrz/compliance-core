from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
r=Path('/tmp/compliance-risk-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(data):return hashlib.sha256(data).hexdigest()
def diff(path,before,after):return ''.join(difflib.unified_diff((before or b'').decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+path if before is not None else '/dev/null',tofile='b/'+path))
shared={'src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/Features/Work/WorkQueueReader.cs'}
red={'test/Compliance.Tests/Features/Risks/RiskDraftNativePayloadTests.cs':(r/'draft-behavioral-red.cs').read_bytes(),'test/Compliance.Tests/Features/Risks/RiskEvaluationCompactionTests.cs':(r/'evaluation-old-api-red.cs').read_bytes()}
files={}
provenance={x['path']:x for name in ['draft-baselines.json','evaluation-baselines.json','shared-baselines.json'] for x in json.loads((r/name).read_text())}
for f in sorted((r/'work').rglob('*.cs')):
 path=str(f.relative_to(r/'work'));b=r/'base'/path;before=b.read_bytes() if b.exists() else None;after=f.read_bytes()
 if before==after:continue
 assert not (repo/path).exists() or before is not None,'Existing repository path has no saved original: '+path
 assert after.endswith(b'\n') and b'\r\n' not in after,path
 if path in provenance and before is not None:assert provenance[path]['beforeSha256']==sha(before),path
 files[path]={'before':before,'after':after}
assert set(red)<=set(files)
groups={n:[] for n in ['tests-red.patch','implementation.patch','shared.patch','migrated-tests.patch','native-tests.patch','tests-full.patch']}
for path,data in red.items():assert files[path]['before'] is None;groups['tests-red.patch'].append(diff(path,None,data))
manifest=[]
for path,value in files.items():
 before=value['before'];after=value['after'];test=path.startswith('test/');newTest=before is None and test and (b'[Fact]' in after or b'[Theory]' in after) and path not in red
 phase='shared.patch' if path in shared else 'native-tests.patch' if newTest else 'migrated-tests.patch' if test else 'implementation.patch'
 groups[phase].append(diff(path,red.get(path,before),after))
 if test:groups['tests-full.patch'].append(diff(path,before,after))
 origin=provenance.get(path)
 manifest.append({'path':path,'phase':phase,'beforeSha256':sha(before) if before is not None else None,'afterSha256':sha(after),'redBeforeSha256':sha(red[path]) if path in red else None,'baselineSource':origin['baselineSource'] if origin else None,'originalExistsInRepository':(repo/path).exists()})
for name,pieces in groups.items():(r/name).write_text(''.join(pieces))
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
sequences={'all-final':['implementation.patch','shared.patch','tests-full.patch'],'tests-first':['tests-red.patch','implementation.patch','shared.patch','migrated-tests.patch','native-tests.patch']}
verified={}
for name,order in sequences.items():
 target=Path(tempfile.mkdtemp(prefix='combined-reconstruct-',dir=r))
 try:
  for path,value in files.items():
   if value['before'] is not None:
    f=target/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(value['before'])
  for patch in order:
   result=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/patch)],cwd=target,capture_output=True,text=True);assert result.returncode==0,(name,patch,result.stdout,result.stderr)
  bad=[p for p,v in files.items() if not (target/p).exists() or (target/p).read_bytes()!=v['after']];assert not bad,(name,bad)
  verified[name]={'patchOrder':order,'exactFiles':len(files)}
 finally:shutil.rmtree(target)
(r/'reconstruction.json').write_text(json.dumps(verified,indent=2)+'\n')
audit=json.loads((r/'audit.json').read_text())
assert not audit['constructorErrors'] and not audit['cancellationTokenNotLast'] and not audit['duplicateUsings'] and not audit['potentialMissingProofsUsing'] and not audit['removedAcceptanceNames'] and not audit['assertionCountDrops'] and not audit['existingRepositoryPathsMissingBefore'],audit
assert all(x['unchangedBaselineGrammar'] for x in audit['syntaxErrors'])
handoff={'root':str(r),'status':'Combined RiskDraft/RiskEvaluation native owner + consumer + shared wiring preparation frozen offline. Parent owns runtime RED/GREEN, build/analyzers, tests, direct Jev per-file review, integration and delivery.','changedFiles':len(files),'implementationFiles':sum(not p.startswith('test/') and p not in shared for p in files),'testFiles':sum(p.startswith('test/') for p in files),'sharedFiles':len(shared),'existingPathsWithOriginals':sum(v['before'] is not None for v in files.values()),'newPaths':sum(v['before'] is None for v in files.values()),'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in groups},'allFinalOrder':sequences['all-final'],'testsFirstOrder':sequences['tests-first'],'oldApiRedFilter':'FullyQualifiedName~RiskDraftNativePayloadTests|FullyQualifiedName~RiskEvaluationCompactionTests','oldApiExpectedFailures':['ShouldAcceptMaximumValidEscapedNarrativeGivenCompactRiskDraftStorage: previous raw event byte budget rejects maximum valid escaped decoded content.','ShouldKeepOwnerAuthorityBoundedGivenLongAssessmentHistory: previous owner retains mutable history and raw assessment body facts exceed compact bound.'],'nativeFocusedFilter':'FullyQualifiedName~RiskDraftNative|FullyQualifiedName~RiskDraftHttpTests|FullyQualifiedName~RiskEvaluationCompactionTests|FullyQualifiedName~RiskEvaluationNativeSourceTests|FullyQualifiedName~RiskDraftCreationIdentityTests|FullyQualifiedName~RiskDraftRevisionIdentityTests|FullyQualifiedName~RiskAssessmentIdentityTests|FullyQualifiedName~RiskTreatmentIdentityTests|FullyQualifiedName~RiskAcceptanceIdentityTests|FullyQualifiedName~FitzRisk','consumerFocusedFilter':'FullyQualifiedName~Risk|FullyQualifiedName~Provider|FullyQualifiedName~WorkSourceCompositionTests|FullyQualifiedName~ReviewerWorkAuthorityTests|FullyQualifiedName~AttestRiskManagementWriteWallTests|FullyQualifiedName~PolicyAcknowledgementIndependenceTests','suiteFilter':'Category!=BrokerIntegration','staticAudit':'audit.json','exactReconstruction':'reconstruction.json','wiring':'wiring.json','evaluationReview':'evaluation-integrity-review.json','localBlockers':'LOCAL-BLOCKERS.md','originalAcceptanceNames':audit['originalAcceptanceNames'],'constructorCalls':audit['constructorCallsAcrossEffectiveTree'],'dependencyNotes':['Prepared after frozen native Commitment and Boundary layers. Source/test baselines are exact saved file originals with provenance.','Shared DI/JSON/WorkQueueReader baselines snapshot parent current dirty native bridge/TypeII/Commitment/Boundary files. Apply narrow delta hunks; do not replace their full files.','Use latest combined work bytes for all reserved fixtures; eval-only fixture snapshots exclude later Draft migrations.','Keep plain IRequest Unit roots and existing OnNativeResult().WithNativeFirstResponse<T>() hooks; no Program route changes are needed.','No native v1 persistence upgrade/dual-read compatibility or broker qualification is claimed.'],'noRuntimeClaims':True}
(r/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({k:handoff[k] for k in ['changedFiles','implementationFiles','testFiles','sharedFiles','existingPathsWithOriginals','newPaths','manifestSha256','patches']},indent=2))
