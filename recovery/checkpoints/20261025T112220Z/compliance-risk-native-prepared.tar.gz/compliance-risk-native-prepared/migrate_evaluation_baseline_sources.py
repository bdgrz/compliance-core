from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');core=r/'src/Compliance.Core/Features';p=core/'Examinations/RiskTypeIBaselineSourceContributor.cs';s=p.read_text();a=s.index('        await foreach (var record in events.ReadAsync(stream, 0, ct)',s.index('ReadEvaluationHistoryAsync(Uuid'));b=s.index('\n        var source = await reader.HydrateAsync(new RiskEvaluation',a)
s=s[:a]+'''        try
        {
            await foreach (var record in events.ReadAsync(stream, 0, ct).ConfigureAwait(false))
            {
                if (++count > MaximumEventsPerStream || record.Stream != stream || record.Event?.Metadata is not { } metadata ||
                    !ValidMetadata(metadata, riskId, expectedVersion, seenEventIds) || priorRecordedAt is { } prior && metadata.OccurredOn < prior)
                    return InvalidHistory<EvaluationHistory>();
                expectedVersion++;
                priorRecordedAt = metadata.OccurredOn;
                if (metadata.IsAudit)
                    continue;
                if (record.Event is not IRiskEvaluationFact fact || fact.NativeSequence != expectedRevision)
                    return InvalidHistory<EvaluationHistory>();
                var mutation = await RiskEvaluationContent.ReadMutationAsync(content, record.Event, ct).ConfigureAwait(false);
                if (!RiskEvaluationContent.InScope(mutation, fact.Header) ||
                    !TryEvaluationEvent(mutation, tenantId, programId, riskId, expectedRevision, out var occurredAt) || !currentState.Apply(mutation))
                    return InvalidHistory<EvaluationHistory>();
                var isAsOf = occurredAt <= through && metadata.OccurredOn <= through;
                if (isAsOf && excluded)
                    return InvalidHistory<EvaluationHistory>();
                if (isAsOf)
                {
                    if (!asOfState.Apply(mutation)) return InvalidHistory<EvaluationHistory>();
                    asOfEvents.Add(SerializeEvent(record.Event, "risk-evaluations", riskId, metadata));
                }
                else excluded = true;
                expectedRevision++;
            }
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<EvaluationHistory>.Failure(RiskEvaluationReadFailure.Of(failure));
        }
'''+s[b:]
s=s.replace('var source = await reader.HydrateAsync(new RiskEvaluation(tenantId, riskId), ct)\n            .ConfigureAwait(false);','var source = await new RiskEvaluationReader(reader, events, content).ReadAsync(tenantId, programId, riskId, ct).ConfigureAwait(false);')
s=s.replace('static bool TryEvaluationEvent(DomainEvent domainEvent','static bool TryEvaluationEvent(object domainEvent')
a=s.index('    static bool TryEvaluationEvent(');b=s.index('    static ',a+20)
block=s[a:b]
for n in ['RiskAssessmentRecorded','RiskTreatmentChosen','RiskAccepted']:block=block.replace(n,n+'Body')
s=s[:a]+block+s[b:]
a=s.index('    sealed class RiskEvaluationState');block=s[a:].replace('public bool Apply(DomainEvent domainEvent)','public bool Apply(object domainEvent)')
for n in ['RiskAssessmentRecorded','RiskTreatmentChosen','RiskAccepted']:block=block.replace(n,n+'Body')
s=s[:a]+block;p.write_text(s)
p=r/'test/Compliance.Tests/Testing/RiskEvaluationSeeds.cs';s=p.read_text();a=s.index('    static async ValueTask ApplyAsync(');s=s[:a]+'''    public static async ValueTask<RiskEvaluation> OwnerAsync(IImmutableContentStore content, RiskEvaluationRules source,
        CancellationToken ct = default)
    {
        var owner = new RiskEvaluation(source.TenantId, source.Id);
        await ApplyAsync(owner, new RiskEvaluationRules(source.TenantId, source.Id), source.AppliedChanges, content, ct);
        return owner;
    }
'''+s[a:];p.write_text(s)
p=r/'test/Compliance.Tests/Features/Examinations/RiskTypeIBaselineSourceContributorTests.cs';s=p.read_text().replace('var evaluation = new RiskEvaluation(TenantId, RiskId);','var evaluation = new RiskEvaluationRules(TenantId, RiskId);');s=s.replace('var evaluationEvents = new AggregateScenario<RiskEvaluation>(evaluation)\n                .PendingEvents.ToArray();','var evaluationOwner = await RiskEvaluationSeeds.OwnerAsync(content, evaluation);\n            var evaluationEvents = new AggregateScenario<RiskEvaluation>(evaluationOwner).PendingEvents.ToArray();');s=s.replace('DomainEvent stamped = new RiskAssessmentRecorded(recorded.TenantId,\n                    recorded.ProgramId, recorded.RiskId, recorded.Revision, recorded.Assessment);','DomainEvent stamped = recorded with { };');p.write_text(s)
