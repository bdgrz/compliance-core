from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');common=r/'src/Compliance.Common/Features/Risks';core=r/'src/Compliance.Core/Features/Risks'
def write(root,name,text):p=root/(name+'.cs');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
write(common,'RiskEvaluationAuthorityHeader','''using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
/// <summary>Bounded current identity and hashes of source-composed history; no authored bodies or history are owner state.</summary>
public sealed record RiskEvaluationAuthorityHeader(Uuid TenantId, Uuid ProgramId, Uuid RiskId, long Revision,
    Uuid? InherentAssessmentId, Uuid? InherentMethodVersionId, Uuid? ResidualAssessmentId, string? TreatmentKind,
    Uuid? LatestAcceptanceId, long AssessmentCount, long AcceptanceCount, string ViewSha256);
''')
write(common,'IRiskEvaluationFact','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
public interface IRiskEvaluationFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid ProgramId { get; }
    Uuid RiskId { get; }
    long Revision { get; }
    long NativeSequence { get; }
    RiskEvaluationAuthorityHeader Header { get; }
    ImmutableContentRef ChangeContent { get; }
    ImmutableContentRef CurrentAuthorityContent { get; }
    ImmutableContentRef? OperationResult { get; }
}
''')
for name,disc in [('RiskAssessmentRecorded','bdgrz.risk.assessment.recorded'),('RiskTreatmentChosen','bdgrz.risk.treatment.chosen'),('RiskAccepted','bdgrz.risk.accepted')]:
 write(common,name,f'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
[Discriminator("{disc}", 2)]
public sealed record {name}(Uuid TenantId, Uuid ProgramId, Uuid RiskId, long Revision, long NativeSequence,
    RiskEvaluationAuthorityHeader Header, ImmutableContentRef ChangeContent, ImmutableContentRef CurrentAuthorityContent,
    OperationProvenance Operation, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult)
    : DomainEvent, IRiskEvaluationFact;
''')
write(core,'RiskEvaluationCurrentAuthority','''using Bdgrz.Compliance.Features.AccessControl;
namespace Bdgrz.Compliance.Features.Risks;
/// <summary>Three current assessment slots and the current decisions, stored as immutable content.</summary>
public sealed record RiskEvaluationCurrentAuthority(RiskAssessmentView? Inherent, RiskAssessmentView? Target,
    RiskAssessmentView? Residual, RiskTreatmentView? Treatment, RiskAcceptanceView? LatestAcceptance,
    ActorReference? LastChangedBy, DateTimeOffset? LastChangedAt);
''')
for name,view,field in [('RiskAssessmentRecorded','RiskAssessmentView','Assessment'),('RiskTreatmentChosen','RiskTreatmentView','Treatment'),('RiskAccepted','RiskAcceptanceView','Acceptance')]:
 extra='''    public long? OriginalExpectedRevision { get; init; }
    public string? AuthoredIntentSha256 { get; init; }
'''
 if name=='RiskAssessmentRecorded':extra+='    public RiskMethodVersionView? Method { get; init; }\n    public bool HasAcceptedControlTreatment { get; init; }\n'
 if name=='RiskTreatmentChosen':extra+='    public Uuid? CommandId { get; init; }\n'
 if name=='RiskAccepted':extra+='    public RiskMethodVersionView? Method { get; init; }\n    public bool ApproverHoldsAuthority { get; init; }\n    public Uuid? OwnerMemberId { get; init; }\n    public SeparationOfDutiesWaiverProof? WaiverProof { get; init; }\n'
 write(core,name+'Body',f'''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
public sealed record {name}Body(Uuid TenantId, Uuid ProgramId, Uuid RiskId, long Revision, {view} {field})
{{
{extra}}}
''')
write(core,'FrozenRiskEvaluationMutation','''using Bdgrz.Compliance.Features.Proofs;
namespace Bdgrz.Compliance.Features.Risks;
public sealed record FrozenRiskEvaluationMutation(RiskEvaluationView Before, RiskEvaluationView After,
    RiskEvaluationAuthorityHeader Header, ImmutableContentRef Change, ImmutableContentRef CurrentAuthority,
    object Mutation, string CommandKind);
''')
# Move the unchanged business rules out of Aggregate; their full history exists only in transient read/preparation state.
s=(core/'RiskEvaluation.cs').read_text();s=s.replace('public sealed class RiskEvaluation : Aggregate','public sealed class RiskEvaluationRules')
for n in ['RiskAssessmentRecorded','RiskTreatmentChosen','RiskAccepted']:s=s.replace(n,n+'Body')
s=s.replace('DomainEvent? _selectedFact;','object? _selectedFact;').replace('void Observe(Uuid? logicalId, DomainEvent fact)','void Observe(Uuid? logicalId, object fact)')
s=s.replace('public RiskEvaluation(Uuid tenantId, Uuid riskId, Uuid selectedLogicalId = default)\n        : base(riskId, new EventStreamAddress(tenantId.ToString(), "risk-evaluations",\n            riskId.ToString()))','public RiskEvaluationRules(Uuid tenantId, Uuid riskId, Uuid selectedLogicalId = default)')
s=s.replace('        _tenantId = tenantId;','        Id = riskId;\n        _tenantId = tenantId;',1)
s=s.replace('    public long Revision { get; private set; }','''    public Uuid Id { get; }
    public Uuid TenantId => _tenantId;
    public long SourceNativeSequence { get; internal set; }
    public ulong SourcePhysicalPosition { get; internal set; }
    readonly Dictionary<Type, Action<object>> _reducers = [];
    readonly List<object> _applied = [];
    readonly List<object> _pending = [];
    public IReadOnlyList<object> AppliedChanges => _applied;
    public IReadOnlyList<object> PendingChanges => _pending;
    void On<T>(Action<T> apply) => _reducers.Add(typeof(T), value => apply((T)value));
    public void Apply(object value)
    {
        _reducers[value.GetType()](value);
        _applied.Add(value);
    }
    public void RaiseEvent(object value) { Apply(value); _pending.Add(value); }
    public void ClearPendingChanges() => _pending.Clear();
    public long Revision { get; private set; }''')
s=s.replace('            OriginalExpectedRevision = expectedRevision,\n            AuthoredIntentSha256 = AuthoredIntentDigest.Compute(authored),','            OriginalExpectedRevision = expectedRevision,\n            AuthoredIntentSha256 = AuthoredIntentDigest.Compute(authored),\n            Method = method,\n            HasAcceptedControlTreatment = hasAcceptedControlTreatment,',1)
a=s.index('RaiseEvent(new RiskAcceptedBody');s=s[:a]+s[a:].replace('            WaiverProof = waiver,','            WaiverProof = waiver,\n            Method = method,\n            ApproverHoldsAuthority = approverHoldsAuthority,\n            OwnerMemberId = ownerMemberId,',1)
a=s.index('    CommandFailure? CheckScope(')
s=s[:a]+'''    public static RiskEvaluationRules FromView(RiskEvaluationView view)
    {
        var rules = new RiskEvaluationRules(view.TenantId, view.RiskId);
        rules.ProgramId = view.ProgramId;
        rules.Revision = view.Revision;
        rules.Treatment = view.Treatment;
        rules._lastChangedBy = view.LastChangedBy;
        rules._lastChangedAt = view.LastChangedAt;
        foreach (var assessment in view.Assessments)
            rules._assessments.Add(new RiskAssessmentRecordedBody(view.TenantId, view.ProgramId, view.RiskId, 0, assessment));
        foreach (var acceptance in view.Acceptances)
        {
            rules._acceptances.Add(acceptance);
            rules._acceptanceFacts.Add(acceptance.AcceptanceId, new RiskAcceptedBody(view.TenantId, view.ProgramId, view.RiskId, 0, acceptance));
        }
        return rules;
    }

'''+s[a:]
write(core,'RiskEvaluationRules',s)
