from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');test=r/'test/Compliance.Tests/Testing';test.mkdir(parents=True,exist_ok=True)
(test/'RiskEvaluationSeeds.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Tests.Testing;
/// <summary>Publishes real immutable native evaluation facts for existing business source fixtures.</summary>
static class RiskEvaluationSeeds
{
    public static async ValueTask<RiskEvaluation> WriteAsync(IAggregateWriter writer, IImmutableContentStore content,
        RiskEvaluationRules source, CancellationToken ct = default)
    {
        var owner = new RiskEvaluation(source.TenantId, source.Id);
        var rules = new RiskEvaluationRules(source.TenantId, source.Id);
        await ApplyAsync(owner, rules, source.AppliedChanges, content, ct);
        await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
        source.ClearPendingChanges(); source.SourceNativeSequence = owner.NativeSequence; source.SourcePhysicalPosition = owner.CommittedStreamPosition;
        return owner;
    }
    public static async ValueTask<RiskEvaluation> AppendAsync(IAggregateReader reader, IAggregateWriter writer, IDomainEventReader events,
        IImmutableContentStore content, RiskEvaluationRules source, CancellationToken ct = default)
    {
        var snapshot = await new RiskEvaluationReader(reader, events, content).ReadAsync(source.TenantId, source.ProgramId, source.Id, ct);
        await ApplyAsync(snapshot.Owner, snapshot.Rules, source.PendingChanges.ToArray(), content, ct);
        await writer.SaveAsync(snapshot.Owner, new RequestDispatchContext(RequestActor.System), ct);
        source.ClearPendingChanges(); source.SourceNativeSequence = snapshot.Owner.NativeSequence; source.SourcePhysicalPosition = snapshot.Owner.CommittedStreamPosition;
        return snapshot.Owner;
    }
    static async ValueTask ApplyAsync(RiskEvaluation owner, RiskEvaluationRules rules, IReadOnlyList<object> changes,
        IImmutableContentStore content, CancellationToken ct)
    {
        foreach (var change in changes)
        {
            var before = rules.ToView(); rules.ClearPendingChanges(); rules.RaiseEvent(change);
            var kind = change switch
            {
                RiskAssessmentRecordedBody => nameof(RecordRiskAssessment),
                RiskTreatmentChosenBody => nameof(ChooseRiskTreatment),
                _ => nameof(AcceptRisk),
            };
            var digest = change switch
            {
                RiskAssessmentRecordedBody value => value.AuthoredIntentSha256!,
                RiskTreatmentChosenBody value => value.AuthoredIntentSha256!,
                RiskAcceptedBody value => value.AuthoredIntentSha256!,
                _ => throw new InvalidOperationException("Another evaluation fixture mutation kind."),
            };
            var operation = OwnerProvenance.For(owner, RiskEvaluationContent.LogicalId(change), kind, RiskEvaluationContent.Actor(change),
                owner.Id.ToString(), unchecked((ulong)before.Revision), digest, RiskEvaluationContent.At(change)) with { FirstOwner = owner.Stream };
            var frozen = await RiskEvaluationContent.FreezeAsync(content, before, rules, kind, ct);
            var response = change switch
            {
                RiskAssessmentRecordedBody value => await NativeContent.FreezeAsync(content, owner.TenantId, RiskEvaluationContent.AssessmentResultSchema, value.Assessment, ct),
                RiskAcceptedBody value => await NativeContent.FreezeAsync(content, owner.TenantId, RiskEvaluationContent.AcceptanceResultSchema, value.Acceptance, ct),
                _ => await NativeContent.FreezeUnitAsync(content, owner.TenantId, ct),
            };
            var first = await FirstResponses.FreezeAsync(content, owner.TenantId.ToString(), response.Response, ct);
            var result = owner.Append(RiskEvaluationContent.Fact(frozen, owner.NativeSequence + 1, operation, first, response.Result),
                frozen, owner.NativeSequence, owner.CommittedStreamPosition);
            Assert.True(result.IsSuccess, result.Error?.Message);
        }
    }
}
''')
(test/'RiskEvaluationSourceFixture.cs').write_text('''using System.Security.Claims;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Risks;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;
namespace Bdgrz.Compliance.Tests.Testing;
sealed class RiskEvaluationSourceFixture : IAsyncDisposable
{
    readonly ServiceProvider _provider;
    readonly AsyncServiceScope _scope;
    public InMemoryEventStore Events { get; } = new();
    public InMemoryKvClient Kv { get; } = new();
    public IImmutableContentStore Content { get; }
    public IAggregateReader Reader { get; }
    public IAggregateWriter Writer { get; }
    public IAggregateExecutor Executor { get; }
    public FixtureClock Clock { get; } = new();
    public RiskEvaluationReader Evaluations { get; }
    public RiskEvaluationSourceFixture()
    {
        Content = new FitzKvImmutableContentStore(Kv);
        var services = new ServiceCollection(); services.AddSingleton<IEventStore>(Events); services.AddPortia();
        _provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true }); _scope = _provider.CreateAsyncScope();
        Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>(); Writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
        Executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>(); Evaluations = new(Reader, Events, Content);
    }
    public RiskEvaluationOperations Operations(IAggregateReader? reader = null, IImmutableContentStore? content = null) => new(reader ?? Reader,
        new RiskEvaluationReader(reader ?? Reader, Events, content ?? Content), new NativeOperationExecutor(reader ?? Reader, Executor, content ?? Content),
        content ?? Content, Clock);
    public ValueTask<RiskEvaluation> SeedAsync(RiskEvaluationRules rules) => RiskEvaluationSeeds.AppendAsync(Reader, Writer, Events, Content, rules);
    public static Cntryl.Portia.RequestContext<T> Context<T>(T request, Uuid user, string display = "Updated member") where T : IRequestBase => new(request,
        new RequestDispatchContext(new ClaimsPrincipal(new ClaimsIdentity([new Claim("iss", "bdgrz"), new Claim("sub", user.ToString()),
            new Claim("name", display)], "UnitTest")), new HttpInvocation("PUT", "/risk", "/risk", "risk-test")));
    public async Task<IReadOnlyList<DomainEvent>> FactsAsync(Uuid tenant, Uuid risk)
    {
        var result = new List<DomainEvent>();
        await foreach (var record in Events.ReadAsync(EventStreamPattern.ForPattern(tenant.ToString(), RiskEvaluation.Area, risk.ToString()), EventCursor.Start))
            if (!record.Event.Metadata.IsAudit) result.Add(record.Event);
        return result;
    }
    public async ValueTask DisposeAsync() { await _scope.DisposeAsync(); await _provider.DisposeAsync(); }
    public sealed class FixtureClock : TimeProvider
    {
        public DateTimeOffset Now { get; set; } = new(2026, 10, 24, 12, 0, 0, TimeSpan.Zero);
        public override DateTimeOffset GetUtcNow() => Now;
    }
}
''')
(test/'RiskEvaluationRulesScenario.cs').write_text('''using Bdgrz.Compliance.Features.Risks;
namespace Bdgrz.Compliance.Tests.Testing;
/// <summary>Exercises the transient business rules over actual structured mutation bodies.</summary>
sealed class RiskEvaluationRulesScenario(RiskEvaluationRules rules)
{
    public RiskEvaluationRules Aggregate => rules;
    public IReadOnlyList<object> PendingEvents => rules.PendingChanges;
    public RiskEvaluationRulesScenario Given(params object[] facts)
    {
        foreach (var fact in facts) rules.Apply(fact);
        rules.ClearPendingChanges(); return this;
    }
}
''')
