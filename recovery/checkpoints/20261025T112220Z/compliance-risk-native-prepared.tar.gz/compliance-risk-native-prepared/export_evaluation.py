from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
r=Path('/tmp/compliance-risk-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
def diff(p,a,b):return ''.join(difflib.unified_diff((a or b'').decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+p if a is not None else '/dev/null',tofile='b/'+p))
paths=(r/'evaluation-owned-paths.txt').read_text().splitlines();files={};missing=[];prov=json.loads((r/'evaluation-baselines.json').read_text());known={x['path'] for x in prov}
for p in paths:
 f=r/'work'/p
 if not f.exists():continue
 old=(r/'base'/p).read_bytes() if (r/'base'/p).exists() else None;new=f.read_bytes()
 if old==new:continue
 if (repo/p).exists() and old is None:missing.append(p)
 if old is not None and p not in known:prov.append({'path':p,'baselineSource':str(repo/p),'beforeSha256':sha(old)});known.add(p)
 files[p]={'old':old,'new':new}
assert not missing,missing
(r/'evaluation-baselines.json').write_text(json.dumps(prov,indent=2)+'\n')
redPath='test/Compliance.Tests/Features/Risks/RiskEvaluationCompactionTests.cs';oldRed=(r/'evaluation-old-api-red.cs').read_bytes()
groups={name:[] for name in ['evaluation-tests-red.patch','evaluation-implementation.patch','evaluation-migrated-tests.patch','evaluation-native-tests.patch','evaluation-tests-full.patch']}
groups['evaluation-tests-red.patch']=[diff(redPath,None,oldRed)]
manifest=[]
for p,v in files.items():
 test=p.startswith('test/');native=p.endswith('RiskEvaluationNativeSourceTests.cs');phase='evaluation-native-tests.patch' if native else 'evaluation-migrated-tests.patch' if test else 'evaluation-implementation.patch'
 groups[phase].append(diff(p,oldRed if p==redPath else v['old'],v['new']))
 if test:groups['evaluation-tests-full.patch'].append(diff(p,v['old'],v['new']))
 manifest.append({'path':p,'phase':phase,'beforeSha256':sha(v['old']) if v['old'] is not None else None,'afterSha256':sha(v['new']),'redBeforeSha256':sha(oldRed) if p==redPath else None})
for name,parts in groups.items():(r/name).write_text(''.join(parts))
(r/'evaluation-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
verified={}
for mode,order in [('final',['evaluation-implementation.patch','evaluation-tests-full.patch']),('tests-first',['evaluation-tests-red.patch','evaluation-implementation.patch','evaluation-migrated-tests.patch','evaluation-native-tests.patch'])]:
 root=Path(tempfile.mkdtemp(prefix='evaluation-reconstruct-',dir=r))
 try:
  for p,v in files.items():
   if v['old'] is not None:
    f=root/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(v['old'])
  for name in order:
   result=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/name)],cwd=root,capture_output=True,text=True);assert result.returncode==0,(name,result.stdout,result.stderr)
  mismatch=[p for p,v in files.items() if not (root/p).exists() or (root/p).read_bytes()!=v['new']];assert not mismatch,(mode,mismatch)
  verified[mode]={'patchOrder':order,'exactFiles':len(files)}
 finally:shutil.rmtree(root)
(r/'evaluation-reconstruction.json').write_text(json.dumps(verified,indent=2)+'\n')
audit=json.loads((r/'evaluation-audit.json').read_text())
h={'root':str(r),'status':'Evaluation slice frozen offline; parent compiles, runs actual RED/GREEN and backend suites, reviews with Jev, integrates and delivers.','changedFiles':len(files),'implementationFiles':sum(not p.startswith('test/') for p in files),'testFiles':sum(p.startswith('test/') for p in files),'allFinalOrder':verified['final']['patchOrder'],'testsFirstOrder':verified['tests-first']['patchOrder'],'oldApiRedFilter':'FullyQualifiedName~RiskEvaluationCompactionTests','expectedOldApiRed':'ShouldKeepOwnerAuthorityBoundedGivenLongAssessmentHistory fails existing raw/history owner collection and compact-frame assertions; parent must run on actual old API before implementation.','nativeFilter':'FullyQualifiedName~RiskEvaluationCompactionTests|FullyQualifiedName~RiskEvaluationNativeSourceTests|FullyQualifiedName~RiskAssessmentIdentityTests|FullyQualifiedName~RiskTreatmentIdentityTests|FullyQualifiedName~RiskAcceptanceIdentityTests|FullyQualifiedName~FitzRiskEvaluationDirectoryTests','focusedFilter':'FullyQualifiedName~RiskEvaluation|FullyQualifiedName~RiskAssessmentIdentityTests|FullyQualifiedName~RiskTreatmentIdentityTests|FullyQualifiedName~RiskAcceptanceIdentityTests|FullyQualifiedName~RiskGovernanceHandlerTests|FullyQualifiedName~RiskAcceptanceWork|FullyQualifiedName~RiskTypeIBaselineSourceContributorTests|FullyQualifiedName~AttestRiskManagementWriteWallTests|FullyQualifiedName~Provider','patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in groups},'staticAudit':'evaluation-audit.json','exactReconstruction':'evaluation-reconstruction.json','baselineProvenance':'evaluation-baselines.json','sourceHashes':'evaluation-manifest.json','existingAcceptanceNames':audit['originalAcceptanceNames'],'sharedWiring':'evaluation-wiring.json','notes':['The 4 reserved fixture files in work contain parent Draft follow-ups after eval migration; final combined parent export must preserve latest work bytes. eval-only snapshots and patch are in evaluation-fixtures-before-draft/ and evaluation-fixture-handoff.patch.','Parent owns shared DI/JSON/Program/WorkQueueReader/ProgramManagementServices wiring and RiskDraft seed helpers.','No main/dotnet/broker/Git/worktree/GitHub/Jev changes or issue creation performed.','Native event contracts RiskAssessmentRecorded/RiskTreatmentChosen/RiskAccepted are explicit v2 compact facts; API result shapes and identified existing command fields are retained. No legacy-v1 stored event qualification is claimed.']}
(r/'evaluation-handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'changedFiles':len(files),'implementationFiles':h['implementationFiles'],'testFiles':h['testFiles'],'patches':h['patches']},indent=2))
