from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');core=r/'src/Compliance.Core/Features/Risks'
def write(n,s):p=core/(n+'.cs');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
write('RiskEvaluationContent','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
public static class RiskEvaluationContent
{
    public const string AuthoritySchema = "risk-evaluation-current-authority.v1";
    public const string AssessmentSchema = "risk-assessment-change.v1";
    public const string TreatmentSchema = "risk-treatment-change.v1";
    public const string AcceptanceSchema = "risk-acceptance-change.v1";
    public const string AssessmentResultSchema = "risk-assessment-result.v1";
    public const string AcceptanceResultSchema = "risk-acceptance-result.v1";
    public static RiskEvaluationAuthorityHeader Header(RiskEvaluationView view) => new(view.TenantId, view.ProgramId, view.RiskId,
        view.Revision, view.Assessments.LastOrDefault(value => value.Phase == RiskEvaluation.Inherent)?.AssessmentId,
        view.Assessments.LastOrDefault(value => value.Phase == RiskEvaluation.Inherent)?.MethodVersionId,
        view.Assessments.LastOrDefault(value => value.Phase == RiskEvaluation.Residual)?.AssessmentId,
        view.Treatment?.Kind, view.Acceptances.LastOrDefault()?.AcceptanceId, view.Assessments.Count, view.Acceptances.Count,
        AuthoredIntentDigest.Compute(view));
    public static RiskEvaluationCurrentAuthority Current(RiskEvaluationView view) => new(
        view.Assessments.LastOrDefault(value => value.Phase == RiskEvaluation.Inherent),
        view.Assessments.LastOrDefault(value => value.Phase == RiskEvaluation.Target),
        view.Assessments.LastOrDefault(value => value.Phase == RiskEvaluation.Residual), view.Treatment,
        view.Acceptances.LastOrDefault(), view.LastChangedBy, view.LastChangedAt);
    public static async ValueTask<FrozenRiskEvaluationMutation> FreezeAsync(IImmutableContentStore content,
        RiskEvaluationView before, RiskEvaluationRules rules, string kind, CancellationToken ct = default)
    {
        if (rules.PendingChanges.Count != 1)
            throw new ImmutableContentIntegrityException("A new evaluation command must produce exactly one local business transition.");
        var mutation = rules.PendingChanges[0];
        var after = rules.ToView();
        var change = mutation switch
        {
            RiskAssessmentRecordedBody value => await NativeContent.WriteAsync(content, rules.TenantId, AssessmentSchema, value, ct).ConfigureAwait(false),
            RiskTreatmentChosenBody value => await NativeContent.WriteAsync(content, rules.TenantId, TreatmentSchema, value, ct).ConfigureAwait(false),
            RiskAcceptedBody value => await NativeContent.WriteAsync(content, rules.TenantId, AcceptanceSchema, value, ct).ConfigureAwait(false),
            _ => throw new ImmutableContentIntegrityException("The evaluation mutation has another selected kind."),
        };
        var authority = await NativeContent.WriteAsync(content, rules.TenantId, AuthoritySchema, Current(after), ct).ConfigureAwait(false);
        return new(before, after, Header(after), change, authority, mutation, kind);
    }
    public static async ValueTask<object> ReadMutationAsync(IImmutableContentStore content, DomainEvent value, CancellationToken ct = default)
    {
        var fact = value as IRiskEvaluationFact ?? throw new ImmutableContentIntegrityException("The source is not one native evaluation fact.");
        return value switch
        {
            RiskAssessmentRecorded when fact.ChangeContent.Schema == AssessmentSchema => await NativeContent.ReadAsync<RiskAssessmentRecordedBody>(content, fact.TenantId, fact.ChangeContent, ct).ConfigureAwait(false),
            RiskTreatmentChosen when fact.ChangeContent.Schema == TreatmentSchema => await NativeContent.ReadAsync<RiskTreatmentChosenBody>(content, fact.TenantId, fact.ChangeContent, ct).ConfigureAwait(false),
            RiskAccepted when fact.ChangeContent.Schema == AcceptanceSchema => await NativeContent.ReadAsync<RiskAcceptedBody>(content, fact.TenantId, fact.ChangeContent, ct).ConfigureAwait(false),
            _ => throw new ImmutableContentIntegrityException("The evaluation source has another exact change schema."),
        };
    }
    public static async ValueTask<RiskAcceptanceView> ReadAcceptanceAsync(IImmutableContentStore content, RiskAccepted value, CancellationToken ct = default) =>
        ((RiskAcceptedBody)await ReadMutationAsync(content, value, ct).ConfigureAwait(false)).Acceptance;
    public static bool Verify(FrozenRiskEvaluationMutation frozen)
    {
        var rules = RiskEvaluationRules.FromView(frozen.Before);
        var failure = frozen.Mutation switch
        {
            RiskAssessmentRecordedBody value when value.Method is not null => rules.RecordAssessment(value.ProgramId, frozen.Before.Revision,
                value.Assessment.AssessmentId, value.Method, value.Assessment.Phase, value.Assessment.Likelihood, value.Assessment.Impact,
                value.Assessment.Rationale, Uuid.Parse(value.Assessment.Assessor.Id), value.Assessment.Assessor.Display,
                value.Assessment.AssessedAt, value.HasAcceptedControlTreatment),
            RiskTreatmentChosenBody value => rules.ChooseTreatment(value.ProgramId, frozen.Before.Revision, value.Treatment.Kind,
                value.Treatment.Rationale, Uuid.Parse(value.Treatment.ChosenBy.Id), value.Treatment.ChosenBy.Display, value.Treatment.ChosenAt,
                value.CommandId, value.AuthoredIntentSha256),
            RiskAcceptedBody value when value.Method is not null => rules.Accept(value.ProgramId, frozen.Before.Revision,
                value.Acceptance.AcceptanceId, value.Acceptance.ResidualAssessmentId, value.Method, value.Acceptance.ApproverAuthority,
                value.ApproverHoldsAuthority, value.Acceptance.ExpiresAt, value.Acceptance.Rationale, value.Acceptance.ApproverMemberId,
                value.Acceptance.Approver.Display, value.Acceptance.AcceptedAt, value.OwnerMemberId, value.WaiverProof),
            _ => throw new ImmutableContentIntegrityException("The evaluation change has no exact rule inputs."),
        };
        return failure is null && rules.PendingChanges.Count == 1 &&
            AuthoredIntentDigest.Compute(rules.ToView()) == AuthoredIntentDigest.Compute(frozen.After) && Header(frozen.After) == frozen.Header;
    }
    public static Uuid LogicalId(object value) => value switch
    {
        RiskAssessmentRecordedBody item => item.Assessment.AssessmentId,
        RiskTreatmentChosenBody item => item.CommandId ?? Uuid.Empty,
        RiskAcceptedBody item => item.Acceptance.AcceptanceId,
        _ => Uuid.Empty,
    };
    public static ActorReference Actor(object value) => value switch
    {
        RiskAssessmentRecordedBody item => item.Assessment.Assessor,
        RiskTreatmentChosenBody item => item.Treatment.ChosenBy,
        RiskAcceptedBody item => item.Acceptance.Approver,
        _ => throw new ImmutableContentIntegrityException("The evaluation mutation has no member actor."),
    };
    public static DateTimeOffset At(object value) => value switch
    {
        RiskAssessmentRecordedBody item => item.Assessment.AssessedAt,
        RiskTreatmentChosenBody item => item.Treatment.ChosenAt,
        RiskAcceptedBody item => item.Acceptance.AcceptedAt,
        _ => default,
    };
    public static DomainEvent Fact(FrozenRiskEvaluationMutation frozen, long sequence, OperationProvenance operation,
        ImmutableContentRef first, ImmutableContentRef result) => frozen.Mutation switch
    {
        RiskAssessmentRecordedBody => new RiskAssessmentRecorded(frozen.Header.TenantId, frozen.Header.ProgramId, frozen.Header.RiskId,
            frozen.Header.Revision, sequence, frozen.Header, frozen.Change, frozen.CurrentAuthority, operation, first, result),
        RiskTreatmentChosenBody => new RiskTreatmentChosen(frozen.Header.TenantId, frozen.Header.ProgramId, frozen.Header.RiskId,
            frozen.Header.Revision, sequence, frozen.Header, frozen.Change, frozen.CurrentAuthority, operation, first, result),
        RiskAcceptedBody => new RiskAccepted(frozen.Header.TenantId, frozen.Header.ProgramId, frozen.Header.RiskId,
            frozen.Header.Revision, sequence, frozen.Header, frozen.Change, frozen.CurrentAuthority, operation, first, result),
        _ => throw new ImmutableContentIntegrityException("The evaluation mutation has another selected native fact."),
    };
}
''')
write('RiskEvaluation','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
/// <summary>One compact risk evaluation owner; immutable history is reconstructed outside command state.</summary>
public sealed class RiskEvaluation : Aggregate
{
    public const string Area = "risk-evaluations";
    public const string Inherent = "inherent";
    public const string Target = "target";
    public const string Residual = "residual";
    public const string ComplianceLead = "compliance_lead";
    public const string Executive = "executive";
    public Uuid TenantId { get; }
    public Uuid ProgramId => Header?.ProgramId ?? Uuid.Empty;
    public long Revision => Header?.Revision ?? 0;
    public long NativeSequence { get; private set; }
    public RiskEvaluationAuthorityHeader? Header { get; private set; }
    public ImmutableContentRef? CurrentAuthority { get; private set; }
    public NativeAcceptance Acceptance { get; }
    public RiskEvaluation(Uuid tenantId, Uuid riskId, Uuid selectedLogicalId = default)
        : base(riskId, new EventStreamAddress(tenantId.ToString(), Area, riskId.ToString()))
    {
        TenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<RiskAssessmentRecorded>(Apply);
        On<RiskTreatmentChosen>(Apply);
        On<RiskAccepted>(Apply);
    }
    public Result Append(DomainEvent value, FrozenRiskEvaluationMutation frozen, long sequence, ulong physicalPosition)
    {
        if (NativeSequence != sequence || CommittedStreamPosition != physicalPosition)
            return Failure("The evaluation changed while its exact authority was prepared.", true);
        if (value is not IRiskEvaluationFact fact || frozen.Before.TenantId != TenantId || frozen.Before.RiskId != Id ||
            (Header is null ? frozen.Before.Revision != 0 : RiskEvaluationContent.Header(frozen.Before) != Header) ||
            frozen.Header != fact.Header || frozen.Change != fact.ChangeContent || frozen.CurrentAuthority != fact.CurrentAuthorityContent ||
            RiskEvaluationContent.LogicalId(frozen.Mutation) != fact.Operation.LogicalId ||
            RiskEvaluationContent.Actor(frozen.Mutation) != fact.Operation.Actor || RiskEvaluationContent.At(frozen.Mutation) != fact.Operation.AcceptedAt ||
            !RiskEvaluationContent.Verify(frozen))
            return Failure("The evaluation mutation differs from its exact verified local transition.");
        try
        {
            Validate(value, fact);
            if (DomainEventPayload.Size(value) > DomainEventPayload.MaximumBytes)
                return Failure("The compact native evaluation fact exceeds the bounded envelope.");
        }
        catch (InvalidOperationException)
        {
            return Failure("The evaluation native provenance is invalid.");
        }
        RaiseEvent(value);
        return Result.Success;
    }
    void Apply(DomainEvent value)
    {
        var fact = (IRiskEvaluationFact)value;
        Validate(value, fact);
        Header = fact.Header;
        CurrentAuthority = fact.CurrentAuthorityContent;
        NativeSequence = fact.NativeSequence;
        Acceptance.Observe(value);
    }
    void Validate(DomainEvent value, IRiskEvaluationFact fact)
    {
        var kind = value switch
        {
            RiskAssessmentRecorded => nameof(RecordRiskAssessment),
            RiskTreatmentChosen => nameof(ChooseRiskTreatment),
            RiskAccepted => nameof(AcceptRisk),
            _ => string.Empty,
        };
        var op = fact.Operation;
        if (kind.Length == 0 || fact.TenantId != TenantId || fact.RiskId != Id || fact.ProgramId == Uuid.Empty ||
            Header is not null && fact.ProgramId != Header.ProgramId || fact.Header.TenantId != TenantId || fact.Header.RiskId != Id ||
            fact.Header.ProgramId != fact.ProgramId || fact.Revision != Revision + 1 || fact.Header.Revision != fact.Revision ||
            fact.NativeSequence != NativeSequence + 1 || fact.FirstResponse is null || fact.OperationResult is null ||
            fact.CurrentAuthorityContent.Schema != RiskEvaluationContent.AuthoritySchema ||
            op.LogicalId == Uuid.Empty || op.LogicalId != op.RootOperationId || op.CausationEventId is not null || op.CommandKind != kind ||
            op.Owner != Stream || op.AffectedOwner != Stream || op.ExpectedRevisionOwner != Stream || op.FirstOwner != Stream ||
            op.Episode != Id.ToString() || op.OriginalExpectedRevision != unchecked((ulong)Revision) ||
            op.Actor.Kind != "member" || !Uuid.TryParse(op.Actor.Id, out var member) || member == Uuid.Empty ||
            op.AcceptedAt == default || op.AuthoredIntentSha256 is not { Length: 64 })
            throw new InvalidOperationException("A native evaluation fact requires its exact owner, sequence, actor and revision binding.");
    }
    static Result Failure(string message, bool transient = false) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
write('RiskEvaluationReadSnapshot','''using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
public sealed record RiskEvaluationReadSnapshot(RiskEvaluation Owner, RiskEvaluationRules Rules, IReadOnlyList<DomainEvent> Facts)
{
    public Uuid Id => Owner.Id;
    public Uuid TenantId => Owner.TenantId;
    public Uuid ProgramId => Owner.ProgramId;
    public long Revision => Owner.Revision;
    public EventStreamAddress Stream => Owner.Stream;
    public RiskTreatmentView? Treatment => Rules.Treatment;
    public RiskEvaluationView ToView() => Rules.ToView();
    public RiskAssessmentView? Latest(string phase) => Rules.Latest(phase);
    public RiskAssessmentView? FindAssessment(Uuid id) => Rules.FindAssessment(id);
    public RiskAcceptanceView? FindAcceptance(Uuid id) => Rules.FindAcceptance(id);
    public RiskAccepted? AcceptanceFact(Uuid id) => Facts.OfType<RiskAccepted>().SingleOrDefault(value => value.Operation.LogicalId == id);
}
''')
write('RiskEvaluationReader','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
/// <summary>Reconstructs exact immutable evaluation history at one hydrated native owner cut.</summary>
public sealed class RiskEvaluationReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async ValueTask<RiskEvaluationReadSnapshot> ReadAsync(Uuid tenant, Uuid risk, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new RiskEvaluation(tenant, risk), ct).ConfigureAwait(false);
        return await ReadAsync(owner, owner.ProgramId, ct).ConfigureAwait(false);
    }
    public async ValueTask<RiskEvaluationReadSnapshot> ReadAsync(Uuid tenant, Uuid program, Uuid risk, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new RiskEvaluation(tenant, risk), ct).ConfigureAwait(false);
        return await ReadAsync(owner, program, ct).ConfigureAwait(false);
    }
    public async ValueTask<RiskEvaluationRules> RulesAsync(Uuid tenant, Uuid program, Uuid risk, CancellationToken ct = default) =>
        (await ReadAsync(tenant, program, risk, ct).ConfigureAwait(false)).Rules;
    internal async ValueTask<RiskEvaluationReadSnapshot> ReadAsync(RiskEvaluation owner, Uuid program, CancellationToken ct)
    {
        var rules = new RiskEvaluationRules(owner.TenantId, owner.Id);
        var facts = new List<DomainEvent>();
        if (owner.Header is null || owner.ProgramId != program)
            return new(owner, rules, facts);
        var sequence = 0L;
        IRiskEvaluationFact? last = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(owner.TenantId.ToString(), RiskEvaluation.Area,
            owner.Id.ToString()), EventCursor.Start, ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit)
                continue;
            if (record.Event is not IRiskEvaluationFact fact || record.Stream != owner.Stream || fact.NativeSequence != sequence + 1 ||
                fact.TenantId != owner.TenantId || fact.ProgramId != program || fact.RiskId != owner.Id)
                throw new ImmutableContentIntegrityException("The evaluation history has another native sequence or exact owner scope.");
            if (fact.NativeSequence > owner.NativeSequence)
                break;
            var mutation = await RiskEvaluationContent.ReadMutationAsync(content, record.Event, ct).ConfigureAwait(false);
            var before = rules.ToView();
            var after = RiskEvaluationRules.FromView(before);
            after.Apply(mutation);
            var frozen = new FrozenRiskEvaluationMutation(before, after.ToView(), fact.Header, fact.ChangeContent, fact.CurrentAuthorityContent,
                mutation, fact.Operation.CommandKind);
            if (!RiskEvaluationContent.Verify(frozen) || RiskEvaluationContent.LogicalId(mutation) != fact.Operation.LogicalId ||
                RiskEvaluationContent.Actor(mutation) != fact.Operation.Actor || RiskEvaluationContent.At(mutation) != fact.Operation.AcceptedAt ||
                fact.CurrentAuthorityContent.Schema != RiskEvaluationContent.AuthoritySchema)
                throw new ImmutableContentIntegrityException("The evaluation body differs from its exact native transition and actor.");
            var authority = await content.ReadJsonAsync<RiskEvaluationCurrentAuthority>(owner.TenantId.ToString(), fact.CurrentAuthorityContent, ct).ConfigureAwait(false);
            if (AuthoredIntentDigest.Compute(authority) != AuthoredIntentDigest.Compute(RiskEvaluationContent.Current(after.ToView())))
                throw new ImmutableContentIntegrityException("The evaluation current authority differs from its exact immutable source.");
            rules.Apply(mutation); facts.Add(record.Event); sequence = fact.NativeSequence; last = fact;
            if (sequence == owner.NativeSequence)
                break;
        }
        if (sequence != owner.NativeSequence || last is null)
            throw new ImmutableContentUnavailableException("The exact evaluation native source cut is not visible yet.");
        if (last.Header != owner.Header || last.CurrentAuthorityContent != owner.CurrentAuthority)
            throw new ImmutableContentIntegrityException("The evaluation read differs from its hydrated compact authority.");
        rules.ClearPendingChanges(); rules.SourceNativeSequence = owner.NativeSequence; rules.SourcePhysicalPosition = owner.CommittedStreamPosition;
        return new(owner, rules, facts.AsReadOnly());
    }
}
''')
write('RiskEvaluationReadFailure','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
public static class RiskEvaluationReadFailure
{
    public static RequestError Of(ImmutableContentIntegrityException error) => new(RequestErrorKind.Conflict,
        "The risk evaluation's exact immutable source cannot be verified.", error is ImmutableContentUnavailableException);
}
''')
