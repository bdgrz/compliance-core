from pathlib import Path
import json,hashlib
r=Path('/tmp/compliance-risk-native-prepared');d=r/'work/src/Compliance.Core/Features/Risks'
p=d/'RiskEvaluationNativeFact.cs';s=p.read_text().replace('metadata.AggregateVersion != unchecked((ulong)fact.Revision)','metadata.AggregateVersion == 0');p.write_text(s)
p=d/'RiskEvaluationReader.cs';s=p.read_text().replace('''        var sequence = 0L;
''','''        var sequence = 0L;
        var physicalOffset = 0UL;
        ulong? previousMetadataVersion = null;
''');s=s.replace('''            if (record is null || record.Stream != owner.Stream || record.Event is null)
''','''            if (record is null || record.Stream != owner.Stream || record.Event is null || record.ResourceOffset != physicalOffset)
''');s=s.replace('''            if (metadata.IsAudit)
                continue;
''','''            if (metadata.OccurredOn == default || previousMetadataVersion is { } previous &&
                (metadata.AggregateVersion < previous || !metadata.IsAudit && metadata.AggregateVersion == previous))
                throw new ImmutableContentIntegrityException("The evaluation source metadata does not advance independently in physical record order.");
            previousMetadataVersion = metadata.AggregateVersion;
            physicalOffset = checked(physicalOffset + 1);
            if (metadata.IsAudit)
                continue;
''');p.write_text(s)
p=r/'work/test/Compliance.Tests/Features/Risks/RiskEvaluationNativeSourceTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.UserIdentities;\n'+s
needle='''    static async Task<(Uuid Tenant, Uuid Program, Uuid Risk, IReadOnlyList<DomainEvent> Facts)> HistoryAsync'''
insert='''    [Fact]
    public async Task ShouldKeepNativeAuthorityCutGivenDurableIndependentAuditSession()
    {
        // Arrange
        await using var source = new RiskEvaluationSourceFixture();
        var (tenant, program, risk, _) = await HistoryAsync(source);
        var before = await source.Evaluations.ReadAsync(tenant, program, risk);
        var probe = await source.Reader.HydrateAsync(new AuditProbe(tenant, risk));

        // Act
        probe.RecordAudit();
        await source.Writer.SaveAsync(probe, new RequestDispatchContext(RequestActor.System));
        var records = new List<DomainEventRecord>();
        await foreach (var record in source.Events.ReadAsync(EventStreamPattern.ForPattern(tenant.ToString(), RiskEvaluation.Area), EventCursor.Start))
            records.Add(record);
        var after = await source.Evaluations.ReadAsync(tenant, program, risk);

        // Assert
        var audit = Assert.Single(records.Where(record => record.Event.Metadata.IsAudit));
        Assert.NotEqual(before.Stream, audit.Stream);
        Assert.Equal(before.Owner.Version, audit.Event.Metadata.AggregateVersion);
        Assert.Equal(before.Revision, after.Revision);
        Assert.Equal(before.Owner.NativeSequence, after.Owner.NativeSequence);
        Assert.Equal(before.Owner.CommittedStreamPosition, after.Owner.CommittedStreamPosition);
        Assert.Equal(2, after.Facts.Count);
        Assert.Equal(3, records.Count);
    }

    sealed class AuditProbe : Aggregate
    {
        public AuditProbe(Uuid tenant, Uuid risk) : base(risk, new EventStreamAddress(tenant.ToString(), RiskEvaluation.Area, risk.ToString()))
        {
            On<RiskAssessmentRecorded>(_ => { });
            On<RiskTreatmentChosen>(_ => { });
        }
        public void RecordAudit() => AuditEvent(new UserIdentityAuthenticated(Id, "native-risk-test", "audit-session"));
    }

'''
assert needle in s;s=s.replace(needle,insert+needle);p.write_text(s)
notes={
 'selectedPackage':'Cntryl.Portia.Abstractions/0.9.1',
 'packageAsset':'/tmp/compliance-pr-review-20261024/packages/cntryl.portia.abstractions/0.9.1/lib/net10.0/Portia.Abstractions.xml',
 'repositoryCommitFromNuspec':'9671b793abfa8c5462d74accdf82d54b5cebefa5',
 'confirmedPackageDocumentation':[
  {'lines':'38-46','behavior':'Version counts state-changing events; CommittedStreamPosition is next physical raised-event offset; audit sessions never advance that OCC position.'},
  {'lines':'744-760','behavior':'Raised-event saves use the owner committed event-stream position; audits use independent session streams.'}
 ],
 'localSourceCorroboration':[
  '/Users/jrepanich/Code/cntryl/portia/src/Portia.Core/Aggregates/AggregateRepository.cs:89-90 chooses independent audit stream and expected position0.',
  '/Users/jrepanich/Code/cntryl/portia/src/Portia.Abstractions/Aggregates/Aggregate.cs:219-232 stamps an audit with current Version without a state event.',
  '/Users/jrepanich/Code/cntryl/portia/src/Portia.Abstractions/Aggregates/Aggregate.cs:257-272 leaves owner OCC tail unchanged by audit and creates fresh audit session resource.'
 ],
 'change':'Committed native metadata requires a nonzero aggregate version, without equality to business revision/native sequence/physical tail. Source scan validates actual ResourceOffset contiguity and metadata version monotonicity independently; exact SameSource compares full actual metadata records.',
 'regression':'ShouldKeepNativeAuthorityCutGivenDurableIndependentAuditSession uses public protected Portia AuditEvent through a test probe plus actual in-memory durable writer/store. It asserts a separate stored audit session and retained owner business/native/physical cuts. Supplied, not executed.',
 'limit':'The selected public Portia0.9.1 audit API cannot establish that an audit advances this owner raised-event tail: package documentation explicitly states the opposite. No owner-stream audit-tail advance is claimed.'
}
(r/'evaluation-metadata-cuts.json').write_text(json.dumps(notes,indent=2)+'\n')
