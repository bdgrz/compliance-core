from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');core=r/'src/Compliance.Core/Features/Risks'
(core/'RiskEvaluationDirectoryIdentity.cs').write_text('''using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
public sealed record RiskEvaluationDirectoryIdentity(Uuid TenantId, Uuid ProgramId, Uuid RiskId, long Revision, long NativeSequence);
''')
(core/'RiskEvaluationDirectorySchema.cs').write_text('''using System.Globalization;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
static class RiskEvaluationDirectorySchema
{
    public static readonly KvDirectory<RiskEvaluationDirectoryIdentity, Uuid> Evaluations = new("risk_evaluation_identities_v2",
        ComplianceCoreJsonContext.Default.RiskEvaluationDirectoryIdentity, static value => value.RiskId, static id => [id.ToString()], []);
    public static readonly KvDirectoryIndex<RiskEvaluationDirectoryIdentity> ByRiskRevision = new("by_risk_revision", 1,
        static value => [value.RiskId.ToString(), value.Revision.ToString("D20", CultureInfo.InvariantCulture)]);
    public static readonly KvDirectory<RiskEvaluationDirectoryIdentity, string> History = new("risk_evaluation_history_identities_v2",
        ComplianceCoreJsonContext.Default.RiskEvaluationDirectoryIdentity, static value => HistoryKey(value.RiskId, value.Revision),
        static key => [key], [ByRiskRevision]);
    public static string HistoryKey(Uuid riskId, long revision) => $"{riskId}:{revision.ToString("D20", CultureInfo.InvariantCulture)}";
}
''')
(core/'FitzRiskEvaluationDirectory.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Cntryl.Fitz;
using Cntryl.Portia;
namespace Bdgrz.Compliance.Features.Risks;
sealed class FitzRiskEvaluationDirectory(IKvClient client, RiskEvaluationReader sources)
    : FitzKvProjectionStore(client, "kv://bdgrz/risk-evaluation-directory-v2/projection", ProjectorName),
        IRiskEvaluationDirectoryReader, IRiskEvaluationDirectoryProjection
{
    public const string ProjectorName = "RiskEvaluationDirectoryV2";
    public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId, CancellationToken ct = default) =>
        base.LoadCheckpointAsync(new CheckpointIdentity(ProjectorName, EventStreamPattern.ForPattern(tenantId.ToString(), RiskEvaluation.Area)), ct);
    public async ValueTask ApplyAsync(DomainEvent value, CancellationToken ct = default)
    {
        if (value is not IRiskEvaluationFact fact)
            return;
        if (fact.TenantId == Uuid.Empty || fact.ProgramId == Uuid.Empty || fact.RiskId == Uuid.Empty || fact.Revision < 1 ||
            fact.Header.TenantId != fact.TenantId || fact.Header.ProgramId != fact.ProgramId || fact.Header.RiskId != fact.RiskId ||
            fact.Header.Revision != fact.Revision || fact.Operation.Owner != new EventStreamAddress(fact.TenantId.ToString(), RiskEvaluation.Area, fact.RiskId.ToString()))
            throw new InvalidOperationException("An evaluation projection requires its exact native source identity.");
        var prior = await RiskEvaluationDirectorySchema.Evaluations.GetAsync(Transaction, fact.RiskId, ct).ConfigureAwait(false);
        var next = new RiskEvaluationDirectoryIdentity(fact.TenantId, fact.ProgramId, fact.RiskId, fact.Revision, fact.NativeSequence);
        if (prior == next) return;
        if (prior is null ? fact.Revision != 1 || fact.NativeSequence != 1 : prior.TenantId != fact.TenantId || prior.ProgramId != fact.ProgramId ||
            prior.Revision + 1 != fact.Revision || prior.NativeSequence + 1 != fact.NativeSequence)
            throw new InvalidOperationException("An evaluation projection cannot precede its exact native predecessor.");
        if (prior is null) await RiskEvaluationDirectorySchema.Evaluations.InsertAsync(Transaction, next, ct).ConfigureAwait(false);
        else await RiskEvaluationDirectorySchema.Evaluations.ReplaceAsync(Transaction, prior, next, ct).ConfigureAwait(false);
        await RiskEvaluationDirectorySchema.History.InsertAsync(Transaction, next, ct).ConfigureAwait(false);
    }
    public async ValueTask<RiskEvaluationView?> GetAsync(Uuid tenantId, Uuid riskId, CancellationToken ct = default)
    {
        RiskEvaluationDirectoryIdentity? row;
        await using (var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false))
            row = await RiskEvaluationDirectorySchema.Evaluations.GetAsync(tx, riskId, ct).ConfigureAwait(false);
        if (row is null) return null;
        var source = await ReadAsync(tenantId, riskId, row, ct).ConfigureAwait(false);
        if (source.Revision != row.Revision)
            throw new ImmutableContentUnavailableException("The evaluation projection has not reached its current native authority.");
        return source.ToView();
    }
    public async ValueTask<Page<RiskEvaluationHistoryEntryView>> ListHistoryAsync(Uuid tenantId, Uuid riskId, int limit, string? cursor, CancellationToken ct = default)
    {
        Page<RiskEvaluationDirectoryIdentity> page;
        await using (var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false))
            page = await RiskEvaluationDirectorySchema.History.QueryAsync(tx, RiskEvaluationDirectorySchema.ByRiskRevision.Query()
                .WithPrefix(riskId.ToString()).Take(Math.Clamp(limit, 1, 200)).After(cursor), ct).ConfigureAwait(false);
        var values = new List<RiskEvaluationHistoryEntryView>(page.Items.Count);
        RiskEvaluationReadSnapshot? source = null;
        foreach (var row in page.Items)
        {
            source ??= await ReadAsync(tenantId, riskId, row, ct).ConfigureAwait(false);
            if (row.TenantId != tenantId || row.ProgramId != source.ProgramId || row.RiskId != riskId || row.Revision > source.Revision)
                throw new ImmutableContentIntegrityException("The evaluation history identity differs from its exact native owner.");
            var fact = source.Facts.SingleOrDefault(value => value is IRiskEvaluationFact native && native.Revision == row.Revision && native.NativeSequence == row.NativeSequence)
                ?? throw new ImmutableContentUnavailableException("The exact evaluation history source is not visible yet.");
            values.Add(await sources.HistoryEntryAsync(fact, ct).ConfigureAwait(false));
        }
        return new(values, page.NextCursor);
    }
    async ValueTask<RiskEvaluationReadSnapshot> ReadAsync(Uuid tenantId, Uuid riskId, RiskEvaluationDirectoryIdentity row, CancellationToken ct)
    {
        if (row.TenantId != tenantId || row.RiskId != riskId)
            throw new ImmutableContentIntegrityException("The evaluation identity has another exact tenant or owner.");
        var source = await sources.ReadAsync(tenantId, row.ProgramId, riskId, ct).ConfigureAwait(false);
        if (source.ProgramId != row.ProgramId || source.Revision < row.Revision || source.Owner.NativeSequence < row.NativeSequence)
            throw new ImmutableContentUnavailableException("The projected evaluation source is not visible yet.");
        return source;
    }
}
''')
p=core/'RiskEvaluationReader.cs';s=p.read_text();a=s.index('    internal async ValueTask<RiskEvaluationReadSnapshot>');s=s[:a]+'''    public async ValueTask<RiskEvaluationHistoryEntryView> HistoryEntryAsync(DomainEvent fact, CancellationToken ct = default)
    {
        var native = (IRiskEvaluationFact)fact;
        var body = await RiskEvaluationContent.ReadMutationAsync(content, fact, ct).ConfigureAwait(false);
        if (!RiskEvaluationContent.InScope(body, native.Header))
            throw new ImmutableContentIntegrityException("The evaluation history body has another exact scope.");
        return new(native.TenantId, native.ProgramId, native.RiskId, native.Revision, body switch
        {
            RiskAssessmentRecordedBody => "assessment_recorded",
            RiskTreatmentChosenBody => "treatment_chosen",
            _ => "risk_accepted",
        }, (body as RiskAssessmentRecordedBody)?.Assessment, (body as RiskTreatmentChosenBody)?.Treatment,
            (body as RiskAcceptedBody)?.Acceptance, RiskEvaluationContent.Actor(body), RiskEvaluationContent.At(body));
    }
'''+s[a:];p.write_text(s)
p=core/'RiskEvaluationReadConsistency.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s;s=s.replace('    IAggregateReader reader)','    IAggregateReader reader, RiskEvaluationReader evaluations)');s=s.replace('        var source = await reader.HydrateAsync(new RiskEvaluation(tenantId, riskId), ct)\n            .ConfigureAwait(false);','        var source = await evaluations.ReadAsync(tenantId, programId, riskId, ct).ConfigureAwait(false);');s=s.replace('? Result<RiskEvaluationView>.Success(view)','? Result<RiskEvaluationView>.Success(source.ToView())');a=s.index('        if (minimumRevision is < 0)');b=s.rindex('\n    }');body=s[a:b];s=s[:a]+'        try\n        {\n'+''.join('    '+line+'\n' for line in body.splitlines())+'        }\n        catch (ImmutableContentIntegrityException failure)\n        {\n            return Result<RiskEvaluationView>.Failure(RiskEvaluationReadFailure.Of(failure));\n        }'+s[b:];p.write_text(s)
for name,typ in [('ListRiskEvaluationHistoryHandler','Page<RiskEvaluationHistoryEntryView>'),('GetRiskEvaluationHandler','RiskEvaluationView')]:
 p=core/(name+'.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s;a=s.index('        var request = context.Request;');b=s.rindex('\n    }');body=s[a:b];s=s[:a]+'        try\n        {\n'+''.join('    '+line+'\n' for line in body.splitlines())+'        }\n        catch (ImmutableContentIntegrityException failure)\n        {\n            return Result<'+typ+'>.Failure(RiskEvaluationReadFailure.Of(failure));\n        }'+s[b:];p.write_text(s)
