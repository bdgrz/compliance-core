using System.Reflection;
using System.Text.Json;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
namespace Bdgrz.Compliance.Tests.Features.Risks;
public sealed class RiskEvaluationCompactionTests
{
    [Fact]
    public void ShouldKeepOwnerAuthorityBoundedGivenLongAssessmentHistory()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var risk = Uuid.CreateVersion4();
        var actor = Uuid.CreateVersion4();
        var method = new RiskMethod(tenant, program);
        var now = DateTimeOffset.UtcNow;
        Assert.Null(method.Publish(program, 0, RiskMethodTests.Scale(), RiskMethodTests.Scale(), 12, ActorReference.ForMember(actor, "Lead"), now));
        var evaluation = new RiskEvaluation(tenant, risk);
        for (var index = 0; index < 100; index++)
            Assert.Null(evaluation.RecordAssessment(program, index, Uuid.CreateVersion4(), method.Current!, "inherent", 2, 2,
                new string('界', 4000), actor, "Assessor", now.AddMinutes(index)));
        var facts = new AggregateScenario<RiskEvaluation>(evaluation).PendingEvents;

        // Act
        var collections = typeof(RiskEvaluation).GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(evaluation) is System.Collections.ICollection).ToArray();
        var maximum = facts.Max(value => JsonSerializer.SerializeToUtf8Bytes(value, value.GetType(), ComplianceCoreJsonContext.Default).Length);

        // Assert
        Assert.Empty(collections);
        Assert.True(maximum <= 8192, $"A native evaluation fact must remain compact; largest source was {maximum} bytes.");
        Assert.Equal(100, evaluation.Revision);
    }
}
