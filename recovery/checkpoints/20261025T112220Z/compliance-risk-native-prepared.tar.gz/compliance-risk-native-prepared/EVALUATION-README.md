# RiskEvaluation offline native handoff

Frozen evaluation export: 57 changed files, comprising 40 source files and 17 test/helper files. All files live beneath `/tmp/compliance-risk-native-prepared`; this preparation made no main checkout, Git, worktree, GitHub, build, broker, or Jev changes.

`evaluation-handoff.json` is the integration entry point. `evaluation-manifest.json` has exact before/final SHA-256 hashes for every changed path; `evaluation-baselines.json` records baseline provenance. Every existing repository changed path has a nonnull exact original baseline. New paths are explicitly null before hashes.

## Integration order

Use either complete sequence, not both:

1. Final-only: `evaluation-implementation.patch`, then `evaluation-tests-full.patch`.
2. Tests first: `evaluation-tests-red.patch` on the existing API; run the focused RED; then apply `evaluation-implementation.patch`, `evaluation-migrated-tests.patch`, and `evaluation-native-tests.patch`.

`evaluation-reconstruction.json` confirms both sequences reconstruct the exact final 57 files in a temporary offline directory. The RED is supplied for execution, not claimed as run. Its original API test retains the same final acceptance name and demonstrates owner history collections and the oversized raw assessment fact. Native implementation adds a complete immutable-history assertion.

The four shared fixtures named in `evaluation-fixture-handoff.json` contain parent RiskDraft follow-ups in final `work/` bytes. Preserve those latest combined files. The `evaluation-fixtures-before-draft/` snapshots and `evaluation-fixture-handoff.patch` are eval-only historical aids, not replacements for final files.

## Behavior

The command owner retains a bounded authority header, immutable current-authority reference, native sequence, and one selected native acceptance. Business history exists in immutable change bodies and transient read/rules composition. Assessment, treatment, and acceptance facts are explicit version 2 native contracts with exact scoped references and full command/actor/revision binding. No legacy version 1 stored-event compatibility is claimed.

Each new operation freezes the actual body, bounded current authority, original typed HTTP 200 result, and response descriptor before the accepted append. Selected exact retries precede mutable risk/method/governance/waiver dependencies. Personal HTTP acceptance and current permission grants still precede acceptance replay. Provider gap admission remains its existing HTTP 202 protocol and proves the actual persisted native acceptance fact.

The V2 evaluation directory stores scoped current/history identities. Reads reconstruct verified immutable bodies at the native owner cut. Projection malformed scope, missing predecessor, rollback, and exact replay assertions remain present. The Type I source contributor migrates both Draft and Evaluation sources while retaining exact source IDs, original metadata/body cutoff, included/excluded-prefix handling, and actual native source proof payloads. Audits do not advance the state version.

`evaluation-wiring.json` records constructor, DI, JSON, route, projector, and shared helper deltas. The parent owns those shared paths; this patch does not replace its transport or other native-family branches.

## Evidence and remaining gates

`evaluation-audit.json`: 59 owned C# paths parsed; 61 explicit constructor call sites checked across the effective layered tree; every CancellationToken parameter is final (CA1068 static gate); all 87 original acceptance names retained; no assertion-count reduction; no missing original baseline. This does not establish semantic type checking or runtime behavior.

Parent must execute the focused existing-API RED, compile, run focused native/identity/projection/source/work/provider tests with `Category!=BrokerIntegration`, run the applicable backend suite, and perform direct Jev per-file review. No broker startup is required by this preparation.

Native fact version 2 and the fresh V2 projection namespace require the parent's normal persistence/compatibility qualification before a delivery claim. No new source-use permits were invented. No newly discovered external source-use blocker or GitHub issue is asserted by this slice. Full read/rule reconstruction remains linear in immutable history; bounded command state and fact size do not claim constant read cost.

`evaluation-integrity-review.json` records the corrected native provenance/metadata projection admission, per-history source identity checks and malformed nested-body classification, with focused regression cases supplied for parent execution. Projection admission now reconstructs the native source to compare an exact committed fact; this adds read work and has no performance qualification.

`evaluation-metadata-cuts.json` records the selected Portia0.9.1 package audit contract. Native metadata is validated independently of business revision/native sequence; source record offsets and metadata order are checked separately. A supplied durable audit-session regression verifies the actual public API preserves owner authority and OCC cuts.

Exact patch SHA-256 values:

- `evaluation-tests-red.patch`: `79fef9d24f7f298a99c91e4c31bc65f4b30a1e5a31f6fb31658f2813db79fb22`
- `evaluation-implementation.patch`: `0984e26fe770cc5a429c69e6bad35537a4c60451fdc825b2e856da4b1cefdd10`
- `evaluation-migrated-tests.patch`: `08dfc14218ed1a198c464b8af10161fecc533056f2158471fdfe7884b385a6a4`
- `evaluation-native-tests.patch`: `49dca6e1eaa4f59fa6023a51ed2a75e50ead32f962a4ef94dd1b2736f5fb6193`
- `evaluation-tests-full.patch`: `d418d9d23a36741df5171d457c3cfbdbaf22afc8b002e6e9b4af46f045801b26`
