from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work/test/Compliance.Tests/E2E')
p=r/'RiskDraftE2ETests.cs';s=p.read_text();s='using Bdgrz.Compliance.Tests.Testing;\n'+s
s=s.replace('owner.PostAsJsonAsync(path, Draft(', 'RiskDraftHttpRequests.CreateAsync(owner, path, Draft(').replace('outsider.PostAsJsonAsync(path, Draft(', 'RiskDraftHttpRequests.CreateAsync(outsider, path, Draft(').replace('owner.PutAsJsonAsync(draftPath,','RiskDraftHttpRequests.ReviseAsync(owner, draftPath,')
s=s.replace('Assert.Equal(HttpStatusCode.NoContent, revisedResponse.StatusCode);','Assert.Equal(HttpStatusCode.OK, revisedResponse.StatusCode);').replace('Assert.Equal(HttpStatusCode.NoContent, revised.StatusCode);','Assert.Equal(HttpStatusCode.OK, revised.StatusCode);')
s=s.replace('                ["identifier"] = "R-02",','                ["risk_id"] = RiskDraftHttpRequests.IdForCollection(path, "R-02").ToString(),\n                ["identifier"] = "R-02",')
s=s.replace('_ = await mcp.When("bdgrz.risk.draft.revise", new Dictionary<string, object?>\n            {','_ = await mcp.When("bdgrz.risk.draft.revise", new Dictionary<string, object?>\n            {\n                ["command_id"] = Uuid.CreateVersion4().ToString(),')
s=s.replace('"RiskDraftDirectory", WorkloadScope.PerTenant','"RiskDraftDirectoryV2", WorkloadScope.PerTenant').replace('"RiskDraftHistoryDirectoryV1",','"RiskDraftHistoryDirectoryV2",')
p.write_text(s)
p=r/'DraftReadLeakMatrixE2ETests.cs';s=p.read_text();s=s.replace('owner.PostAsJsonAsync(prefix + "/risks", new','RiskDraftHttpRequests.CreateAsync(owner, prefix + "/risks", new')
s=s.replace('using (var risk = await owner.PutAsJsonAsync(\n                   $"{prefix}/risks/{risks[0]}/draft", new','using (var risk = await RiskDraftHttpRequests.ReviseAsync(owner,\n                   $"{prefix}/risks/{risks[0]}/draft", new').replace('Assert.Equal(HttpStatusCode.NoContent, risk.StatusCode);','Assert.Equal(HttpStatusCode.OK, risk.StatusCode);')
if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
p.write_text(s)
p=r/'DraftActorSnapshotE2ETests.cs';s=p.read_text().replace('owner.PostAsJsonAsync(risks, new','RiskDraftHttpRequests.CreateAsync(owner, risks, new').replace('owner.PutAsJsonAsync(drafts[2].Current, new','RiskDraftHttpRequests.ReviseAsync(owner, drafts[2].Current, new').replace('Assert.Equal(HttpStatusCode.NoContent, riskRevision.StatusCode);','Assert.Equal(HttpStatusCode.OK, riskRevision.StatusCode);')
if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
p.write_text(s)
