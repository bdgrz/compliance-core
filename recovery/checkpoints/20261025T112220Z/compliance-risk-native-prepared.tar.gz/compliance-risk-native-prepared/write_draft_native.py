from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');common=r/'src/Compliance.Common/Features/Risks';core=r/'src/Compliance.Core/Features/Risks'
(common/'RiskDraftAuthorityHeader.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Bounded current author and identity authority; draft narrative bytes remain immutable content.</summary>
public sealed record RiskDraftAuthorityHeader(Uuid TenantId, Uuid ProgramId, Uuid RiskId, string Identifier,
    long Revision, Uuid ActorMemberId, string ActorDisplay, ActorReference Actor, DateTimeOffset ChangedAt);
''')
(common/'IRiskDraftFact.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

public interface IRiskDraftFact : INativeOperationFact
{
    RiskDraftAuthorityHeader Header { get; }
    ImmutableContentRef Content { get; }
    ImmutableContentRef? OperationResult { get; }
    long NativeSequence { get; }
}
''')
for name,discriminator in [('RiskDraftCreated','created'),('RiskDraftRevised','revised')]:
 extra='    public Uuid CreateRequestId => Operation.CommandKind == nameof(CreateRiskDraft) ? Operation.CommandId : Uuid.Empty;\n' if name.endswith('Created') else '    public Uuid? CommandId => Operation.CommandId;\n    public long? OriginalExpectedRevision => Operation.OriginalExpectedRevision is { } revision ? checked((long)revision) : null;\n'
 # OperationProvenance's logical id is the authored command id.
 extra=extra.replace('Operation.CommandId','Operation.LogicalId')
 (common/(name+'.cs')).write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

[Discriminator("bdgrz.risk.draft.'''+discriminator+'''", 2)]
public sealed record '''+name+'''(RiskDraftAuthorityHeader Header, ImmutableContentRef Content,
    long NativeSequence, OperationProvenance Operation, ImmutableContentRef? FirstResponse,
    ImmutableContentRef? OperationResult) : DomainEvent, IRiskDraftFact
{
    public Uuid TenantId => Header.TenantId;
    public Uuid ProgramId => Header.ProgramId;
    public Uuid RiskId => Header.RiskId;
    public string Identifier => Header.Identifier;
    public long Revision => Header.Revision;
    public Uuid ActorMemberId => Header.ActorMemberId;
    public string ActorDisplay => Header.ActorDisplay;
    public DateTimeOffset ChangedAt => Header.ChangedAt;
    public ActorReference Actor => Header.Actor;
    public ActorReference StoredActor => Header.Actor;
    public string AuthoredIntentSha256 => Operation.AuthoredIntentSha256;
'''+extra+'''}
''')
(core/'RiskDraft.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Current compact risk identity and one selected native acceptance; narrative and history are read composition.</summary>
public sealed class RiskDraft : Aggregate
{
    public const string Area = "risks";
    public const int MaximumDraftEventPayloadBytes = 48 * 1024;
    readonly Uuid _tenantId;
    public RiskDraft(Uuid tenantId, Uuid riskId, Uuid selectedCommandId = default)
        : base(riskId, new EventStreamAddress(tenantId.ToString(), Area, riskId.ToString()))
    {
        _tenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedCommandId);
        On<RiskDraftCreated>(Apply);
        On<RiskDraftRevised>(Apply);
    }
    public Uuid TenantId => _tenantId;
    public bool IsCreated => Header is not null;
    public Uuid ProgramId => Header?.ProgramId ?? Uuid.Empty;
    public long Revision => Header?.Revision ?? 0;
    public RiskDraftAuthorityHeader? Header { get; private set; }
    public ImmutableContentRef? CurrentContent { get; private set; }
    public long NativeSequence { get; private set; }
    public NativeAcceptance Acceptance { get; }
    public static string NormalizeIdentifier(string? identifier) => RiskDraftRules.NormalizeIdentifier(identifier);
    public static Uuid IdFor(Uuid tenant, Uuid program, string identifier) => RiskDraftRules.IdFor(tenant, program, identifier);

    public Result Append(DomainEvent value, RiskDraftRevisionView prepared, long sequence, ulong physicalPosition)
    {
        if (NativeSequence != sequence || CommittedStreamPosition != physicalPosition)
            return Failure("The risk draft changed during its immutable preparation.", true);
        if (value is not IRiskDraftFact fact || RiskDraftFactContent.Header(prepared) != fact.Header ||
            ContentDigest.OfJson(prepared) != fact.Content.Sha256)
            return Failure("The risk draft fact differs from its exact prepared content and authority.");
        try { Validate(value, fact); }
        catch (InvalidOperationException) { return Failure("The risk draft fact has an invalid native owner binding."); }
        RaiseEvent(value);
        return Result.Success;
    }
    void Apply(RiskDraftCreated fact) => ApplyFact(fact);
    void Apply(RiskDraftRevised fact) => ApplyFact(fact);
    void ApplyFact(DomainEvent value)
    {
        var fact = (IRiskDraftFact)value;
        Validate(value, fact);
        Header = fact.Header; CurrentContent = fact.Content; NativeSequence = fact.NativeSequence;
        Acceptance.Observe(value);
    }
    void Validate(DomainEvent value, IRiskDraftFact fact)
    {
        var h = fact.Header; var op = fact.Operation;
        if (h.TenantId != _tenantId || h.ProgramId == Uuid.Empty || h.RiskId != Id || h.Revision != Revision + 1 ||
            fact.NativeSequence != NativeSequence + 1 || h.ActorMemberId == Uuid.Empty || string.IsNullOrWhiteSpace(h.ActorDisplay) ||
            h.Actor != op.Actor || h.ChangedAt != op.AcceptedAt || fact.Content.Schema != RiskDraftFactContent.Schema ||
            fact.FirstResponse is null || fact.OperationResult is null || op.LogicalId == Uuid.Empty || op.RootOperationId != op.LogicalId ||
            op.Owner != Stream || op.FirstOwner != Stream || op.AffectedOwner != Stream || op.ExpectedRevisionOwner != Stream ||
            op.Episode != Id.ToString() || op.AuthoredIntentSha256.Length != 64 ||
            value is RiskDraftCreated && (Header is not null || op.CommandKind != nameof(CreateRiskDraft) || op.LogicalId != Id || op.OriginalExpectedRevision is not null ||
                Id != IdFor(_tenantId, h.ProgramId, h.Identifier)) ||
            value is RiskDraftRevised && (Header is null || Header.ProgramId != h.ProgramId || Header.Identifier != h.Identifier ||
                op.CommandKind != nameof(ReviseRiskDraft) || op.OriginalExpectedRevision != unchecked((ulong)Revision)) ||
            DomainEventPayload.Size(value) > DomainEventPayload.MaximumBytes)
            throw new InvalidOperationException("The risk draft native fact has another selected owner, author, intent or revision cut.");
    }
    static Result Failure(string message, bool transient = false) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
(core/'RiskDraftFactContent.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

public static class RiskDraftFactContent
{
    public const string Schema = "risk-draft-revision-content.v1";
    public static RiskDraftAuthorityHeader Header(RiskDraftRevisionView value) => new(value.TenantId, value.ProgramId,
        value.RiskId, value.Identifier, value.Revision, value.ChangedByMemberId, value.ChangedByDisplay, value.Actor, value.ChangedAt);
    public static async ValueTask<RiskDraftRevisionView> ReadAsync(IImmutableContentStore content, IRiskDraftFact fact, CancellationToken ct = default)
    {
        if (fact.Content.Schema != Schema || fact.Header is not { } header || fact.Operation is null ||
            header.RiskId == Uuid.Empty || header.TenantId == Uuid.Empty || header.ProgramId == Uuid.Empty ||
            fact.Operation.Owner != new EventStreamAddress(header.TenantId.ToString(), RiskDraft.Area, header.RiskId.ToString()) ||
            fact.FirstResponse is null || fact.OperationResult is null || fact.NativeSequence < 1)
            throw new ImmutableContentIntegrityException("The risk draft native source has another exact owner or schema.");
        var value = await content.ReadJsonAsync<RiskDraftRevisionView>(header.TenantId.ToString(), fact.Content, ct).ConfigureAwait(false);
        if (Header(value) != header || RiskDraftRules.Validate(value.Identifier, value.Content) is not null ||
            ContentDigest.OfJson(value.Content) != ContentDigest.OfJson(RiskDraftRules.Clean(value.Content)))
            throw new ImmutableContentIntegrityException("The risk draft immutable narrative differs from its native authority.");
        return value;
    }
    public static RiskDraftView View(RiskDraftRevisionView revision) => new(revision.TenantId, revision.ProgramId,
        revision.RiskId, revision.Identifier, revision.Revision, "draft_unassessed", "unresolved", revision.Content,
        revision.ChangedByMemberId, revision.ChangedByDisplay, revision.ChangedAt) { LastChangedBy = revision.Actor };
}
''')
(core/'RiskDraftReadSnapshot.cs').write_text('''namespace Bdgrz.Compliance.Features.Risks;

public sealed record RiskDraftReadSnapshot(RiskDraft Owner, RiskDraftRules Rules, RiskDraftRevisionView? Current)
{
    public bool IsCreated => Current is not null;
    public RiskDraftView? View => Current is null ? null : RiskDraftFactContent.View(Current);
}
''')
(core/'RiskDraftReadFailure.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

public static class RiskDraftReadFailure
{
    public static RequestError Of(ImmutableContentIntegrityException failure) => new(RequestErrorKind.Conflict,
        "The risk draft's exact immutable source cannot be verified.", failure is ImmutableContentUnavailableException);
}
''')
(core/'RiskDraftReader.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

public sealed class RiskDraftReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async ValueTask<RiskDraftReadSnapshot> ReadAsync(Uuid tenant, Uuid program, Uuid risk, CancellationToken ct = default) =>
        await ReadAsync(await reader.HydrateAsync(new RiskDraft(tenant, risk), ct).ConfigureAwait(false), program, ct).ConfigureAwait(false);
    internal async ValueTask<RiskDraftReadSnapshot> ReadAsync(RiskDraft owner, Uuid program, CancellationToken ct)
    {
        if (owner.Header is null || owner.ProgramId != program)
            return new(owner, new RiskDraftRules(owner.TenantId, owner.Id), null);
        var selected = await content.ReadJsonAsync<RiskDraftRevisionView>(owner.TenantId.ToString(), owner.CurrentContent!, ct).ConfigureAwait(false);
        if (owner.CurrentContent!.Schema != RiskDraftFactContent.Schema || RiskDraftFactContent.Header(selected) != owner.Header ||
            RiskDraftRules.Validate(selected.Identifier, selected.Content) is not null ||
            ContentDigest.OfJson(selected.Content) != ContentDigest.OfJson(RiskDraftRules.Clean(selected.Content)))
            throw new ImmutableContentIntegrityException("The risk draft current narrative differs from its native owner cut.");
        return new(owner, RiskDraftRules.FromCurrent(selected, owner.TenantId, owner.Id), selected);
    }
    public async ValueTask<IReadOnlyList<RiskDraftRevisionView>> ReadRevisionsAsync(Uuid tenant, Uuid program, Uuid risk, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new RiskDraft(tenant, risk), ct).ConfigureAwait(false);
        if (!owner.IsCreated || owner.ProgramId != program) return [];
        var result = new List<RiskDraftRevisionView>(); var sequence = 0L; IRiskDraftFact? last = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(tenant.ToString(), RiskDraft.Area, risk.ToString()), EventCursor.Start, ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit) continue;
            if (record.Stream != owner.Stream || record.Event is not IRiskDraftFact fact || fact.NativeSequence != sequence + 1)
                throw new ImmutableContentIntegrityException("The risk draft history has another exact native owner sequence.");
            if (fact.NativeSequence > owner.NativeSequence) break;
            result.Add(await RiskDraftFactContent.ReadAsync(content, fact, ct).ConfigureAwait(false));
            last = fact; sequence = fact.NativeSequence;
            if (sequence == owner.NativeSequence) break;
        }
        if (last is null || sequence != owner.NativeSequence)
            throw new ImmutableContentUnavailableException("The risk draft exact native history cut is not visible yet.");
        if (last.Header != owner.Header || last.Content != owner.CurrentContent)
            throw new ImmutableContentIntegrityException("The risk draft history differs from its hydrated current authority.");
        return result.AsReadOnly();
    }
}
''')
