from pathlib import Path
import json,hashlib
r=Path('/tmp/compliance-risk-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=['src/Compliance.Core/Features/Risks/'+n+'.cs' for n in ['RiskEvaluation','RecordRiskAssessmentHandler','ChooseRiskTreatmentHandler','AcceptRiskHandler','FitzRiskEvaluationDirectory','RiskEvaluationDirectorySchema','RiskEvaluationReadConsistency','GetRiskEvaluationHandler','ListRiskEvaluationHistoryHandler','RiskEvaluationDirectoryProjectorV1','ProposeRiskControlTreatmentHandler','AddRiskTreatmentActionHandler','GetRiskGovernanceHandler','RaiseRiskReassessmentTriggersHandler','RiskReassessmentFanOut']]
paths += ['src/Compliance.Common/Features/Risks/'+n+'.cs' for n in ['RiskAssessmentRecorded','RiskTreatmentChosen','RiskAccepted']]
paths += ['src/Compliance.Core/Features/'+p for p in ['Providers/LinkProviderCoverageGapRiskAcceptanceHandler.cs','Remediation/LinkFindingAcceptanceHandler.cs','Examinations/RiskTypeIBaselineSourceContributor.cs','Work/RiskAcceptanceWork.cs','Work/RiskAcceptanceWorkItemDirectory.cs']]
paths += ['test/Compliance.Tests/Features/Risks/'+n+'.cs' for n in ['RiskEvaluationTests','RiskAssessmentIdentityTests','RiskTreatmentIdentityTests','RiskAcceptanceIdentityTests','RiskGovernanceHandlerTests','FitzRiskEvaluationDirectoryTests','AttestRiskManagementWriteWallTests']]
paths += ['test/Compliance.Tests/'+p for p in ['Features/Examinations/RiskTypeIBaselineSourceContributorTests.cs','Features/Work/RiskAcceptanceWorkTests.cs','Features/Work/RiskAcceptanceWorkAuthorityTests.cs','Features/Work/WorkSourceCompositionTests.cs','Features/PolicyDistribution/PolicyAcknowledgementIndependenceTests.cs','Testing/ProviderAssuranceHost.cs']]
prov=[]
for p in paths:
 source=repo/p
 for overlay in ['/tmp/compliance-s32-commitment-prepared/after','/tmp/compliance-commitment-consumers-prepared/after','/tmp/compliance-s32-boundary-prepared/after','/tmp/compliance-boundary-consumers-prepared/after','/tmp/compliance-system-description-prepared/work']:
  if (Path(overlay)/p).exists():source=Path(overlay)/p
 data=source.read_bytes()
 for d in ['base','work']:
  f=r/d/p
  if f.exists():assert f.read_bytes()==data,(d,p,'overlap already edited')
  f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 prov.append({'path':p,'baselineSource':str(source),'beforeSha256':hashlib.sha256(data).hexdigest()})
(r/'evaluation-baselines.json').write_text(json.dumps(prov,indent=2)+'\n');(r/'evaluation-owned-paths.txt').write_text('\n'.join(paths)+'\n')
print(len(paths))
