from pathlib import Path
r=Path('/tmp/compliance-risk-native-prepared/work');tests=r/'test/Compliance.Tests'
# Source fixture callbacks must use explicit transient Rules and publish native facts.
for rel in ['Features/Risks/RiskGovernanceHandlerTests.cs','Features/Work/WorkSourceCompositionTests.cs','Features/Work/RiskAcceptanceWorkTests.cs','Features/Work/RiskAcceptanceWorkAuthorityTests.cs','Features/PolicyDistribution/PolicyAcknowledgementIndependenceTests.cs']:
 p=tests/rel;s=p.read_text();s=s.replace('new RiskEvaluation(', 'new RiskEvaluationRules(')
 # Reads of command state only ask Revision in authority tests; keep compact owner for those hydrations.
 s=s.replace('ProgramManagementServices.HydrateAsync(fixture.Provider,\n            new RiskEvaluationRules(', 'ProgramManagementServices.HydrateAsync(fixture.Provider,\n            new RiskEvaluation(')
 p.write_text(s)
p=tests/'Testing/ProviderAssuranceHost.cs';s=p.read_text().replace('await SeedAsync(new RiskEvaluation(', 'await SeedAsync(new RiskEvaluationRules(');a=s.index('    public async Task SeedAsync<TAggregate>');s=s[:a]+'''    public async Task SeedAsync(RiskEvaluationRules selected, Func<RiskEvaluationRules, Result> operation)
    {
        await using var scope = _provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var rules = await new RiskEvaluationReader(reader, Events, Content).RulesAsync(selected.TenantId, selected.Id);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await RiskEvaluationSeeds.AppendAsync(reader, services.GetRequiredService<IAggregateWriter>(), Events, Content, rules);
    }

'''+s[a:];p.write_text(s)
p=tests/'Features/Risks/FitzRiskEvaluationDirectoryTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Tests.Testing;\n'+s;s=s.replace('        var directory = new FitzRiskEvaluationDirectory(new InMemoryKvClient());','        await using var native = new RiskEvaluationSourceFixture();\n        var directory = new FitzRiskEvaluationDirectory(native.Kv, native.Evaluations);');s=s.replace('var events = Events(tenantId, programId, riskId);','var events = await EventsAsync(native, tenantId, programId, riskId);').replace('var events = Events(tenantId, Uuid.CreateVersion4(), Uuid.CreateVersion4());','var events = await EventsAsync(native, tenantId, Uuid.CreateVersion4(), Uuid.CreateVersion4());');s=s.replace('static List<DomainEvent> Events(Uuid tenantId, Uuid programId, Uuid riskId)','static async Task<IReadOnlyList<DomainEvent>> EventsAsync(RiskEvaluationSourceFixture native, Uuid tenantId, Uuid programId, Uuid riskId)').replace('var evaluation = new RiskEvaluation(tenantId, riskId);','var evaluation = new RiskEvaluationRules(tenantId, riskId);').replace('return [.. new AggregateScenario<RiskEvaluation>(evaluation).PendingEvents];','await native.SeedAsync(evaluation);\n        return await native.FactsAsync(tenantId, riskId);').replace('RiskEvaluationDirectoryV1','RiskEvaluationDirectoryV2');p.write_text(s)
p=tests/'Features/Work/RiskAcceptanceWorkTests.cs';s=p.read_text();s=s.replace('now, null, CancellationToken.None);','now, null, CancellationToken.None, scope.ServiceProvider.GetRequiredService<RiskEvaluationReader>());')
s=s.replace('        var evaluations = new FitzRiskEvaluationDirectory(new InMemoryKvClient());','        await using var sourceScope = fixture.Provider.CreateAsyncScope();\n        var evaluations = new FitzRiskEvaluationDirectory(new InMemoryKvClient(), sourceScope.ServiceProvider.GetRequiredService<RiskEvaluationReader>());')
s=s.replace('fixture.Risks, null, evaluations);','fixture.Risks, null, evaluations, scope.ServiceProvider.GetRequiredService<RiskEvaluationReader>());').replace('RiskEvaluationDirectoryV1','RiskEvaluationDirectoryV2');p.write_text(s)
p=tests/'Features/Work/RiskAcceptanceWorkAuthorityTests.cs';s=p.read_text().replace('provider.GetRequiredService<FitzRiskEvaluationDirectory>()));','provider.GetRequiredService<FitzRiskEvaluationDirectory>(), provider.GetRequiredService<RiskEvaluationReader>()));');p.write_text(s)
# Catch current source reads and projection body failures at the contributor result boundary.
p=r/'src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs';s=p.read_text();a=s.index('        var source = await new RiskEvaluationReader');b=s.index('\n    }',a);body=s[a:b];s=s[:a]+'        try\n        {\n'+''.join('    '+line+'\n' for line in body.splitlines())+'        }\n        catch (ImmutableContentIntegrityException failure)\n        {\n            return Result<EvaluationHistory>.Failure(RiskEvaluationReadFailure.Of(failure));\n        }'+s[b:];p.write_text(s)
