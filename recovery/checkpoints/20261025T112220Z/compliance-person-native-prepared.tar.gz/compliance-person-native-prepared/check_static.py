from pathlib import Path
import os,json,re,subprocess
p=Path('/tmp/compliance-person-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
changed=[f for f in (p/'work').rglob('*.cs') if not (p/'base'/f.relative_to(p/'work')).exists() or f.read_bytes()!=(p/'base'/f.relative_to(p/'work')).read_bytes()]
(p/'changed-csharp.txt').write_text('\n'.join(map(str,changed))+'\n')
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
q=Parser(Language(tree_sitter_c_sharp.language()));fs=[Path(x) for x in Path('/tmp/compliance-person-native-prepared/changed-csharp.txt').read_text().splitlines()];print(json.dumps({'files':len(fs),'errors':[str(f) for f in fs if q.parse(f.read_bytes()).root_node.has_error]}))'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')));assert not syntax['errors'],syntax
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));expected={'Person':(2,3),'PersonRules':(2,3),'RecordPerson':(3,5),'RevisePerson':(5,7),'CorrelatePersonMembership':(4,5),'RecordPersonHandler':(1,1),'RevisePersonHandler':(1,1),'CorrelatePersonMembershipHandler':(1,1),'PersonReader':(3,3),'PersonOperations':(5,5),'PersonAggregateReader':(2,2),'PersonReadSnapshot':(2,2),'PersonReadConsistency':(4,4),'FitzPersonDirectory':(1,2),'PersonPrepared':(14,14),'PersonHeader':(7,7),'PersonChangeContent':(6,6),'PersonRegistrationRecorded':(7,7),'PersonDetailsRevised':(7,7),'PersonMembershipCorrelationRecorded':(7,7)}
files={str(f.relative_to(repo)):f for part in ['src','test'] for f in (repo/part).rglob('*.cs')}
for f in (p/'work').rglob('*.cs'):files[str(f.relative_to(p/'work'))]=f
calls=[];issues=[]
for rel,f in files.items():
 data=f.read_bytes();stack=[parser.parse(data).root_node]
 while stack:
  node=stack.pop();stack.extend(node.children)
  if node.type not in ['object_creation_expression','implicit_object_creation_expression']:continue
  typ=node.child_by_field_name('type');args=node.child_by_field_name('arguments') or next((c for c in node.named_children if c.type=='argument_list'),None)
  if node.type=='implicit_object_creation_expression':
   at=node.parent
   while at and at.type not in ['property_declaration','method_declaration','variable_declaration','local_function_statement','field_declaration']:at=at.parent
   if at:typ=at.child_by_field_name('type') or at.child_by_field_name('returns')
  if not typ or not args:continue
  name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
  if name not in expected:continue
  count=sum(c.type=='argument' for c in args.named_children);row={'path':rel,'line':node.start_point[0]+1,'type':name,'arguments':count,'implicit':node.type=='implicit_object_creation_expression'};calls.append(row)
  if not expected[name][0]<=count<=expected[name][1]:issues.append(row)
preserved=[];drops=[]
for after in changed:
 r=str(after.relative_to(p/'work'));before=p/'base'/r
 if not r.startswith('test/') or not before.exists():continue
 names=lambda f:set(re.findall(r'\b(Should\w+)\s*\(',f.read_text()))
 if not names(before)<=names(after):drops.append({'path':r,'names':sorted(names(before)-names(after))})
 if after.read_text().count('Assert.')<before.read_text().count('Assert.'):drops.append({'path':r,'assertsBefore':before.read_text().count('Assert.'),'assertsAfter':after.read_text().count('Assert.')})
 preserved+=sorted(names(before))
report={'syntax':syntax,'constructors':calls,'constructorIssues':issues,'preservedAcceptanceNames':preserved,'coverageIssues':drops,'runtime':'Root exclusive; no local execution.'};(p/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'syntax':syntax,'constructors':len(calls),'constructorIssues':issues,'preserved':len(preserved),'coverageIssues':drops}));assert not issues and not drops
