from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
R=Path('/tmp/compliance-incident-native-prepared')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def changed(root,b='base',w='work'):
 return sorted(str(p.relative_to(root/w)) for p in (root/w).rglob('*') if p.is_file() and (not(root/b/p.relative_to(root/w)).exists() or p.read_bytes()!=(root/b/p.relative_to(root/w)).read_bytes()))
def export(root,name,paths,b='base',w='work'):
 chunks=[]
 for rel in paths:
  before=root/b/rel;after=root/w/rel
  chunks+=difflib.unified_diff(before.read_text().splitlines(keepends=True) if before.exists() else [],after.read_text().splitlines(keepends=True) if after.exists() else [],fromfile='a/'+rel if before.exists() else '/dev/null',tofile='b/'+rel if after.exists() else '/dev/null')
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(chunks));return {'path':str(p),'sha256':sha(p),'paths':paths}
paths=changed(R);shared=changed(R,'shared-base','shared-work');V=R/'current-main-overlaps';overlaps=changed(V)
foundation=[p for p in paths if '/SourceFacts/' in p or p=='test/Compliance.Tests/Testing/EventStoreSourceFactResolver.cs' or p=='test/Compliance.Tests/Features/AccessReviews/AccessReviewBulkDecisionTests.cs']
source=[p for p in paths if p.startswith('src/')];tests=[p for p in paths if p.startswith('test/')]
artifacts={}
for name,selected in [('implementation.patch',source),('tests.patch',tests),('implementation-core.patch',[p for p in source if p not in overlaps]),('tests-core.patch',[p for p in tests if p not in overlaps]),('incident-after-foundation-implementation.patch',[p for p in source if p not in overlaps+foundation]),('incident-after-foundation-tests.patch',[p for p in tests if p not in overlaps+foundation]),('queued-system-description-overlap.patch',overlaps),('source-proof-foundation.patch',foundation),('source-proof-green-after-red.patch',[p for p in foundation if p!='test/Compliance.Tests/Features/SourceFacts/SourceFactProofsTests.cs']),('source-proof-behavioral-red.patch',['test/Compliance.Tests/Features/SourceFacts/SourceFactProofsTests.cs'])]:artifacts[name]=export(R,name,selected)
artifacts['shared.patch']=export(R,'shared.patch',shared,'shared-base','shared-work')
artifacts['current-main-overlaps.patch']=export(V,'current-main-overlaps.patch',overlaps)
manifest=[{'path':p,'beforeSha256':sha(R/'base'/p),'afterSha256':sha(R/'work'/p),'layer':'source-proof-foundation' if p in foundation else 'queued-system-description-overlap' if p in overlaps else 'core'} for p in paths]
manifest +=[{'path':p,'beforeSha256':sha(R/'shared-base'/p),'afterSha256':sha(R/'shared-work'/p),'layer':'shared-compose-by-delta'} for p in shared]
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(V/'manifest.json').write_text(json.dumps([{'path':p,'beforeSha256':sha(V/'base'/p),'afterSha256':sha(V/'work'/p),'layer':'current Description source API, native Incident'} for p in overlaps],indent=2)+'\n')
results=[]
for label,root,patches,selected in [('full-native',R,['implementation.patch','tests.patch'],paths),('core',R,['implementation-core.patch','tests-core.patch'],[p for p in paths if p not in overlaps]),('current-main-overlaps',V,['current-main-overlaps.patch'],overlaps),('source-proof-foundation',R,['source-proof-foundation.patch'],foundation)]:
 out=R/'reconstruction'/label
 if out.exists():shutil.rmtree(out)
 out.mkdir(parents=True)
 for rel in selected:
  b=root/'base'/rel
  if b.exists():d=out/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b,d)
 for f in patches:
  x=subprocess.run(['patch','-p1','-E','--batch','-i',str(R/f)],cwd=out,capture_output=True,text=True)
  if x.returncode:raise RuntimeError(x.stdout+x.stderr)
 for rel in selected:
  if sha(out/rel)!=sha(root/'work'/rel):raise RuntimeError('hash mismatch '+label+' '+rel)
 results.append({'layer':label,'pathCount':len(selected),'exact':True})
# Shared deltas reconstruct separately; main integration composes newer shared wiring by exact added roots/routes/services.
out=R/'reconstruction/shared'
if out.exists():shutil.rmtree(out)
for rel in shared:
 d=out/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'shared-base'/rel,d)
x=subprocess.run(['patch','-p1','-E','--batch','-i',str(R/'shared.patch')],cwd=out,capture_output=True,text=True)
if x.returncode:raise RuntimeError(x.stdout+x.stderr)
for rel in shared:
 if sha(out/rel)!=sha(R/'shared-work'/rel):raise RuntimeError('shared mismatch '+rel)
results.append({'layer':'shared','pathCount':len(shared),'exact':True})
(R/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n');(R/'reconstruction-checks.json').write_text(json.dumps(results,indent=2)+'\n')
(R/'owning-paths.txt').write_text('\n'.join(paths+shared)+'\n');print(json.dumps({'paths':len(paths),'shared':len(shared),'source':len(source),'tests':len(tests),'foundation':len(foundation),'overlaps':len(overlaps),'artifacts':{k:v['sha256'] for k,v in artifacts.items()},'reconstruction':results},indent=2))
