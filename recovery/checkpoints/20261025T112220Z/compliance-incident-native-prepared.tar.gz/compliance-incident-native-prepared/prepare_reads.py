from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared');W=P/'work';CH=Path('/tmp/compliance-significant-change-prepared/work');K='src/Compliance.Core/Features/Incidents/'
for name in ['SignificantChangeDirectoryEntry','SignificantChangeDirectoryReadConsistency','FitzSignificantChangeDirectory','SignificantChangeDirectorySchema','ListSignificantChangesHandler','GetSignificantChangeHandler','ISignificantChangeDirectoryReader']:
 text=(CH/'src/Compliance.Core/Features/Changes'/(name+'.cs')).read_text()
 text=text.replace('SignificantChange','ComplianceIncident').replace('significant-change','compliance-incident').replace('SignificantChanges','ComplianceIncidents').replace('significant changes','compliance incidents').replace('significant change','compliance incident').replace('namespace Bdgrz.Compliance.Features.Changes;','namespace Bdgrz.Compliance.Features.Incidents;')
 text=text.replace('IncidentOperations' if False else 'ComplianceIncidentOperations','IncidentOperations')
 text=text.replace('h.ComplianceIncidentId','h.IncidentId').replace('request.ChangeId','request.IncidentId')
 if name in ['GetSignificantChangeHandler','ListSignificantChangesHandler']:
  text='using Bdgrz.Compliance.Features.Changes;\n'+text
 if name=='GetSignificantChangeHandler':text=text.replace('ComplianceIncidentReader changes,','ComplianceIncidentReader changes,').replace('RestrictedComplianceRecordVisibility visibility)','RestrictedComplianceRecordVisibility visibility,ComplianceIncidentReadConsistency consistency)')
 if name=='GetSignificantChangeHandler':
  text=text.replace('var change = (await changes.ReadAsync(request.TenantId,request.ProgramId,request.IncidentId,ct).ConfigureAwait(false)).View;','''var snapshot = await changes.ReadAsync(request.TenantId,request.ProgramId,request.IncidentId,ct).ConfigureAwait(false);
        var change = snapshot.View;
        var result =''').replace('        return change is','        result = change is') if False else text
  start=text.index('        var change = ');end=text.index('        catch (ImmutableContentIntegrityException',start)
  text=text[:start]+'''            var snapshot = await changes.ReadAsync(request.TenantId,request.ProgramId,request.IncidentId,ct).ConfigureAwait(false);
            if (snapshot.View is not { Current: { } current } view ||
                !await visibility.CanReadAsync(request.TenantId,context.Actor,current.Content.HandlingClass,
                    view.Assessments.Select(item => item.AssessedByMemberId).ToArray(),ct).ConfigureAwait(false))
                return Result<ComplianceIncidentView>.Failure(new RequestError(RequestErrorKind.NotFound,"The compliance incident was not found."));
            var confirmed = await consistency.ConfirmAsync(snapshot,ct).ConfigureAwait(false);
            return confirmed.IsSuccess ? Result<ComplianceIncidentView>.Success(view) : Result<ComplianceIncidentView>.Failure(confirmed.Error!);
        }
'''+text[end:]
 out=name.replace('SignificantChange','ComplianceIncident')+'.cs';(W/K/out).write_text(text)
# Projector replay uses compact authority in a fresh projection generation.
p=W/K/'ComplianceIncidentDirectoryProjector.cs';s=p.read_text().replace('ComplianceIncidentDirectoryV1','ComplianceIncidentDirectoryV2');p.write_text(s)
(W/K/'ComplianceIncidentReadConsistency.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Fences verified scoped details and current restricted authorization against a later owner change.</summary>
public sealed class ComplianceIncidentReadConsistency(IAggregateReader reader)
{
    public async ValueTask<Result> ConfirmAsync(ComplianceIncidentReadSnapshot snapshot,CancellationToken ct)
    {
        var owner = snapshot.Owner;
        var current = await reader.HydrateAsync(new ComplianceIncident(owner.TenantId,owner.ProgramId,owner.Id),ct).ConfigureAwait(false);
        return current.NativeSequence == owner.NativeSequence && current.CommittedStreamPosition == owner.CommittedStreamPosition
            ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict,"The incident changed while its exact authorized source was composed. Retry the query.",true));
    }
}
''')
(W/K/'GetComplianceImpactAssessmentHandler.cs').write_text('''using Bdgrz.Compliance.Features.Changes;
using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

public sealed class GetComplianceImpactAssessmentHandler(ComplianceIncidentReader incidents,RestrictedComplianceRecordVisibility visibility,
    ComplianceIncidentReadConsistency consistency) : IRequestHandler<GetComplianceImpactAssessment,ComplianceIncidentImpactAssessmentView>
{
    public async ValueTask<Result<ComplianceIncidentImpactAssessmentView>> HandleAsync(IRequestContext<GetComplianceImpactAssessment> context,CancellationToken ct)
    {
        var request = context.Request;
        if (request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty || request.IncidentId == Uuid.Empty)
            return Result<ComplianceIncidentImpactAssessmentView>.Failure(new RequestError(RequestErrorKind.Validation,"Tenant, program and incident identities are required."));
        try
        {
            var snapshot = await incidents.ReadAsync(request.TenantId,request.ProgramId,request.IncidentId,ct).ConfigureAwait(false);
            if (snapshot.View is not { Current: { } version,CurrentAssessment: { } assessment } view ||
                !await visibility.CanReadAsync(request.TenantId,context.Actor,version.Content.HandlingClass,
                    view.Assessments.Select(item => item.AssessedByMemberId).ToArray(),ct).ConfigureAwait(false))
                return Result<ComplianceIncidentImpactAssessmentView>.Failure(new RequestError(RequestErrorKind.NotFound,"The current compliance-incident assessment was not found."));
            var confirmed = await consistency.ConfirmAsync(snapshot,ct).ConfigureAwait(false);
            return confirmed.IsSuccess ? Result<ComplianceIncidentImpactAssessmentView>.Success(assessment) : Result<ComplianceIncidentImpactAssessmentView>.Failure(confirmed.Error!);
        }
        catch (ImmutableContentIntegrityException exception)
        { return Result<ComplianceIncidentImpactAssessmentView>.Failure(IncidentOperations.ContentFailure(exception)); }
    }
}
''')
p=W/K/'IncidentOperations.cs';s=p.read_text().replace('A incident operation','An incident operation').replace('The system incident','The incident').replace('RequestErrorKind.Conflict,"The incident requires its current positive original logical revision."','RequestErrorKind.Validation,"The expected revision must not be negative."');p.write_text(s)
# Preserve the previous direct-call forbidden result instead of letting a handler assume authorization ran.
for name in ['RecordComplianceIncidentHandler','ReviseComplianceIncidentHandler','AssessComplianceIncidentHandler','RecordComplianceIncidentResolutionHandler']:
 p=W/K/(name+'.cs');s=p.read_text().replace('using Bdgrz.Compliance.Features.Programs;','using Bdgrz.Compliance.Features.Programs;\nusing Bdgrz.Compliance.Features.UserIdentities;').replace('if (RequestActor.IsSystem(context.Actor))','if (RequestActor.IsSystem(context.Actor) || !UserIdentityClaims.TryGetBdgrzSubject(context.Actor,out _))');p.write_text(s)
