from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared');K='src/Compliance.Core/Features/Incidents/';W=P/'work';s=(P/'base'/K/'ComplianceIncident.cs').read_text()
s=s.replace('using Bdgrz.Compliance.Hosting.Persistence;\n','').replace('public sealed class ComplianceIncident : Aggregate','public sealed class ComplianceIncidentRules').replace('    const int MaximumVersions = 32;\n','').replace('    const int MaximumEventBytes = DomainEventPayload.MaximumBytes;\n','')
s=s.replace('    /// <summary>Acceptance of the logical operation this hydration was selected for.</summary>\n    public NativeAcceptance Acceptance { get; }\n','''    readonly Dictionary<Type,Action<object>> _reducers = [];
    readonly List<object> _applied = [];
    readonly List<object> _pending = [];
    bool _currentOnly;
    public Uuid Id { get; }
    public EventStreamAddress Stream { get; }
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;
    public IReadOnlyList<object> AppliedChanges => _applied.AsReadOnly();
    public IReadOnlyList<object> PendingChanges => _pending.AsReadOnly();
    public void ClearPendingChanges() => _pending.Clear();
    void On<T>(Action<T> reducer) where T : class => _reducers.Add(typeof(T),value => reducer((T)value));
    public void Apply(object value)
    {
        if (!_reducers.TryGetValue(value.GetType(),out var reduce))
            throw new InvalidOperationException("The incident rule mutation has another kind.");
        reduce(value);_applied.Add(value);
    }
    void RaiseEvent(object value) { Apply(value);_pending.Add(value); }
    internal static ComplianceIncidentRules FromView(ComplianceIncidentView? view,Uuid tenant,Uuid program,Uuid id,bool currentOnly = false)
    {
        var rules = new ComplianceIncidentRules(tenant,program,id) { _currentOnly = currentOnly };
        if (view is not null) rules._current = Freeze(view);
        return rules;
    }
''')
start=s.index('    public ComplianceIncident(');end=s.index('    public CommandFailure? Record(',start)
s=s[:start]+'''    public ComplianceIncidentRules(Uuid tenantId,Uuid programId,Uuid incidentId)
    {
        Id = incidentId;Stream = new EventStreamAddress(tenantId.ToString(),ComplianceIncident.Area,incidentId.ToString());
        _tenantId = tenantId;_programId = programId;
        On<ComplianceIncidentRecordedBody>(Apply);
        On<ComplianceIncidentRevisedBody>(Apply);
        On<ComplianceIncidentImpactAssessedBody>(Apply);
        On<ComplianceIncidentSystemDescriptionDecisionRecordedBody>(Apply);
        On<IncidentResolutionRecordedBody>(Apply);
    }

'''+s[end:]
# Replace operation-bearing business entry methods, retaining the exact actual planning/guard code.
start=s.index('    /// <summary>Checks a revision');end=s.index('    CommandFailure? PlanRevise',start)
s=s[:start]+'''    public CommandFailure? Revise(long expectedRevision,ComplianceIncidentContent content,string changeReason,
        Uuid actorMemberId,string actorDisplay,DateTimeOffset at)
    {
        if (PlanRevise(expectedRevision,content,changeReason,actorMemberId,actorDisplay,at,out var state) is { } failure) return failure;
        return Emit(state!,actorMemberId,at,static (tenant,subject,revision,actor,snapshot,time) =>
            new ComplianceIncidentRevisedBody(tenant,subject,revision,actor,snapshot,time),"revise");
    }

'''+s[end:]
start=s.index('    /// <summary>Checks an assessment');end=s.index('    CommandFailure? PlanAssess',start)
s=s[:start]+'''    public CommandFailure? Assess(long expectedRevision,ComplianceIncidentImpactAssessmentContent content,
        Uuid actorMemberId,string actorDisplay,DateTimeOffset at)
    {
        if (PlanAssess(expectedRevision,content,actorMemberId,actorDisplay,at,out var state) is { } failure) return failure;
        return Emit(state!,actorMemberId,at,static (tenant,subject,revision,actor,snapshot,time) =>
            new ComplianceIncidentImpactAssessedBody(tenant,subject,revision,actor,snapshot,time),"assessment");
    }

'''+s[end:]
start=s.index('    /// <summary>Checks a description');end=s.index('    CommandFailure? PlanDecision',start)
s=s[:start]+'''    public CommandFailure? RecordSystemDescriptionDecision(string decision,Uuid decisionId,string rationale,
        Uuid actorMemberId,string actorDisplay,DateTimeOffset at)
    {
        if (PlanDecision(decision,decisionId,rationale,actorMemberId,actorDisplay,at,out var state) is { } failure) return failure;
        return Emit(state!,actorMemberId,at,static (tenant,subject,revision,actor,snapshot,time) =>
            new ComplianceIncidentSystemDescriptionDecisionRecordedBody(tenant,subject,revision,actor,snapshot,time),"description_decision");
    }

'''+s[end:]
start=s.index('    /// <summary>Checks a resolution');end=s.index('    CommandFailure? PlanResolve',start)
s=s[:start]+'''    public CommandFailure? Resolve(long expectedRevision,VerifiedIncidentResolution resolution,
        Uuid actorMemberId,string actorDisplay,DateTimeOffset at)
    {
        if (PlanResolve(expectedRevision,resolution,actorMemberId,actorDisplay,at,out var state) is { } failure) return failure;
        return Emit(state!,actorMemberId,at,static (tenant,subject,revision,actor,snapshot,time) =>
            new IncidentResolutionRecordedBody(tenant,subject,revision,actor,snapshot,time),"resolution");
    }

'''+s[end:]
start=s.index('    CommandFailure? OwnOperation(');end=s.index('    void ApplyState(',start)
s=s[:start]+'''    void Apply(ComplianceIncidentRecordedBody ev) => ApplyState(ev.TenantId,ev.SubjectId,ev.Revision,ev.ActorMemberId,ev.State,ev.OccurredAt,true,"record");
    void Apply(ComplianceIncidentRevisedBody ev) => ApplyState(ev.TenantId,ev.SubjectId,ev.Revision,ev.ActorMemberId,ev.State,ev.OccurredAt,false,"revise");
    void Apply(ComplianceIncidentImpactAssessedBody ev) => ApplyState(ev.TenantId,ev.SubjectId,ev.Revision,ev.ActorMemberId,ev.State,ev.OccurredAt,false,"assessment");
    void Apply(ComplianceIncidentSystemDescriptionDecisionRecordedBody ev) => ApplyState(ev.TenantId,ev.SubjectId,ev.Revision,ev.ActorMemberId,ev.State,ev.OccurredAt,false,"description_decision");
    void Apply(IncidentResolutionRecordedBody ev) => ApplyState(ev.TenantId,ev.SubjectId,ev.Revision,ev.ActorMemberId,ev.State,ev.OccurredAt,false,"resolution");

'''+s[end:]
s=s.replace('Func<Uuid, Uuid, long, Uuid?, ComplianceIncidentView, DateTimeOffset, DomainEvent> createEvent','Func<Uuid, Uuid, long, Uuid?, ComplianceIncidentView, DateTimeOffset, object> createEvent')
s=s.replace('        if (DomainEventPayload.Size(ev) > MaximumEventBytes)\n            return Invalid("The complete incident chronology exceeds the bounded event payload.");\n','')
s=s.replace('new ComplianceIncidentRecorded(tenant, subject, revision, actor, snapshot, at)','new ComplianceIncidentRecordedBody(tenant, subject, revision, actor, snapshot, at)')
s=s.replace('current.Status == "resolved" || current.Versions.Count >= MaximumVersions','current.Status == "resolved"').replace('A resolved incident or exhausted chronology cannot be revised.','A resolved incident cannot be revised.')
s=s.replace('    CommandFailure? ValidateState(ComplianceIncidentView state)','    public CommandFailure? ValidateState(ComplianceIncidentView state)')
s=s.replace('state.Versions.Count is < 1 or > MaximumVersions','state.Versions.Count < 1').replace('state.CurrentVersionNumber != state.Versions.Count','(!_currentOnly && state.CurrentVersionNumber != state.Versions.Count)').replace('version.Version != index + 1','version.Version != (_currentOnly ? state.Versions[0].Version : 1) + index')
s=s.replace('if (item.ContentVersion < 1 || item.ContentVersion > versions.Count ||','if (item.ContentVersion < 1 || versions.All(version => version.Version != item.ContentVersion) ||').replace('var content = versions[item.ContentVersion - 1].Content;','var content = versions.First(version => version.Version == item.ContentVersion).Content;')
# Pure transient snapshot mutations are not native events and carry no fake operation/result contracts.
(W/K/'ComplianceIncidentRules.cs').write_text(s)
for name in ['ComplianceIncidentRecorded','ComplianceIncidentRevised','ComplianceIncidentImpactAssessed','ComplianceIncidentSystemDescriptionDecisionRecorded','IncidentResolutionRecorded']:
 (W/K/(name+'Body.cs')).write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Transient local rule delta, never a native aggregate fact.</summary>
public sealed record '''+name+'''Body(Uuid TenantId,Uuid SubjectId,long Revision,Uuid? ActorMemberId,ComplianceIncidentView State,DateTimeOffset OccurredAt);
''')
print('Rules/plain mutation source saved; no main changes')
