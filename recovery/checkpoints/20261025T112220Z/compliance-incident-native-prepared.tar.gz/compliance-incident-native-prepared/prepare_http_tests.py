from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared/work/test/Compliance.Tests/Features/Incidents')
s=Path('/tmp/compliance-significant-change-prepared/work/test/Compliance.Tests/Features/Changes/SignificantChangeHttpTests.cs').read_text()
s=s.replace('Bdgrz.Compliance.Features.Changes','Bdgrz.Compliance.Features.Incidents').replace('Bdgrz.Compliance.Tests.Features.Changes','Bdgrz.Compliance.Tests.Features.Incidents').replace('SignificantChange','ComplianceIncident').replace('significant-changes','incidents').replace('significant_change_id','compliance_incident_id').replace('change_id','incident_id').replace('ChangeId','IncidentId').replace('changeId','incidentId').replace('ChangeRoute','IncidentRoute').replace('HideChange','HideIncident').replace('ChangeHttpContract','IncidentHttpContract').replace('Governed production change','Governed production incident').replace('change-reader@example.com','incident-reader@example.com').replace('significant-change-read-http-tests','incident-read-http-tests')
# Truthful preserved plain Unit wire contract, with native transport bridge already merged.
s=s.replace('ShouldReturnTypedUnitAndReplayGivenIdentifiedProductionCreationRoute','ShouldReturnOriginalUnit200AndEnforceCurrentAuthorizationGivenIdentifiedIncidentRetries')
start=s.index('        var request = new RecordComplianceIncident(');end=s.index('\n        // Act',start)
s=s[:start]+'''        var request = new RecordComplianceIncident(fixture.Tenant,fixture.Program,Uuid.CreateVersion4(),fixture.Body("HTTP native incident"));
'''+s[end:]
s=s.replace('        using var replay = await fixture.PutAsync(request);','''        using var replay = await fixture.PutAsync(request);
        var revision = new ReviseComplianceIncident(Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,request.IncidentId,1,
            request.Content with { Title = "Corrected HTTP incident" },"Correction");
        using var revised = await fixture.ReviseAsync(revision);
        fixture.Permissions.Allowed = false;
        using var denied = await fixture.PutAsync(request);
        fixture.Permissions.Allowed = true;
        using var original = await fixture.PutAsync(request);''')
s=s.replace('        Assert.Equal(1,await fixture.CountAsync(request.IncidentId));','''        Assert.Equal(HttpStatusCode.OK,revised.StatusCode);Assert.Equal(HttpStatusCode.Forbidden,denied.StatusCode);
        Assert.Equal(HttpStatusCode.OK,original.StatusCode);Assert.Equal("{}",await original.Content.ReadAsStringAsync());
        Assert.Equal(2,await fixture.CountAsync(request.IncidentId));''')
s=s.replace('        public Uuid Tenant { get; } = Uuid.CreateVersion4();','        public MutablePermissionAuthorizer Permissions { get; } = new();\n        public Uuid Tenant { get; } = Uuid.CreateVersion4();')
s=s.replace('        public Fixture(bool allowed = true)\n        {','        public Fixture(bool allowed = true)\n        {\n            Permissions.Allowed = allowed;')
s=s.replace('new RecordingPermissionAuthorizer(allowed)','Permissions')
start=s.index('            Assert.Null(package.Record(');end=s.index('            await ChangeSeeds.WriteAsync',start) if '            await ChangeSeeds.WriteAsync' in s[start:] else s.index('            await ComplianceIncidentSeeds.WriteAsync',start)
s=s[:start]+'''            Assert.Null(package.Record(Body("Governed production incident"),Member,"Incident recorder",Now));
'''+s[end:]
s=s.replace('ChangeSeeds.WriteAsync','IncidentSeeds.WriteAsync')
needle='        public async Task<HttpResponseMessage> PutAsync(RecordComplianceIncident request)'
helper='''        public ComplianceIncidentContent Body(string title) => new(null,null,null,null,title,"Complete governed incident chronology.","security","high",
            Now.AddHours(-2),Now.AddHours(-1),Member,true,false,[Uuid.CreateVersion4()],"confidential",[]);
        public async Task<HttpResponseMessage> ReviseAsync(ReviseComplianceIncident request)
        {
            using var body = new StringContent(JsonSerializer.Serialize(request,Bdgrz.Compliance.ComplianceCoreJsonContext.Default.ReviseComplianceIncident),Encoding.UTF8,"application/json");
            return await _client.PutAsync($"/api/v1/tenants/{Tenant}/programs/{Program}/incidents/{request.IncidentId}/revisions/{request.CommandId}",body);
        }
''';assert needle in s;s=s.replace(needle,helper+needle)
# Existing canonical GET is {incident_id}; query aliases must never shadow route identities.
s=s.replace('Assert.False(paths.TryGetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/incidents/{compliance_incident_id}", out _));','''Assert.False(paths.TryGetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/incidents/{compliance_incident_id}", out _));
        Assert.True(paths.GetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/incidents/{incident_id}/resolutions/{command_id}").TryGetProperty("put",out _));''')
needle='    sealed class ActiveTenant : ITenantActivity'
s=s.replace(needle,'''    sealed class MutablePermissionAuthorizer : IPermissionAuthorizer
    {
        public bool Allowed { get; set; } = true;
        public ValueTask<bool> IsAllowedAsync(Uuid tenant,Uuid user,Uuid member,string permission,CancellationToken ct = default) => ValueTask.FromResult(Allowed);
    }

'''+needle)
(P/'ComplianceIncidentHttpTests.cs').write_text(s)
