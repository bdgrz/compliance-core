from pathlib import Path
import json,shutil,hashlib,re
P=Path('/tmp/compliance-incident-native-prepared');W=P/'work';REC=Path('/tmp/compliance-native-receipts-prepared/work');I='src/Compliance.Core/Features/Incidents/'
p=W/I/'ComplianceIncidentReader.cs';s=p.read_text().replace('IImmutableContentStore content)','IImmutableContentStore content,INativeEventReceiptReader? receipts = null)',1)
s=s.replace('        DateTimeOffset? receipt = null;','        var observedSequence = 0L;\n        var excluded = false;')
s=s.replace('fact.NativeSequence != sequence+1 ||\n                receipt is { } previous && fact.Operation.AcceptedAt < previous','fact.NativeSequence != observedSequence+1')
s=s.replace('            if (fact.NativeSequence > owner.NativeSequence || through is { } cutoff && fact.Operation.AcceptedAt > cutoff) break;','''            if (fact.NativeSequence > owner.NativeSequence) break;
            observedSequence = fact.NativeSequence;
            if (through is { } cutoff)
            {
                if (receipts is null) throw new ImmutableContentUnavailableException("The exact broker receipt authority is not configured for this recorded-through query.");
                var recordedAt = await receipts.RecordedAtAsync(record,ct).ConfigureAwait(false);
                if (recordedAt > cutoff) { excluded = true;continue; }
                if (excluded) throw new ImmutableContentIntegrityException("The broker receipt cutoff does not select a complete causal prefix of incident history.");
            }''')
s=s.replace('            receipt = fact.Operation.AcceptedAt;facts.Add(record.Event);','            facts.Add(record.Event);')
s=s.replace('        if (through is null &&','        if (observedSequence != owner.NativeSequence)\n            throw new ImmutableContentUnavailableException("The complete captured native incident source cut is not readable yet.");\n        if (through is null &&');p.write_text(s)
# Layer this owning consumer delta atop the frozen shared receipt correction, not the previous false receipt baseline.
rel='src/Compliance.Core/Features/Operations/TypeIIPeriodCloseHistory.cs';source=REC/rel;shutil.copy2(source,P/'base'/rel)
j=json.loads((P/'baselines.json').read_text());row=next(x for x in j if x['path']==rel);row['baselineSource']=str(source);row['beforeSha256']=hashlib.sha256(source.read_bytes()).hexdigest();(P/'baselines.json').write_text(json.dumps(j,indent=2)+'\n')
p=W/rel;s=p.read_text().replace('IImmutableContentStore content,ComplianceIncidentReader incidents)','IImmutableContentStore content,ComplianceIncidentReader incidents,INativeEventReceiptReader receipts)')
s=s.replace('            if (state.Value.Program != program || state.Value.At > through)','            if (state.Value.Program != program)')
needle='            if (state.Value.Tenant != tenant';at=s.index(needle);s=s[:at]+'''            var recordedAt = await receipts.RecordedAtAsync(record,ct).ConfigureAwait(false);
            if (recordedAt > through) continue;
'''+s[at:]
s=s.replace('var captured = Capture(record.Stream,record.Event);','var captured = Capture(record.Stream,record.Event) with { RecordedAt = recordedAt };')
s=s.replace('pair.First.EventKind == pair.Second.EventKind &&','pair.First.EventKind == pair.Second.EventKind && pair.First.RecordedAt == pair.Second.RecordedAt &&');p.write_text(s)
p=W/'test/Compliance.Tests/Features/Incidents/IncidentNativeFixture.cs';s=p.read_text().replace('using System.Security.Claims;','using System.Security.Claims;\nusing Bdgrz.Compliance.Tests.Testing;');s=s.replace('var services = new ServiceCollection();services.AddSingleton<IEventStore>(Events);services.AddPortia();','''var services = new ServiceCollection();Receipts = new ReceiptTrackingEventStore(Events,Clock);
        services.AddSingleton<IEventStore>(Receipts);services.AddPortia();''').replace('new ComplianceIncidentReader(Reader,Events,Content)','new ComplianceIncidentReader(Reader,Events,Content,Receipts)').replace('    public InMemoryEventStore Events { get; } = new();','    public InMemoryEventStore Events { get; } = new();\n    public ReceiptTrackingEventStore Receipts { get; }');p.write_text(s)
for name in ['TypeIIPeriodCommandHandlerTests.CloseSources.cs','TypeIIPeriodCommandHandlerTests.CloseArchive.cs']:
 rel='test/Compliance.Tests/Features/Operations/'+name
 # Preserve our new native Incident archive/consumer work while using the actual receipt predecessor as saved base.
 shutil.copy2(REC/rel,P/'base'/rel)
 row=next(x for x in j if x['path']==rel);row['baselineSource']=str(REC/rel);row['beforeSha256']=hashlib.sha256((REC/rel).read_bytes()).hexdigest()
 p=W/rel;s=p.read_text()
 for using in ['using Microsoft.Extensions.DependencyInjection;','using Bdgrz.Compliance.Features.SourceFacts;']:
  if using not in s:s=using+'\n'+s
 s=re.sub(r'new SignificantChangeReader\(fixture.Reader,\s*fixture.Events,\s*fixture.Host.Content\)','new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Host.Content,fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>())',s)
 s=s.replace('new ComplianceIncidentReader(fixture.Reader,fixture.Events,fixture.Host.Content))','new ComplianceIncidentReader(fixture.Reader,fixture.Events,fixture.Host.Content,fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>()),fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>())')
 p.write_text(s)
(P/'baselines.json').write_text(json.dumps(j,indent=2)+'\n')
p=P/'shared-wiring-deltas.json';j=json.loads(p.read_text());j['requiresFrozenReceiptLayer']='/tmp/compliance-native-receipts-prepared/handoff.json';j['constructors']['ComplianceIncidentReader']=['IAggregateReader','IDomainEventReader','IImmutableContentStore','INativeEventReceiptReader?'];j['constructors']['TypeIIPeriodCloseHistory']=['IDomainEventReader','RestrictedComplianceRecordVisibility','SignificantChangeReader','IImmutableContentStore','ComplianceIncidentReader','INativeEventReceiptReader'];p.write_text(json.dumps(j,indent=2)+'\n')
# Fake commit authority in HTTP composition is explicit even though current reads never invoke it.
p=W/'test/Compliance.Tests/Features/Incidents/ComplianceIncidentHttpTests.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.SourceFacts;').replace('services.AddSingleton<IEventStore>(_events);\n                    services.AddSingleton<IDomainEventReader>(_events);','''var receipts = new ReceiptTrackingEventStore(_events,TimeProvider.System);
                    services.AddSingleton<IEventStore>(receipts);services.AddSingleton<IDomainEventReader>(receipts);
                    services.RemoveAll<INativeEventReceiptReader>();services.AddSingleton<INativeEventReceiptReader>(receipts);''');p.write_text(s)
