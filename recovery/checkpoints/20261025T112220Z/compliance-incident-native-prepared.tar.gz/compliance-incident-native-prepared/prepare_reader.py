from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared/work/src/Compliance.Core/Features/Incidents')
(P/'ComplianceIncidentReader.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.Work;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Verifies active write gates independently of historical bodies; reconstructs complete chronology for scoped/as-of reads.</summary>
public sealed class ComplianceIncidentReader(IAggregateReader reader,IDomainEventReader events,IImmutableContentStore content)
{
    public async ValueTask<ComplianceIncidentReadSnapshot> ReadAsync(Uuid tenant,Uuid program,Uuid incident,CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new ComplianceIncident(tenant,program,incident),ct).ConfigureAwait(false);
        return await ReadHistoryAsync(owner,program,null,ct).ConfigureAwait(false);
    }
    public async ValueTask<ComplianceIncidentReadSnapshot> ReadThroughAsync(Uuid tenant,Uuid program,Uuid incident,
        DateTimeOffset recordedThrough,CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new ComplianceIncident(tenant,program,incident),ct).ConfigureAwait(false);
        return await ReadHistoryAsync(owner,program,recordedThrough,ct).ConfigureAwait(false);
    }
    public async ValueTask<ComplianceIncidentReadSnapshot> ReadCurrentAsync(Uuid tenant,Uuid program,Uuid incident,CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new ComplianceIncident(tenant,program,incident),ct).ConfigureAwait(false);
        return await ReadCurrentAsync(owner,program,ct).ConfigureAwait(false);
    }
    internal async ValueTask<ComplianceIncidentReadSnapshot> ReadCurrentAsync(ComplianceIncident owner,Uuid program,CancellationToken ct)
    {
        if (owner.Header is not { } h || owner.ProgramId != program)
            return new(owner,new ComplianceIncidentRules(owner.TenantId,program,owner.Id),null,[]);
        if (owner.CurrentContent is not { Schema: ComplianceIncidentContentStore.AuthoritySchema } reference)
            throw new ImmutableContentIntegrityException("The incident lacks its immutable current authority.");
        var authority = await content.ReadJsonAsync<ComplianceIncidentCurrentAuthority>(owner.TenantId.ToString(),reference,ct).ConfigureAwait(false);
        var view = await ComposeCurrentAsync(h,authority,ct).ConfigureAwait(false);
        return new(owner,ComplianceIncidentRules.FromView(view,owner.TenantId,program,owner.Id,true),authority,[]);
    }
    async ValueTask<ComplianceIncidentView> ComposeCurrentAsync(ComplianceIncidentAuthorityHeader h,ComplianceIncidentCurrentAuthority authority,CancellationToken ct)
    {
        var version = await ReadAsync<ComplianceIncidentVersionView>(h.TenantId,authority.VersionContent,ComplianceIncidentContentStore.VersionSchema,ct).ConfigureAwait(false);
        var assessment = authority.AssessmentContent is { } a ? await ReadAsync<ComplianceIncidentImpactAssessmentView>(h.TenantId,a,ComplianceIncidentContentStore.AssessmentSchema,ct).ConfigureAwait(false) : null;
        var decision = authority.DecisionContent is { } d ? await ReadAsync<ComplianceIncidentSystemDescriptionDecisionView>(h.TenantId,d,ComplianceIncidentContentStore.DecisionSchema,ct).ConfigureAwait(false) : null;
        var resolution = authority.ResolutionContent is { } r ? await ReadAsync<ComplianceIncidentResolutionView>(h.TenantId,r,ComplianceIncidentContentStore.ResolutionSchema,ct).ConfigureAwait(false) : null;
        var view = new ComplianceIncidentView(h.TenantId,h.ProgramId,h.IncidentId,h.Status,h.Revision,h.CurrentVersionNumber,version,
            [version],assessment is null ? [] : [assessment],decision is null ? [] : [decision],resolution,h.ActorMemberId,h.ActorDisplay,h.UpdatedAt);
        if (!ComplianceIncidentContentStore.MatchesCurrent(h,authority,view))
            throw new ImmutableContentIntegrityException("The incident active components differ from its compact native authority.");
        if (resolution is not null)
            await VerifyCompletionsAsync(h.TenantId,h.ProgramId,resolution,ct).ConfigureAwait(false);
        return view;
    }
    Task<T> ReadAsync<T>(Uuid tenant,ImmutableContentRef value,string schema,CancellationToken ct) where T : notnull => value.Schema == schema
        ? content.ReadJsonAsync<T>(tenant.ToString(),value,ct)
        : throw new ImmutableContentIntegrityException("The incident component has another exact schema.");
    async ValueTask<ComplianceIncidentReadSnapshot> ReadHistoryAsync(ComplianceIncident owner,Uuid program,DateTimeOffset? through,CancellationToken ct)
    {
        var rules = new ComplianceIncidentRules(owner.TenantId,program,owner.Id);
        var facts = new List<DomainEvent>();
        if (owner.Header is null || owner.ProgramId != program)
            return new(owner,rules,null,facts);
        ComplianceIncidentCurrentAuthority? prior = null;
        ComplianceIncidentAuthorityHeader? priorHeader = null;
        IComplianceIncidentFact? last = null;
        var sequence = 0L;
        DateTimeOffset? receipt = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(owner.TenantId.ToString(),ComplianceIncident.Area,owner.Id.ToString()),EventCursor.Start,ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit) continue;
            if (record.Event is not IComplianceIncidentFact fact || record.Stream != owner.Stream || fact.Header.ProgramId != program ||
                fact.TenantId != owner.TenantId || fact.SubjectId != owner.Id || fact.NativeSequence != sequence+1 ||
                receipt is { } previous && fact.Operation.AcceptedAt < previous)
                throw new ImmutableContentIntegrityException("The incident history has another exact native sequence, receipt cut or owner scope.");
            if (fact.NativeSequence > owner.NativeSequence || through is { } cutoff && fact.Operation.AcceptedAt > cutoff) break;
            var mutation = await ReadAsync<ComplianceIncidentMutation>(owner.TenantId,fact.Change,ComplianceIncidentContentStore.ChangeSchema,ct).ConfigureAwait(false);
            var authority = await ReadAsync<ComplianceIncidentCurrentAuthority>(owner.TenantId,fact.CurrentContent,ComplianceIncidentContentStore.AuthoritySchema,ct).ConfigureAwait(false);
            var current = await ComposeCurrentAsync(fact.Header,authority,ct).ConfigureAwait(false);
            var payload = await ComplianceIncidentContentStore.ReadPayloadAsync(content,owner.TenantId,mutation.Payload,ct).ConfigureAwait(false);
            var frozen = new FrozenComplianceIncidentMutation(rules.Current is { } before ? ComplianceIncidentContentStore.CurrentOnly(before) : null,current,
                prior,authority,fact.CurrentContent,fact.Change,mutation,payload,fact.Header);
            if (fact.ChangeCount != 1 || mutation.Kind != fact.Operation.CommandKind || !ComplianceIncidentContentStore.Verify(frozen,priorHeader))
                throw new ImmutableContentIntegrityException("The incident immutable component differs from its actual selected local business transition.");
            if (ComplianceIncidentContentStore.Execute(rules,mutation.Kind,payload,current.ActorMemberId,current.ActorDisplay,current.UpdatedAt) is not null ||
                rules.Current is not { } composed || ContentDigest.OfJson(ComplianceIncidentContentStore.CurrentOnly(composed)) != ContentDigest.OfJson(current))
                throw new ImmutableContentIntegrityException("The reconstructed incident chronology differs from its verified current cut.");
            rules.ClearPendingChanges();prior = authority;priorHeader = fact.Header;last = fact;sequence = fact.NativeSequence;
            receipt = fact.Operation.AcceptedAt;facts.Add(record.Event);
        }
        if (through is null && (sequence != owner.NativeSequence || last is null || last.Header != owner.Header || last.CurrentContent != owner.CurrentContent))
            throw new ImmutableContentUnavailableException("The complete exact incident native source cut is not readable yet.");
        return new(owner,rules,prior,facts.AsReadOnly());
    }
    async ValueTask VerifyCompletionsAsync(Uuid tenant,Uuid program,ComplianceIncidentResolutionView resolution,CancellationToken ct)
    {
        foreach (var completion in resolution.FollowUpCompletions)
        {
            var proof = completion.Proof;
            if (proof.Source.Realm != tenant.ToString() || proof.Source.Area != CorrectiveAction.Area || proof.RequiredFacts.Schema != SourceFactProofs.RequiredFactsSchema ||
                proof.EventKind != EventKind.Of(typeof(CorrectiveActionCompletedV2)) || proof.EventId == Uuid.Empty || proof.OwnerRevision == 0)
                throw new ImmutableContentIntegrityException("The incident resolution has another required native completion proof kind or tenant.");
            var locator = await content.ReadJsonAsync<SourceFactLocator>(tenant.ToString(),proof.RequiredFacts,ct).ConfigureAwait(false);
            if (locator.Source != proof.Source || locator.EventId != proof.EventId || locator.ResourcePosition != proof.PhysicalPosition ||
                locator.AggregateVersion != proof.OwnerRevision || locator.PayloadSha256 != proof.PayloadSha256 ||
                locator.GlobalPosition != proof.GlobalPosition || locator.RealmPosition != proof.RealmPosition)
                throw new ImmutableContentIntegrityException("The incident completion proof differs from its exact immutable admitted locator.");
            DomainEvent? exact = null;
            try
            {
                await foreach (var record in events.ReadAsync(proof.Source,proof.PhysicalPosition,ct).ConfigureAwait(false))
                {
                    if (record.ResourceOffset != proof.PhysicalPosition) continue;
                    if (record.Stream != proof.Source) throw new ImmutableContentIntegrityException("A completion resolved on another source stream.");
                    exact = record.Event;break;
                }
            }
            catch (InvalidOperationException) { throw new ImmutableContentUnavailableException("The exact admitted corrective-action completion is not readable yet."); }
            if (exact is null) throw new ImmutableContentUnavailableException("The exact admitted corrective-action completion is not readable yet.");
            if (exact is not CorrectiveActionCompletedV2 fact || fact.Metadata.IsAudit || fact.Metadata.EventId != proof.EventId ||
                fact.Metadata.AggregateVersion != proof.OwnerRevision || ContentDigest.Sha256(fact,typeof(CorrectiveActionCompletedV2)) != proof.PayloadSha256 ||
                fact.TenantId != tenant || fact.ProgramId != program || proof.Source != new CorrectiveAction(tenant,program,fact.FindingId,fact.ActionId).Stream ||
                completion.WorkItemId != WorkCandidate.IdFor(fact.ActionId,WorkSource.CorrectiveAction))
                throw new ImmutableContentIntegrityException("The incident resolution is not bound to the exact committed completion in this program.");
        }
    }
}
''')
p=P/'ComplianceIncidentContentStore.cs';s=p.read_text().replace('            authority.Assessments.Select(item => item.ContentVersion)', '            authority.Assessments.Any(item => item.ContentVersion == view.CurrentVersionNumber) != (view.CurrentAssessment is not null) ||\n            authority.Assessments.Select(item => item.ContentVersion)');p.write_text(s)
