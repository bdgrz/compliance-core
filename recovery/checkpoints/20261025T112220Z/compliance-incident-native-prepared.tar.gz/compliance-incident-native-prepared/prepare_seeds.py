from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared/work');K=P/'src/Compliance.Core/Features/Incidents';T=P/'test/Compliance.Tests/Features/Incidents'
p=K/'ComplianceIncidentRules.cs';s=p.read_text().replace('    void RaiseEvent(object value)','    internal void RaiseEvent(object value)');p.write_text(s)
(T/'IncidentSeeds.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Incidents;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.Incidents;

/// <summary>Publishes pure fixture rules through the same compact native append and immutable proof seams as production.</summary>
static class IncidentSeeds
{
    public static async ValueTask<ComplianceIncident> WriteAsync(IAggregateWriter writer,IImmutableContentStore content,ComplianceIncidentRules source)
    {
        var owner = await OwnerAsync(content,source);
        await writer.SaveAsync(owner,new RequestDispatchContext(RequestActor.System));source.ClearPendingChanges();return owner;
    }
    public static async ValueTask<ComplianceIncident> OwnerAsync(IImmutableContentStore content,ComplianceIncidentRules source)
    {
        var owner = new ComplianceIncident(source.TenantId,source.ProgramId,source.Id);
        var cursor = new ComplianceIncidentRules(source.TenantId,source.ProgramId,source.Id);
        await AppendAsync(owner,cursor,null,source.AppliedChanges,content);
        return owner;
    }
    public static async ValueTask<ComplianceIncident> AppendAsync(IAggregateWriter writer,ComplianceIncidentReader reader,IImmutableContentStore content,ComplianceIncidentRules source)
    {
        var snapshot = await reader.ReadAsync(source.TenantId,source.ProgramId,source.Id);
        await AppendAsync(snapshot.Owner,snapshot.Rules,snapshot.Authority,source.PendingChanges.ToArray(),content);
        await writer.SaveAsync(snapshot.Owner,new RequestDispatchContext(RequestActor.System));source.ClearPendingChanges();return snapshot.Owner;
    }
    static async ValueTask AppendAsync(ComplianceIncident owner,ComplianceIncidentRules cursor,ComplianceIncidentCurrentAuthority? prior,
        IReadOnlyList<object> changes,IImmutableContentStore content)
    {
        foreach (var value in changes)
        {
            var before = cursor.Current;cursor.ClearPendingChanges();cursor.RaiseEvent(value);
            var state = cursor.Current!;
            var kind = value switch
            {
                ComplianceIncidentRecordedBody => nameof(RecordComplianceIncident),
                ComplianceIncidentRevisedBody => nameof(ReviseComplianceIncident),
                ComplianceIncidentImpactAssessedBody => nameof(AssessComplianceIncident),
                ComplianceIncidentSystemDescriptionDecisionRecordedBody => nameof(RecordComplianceIncidentSystemDescriptionDecision),
                IncidentResolutionRecordedBody => nameof(RecordComplianceIncidentResolution),
                _ => throw new InvalidOperationException("Another incident fixture mutation kind."),
            };
            var command = before is null ? owner.Id : Uuid.CreateVersion5(owner.Id,$"seed:{owner.NativeSequence+1}:{kind}");
            var actor = kind == nameof(RecordComplianceIncidentSystemDescriptionDecision)
                ? ActorReference.ForSystemProcess("system","system") : ActorReference.ForMember(state.ActorMemberId,state.ActorDisplay);
            var op = OwnerProvenance.For(owner,command,kind,actor,owner.Id.ToString(),before is null || kind == nameof(RecordComplianceIncidentSystemDescriptionDecision)
                ? null : unchecked((ulong)before.Revision),AuthoredIntentDigest.Compute(state),state.UpdatedAt) with { FirstOwner = owner.Stream };
            var frozen = await ComplianceIncidentContentStore.FreezeAsync(content,before,prior,owner.Header,cursor,kind,CancellationToken.None);
            var response = await NativeContent.FreezeUnitAsync(content,owner.TenantId);
            var first = await FirstResponses.FreezeAsync(content,owner.TenantId.ToString(),response.Response);
            var result = owner.Append(ComplianceIncidentContentStore.Fact(frozen,owner.NativeSequence+1,op,first,response.Result),frozen,owner.NativeSequence,owner.CommittedStreamPosition);
            Assert.True(result.IsSuccess,result.Error?.Message);prior = frozen.Authority;
        }
    }
}
''')
(T/'IncidentNativeFixture.cs').write_text('''using System.Security.Claims;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Incidents;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Hosting.Persistence;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Incidents;

sealed class IncidentNativeFixture : IAsyncDisposable
{
    readonly ServiceProvider _provider;
    readonly AsyncServiceScope _scope;
    public IncidentNativeFixture()
    {
        var services = new ServiceCollection();services.AddSingleton<IEventStore>(Events);services.AddPortia();
        _provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true });_scope = _provider.CreateAsyncScope();
        Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();Writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
        Executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();
        Incidents = new ComplianceIncidentReader(Reader,Events,Content);
        Operations = new IncidentOperations(new NativeOperationExecutor(Reader,Executor,Content),Incidents,Content,Clock);
    }
    public Uuid Tenant { get; } = Uuid.CreateVersion4();
    public Uuid Program { get; } = Uuid.CreateVersion4();
    public Uuid Incident { get; } = Uuid.CreateVersion4();
    public Uuid User { get; } = Uuid.CreateVersion4();
    public InMemoryEventStore Events { get; } = new();
    public IImmutableContentStore Content { get; } = new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient()));
    public IAggregateReader Reader { get; }
    public IAggregateWriter Writer { get; }
    public IAggregateExecutor Executor { get; }
    public ComplianceIncidentReader Incidents { get; }
    public IncidentOperations Operations { get; }
    public ClockStub Clock { get; } = new();
    public RequestContext<T> Context<T>(T request,Uuid? user = null) where T : IRequestBase => new(request,
        new ClaimsPrincipal(new ClaimsIdentity([new Claim("iss","bdgrz"),new Claim("sub",(user ?? User).ToString()),new Claim("name","Incident member")],"UnitTest")));
    public ComplianceIncidentContent Body(string title = "Production credential incident") => new(null,null,null,null,title,"Exact incident chronology",
        "security","high",Clock.Now.AddHours(-2),Clock.Now.AddHours(-1),RbacIds.Member(Tenant,User),true,false,[Uuid.CreateVersion4()],"confidential",[]);
    public async Task<ComplianceIncidentRules> SeedAsync(ComplianceIncidentContent? content = null,Uuid? id = null)
    {
        var rules = new ComplianceIncidentRules(Tenant,Program,id ?? Incident);
        Assert.Null(rules.Record(content ?? Body(),RbacIds.Member(Tenant,User),"Incident member",Clock.Now));
        await IncidentSeeds.WriteAsync(Writer,Content,rules);return rules;
    }
    public async Task<IReadOnlyList<DomainEvent>> FactsAsync(Uuid? id = null)
    {
        var result = new List<DomainEvent>();
        await foreach (var record in Events.ReadAsync(EventStreamPattern.ForPattern(Tenant.ToString(),ComplianceIncident.Area,(id ?? Incident).ToString()),EventCursor.Start,CancellationToken.None))
            if (!record.Event.Metadata.IsAudit)result.Add(record.Event);
        return result;
    }
    public async ValueTask DisposeAsync() { await _scope.DisposeAsync();await _provider.DisposeAsync(); }
    public sealed class ClockStub : TimeProvider
    {
        public DateTimeOffset Now { get; set; } = new(2026,10,24,12,0,0,TimeSpan.Zero);
        public override DateTimeOffset GetUtcNow() => Now;
    }
}
''')
# Keep fake completion shapes exclusively in the original pure-rule unit test helpers; production native seeds do not create source proofs.
p=P/'test/Compliance.Tests/IncidentFacts.cs';s=p.read_text();s=s.replace('ComplianceIncident incident','ComplianceIncidentRules incident');start=s.index('    static readonly ActorReference Actor');end=s.index('    /// <summary>A verified completion',start);s=s[:start]+s[end:]
s=s.replace('incident.Revise(Provenance(incident, "ReviseComplianceIncident", at), Response(),\n        expectedRevision, content, changeReason, actorMemberId, actorDisplay);','incident.Revise(expectedRevision,content,changeReason,actorMemberId,actorDisplay,at);')
s=s.replace('incident.Assess(Provenance(incident, "AssessComplianceIncident", at), Response(),\n        expectedRevision, content, assessorMemberId, assessorDisplay);','incident.Assess(expectedRevision,content,assessorMemberId,assessorDisplay,at);')
s=s.replace('incident.RecordSystemDescriptionDecision(Provenance(incident, "RecordComplianceIncidentSystemDescriptionDecision",\n            at), Response(), decision, decisionId, rationale, actorMemberId, actorDisplay, at);','incident.RecordSystemDescriptionDecision(decision,decisionId,rationale,actorMemberId,actorDisplay,at);')
s=s.replace('incident.Resolve(\n        Provenance(incident, "RecordComplianceIncidentResolution", at), Response(), expectedRevision,','incident.Resolve(expectedRevision,').replace('resolverMemberId, resolverDisplay);','resolverMemberId,resolverDisplay,at);')
s=s.replace('            Response(), 30, 20));','            new ImmutableContentRef(Uuid.CreateVersion4(),new string(\'b\',64),2,"application/json","source-fact-locator.v1"),30,20));')
s=s.replace('A verified completion carrying a well-formed proof','A pure-rule fixture completion carrying a well-formed proof shape').replace('Accepts incident operations on the aggregate under fresh logical ids for tests that need a state.','Pure-rule incident test conveniences; no native acceptance or production source proof is manufactured.');p.write_text(s)
