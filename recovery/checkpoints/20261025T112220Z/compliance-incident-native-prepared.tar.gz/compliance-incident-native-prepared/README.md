# Native Incident handoff

Frozen offline. 70 changed paths (48 source,19 test,3 shared). handoff.json and manifest.json are the exact source of artifact hashes/layers. All 64 captured original acceptance names and per-file assertion counts remain;21 new methods include theory rows. Modern parse91, explicit relevant constructors76, zero static errors. Reconstruction checks cover full67/core63/current-main4/foundation9/shared3. No compiler/runtime/Jev evidence is claimed.

The Aggregate retains compact authority and selected native acceptance. Immutable version/assessment/decision/resolution bodies and chronology stay outside command state. Current writes hydrate active components and assessor metadata without replaying historical narratives; full/as-of reads verify complete exact native mutation sequence, history hashes, body references and source proofs. Scoped readers use current restricted visibility and source/directory fences. The five existing producer/receiver paths preserve original revision, intent, actor, first-owner and frozen Unit response. All actual routes/tests/source consumers are included.

## Integration alternatives

Current main (legacy SystemDescription source owner): implementation-core.patch + tests-core.patch + current-main-overlaps.patch. The four current-main paths use the current Description API and complete new Incident API. Queue-native Description: implementation.patch + tests.patch, or replace four overlap paths using queued-system-description-overlap.patch once SD101 is integrated. These are alternative source baselines; no dual-read compatibility path is shipped. Source lookup remains scoped, and no new trusted callback/global identity lookup is invented.

Compose shared.patch from shared-wiring-deltas.json: four services, six JSON roots, four identified personal routes and existing canonical read routes/bridge. Preserve root's newer service/JSON/route/workload registration deltas. The shared full file baseline is frozen SD shared-work, not authoritative current main. Receipt prefix layer1113 is a prerequisite; new prefix locals are inferred and work with parent RecordedSourceReceiptPrefix rename.

## Independent proof foundation

source-proof-foundation.patch is9 paths and is included in full/core patches. It adds exact requested tuple/typed-byte checks before required-facts writes, an explicit physical-offset overload, and typed exact-source absence. Incident searches the exact scoped native stream for its named completion and uses its actual offset, so preceding audits do not shift it onto another fact. Missing proof sources stay transient in Incident; mismatch/corruption fails closed. SourceFactProofsTests supplies six old-API RED rows; apply source-proof-behavioral-red.patch first, run source-proof-red-filter.txt, then source-proof-green-after-red.patch. Other default BuildAsync users are not claimed audit-offset corrected; they remain inventoried internal work.

If foundation lands first, use incident-after-foundation-implementation.patch + incident-after-foundation-tests.patch + selected Description overlap + shared wiring. Avoid applying foundation twice. One missing-proof subtype assertion hunk touches AccessReviewBulkDecisionTests; preserve root/peer's independent reused-decision positive test in that file.

## Behavioral evidence to run centrally

Existing behavioral-red.patch has the old API lifetime32, legal1000+1000 reference payload, and exact creation retry regressions. Names remain in migrated native tests, supplemented by unknown append, current auth, scope, content failure/recovery, page completeness, verified completion/audit offsets, actual HTTP Unit200 and real native close→ZIP proof. Parent owns all red execution, formatting, strict build, focused-filter.txt, full unit and exact-file Jev.

## Explicit qualifications

The no_change-only trusted Incident receiver remains. There is no selected Incident approved_successor producer/receiver/permit pair; record this precise local gap and continue independently provable work. No issue was created. Only the actual corrective-action completion producer is mapped for follow-up verification. Final target JSON catalogs omit this Incident family; no fabricated selected contract count is asserted. Actual five fact schemas advance2→3, and no persisted legacy conversion is shipped. See protocol-qualification.md.

Frozen all-source receipt and SD101 artifacts were not modified. Source/WIP code was written only under /tmp. Parent runtime integration may require routine analyzer/constructor adaptation; static parse is not compilation.
