from pathlib import Path
import re
P=Path('/tmp/compliance-incident-native-prepared');W=P/'work';C='src/Compliance.Common/Features/Incidents/';K='src/Compliance.Core/Features/Incidents/'
def put(path,s): (W/path).write_text(s)
put(C+'ComplianceIncidentAuthorityHeader.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Bounded current incident authority; exact version/decision bodies and chronology remain immutable content.</summary>
public sealed record ComplianceIncidentAuthorityHeader(Uuid TenantId,Uuid ProgramId,Uuid IncidentId,long Revision,
    int CurrentVersionNumber,string ContentSha256,string Title,string Status,string HandlingClass,DateTimeOffset OccurredAt,
    DateTimeOffset DetectedAt,Uuid OwnerMemberId,Uuid ActorMemberId,string ActorDisplay,DateTimeOffset UpdatedAt,
    bool PeriodCloseEligible,string? CurrentAssessmentSha256,Uuid? CurrentAssessorMemberId,bool RequiresSystemDescriptionReview,
    string AssessmentHistorySha256,string HistorySha256);
''')
put(C+'ComplianceIncidentAssessmentToken.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Historical assessment identity/attribution needed for exact delayed-reaction classification without narrative history.</summary>
public sealed record ComplianceIncidentAssessmentToken(int ContentVersion,string AssessmentSha256,Uuid AssessorMemberId,
    DateTimeOffset AssessedAt,bool RequiresSystemDescriptionReview);
''')
put(C+'ComplianceIncidentCurrentAuthority.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Active incident gates and lightweight immutable assessment commitments; historical bodies are not retained here.</summary>
public sealed record ComplianceIncidentCurrentAuthority(ImmutableContentRef VersionContent,ImmutableContentRef? AssessmentContent,
    ImmutableContentRef? DecisionContent,ImmutableContentRef? ResolutionContent,IReadOnlyList<ComplianceIncidentAssessmentToken> Assessments);
''')
put(C+'IComplianceIncidentFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

public interface IComplianceIncidentFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid SubjectId { get; }
    long Revision { get; }
    Uuid? ActorMemberId { get; }
    ComplianceIncidentAuthorityHeader Header { get; }
    ImmutableContentRef CurrentContent { get; }
    ImmutableContentRef Change { get; }
    long NativeSequence { get; }
    int ChangeCount { get; }
    ImmutableContentRef OperationResult { get; }
    DateTimeOffset OccurredAt { get; }
}
''')
for name in ['ComplianceIncidentRecorded','ComplianceIncidentRevised','ComplianceIncidentImpactAssessed','ComplianceIncidentSystemDescriptionDecisionRecorded','IncidentResolutionRecorded']:
 old=(P/'base'/C/(name+'.cs')).read_text();tag=re.search(r'\[Discriminator\("([^"]+)"',old)[1]
 put(C+name+'.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>One bounded native incident fact with exact immutable business payload and original accepted response.</summary>
[Discriminator("'''+tag+'''", 3)]
public sealed record '''+name+'''(Uuid TenantId,Uuid SubjectId,long Revision,Uuid? ActorMemberId,
    ComplianceIncidentAuthorityHeader Header,ImmutableContentRef CurrentContent,ImmutableContentRef Change,long NativeSequence,
    int ChangeCount,OperationProvenance Operation,ImmutableContentRef FirstResponse,ImmutableContentRef OperationResult,
    DateTimeOffset OccurredAt) : DomainEvent,IComplianceIncidentFact;
''')
put(K+'ComplianceIncidentMutation.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>One exact changed business component and the immutable before/after current-authority commitments.</summary>
public sealed record ComplianceIncidentMutation(string Kind,string? BeforeSha256,string AfterSha256,ImmutableContentRef Payload);
''')
put(K+'FrozenComplianceIncidentMutation.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Verified preparation data consumed synchronously by the native owner at its exact cut.</summary>
public sealed record FrozenComplianceIncidentMutation(ComplianceIncidentView? Before,ComplianceIncidentView After,
    ComplianceIncidentCurrentAuthority? BeforeAuthority,ComplianceIncidentCurrentAuthority Authority,
    ImmutableContentRef CurrentContent,ImmutableContentRef Change,ComplianceIncidentMutation Mutation,object Payload,
    ComplianceIncidentAuthorityHeader Header);
''')
put(K+'ComplianceIncidentReadSnapshot.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Explicit verified read composition; not aggregate state or a compatibility owner surface.</summary>
public sealed record ComplianceIncidentReadSnapshot(ComplianceIncident Owner,ComplianceIncidentRules Rules,
    ComplianceIncidentCurrentAuthority? Authority,IReadOnlyList<DomainEvent> Facts)
{
    public ComplianceIncidentView? View => Rules.Current;
}
''')
