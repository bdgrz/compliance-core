from pathlib import Path
R=Path('/tmp/compliance-incident-native-prepared')
p=R/'work/test/Compliance.Tests/Features/SourceFacts/EventStoreSourceFactResolverTests.cs';s=p.read_text();old='''        // Assert
        Assert.IsType<SourceFactVerificationException>(failure);
    }

    [Fact]
    public async Task ShouldRejectGivenAuditRecord''';new='''        // Assert
        if (mismatch is "stream" or "realm")
            Assert.IsType<SourceFactUnavailableException>(failure);
        else
            Assert.IsType<SourceFactVerificationException>(failure);
    }

    [Fact]
    public async Task ShouldRejectGivenAuditRecord''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=R/'work/test/Compliance.Tests/Features/SourceFacts/SourceFactProofsTests.cs';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.SourceFacts;

public sealed class SourceFactProofsTests
{
    [Theory]
    [InlineData("stream")]
    [InlineData("physical_position")]
    [InlineData("native_version")]
    [InlineData("payload_digest")]
    [InlineData("metadata_event")]
    [InlineData("metadata_version")]
    public async Task ShouldWriteNoProofGivenResolverReturnsAnotherRequestedNativeTuple(string mismatch)
    {
        // Arrange
        var stream = new EventStreamAddress("proof-tenant", "tenants", "owner");
        var id = Uuid.CreateVersion4();
        var fact = new TenantRegistered(Uuid.CreateVersion4(), Uuid.CreateVersion4(), "Source", "source");
        fact.AttachMetadata(new(mismatch == "metadata_event" ? Uuid.CreateVersion4() : id, Uuid.CreateVersion4(),
            mismatch == "metadata_version" ? 9UL : 2UL, DateTimeOffset.UnixEpoch.AddDays(1)));
        var locator = new SourceFactLocator(mismatch == "stream" ? new("proof-tenant", "tenants", "another-owner") : stream,
            id, mismatch == "physical_position" ? 7UL : 1UL, 1001, 10001,
            mismatch == "native_version" ? 9UL : 2UL, mismatch == "payload_digest" ? new string('f', 64) : ContentDigest.Sha256(fact, typeof(TenantRegistered)));
        var content = new RejectProofWrites();
        var resolver = new RedirectingResolver(new(fact, locator));

        // Act
        var failure = await Record.ExceptionAsync(() => SourceFactProofs.BuildAsync<TenantRegistered>(resolver, content,
            stream.Realm, new NativeFactReference(stream, id, 2)));

        // Assert
        Assert.IsType<SourceFactVerificationException>(failure);
        Assert.Equal(0, content.Writes);
    }

    sealed class RedirectingResolver(ResolvedSourceFact value) : ISourceFactResolver
    {
        public Task<ResolvedSourceFact> ResolveAsync(EventStreamAddress stream, ulong resourcePosition, CancellationToken ct = default) =>
            Task.FromResult(value);
        public Task<VerifiedSourceProof<T>> VerifyAsync<T>(SourceFactProof<T> proof, CancellationToken ct = default) where T : DomainEvent =>
            throw new InvalidOperationException("This test exercises source proof creation.");
    }
    sealed class RejectProofWrites : IImmutableContentStore
    {
        public int Writes { get; private set; }
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid id, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default)
        {
            Writes++;
            throw new InvalidOperationException("A mismatched native source must not write an admitted proof.");
        }
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default) =>
            throw new InvalidOperationException("No admitted source proof exists in this test.");
    }
}
''')
p=R/'work/test/Compliance.Tests/Features/Incidents/ComplianceIncidentOperationTests.cs';s=p.read_text();anchor='''    [Fact]
    public async Task ShouldAppendNothingGivenExactRetryOfResolveAfterTheClockMoved()''';insert='''    [Fact]
    public async Task ShouldResolveExactCompletionPositionGivenAuditRecordPrecedesNativeCompletion()
    {
        // Arrange
        await using var host = new Host();
        var completed = await host.CompletedActionAsync(host.ProgramId);
        var source = new InMemoryEventStore();
        var next = 0UL;
        await foreach (var record in host.Events.ReadAsync(completed.Fact.Stream, 0, CancellationToken.None))
        {
            if (record.Event.Metadata.EventId == completed.Fact.EventId)
            {
                var audit = new TenantRegistered(host.TenantId, Uuid.CreateVersion4(), "Source audit", "source-audit");
                audit.AttachMetadata(new(Uuid.CreateVersion4(), record.Event.Metadata.AggregateId,
                    record.Event.Metadata.AggregateVersion - 1, Start, IsAudit: true));
                await source.AppendAsync(completed.Fact.Stream, next++, [audit]);
            }
            await source.AppendAsync(completed.Fact.Stream, next++, [record.Event]);
        }
        var verifier = new FollowUpCompletionVerifier(new EventStoreSourceFactResolver(source), host.Content, source);
        var resolution = new ComplianceIncidentResolutionContent("Verified corrective action completion.", Start,
            [], [completed.Fact]);

        // Act
        var verified = await verifier.VerifyAsync(host.TenantId, host.ProgramId, resolution, CancellationToken.None);

        // Assert
        Assert.True(verified.IsSuccess, verified.Error?.Message);
        var proof = Assert.Single(verified.Value.FollowUpCompletions).Proof;
        Assert.Equal(completed.Fact.EventId, proof.EventId);
        Assert.Equal(completed.Fact.AggregateVersion, proof.OwnerRevision);
        Assert.Equal(completed.Fact.AggregateVersion, proof.PhysicalPosition);
    }

''';assert anchor in s;s=s.replace(anchor,insert+anchor)
s=s.replace('''        public FollowUpCompletionVerifier Verifier { get; }''','''        public FollowUpCompletionVerifier Verifier { get; }
        public IDomainEventReader Events => _events;''')
p.write_text(s)
