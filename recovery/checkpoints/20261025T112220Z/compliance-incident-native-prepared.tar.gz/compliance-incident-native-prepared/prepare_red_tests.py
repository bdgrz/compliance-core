from pathlib import Path
import difflib
P=Path('/tmp/compliance-incident-native-prepared');T='test/Compliance.Tests/Features/Incidents/';base=(P/'base'/T/'ComplianceIncidentTests.cs').read_text()
cap='''    [Fact]
    public void ShouldRetainCompleteChronologyGivenMoreThanThirtyTwoGovernedIncidentVersions()
    {
        // Arrange
        var incident = RecordedIncident();

        // Act
        for (var version = 2; version <= 40; version++)
            Assert.Null(incident.Revise(incident.Revision,Content() with { Title = "Governed incident correction " + version },
                "Correct incident narrative",RecorderId,"Compliance lead",Now.AddMinutes(version)));

        // Assert
        Assert.Equal(40,incident.Current!.CurrentVersionNumber);
        Assert.Equal(40,incident.Current.Versions.Count);
    }

'''
large='''    [Fact]
    public void ShouldRetainAllGovernedReferencesGivenIncidentContentExceedsEventEnvelope()
    {
        // Arrange
        var incident = NewIncident();
        var content = Content() with
        {
            AffectedSystemIds = Enumerable.Range(0,1000).Select(_ => Uuid.CreateVersion4()).ToArray(),
            EvidenceArtifactIds = Enumerable.Range(0,1000).Select(_ => Uuid.CreateVersion4()).ToArray(),
        };

        // Act
        var failure = incident.Record(content,RecorderId,"Compliance lead",Now);

        // Assert
        Assert.Null(failure);
        Assert.Equal(1000,incident.Current!.Current!.Content.AffectedSystemIds.Count);
        Assert.Equal(1000,incident.Current.Current.Content.EvidenceArtifactIds.Count);
    }

'''
red=base.replace('    [Fact]\n',cap+large+'    [Fact]\n',1);(P/'behavioral-red-source.cs').write_text(red)
work=red.replace('Bdgrz.Compliance.Features.Incidents.ComplianceIncident;','Bdgrz.Compliance.Features.Incidents.ComplianceIncidentRules;')
work=work.replace('        var events = new AggregateScenario<ComplianceIncidentAggregate>(incident).PendingEvents.ToArray();','        var events = incident.AppliedChanges.ToArray();').replace('        var replay = new AggregateScenario<ComplianceIncidentAggregate>(NewIncident()).Given(events).Aggregate;','        var replay = NewIncident();\n        foreach (var value in events) replay.Apply(value);')
start=work.index('    [Fact]\n    public void ShouldRejectOversizedConcreteEvent');end=work.index('    [Fact]',start+12)
work=work[:start]+'''    [Fact]
    public async Task ShouldRejectOversizedConcreteEventGivenIndividuallyValidIncidentFields()
    {
        // Arrange
        await using var fixture = new IncidentNativeFixture();
        var incident = NewIncident();
        Assert.Null(incident.Record(Content(),RecorderId,"Compliance lead",Now));
        var owner = new Bdgrz.Compliance.Features.Incidents.ComplianceIncident(TenantId,ProgramId,IncidentId);
        var frozen = await Bdgrz.Compliance.Features.Incidents.ComplianceIncidentContentStore.FreezeAsync(fixture.Content,null,null,null,incident,
            nameof(RecordComplianceIncident),CancellationToken.None);
        var op = Bdgrz.Compliance.Features.NativeOperations.OwnerProvenance.For(owner,IncidentId,nameof(RecordComplianceIncident),
            Bdgrz.Compliance.Features.NativeOperations.ActorReference.ForMember(RecorderId,new string('x',500000)),IncidentId.ToString(),null,
            new string('a',64),Now) with { FirstOwner = owner.Stream };
        var response = await Bdgrz.Compliance.Features.NativeOperations.NativeContent.FreezeUnitAsync(fixture.Content,TenantId);
        var first = await Bdgrz.Compliance.Features.NativeOperations.FirstResponses.FreezeAsync(fixture.Content,TenantId.ToString(),response.Response);
        var fact = ComplianceIncidentContentStore.Fact(frozen,1,op,first,response.Result);

        // Act
        var result = owner.Append(fact,frozen,0,0);

        // Assert
        Assert.True(Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.Size(fact) > Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.MaximumBytes);
        Assert.False(result.IsSuccess);Assert.Equal(RequestErrorKind.Conflict,result.Error!.Kind);
        Assert.Empty(new AggregateScenario<Bdgrz.Compliance.Features.Incidents.ComplianceIncident>(owner).PendingEvents);
    }

'''+work[end:]
# Strengthen the two new old-surface cases with actual native publication/readback after migration.
for name in ['ShouldRetainCompleteChronologyGivenMoreThanThirtyTwoGovernedIncidentVersions','ShouldRetainAllGovernedReferencesGivenIncidentContentExceedsEventEnvelope']:
 work=work.replace('public void '+name,'public async Task '+name)
work=work.replace('        Assert.Equal(40,incident.Current.Versions.Count);','''        Assert.Equal(40,incident.Current.Versions.Count);
        await using var fixture = new IncidentNativeFixture();
        await IncidentSeeds.WriteAsync(fixture.Writer,fixture.Content,incident);
        var read = await fixture.Incidents.ReadAsync(TenantId,ProgramId,IncidentId);
        Assert.Equal(40,read.View!.Versions.Count);Assert.Equal(40,read.Owner.NativeSequence);
        var authority = await fixture.Content.ReadJsonAsync<ComplianceIncidentCurrentAuthority>(TenantId.ToString(),read.Owner.CurrentContent!);
        Assert.Empty(authority.Assessments);
        await foreach (var source in fixture.Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString(),"compliance-incidents",IncidentId.ToString()),EventCursor.Start,CancellationToken.None))
            if (!source.Event.Metadata.IsAudit)
                Assert.True(Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.Size(source.Event) < Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.MaximumBytes);''')
work=work.replace('        Assert.Equal(1000,incident.Current.Current.Content.EvidenceArtifactIds.Count);','''        Assert.Equal(1000,incident.Current.Current.Content.EvidenceArtifactIds.Count);
        await using var fixture = new IncidentNativeFixture();
        await IncidentSeeds.WriteAsync(fixture.Writer,fixture.Content,incident);
        var read = await fixture.Incidents.ReadAsync(TenantId,ProgramId,IncidentId);
        Assert.Equal(1000,read.View!.Current!.Content.AffectedSystemIds.Count);
        Assert.Equal(1000,read.View.Current.Content.EvidenceArtifactIds.Count);''')
work='using Bdgrz.Compliance.Features.Content;\n'+work;(P/'work'/T/'ComplianceIncidentTests.cs').write_text(work)
(P/'behavioral-red.patch').write_text(''.join(difflib.unified_diff(base.splitlines(keepends=True),red.splitlines(keepends=True),fromfile='a/'+T+'ComplianceIncidentTests.cs',tofile='b/'+T+'ComplianceIncidentTests.cs')))
(P/'behavioral-red.md').write_text('''Old-API RED filters, independent and using existing aggregate + IncidentFacts extension surface only:

- `FullyQualifiedName~ComplianceIncidentTests.ShouldRetainCompleteChronologyGivenMoreThanThirtyTwoGovernedIncidentVersions`
- `FullyQualifiedName~ComplianceIncidentTests.ShouldRetainAllGovernedReferencesGivenIncidentContentExceedsEventEnvelope`

The first demonstrates the invented lifetime32 cap. The second supplies1,000 individually supported affected-system and evidence references and demonstrates the full-State event-frame rejection. Reverse standalone RED before applying full source/tests. Both names remain and gain native publication, immutable readback and bounded-frame checks. The original oversized-concrete-event acceptance remains, now rejecting an actually oversized native receipt while allowing supported legal source content in immutable storage. Parent owns all runtime evidence.
''')
