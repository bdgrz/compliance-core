from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared/work');C=P/'test/Compliance.Tests/Features/Changes'
for name in ['RestrictedComplianceRecordMutationAuthorizerTests','ComplianceImpactReactionHandlerTests']:
 p=C/(name+'.cs');s=p.read_text();s='using Bdgrz.Compliance.Tests.Features.Incidents;\n'+s
 s=s.replace('static ComplianceIncident AssessedIncident','static ComplianceIncidentRules AssessedIncident').replace('internal static ComplianceIncident AssessedIncident','internal static ComplianceIncidentRules AssessedIncident').replace('var incident = new ComplianceIncident(tenantId, programId, incidentId);','var incident = new ComplianceIncidentRules(tenantId,programId,incidentId);')
 writer='writer' if name=='RestrictedComplianceRecordMutationAuthorizerTests' else 'Writer'
 needle='        public ValueTask SaveAsync(Aggregate aggregate)'
 s=s.replace(needle,'        public ValueTask<ComplianceIncident> SaveAsync(ComplianceIncidentRules rules) => IncidentSeeds.WriteAsync('+writer+',Content,rules);\n\n'+needle)
 if name=='ComplianceImpactReactionHandlerTests':
  s=s.replace('            scenario.Operations, scenario.Descriptions, scenario.Content, new FixedTimeProvider(Now))','            scenario.IncidentOperations,scenario.Descriptions)')
  s=s.replace('await scenario.Reader.HydrateAsync(new ComplianceIncident(tenantId,\n            programId, incidentId))','await scenario.IncidentRulesAsync(tenantId,programId,incidentId)')
  s=s.replace('            Descriptions = new SystemDescriptionReader(Reader, events, Content);','''            Descriptions = new SystemDescriptionReader(Reader, events, Content);
            Incidents = new ComplianceIncidentReader(Reader,events,Content);
            IncidentOperations = new IncidentOperations(Operations,Incidents,Content,new FixedTimeProvider(Now));''')
  s=s.replace('        public SystemDescriptionReader Descriptions { get; }','''        public ComplianceIncidentReader Incidents { get; }
        public IncidentOperations IncidentOperations { get; }
        public async ValueTask<ComplianceIncidentRules> IncidentRulesAsync(Uuid tenant,Uuid program,Uuid incident) => (await Incidents.ReadAsync(tenant,program,incident)).Rules;
        public SystemDescriptionReader Descriptions { get; }''')
 p.write_text(s)
# Update the three exact Type II history constructor sites, retaining frozen Change/publisher constructor overlays.
for file in ['TypeIIPeriodCommandHandlerTests.CloseSources.cs','TypeIIPeriodCommandHandlerTests.CloseArchive.cs']:
 p=P/'test/Compliance.Tests/Features/Operations'/file;s=p.read_text();s='using Bdgrz.Compliance.Features.Incidents;\n'+s
 s=s.replace('new TypeIIPeriodCloseHistory(fixture.Reader, fixture.Events,','new TypeIIPeriodCloseHistory(fixture.Events,').replace('new TypeIIPeriodCloseHistory(fixture.Reader,fixture.Events,','new TypeIIPeriodCloseHistory(fixture.Events,')
 # All prepared constructor calls use final Content argument; limit replacement to exact known text.
 s=s.replace('fixture.Host.Services.GetRequiredService<SignificantChangeReader>(),fixture.Content)','fixture.Host.Services.GetRequiredService<SignificantChangeReader>(),fixture.Content,new ComplianceIncidentReader(fixture.Reader,fixture.Events,fixture.Content))')
 s=s.replace('new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Content),fixture.Content)','new SignificantChangeReader(fixture.Reader,fixture.Events,fixture.Content),fixture.Content,new ComplianceIncidentReader(fixture.Reader,fixture.Events,fixture.Content))')
 s=s.replace('new SignificantChangeReader(fixture.Reader, fixture.Events, fixture.Content), fixture.Content)','new SignificantChangeReader(fixture.Reader, fixture.Events, fixture.Content), fixture.Content,new ComplianceIncidentReader(fixture.Reader,fixture.Events,fixture.Content))')
 p.write_text(s)
