from pathlib import Path
import shutil,subprocess,json
R=Path('/tmp/compliance-incident-native-prepared');M=Path('/Users/jrepanich/Code/bdgrz/compliance-core');V=R/'current-main-overlaps'
paths=['src/Compliance.Core/Features/Incidents/RecordComplianceIncidentSystemDescriptionDecisionHandler.cs','src/Compliance.Core/Features/Changes/SystemDescriptionDecisionReactor.cs','test/Compliance.Tests/Features/Incidents/ComplianceIncidentOperationTests.cs','test/Compliance.Tests/Features/Changes/ComplianceImpactReactionHandlerTests.cs']
status=[]
for rel in paths:
 for d in ['base','work']:
  p=V/d/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(M/rel,p)
 if 'RecordComplianceIncidentSystemDescription' in rel:
  # Same native Incident prepare/guards, with exactly the current owning Description source reader.
  s=(R/'work'/rel).read_text().replace('IncidentOperations operations,SystemDescriptionReader descriptions)','IncidentOperations operations, IAggregateReader descriptions)')
  s=s.replace('''                SystemDescriptionReadSnapshot source;
                try { source = await descriptions.ReadAsync(request.TenantId,request.ProgramId,request.SystemDescriptionId,token).ConfigureAwait(false); }''','''                Bdgrz.Compliance.Features.SystemDescription.SystemDescription source;
                try { source = await descriptions.HydrateAsync(new Bdgrz.Compliance.Features.SystemDescription.SystemDescription(
                    request.TenantId, request.ProgramId, request.SystemDescriptionId), token).ConfigureAwait(false); }''')
  (V/'work'/rel).write_text(s);status.append({'path':rel,'strategy':'native Incident guards with current legacy Description source API'});continue
 run=subprocess.run(['diff3','-m',str(V/'base'/rel),str(R/'base'/rel),str(R/'work'/rel)],capture_output=True,text=True)
 (V/'work'/rel).write_text(run.stdout);status.append({'path':rel,'strategy':'three-way native Incident delta over current Description baseline','conflict':run.returncode!=0})
(V/'merge-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
