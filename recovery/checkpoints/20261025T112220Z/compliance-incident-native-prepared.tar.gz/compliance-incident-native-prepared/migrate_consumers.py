from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared');W=P/'work';C='src/Compliance.Core/Features/Changes/';I='src/Compliance.Core/Features/Incidents/'
# Existing mutation authorization needs only current compact restricted authority before retry, never historical narrative bytes.
p=W/C/'RestrictedComplianceRecordMutationAuthorizer.cs';s=p.read_text();s=s.replace('            var current = aggregate.Current;','            var current = aggregate.Header;').replace('current.ComplianceIncidentId != target.Id','current.IncidentId != target.Id').replace('currentHandlingClass = current?.Current?.Content.HandlingClass;','currentHandlingClass = current?.HandlingClass;',1 if False else 0) if False else s
start=s.index('        else\n        {\n            var aggregate =');end=s.index('\n        if (currentHandlingClass',start)
s=s[:start]+'''        else
        {
            var aggregate = await reader.HydrateAsync(new IncidentAggregate(request.TenantId,request.ProgramId,target.Id),ct).ConfigureAwait(false);
            var current = aggregate.Header;
            if (current is not null && (current.TenantId != request.TenantId || current.ProgramId != request.ProgramId || current.IncidentId != target.Id))
                return HiddenRecord();
            currentHandlingClass = current?.HandlingClass;
            currentAssessorIds = current?.CurrentAssessorMemberId is { } assessor ? [assessor] : [];
        }
'''+s[end:];p.write_text(s)
p=W/C/'AggregateSystemDescriptionDecisionCorrelationReader.cs';s=p.read_text().replace('IAggregateReader reader, SignificantChangeReader changes','ComplianceIncidentReader incidents, SignificantChangeReader changes');s=s.replace('var incident = await reader.HydrateAsync(new IncidentAggregate(tenantId, programId, incidentId), ct)','var incident = await incidents.ReadCurrentAsync(tenantId,programId,incidentId,ct)').replace('if (incident.Current is not','if (incident.View is not');p.write_text(s)
# Source/current read authority retains lightweight historical assessor identities required by the existing restricted-read policy.
(W/I/'ComplianceIncidentReadAuthority.cs').write_text('''namespace Bdgrz.Compliance.Features.Incidents;

/// <summary>Verified current handling and assessment identities without live narrative bodies.</summary>
public sealed record ComplianceIncidentReadAuthority(ComplianceIncident Owner,ComplianceIncidentCurrentAuthority Authority);
''')
p=W/I/'ComplianceIncidentReader.cs';s=p.read_text();needle='    public async ValueTask<ComplianceIncidentReadSnapshot> ReadAsync('
helper='''    public async ValueTask<ComplianceIncidentReadAuthority?> ReadAuthorityAsync(Uuid tenant,Uuid program,Uuid incident,CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new ComplianceIncident(tenant,program,incident),ct).ConfigureAwait(false);
        if (owner.Header is not { } h || h.ProgramId != program) return null;
        if (owner.CurrentContent is not { Schema: ComplianceIncidentContentStore.AuthoritySchema } reference)
            throw new ImmutableContentIntegrityException("The incident lacks its immutable current authority.");
        var authority = await content.ReadJsonAsync<ComplianceIncidentCurrentAuthority>(tenant.ToString(),reference,ct).ConfigureAwait(false);
        if (authority.Assessments is null || AuthoredIntentDigest.Compute(authority.Assessments) != h.AssessmentHistorySha256)
            throw new ImmutableContentIntegrityException("The current incident assessor identities differ from its native authority.");
        return new(owner,authority);
    }
''';s=s.replace(needle,helper+needle);p.write_text(s)
p=W/'src/Compliance.Core/Features/Operations/TypeIIPeriodCloseHistory.cs';s=p.read_text();s=s.replace('RestrictedComplianceRecordVisibility visibility, SignificantChangeReader changes, IImmutableContentStore content)','RestrictedComplianceRecordVisibility visibility, SignificantChangeReader changes, IImmutableContentStore content,ComplianceIncidentReader incidents)')
start=s.index('                    var current = await reader.HydrateAsync(new ComplianceIncident');end=s.index('                    if (past.Current is null',start)
s=s[:start]+'''                    var current = await incidents.ReadAuthorityAsync(period.TenantId,period.ProgramId,id,ct).ConfigureAwait(false)
                        ?? throw new ImmutableContentUnavailableException("A discovered native incident is not readable yet.");
                    var latest = current.Owner.Header!;
                    var past = (await incidents.ReadThroughAsync(period.TenantId,period.ProgramId,id,recordedThrough,ct).ConfigureAwait(false)).View
                        ?? throw new ImmutableContentIntegrityException("A scoped incident history has no complete verified final immutable state.");
'''+s[end:]
# Target only Incident visibility branch, preserving all accepted Change branches.
start=s.index('                    var current = await incidents.ReadAuthorityAsync');end=s.index('                    if (!past.PeriodCloseEligible)',start)
chunk=s[start:end].replace('latest.Current!.Content.HandlingClass','latest.HandlingClass').replace('latest.Assessments.Select(item => item.AssessedByMemberId).ToArray()','current.Authority.Assessments.Select(item => item.AssessorMemberId).ToArray()');s=s[:start]+chunk+s[end:]
needle='            result.Add(captured);';extra='''            if (record.Event is IComplianceIncidentFact incident)
            {
                var authority = await content.ReadJsonAsync<ComplianceIncidentCurrentAuthority>(tenant.ToString(),incident.CurrentContent,ct).ConfigureAwait(false);
                var mutation = await content.ReadJsonAsync<ComplianceIncidentMutation>(tenant.ToString(),incident.Change,ct).ConfigureAwait(false);
                var references = new[] { incident.CurrentContent,incident.Change,authority.VersionContent,authority.AssessmentContent,
                    authority.DecisionContent,authority.ResolutionContent,mutation.Payload }.OfType<Bdgrz.Compliance.Features.Proofs.ImmutableContentRef>().ToList();
                if (authority.ResolutionContent is { } resolutionRef)
                {
                    var resolution = await content.ReadJsonAsync<ComplianceIncidentResolutionView>(tenant.ToString(),resolutionRef,ct).ConfigureAwait(false);
                    references.AddRange(resolution.FollowUpCompletions.Select(item => item.Proof.RequiredFacts));
                }
                var blobs = new List<TypeIIPeriodCloseContentBlob>();
                foreach (var reference in references.Distinct().OrderBy(item => item.Schema,StringComparer.Ordinal).ThenBy(item => item.ContentId.ToString(),StringComparer.Ordinal))
                {
                    var bytes = await content.ReadVerifiedAsync(tenant.ToString(),reference,ct).ConfigureAwait(false);
                    blobs.Add(new(reference,Convert.ToBase64String(bytes.Span)));
                }
                captured = captured with { ContentBlobs = blobs.ToArray() };
            }
''';assert needle in s;s=s.replace(needle,extra+needle)
start=s.index('        ComplianceIncidentRecorded e =>');end=s.index('        _ => null,',start);s=s[:start]+'''        IComplianceIncidentFact e => (e.TenantId,e.Header.ProgramId,e.SubjectId,e.Operation.AcceptedAt),
'''+s[end:]
start=s.index('    static ComplianceIncidentView? IncidentState(');end=s.index('    static bool Same(',start);s=s[:start]+s[end:]
# Source constructor's old aggregate reader was solely the old Incident branch; remove it instead of adding unused DI dependencies.
s=s.replace('public sealed class TypeIIPeriodCloseHistory(IAggregateReader reader, IDomainEventReader events,','public sealed class TypeIIPeriodCloseHistory(IDomainEventReader events,');p.write_text(s)
