from pathlib import Path
P=Path('/tmp/compliance-incident-native-prepared');W=P/'work';K='src/Compliance.Core/Features/Incidents/';C='src/Compliance.Common/Features/Incidents/'
# Reuse the qualified native preparation flow, keeping Incident's actual plain Unit surface for the merged HTTP bridge.
s=Path('/tmp/compliance-system-description-prepared/work/src/Compliance.Core/Features/SystemDescription/SystemDescriptionOperations.cs').read_text()
s=s.replace('namespace Bdgrz.Compliance.Features.SystemDescription;','namespace Bdgrz.Compliance.Features.Incidents;').replace('SystemDescriptionReadSnapshot','ComplianceIncidentReadSnapshot').replace('SystemDescriptionOperations','IncidentOperations').replace('SystemDescriptionRules','ComplianceIncidentRules').replace('SystemDescriptionReader','ComplianceIncidentReader').replace('SystemDescription','ComplianceIncident').replace('descriptions','incidents').replace('description','incident')
s=s.replace('Uuid incident,Uuid command,string kind,long? expected,','Uuid incident,Uuid command,string kind,long? expected,ActorReference actor,')
start=s.index('        if (context.Invocation is not HttpInvocation');end=s.index('        if (tenant == Uuid.Empty',start);s=s[:start]+s[end:]
s=s.replace('if (expected is <= 0)','if (expected is < 0)').replace('ActorReference.ForMember(member,display),incident.ToString()','actor,incident.ToString()')
s=s.replace('FrozenComplianceIncidentMutation','FrozenComplianceIncidentMutation')
s=s.replace('Func<ComplianceIncidentRules,OperationProvenance,object?>? receipt,','')
s=s.replace('var snapshot = kind == nameof(BindComplianceIncidentToExamination)\n                            ? await incidents.ReadAsync(owner,program,token).ConfigureAwait(false)\n                            : await incidents.ReadCurrentAsync(owner,program,token).ConfigureAwait(false);','var snapshot = await incidents.ReadCurrentAsync(owner,program,token).ConfigureAwait(false);')
s=s.replace('nameof(CreateComplianceIncidentDraft)','nameof(RecordComplianceIncident)')
start=s.index('                        frozen = await ComplianceIncidentContent.FreezeAsync');end=s.index('                        var response = ',start)
s=s[:start]+'''                        frozen = await ComplianceIncidentContentStore.FreezeAsync(content,before,snapshot.Authority,owner.Header,snapshot.Rules,kind,token).ConfigureAwait(false);
'''+s[end:]
s=s.replace('ComplianceIncidentFactFactory.Create(frozen!','ComplianceIncidentContentStore.Fact(frozen!').replace('ComplianceIncidentReadFailure.Of(exception)','ContentFailure(exception)')
s=s.replace('    public static Result Outcome(CommandFailure? failure)', '''    public static RequestError ContentFailure(ImmutableContentIntegrityException exception) => new(RequestErrorKind.Conflict,
        "The incident's exact immutable source cannot be verified.",exception is ImmutableContentUnavailableException);
    public static Result Outcome(CommandFailure? failure)''')
(W/K/'IncidentOperations.cs').write_text(s)
# Identified stable creation identity; current Callable policy is preserved.
p=W/C/'RecordComplianceIncident.cs';s=p.read_text().replace('IRestrictedComplianceRecordMutationRequest, ICallable;','IRestrictedComplianceRecordMutationRequest, ICallable, IIdentifiedRequest\n{\n    Uuid IIdentifiedRequest.RequestId => IncidentId;\n}');p.write_text(s)
for name,kind,identity,expected,rule in [
 ('RecordComplianceIncident','RecordComplianceIncident','request.IncidentId','null','snapshot.Rules.Record(request.Content,member,display,operation.AcceptedAt)'),
 ('ReviseComplianceIncident','ReviseComplianceIncident','request.CommandId','request.ExpectedRevision','snapshot.Rules.Revise(request.ExpectedRevision,request.Content,request.ChangeReason,member,display,operation.AcceptedAt)'),
 ('AssessComplianceIncident','AssessComplianceIncident','request.CommandId','request.ExpectedRevision','snapshot.Rules.Assess(request.ExpectedRevision,request.Content,member,display,operation.AcceptedAt)')]:
 (W/K/(name+'Handler.cs')).write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Programs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

public sealed class '''+name+'''Handler(IncidentOperations operations) : IRequestHandler<'''+name+'''>
{
    public ValueTask<Result> HandleAsync(IRequestContext<'''+name+'''> context,CancellationToken ct)
    {
        var request = context.Request;
        if (RequestActor.IsSystem(context.Actor))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Forbidden,"An incident management operation requires a current Bdgrz member.")));
        var (member,display) = ClientServiceActor.Snapshot(context);
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.IncidentId,'''+identity+''',
            nameof('''+kind+'''),'''+expected+''',ActorReference.ForMember(member,display),
            (snapshot,operation,token) => ValueTask.FromResult(IncidentOperations.Outcome('''+rule+''')),ct);
    }
}
''')
(W/K/'RecordComplianceIncidentResolutionHandler.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Programs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

public sealed class RecordComplianceIncidentResolutionHandler(IncidentOperations operations,FollowUpCompletionVerifier completions)
    : IRequestHandler<RecordComplianceIncidentResolution>
{
    public ValueTask<Result> HandleAsync(IRequestContext<RecordComplianceIncidentResolution> context,CancellationToken ct)
    {
        var request = context.Request;
        if (RequestActor.IsSystem(context.Actor))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Forbidden,"Incident resolution requires a current Bdgrz member.")));
        var (member,display) = ClientServiceActor.Snapshot(context);
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.IncidentId,request.CommandId,
            nameof(RecordComplianceIncidentResolution),request.ExpectedRevision,ActorReference.ForMember(member,display),async (snapshot,operation,token) =>
            {
                if (request.Content is null)
                    return Result.Failure(new RequestError(RequestErrorKind.Validation,"The resolution is required."));
                var verified = await completions.VerifyAsync(request.TenantId,request.ProgramId,request.Content,token).ConfigureAwait(false);
                return !verified.IsSuccess ? Result.Failure(verified.Error!) : IncidentOperations.Outcome(snapshot.Rules.Resolve(request.ExpectedRevision,
                    verified.Value,member,display,operation.AcceptedAt));
            },ct);
    }
}
''')
(W/K/'RecordComplianceIncidentSystemDescriptionDecisionHandler.cs').write_text('''using Bdgrz.Compliance.Features.Changes;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.SystemDescription;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Incidents;

public sealed class RecordComplianceIncidentSystemDescriptionDecisionHandler(IncidentOperations operations,SystemDescriptionReader descriptions)
    : IRequestHandler<RecordComplianceIncidentSystemDescriptionDecision>
{
    public ValueTask<Result> HandleAsync(IRequestContext<RecordComplianceIncidentSystemDescriptionDecision> context,CancellationToken ct)
    {
        var request = context.Request;
        if (!RequestActor.IsSystem(context.Actor))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Forbidden,"System-description decisions may only be copied by a trusted reactor.")));
        if (request.ContentVersion < 1 || request.SystemDescriptionId == Uuid.Empty || request.SystemDescriptionVersionId == Uuid.Empty ||
            request.DecisionId == Uuid.Empty || request.AssessmentSha256 is not { Length: 64 } || !request.AssessmentSha256.All(Uri.IsHexDigit))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Validation,"The exact incident no-change decision is required.")));
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.IncidentId,request.CommandId,
            nameof(RecordComplianceIncidentSystemDescriptionDecision),null,ActorReference.ForSystemProcess("system","system"),async (snapshot,operation,token) =>
            {
                SystemDescriptionReadSnapshot source;
                try { source = await descriptions.ReadAsync(request.TenantId,request.ProgramId,request.SystemDescriptionId,token).ConfigureAwait(false); }
                catch (ImmutableContentIntegrityException exception) { return Result.Failure(SystemDescriptionReadFailure.Of(exception)); }
                var decision = SystemDescriptionDecisionCorrelation.Find(source,request.TenantId,request.ProgramId,request.IncidentId,
                    request.SystemDescriptionVersionId,request.DecisionId,"no_change",request.AssessmentSha256);
                if (decision is null || snapshot.View is not { } current)
                    return Conflict();
                var retained = snapshot.Authority?.Assessments.FirstOrDefault(item => item.ContentVersion == request.ContentVersion);
                if (retained is not null && retained.AssessmentSha256 != request.AssessmentSha256)
                    return Conflict();
                var outcome = ImpactReactionOutcomes.ClassifyDecision(request.ContentVersion,current.CurrentVersionNumber,retained is not null,
                    current.SystemDescriptionDecisions.Any(item => item.ContentVersion == request.ContentVersion),decision.DecidedAt,retained?.AssessedAt ?? default);
                if (outcome is not null) return Result.Failure(outcome);
                if (current.CurrentAssessment is not { RequiresSystemDescriptionReview: true } assessment || assessment.ContentVersion != request.ContentVersion ||
                    ComplianceIncident.AssessmentSha256(assessment) != request.AssessmentSha256 || decision.DecidedAt < assessment.AssessedAt)
                    return Conflict();
                return IncidentOperations.Outcome(snapshot.Rules.RecordSystemDescriptionDecision(decision.Decision,decision.DecisionId,
                    decision.Rationale,decision.ActorMemberId,decision.ActorDisplay,decision.DecidedAt));
            },ct);
    }
    static Result Conflict() => Result.Failure(new RequestError(RequestErrorKind.Conflict,"The no-change decision does not match the current incident assessment."));
}
''')
