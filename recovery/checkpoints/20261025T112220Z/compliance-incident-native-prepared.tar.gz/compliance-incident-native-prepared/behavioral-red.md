Old-API RED filters, independent and using existing aggregate + IncidentFacts extension surface only:

- `FullyQualifiedName~ComplianceIncidentTests.ShouldRetainCompleteChronologyGivenMoreThanThirtyTwoGovernedIncidentVersions`
- `FullyQualifiedName~ComplianceIncidentTests.ShouldRetainAllGovernedReferencesGivenIncidentContentExceedsEventEnvelope`

The first demonstrates the invented lifetime32 cap. The second supplies1,000 individually supported affected-system and evidence references and demonstrates the full-State event-frame rejection. Reverse standalone RED before applying full source/tests. Both names remain and gain native publication, immutable readback and bounded-frame checks. The original oversized-concrete-event acceptance remains, now rejecting an actually oversized native receipt while allowing supported legal source content in immutable storage. Parent owns all runtime evidence.

- `FullyQualifiedName~IncidentCreationRetryTests.ShouldReplayCreationWithoutNewFactGivenClockMovesBeforeExactRetry` exercises the real old creation handler, proving fresh server timestamps break exact authorized creation retries. The migrated case uses native creation acceptance and the original Unit response.
