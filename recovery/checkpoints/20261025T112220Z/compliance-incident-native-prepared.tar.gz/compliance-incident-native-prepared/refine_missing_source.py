exec(open('/tmp/compliance-incident-native-prepared/refine_receipts_and_proofs.py').read().split('# Future Incident overlays')[0])
p=capture('src/Compliance.Core/Features/SourceFacts/SourceFactVerificationException.cs');p.write_text(p.read_text().replace('public sealed class SourceFactVerificationException','public class SourceFactVerificationException'))
p=R/'work/src/Compliance.Core/Features/SourceFacts/SourceFactUnavailableException.cs';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('''namespace Bdgrz.Compliance.Features.SourceFacts;

/// <summary>The exact native source record is not visible yet; durable source consumers may retry.</summary>
public sealed class SourceFactUnavailableException(string message) : SourceFactVerificationException(message);
''')
p=capture('src/Compliance.Core/Features/SourceFacts/FitzSourceFactResolver.cs');p.write_text(p.read_text().replace('throw new SourceFactVerificationException($"No record exists at {concrete} offset {resourcePosition}.");','throw new SourceFactUnavailableException($"No record exists at {concrete} offset {resourcePosition}.");'))
p=capture('test/Compliance.Tests/Testing/EventStoreSourceFactResolver.cs');p.write_text(p.read_text().replace('throw new SourceFactVerificationException($"No record exists at {stream} offset {resourcePosition}.");','throw new SourceFactUnavailableException($"No record exists at {stream} offset {resourcePosition}.");'))
p=capture('test/Compliance.Tests/Features/SourceFacts/FitzSourceFactResolverTests.cs');p.write_text(p.read_text().replace('Assert.IsType<SourceFactVerificationException>(failure);','Assert.IsType<SourceFactUnavailableException>(failure);'))
p=capture('test/Compliance.Tests/Features/SourceFacts/EventStoreSourceFactResolverTests.cs');s=p.read_text();s=s.replace('''        Assert.IsType<SourceFactVerificationException>(failure);
    }

    static async Task<(EventStoreSourceFactResolver''','''        Assert.IsType<SourceFactUnavailableException>(failure);
    }

    static async Task<(EventStoreSourceFactResolver''');p.write_text(s)
p=R/'work/src/Compliance.Core/Features/Incidents/FollowUpCompletionVerifier.cs';s=p.read_text();s=s.replace('''            catch (SourceFactVerificationException exception)''','''            catch (SourceFactUnavailableException exception)
            {
                return Pending($"The exact committed completion source is not visible yet: {exception.Message}");
            }
            catch (SourceFactVerificationException exception)''');p.write_text(s)
