from pathlib import Path
import shutil,json,hashlib
R=Path('/Users/jrepanich/Code/bdgrz/compliance-core');P=Path('/tmp/compliance-incident-native-prepared');SD=Path('/tmp/compliance-system-description-prepared/work');CH=Path('/tmp/compliance-significant-change-prepared/work')
paths=set()
for folder in ['src/Compliance.Common/Features/Incidents','src/Compliance.Core/Features/Incidents','test/Compliance.Tests/Features/Incidents']:
 paths|={str(p.relative_to(R)) for p in (R/folder).glob('*.cs')}
paths|={'test/Compliance.Tests/IncidentFacts.cs','src/Compliance.Core/Features/Changes/RestrictedComplianceRecordMutationAuthorizer.cs','src/Compliance.Core/Features/Changes/AggregateSystemDescriptionDecisionCorrelationReader.cs','src/Compliance.Core/Features/Changes/SystemDescriptionDecisionReactor.cs','src/Compliance.Core/Features/Operations/TypeIIPeriodCloseHistory.cs','test/Compliance.Tests/Features/Changes/RestrictedComplianceRecordMutationAuthorizerTests.cs','test/Compliance.Tests/Features/Changes/ComplianceImpactReactionHandlerTests.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseSources.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.CloseArchive.cs'}
rows=[]
for path in sorted(paths):
 source=next(p/path for p in [SD,CH,R] if (p/path).exists())
 for folder in ['base','work']:
  target=P/folder/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 rows.append({'path':path,'baselineSource':str(source),'beforeSha256':hashlib.sha256(source.read_bytes()).hexdigest()})
(P/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');(P/'owning-paths.txt').write_text('\n'.join(sorted(paths))+'\n');print(len(paths))
