from pathlib import Path
import shutil,json
R=Path('/tmp/compliance-incident-native-prepared');M=Path('/Users/jrepanich/Code/bdgrz/compliance-core');A=Path('/tmp/compliance-all-source-receipts-prepared')
def capture(rel,source=None):
 p=R/'base'/rel;w=R/'work'/rel
 if not p.exists():
  src=Path(source) if source else M/rel
  p.parent.mkdir(parents=True,exist_ok=True);w.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p);shutil.copyfile(src,w)
 return w
# Future Incident overlays the shared all-source history baseline, retaining the native Incident branch.
rel='src/Compliance.Core/Features/Operations/TypeIIPeriodCloseHistory.cs';(R/'base'/rel).write_bytes((A/'work'/rel).read_bytes());p=R/'work'/rel;s=p.read_text();s=s.replace('''        var result = new List<TypeIIPeriodCloseNativeSource>();
        await foreach''','''        var result = new List<TypeIIPeriodCloseNativeSource>();
        var receiptCut = new RecordedSourceReceiptCutFactory(events, receipts).Create(tenant, through);
        await foreach''');s=s.replace('''            var recordedAt = await receipts.RecordedAtAsync(record,ct).ConfigureAwait(false);
            if (recordedAt > through) continue;''','''            var receiptStream = await receiptCut.ReadAsync(record.Stream, ct).ConfigureAwait(false);
            if (!receiptStream.Includes(record.Event)) continue;
            var recordedAt = receiptStream.RecordedAt(record.Event);''');p.write_text(s)
# Small source proof helper delta: explicit physical offset overload + full requested tuple/payload matching.
p=capture('src/Compliance.Core/Features/SourceFacts/SourceFactProofs.cs');s=p.read_text();s=s.replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;')
old='''    public static async Task<(SourceFactProof<TEvent> Proof, TEvent Fact, SourceFactLocator Locator)> BuildAsync<TEvent>(
        ISourceFactResolver resolver, IImmutableContentStore content, string realm, NativeFactReference reference,
        CancellationToken ct = default) where TEvent : DomainEvent
    {'''
new='''    public static Task<(SourceFactProof<TEvent> Proof, TEvent Fact, SourceFactLocator Locator)> BuildAsync<TEvent>(
        ISourceFactResolver resolver, IImmutableContentStore content, string realm, NativeFactReference reference,
        CancellationToken ct = default) where TEvent : DomainEvent =>
        BuildAsync<TEvent>(resolver, content, realm, reference,
            reference.AggregateVersion == 0 ? 0 : reference.AggregateVersion - 1, ct);

    /// <summary>Builds from the actual resource position discovered in the exact scoped native source stream, including preceding audits.</summary>
    public static async Task<(SourceFactProof<TEvent> Proof, TEvent Fact, SourceFactLocator Locator)> BuildAsync<TEvent>(
        ISourceFactResolver resolver, IImmutableContentStore content, string realm, NativeFactReference reference,
        ulong resourcePosition, CancellationToken ct = default) where TEvent : DomainEvent
    {'''
assert old in s;s=s.replace(old,new).replace('''        if (reference.AggregateVersion == 0)''','''        if (reference.Stream.Realm != realm)
            throw new SourceFactVerificationException("The requested source proof belongs to another exact realm.");
        if (reference.AggregateVersion == 0)''',1)
s=s.replace('resolver.ResolveAsync(reference.Stream, reference.AggregateVersion - 1, ct)','resolver.ResolveAsync(reference.Stream, resourcePosition, ct)')
s=s.replace('''        if (locator.EventId != reference.EventId)
            throw new SourceFactVerificationException("The record is not the referenced event.");''','''        if (locator.Source != reference.Stream || locator.ResourcePosition != resourcePosition ||
            locator.EventId != reference.EventId || locator.AggregateVersion != reference.AggregateVersion ||
            typed.Metadata.IsAudit || typed.Metadata.EventId != reference.EventId ||
            typed.Metadata.AggregateVersion != reference.AggregateVersion ||
            locator.PayloadSha256 != ContentDigest.Sha256(typed, typeof(TEvent)))
            throw new SourceFactVerificationException("The returned source does not match the exact requested native tuple and typed payload.");''')
p.write_text(s)
# Narrow receiver scope lookup resolves a true physical offset before asking the authoritative proof resolver.
p=R/'work/src/Compliance.Core/Features/Incidents/FollowUpCompletionVerifier.cs';s=p.read_text();s=s.replace('ISourceFactResolver resolver, IImmutableContentStore content)','ISourceFactResolver resolver, IImmutableContentStore content, IDomainEventReader events)')
s=s.replace('''                var (proof, fact, locator) = await SourceFactProofs.BuildAsync<CorrectiveActionCompletedV2>(resolver,
                    content, tenantId.ToString(), reference, ct).ConfigureAwait(false);''','''                DomainEventRecord? selected = null;
                try
                {
                    await foreach (var record in events.ReadAsync(reference.Stream, 0, ct).ConfigureAwait(false))
                    {
                        if (record.Stream != reference.Stream)
                            return Reject("The scoped completion history returned another native source stream.");
                        if (record.Event.Metadata.IsAudit || record.Event.Metadata.EventId != reference.EventId)
                            continue;
                        if (selected is not null || record.Event.Metadata.AggregateVersion != reference.AggregateVersion ||
                            record.Event is not CorrectiveActionCompletedV2)
                            return Reject("The named completion has no unique exact native source tuple.");
                        selected = record;
                    }
                }
                catch (InvalidOperationException)
                {
                    return Pending("The exact committed completion source is not readable yet.");
                }
                if (selected is null)
                    return Pending("The exact committed completion source is not visible yet.");
                var (proof, fact, locator) = await SourceFactProofs.BuildAsync<CorrectiveActionCompletedV2>(resolver,
                    content, tenantId.ToString(), reference, selected.ResourceOffset, ct).ConfigureAwait(false);''')
s=s.replace('''    static Result<VerifiedIncidentResolution> Reject''','''    static Result<VerifiedIncidentResolution> Pending(string message) => Result<VerifiedIncidentResolution>.Failure(
        new RequestError(RequestErrorKind.Conflict, message, true));

    static Result<VerifiedIncidentResolution> Reject''')
p.write_text(s)
# Explicit manual receiver fixture sites in the Incident snapshot.
for p in (R/'work/test').rglob('*.cs'):
 s=p.read_text();s=s.replace('new FollowUpCompletionVerifier(new EventStoreSourceFactResolver(_events), Content)','new FollowUpCompletionVerifier(new EventStoreSourceFactResolver(_events), Content, _events)')
 p.write_text(s)
