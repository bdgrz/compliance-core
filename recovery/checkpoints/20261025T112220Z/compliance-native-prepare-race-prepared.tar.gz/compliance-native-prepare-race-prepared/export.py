from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
r=Path('/tmp/compliance-native-prepare-race-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');test='test/Compliance.Tests/Features/NativeOperations/NativeOperationExecutorTests.cs'
def sha(b):return hashlib.sha256(b).hexdigest()
def diff(p,a,b):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
pro={x['path']:x for x in json.loads((r/'baselines.json').read_text())};red=(r/'old-api-red.cs').read_bytes();files={};manifest=[];patches={p:[] for p in ['implementation.patch','tests.patch','full.patch','green-after-red.patch']}
for f in sorted((r/'work').rglob('*.cs')):
 p=str(f.relative_to(r/'work'));base=r/'base'/p;assert base.exists(),p;before=base.read_bytes();after=f.read_bytes()
 if before==after:continue
 assert (repo/p).exists() and sha(before)==pro[p]['beforeSha256'],p
 files[p]={'before':before,'after':after};d=diff(p,before,after);phase='tests.patch' if p==test else 'implementation.patch';patches[phase].append(d);patches['full.patch'].append(d);patches['green-after-red.patch'].append(diff(p,red if p==test else before,after));manifest.append({'path':p,'beforeSha256':sha(before),'afterSha256':sha(after),'phase':phase,'redBeforeSha256':sha(red) if p==test else None,'baselineSource':pro[p]['baselineSource']})
for p,v in patches.items():(r/p).write_text(''.join(v))
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');orders={'tests-first':['tests-red.patch','green-after-red.patch'],'full':['full.patch'],'split':['implementation.patch','tests.patch']};verified={}
for mode,order in orders.items():
 t=Path(tempfile.mkdtemp(prefix='native-prepare-reconstruct-',dir=r))
 try:
  for p,x in files.items():
   f=t/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(x['before'])
  for p in order:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/p)],cwd=t,capture_output=True,text=True);assert x.returncode==0,(mode,p,x.stdout,x.stderr)
  assert all((t/p).read_bytes()==x['after'] for p,x in files.items()),mode
  verified[mode]={'exactFiles':len(files),'patchOrder':order}
 finally:shutil.rmtree(t)
(r/'reconstruction.json').write_text(json.dumps(verified,indent=2)+'\n');a=json.loads((r/'audit.json').read_text())
for k in ['syntaxErrors','constructorErrors','cancellationTokenNotLast','duplicateUsings','potentialMissingProofsUsing','removedAcceptanceNames','assertionCountDrops','existingRepositoryPathsMissingBefore']:assert not a[k],(k,a[k])
h={'root':str(r),'status':'FROZEN offline central native immutable-prepare exception race correction. Parent owns actual RED/GREEN/format/build/analyzers/full suite/direct per-file Jev/integration and delivery.','changedPaths':len(files),'sourcePaths':1,'testPaths':1,'existingPathsWithOriginals':2,'newPaths':0,'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'patches':{p:{'sha256':sha((r/p).read_bytes()),'bytes':(r/p).stat().st_size} for p in ['tests-red.patch',*patches]},'testsFirstOrder':orders['tests-first'],'allFinalOrder':orders['full'],'oldApiRedFilter':'FullyQualifiedName~ShouldReplayOriginalTypedResponseGivenEqualWinnerCommitsBeforeImmutablePreparationThrows','focusedFilter':'FullyQualifiedName~NativeOperationExecutorTests|FullyQualifiedName~NativeFirstResponseBridgeTests|FullyQualifiedName~NativeFirstResponseProductionHttpTests','suiteFilter':'Category!=BrokerIntegration','originalAcceptanceNames':a['originalAcceptanceNames'],'staticConstructorCalls':a['constructorCallsAcrossEffectiveTree'],'audit':'audit.json','reconstruction':'reconstruction.json','readme':'README.md','notes':['Expected ImmutableContentIntegrityException around operation.Prepare and FirstResponses.FreezeAsync rechecks exact native acceptance before classifying losing-candidate failure.','Equal winner returns original typed202 body/ref/native receipt and transport observation; changed-intent winner remains Conflict. No second append.','No winner rethrows the original exception unchanged, retaining existing outer transport/family transient/permanent classification or raw exception when no classifier exists.','Requested cancellation is checked before the recheck; OCE and unexpected programmer exceptions never enter the new catch.','Initial hydration/replay, failed-Result recovery, apply/append/OCC/unknown-outcome loops and observer/current authorization boundaries remain unchanged.','ExistingAPI RED has3 read/write/descriptor-freeze rows with winner commit inside actual failing immutable store callback. Green adds absent winner classification/rethrow, changed intent, requested/unrequested cancellation and programmer fault cases.','No family-specific workaround, SourceUse/proof publication change, wire/DI/JSON/constructor contract change.'],'noRuntimeOrJevClaims':True}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'manifestSha256':h['manifestSha256'],'handoffSha256':sha((r/'handoff.json').read_bytes()),'patches':h['patches']},indent=2))
