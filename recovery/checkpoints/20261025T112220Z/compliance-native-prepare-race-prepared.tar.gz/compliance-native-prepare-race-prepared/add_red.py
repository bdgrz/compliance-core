from pathlib import Path
import difflib,hashlib
r=Path('/tmp/compliance-native-prepare-race-prepared');p='test/Compliance.Tests/Features/NativeOperations/NativeOperationExecutorTests.cs';f=r/'work'/p;s=f.read_text();at=s.index('    const string ContentRoute');methods='''    [Theory]
    [InlineData("read")]
    [InlineData("write")]
    [InlineData("freeze")]
    public async Task ShouldReplayOriginalTypedResponseGivenEqualWinnerCommitsBeforeImmutablePreparationThrows(string stage)
    {
        // Arrange
        var state = await PreparationRaceAsync(stage, new ImmutableContentUnavailableException("The losing immutable preparation is unavailable."));
        await using var provider = state.Provider;

        // Act
        var result = await state.Loser.ExecuteAsync(state.Operation, Context(), CancellationToken.None);
        var replay = Assert.IsType<AcceptedAppendResult.Replayed>(result.Value);
        var winner = Assert.IsType<AcceptedAppendResult.Committed>(state.Winner());
        var body = Assert.IsType<StandardResponseBody>(replay.Response.Body);
        var typed = await state.Content.ReadJsonAsync<OperationAcceptedResponse>(Owner.Realm, body.Content);
        var exact = await state.Content.ReadVerifiedAsync(Owner.Realm, body.Content);

        // Assert
        Assert.Equal(winner.Response, replay.Response);
        Assert.Equal(winner.FirstResponse, replay.FirstResponse);
        Assert.Equal(winner.FirstFact, replay.FirstFact);
        Assert.Equal(202, replay.Response.HttpStatus);
        Assert.Equal(new OperationAcceptedResponse(Logical, "/winner", At), typed);
        Assert.Equal((await state.Content.ReadVerifiedAsync(Owner.Realm, state.WinnerBody)).ToArray(), exact.ToArray());
        Assert.Equal(1, await CountAsync(state.Events));
        Assert.Equal(0, state.Transport.Classifications);
        Assert.Same(replay, state.Transport.Observed);
    }

    static async Task<PreparationRace> PreparationRaceAsync(string stage, Exception failure,
        bool commitWinner = true, bool changedIntent = false, Action? beforeFailure = null)
    {
        var (provider, events, _) = Build();
        var content = provider.GetRequiredService<IImmutableContentStore>();
        var winnerBody = await content.WriteJsonAsync(Owner.Realm, Uuid.CreateVersion4(), "winner-response.v1",
            new OperationAcceptedResponse(Logical, "/winner", At));
        var candidate = await content.WriteJsonAsync(Owner.Realm, Uuid.CreateVersion4(), "loser-response.v1",
            new OperationAcceptedResponse(Logical, "/loser", At.AddHours(1)));
        var source = await content.WriteJsonAsync(Owner.Realm, Uuid.CreateVersion4(), "prepare-source.v1", new UnitResult());
        AcceptedAppendResult? accepted = null;
        async Task CompeteAsync()
        {
            if (commitWinner)
            {
                await using var scope = provider.CreateAsyncScope();
                var binding = changedIntent ? Provenance() with { AuthoredIntentSha256 = new string('e', 64) } : Provenance();
                var operation = Operation(binding, 202, "winner") with
                {
                    Prepare = (_, _) => ValueTask.FromResult(Result<FirstResponseDescriptor>.Success(new(202,
                        "application/json", winnerBody.Schema, new StandardResponseBody(winnerBody))))
                };
                var native = new NativeOperationExecutor(scope.ServiceProvider.GetRequiredService<IAggregateReader>(),
                    scope.ServiceProvider.GetRequiredService<IAggregateExecutor>(), content);
                var result = await native.ExecuteAsync(operation, Context(), CancellationToken.None);
                Assert.True(result.IsSuccess, result.Error?.Message);
                accepted = result.Value;
            }
            beforeFailure?.Invoke();
        }
        var faulty = new PreparationFaultStore(content, stage, failure, CompeteAsync);
        var transport = new PreparationTransport();
        // Keep the scope alive until its provider is disposed; the runtime executor resolves its original real reader.
        var execution = provider.CreateAsyncScope();
        var loser = new NativeOperationExecutor(execution.ServiceProvider.GetRequiredService<IAggregateReader>(),
            execution.ServiceProvider.GetRequiredService<IAggregateExecutor>(), faulty, transport);
        var losing = Operation(Provenance(), 202, "loser") with
        {
            Prepare = async (_, ct) =>
            {
                if (stage == "read")
                    _ = await faulty.ReadVerifiedAsync(Owner.Realm, source, ct);
                else if (stage == "write")
                    _ = await faulty.WriteJsonAsync(Owner.Realm, Uuid.CreateVersion4(), "prepare-source.v1", new UnitResult(), ct);
                return Result<FirstResponseDescriptor>.Success(new(202, "application/json", candidate.Schema,
                    new StandardResponseBody(candidate)));
            }
        };
        return new(provider, events, content, winnerBody, loser, losing, () => accepted, transport);
    }

    sealed record PreparationRace(ServiceProvider Provider, InMemoryEventStore Events, IImmutableContentStore Content,
        ImmutableContentRef WinnerBody, NativeOperationExecutor Loser, NativeOperation<AcceptanceProbe> Operation,
        Func<AcceptedAppendResult?> Winner, PreparationTransport Transport);

    sealed class PreparationTransport : INativeOperationTransportObserver
    {
        public int Classifications { get; private set; }
        public AcceptedAppendResult? Observed { get; private set; }
        public RequestError? ClassifyFailure(AcceptedOperationBinding binding, IExecutionContext context,
            ImmutableContentIntegrityException exception)
        {
            Classifications++;
            return new RequestError(RequestErrorKind.Conflict, exception.Message,
                exception is ImmutableContentUnavailableException);
        }
        public void Observe(AcceptedOperationBinding binding, IExecutionContext context, AcceptedAppendResult accepted) =>
            Observed = accepted;
    }

    sealed class PreparationFaultStore(IImmutableContentStore inner, string stage, Exception failure,
        Func<Task> beforeFailure) : IImmutableContentStore
    {
        public async Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema,
            string mediaType, ReadOnlyMemory<byte> bytes, CancellationToken ct = default)
        {
            if (stage == "write" && schema == "prepare-source.v1" || stage == "freeze" && schema == FirstResponses.Schema)
            {
                await beforeFailure();
                throw failure;
            }
            return await inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        }
        public async Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference,
            CancellationToken ct = default)
        {
            if (stage == "read" && reference.Schema == "prepare-source.v1")
            {
                await beforeFailure();
                throw failure;
            }
            return await inner.ReadVerifiedAsync(realm, reference, ct);
        }
    }

''';s=s[:at]+methods+s[at:];f.write_text(s);(r/'old-api-red.cs').write_text(s);patch=''.join(difflib.unified_diff((r/'base'/p).read_text().splitlines(True),s.splitlines(True),fromfile='a/'+p,tofile='b/'+p));(r/'tests-red.patch').write_text(patch);print(hashlib.sha256(patch.encode()).hexdigest())
