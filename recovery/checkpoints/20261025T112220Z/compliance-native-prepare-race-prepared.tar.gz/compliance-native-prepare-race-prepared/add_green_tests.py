from pathlib import Path
r=Path('/tmp/compliance-native-prepare-race-prepared');p=r/'work/test/Compliance.Tests/Features/NativeOperations/NativeOperationExecutorTests.cs';s=p.read_text();at=s.index('    static async Task<PreparationRace> PreparationRaceAsync');s=s[:at]+'''    [Theory]
    [InlineData("read", true)]
    [InlineData("read", false)]
    [InlineData("write", true)]
    [InlineData("write", false)]
    [InlineData("freeze", true)]
    [InlineData("freeze", false)]
    public async Task ShouldPreserveTypedPreparationFailureGivenNoConcurrentWinner(string stage, bool unavailable)
    {
        // Arrange
        ImmutableContentIntegrityException fault = unavailable
            ? new ImmutableContentUnavailableException("The original preparation is not visible yet.")
            : new ImmutableContentIntegrityException("The original preparation cannot be verified.");
        await using var state = await PreparationRaceAsync(stage, fault, commitWinner: false);

        // Act
        var result = await state.Loser.ExecuteAsync(state.Operation, Context(), CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.Equal(unavailable, result.Error!.IsTransient);
        Assert.Same(fault, state.Transport.Classified);
        Assert.Equal(1, state.Transport.Classifications);
        Assert.Null(state.Transport.Observed);
        Assert.Equal(2, state.Reader.Calls);
        Assert.Equal(0, await CountAsync(state.Events));
    }

    [Theory]
    [InlineData("read")]
    [InlineData("write")]
    [InlineData("freeze")]
    public async Task ShouldRethrowOriginalExpectedFailureGivenNoWinnerAndNoTransportClassifier(string stage)
    {
        // Arrange
        var fault = new ImmutableContentIntegrityException("Exact original failure object.");
        await using var state = await PreparationRaceAsync(stage, fault, commitWinner: false, observeFailures: false);

        // Act
        var failure = await Record.ExceptionAsync(() => state.Loser.ExecuteAsync(state.Operation, Context(),
            CancellationToken.None).AsTask());

        // Assert
        Assert.Same(fault, failure);
        Assert.Equal(2, state.Reader.Calls);
        Assert.Equal(0, await CountAsync(state.Events));
    }

    [Theory]
    [InlineData("read")]
    [InlineData("freeze")]
    public async Task ShouldReturnConflictGivenDifferentIntentWinnerAndThrownPreparationFailure(string stage)
    {
        // Arrange
        await using var state = await PreparationRaceAsync(stage,
            new ImmutableContentUnavailableException("Losing preparation."), changedIntent: true);

        // Act
        var result = await state.Loser.ExecuteAsync(state.Operation, Context(), CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.IsType<AcceptedAppendResult.Conflict>(result.Value);
        Assert.Equal(0, state.Transport.Classifications);
        Assert.Null(state.Transport.Observed);
        Assert.Equal(2, state.Reader.Calls);
        Assert.Equal(1, await CountAsync(state.Events));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldPassRequestedCancellationWithoutRecheckGivenExpectedPreparationFailure(bool winner)
    {
        // Arrange
        using var cancellation = new CancellationTokenSource();
        await using var state = await PreparationRaceAsync("read", new ImmutableContentUnavailableException("Losing read."),
            commitWinner: winner, beforeFailure: cancellation.Cancel);

        // Act
        var failure = await Record.ExceptionAsync(() => state.Loser.ExecuteAsync(state.Operation, Context(),
            cancellation.Token).AsTask());

        // Assert
        var canceled = Assert.IsAssignableFrom<OperationCanceledException>(failure);
        Assert.Equal(cancellation.Token, canceled.CancellationToken);
        Assert.Equal(1, state.Reader.Calls);
        Assert.Equal(0, state.Transport.Classifications);
        Assert.Null(state.Transport.Observed);
        Assert.Equal(winner ? 1 : 0, await CountAsync(state.Events));
    }

    [Fact]
    public async Task ShouldPreserveProgrammerFaultWithoutRecheckGivenConcurrentWinnerDuringPreparation()
    {
        // Arrange
        var fault = new InvalidOperationException("A programmer fault is not a source-content failure.");
        await using var state = await PreparationRaceAsync("read", fault);

        // Act
        var failure = await Record.ExceptionAsync(() => state.Loser.ExecuteAsync(state.Operation, Context(),
            CancellationToken.None).AsTask());

        // Assert
        Assert.Same(fault, failure);
        Assert.Equal(1, state.Reader.Calls);
        Assert.Equal(0, state.Transport.Classifications);
        Assert.Null(state.Transport.Observed);
        Assert.Equal(1, await CountAsync(state.Events));
    }

    [Fact]
    public async Task ShouldPreserveUnrequestedCancellationWithoutRecheckGivenConcurrentWinnerDuringPreparation()
    {
        // Arrange
        var fault = new OperationCanceledException("The prepare operation canceled itself.");
        await using var state = await PreparationRaceAsync("write", fault);

        // Act
        var failure = await Record.ExceptionAsync(() => state.Loser.ExecuteAsync(state.Operation, Context(),
            CancellationToken.None).AsTask());

        // Assert
        Assert.Same(fault, failure);
        Assert.Equal(1, state.Reader.Calls);
        Assert.Equal(0, state.Transport.Classifications);
        Assert.Null(state.Transport.Observed);
        Assert.Equal(1, await CountAsync(state.Events));
    }

'''+s[at:];s=s.replace('''        bool commitWinner = true, bool changedIntent = false, Action? beforeFailure = null)''','''        bool commitWinner = true, bool changedIntent = false, Action? beforeFailure = null, bool observeFailures = true)''');s=s.replace('''        var loser = new NativeOperationExecutor(execution.ServiceProvider.GetRequiredService<IAggregateReader>(),
            execution.ServiceProvider.GetRequiredService<IAggregateExecutor>(), faulty, transport);''','''        var observedReader = new PreparationReader(execution.ServiceProvider.GetRequiredService<IAggregateReader>());
        var loser = new NativeOperationExecutor(observedReader,
            execution.ServiceProvider.GetRequiredService<IAggregateExecutor>(), faulty, observeFailures ? transport : null);''');s=s.replace('''return new(provider, events, content, winnerBody, loser, losing, () => accepted, transport, execution);''','''return new(provider, events, content, winnerBody, loser, losing, () => accepted, transport, execution, observedReader);''');s=s.replace('''PreparationTransport Transport, AsyncServiceScope Execution) : IAsyncDisposable''','''PreparationTransport Transport, AsyncServiceScope Execution, PreparationReader Reader) : IAsyncDisposable''');s=s.replace('''        public int Classifications { get; private set; }
        public AcceptedAppendResult? Observed''','''        public int Classifications { get; private set; }
        public ImmutableContentIntegrityException? Classified { get; private set; }
        public AcceptedAppendResult? Observed''');s=s.replace('''            Classifications++;
            return new RequestError''','''            Classifications++;
            Classified = exception;
            return new RequestError''');at=s.index('    sealed class PreparationFaultStore');s=s[:at]+'''    sealed class PreparationReader(IAggregateReader inner) : IAggregateReader
    {
        public int Calls { get; private set; }
        public ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate, CancellationToken ct = default)
            where TAggregate : Aggregate
        {
            Calls++;
            return inner.HydrateAsync(aggregate, ct);
        }
    }

'''+s[at:];p.write_text(s)
print('added absent-winner classification/rethrow, changed intent, requested/unrequested cancellation and programmer fault regressions')
