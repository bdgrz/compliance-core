from pathlib import Path
import hashlib,json,difflib,shutil,subprocess
p=Path('/tmp/compliance-tenant-manager-native-prepared');base=p/'base';work=p/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
src=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')]
def apply(dest,filename):
 result=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/filename)],cwd=dest,capture_output=True,text=True)
 assert result.returncode==0,(filename,result.stdout+result.stderr)
def copy(label):
 dest=p/'verify'/label;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest);return dest
red=copy('red-baseline');apply(red,'behavioral-red.patch')
allred=copy('all-red-baseline');apply(allred,'behavioral-red.patch');apply(allred,'additional-behavioral-red.patch')
arts={}
for name,selected,before in [('implementation.patch',src,base),('tests.patch',tests,base),('green-after-red.patch',paths,red),('green-after-all-red.patch',paths,allred),('full.patch',paths,base)]:
 value=''
 for r in selected:
  b=before/r;f=work/r
  value+=''.join(difflib.unified_diff(b.read_text().splitlines(True) if b.exists() else [],f.read_text().splitlines(True),fromfile='a/'+r if b.exists() else '/dev/null',tofile='b/'+r))
 f=p/name;f.write_text(value);arts[name]={'path':str(f),'sha256':sha(f)}
for name in ['behavioral-red.patch','additional-behavioral-red.patch','QUALIFICATION.md','static-checks.json']:
 arts[name]={'path':str(p/name),'sha256':sha(p/name)}
checks=[]
for label,sequence in [('full',['full.patch']),('split',['tests.patch','implementation.patch']),('staged',['behavioral-red.patch','green-after-red.patch']),('all-staged',['behavioral-red.patch','additional-behavioral-red.patch','green-after-all-red.patch'])]:
 dest=copy(label)
 for patch in sequence:apply(dest,patch)
 assert all(sha(dest/r)==sha(work/r) for r in paths),label
 checks.append({'sequence':sequence,'exact':True})
rows=[{'path':r,'before':sha(base/r),'after':sha(work/r),'currentMainMatchesBase':sha(repo/r)==sha(base/r)} for r in paths]
(p/'owned-paths.txt').write_text('\n'.join(paths)+'\n');(p/'hashes.json').write_text(json.dumps(rows,indent=2)+'\n')
static=json.loads((p/'static-checks.json').read_text())
report={'status':'FROZEN','pathCount':len(rows),'sourceCount':len(src),'testCount':len(tests),'paths':rows,'artifacts':arts,'reconstruction':checks,
'prerequisites':['Merged NativeOperationExecutor expected Prepare/freeze equal-winner recovery','Merged NativeOwnerHistory and FirmIndependenceReplayCut/Digest','Preserve all newer root reader decorators, JSON roots, Evidence and Work deltas when composing'],
'scope':'Compact TenantManagerGuard authority keeps all exact current available identities, all live transitions, and one selected historical episode. Full lifetime contributions/neutral reasons are transient external history, with rolling exact prefix and full selected metadata verification. Bounded affected-episode after-authority facts allow raw replay to reconstruct later restoration of an unselected retired episode without retaining lifetime maps. No count-only invariant or cap.',
'protocol':'Existing five personal/assignment admissions and eight source/guard receivers remain. Admission Bind/Plan/baseline+intent publication/frozen202 are inside native async Prepare. FirstOwner explicitly guard stream throughout root and receiver provenance. Exact historical episode/root passed through loader and four guard readers. Existing source proof/current member/assignment eligibility and last-administrator semantics preserved. Live superseded restoration flags replace lifetime withdrawal tombstones. Atomic restored+completion pair is independently checked.',
'wire':'Preserve selected existing fields. Six existing occupied discriminator tags evolve1→2 for added CurrentAuthority; new DTO is static JSON rooted. Original frozen AdministratorTransitionResponse202 unchanged. No public route contract or lookup added. Persisted v1 history not migration-qualified; no silent alias/fallback.',
'baseline':'Pinned baseline contains concrete member/episode/assignment/generation/denial identities and is validated structurally; source bootstrap semantics unchanged. Constructor candidate seed is consumed and cleared by installed reader, which rehydrates from actual winning pinned baseline after any concurrent first append. Complete baseline remains transient in LoadedGuard, not command-authority lifetime state.',
'shared':'Production PersistenceServiceCollectionExtensions adds TenantManagerGuardAggregateReader(inner,events,content,clock). Core JSON adds TenantManagerEpisodeAuthority. AdministratorTransitionHost adds broker-free finalizer and optional content decorator. Preserve root current Work/SourceUse/Evidence/Identity/etc reader wrappers via union rather than replacing shared files.',
'validation':{'staticSyntaxFiles':static['syntax']['files'],'effectiveConstructorSites':len(static['constructors']),'preservedAcceptanceNames':len(static['preservedAcceptanceNames']),'assertCountsPreserved':True,'reconstruction':checks,'runtime':'No local .NET/build/test/broker/Jev/Git/main mutation. Root executes runtime and final review.'},
'oldApiRed':{'primary':{'patch':str(p/'behavioral-red.patch'),'filter':str(p/'behavioral-red-filter.txt'),'cases':2,'evidence':'Qualified centrally against5887: retired contribution/withdrawal and neutral history retained. Archive recovery/work-guard-qualified-red.'},'additional':{'patch':str(p/'additional-behavioral-red.patch'),'filter':str(p/'additional-behavioral-red-filter.txt'),'cases':1,'evidence':'Qualified centrally: actual equal Suspend winning frozen202 before losing intent write Unavailable. Archive recovery/preference-guard-prepare-qualified-red.'}},
'newNativeCases':['Exact unselected middle payload substitution fails closed','Exact middle EventId substitution fails closed','Truncated captured prefix is unavailable','Full history retains neutral/retired episode reasons while default compact authority omits it','Actual first winner pinned newer baseline supersedes caller earlier empty-stream seed'],
'qualification':'See QUALIFICATION.md. Full required proof guards remain before receivers where terms are not natively bound. No broad claim all preexisting receiver immutable-preflight recovery is migrated. No new source permit/current-through-append claim, global registry, migration authority, or callback. No issues created.',
'filters':['FullyQualifiedName~TenantManager|FullyQualifiedName~AdministratorTransition|FullyQualifiedName~MemberTransitionTransport|FullyQualifiedName~MemberRetirement|FullyQualifiedName~TeamMember'],
'next':'Await root allocation after this bounded guard handoff; root owns Schedule/finite follow-ups.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'source':len(src),'tests':len(tests),'artifacts':arts,'reconstruction':checks,'handoffSha256':sha(p/'handoff.json')},indent=2))
