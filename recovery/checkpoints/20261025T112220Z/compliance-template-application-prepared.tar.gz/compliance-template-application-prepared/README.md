# TemplateApplication native history preparation

Main untouched; no .NET, Git or GitHub writes. Runtime/HTTP/RED→GREEN proof belongs to parent integration.

1. Apply `tests.patch` alone to current baseline and run the two added TemplateApplicationTests. Both require successful existing behavior beyond the old 48 KiB snapshot/lifetime boundaries; no new API or reflection is involved.
2. Apply `implementation.patch`, `migrated-tests.patch`, and the three shared patches symbolically against current Program/JSON/DI. Compile and run all MethodologyTemplates focused tests then the full backend gate.
3. All 16 copied existing acceptance names remain. Existing RecordDraftCreated receipt tests now exercise the transient pure rules and exact immutable delta fold; that callback never had a runtime caller. Native tests execute the actual NativeOperationExecutor, immutable content store and source-cut reader. Existing handler tests continue through actual program/template/application command handlers.

Native owner retains only scalar TemplateApplicationHeader + selected NativeAcceptance. Full source content appears only in initial immutable application content; later delta bodies carry exactly one proposal or decision. They never repeat application/successor histories. Reader composes complete history from captured native owner revision, validates every exact transition/header/body, and returns unavailable versus corrupt content through typed query/command outcomes. No list DTO exists; no unbounded event scan is used for discovery. Fully scoped Get requires no directory.

The three command discriminators retain spelling; event versions advance Applied2→3, Propose2→3, Disposition2→3. Original TemplateApplicationDraftCreated v1 decoder stays unchanged and has no new writer. See blockers.json for unselected callback/child protocol, preview semantics and retained-store migration boundaries. No generic command receipt dictionary, owner.Current history shim or compatibility read fallback exists.

Plain IRequest/Result shapes remain per existing contract. Native descriptor/result freeze is HTTP200 Unit; parent global first-response transport bridge qualifies actual HTTP behavior.
