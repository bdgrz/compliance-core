Preparation contract shared with the scoped-read agent. Not frozen or eligible for integration until complete.

AuditorRequestReader(IAggregateReader, IDomainEventReader, IImmutableContentStore)
- ValueTask<AuditorRequestReadSnapshot> ReadAsync(Uuid tenant, Uuid program, Uuid request, CancellationToken ct = default)
- ValueTask<IReadOnlyList<AuditorRequestResponseView>> ReadResponseViewsAsync(Uuid tenant, Uuid program, Uuid request, CancellationToken ct = default)
- ValueTask<SampleSelectionView?> ReadSelectionAsync(Uuid tenant, Uuid program, Uuid request, Uuid selection, CancellationToken ct = default)

ReadSnapshot: Owner (compact AuditorRequest), History (explicit verified AuditorRequestHistorySnapshot), View (full existing AuditorRequestView?; null absent/wrong verified immutable terms.ProgramId).
HistorySnapshot: Facts, Responses, Comments, Selections, ResolutionHistory; exact metadata cut and original facts, not command authority.
ReadResponseViewsAsync includes current version only when it actually has SubmittedAt. ArtifactId is present iff exactly one artifact belongs to that selected submitted version; full versions/plural evidence stay in Get.
ReadSelectionAsync verifies frozen original sample intent/population version/rows/digests/scopes; null absent/unmaterialized native child. Existing admission locator plus null means transient pending.
Expected content/native proof failures use ImmutableContentUnavailableException (transient) versus ImmutableContentIntegrityException (permanent). Ordinary current reads use no receipt network calls. No broad external auditor/Attest disclosure authority added.

Agent scoped-read ownership: new handlers, created-only identity + scoped sample locator + before/after source checkpoint consistency, shared App/DI/JSON deltas, their focused/API-host tests. Preserve same selection UUID ambiguity across requests.
Parent owner agent: all existing owning parent/response materialization/history/resolution/producers, reader/snapshot implementation, owning fixtures; no client repo or new public identity fields.

Agreed with parent: own all new identity/locator/projection/checkpoint/paging/read-handler paths and explicit App/DI/JSON deltas, plus new focused/HTTP fixtures. Parent retains all existing feature owner/reader/fixtures. No public DTO fields change.
