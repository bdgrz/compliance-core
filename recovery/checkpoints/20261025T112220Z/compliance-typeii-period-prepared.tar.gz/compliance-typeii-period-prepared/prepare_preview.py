from pathlib import Path
import shutil
r=Path('/tmp/compliance-typeii-period-prepared');w=r/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');op=w/'src/Compliance.Core/Features/Operations'
rel=Path('src/Compliance.Common/Features/AuditPopulations/ObservationPeriodClosePreview.cs')
for d in ['base','work']:
 p=r/d/rel
 if not p.exists():shutil.copy2(repo/rel,p)
(w/rel).write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPopulations;

/// <summary>Current complete-close readiness at one verified period and source receipt cut; this report is not an admission.</summary>
public sealed record ObservationPeriodClosePreview(Uuid TenantId, Uuid ProgramId, Uuid ObservationPeriodId,
    long Revision, bool Ready, int ExpectedOccurrenceCount, int ActualOccurrenceCount,
    IReadOnlyList<Uuid> MissingWorkIds, IReadOnlyList<Uuid> DuplicateOccurrenceIds,
    IReadOnlyList<Uuid> UnresolvedMaterialItemIds, IReadOnlyList<string> Blockers,
    IReadOnlyList<string> SourceDifferences, DateTimeOffset CalculatedAt);
''')
(op/'PreviewObservationPeriodCloseHandler.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Source-backed read-only close readiness; publishing immutable candidate bytes never admits or changes the period.</summary>
public sealed class PreviewObservationPeriodCloseHandler(IAggregateReader reader, TypeIIPeriodReader periods,
    ITypeIIPeriodCloseReconciliation sources, TimeProvider clock)
    : IRequestHandler<PreviewObservationPeriodClose, ObservationPeriodClosePreview>
{
    public async ValueTask<Result<ObservationPeriodClosePreview>> HandleAsync(IRequestContext<PreviewObservationPeriodClose> context, CancellationToken ct)
    {
        var request = context.Request;
        if (RequestActor.IsSystem(context.Actor) || !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var user))
            return Result<ObservationPeriodClosePreview>.Failure(new RequestError(RequestErrorKind.Forbidden, "A close preview requires a current personal program reader."));
        var read = await periods.TryReadAsync(request.TenantId, request.ProgramId, request.ObservationPeriodId, ct).ConfigureAwait(false);
        if (!read.IsSuccess)
            return Result<ObservationPeriodClosePreview>.Failure(read.Error!);
        var period = read.Value;
        if (period.View is not { } state)
            return Result<ObservationPeriodClosePreview>.Failure(new RequestError(RequestErrorKind.NotFound, "The observation period has not opened in this program."));
        var at = clock.GetUtcNow();
        var operation = RootOperation.Provenance(Uuid.CreateVersion4(), nameof(PreviewObservationPeriodClose), period.Stream,
            ActorReference.ForMember(RbacIds.Member(request.TenantId, user), UserIdentityClaims.BdgrzDisplay(context.Actor, user)),
            period.Revision, AuthoredIntentDigest.Compute(request), at);
        try
        {
            var source = await sources.ReadAsync(period, context.Actor, user, operation, ct).ConfigureAwait(false);
            if (!source.IsSuccess)
                return Result<ObservationPeriodClosePreview>.Failure(source.Error!);
            var current = await reader.HydrateAsync(new TypeIIPeriod(request.TenantId, request.ProgramId, request.ObservationPeriodId), ct).ConfigureAwait(false);
            if (current.NativeSequence != period.Owner.NativeSequence || current.CommittedStreamPosition != period.Owner.CommittedStreamPosition)
                return Conflict("The period changed during its close preview. Retry the query.", true);
            var value = source.Value;
            if (value.RecordedThrough != at)
                return Conflict("The close preview source differs from its exact server receipt cut.");
            var blockers = value.SourceBlockers.ToList();
            if (DateOnly.FromDateTime(at.UtcDateTime) <= state.PeriodEnd)
                blockers.Add("The complete observation interval has not ended.");
            var ready = blockers.Count == 0 && value.MissingWorkIds.Count == 0 && value.DuplicateOccurrenceIds.Count == 0 &&
                value.ExpectedOccurrenceIds.OrderBy(id => id.ToString(), StringComparer.Ordinal)
                    .SequenceEqual(value.ActualOccurrenceIds.OrderBy(id => id.ToString(), StringComparer.Ordinal));
            return Result<ObservationPeriodClosePreview>.Success(new ObservationPeriodClosePreview(request.TenantId, request.ProgramId,
                request.ObservationPeriodId, period.Revision, ready, value.ExpectedOccurrenceIds.Count, value.ActualOccurrenceIds.Count,
                value.MissingWorkIds, value.DuplicateOccurrenceIds, value.UnresolvedMaterialItemIds, blockers, value.SourceDifferences, at));
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Conflict("The exact close preview source content cannot be verified.", exception is ImmutableContentUnavailableException);
        }
    }
    static Result<ObservationPeriodClosePreview> Conflict(string message, bool transient = false) =>
        Result<ObservationPeriodClosePreview>.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
p=r/'prepare_shared.py';s=p.read_text();s=s.replace('            .AddRequestHandler<GetObservationPeriodCloseHandler>()', '            .AddRequestHandler<GetObservationPeriodCloseHandler>()\n            .AddRequestHandler<PreviewObservationPeriodCloseHandler>()')
s=s.replace('''    app.MapPortiaGet<GetObservationPeriodClose, ObservationPeriodCloseView>(''','''    app.MapPortiaGet<PreviewObservationPeriodClose, ObservationPeriodClosePreview>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/close-preview", endpoint => endpoint
                .OnBind(Program.BindObservationPeriodClosePreview)
                .Parameter<Uuid>("tenant_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("program_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("period_id", PortiaHttpParameterLocation.Route, required: true))
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Observation periods");
    app.MapPortiaGet<GetObservationPeriodClose, ObservationPeriodCloseView>(''')
s=s.replace('''    internal static GetObservationPeriodClose BindObservationPeriodCloseRead''','''    internal static PreviewObservationPeriodClose BindObservationPeriodClosePreview(HttpContext context) => new(
        ApplicationRouteId(context, "tenant_id"), ApplicationRouteId(context, "program_id"), ApplicationRouteId(context, "period_id"));

    internal static GetObservationPeriodClose BindObservationPeriodCloseRead''')
s=s.replace("'GetObservationPeriodCloseHandler']", "'GetObservationPeriodCloseHandler','PreviewObservationPeriodCloseHandler']")
s=s.replace("'binders':['BindObservationPeriodRead','BindObservationPeriodCloseRead']", "'binders':['BindObservationPeriodRead','BindObservationPeriodCloseRead','BindObservationPeriodClosePreview']")
p.write_text(s)
print('Existing scoped close preview now returns honest source-backed readiness without owner admission')
