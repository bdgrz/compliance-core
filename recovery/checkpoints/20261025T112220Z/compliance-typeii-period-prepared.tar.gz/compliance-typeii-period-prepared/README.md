# Native Type II period owner, producers and scoped reads

Prepared offline after merged stage 1 #1103 (`0c5a45c1fa7639bc253245b0464302ec0b48cd82`). No main, git index, branch, worktree, build, test, broker or GitHub mutation was performed by this child.

Apply order: run/reverse `behavioral-red.patch` against the old owner, optionally run/reverse `read-http-red.patch`, then apply `tests.patch`, `implementation.patch`, and the coordinated `shared.patch`. Tests reference the new native APIs, so the full tests-only patch is not the old-code RED. Parent owns all runtime evidence and direct per-file Jev review.

## Artifacts

- `behavioral-red.patch`: old public owner/helper regression `FullyQualifiedName~TypeIIPeriodTests.ShouldOpenCompleteSourcePopulationGivenImmutableBodyExceedsEventBudget`. A valid 1,000-source opening is stored in immutable intent but the old apply re-embeds its entire State and exceeds the event budget. The migrated acceptance preserves its name and verifies actual compact native persistence and complete readback.
- `read-http-red.patch`: independent old-API production host regression `FullyQualifiedName~ObservationPeriodReadHttpTests.ShouldUseCanonicalPeriodRouteGivenMisleadingQueryIdentities`. No new native types/directory APIs appear in this standalone fixture; the old host has no scoped GET and returns 404.
- `implementation.patch`: 76 owning source paths.
- `tests.patch`: 26 test paths, 34 new acceptance methods; no original acceptance name removed.
- `shared.patch`: exact Program/DI/JSON changes, stored separately to preserve concurrent Policy/Template registrations.
- `shared-wiring-deltas.json`: explicit registrations, JSON roots, typed Unit transport and scoped routes.
- `manifest.json`: every base/after SHA, artifact SHAs, static checks and exact patch reconstruction evidence.
- `base/` and `work/`: complete relevant offline files. `before-main-refresh-*` retains the previous offline snapshot. `refresh-report.json` documents incorporation of Control seams and parent stage 1 fixes.

## Resulting owner and protocol

`TypeIIPeriod` retains scalar authority, one verified current body reference, native sequence, one pending admission, exact live calendar permit/intent, and at most the selected historical root/source proofs. It retains no full view, populations, source arrays or history collections. `TypeIIPeriodRules` is a transient non-Aggregate read/rule composition; its state mutations are plain records, not durable DomainEvents. `TypeIIPeriodReader` reconstructs the exact native source cut, verifies each immutable body/action, and checks the complete result against the compact authority.

Started/amended/generated/close facts are compact native envelopes. Required selected business fields, actor attribution and `MutationResultContent` envelopes are retained. Selected final started/amended/generated/frozen discriminator versions are 1; retained close-validation/approval/amendment facts advance their prior schemas. Header/current-content/native-sequence are additive. Range admissions/fences add an explicit ProgramId so a headerless pending opening cannot acquire another program's authority. Close frozen adds its exact calendar intent reference; release no longer guesses from a later owner/history read. Prerelease old full-State histories have no shipped dual read/write path.

Opening/amendment source preparation is inside asynchronous native Prepare. All immediate Unit producers (validation, approval, freeze, close amendment, generation and cancellation) preserve the original typed 200 `{}` response, result envelope, actor, expected revision, authored digest and decision time. Missing immutable preparation bytes return transient failure inside Prepare so an equal concurrent winner is rechecked; corruption remains permanent. Native body appends recheck both logical/native and exact physical preparation cuts. Cancellation fences delayed apply before settlement and now also freezes its original Unit envelope. Existing executive authority is resolved before replay; all write paths retain personal HTTP checks.

Close amendment requires complete current source-family publication, exact expected/actual work, preserved original acknowledged exceptions/population, exact changed source-record sets and sealed affected material proof. Material discovery scans complete authoritative scoped source cuts, including verified native package manifest versions, populations/exports, exact sample population versions and admitted request children, management source bindings, system-description period/version scope and rollover lineage. Same-scope unchanged/current records are never fabricated from a directory absence. The superseded close, actual packages/manifests and discovered dependent material are included. The proof is bound to the exact root, owner, period, receipt cutoff and new physical publication.

All existing direct production consumers now use compact headers where sufficient, or verified explicit period read composition. Test fixture publication uses real immutable bodies/compact native facts. Parent's clock/original-revision replay fix, sidecar digest reconstruction, exact multi-version reference uniqueness/grouped ChangedRecordIds, source RecordedThrough/effective cutoff and current ControlReader seams are preserved.

## Scoped reads

Existing request identities remain unchanged. Existing placeholder response DTOs now expose honest lifecycle/date/plan/close fields. Get reads complete current scalar owner authority after opening applies; pending range amendments retain current dates and expose their pending identity. A not-yet-applied opening has no public opened-period view. No severity/description/evidence placeholders are invented.

The identity-only native opening directory preserves original opening order. List queries compose bounded pages from current compact owners, validate tenant/program scope, and fence the complete period source checkpoint before and after composition. Cursor isolation follows KvDirectory.

Close Get uses a read-only tenant/program/closeId index. Compound rows retain every owning period. A two-row bounded query detects ambiguity and returns Conflict; it never picks a first matching owner or claims atomic global mutation binding. A unique row is verified against its exact native fact, period revision, snapshot version/digest and immutable historical lineage, with checkpoint fencing. This is scoped read discovery, not a new public PeriodId input.

The existing scoped close Preview uses the production reconciliation port, preserves current program/read/restricted-source authorization, verifies the unchanged period source cut, and returns a structured completeness/exception report. It does not append or admit a close; incidental immutable candidate publication is the existing source-preview behavior.

New unblocked routes: scoped period Get/List/close Preview, scoped close Get, native close amendment, and GenerationKey-addressed occurrence generation. Existing approval/freeze/cancellation transport maps are explicitly typed Unit. No new MCP write mapping or client repository code is included.

## Validation boundary

Tree-sitter parses all prepared implementation/test/shared C# files without syntax errors. A static explicit-constructor arity pass reports no signals. Original acceptance-name inventory reports zero removals. `patch` in a plain temporary directory reconstructs every exact implementation/test after SHA; no git index is used. Main baselines matched when exported. Runtime/analyzer/formatter/HTTP qualification and per-file Jev are intentionally pending the parent's serialized integration slot. Do not claim this family merged or runtime green from these static artifacts.
