from pathlib import Path
import re
root=Path('/tmp/compliance-typeii-period-prepared'); w=root/'work'
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriod.cs'
s=p.read_text()
# Historical full views become transient read/rule mutations, never a command aggregate or persisted event.
names=['ObservationPeriodStarted','ObservationPeriodAmended','ObservationPeriodCloseProposed','TypeIIPeriodCloseApproved','ObservationPeriodCloseFrozen','TypeIIPeriodCloseAmended']
for name in names: s=re.sub(r'\b'+name+r'\b',name+'Body',s)
s=re.sub(r'\bTypeIIPeriod\b','TypeIIPeriodRules',s)
s=s.replace('public sealed class TypeIIPeriodRules : Aggregate','public sealed class TypeIIPeriodRules')
s=s.replace('        : base(periodId, new EventStreamAddress(tenantId.ToString(), Area, periodId.ToString()))\n','')
s=s.replace('        _tenantId = tenantId;','        Id = periodId;\n        Stream = new EventStreamAddress(tenantId.ToString(), Area, periodId.ToString());\n        _tenantId = tenantId;',1)
s=s.replace('    const int MaximumEventBytes = DomainEventPayload.MaximumBytes;\n','')
s=re.sub(r'        if \(DomainEventPayload.Size\((started|amended)\) > MaximumEventBytes\)\n            return Result.Failure\(Invalid\("The complete Type II period state exceeds the bounded event payload\."\)\n                \.ToRequestError\(\)\);\n','',s)
s=re.sub(r'        if \(DomainEventPayload.Size\(ev\) > MaximumEventBytes\)\n            return Invalid\("The complete Type II period state exceeds the bounded event payload\."\);\n','',s)
idx=s.index('    readonly Uuid _tenantId;')
s=s[:idx]+'''    readonly Dictionary<Type, Action<DomainEvent>> _reducers = [];
    readonly List<DomainEvent> _pendingChanges = [];
    public Uuid Id { get; }
    public EventStreamAddress Stream { get; }
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;
    public IReadOnlyList<DomainEvent> PendingChanges => _pendingChanges.AsReadOnly();
    public void ClearPendingChanges() => _pendingChanges.Clear();
    void On<T>(Action<T> reducer) where T : DomainEvent =>
        _reducers.Add(typeof(T), change => reducer((T)change));
    public void Apply(DomainEvent change)
    {
        if (!_reducers.TryGetValue(change.GetType(), out var reducer))
            throw new InvalidOperationException("The Type II period read mutation has another kind.");
        reducer(change);
    }
    void RaiseEvent(DomainEvent change)
    {
        Apply(change);
        _pendingChanges.Add(change);
    }

'''+s[idx:]
# Internal validation permits compact append to recheck the exact transient prepared state.
s=s.replace('    CommandFailure? ValidateState(', '    internal CommandFailure? ValidateState(')
s=s.replace('    static bool ValidTransition(', '    internal static bool ValidTransition(')
s=s.replace('    static bool ValidOpeningState(', '    internal static bool ValidOpeningState(')
s=s.replace('/// Owns one Type II observation period from its approved-plan opening through close and any','/// Pure transient rules and read reconstruction for a Type II period through close and any')
(w/'src/Compliance.Core/Features/Operations/TypeIIPeriodRules.cs').write_text(s)
# Preserve the exact old mutation fields privately to this implementation, outside the durable event catalog.
for name in names:
    matches=list((root/'base/src/Compliance.Common').rglob(name+'.cs'))
    assert len(matches)==1,(name,matches)
    body=matches[0].read_text()
    body=re.sub(r'\[Discriminator\([^\n]+\)\]\n','',body)
    body=body.replace('namespace Bdgrz.Compliance.Features.AuditPopulations;','namespace Bdgrz.Compliance.Features.Operations;')
    body=re.sub(r'\b'+name+r'\b',name+'Body',body)
    body=re.sub(r'/// <summary>[\s\S]*?/// </summary>\n','/// <summary>Transient verified period rule mutation; never emitted or retained by the command owner.</summary>\n',body,count=1)
    (w/'src/Compliance.Core/Features/Operations'/ (name+'Body.cs')).write_text(body)
print('Transient rules + six body mutations prepared')
