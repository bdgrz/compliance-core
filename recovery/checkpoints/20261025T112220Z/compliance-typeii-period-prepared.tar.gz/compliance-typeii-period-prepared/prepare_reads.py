from pathlib import Path
import shutil
r=Path('/tmp/compliance-typeii-period-prepared');w=r/'work';op=w/'src/Compliance.Core/Features/Operations';common=w/'src/Compliance.Common/Features/Operations';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
for name in ['GetObservationPeriod','ListObservationPeriods','ObservationPeriodView','ObservationPeriodSummaryView']:
 rel=Path(f'src/Compliance.Common/Features/Operations/{name}.cs')
 for d in ['base','work']:
  p=r/d/rel
  if not p.exists():shutil.copy2(repo/rel,p)
(common/'ObservationPeriodView.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Current period lifecycle authority and its exact approved-plan, date and close bindings.</summary>
public sealed record ObservationPeriodView(Uuid TenantId, Uuid ProgramId, Uuid ObservationPeriodId,
    Uuid ExaminationId, Uuid TypeIIPlanId, int TypeIIPlanVersion, string Status, long Revision,
    DateOnly PeriodStart, DateOnly PeriodEnd, int ExpectedOccurrenceCount, Uuid? PendingAmendmentId,
    string? CloseValidationStatus, Uuid? LatestCloseSnapshotId, int? LatestCloseSnapshotVersion,
    DateTimeOffset UpdatedAt);
''')
(common/'ObservationPeriodSummaryView.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Current scoped period status and dates; discovery ordering is held separately by immutable opening identity.</summary>
public sealed record ObservationPeriodSummaryView(Uuid TenantId, Uuid ProgramId, Uuid ObservationPeriodId,
    Uuid ExaminationId, string Status, long Revision, DateOnly PeriodStart, DateOnly PeriodEnd, DateTimeOffset UpdatedAt);
''')
(common/'ObservationPeriodIdentity.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Immutable discovery identity of a period after its opening is applied; this row is not current lifecycle state.</summary>
public sealed record ObservationPeriodIdentity(Uuid TenantId, Uuid ProgramId, Uuid ObservationPeriodId, DateTimeOffset OpenedAt);
''')
# Reuse the established identity-only directory/checkpoint pattern, with no status placeholders in public results.
source=Path('/tmp/compliance-s29-read-prepared/work/src/Compliance.Core/Features/AuditPackages')
for name in ['AuditPackageDirectorySchema','AuditPackageDirectoryReadConsistency','AuditPackageDirectoryProjector','FitzAuditPackageDirectory','IAuditPackageDirectoryProjection','IAuditPackageDirectoryReader']:
 s=(source/(name+'.cs')).read_text()
 s=s.replace('Bdgrz.Compliance.Features.AuditPackages','Bdgrz.Compliance.Features.Operations')
 s=s.replace('AuditPackageDirectory','ObservationPeriodDirectory').replace('FitzAuditPackageDirectory','FitzObservationPeriodDirectory')
 s=s.replace('AuditPackageManifest.Area','TypeIIPeriod.Area').replace('new AuditPackageManifest(fact.TenantId, fact.SubjectId)','new TypeIIPeriod(fact.TenantId, fact.Header.ProgramId, fact.SubjectId)')
 s=s.replace('AuditPackageCreated','ObservationPeriodStarted').replace('AuditPackageSummaryView','ObservationPeriodIdentity')
 s=s.replace('AuditPackageId','ObservationPeriodId').replace('AuditPackageIdentityDirectory','ObservationPeriodIdentityDirectory')
 s=s.replace('audit-package-identity-directory','observation-period-identity-directory').replace('audit-package','observation-period').replace('audit package','observation period')
 s=s.replace('UpdatedAt','OpenedAt').replace('ByProgramCreated','ByProgramOpened').replace('by_program_created','by_program_opened')
 s=s.replace('Packages','Periods').replace('"packages"','"periods"')
 s=s.replace('fact.ProgramId','fact.Header.ProgramId')
 s=s.replace('fact.PackageVersion != 1 || ', '')
 s=s.replace('fact.Operation.LogicalId != fact.SubjectId', 'fact.Operation.RootOperationId != fact.SubjectId || fact.CalendarAuthorizationId != fact.SubjectId ||\n            fact.Header.TenantId != fact.TenantId || fact.Header.PeriodId != fact.SubjectId || fact.Header.Revision != 1')
 s=s.replace('string.Empty, "created_identity", fact.OccurredAt','fact.OccurredAt')
 s=s.replace('The package', 'The period').replace('A package', 'A period').replace('package identity','period identity')
 (op/(name.replace('AuditPackage','ObservationPeriod')+'.cs')).write_text(s)
(op/'ObservationPeriodRead.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Reads complete scalar command authority; immutable body availability does not erase an accepted lifecycle decision.</summary>
static class ObservationPeriodRead
{
    public static async ValueTask<Result<ObservationPeriodView>> GetAsync(IAggregateReader reader, Uuid tenantId,
        Uuid programId, Uuid periodId, CancellationToken ct)
    {
        var owner = await reader.HydrateAsync(new TypeIIPeriod(tenantId, programId, periodId), ct).ConfigureAwait(false);
        return owner.Header is { } header && header.TenantId == tenantId && header.ProgramId == programId && header.PeriodId == periodId
            ? Result<ObservationPeriodView>.Success(new ObservationPeriodView(tenantId, programId, periodId, header.ExaminationId,
                header.TypeIIPlanId, header.TypeIIPlanVersion, header.Status, header.Revision, header.PeriodStart, header.PeriodEnd,
                header.ExpectedOccurrenceCount, owner.Pending is TypeIIPeriodAmendmentAccepted ? owner.PendingOperationId : null,
                header.ValidationStatus, header.LatestCloseSnapshotId, header.LatestCloseVersion, header.UpdatedAt))
            : Result<ObservationPeriodView>.Failure(new RequestError(RequestErrorKind.NotFound,
                "The observation period has not opened in this program."));
    }
}
''')
(op/'GetObservationPeriodHandler.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Returns current scoped period authority after its native opening has applied.</summary>
public sealed class GetObservationPeriodHandler(IAggregateReader reader)
    : IRequestHandler<GetObservationPeriod, ObservationPeriodView>
{
    public ValueTask<Result<ObservationPeriodView>> HandleAsync(IRequestContext<GetObservationPeriod> context, CancellationToken ct)
    {
        var request = context.Request;
        return ObservationPeriodRead.GetAsync(reader, request.TenantId, request.ProgramId, request.ObservationPeriodId, ct);
    }
}
''')
s=(source/'ListAuditPackagesHandler.cs').read_text().replace('Bdgrz.Compliance.Features.AuditPackages','Bdgrz.Compliance.Features.Operations')
s=s.replace('ListAuditPackages','ListObservationPeriods').replace('AuditPackageSummaryView','ObservationPeriodSummaryView').replace('IAuditPackageDirectoryReader','IObservationPeriodDirectoryReader').replace('AuditPackageDirectoryReadConsistency','ObservationPeriodDirectoryReadConsistency')
s=s.replace('AuditPackageReader packages','IAggregateReader reader').replace('Page<ObservationPeriodSummaryView> identities','Page<ObservationPeriodIdentity> identities')
s=s.replace('AuditPackageRead.GetAsync(packages','ObservationPeriodRead.GetAsync(reader').replace('identity.AuditPackageId','identity.ObservationPeriodId')
s=s.replace('''            current.Add(new ObservationPeriodSummaryView(view.TenantId, view.ProgramId, view.AuditPackageId,
                view.Name, view.Status, view.UpdatedAt));''','''            current.Add(new ObservationPeriodSummaryView(view.TenantId, view.ProgramId, view.ObservationPeriodId,
                view.ExaminationId, view.Status, view.Revision, view.PeriodStart, view.PeriodEnd, view.UpdatedAt));''')
s=s.replace('audit-package','observation-period').replace('audit package','observation period')
(op/'ListObservationPeriodsHandler.cs').write_text(s)
print('Scoped period Get/List and identity-only directory/current-authority composition prepared')
