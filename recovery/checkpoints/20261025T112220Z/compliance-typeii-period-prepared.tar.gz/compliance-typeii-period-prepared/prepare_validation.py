from pathlib import Path
w=Path('/tmp/compliance-typeii-period-prepared/work');op=w/'src/Compliance.Core/Features/Operations'
p=w/'src/Compliance.Common/Features/Operations/RecordTypeIIPeriodCloseValidation.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s;s=s.replace(': IRequest,',': IRequest<UnitResult>,');p.write_text(s)
p=op/'RecordTypeIIPeriodCloseValidationHandler.cs';old=p.read_text()
a=old.index('                        var proof = await SnapshotSourcePublicationReader');b=old.index('                        var frozen = await NativeContent.FreezeUnitAsync',a)
validation=old[a:b]
validation=validation.replace('period.PrepareCloseValidation','snapshot.Rules.PrepareCloseValidation').replace('owner.Stream','snapshot.Owner.Stream')
validation=validation.replace('request.TenantId, request.ProgramId,','request.TenantId, request.ProgramId,')
validation=validation.replace('return Result<FirstResponseDescriptor>.Failure(', 'return Result.Failure(')
s='''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Snapshots;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Native identified close reconciliation at a verified immutable period cut; exact retries keep their original Unit body.</summary>
public sealed class RecordTypeIIPeriodCloseValidationHandler(TypeIIPeriodOperations operations,
    ITypeIIPeriodCloseReconciliation sources, IImmutableContentStore content)
    : IRequestHandler<RecordTypeIIPeriodCloseValidation, UnitResult>
{
    public async ValueTask<Result<UnitResult>> HandleAsync(IRequestContext<RecordTypeIIPeriodCloseValidation> context, CancellationToken ct)
    {
        var request = context.Request;
        if (!ExaminationCommandActor.TryGet(context.Actor, context.Invocation, request.TenantId, out var member, out var display) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var user))
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Forbidden, "Recording a period close requires a personal HTTP actor."));
        return await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PeriodId, request.CommandId,
            nameof(RecordTypeIIPeriodCloseValidation), request.ExpectedRevision, async (snapshot, operation, token) =>
            {
                var current = snapshot.View!;
                if (current.Status is not ("active" or "close_blocked" or "close_ready") ||
                    DateOnly.FromDateTime(operation.AcceptedAt.UtcDateTime) <= current.PeriodEnd)
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The complete observation interval must end before its eligible close can be reconciled."));
                var read = await sources.ReadAsync(snapshot, context.Actor, user, operation, token).ConfigureAwait(false);
                if (!read.IsSuccess)
                    return Result.Failure(read.Error!);
                var reconciliation = read.Value;
                if (reconciliation.RecordedThrough != operation.AcceptedAt || reconciliation.SourceContentManifest is null)
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The exact close receipt cutoff and published source proof are required."));
                ImmutableContentRef? change;
'''+validation+'''                return TypeIIPeriodOperations.Outcome(snapshot.Rules.RecordCloseValidation(operation, reconciliation, change!, null, null));
            }, ct).ConfigureAwait(false);
    }
}
'''
p.write_text(s)
p=op/'TypeIIPeriod.cs';s=p.read_text().replace('public Uuid ProgramId => _programId;', 'public Uuid ProgramId => Header?.ProgramId ?? _programId;')
s=s.replace('after.TenantId != _tenantId || after.ProgramId != _programId || after.PeriodId != Id ||','after.TenantId != _tenantId || after.ProgramId == Uuid.Empty || after.PeriodId != Id ||')
s=s.replace('after.ExaminationId != prior.ExaminationId ||','after.ProgramId != prior.ProgramId || after.ExaminationId != prior.ExaminationId ||')
p.write_text(s)
p=op/'TypeIIPeriodOperations.cs';s=p.read_text().replace('if (owner.Header is null)','if (owner.Header is null || owner.ProgramId != programId)');p.write_text(s)
p=op/'TypeIIPeriodReader.cs';s=p.read_text().replace('        return await ReadAsync(owner, ct).ConfigureAwait(false);','''        return owner.ProgramId == programId ? await ReadAsync(owner, ct).ConfigureAwait(false) :
            new TypeIIPeriodReadSnapshot(owner, new TypeIIPeriodRules(tenantId, programId, periodId), []);''',1);p.write_text(s)
print('Native typed close-validation producer and scope-safe immutable reads prepared')
