from pathlib import Path
import difflib,hashlib,json,re,datetime
r=Path('/tmp/compliance-typeii-period-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
shared={'src/Compliance.App/Program.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs'}
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[];implementation='';tests='';acceptance_removed=[];acceptance_added=[]
for p in sorted((r/'work').rglob('*')):
 if not p.is_file() or p.suffix!='.cs':continue
 rel=str(p.relative_to(r/'work'))
 if rel in shared:continue
 base=r/'base'/rel;old=base.read_bytes() if base.exists() else b'';new=p.read_bytes()
 if old==new:continue
 patch=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel if base.exists() else '/dev/null',tofile='b/'+rel))
 if rel.startswith('test/'):tests+=patch
 else:implementation+=patch
 main=repo/rel
 files.append({'path':rel,'kind':'test' if rel.startswith('test/') else 'source','base_sha256':sha(old) if base.exists() else None,'after_sha256':sha(new),'bytes':len(new),'main_matches_base':main.read_bytes()==old if main.exists() else not base.exists()})
 if rel.startswith('test/'):
  before=set(re.findall(r'\b(Should\w+)\s*\(',old.decode()));after=set(re.findall(r'\b(Should\w+)\s*\(',new.decode()))
  acceptance_removed += [{'path':rel,'name':name} for name in sorted(before-after)]
  acceptance_added += [{'path':rel,'name':name} for name in sorted(after-before)]
(r/'implementation.patch').write_text(implementation);(r/'tests.patch').write_text(tests)
# Reconstruct every exact patch in isolation without touching a git index.
import tempfile,subprocess,shutil
with tempfile.TemporaryDirectory(prefix='typeii-period-patch-check-') as directory:
 directory=Path(directory)
 for item in files:
  b=r/'base'/item['path']
  if b.exists():dst=directory/item['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b,dst)
 for name in ['implementation.patch','tests.patch']:
  result=subprocess.run(['patch','-p1','-i',str(r/name)],cwd=directory,capture_output=True,text=True)
  if result.returncode:raise RuntimeError(name+': '+result.stdout+result.stderr)
 for item in files:
  assert sha((directory/item['path']).read_bytes())==item['after_sha256'],item['path']
artifacts={name:sha((r/name).read_bytes()) for name in ['implementation.patch','tests.patch','shared.patch','behavioral-red.patch','read-http-red.patch','shared-wiring-deltas.json','static-checks.json']}
manifest={'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_base':'Stage1 merged #1103 / 0c5a45c1fa7639bc253245b0464302ec0b48cd82; refreshed Control consumer seams and parent stage1 rule fixes offline. Shared deltas captured separately.','files':files,'counts':{'source':sum(f['kind']=='source' for f in files),'test':sum(f['kind']=='test' for f in files),'new_acceptance_methods':len(acceptance_added)},'acceptance_removed':acceptance_removed,'acceptance_added':acceptance_added,'patch_reconstruction':'Every implementation/test patch reconstructs every exact after SHA from stored baselines using patch in a temporary plain directory. No git index/worktree mutation.','static_checks':json.loads((r/'static-checks.json').read_text()),'artifacts_sha256':artifacts,'runtime':'Not run by child. Parent exclusively owns dotnet format/build/tests, production-host RED/green, direct per-file Jev and integration.','main_baseline_drift':[f['path'] for f in files if not f['main_matches_base']]}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(r/'owned-paths.txt').write_text(''.join(f['path']+'\n' for f in files))
print(json.dumps({'counts':manifest['counts'],'removed_acceptance':acceptance_removed,'main_baseline_drift':manifest['main_baseline_drift'],'patch_reconstruction':'verified','artifacts':artifacts},indent=2))
