from pathlib import Path
import difflib
r=Path('/tmp/compliance-typeii-period-prepared');w=r/'work';source=Path('/tmp/compliance-s29-read-prepared/work/test/Compliance.Tests/Features/AuditPackages/AuditPackageReadHttpTests.cs')
s=source.read_text().replace('using Bdgrz.Compliance.Features.AuditPackages;', 'using Bdgrz.Compliance.Features.Operations;\nusing Bdgrz.Compliance.Features.Examinations;')
s=s.replace('namespace Bdgrz.Compliance.Tests.Features.AuditPackages;', 'namespace Bdgrz.Compliance.Tests.Features.Operations;')
s=s.replace('AuditPackageReadHttpTests','ObservationPeriodReadHttpTests').replace('packageId','periodId').replace('PackageRoute','PeriodRoute').replace('PackageGiven','PeriodGiven').replace('CustomPackageReadBinder','CustomPeriodReadBinder')
s=s.replace('audit_package_id','observation_period_id').replace('audit-packages','observation-periods').replace('package_id','period_id').replace('package-reader','period-reader').replace('audit-package-read-http-tests','observation-period-read-http-tests')
s=s.replace('"Audit package", summary.GetProperty("name").GetString()', '"active", summary.GetProperty("status").GetString()')
s=s.replace('        Assert.Equal("draft", summary.GetProperty("status").GetString());', '        Assert.Equal(1, summary.GetProperty("revision").GetInt64());\n        Assert.Equal("2026-10-01", summary.GetProperty("period_start").GetString());\n        Assert.Equal("2027-09-30", summary.GetProperty("period_end").GetString());')
s=s.replace('        Assert.True(route.TryGetProperty("put", out _));\n','')
a=s.index('            var package = new AuditPackageRules(');b=s.index('            var projection = ',a)
s=s[:a]+'''            var plan = ApprovedPlan();
            var period = new TypeIIPeriodRules(Tenant, Program, Uuid.CreateVersion4());
            var source = new ExaminationContentReference("control", Uuid.CreateVersion4(), Uuid.CreateVersion4(), 1, new string('a', 64));
            Assert.Null(period.Start(plan.Current!, new TypeIIPeriodOpeningContent(plan.Current!.Current!.Content.ExaminationId,
                Uuid.CreateVersion4(), new string('b', 64), [source], []), Member, "Period manager", Now));
            await TypeIIPeriodSeeds.WriteAsync(writer, content, period);
'''+s[b:]
s=s.replace('IAuditPackageDirectoryProjection','IObservationPeriodDirectoryProjection').replace('FitzAuditPackageDirectory','FitzObservationPeriodDirectory').replace('AuditPackageManifest.Area','TypeIIPeriod.Area').replace('AuditPackageCreated','ObservationPeriodStarted').replace('return package.Id;', 'return period.Id;')
idx=s.index('        public async Task SeedProgramAsync(')
s=s[:idx]+'''        TypeIIPlan ApprovedPlan()
        {
            var plan = new TypeIIPlan(Tenant, Program, Uuid.CreateVersion4());
            var start = new DateOnly(2026, 10, 1);
            var end = new DateOnly(2027, 9, 30);
            var source = new ExaminationContentReference("control", Uuid.CreateVersion4(), Uuid.CreateVersion4(), 1, new string('a', 64));
            var terms = new TypeIIPlanContent(Uuid.CreateVersion4(), Uuid.CreateVersion4(), new string('a', 64), Uuid.CreateVersion4(), start, end,
                "Audit Firm", ["security"], Uuid.CreateVersion4(), Uuid.CreateVersion4(), [source],
                [new TypeIIControlPlanEntry(Uuid.CreateVersion4(), Uuid.CreateVersion4(), "Quarterly control", Member,
                    "quarterly", 4, start, null, ExpectedEvidenceDescriptions: ["Dated review"])], [], [], []);
            Assert.Null(plan.Propose(terms, Member, "Plan author", Now.AddHours(-3)));
            Assert.Null(plan.Review(plan.Revision, 1, "approve", "Reviewed exact plan.", Uuid.CreateVersion4(), "Independent reviewer", Now.AddHours(-2)));
            Assert.Null(plan.Approve(plan.Revision, 1, "Approved exact plan.", Uuid.CreateVersion4(), "CISO", "Executive approver", Now.AddHours(-1)));
            return plan;
        }

'''+s[idx:]
rel=Path('test/Compliance.Tests/Features/Operations/ObservationPeriodReadHttpTests.cs');(w/rel).write_text(s)
# Old-surface HTTP RED is separately applicable: same acceptance name, old aggregate persistence, no new directory APIs.
red=s.replace('var period = new TypeIIPeriodRules(', 'var period = new TypeIIPeriod(').replace('await TypeIIPeriodSeeds.WriteAsync(writer, content, period);', 'await writer.SaveAsync(period, new RequestDispatchContext(RequestActor.System));')
a=red.index('            var projection = ');b=red.index('            return period.Id;',a);red=red[:a]+red[b:]
# Keep only the canonical route regression in the standalone test file; all five rows remain in the migrated suite.
a=red.index('    [Fact]',red.index('    public async Task ShouldUseCanonicalPeriodRouteGivenMisleadingQueryIdentities'))
b=red.index('    sealed class Fixture',a);red=red[:a]+red[b:]
# Unused immutable content local is not needed against the old fixture.
red=red.replace('            var content = scope.ServiceProvider.GetRequiredService<IImmutableContentStore>();\n','')
(r/'read-http-red.patch').write_text(''.join(difflib.unified_diff([],red.splitlines(True),fromfile='/dev/null',tofile='b/'+str(rel))))
(r/'read-http-red.md').write_text('''Optional separate production HTTP RED before applying the read layer:\n\n`FullyQualifiedName~ObservationPeriodReadHttpTests.ShouldUseCanonicalPeriodRouteGivenMisleadingQueryIdentities`\n\nThe standalone patch seeds through the existing old period class/helper, contains no new compact types or projection APIs, and expects the selected scoped GET to return its exact route-bound identity. The old host returns 404. Reverse the standalone patch before applying the full tests patch, which preserves the same acceptance and adds scoped list/authorization/OpenAPI cases.\n''')
print('Scoped period production HTTP tests and standalone old-API HTTP RED prepared')
