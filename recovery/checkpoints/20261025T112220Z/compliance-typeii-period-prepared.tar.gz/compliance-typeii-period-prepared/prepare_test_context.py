from pathlib import Path
import re,shutil
r=Path('/tmp/compliance-typeii-period-prepared');w=r/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def get(rel):
 rel=Path(rel)
 for d in ['base','work']:
  p=r/d/rel
  if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,p)
 return w/rel
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriodReadSnapshot.cs';s=p.read_text();idx=s.index('    public TypeIIPeriodView? View')
s=s[:idx]+'''    public Uuid Id => Owner.Id;
    public EventStreamAddress Stream => Owner.Stream;
    public long Revision => Owner.Revision;
    public DomainEvent? Pending => Owner.Pending;
    public Uuid? PendingOperationId => Owner.PendingOperationId;
    public TypeIIPeriodCalendarAuthorization? CalendarAuthorization => Owner.CalendarAuthorization;
'''+s[idx:];p.write_text(s)
p=w/'test/Compliance.Tests/Testing/TypeIIRangeHost.cs';s=p.read_text();idx=s.index('    public IRequestBus Bus')
s=s[:idx]+'''    public TypeIIPeriodReader Periods => new(Reader, Events, Content);
    public TypeIIPeriodOperations PeriodOperations(TimeProvider clock) => new(
        Services.GetRequiredService<NativeOperationExecutor>(), Periods, Content, clock);

'''+s[idx:]
s=s.replace('Services.GetRequiredService<NativeOperationExecutor>(), Reader, Content, clock);','Services.GetRequiredService<NativeOperationExecutor>(), Reader, Periods, Content, clock);',1)
s=s.replace('''        Services.GetRequiredService<NativeOperationExecutor>(), Reader, Services.GetRequiredService<ControlOperationsReader>(),
        Content, clock);''','''        PeriodOperations(clock), Services.GetRequiredService<ControlOperationsReader>(), Content);''')
p.write_text(s)
p=w/'test/Compliance.Tests/Testing/TypeIIRangeFixture.cs';s=p.read_text()
s=s.replace('''    public Task<TypeIIPeriod> PeriodAsync(Uuid periodId) =>
        Host.HydrateAsync(new TypeIIPeriod(TenantId, ProgramId, periodId));''','''    public Task<TypeIIPeriodReadSnapshot> PeriodAsync(Uuid periodId) =>
        Host.Periods.ReadAsync(TenantId, ProgramId, periodId).AsTask();''')
s=s.replace('Assert.Null(period.PrepareOpening(plan.Current!, Opening(gap),','Assert.Null(new TypeIIPeriodRules(TenantId, ProgramId, id).PrepareOpening(plan.Current!, Opening(gap),')
s=s.replace('        var period = await PeriodAsync(periodId);\n        var references = period.Current!', '        var period = (await PeriodAsync(periodId)).Rules;\n        var references = period.Current!')
s=s.replace('await Host.Writer.SaveAsync(period, new RequestDispatchContext(RequestActor.System));\n    }\n\n    public ValueTask DisposeAsync()',
 'await TypeIIPeriodSeeds.AppendAsync(Host.Reader, Host.Writer, Host.Content, period);\n    }\n\n    public ValueTask DisposeAsync()')
p.write_text(s)
# Pure rules are sufficient for standalone domain fixtures that never persist period state.
for rel in ['Features/AuditPackages/AuditPackageTests.cs','Features/AuditPopulations/AuditPopulationTests.cs','Features/AuditPopulations/AuditPopulationCommandHandlerTests.cs','Features/AuditPopulations/GenerateAuditPopulationExportHandlerTests.cs']:
 p=w/'test/Compliance.Tests'/rel;s=p.read_text();s=s.replace('using TypeIIPeriodAggregate = Bdgrz.Compliance.Features.Operations.TypeIIPeriod;', 'using TypeIIPeriodAggregate = Bdgrz.Compliance.Features.Operations.TypeIIPeriodRules;');p.write_text(s)
# Expose the real event reader/immutable store to explicit read composition in small manual fixtures.
fixtures=[
 ('Features/AuditPackages/AmendAuditPackageHandlerTests.cs','ContentStore'),
 ('Features/AuditPackages/CreateAuditPackageHandlerTests.cs','ContentStore'),
 ('Features/AuditPackages/SnapshotSourcePublicationTests.cs','Content'),
 ('Features/AuditPopulations/DefineAuditPopulationHandlerTests.cs','PeriodContent'),
 ('Features/Programs/ProposeProgramRolloverHandlerTests.cs','PeriodContent'),
 ('Features/SystemDescription/SystemDescriptionDraftCommandHandlerTests.cs','PeriodContent'),
 ('Features/Examinations/RecordManagementAssertionHandlerTests.cs','ContentStore')]
for rel,content in fixtures:
 p=get('test/Compliance.Tests/'+rel);s=p.read_text()
 if 'using Bdgrz.Compliance.Features.Operations;' not in s:s='using Bdgrz.Compliance.Features.Operations;\n'+s
 if 'using Bdgrz.Compliance.Features.Content;' not in s:s='using Bdgrz.Compliance.Features.Content;\n'+s
 if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
 idx=s.index('        public IAggregateReader Reader')
 props='''        public InMemoryEventStore PeriodEvents { get; } = new();
'''
 if content=='PeriodContent':props+='''        public IImmutableContentStore PeriodContent { get; } = TypeIIPeriodSeeds.NewContentStore();
'''
 props+=f'''        public TypeIIPeriodReader Periods => new(Reader, PeriodEvents, {content});
'''
 s=s[:idx]+props+s[idx:]
 s=s.replace('services.AddSingleton<IEventStore>(new InMemoryEventStore());','services.AddSingleton<IEventStore>(PeriodEvents);')
 s=s.replace('new AuditPackageSourceBuilder(Reader)', 'new AuditPackageSourceBuilder(Reader, Periods)')
 s=s.replace('new AuditPackageSourceBuilder(fixture.Reader)', 'new AuditPackageSourceBuilder(fixture.Reader, fixture.Periods)')
 s=s.replace('new AuditPackageSourceBuilder(fixture.Reader, fixture.Content)', 'new AuditPackageSourceBuilder(fixture.Reader, fixture.Periods, fixture.Content)')
 s=s.replace('new AuditPackageSourceBuilder(fixture.Reader,\n', 'new AuditPackageSourceBuilder(fixture.Reader, fixture.Periods,\n')
 s=s.replace('new(Executor, Reader, _clock)', 'new(Executor, Periods, _clock)' if 'DefineAuditPopulation' in rel else 'new(Executor, Reader, Periods, _clock)')
 s=s.replace('new(Executor, Reader, Clock)', 'new(Executor, Reader, Periods, Clock)')
 s=s.replace('new(Reader, Executor, _clock);\n\n        public', 'new(Reader, Executor, _clock);\n\n        public')
 if 'SystemDescription' in rel:s=s.replace('BindSourcesHandler() => new(Reader, Executor, _clock)', 'BindSourcesHandler() => new(Reader, Executor, Periods, _clock)')
 s=s.replace('fixture.Reader, packages, fixture.Clock)', 'fixture.Reader, packages, fixture.Periods, fixture.Clock)')
 p.write_text(s)
# Common content creation remains test-only and uses the real Fitz immutable adapter.
p=w/'test/Compliance.Tests/Testing/TypeIIPeriodSeeds.cs';s=p.read_text();idx=s.index('    public static Task WriteAsync')
s=s[:idx]+'''    public static IImmutableContentStore NewContentStore() => new FitzKvImmutableContentStore(
        new Bdgrz.Compliance.Hosting.Persistence.PersistenceKvClient(new Cntryl.Fitz.Testing.InMemoryKvClient()));

'''+s[idx:];p.write_text(s)
# Shared package fixtures serve validation and management-review tests as well.
for rel in ['Features/AuditPackages/ValidateAuditPackageHandlerTests.cs','Features/Examinations/RecordManagementExaminationReviewHandlerTests.cs']:
 p=get('test/Compliance.Tests/'+rel);s=p.read_text()
 s=s.replace('new AuditPackageSourceBuilder(fixture.Reader)', 'new AuditPackageSourceBuilder(fixture.Reader, fixture.Periods)')
 s=s.replace('fixture.Reader, fixture.Packages,', 'fixture.Reader, fixture.Packages, fixture.Periods,')
 p.write_text(s)
# Revert two unaffected handler copies: only assertion and review consume the period reader.
for name in ['RecordExaminationOutcomeHandler','RecordManagementRepresentationLetterHandler']:
 rel=Path(f'src/Compliance.Core/Features/Examinations/{name}.cs');shutil.copy2(r/'base'/rel,w/rel)
print('Test stores/read contexts and shared period/package fixture dependencies prepared')
