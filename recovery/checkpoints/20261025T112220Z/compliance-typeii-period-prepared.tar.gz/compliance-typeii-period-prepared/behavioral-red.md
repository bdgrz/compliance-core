Run against the pre-compaction code after stage 1 integration:

`FullyQualifiedName~TypeIIPeriodTests.ShouldOpenCompleteSourcePopulationGivenImmutableBodyExceedsEventBudget`

The existing opening allows 1,000 source references and its admitted intent is stored outside the event, but ApplyOpening re-embeds the complete view in its event and rejects it at 64 KiB. This regression uses only the old public class/test helper surface and must fail there. Reverse this standalone patch before applying the full migration; preserve the same acceptance name in the new rule/native persistence coverage. Parent owns all runtime evidence.
