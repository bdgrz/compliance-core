from pathlib import Path
import shutil,json
r=Path('/tmp/compliance-typeii-period-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');w=r/'work'
def method(text, needle):
 start=text.index(needle);a=text.index('{',start);depth=0
 for i in range(a,len(text)):
  if text[i]=='{':depth+=1
  elif text[i]=='}':
   depth-=1
   if depth==0:return text[start:i+1],start,i+1
 raise ValueError(needle)
main=(repo/'src/Compliance.Core/Features/Operations/TypeIIPeriod.cs').read_text()
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriodRules.cs';s=p.read_text()
for needle in ['    static ExaminationContentReference[]? NormalizeReferences(', '    static Uuid[] ChangedRecordIds(']:
 fresh,_,_=method(main,needle)
 oldneedle=needle if needle in s else needle.replace('    static','    internal static')
 _,a,b=method(s,oldneedle)
 if 'ChangedRecordIds' in needle:fresh=fresh.replace('    static', '    internal static',1)
 s=s[:a]+fresh+s[b:]
p.write_text(s)
rel=Path('test/Compliance.Tests/Features/Operations/TypeIIPeriodTests.cs');s=(w/rel).read_text();new,_,_=method((repo/rel).read_text(),'    public void ShouldPreserveOpeningAndClosingSourceVersionsGivenSourceChangedDuringObservationPeriod()')
idx=s.index('    [Fact]');s=s[:idx]+'    [Fact]\n'+new+'\n\n'+s[idx:];(w/rel).write_text(s)
for rel in [Path('src/Compliance.Core/Features/Operations/TypeIIPeriod.cs'),Path('src/Compliance.Core/Features/Operations/RecordTypeIIPeriodCloseValidationHandler.cs'),rel]:
 shutil.copy2(repo/rel,r/'base'/rel)
report=json.loads((r/'refresh-report.json').read_text());report['resolved']={
 'TypeIIPeriod.cs':'Stage2 compact owner retained; all parent state-rule fixes copied into TypeIIPeriodRules.',
 'RecordTypeIIPeriodCloseValidationHandler.cs':'Stage2 typed Unit native helper preserves parent typed transport and all inner preparation catches.',
 'TypeIIPeriodTests.cs':'Both new large-source native persistence acceptance and parent exact source-version set acceptance retained.'}
report['conflicts']=[];(r/'refresh-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Offline refresh conflicts resolved; Control APIs and parent source-version/snapshot fixes preserved')
