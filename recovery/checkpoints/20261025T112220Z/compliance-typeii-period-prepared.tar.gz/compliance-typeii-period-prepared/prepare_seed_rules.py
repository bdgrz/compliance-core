from pathlib import Path
w=Path('/tmp/compliance-typeii-period-prepared/work');op=w/'src/Compliance.Core/Features/Operations';testing=w/'test/Compliance.Tests/Testing'
p=op/'TypeIIPeriodRules.cs';s=p.read_text().replace('readonly List<DomainEvent> _pendingChanges = [];','readonly List<DomainEvent> _pendingChanges = [];\n    readonly List<DomainEvent> _appliedChanges = [];\n    public IReadOnlyList<DomainEvent> AppliedChanges => _appliedChanges.AsReadOnly();\n    internal ulong SourcePhysicalPosition { get; set; }')
s=s.replace('        reducer(change);\n','        reducer(change);\n        _appliedChanges.Add(change);\n')
s=s.replace('    void RaiseEvent(DomainEvent change)','    internal void RaiseEvent(DomainEvent change)')
s=s.replace('    static Uuid[] ChangedRecordIds(', '    internal static Uuid[] ChangedRecordIds(')
s=s.replace('            reason, changed, affected);','            reason, changed, affected) with { OriginalExpectedRevision = expectedRevision };')
p.write_text(s)
p=op/'TypeIIPeriod.cs';s=p.read_text().replace('CommandFailure StaleRevision() => VersionedRecordRules.StaleRevision("Type II period", Revision);','CommandFailure StaleRevision() => CommandFailure.ForVersion(VersionedRecordRules.StaleRevision("Type II period", Revision));');p.write_text(s)
p=testing/'TypeIIPeriodTestExtensions.cs';s=p.read_text().replace('this TypeIIPeriod period','this TypeIIPeriodRules period').replace('Provenance(TypeIIPeriod period','Provenance(TypeIIPeriodRules period');p.write_text(s)
p=w/'test/Compliance.Tests/Features/Operations/TypeIIPeriodTests.cs';s=p.read_text().replace('using TypeIIPeriodAggregate = Bdgrz.Compliance.Features.Operations.TypeIIPeriod;','using TypeIIPeriodAggregate = Bdgrz.Compliance.Features.Operations.TypeIIPeriodRules;')
s=s.replace('new AggregateScenario<TypeIIPeriodAggregate>(', 'new TypeIIPeriodRuleScenario(')
# Assertions about internal rule mutations name the transient body rather than the shipped compact fact.
for n in ['ObservationPeriodStarted','ObservationPeriodAmended','ObservationPeriodCloseProposed','TypeIIPeriodCloseApproved','ObservationPeriodCloseFrozen','TypeIIPeriodCloseAmended']:
 s=s.replace('Assert.IsType<'+n+'>','Assert.IsType<'+n+'Body>').replace('.OfType<'+n+'>','.OfType<'+n+'Body>')
p.write_text(s)
(testing/'TypeIIPeriodRuleScenario.cs').write_text('''using Bdgrz.Compliance.Features.Operations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

/// <summary>Pure rule replay assertions; native content publication and compact persistence are proved separately.</summary>
sealed class TypeIIPeriodRuleScenario(TypeIIPeriodRules rules)
{
    public TypeIIPeriodRules Aggregate { get; private set; } = rules;
    public IReadOnlyList<DomainEvent> PendingEvents => Aggregate.PendingChanges;
    public TypeIIPeriodRuleScenario Given(IEnumerable<DomainEvent> changes)
    {
        foreach (var change in changes)
            Aggregate.Apply(change);
        Aggregate.ClearPendingChanges();
        return this;
    }
}
''')
print('Pure rule acceptance names/replay fixture migrated; native seed helper follows')
