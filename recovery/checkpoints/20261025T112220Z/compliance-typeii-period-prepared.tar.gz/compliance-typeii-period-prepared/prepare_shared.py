from pathlib import Path
import shutil,difflib,json
r=Path('/tmp/compliance-typeii-period-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
rels=[Path('src/Compliance.App/Program.cs'),Path('src/Compliance.Core/ComplianceServiceCollectionExtensions.cs'),Path('src/Compliance.Core/ComplianceCoreJsonContext.cs')]
for rel in rels:
 for d in ['shared-base','shared-work']:
  p=r/d/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,p)
p=r/'shared-work/src/Compliance.Core/ComplianceCoreJsonContext.cs';s=p.read_text();roots=['Bdgrz.Compliance.Features.Operations.TypeIIPeriodAuthorityHeader','Bdgrz.Compliance.Features.Operations.TypeIIPeriodMutationContent','Bdgrz.Compliance.Features.Operations.TypeIIPeriodCloseMaterialProof','Bdgrz.Compliance.Features.Operations.ObservationPeriodIdentity','Bdgrz.Compliance.Features.Operations.ObservationPeriodCloseIdentity']
new=''.join('[JsonSerializable(typeof('+name+'))]\n' for name in roots if 'typeof('+name+')' not in s)
s=s.replace('[JsonSerializable(typeof(',new+'[JsonSerializable(typeof(',1);p.write_text(s)
p=r/'shared-work/src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';s=p.read_text()
s=s.replace('        services.AddScoped<TypeIIRangeVerifier>();','''        services.AddScoped<TypeIIPeriodReader>();
        services.AddScoped<TypeIIPeriodOperations>();
        services.AddScoped<TypeIIPeriodCloseMaterialReader>();
        services.AddScoped<FitzObservationPeriodDirectory>();
        services.AddScoped<IObservationPeriodDirectoryReader>(provider => provider.GetRequiredService<FitzObservationPeriodDirectory>());
        services.AddScoped<IObservationPeriodCloseDirectoryReader>(provider => provider.GetRequiredService<FitzObservationPeriodDirectory>());
        services.AddScoped<IObservationPeriodDirectoryProjection>(provider => provider.GetRequiredService<FitzObservationPeriodDirectory>());
        services.AddScoped<ObservationPeriodDirectoryReadConsistency>();
        services.AddScoped<TypeIIRangeVerifier>();''')
s=s.replace('            .AddRequestHandler<FreezeTypeIIPeriodCloseHandler>()','''            .AddRequestHandler<FreezeTypeIIPeriodCloseHandler>()
            .AddRequestHandler<AmendTypeIIPeriodCloseHandler>()
            .AddRequestHandler<GetObservationPeriodHandler>()
            .AddRequestHandler<ListObservationPeriodsHandler>()
            .AddRequestHandler<GetObservationPeriodCloseHandler>()
            .AddRequestHandler<PreviewObservationPeriodCloseHandler>()''')
s=s.replace('            .AddProjector<AuditPackageDirectoryProjector>', '''            .AddProjector<ObservationPeriodDirectoryProjector>(FitzObservationPeriodDirectory.ProjectorName, WorkloadScope.PerTenant)
            .AddProjector<AuditPackageDirectoryProjector>''')
p.write_text(s)
p=r/'shared-work/src/Compliance.App/Program.cs';s=p.read_text()
for method,name in [('Put','CancelTypeIIPeriodAmendment'),('Post','ApproveTypeIIPeriodClose'),('Post','FreezeTypeIIPeriodClose')]:s=s.replace(f'MapPortia{method}<{name}>',f'MapPortia{method}<{name}, UnitResult>')
marker='    app.MapPortiaPost<ApproveTypeIIPeriodClose, UnitResult>('
new='''    app.MapPortiaPut<GenerateDueControlOccurrences, UnitResult>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/occurrence-generations/{generation_key}")
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Observation periods");
    app.MapPortiaGet<GetObservationPeriod, ObservationPeriodView>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}", endpoint => endpoint
                .OnBind(Program.BindObservationPeriodRead)
                .Parameter<Uuid>("tenant_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("program_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("period_id", PortiaHttpParameterLocation.Route, required: true))
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Observation periods");
    app.MapPortiaGet<ListObservationPeriods, Page<ObservationPeriodSummaryView>>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods")
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Observation periods");
    app.MapPortiaGet<PreviewObservationPeriodClose, ObservationPeriodClosePreview>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/close-preview", endpoint => endpoint
                .OnBind(Program.BindObservationPeriodClosePreview)
                .Parameter<Uuid>("tenant_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("program_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("period_id", PortiaHttpParameterLocation.Route, required: true))
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Observation periods");
    app.MapPortiaGet<GetObservationPeriodClose, ObservationPeriodCloseView>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-period-closes/{close_id}", endpoint => endpoint
                .OnBind(Program.BindObservationPeriodCloseRead)
                .Parameter<Uuid>("tenant_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("program_id", PortiaHttpParameterLocation.Route, required: true)
                .Parameter<Uuid>("close_id", PortiaHttpParameterLocation.Route, required: true))
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Observation periods");
    app.MapPortiaPut<AmendTypeIIPeriodClose, UnitResult>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/close-snapshots/{close_snapshot_id}/amendments/{command_id}")
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Observation periods");
'''
assert marker in s;s=s.replace(marker,new+marker)
marker='public partial class Program\n{';assert marker in s
s=s.replace(marker,marker+'''
    internal static GetObservationPeriod BindObservationPeriodRead(HttpContext context) => new(
        ApplicationRouteId(context, "tenant_id"), ApplicationRouteId(context, "program_id"), ApplicationRouteId(context, "period_id"));

    internal static PreviewObservationPeriodClose BindObservationPeriodClosePreview(HttpContext context) => new(
        ApplicationRouteId(context, "tenant_id"), ApplicationRouteId(context, "program_id"), ApplicationRouteId(context, "period_id"));

    internal static GetObservationPeriodClose BindObservationPeriodCloseRead(HttpContext context) => new(
        ApplicationRouteId(context, "tenant_id"), ApplicationRouteId(context, "program_id"), ApplicationRouteId(context, "close_id"));
''')
p.write_text(s)
patch=''
for rel in rels:
 a=(r/'shared-base'/rel).read_text();b=(r/'shared-work'/rel).read_text()
 patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(r/'shared.patch').write_text(patch)
(r/'shared-wiring-deltas.json').write_text(json.dumps({'json_roots':roots,'scoped_services':['TypeIIPeriodReader','TypeIIPeriodOperations','TypeIIPeriodCloseMaterialReader','FitzObservationPeriodDirectory','IObservationPeriodDirectoryReader -> same scoped FitzObservationPeriodDirectory','IObservationPeriodCloseDirectoryReader -> same scoped FitzObservationPeriodDirectory','IObservationPeriodDirectoryProjection -> same scoped FitzObservationPeriodDirectory','ObservationPeriodDirectoryReadConsistency'],'handlers_add':['AmendTypeIIPeriodCloseHandler','GetObservationPeriodHandler','ListObservationPeriodsHandler','GetObservationPeriodCloseHandler','PreviewObservationPeriodCloseHandler'],'existing_typed_unit_handlers':['RecordTypeIIPeriodCloseValidationHandler','ApproveTypeIIPeriodCloseHandler','FreezeTypeIIPeriodCloseHandler','GenerateDueControlOccurrencesHandler','CancelTypeIIPeriodAmendmentHandler'],'projector':'ObservationPeriodDirectoryProjector; ObservationPeriodIdentityDirectoryV1; PerTenant','http':{'existing_typed_unit_maps':['CancelTypeIIPeriodAmendment','ApproveTypeIIPeriodClose','FreezeTypeIIPeriodClose'],'add':['PUT /api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/occurrence-generations/{generation_key}','GET /api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}','GET /api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods','GET /api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/close-preview','GET /api/v1/tenants/{tenant_id}/programs/{program_id}/observation-period-closes/{close_id}','PUT /api/v1/tenants/{tenant_id}/programs/{program_id}/observation-periods/{period_id}/close-snapshots/{close_snapshot_id}/amendments/{command_id}'],'binders':['BindObservationPeriodRead','BindObservationPeriodCloseRead','BindObservationPeriodClosePreview'],'authorization':'Existing ApiUser HTTP policy and current IProgramReadRequest / program-scoped client-management mutation authorizers; current executive authority before close replay.'},'mcp':'No new MCP write mapping. Existing personal-HTTP command checks retained.'},indent=2)+'\n')
print('Exact shared registration/JSON/HTTP delta prepared; main untouched')
