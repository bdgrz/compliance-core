from pathlib import Path
import difflib
r=Path('/tmp/compliance-typeii-period-prepared');rel=Path('test/Compliance.Tests/Features/Operations/TypeIIPeriodTests.cs')
old=(r/'base'/rel).read_text();idx=old.index('    [Fact]')
test='''    [Fact]
    public void ShouldOpenCompleteSourcePopulationGivenImmutableBodyExceedsEventBudget()
    {
        // Arrange
        var period = NewPeriod();
        var opening = Opening() with
        {
            SourceReferences = Enumerable.Range(0, 1000).Select(index => new ExaminationContentReference(
                "evidence", Uuid.CreateVersion5(PeriodId, "source:" + index),
                Uuid.CreateVersion5(PeriodId, "version:" + index), 1, new string('a', 64))).ToArray(),
        };

        // Act
        var result = period.Start(ApprovedPlan().Current!, opening, ProposerId, "Compliance lead", Now);

        // Assert
        Assert.Null(result);
        Assert.Equal(1000, period.Current!.OpeningSourceReferences.Count);
    }

'''
new=old[:idx]+test+old[idx:]
(r/'behavioral-red.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel))))
(r/'behavioral-red.md').write_text('''Run against the pre-compaction code after stage 1 integration:\n\n`FullyQualifiedName~TypeIIPeriodTests.ShouldOpenCompleteSourcePopulationGivenImmutableBodyExceedsEventBudget`\n\nThe existing opening allows 1,000 source references and its admitted intent is stored outside the event, but ApplyOpening re-embeds the complete view in its event and rejects it at 64 KiB. This regression uses only the old public class/test helper surface and must fail there. Reverse this standalone patch before applying the full migration; preserve the same acceptance name in the new rule/native persistence coverage. Parent owns all runtime evidence.\n''')
(r/'work'/rel).write_text(new)
print('Standalone old-API large-source opening regression ready')
