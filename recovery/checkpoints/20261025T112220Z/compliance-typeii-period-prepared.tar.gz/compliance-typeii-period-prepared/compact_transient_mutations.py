from pathlib import Path
w=Path('/tmp/compliance-typeii-period-prepared/work');op=w/'src/Compliance.Core/Features/Operations'
for p in op.glob('*Body.cs'):
 s=p.read_text().replace(' : DomainEvent, INativeOperationFact;', ';').replace(' : DomainEvent;', ';').replace(' : DomainEvent\n{','\n{')
 p.write_text(s)
p=op/'TypeIIPeriodRules.cs';s=p.read_text()
s=s.replace('Dictionary<Type, Action<DomainEvent>>', 'Dictionary<Type, Action<object>>')
s=s.replace('List<DomainEvent> _pendingChanges', 'List<object> _pendingChanges').replace('List<DomainEvent> _appliedChanges','List<object> _appliedChanges')
s=s.replace('IReadOnlyList<DomainEvent> AppliedChanges', 'IReadOnlyList<object> AppliedChanges').replace('IReadOnlyList<DomainEvent> PendingChanges','IReadOnlyList<object> PendingChanges')
s=s.replace('void On<T>(Action<T> reducer) where T : DomainEvent', 'void On<T>(Action<T> reducer) where T : class')
s=s.replace('public void Apply(DomainEvent change)', 'public void Apply(object change)').replace('internal void RaiseEvent(DomainEvent change)', 'internal void RaiseEvent(object change)')
s=s.replace('Dictionary<Uuid, DomainEvent> _terminal', 'Dictionary<Uuid, object> _terminal').replace('List<DomainEvent> _facts', 'List<object> _facts')
s=s.replace('public DomainEvent? TerminalFor(', 'public object? TerminalFor(')
s=s.replace('_facts.FirstOrDefault(fact => fact.Metadata?.EventId == eventId)', '_facts.OfType<DomainEvent>().FirstOrDefault(fact => fact.Metadata?.EventId == eventId)')
s=s.replace('void Settle(DomainEvent fact,', 'void Settle(object fact,')
s=s.replace('Func<Uuid, Uuid, long, Uuid?, TypeIIPeriodView, DateTimeOffset, DomainEvent> createEvent', 'Func<Uuid, Uuid, long, Uuid?, TypeIIPeriodView, DateTimeOffset, object> createEvent')
# Only actual native admission/generation facts participate in NativeAcceptance; transient body records never do.
for name in ['ObservationPeriodStartedBody','ObservationPeriodAmendedBody','ObservationPeriodCloseProposedBody']:
 start=s.index('    void Apply('+name+' ev)');end=s.find('\n    void ',start+1)
 if end<0:end=len(s)
 chunk=s[start:end].replace('        Acceptance.Observe(ev);\n','')
 s=s[:start]+chunk+s[end:]
p.write_text(s)
p=op/'FrozenTypeIIPeriodMutation.cs';s=p.read_text().replace('DomainEvent RuleMutation','object RuleMutation');p.write_text(s)
p=op/'TypeIIPeriodContent.cs';s=p.read_text();a=s.index('    internal static DomainEvent Body(');s=s[:a]+'}\n';p.write_text(s)
p=w/'test/Compliance.Tests/Testing/TypeIIPeriodRuleScenario.cs';s=p.read_text().replace('IReadOnlyList<DomainEvent>', 'IReadOnlyList<object>').replace('IEnumerable<DomainEvent>', 'IEnumerable<object>');p.write_text(s)
p=w/'test/Compliance.Tests/Testing/TypeIIPeriodSeeds.cs';s=p.read_text().replace('Operation(DomainEvent value,','Operation(object value,');p.write_text(s)
p=w/'test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.NativeOwners.cs';s=p.read_text().replace('result.ResultSchema','result.Schema').replace('result.Body','result.Value');p.write_text(s)
print('Transient period body mutations are plain records; no unregistered durable event types remain')
