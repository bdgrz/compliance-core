from pathlib import Path
w=Path('/tmp/compliance-typeii-period-prepared/work');op=w/'src/Compliance.Core/Features/Operations'
p=op/'TypeIIRangeReceivers.cs';s=p.read_text()
s=s.replace('IRequestBus bus, TimeProvider clock, TypeIIRangeVerifier verifier)', 'IRequestBus bus, TimeProvider clock, TypeIIRangeVerifier verifier, TypeIIPeriodReader periods)')
s=s.replace('command.PeriodId, command.CommandId, ct).ConfigureAwait(false);','command.PeriodId, command.CommandId, ct, command.Source.EventId).ConfigureAwait(false);')
s=s.replace('command.CommandId), fresh =>','command.CommandId, operation), fresh =>')
s=s.replace('commandId), pending =>','commandId, operationId), pending =>')
a=s.index('                var step = await executor.ExecuteAsync(new TypeIIPeriod',s.index('    public async ValueTask<Result<ReceiverOutcome>> ApplyAsync'))
b=s.index('                return step.IsSuccess',a)
s=s[:a]+'''                var preparedOwner = await reader.HydrateAsync(new TypeIIPeriod(tenant, intent.ProgramId, intent.PeriodId,
                    command.CommandId, operation), ct).ConfigureAwait(false);
                if (DecidePeriod(preparedOwner, binding, operation, intent) is { } already)
                    return already;
                var snapshot = await periods.ReadAsync(preparedOwner, ct).ConfigureAwait(false);
                var before = snapshot.View;
                var ready = opening is not null
                    ? snapshot.Rules.ApplyOpening(provenance, opening.State, permit, result)
                    : snapshot.Rules.ApplyAmendment(provenance, amendment!, permit, result);
                if (!ready.IsSuccess)
                    return Result<ReceiverOutcome>.Failure(ready.Error!);
                var frozen = await TypeIIPeriodContent.FreezeAsync(content, before, snapshot.Rules, provenance, ct).ConfigureAwait(false);
                var native = TypeIIPeriodContent.Fact(frozen, provenance, null, result, preparedOwner.NativeSequence + 1);
                var step = await executor.ExecuteAsync(new TypeIIPeriod(tenant, intent.ProgramId, intent.PeriodId,
                    command.CommandId, operation), fresh =>
                    {
                        if (DecidePeriod(fresh, binding, operation, intent) is { } decided)
                            return AggregateOutcome.Discard(Result<Step>.Success(new Decided(decided)));
                        var raised = fresh.Append(native, frozen.Before, frozen.After, preparedOwner.NativeSequence,
                            preparedOwner.CommittedStreamPosition);
                        return raised.IsSuccess
                            ? AggregateOutcome.Commit(Result<Step>.Success(new Decided(SourceUseReceiverSupport.Applied(
                                Fact(fresh.Stream, fresh.Acceptance.SelectedFact!)))))
                            : AggregateOutcome.Discard(Result<Step>.Failure(raised.Error!));
                    }, context, ct).ConfigureAwait(false);
'''+s[b:]
s=s.replace('return SourceUseReceiverSupport.Permanent($"The frozen change cannot be verified: {exception.Message}");',
 '''return Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The frozen range change cannot be verified.", exception is ImmutableContentUnavailableException));''')
p.write_text(s)
p=op/'CancelTypeIIPeriodAmendmentHandler.cs';s=p.read_text().replace('request.PeriodId, request.CommandId),','request.PeriodId, request.CommandId, request.AmendmentId),');p.write_text(s)
p=op/'MaterializeControlOccurrenceHandler.cs';s=p.read_text().replace('new TypeIIPeriod(tenant, command.ProgramId, periodId)',
 'new TypeIIPeriod(tenant, command.ProgramId, periodId, selectedEventId: source.EventId)');p.write_text(s)
print('Range receivers now prepare verified immutable bodies and append against the exact native/physical cut')
