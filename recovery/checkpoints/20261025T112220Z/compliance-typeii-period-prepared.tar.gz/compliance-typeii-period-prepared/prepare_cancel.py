from pathlib import Path
w=Path('/tmp/compliance-typeii-period-prepared/work');op=w/'src/Compliance.Core/Features/Operations'
for name in ['ApproveTypeIIPeriodClose','FreezeTypeIIPeriodClose','AmendTypeIIPeriodClose']:
 p=w/f'src/Compliance.Common/Features/Examinations/{name}.cs';s=p.read_text().replace('IClientManagementMutationRequest, ICallable;', 'IClientManagementMutationRequest, ICallable\n{\n    Uuid IIdentifiedRequest.RequestId => CommandId;\n}\n');p.write_text(s)
p=w/'src/Compliance.Common/Features/Operations/RecordTypeIIPeriodCloseValidation.cs';s=p.read_text();seen=set();lines=[]
for line in s.splitlines(True):
 if line.startswith('using ') and line in seen:continue
 if line.startswith('using '):seen.add(line)
 lines.append(line)
p.write_text(''.join(lines))
p=w/'src/Compliance.Common/Features/Operations/CancelTypeIIPeriodAmendment.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s;s=s.replace(': IRequest,', ': IRequest<UnitResult>,');p.write_text(s)
p=op/'TypeIIPeriod.cs';s=p.read_text().replace('public Result CancelAmendment(Uuid amendmentId, OperationProvenance operation, ImmutableContentRef firstResponse)',
 'public Result CancelAmendment(Uuid amendmentId, OperationProvenance operation, ImmutableContentRef firstResponse, ImmutableContentRef operationResult)')
s=s.replace('accepted.Intent, null, operation, firstResponse, null, ProgramId));', 'accepted.Intent, null, operation, firstResponse, operationResult, ProgramId));');p.write_text(s)
p=op/'CancelTypeIIPeriodAmendmentHandler.cs';s=p.read_text().replace('IRequestHandler<CancelTypeIIPeriodAmendment>', 'IRequestHandler<CancelTypeIIPeriodAmendment, UnitResult>').replace('ValueTask<Result> HandleAsync', 'ValueTask<Result<UnitResult>> HandleAsync')
s=s.replace('return Result.Failure(', 'return Result<UnitResult>.Failure(')
a=s.index('        var unitBody = ');b=s.index('    static Result<FirstResponseDescriptor> Prepare(',a)
s=s[:a]+'''        ImmutableContentRef? result = null;
        try
        {
            var accepted = await operations.ExecuteAsync(new NativeOperation<TypeIIPeriod>(binding,
                () => new TypeIIPeriod(request.TenantId, request.ProgramId, request.PeriodId, request.CommandId, request.AmendmentId),
                period => period.Acceptance,
                async (period, token) =>
                {
                    if (period.ProgramId != request.ProgramId)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The period was not found in this program."));
                    var guard = period.PrepareCancel(request.AmendmentId, request.ExpectedRevision);
                    if (!guard.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(guard.Error!);
                    try
                    {
                        var response = await NativeContent.FreezeUnitAsync(content, request.TenantId, token).ConfigureAwait(false);
                        result = response.Result;
                        return Result<FirstResponseDescriptor>.Success(response.Response);
                    }
                    catch (ImmutableContentIntegrityException exception)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The exact cancellation response cannot be verified.", exception is ImmutableContentUnavailableException));
                    }
                }, (period, first) => period.CancelAmendment(request.AmendmentId, provenance, first, result!)), context, ct).ConfigureAwait(false);
            return await NativeContent.ResponseAsync<UnitResult>(content, request.TenantId, accepted, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The original period cancellation response cannot be verified.", exception is ImmutableContentUnavailableException));
        }
    }
}
'''
p.write_text(s)
p=w/'test/Compliance.Tests/Testing/TypeIIRangeFixture.cs';s=p.read_text().replace('public Task<Result> CancelAsync(', 'public Task<Result<UnitResult>> CancelAsync(');p.write_text(s)
p=w/'test/Compliance.Tests/Features/Operations/TypeIIRangeTransportTests.cs';s=p.read_text();s=s.replace('''        Assert.True(canceled.IsSuccessStatusCode, await canceled.Content.ReadAsStringAsync());
        Assert.True(retried.IsSuccessStatusCode);''','''        Assert.Equal(HttpStatusCode.OK, canceled.StatusCode);
        Assert.Equal("{}", await canceled.Content.ReadAsStringAsync());
        Assert.Equal(HttpStatusCode.OK, retried.StatusCode);''');p.write_text(s)
print('All period immediate-Unit producers include typed results; cancellation now freezes its original result envelope inside preparation')
