from pathlib import Path
import re
w=Path('/tmp/compliance-typeii-period-prepared/work');op=w/'src/Compliance.Core/Features/Operations'
p=op/'TypeIIPeriodOperations.cs';s=p.read_text().replace('descriptor.StatusCode','descriptor.HttpStatus')
s=s.replace('            var descriptor = accepted.Value switch','            if (!accepted.IsSuccess)\n                return Result<UnitResult>.Failure(accepted.Error!);\n            var descriptor = accepted.Value switch')
s=s.replace('            if (!accepted.IsSuccess)\n                return Result<UnitResult>.Failure(accepted.Error!);\n            if (descriptor is null)','            if (descriptor is null)')
p.write_text(s)
p=op/'TypeIIPeriodRules.cs';s=p.read_text();s=re.sub(r'        if \(DomainEventPayload.Size\(fact\) > MaximumEventBytes\)\n            return Invalid\("The complete Type II period state exceeds the bounded event payload\."\);\n','',s);p.write_text(s)
p=op/'StartTypeIIObservationPeriodHandler.cs';s=p.read_text()
s=s.replace('        var snapshot = await reader.HydrateAsync(new TypeIIPeriod(request.TenantId, request.ProgramId,\n            request.PeriodId, request.PeriodId), ct).ConfigureAwait(false);','        var snapshot = new TypeIIPeriod(request.TenantId, request.ProgramId, request.PeriodId);')
a=s.index('        // A logical id');b=s.index('        return await TypeIIRangeContent.AcknowledgmentAsync',a)
s=s[:a]+'''        ImmutableContentRef? intent = null;
        var sequence = 0L;
        var position = 0UL;
        var outcome = await operations.ExecuteAsync(new NativeOperation<TypeIIPeriod>(binding,
            () => new TypeIIPeriod(request.TenantId, request.ProgramId, request.PeriodId, request.PeriodId),
            period => period.Acceptance,
            async (period, token) =>
            {
                var guard = period.PrepareOpeningAcceptance();
                if (!guard.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(guard.Error!);
                var rules = new TypeIIPeriodRules(request.TenantId, request.ProgramId, request.PeriodId);
                var frozen = await FreezeAsync(request, rules, provenance, actorMemberId, actorDisplay, now, token).ConfigureAwait(false);
                if (!frozen.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(frozen.Error!);
                intent = frozen.Value.Intent;
                sequence = period.NativeSequence;
                position = period.CommittedStreamPosition;
                return Result<FirstResponseDescriptor>.Success(frozen.Value.Response);
            }, (TypeIIPeriod period, ImmutableContentRef acknowledgment) =>
                period.AtCut(sequence, position) is { IsSuccess: false } changed ? changed :
                period.AcceptOpening(provenance, intent!, acknowledgment)), context, ct).ConfigureAwait(false);
'''+s[b:]
s=s.replace('StartTypeIIObservationPeriod request, TypeIIPeriod period','StartTypeIIObservationPeriod request, TypeIIPeriodRules period')
a=s.index('    static Result<FirstResponseDescriptor> Prepare(');b=s.index('    static bool Approved(',a);s=s[:a]+s[b:]
p.write_text(s)
p=op/'AmendTypeIIObservationPeriodHandler.cs';s=p.read_text().replace('Handler(NativeOperationExecutor operations, IAggregateReader reader,','Handler(NativeOperationExecutor operations, IAggregateReader reader, TypeIIPeriodReader periods,')
s=s.replace('        var snapshot = await reader.HydrateAsync(new TypeIIPeriod(request.TenantId, request.ProgramId,\n            request.PeriodId, request.CommandId), ct).ConfigureAwait(false);','        var snapshot = new TypeIIPeriod(request.TenantId, request.ProgramId, request.PeriodId);')
a=s.index('        // A logical id');b=s.index('        return await TypeIIRangeContent.AcknowledgmentAsync',a)
s=s[:a]+'''        ImmutableContentRef? intent = null;
        var sequence = 0L;
        var position = 0UL;
        var outcome = await operations.ExecuteAsync(new NativeOperation<TypeIIPeriod>(binding,
            () => new TypeIIPeriod(request.TenantId, request.ProgramId, request.PeriodId, request.CommandId),
            period => period.Acceptance,
            async (period, token) =>
            {
                var read = await periods.ReadAsync(period, token).ConfigureAwait(false);
                var frozen = await FreezeAsync(request, read, provenance, actorMemberId, actorDisplay, now, token).ConfigureAwait(false);
                if (!frozen.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(frozen.Error!);
                intent = frozen.Value.Intent;
                sequence = period.NativeSequence;
                position = period.CommittedStreamPosition;
                return Result<FirstResponseDescriptor>.Success(frozen.Value.Response);
            }, (TypeIIPeriod period, ImmutableContentRef acknowledgment) =>
                period.AtCut(sequence, position) is { IsSuccess: false } changed ? changed :
                period.AcceptAmendment(request.ExpectedRevision, provenance, intent!, acknowledgment)), context, ct).ConfigureAwait(false);
'''+s[b:]
s=s.replace('        TypeIIPeriod period, OperationProvenance provenance,','        TypeIIPeriodReadSnapshot period, OperationProvenance provenance,')
s=s.replace('period.Current','period.View').replace('period.PendingOperationId','period.Owner.PendingOperationId').replace('period.PrepareAmendment','period.Rules.PrepareAmendment').replace('period.CalendarAuthorization','period.Owner.CalendarAuthorization').replace('period.Stream','period.Owner.Stream')
a=s.index('    static Result<FirstResponseDescriptor> Prepare(');b=s.index('    static Result<(ImmutableContentRef, FirstResponseDescriptor, TypeIIPeriodCalendarAuthorization)> Fail(',a);s=s[:a]+s[b:]
# Earlier scalar native owner lambda must keep owner method calls; only helper content uses read composition.
s=s.replace('period.Owner.Stream', 'period.Owner.Stream')
p.write_text(s)
p=op/'TypeIIPeriod.cs';s=p.read_text();idx=s.index('    /// <summary>Rechecks')
s=s[:idx]+'''    public Result AtCut(long nativeSequence, ulong physicalPosition) => NativeSequence == nativeSequence &&
        CommittedStreamPosition == physicalPosition ? Result.Success : Failure("The exact period preparation cut changed.", true);

'''+s[idx:];s=s.replace('Settle(started.Operation, started.Change','Settle(started.Change').replace('Settle(amended.Operation, amended.Change','Settle(amended.Change').replace('void Settle(OperationProvenance operation, ImmutableContentRef intent','void Settle(ImmutableContentRef intent');p.write_text(s)
print('Opening/amendment guards and source freezing moved inside native Prepare')
