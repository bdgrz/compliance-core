from pathlib import Path
import re
r=Path('/tmp/compliance-typeii-period-prepared');w=r/'work';test=w/'test/Compliance.Tests'
# Standalone persisted period fixtures use transient rules and explicit native publication.
for rel,content in [
 ('Features/AuditPackages/CreateAuditPackageHandlerTests.cs','ContentStore'),
 ('Features/AuditPopulations/DefineAuditPopulationHandlerTests.cs','PeriodContent'),
 ('Features/SystemDescription/SystemDescriptionDraftCommandHandlerTests.cs','PeriodContent'),
 ('Features/Programs/ProposeProgramRolloverHandlerTests.cs','PeriodContent')]:
 p=test/rel;s=p.read_text().replace('using TypeIIPeriodAggregate = Bdgrz.Compliance.Features.Operations.TypeIIPeriod;', 'using TypeIIPeriodAggregate = Bdgrz.Compliance.Features.Operations.TypeIIPeriodRules;')
 s=s.replace('new TypeIIPeriod(TenantId, ProgramId, PeriodId)', 'new TypeIIPeriodRules(TenantId, ProgramId, PeriodId)')
 s=s.replace('await Writer.SaveAsync(period, new RequestDispatchContext(RequestActor.System));',f'await TypeIIPeriodSeeds.WriteAsync(Writer, {content}, period);')
 p.write_text(s)
# Shared command fixture: real native opening publication, followed by the matching calendar permit.
p=test/'Features/Operations/TypeIIPeriodCommandHandlerTests.cs';s=p.read_text()
s=s.replace('public IDomainEventReader Events => Host.Events;', 'public IDomainEventReader Events => Host.Events;\n        public TypeIIPeriodReader Periods => Host.Periods;')
s=s.replace('''            new(Executor, new ManagementExecutiveAuthority(Reader,
                new ExecutivePermissions(permissions)), CloseClock);''','''            new(Host.PeriodOperations(CloseClock), new ManagementExecutiveAuthority(Reader,
                new ExecutivePermissions(permissions)));''')
s=s.replace('''            new(Executor, Reader, new ManagementExecutiveAuthority(Reader,
                new ExecutivePermissions(permissions)), new TypeIIOccurrenceCoverage(Reader, Host.Content),
                CloseClock);''','''            new(Host.PeriodOperations(CloseClock), new ManagementExecutiveAuthority(Reader,
                new ExecutivePermissions(permissions)), new TypeIIOccurrenceCoverage(Reader, Host.Content));''')
a=s.index('            var period = new TypeIIPeriod(TenantId, ProgramId, PeriodId);',s.index('public async Task SeedStartedPeriodAsync'))
b=s.index('            // The calendar holds',a)
s=s[:a]+'''            var period = new TypeIIPeriodRules(TenantId, ProgramId, PeriodId);
            Assert.Null(period.Start(plan.Current!, Opening(), ProposerMemberId, "Compliance lead", StartedAt));
            await TypeIIPeriodSeeds.WriteAsync(Writer, Host.Content, period);
            var persisted = await Reader.HydrateAsync(new TypeIIPeriod(TenantId, ProgramId, PeriodId));
            var intent = persisted.CalendarIntent!;
            var calendar = new TypeIIObservationCalendar(TenantId, ProgramId);

'''+s[b:]
# All command identities are now explicitly authored and replayed unchanged by the same request variable.
s=s.replace('new ApproveTypeIIPeriodClose(', 'new ApproveTypeIIPeriodClose(Uuid.CreateVersion4(), ')
s=s.replace('new FreezeTypeIIPeriodClose(', 'new FreezeTypeIIPeriodClose(Uuid.CreateVersion4(), ')
# Existing seed methods continue to exercise rules, but persistence is native and immutable.
s=s.replace('var period = await Reader.HydrateAsync(new TypeIIPeriod(TenantId, ProgramId, PeriodId));',
 'var period = (await Periods.ReadAsync(TenantId, ProgramId, PeriodId)).Rules;')
s=s.replace('await Writer.SaveAsync(period, new RequestDispatchContext(RequestActor.System));',
 'await TypeIIPeriodSeeds.AppendAsync(Reader, Writer, Host.Content, period);')
# Assertion reads use the explicit composition. Matching regex is restricted to fixture period owner hydrations.
s=re.sub(r'await fixture.Reader.HydrateAsync\(new TypeIIPeriod\((.*?)\)\)',r'await fixture.Periods.ReadAsync(\1)',s,flags=re.S)
# The pattern cannot cross a semicolon; verify rather than risk a broad replacement silently swallowing code.
assert all(len(m)<500 for m in re.findall(r'fixture.Periods.ReadAsync\((.*?)\)',s,re.S))
# Period view reads; avoid changing unrelated plan/member projections.
for name in ['saved','period','pending']:
 s=s.replace(name+'.Current',name+'.View')
# The fixture's transient rules still expose Current.
start=s.index('    sealed partial class Fixture') if '    sealed partial class Fixture' in s else s.index('    sealed class Fixture')
pre,fixture=s[:start],s[start:];fixture=fixture.replace('period.View','period.Current');s=pre+fixture
p.write_text(s)
# Original opening-handler tests now compose immutable period views; close seeding is explicit.
p=test/'Features/Operations/StartTypeIIObservationPeriodHandlerTests.cs';s=p.read_text()
s=s.replace('public IAggregateWriter Writer => Host.Writer;', 'public IAggregateWriter Writer => Host.Writer;\n        public TypeIIPeriodReader Periods => Host.Periods;')
s=re.sub(r'await fixture.Reader.HydrateAsync\(new TypeIIPeriod\((.*?)\)\)',r'await fixture.Periods.ReadAsync(\1)',s,flags=re.S)
for name in ['saved','accepted','second','stillBlocked']:s=s.replace(name+'.Current',name+'.View')
s=s.replace('var period = await Reader.HydrateAsync(new TypeIIPeriod(TenantId, ProgramId, PeriodId));',
 'var period = (await Periods.ReadAsync(TenantId, ProgramId, PeriodId)).Rules;')
s=s.replace('await Writer.SaveAsync(period, new RequestDispatchContext(RequestActor.System));',
 'await TypeIIPeriodSeeds.AppendAsync(Reader, Writer, Host.Content, period);')
p.write_text(s)
# Range assertions retain native terminal facts in the composition, while full state is View.
for rel in ['Features/Operations/TypeIIRangeProcessTests.cs','Features/Operations/TypeIIRangeTransportTests.cs']:
 p=test/rel;s=p.read_text().replace('.Current','.View');p.write_text(s)
print('Persisted fixture seeds and original period/range command acceptance reads migrated')
