from pathlib import Path
w=Path('/tmp/compliance-typeii-period-prepared/work');op=w/'src/Compliance.Core/Features/Operations'
(op/'TypeIIPeriodMutationContent.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Exact immutable close mutation binding the first owner, original command, prior authority and resulting body.</summary>
public sealed record TypeIIPeriodMutationContent(DurableIntentHeader Header, string Kind,
    string? BeforeSha256, ImmutableContentRef After)
{
    public const string Schema = "type-ii-period-mutation.v1";
}
''')
(op/'FrozenTypeIIPeriodMutation.cs').write_text('''using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Transient prepared append; full views never enter the command owner's retained state.</summary>
public sealed record FrozenTypeIIPeriodMutation(TypeIIPeriodView? Before, TypeIIPeriodView After,
    DomainEvent RuleMutation, ImmutableContentRef CurrentContent, ImmutableContentRef? Change);
''')
(op/'TypeIIPeriodContent.cs').write_text('''using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Immutable period bodies and compact native fact construction over exact prepared rules.</summary>
public static class TypeIIPeriodContent
{
    public const string StateSchema = "type-ii-period-state.v1";

    public static TypeIIPeriodAuthorityHeader Header(TypeIIPeriodView view)
    {
        var validation = view.CloseValidation;
        var approval = view.CloseApprovals.Count == 0 ? null : view.CloseApprovals[^1];
        var close = view.CloseSnapshots.Count == 0 ? null : view.CloseSnapshots[^1];
        return new TypeIIPeriodAuthorityHeader(view.TenantId, view.ProgramId, view.PeriodId, view.Revision,
            view.Status, view.ExaminationId, view.TypeIIPlanId, view.TypeIIPlanVersion, view.TypeIIPlanContentSha256,
            view.PeriodStart, view.PeriodEnd, view.OpeningSnapshotId, view.OpeningSnapshotSha256,
            view.ExpectedOccurrences.Count, ContentDigest.OfJson(view.ExpectedOccurrences),
            validation is null ? null : ContentDigest.OfJson(validation), validation?.Status, validation?.ValidatorMemberId, validation?.ValidatedAt,
            approval is null ? null : ContentDigest.OfJson(approval), approval?.ApprovedByMemberId, approval?.ApproverRole, approval?.ApprovedAt,
            view.CloseSnapshots.Count, close?.CloseSnapshotId, close?.Version,
            close is null ? null : ContentDigest.OfJson(close), close?.ActorMemberId, close?.ActorRole,
            close?.OriginalExpectedRevision, view.ActorMemberId, view.UpdatedAt);
    }

    public static async ValueTask<FrozenTypeIIPeriodMutation> FreezeAsync(IImmutableContentStore store,
        TypeIIPeriodView? before, TypeIIPeriodRules rules, OperationProvenance operation, CancellationToken ct)
    {
        var after = rules.Current ?? throw new InvalidOperationException("A period mutation requires its complete verified result.");
        var mutations = rules.PendingChanges;
        if (mutations.Count != 1)
            throw new InvalidOperationException("One native period append requires exactly one prepared rule mutation.");
        var body = await store.WriteJsonAsync(operation.Owner.Realm, Uuid.CreateVersion4(), StateSchema, after, ct).ConfigureAwait(false);
        var rule = mutations[0];
        ImmutableContentRef? change = rule switch
        {
            ObservationPeriodStartedBody started => started.Change,
            ObservationPeriodAmendedBody amended => amended.Change,
            ObservationPeriodCloseProposedBody validation => validation.Change,
            DueControlOccurrencesGenerated => null,
            _ => await store.WriteJsonAsync(operation.Owner.Realm, Uuid.CreateVersion4(), TypeIIPeriodMutationContent.Schema,
                new TypeIIPeriodMutationContent(new DurableIntentHeader(operation.RootOperationId, operation.Owner,
                    operation.AffectedOwner, operation.ExpectedRevisionOwner, operation.Actor, operation.Episode,
                    operation.OriginalExpectedRevision, operation.AuthoredIntentSha256, operation.AcceptedAt),
                    operation.CommandKind, before is null ? null : ContentDigest.OfJson(before), body), ct).ConfigureAwait(false),
        };
        return new FrozenTypeIIPeriodMutation(before, after, rule, body, change);
    }

    public static DomainEvent Fact(FrozenTypeIIPeriodMutation prepared, OperationProvenance operation,
        ImmutableContentRef? firstResponse, ImmutableContentRef operationResult, long sequence,
        ImmutableContentRef? calendarIntent = null)
    {
        var state = prepared.After;
        var header = Header(state);
        var current = prepared.CurrentContent;
        var change = prepared.Change;
        return prepared.RuleMutation switch
        {
            ObservationPeriodStartedBody started => new ObservationPeriodStarted(state.TenantId, state.PeriodId,
                state.Revision, started.ActorMemberId, change!, started.OccurredAt, operation, started.CalendarAuthorizationId,
                started.CalendarGeneration, firstResponse, operationResult, sequence, header, current),
            ObservationPeriodAmendedBody amended => new ObservationPeriodAmended(state.TenantId, state.PeriodId,
                state.Revision, amended.ActorMemberId, change!, amended.OccurredAt, operation, amended.CalendarAuthorizationId,
                amended.CalendarGeneration, firstResponse, operationResult, sequence, header, current),
            ObservationPeriodCloseProposedBody validation => new ObservationPeriodCloseProposed(state.TenantId, state.PeriodId,
                state.Revision, validation.ActorMemberId, change!, validation.OccurredAt, operation, firstResponse,
                operationResult, sequence, header, current),
            TypeIIPeriodCloseApprovedBody approved => new TypeIIPeriodCloseApproved(state.TenantId, state.PeriodId,
                state.Revision, approved.ActorMemberId, change!, approved.OccurredAt, operation, firstResponse,
                operationResult, sequence, header, current),
            ObservationPeriodCloseFrozenBody frozen => new ObservationPeriodCloseFrozen(state.TenantId, state.PeriodId,
                state.Revision, frozen.ActorMemberId, change!, frozen.OccurredAt, operation, frozen.CalendarAuthorizationId,
                frozen.CalendarGeneration, firstResponse, operationResult, sequence, header, current,
                calendarIntent ?? throw new InvalidOperationException("A close freeze requires the exact admitted calendar intent.")),
            TypeIIPeriodCloseAmendedBody amended => new TypeIIPeriodCloseAmended(state.TenantId, state.PeriodId,
                state.Revision, amended.ActorMemberId, change!, amended.OccurredAt, operation, firstResponse,
                operationResult, sequence, header, current),
            DueControlOccurrencesGenerated generated => generated with
            {
                NativeSequence = sequence, Header = header, CurrentContent = current,
                FirstResponse = firstResponse, OperationResult = operationResult,
            },
            _ => throw new InvalidOperationException("The period mutation has another native fact kind."),
        };
    }

    public static string Transition(DomainEvent value) => value switch
    {
        ObservationPeriodStarted => "start", ObservationPeriodAmended => "period_amendment",
        DueControlOccurrencesGenerated => "generation", ObservationPeriodCloseProposed => "validation",
        TypeIIPeriodCloseApproved => "approval", ObservationPeriodCloseFrozen => "freeze",
        TypeIIPeriodCloseAmended => "close_amendment",
        _ => throw new InvalidOperationException("The period mutation has another transition kind."),
    };

    public static bool SameGenerationState(TypeIIPeriodView before, TypeIIPeriodView after) =>
        after.Revision == before.Revision + 1 && ContentDigest.OfJson(before with { Revision = after.Revision }) == ContentDigest.OfJson(after);

    internal static DomainEvent Body(DomainEvent value, TypeIIPeriodView state) => value switch
    {
        ObservationPeriodStarted started => new ObservationPeriodStartedBody(started.TenantId, started.SubjectId,
            started.Revision, started.ActorMemberId, state, started.OccurredAt, started.Change, started.Operation,
            started.CalendarAuthorizationId, started.CalendarGeneration, started.FirstResponse, started.OperationResult),
        ObservationPeriodAmended amended => new ObservationPeriodAmendedBody(amended.TenantId, amended.SubjectId,
            amended.Revision, amended.ActorMemberId, state, amended.OccurredAt, amended.Change, amended.Operation,
            amended.CalendarAuthorizationId, amended.CalendarGeneration, amended.FirstResponse, amended.OperationResult),
        ObservationPeriodCloseProposed validation => new ObservationPeriodCloseProposedBody(validation.TenantId,
            validation.SubjectId, validation.Revision, validation.ActorMemberId, state, validation.OccurredAt,
            validation.Change, validation.Operation, validation.FirstResponse, validation.OperationResult),
        TypeIIPeriodCloseApproved approved => new TypeIIPeriodCloseApprovedBody(approved.TenantId,
            approved.SubjectId, approved.Revision, approved.ActorMemberId, state, approved.OccurredAt),
        ObservationPeriodCloseFrozen frozen => new ObservationPeriodCloseFrozenBody(frozen.TenantId,
            frozen.SubjectId, frozen.Revision, frozen.ActorMemberId, state, frozen.OccurredAt,
            frozen.CalendarAuthorizationId, frozen.CalendarGeneration),
        TypeIIPeriodCloseAmended amended => new TypeIIPeriodCloseAmendedBody(amended.TenantId,
            amended.SubjectId, amended.Revision, amended.ActorMemberId, state, amended.OccurredAt),
        DueControlOccurrencesGenerated generated => generated,
        _ => throw new ImmutableContentIntegrityException("The period source has another immutable body kind."),
    };
}
''')
(op/'TypeIIPeriodReadSnapshot.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Verified immutable read composition at the hydrated owner's exact native sequence.</summary>
public sealed class TypeIIPeriodReadSnapshot(TypeIIPeriod owner, TypeIIPeriodRules rules,
    IReadOnlyList<DomainEvent> facts)
{
    public TypeIIPeriod Owner { get; } = owner;
    public TypeIIPeriodRules Rules { get; } = rules;
    public TypeIIPeriodView? View => Rules.Current;
    public IReadOnlyList<DueControlOccurrencesGenerated> OccurrenceGenerations => Rules.OccurrenceGenerations;
    public DomainEvent? AcceptedFor(Uuid operationId) => facts.FirstOrDefault(value => value switch
    {
        TypeIIPeriodOpeningAccepted opening => opening.Operation.RootOperationId == operationId,
        TypeIIPeriodAmendmentAccepted amendment => amendment.Operation.RootOperationId == operationId,
        _ => false,
    });
    public DomainEvent? TerminalFor(Uuid operationId) => facts.FirstOrDefault(value => value is
        ObservationPeriodStarted or ObservationPeriodAmended or TypeIIPeriodOpeningRejected or TypeIIPeriodAmendmentCanceled &&
        value is Bdgrz.Compliance.Features.NativeOperations.INativeOperationFact fact && fact.Operation.RootOperationId == operationId);
    public DomainEvent? FactById(Uuid eventId) => facts.FirstOrDefault(value => value.Metadata?.EventId == eventId);
}
''')
(op/'TypeIIPeriodReader.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Reconstructs verified complete period views from immutable bodies; command hydration retains bounded authority.</summary>
public sealed class TypeIIPeriodReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async ValueTask<TypeIIPeriodReadSnapshot> ReadAsync(Uuid tenantId, Uuid programId, Uuid periodId,
        CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new TypeIIPeriod(tenantId, programId, periodId), ct).ConfigureAwait(false);
        return await ReadAsync(owner, ct).ConfigureAwait(false);
    }

    public async ValueTask<TypeIIPeriodReadSnapshot> ReadAsync(TypeIIPeriod owner, CancellationToken ct = default)
    {
        var rules = new TypeIIPeriodRules(owner.TenantId, owner.ProgramId, owner.Id);
        var facts = new List<DomainEvent>();
        if (owner.NativeSequence == 0)
            return new TypeIIPeriodReadSnapshot(owner, rules, facts.AsReadOnly());
        var sequence = 0L;
        ITypeIIPeriodStateFact? latest = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(owner.Stream.Realm,
            TypeIIPeriod.Area, owner.Id.ToString()), EventCursor.Start, ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit)
                continue;
            var value = record.Event;
            if (value is ITypeIIPeriodStateFact fact)
            {
                if (fact.NativeSequence != sequence + 1 || fact.CurrentContent.Schema != TypeIIPeriodContent.StateSchema)
                    throw new ImmutableContentIntegrityException("The period's immutable source has another exact native sequence.");
                var state = await content.ReadJsonAsync<TypeIIPeriodView>(owner.Stream.Realm, fact.CurrentContent, ct).ConfigureAwait(false);
                if (TypeIIPeriodContent.Header(state) != fact.Header || ContentDigest.OfJson(state) != fact.CurrentContent.Sha256)
                    throw new ImmutableContentIntegrityException("The period's immutable body differs from its compact native authority.");
                rules.Apply(TypeIIPeriodContent.Body(value, state));
                if (rules.Current is not { } folded || ContentDigest.OfJson(folded) != fact.CurrentContent.Sha256)
                    throw new ImmutableContentIntegrityException("The period's immutable body does not follow its accepted local transition.");
                latest = fact;
            }
            else if (value is TypeIIPeriodOpeningAccepted or TypeIIPeriodAmendmentAccepted or
                TypeIIPeriodOpeningRejected or TypeIIPeriodAmendmentCanceled)
                rules.Apply(value);
            else
                throw new ImmutableContentIntegrityException("The period source has another native fact kind.");
            facts.Add(value);
            sequence++;
            if (sequence == owner.NativeSequence)
                break;
        }
        if (sequence != owner.NativeSequence)
            throw new ImmutableContentUnavailableException("The exact period source cut is not visible yet.");
        if (latest?.Header != owner.Header || latest?.CurrentContent != owner.CurrentContent)
            throw new ImmutableContentIntegrityException("The composed period differs from the hydrated owner's exact native authority.");
        rules.ClearPendingChanges();
        return new TypeIIPeriodReadSnapshot(owner, rules, facts.AsReadOnly());
    }
}
''')
print('Period content factory and exact-cut read composition prepared')
