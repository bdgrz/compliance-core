from pathlib import Path
import shutil
r=Path('/tmp/compliance-typeii-period-prepared');w=r/'work';op=w/'src/Compliance.Core/Features/Operations';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
rel=Path('src/Compliance.Common/Features/AuditPopulations/ObservationPeriodCloseView.cs')
for d in ['base','work']:
 p=r/d/rel
 if not p.exists():shutil.copy2(repo/rel,p)
(w/rel).write_text('''using Bdgrz.Compliance.Features.Operations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPopulations;

/// <summary>The exact requested frozen close and its retained immutable lineage on the owning period.</summary>
public sealed record ObservationPeriodCloseView(Uuid TenantId, Uuid ProgramId, Uuid ObservationPeriodCloseId,
    Uuid PeriodId, Uuid ExaminationId, TypeIIPeriodCloseSnapshotView Snapshot,
    IReadOnlyList<TypeIIPeriodCloseSnapshotView> CloseSnapshots);
''')
(op/'ObservationPeriodCloseIdentity.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Read-only scoped locator; the same close id on different periods is retained as an explicit ambiguity.</summary>
public sealed record ObservationPeriodCloseIdentity(Uuid TenantId, Uuid ProgramId, Uuid CloseId, Uuid PeriodId,
    int Version, long PeriodRevision, string SnapshotSha256, NativeFactReference Source);
''')
(op/'IObservationPeriodCloseDirectoryReader.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Bounded identity discovery only; a locator never establishes global mutation authority.</summary>
public interface IObservationPeriodCloseDirectoryReader
{
    ValueTask<IReadOnlyList<ObservationPeriodCloseIdentity>> FindAsync(Uuid tenantId, Uuid programId, Uuid closeId,
        CancellationToken ct = default);
}
''')
p=op/'ObservationPeriodDirectorySchema.cs';s=p.read_text();idx=s.rindex('}')
s=s[:idx]+'''    public readonly record struct CloseKey(Uuid CloseId, Uuid PeriodId);
    public static readonly KvDirectoryIndex<ObservationPeriodCloseIdentity> ByProgramClose = new(
        "by_program_close", 1, static close => [close.ProgramId.ToString(), close.CloseId.ToString(), close.PeriodId.ToString()]);
    public static readonly KvDirectory<ObservationPeriodCloseIdentity, CloseKey> Closes = new("closes",
        ComplianceCoreJsonContext.Default.ObservationPeriodCloseIdentity, static close => new CloseKey(close.CloseId, close.PeriodId),
        static key => [key.CloseId.ToString(), key.PeriodId.ToString()], [ByProgramClose]);
'''+s[idx:];p.write_text(s)
p=op/'FitzObservationPeriodDirectory.cs';s=p.read_text().replace('using Cntryl.Fitz;', 'using Cntryl.Fitz;\nusing Bdgrz.Compliance.Features.AuditPopulations;\nusing Bdgrz.Compliance.Features.NativeOperations;')
s=s.replace('IObservationPeriodDirectoryReader, IObservationPeriodDirectoryProjection','IObservationPeriodDirectoryReader, IObservationPeriodCloseDirectoryReader, IObservationPeriodDirectoryProjection')
idx=s.index('    public async ValueTask<Page<ObservationPeriodIdentity>> ListProgramAsync')
s=s[:idx]+'''    public ValueTask ApplyAsync(ObservationPeriodCloseFrozen fact, CancellationToken ct = default) => CloseAsync(fact, fact, ct);
    public ValueTask ApplyAsync(TypeIIPeriodCloseAmended fact, CancellationToken ct = default) => CloseAsync(fact, fact, ct);

    async ValueTask CloseAsync(DomainEvent value, ITypeIIPeriodStateFact fact, CancellationToken ct)
    {
        var header = fact.Header;
        if (header.TenantId != fact.TenantId || header.PeriodId != fact.SubjectId || header.ProgramId == Uuid.Empty ||
            header.Status != "closed" || header.LatestCloseSnapshotId is not { } close || close == Uuid.Empty ||
            header.LatestCloseVersion is not > 0 || header.LatestCloseSha256 is not { Length: 64 } digest ||
            fact.Operation.Owner != new TypeIIPeriod(fact.TenantId, header.ProgramId, fact.SubjectId).Stream)
            throw new InvalidOperationException("A close locator requires its exact native period authority.");
        var identity = new ObservationPeriodCloseIdentity(fact.TenantId, header.ProgramId, close, fact.SubjectId,
            header.LatestCloseVersion.Value, fact.Revision, digest, NativeFactReference.Of(fact.Operation.Owner, value));
        var current = await ObservationPeriodDirectorySchema.Closes.GetAsync(Transaction,
            new ObservationPeriodDirectorySchema.CloseKey(close, fact.SubjectId), ct).ConfigureAwait(false);
        if (current is not null)
        {
            if (current != identity)
                throw new InvalidOperationException("A close locator cannot change its original scoped native source.");
            return;
        }
        await ObservationPeriodDirectorySchema.Closes.InsertAsync(Transaction, identity, ct).ConfigureAwait(false);
    }

    public async ValueTask<IReadOnlyList<ObservationPeriodCloseIdentity>> FindAsync(Uuid tenantId, Uuid programId,
        Uuid closeId, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        var values = await ObservationPeriodDirectorySchema.Closes.QueryAsync(tx,
            ObservationPeriodDirectorySchema.ByProgramClose.Query().WithPrefix(programId.ToString(), closeId.ToString())
                .Take(2), ct).ConfigureAwait(false);
        return values.Items;
    }

'''+s[idx:];p.write_text(s)
p=op/'IObservationPeriodDirectoryProjection.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.AuditPopulations;\n'+s;s=s.replace('    ValueTask ApplyAsync(ObservationPeriodStarted fact, CancellationToken ct = default);','''    ValueTask ApplyAsync(ObservationPeriodStarted fact, CancellationToken ct = default);
    ValueTask ApplyAsync(ObservationPeriodCloseFrozen fact, CancellationToken ct = default);
    ValueTask ApplyAsync(TypeIIPeriodCloseAmended fact, CancellationToken ct = default);''');p.write_text(s)
p=op/'ObservationPeriodDirectoryProjector.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.AuditPopulations;\n'+s;s=s.replace('IProjectorHandler<ObservationPeriodStarted>', 'IProjectorHandler<ObservationPeriodStarted>, IProjectorHandler<ObservationPeriodCloseFrozen>, IProjectorHandler<TypeIIPeriodCloseAmended>')
idx=s.rindex('}');s=s[:idx]+'''    public ValueTask HandleAsync(ObservationPeriodCloseFrozen fact, IProjectorContext context, CancellationToken ct) => projection.ApplyAsync(fact, ct);
    public ValueTask HandleAsync(TypeIIPeriodCloseAmended fact, IProjectorContext context, CancellationToken ct) => projection.ApplyAsync(fact, ct);
'''+s[idx:];p.write_text(s)
(op/'GetObservationPeriodCloseHandler.cs').write_text('''using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Resolves one unambiguous scoped historical close from native identity discovery and exact source-backed period lineage.</summary>
public sealed class GetObservationPeriodCloseHandler(IObservationPeriodCloseDirectoryReader directory,
    ObservationPeriodDirectoryReadConsistency consistency, TypeIIPeriodReader periods)
    : IRequestHandler<GetObservationPeriodClose, ObservationPeriodCloseView>
{
    public async ValueTask<Result<ObservationPeriodCloseView>> HandleAsync(IRequestContext<GetObservationPeriodClose> context, CancellationToken ct)
    {
        var request = context.Request;
        var fence = await consistency.CaptureAsync(request.TenantId, ct).ConfigureAwait(false);
        if (!fence.IsSuccess)
            return Result<ObservationPeriodCloseView>.Failure(fence.Error!);
        var identities = await directory.FindAsync(request.TenantId, request.ProgramId, request.ObservationPeriodCloseId, ct).ConfigureAwait(false);
        if (identities.Any(row => row.TenantId != request.TenantId || row.ProgramId != request.ProgramId || row.CloseId != request.ObservationPeriodCloseId))
            return Conflict("The close directory contains another tenant, program or close identity.");
        if (identities.Count > 1)
            return Conflict("The close identity is ambiguous across periods in this program.");
        Result<ObservationPeriodCloseView> result;
        if (identities.Count == 0)
            result = Result<ObservationPeriodCloseView>.Failure(new RequestError(RequestErrorKind.NotFound, "The frozen close was not found in this program."));
        else
        {
            var identity = identities[0];
            var read = await periods.TryReadAsync(request.TenantId, request.ProgramId, identity.PeriodId, ct).ConfigureAwait(false);
            if (!read.IsSuccess)
                return Result<ObservationPeriodCloseView>.Failure(read.Error!);
            var state = read.Value.View;
            var snapshot = state?.CloseSnapshots.SingleOrDefault(close => close.CloseSnapshotId == identity.CloseId);
            var fact = read.Value.FactById(identity.Source.EventId) as ITypeIIPeriodStateFact;
            if (state is null || snapshot is null || fact is null)
                return Conflict("The exact native close source is not visible yet.", true);
            if (identity.Source.Stream != read.Value.Stream || fact.Header.ProgramId != request.ProgramId ||
                fact.Header.LatestCloseSnapshotId != identity.CloseId || fact.Header.LatestCloseVersion != identity.Version ||
                fact.Revision != identity.PeriodRevision || snapshot.Version != identity.Version ||
                ContentDigest.OfJson(snapshot) != identity.SnapshotSha256 ||
                read.Value.FactById(identity.Source.EventId)!.Metadata!.AggregateVersion != identity.Source.AggregateVersion)
                return Conflict("The close locator differs from its exact authoritative historical snapshot.");
            result = Result<ObservationPeriodCloseView>.Success(new ObservationPeriodCloseView(request.TenantId, request.ProgramId,
                identity.CloseId, state.PeriodId, state.ExaminationId, snapshot, state.CloseSnapshots));
        }
        var confirmed = await consistency.ConfirmUnchangedAndCaughtUpAsync(request.TenantId, fence.Value, ct).ConfigureAwait(false);
        return confirmed.IsSuccess ? result : Result<ObservationPeriodCloseView>.Failure(confirmed.Error!);
    }
    static Result<ObservationPeriodCloseView> Conflict(string message, bool transient = false) =>
        Result<ObservationPeriodCloseView>.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
print('Read-only close locator retains collisions and resolves exact authoritative historical snapshots')
