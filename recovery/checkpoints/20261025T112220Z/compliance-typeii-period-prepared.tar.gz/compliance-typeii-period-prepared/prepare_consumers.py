from pathlib import Path
import shutil,re
root=Path('/tmp/compliance-typeii-period-prepared');w=root/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def get(rel):
 rel=Path(rel)
 for d in ['base','work']:
  p=root/d/rel
  if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,p)
 return w/rel
# Header alone is the complete authority required by an evidence support target.
p=w/'src/Compliance.Core/Features/Evidence/EvidenceSupportTargetSource.cs';s=p.read_text().replace('if (period.Current is not { } current','if (period.Header is not { } current');p.write_text(s)
# Typed failure wrapper keeps missing immutable state pending and corruption permanent at existing Result ports.
p=w/'src/Compliance.Core/Features/Operations/TypeIIPeriodReader.cs';s=p.read_text();idx=s.index('    public async ValueTask<TypeIIPeriodReadSnapshot> ReadAsync')
s=s[:idx]+'''    public async ValueTask<Result<TypeIIPeriodReadSnapshot>> TryReadAsync(Uuid tenantId, Uuid programId, Uuid periodId,
        CancellationToken ct = default)
    {
        try
        {
            return Result<TypeIIPeriodReadSnapshot>.Success(await ReadAsync(tenantId, programId, periodId, ct).ConfigureAwait(false));
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<TypeIIPeriodReadSnapshot>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The period's immutable source body cannot be verified.", exception is ImmutableContentUnavailableException));
        }
    }

'''+s[idx:];p.write_text(s)
# Simple owning handlers with a single scoped period read.
for feature,name,var,ids in [
 ('AuditPopulations','DefineAuditPopulationHandler','period','request.TenantId, request.ProgramId, request.PeriodId'),
 ('Programs','ProposeProgramRolloverHandler','sourcePeriod','request.TenantId, request.ProgramId, request.Content.SourcePeriodId')]:
 p=w/f'src/Compliance.Core/Features/{feature}/{name}.cs';s=p.read_text()
 s=s.replace('IAggregateReader reader, TimeProvider clock)','IAggregateReader reader, TypeIIPeriodReader periods, TimeProvider clock)')
 if name=='DefineAuditPopulationHandler':s=s.replace('IAggregateReader reader, TypeIIPeriodReader periods,','TypeIIPeriodReader periods,')
 pattern=r'        var '+var+r' = await reader.HydrateAsync\(new TypeIIPeriod\([\s\S]*?\), ct\)\.ConfigureAwait\(false\);'
 repl=f'''        var periodRead = await periods.TryReadAsync({ids}, ct).ConfigureAwait(false);
        if (!periodRead.IsSuccess)
            return Result.Failure(periodRead.Error!);
        var {var} = periodRead.Value;'''
 s,n=re.subn(pattern,repl,s,count=1);assert n==1,name
 s=s.replace(var+'.Current',var+'.View');p.write_text(s)
p=w/'src/Compliance.Core/Features/SystemDescription/BindSystemDescriptionSourcesHandler.cs';s=p.read_text().replace('IAggregateExecutor executor, TimeProvider clock)','IAggregateExecutor executor, TypeIIPeriodReader periods, TimeProvider clock)')
s=s.replace('''            var periodAggregate = await reader.HydrateAsync(new TypeIIPeriod(request.TenantId,
                request.ProgramId, periodId), ct);
            var period = periodAggregate.Current;''','''            var periodRead = await periods.TryReadAsync(request.TenantId, request.ProgramId, periodId, ct).ConfigureAwait(false);
            if (!periodRead.IsSuccess)
                return Result.Failure(periodRead.Error!);
            var period = periodRead.Value.View;''');p.write_text(s)
p=w/'src/Compliance.Core/Features/AuditPackages/AuditPackageSourceBuilder.cs';s=p.read_text().replace('Handler(', 'Handler(')
s=s.replace('AuditPackageSourceBuilder(IAggregateReader reader, IImmutableContentStore? content = null)','AuditPackageSourceBuilder(IAggregateReader reader, TypeIIPeriodReader periods, IImmutableContentStore? content = null)')
s=s.replace('''            var period = await reader.HydrateAsync(new TypeIIPeriod(tenantId, programId,
                requested.SourcePeriodId), ct).ConfigureAwait(false);
            if (period.Current''','''            var periodRead = await periods.TryReadAsync(tenantId, programId, requested.SourcePeriodId, ct).ConfigureAwait(false);
            if (!periodRead.IsSuccess)
                return Result<AuditPackageContent>.Failure(periodRead.Error!);
            var period = periodRead.Value;
            if (period.View''');p.write_text(s)
# Assertion's direct Type II source selection and the shared signoff validator use explicit composed reads.
p=w/'src/Compliance.Core/Features/Examinations/RecordManagementAssertionHandler.cs';s=p.read_text()
s=s.replace('AuditPackageReader packages,','AuditPackageReader packages, TypeIIPeriodReader periods,')
s=s.replace('''            var period = await reader.HydrateAsync(new TypeIIPeriod(tenantId, programId,
                content.SourcePeriodId), ct).ConfigureAwait(false);''','''            var periodRead = await periods.TryReadAsync(tenantId, programId, content.SourcePeriodId, ct).ConfigureAwait(false);
            if (!periodRead.IsSuccess)
                return Result<DateTimeOffset>.Failure(periodRead.Error!);
            var period = periodRead.Value;''')
s=s.replace('period.Current','period.View');p.write_text(s)
p=w/'src/Compliance.Core/Features/Examinations/ExaminationSignOffSourceValidator.cs';s=p.read_text().replace('using TypeIIPeriodAggregate = Bdgrz.Compliance.Features.Operations.TypeIIPeriod;\n','')
s=s.replace('AuditPackageReader packages,','AuditPackageReader packages, TypeIIPeriodReader periods,')
# Some private snapshot methods did not previously need the package reader; thread the exact period reader through them.
s=s.replace('ResolveSnapshotAsync(reader,', 'ResolveSnapshotAsync(reader, periods,')
s=s.replace('ResolveSnapshotAsync(IAggregateReader reader,','ResolveSnapshotAsync(IAggregateReader reader, TypeIIPeriodReader periods,')
s=s.replace('''        var period = await reader.HydrateAsync(new TypeIIPeriodAggregate(tenantId, programId,
            sourcePeriodId), ct).ConfigureAwait(false);''','''        var periodRead = await periods.TryReadAsync(tenantId, programId, sourcePeriodId, ct).ConfigureAwait(false);
        if (!periodRead.IsSuccess)
            return Result<SnapshotSources>.Failure(periodRead.Error!);
        var period = periodRead.Value;''')
s=s.replace('period.Current','period.View');p.write_text(s)
for name in ['RecordExaminationOutcomeHandler','RecordManagementRepresentationLetterHandler','RecordManagementReviewHandler']:
 p=get(f'src/Compliance.Core/Features/Examinations/{name}.cs');s=p.read_text()
 if 'using Bdgrz.Compliance.Features.Operations;' not in s:s='using Bdgrz.Compliance.Features.Operations;\n'+s
 s=s.replace('AuditPackageReader packages,','AuditPackageReader packages, TypeIIPeriodReader periods,')
 s=s.replace('ValidateAsync(reader, packages,', 'ValidateAsync(reader, packages, periods,')
 p.write_text(s)
print('External direct period consumers migrated to compact headers or verified composed views')
