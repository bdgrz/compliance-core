from pathlib import Path
import shutil, subprocess, hashlib, json, datetime
r=Path('/tmp/compliance-typeii-period-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
backup=r/('before-main-refresh-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
backup.mkdir()
shutil.copytree(r/'base',backup/'base');shutil.copytree(r/'work',backup/'work')
conflicts=[];changed=[];removed=[]
for b in sorted((r/'base').rglob('*.cs')):
 rel=b.relative_to(r/'base');w=r/'work'/rel;main=repo/rel
 if not main.exists():
  removed.append(str(rel));continue
 if main.read_bytes()==b.read_bytes():continue
 changed.append(str(rel))
 if w.read_bytes()==b.read_bytes():w.write_bytes(main.read_bytes());b.write_bytes(main.read_bytes());continue
 p=subprocess.run(['git','merge-file','-p','-L','stage2','-L','baseline','-L','main',str(w),str(b),str(main)],capture_output=True)
 if p.returncode==0:
  w.write_bytes(p.stdout);b.write_bytes(main.read_bytes())
 else:
  dst=r/'refresh-conflicts'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.stdout)
  conflicts.append(str(rel))
(r/'refresh-report.json').write_text(json.dumps({'backup':str(backup),'main_changed':changed,'conflicts':conflicts,'main_removed':removed},indent=2)+'\n')
print(json.dumps({'changed':len(changed),'conflicts':conflicts,'main_removed':removed},indent=2))
