from pathlib import Path
import shutil
w=Path('/tmp/compliance-typeii-period-prepared/work');root=w.parent;op=w/'src/Compliance.Core/Features/Operations'
p=op/'GenerateDueControlOccurrencesHandler.cs';s=p.read_text()
a=s.index('    const string CommandKind');b=s.index('    async ValueTask<Result<IReadOnlyList<ControlOccurrenceSelection>>> SelectAsync',a)
head='''    public async ValueTask<Result<UnitResult>> HandleAsync(IRequestContext<GenerateDueControlOccurrences> context, CancellationToken ct)
    {
        var request = context.Request;
        if (!ExaminationCommandActor.TryGet(context.Actor, context.Invocation, request.TenantId, out var member, out var display))
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Forbidden, "Recurring occurrence generation requires a personal HTTP actor."));
        var key = request.GenerationKey?.Trim() ?? string.Empty;
        var logicalId = TypeIIPeriod.GenerationLogicalId(request.PeriodId, key);
        return await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PeriodId, logicalId,
            nameof(GenerateDueControlOccurrences), null, async (snapshot, operation, token) =>
            {
                if (snapshot.Rules.PrepareGenerateDueOccurrences(key, request.ThroughDate, member, display, operation.AcceptedAt) is { } invalid)
                    return Result.Failure(invalid.ToRequestError());
                var selected = await SelectAsync(snapshot, request, operation, operation.AcceptedAt, token).ConfigureAwait(false);
                if (!selected.IsSuccess)
                    return Result.Failure(selected.Error!);
                var ids = await ControlOperatingContent.WriteAsync(content, request.TenantId, ControlOperatingContent.OccurrenceIdsSchema,
                    (IReadOnlyList<Uuid>)selected.Value!.Select(selection => selection.OccurrenceId).ToArray(), token).ConfigureAwait(false);
                var intents = await ControlOperatingContent.WriteAsync(content, request.TenantId, ControlOccurrenceSelectionManifest.Schema,
                    new ControlOccurrenceSelectionManifest(selected.Value!), token).ConfigureAwait(false);
                return snapshot.Rules.GenerateDueOccurrences(operation, key, request.ThroughDate, member, display, operation.AcceptedAt,
                    ids, intents, null, null);
            }, ct).ConfigureAwait(false);
    }

'''
s=s[:a]+head+s[b:]
s=s.replace('Handler(NativeOperationExecutor operations, IAggregateReader reader,\n    ControlOperationsReader operatingReader, IImmutableContentStore content, TimeProvider clock)',
 'Handler(TypeIIPeriodOperations operations,\n    ControlOperationsReader operatingReader, IImmutableContentStore content)')
s=s.replace(': IRequestHandler<GenerateDueControlOccurrences>',': IRequestHandler<GenerateDueControlOccurrences, UnitResult>')
s=s.replace('SelectAsync(TypeIIPeriod period,','SelectAsync(TypeIIPeriodReadSnapshot period,').replace('period.Current','period.View').replace('period.DueExpectedOccurrences','period.Rules.DueExpectedOccurrences')
p.write_text(s)
rel=Path('src/Compliance.Common/Features/Operations/GenerateDueControlOccurrences.cs')
for d in ['base','work']:
 p=root/d/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(Path('/Users/jrepanich/Code/bdgrz/compliance-core')/rel,p)
p=w/rel;s=p.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s;s=s.replace(': IRequest,',': IRequest<UnitResult>,');p.write_text(s)
# Selected root/event hydration is bounded while delayed receivers still recover from their own historical facts.
p=op/'TypeIIRangeVerifier.cs';s=p.read_text().replace('Uuid selectedCommandId, CancellationToken ct)','Uuid selectedCommandId, CancellationToken ct, Uuid selectedSourceId = default)')
s=s.replace('            selectedCommandId), ct)', '            selectedCommandId, operationId, selectedSourceId), ct)')
s=s.replace('return TypeIIRangeChange.Failed(Permanent($"The frozen range intent cannot be verified: {exception.Message}"));',
 'return TypeIIRangeChange.Failed(new RequestError(RequestErrorKind.Conflict, "The frozen range intent cannot be verified.", exception is ImmutableContentUnavailableException));')
p.write_text(s)
p=op/'MaterializeControlOccurrenceHandler.cs';s=p.read_text()
s=s.replace('new TypeIIPeriod(tenantId, intent.ProgramId, sourcePeriodId)', 'new TypeIIPeriod(tenantId, intent.ProgramId, sourcePeriodId, selectedEventId: source.EventId)')
p.write_text(s)
p=op/'TypeIIRangeReleaseReactor.cs';s=p.read_text()
s=s.replace('    IAggregateReader reader, IImmutableContentStore content)','    IImmutableContentStore content)')
a=s.index('    public async ValueTask HandleAsync(IReactorContext<ObservationPeriodCloseFrozen>');b=s.index('    async ValueTask SettleAsync',a)
s=s[:a]+'''    public ValueTask HandleAsync(IReactorContext<ObservationPeriodCloseFrozen> context, CancellationToken ct) =>
        SettleAsync(context, context.Trigger.CalendarAuthorizationId, context.Trigger.CalendarIntent, "initial", ct);

'''+s[b:]
s=s.replace('$"The frozen range intent cannot be verified: {exception.Message}", true)',
 '"The frozen range intent cannot be verified.", exception is ImmutableContentUnavailableException)')
p.write_text(s)
print('Native typed generation and bounded selected root/source proofs prepared')
