Optional separate production HTTP RED before applying the read layer:

`FullyQualifiedName~ObservationPeriodReadHttpTests.ShouldUseCanonicalPeriodRouteGivenMisleadingQueryIdentities`

The standalone patch seeds through the existing old period class/helper, contains no new compact types or projection APIs, and expects the selected scoped GET to return its exact route-bound identity. The old host returns 404. Reverse the standalone patch before applying the full tests patch, which preserves the same acceptance and adds scoped list/authorization/OpenAPI cases.
