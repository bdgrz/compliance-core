from pathlib import Path
import re
w=Path('/tmp/compliance-typeii-period-prepared/work'); op=w/'src/Compliance.Core/Features/Operations'
for name in ['ApproveTypeIIPeriodClose','FreezeTypeIIPeriodClose','AmendTypeIIPeriodClose']:
 p=w/f'src/Compliance.Common/Features/Examinations/{name}.cs';s=p.read_text()
 s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s
 s=s.replace(f'record {name}(Uuid TenantId',f'record {name}(Uuid CommandId, Uuid TenantId')
 s=s.replace(': IRequest,',': IRequest<UnitResult>, IIdentifiedRequest,')
 s=re.sub(r'(\[Discriminator\("[^"]+", )(\d+)(\)\])',lambda m:m[1]+str(int(m[2])+1)+m[3],s)
 p.write_text(s)
# Transient rule mutations don't contain the durable response envelope, which is frozen exactly once by the native executor.
p=op/'TypeIIPeriodRules.cs';s=p.read_text()
s=s.replace('ImmutableContentRef change, ImmutableContentRef firstResponse, ImmutableContentRef operationResult)',
 'ImmutableContentRef change, ImmutableContentRef? firstResponse, ImmutableContentRef? operationResult)')
s=s.replace(' || operationResult.Schema != "mutation-result-content.v1"',' || operationResult is not null && operationResult.Schema != "mutation-result-content.v1"')
s=s.replace(' ||\n            ev.FirstResponse is null || ev.OperationResult is null || ev.OperationResult.Schema != "mutation-result-content.v1"','')
# Rule-only selection permits the final first response to be supplied by the append factory.
s=s.replace('ev.Operation.LogicalId != GenerationLogicalId(Id, ev.GenerationKey) || ev.FirstResponse is null ||','ev.Operation.LogicalId != GenerationLogicalId(Id, ev.GenerationKey) ||')
s=s.replace('ImmutableContentRef firstResponse, ImmutableContentRef operationResult)', 'ImmutableContentRef? firstResponse, ImmutableContentRef? operationResult)')
s=s.replace('        ArgumentNullException.ThrowIfNull(firstResponse);\n','')
s=s.replace('        ArgumentNullException.ThrowIfNull(operationResult);\n','')
p.write_text(s)
(op/'TypeIIPeriodOperations.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Native immediate Unit decisions; every source/preparation failure rechecks an equal concurrent acceptance.</summary>
public sealed class TypeIIPeriodOperations(NativeOperationExecutor operations, TypeIIPeriodReader periods,
    IImmutableContentStore content, TimeProvider clock)
{
    public async ValueTask<Result<UnitResult>> ExecuteAsync<TRequest>(IRequestContext<TRequest> context,
        Uuid tenantId, Uuid programId, Uuid periodId, Uuid commandId, string kind, long? expectedRevision,
        Func<TypeIIPeriodReadSnapshot, OperationProvenance, CancellationToken, ValueTask<Result>> prepare,
        CancellationToken ct) where TRequest : IRequestBase
    {
        if (!ExaminationCommandActor.TryGet(context.Actor, context.Invocation, tenantId, out var member, out var display))
            return Fail(RequestErrorKind.Forbidden, "A period decision requires an authorized personal HTTP actor.");
        if (tenantId == Uuid.Empty || programId == Uuid.Empty || periodId == Uuid.Empty || commandId == Uuid.Empty ||
            expectedRevision is <= 0)
            return Fail(RequestErrorKind.Validation, "A period decision requires exact identities and a positive original revision.");
        var stream = new TypeIIPeriod(tenantId, programId, periodId).Stream;
        var operation = RootOperation.Provenance(commandId, kind, stream, ActorReference.ForMember(member, display),
            expectedRevision, AuthoredIntentDigest.Compute(context.Request), clock.GetUtcNow());
        FrozenTypeIIPeriodMutation? frozen = null;
        ImmutableContentRef? result = null;
        ImmutableContentRef? calendarIntent = null;
        var sequence = 0L;
        var position = 0UL;
        try
        {
            var accepted = await operations.ExecuteAsync(new NativeOperation<TypeIIPeriod>(AcceptedOperationBinding.Of(operation),
                () => new TypeIIPeriod(tenantId, programId, periodId, commandId), owner => owner.Acceptance,
                async (owner, token) =>
                {
                    if (owner.Header is null)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The observation period was not found."));
                    if (owner.PendingOperationId is not null || expectedRevision is { } expected && owner.Revision != expected)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict, "The period requires its exact current logical revision and no pending range change."));
                    var snapshot = await periods.ReadAsync(owner, token).ConfigureAwait(false);
                    var before = snapshot.View;
                    var ready = await prepare(snapshot, operation, token).ConfigureAwait(false);
                    if (!ready.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(ready.Error!);
                    frozen = await TypeIIPeriodContent.FreezeAsync(content, before, snapshot.Rules, operation, token).ConfigureAwait(false);
                    var response = await NativeContent.FreezeUnitAsync(content, tenantId, token).ConfigureAwait(false);
                    result = response.Result;
                    calendarIntent = owner.CalendarIntent;
                    sequence = owner.NativeSequence;
                    position = owner.CommittedStreamPosition;
                    return Result<FirstResponseDescriptor>.Success(response.Response);
                }, (owner, response) => owner.Append(TypeIIPeriodContent.Fact(frozen!, operation, response, result!, sequence + 1,
                    calendarIntent), frozen!.Before, frozen.After, sequence, position)), context, ct).ConfigureAwait(false);
            var descriptor = accepted.Value switch
            {
                AcceptedAppendResult.Committed committed => committed.Response,
                AcceptedAppendResult.Replayed replayed => replayed.Response,
                _ => null,
            };
            if (!accepted.IsSuccess)
                return Result<UnitResult>.Failure(accepted.Error!);
            if (descriptor is null)
                return Result<UnitResult>.Failure(AcceptedAppendResult.ConflictError);
            if (descriptor.StatusCode != 200 || descriptor.ResultSchema != UnitResult.Schema ||
                descriptor.Body is not StandardResponseBody body || body.Content.Schema != UnitResult.Schema)
                throw new ImmutableContentIntegrityException("The original period decision has another response contract.");
            return await NativeContent.ResponseAsync<UnitResult>(content, tenantId, accepted, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The period's exact immutable content cannot be verified.", exception is ImmutableContentUnavailableException));
        }
    }

    public static Result Outcome(Bdgrz.Compliance.Features.Versioning.CommandFailure? failure) =>
        failure is null ? Result.Success : Result.Failure(failure.ToRequestError());
    static Result<UnitResult> Fail(RequestErrorKind kind, string message) => Result<UnitResult>.Failure(new RequestError(kind, message));
}
''')
(op/'ApproveTypeIIPeriodCloseHandler.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Native close approval over an exact ready reconciliation, with current executive authorization before replay.</summary>
public sealed class ApproveTypeIIPeriodCloseHandler(TypeIIPeriodOperations operations,
    ManagementExecutiveAuthority executiveAuthority) : IRequestHandler<ApproveTypeIIPeriodClose, UnitResult>
{
    public async ValueTask<Result<UnitResult>> HandleAsync(IRequestContext<ApproveTypeIIPeriodClose> context, CancellationToken ct)
    {
        var request = context.Request;
        if (!ExaminationCommandActor.TryGet(context.Actor, context.Invocation, request.TenantId, out var member, out var display) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var user))
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Forbidden, "Close approval requires a personal HTTP actor."));
        var role = await executiveAuthority.ResolveExecutiveRoleAsync(request.TenantId, request.ProgramId, user, member, ct).ConfigureAwait(false);
        if (role is null)
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Forbidden, "Close approval requires current program-scoped CEO or CISO authority."));
        return await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PeriodId, request.CommandId,
            nameof(ApproveTypeIIPeriodClose), request.ExpectedRevision, (snapshot, operation, _) => ValueTask.FromResult(
                TypeIIPeriodOperations.Outcome(snapshot.Rules.ApproveClose(request.ExpectedRevision, request.AcknowledgedMaterialItemIds,
                    request.Rationale, member, role, display, operation.AcceptedAt))), ct).ConfigureAwait(false);
    }
}
''')
(op/'FreezeTypeIIPeriodCloseHandler.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Freezes the exact approved close and complete occurrence coverage in one native period admission.</summary>
public sealed class FreezeTypeIIPeriodCloseHandler(TypeIIPeriodOperations operations,
    ManagementExecutiveAuthority executiveAuthority, TypeIIOccurrenceCoverage coverage)
    : IRequestHandler<FreezeTypeIIPeriodClose, UnitResult>
{
    public async ValueTask<Result<UnitResult>> HandleAsync(IRequestContext<FreezeTypeIIPeriodClose> context, CancellationToken ct)
    {
        var request = context.Request;
        if (!ExaminationCommandActor.TryGet(context.Actor, context.Invocation, request.TenantId, out var member, out _) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var user))
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Forbidden, "Freezing a close requires a personal HTTP actor."));
        if (request.CloseSnapshotId == Uuid.Empty)
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Validation, "A close freeze requires its exact immutable snapshot identity."));
        var role = await executiveAuthority.ResolveExecutiveRoleAsync(request.TenantId, request.ProgramId, user, member, ct).ConfigureAwait(false);
        if (role is null)
            return Result<UnitResult>.Failure(new RequestError(RequestErrorKind.Forbidden, "Freezing a close requires current program-scoped CEO or CISO authority."));
        return await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PeriodId, request.CommandId,
            nameof(FreezeTypeIIPeriodClose), request.ExpectedRevision, async (snapshot, operation, token) =>
            {
                var current = snapshot.View!;
                var approval = current.CloseApprovals.Count == 0 ? null : current.CloseApprovals[^1];
                if (current.CloseValidation is not { Status: "ready" } validation || approval is null)
                    return Conflict("The exact ready reconciliation and current executive approval are required.");
                if (approval.ApprovedByMemberId != member || !StringComparer.OrdinalIgnoreCase.Equals(approval.ApproverRole, role))
                    return Result.Failure(new RequestError(RequestErrorKind.Forbidden, "Only the same currently authorized executive can freeze this exact approval."));
                var proof = await coverage.ProveAsync(snapshot, token).ConfigureAwait(false);
                if (!proof.IsComplete)
                    return Conflict("Every expected recurring occurrence must be selected and materialized before freezing the close.");
                var body = new TypeIIPeriodCloseSnapshotContent(request.CloseSnapshotId, validation.SourceReferences,
                    validation.ExpectedOccurrenceIds, approval.AcknowledgedMaterialItemIds)
                    { SourceContentManifest = validation.SourceContentManifest ?? current.OpeningSourceContentManifest };
                return TypeIIPeriodOperations.Outcome(snapshot.Rules.FreezeClose(request.ExpectedRevision, body, member, role, operation.AcceptedAt));
            }, ct).ConfigureAwait(false);
    }
    static Result Conflict(string message) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message));
}
''')
# Explicit read composition in internal close proof ports.
for name in ['ITypeIIPeriodCloseReconciliation.cs','TypeIIPeriodCloseReconciliation.cs','TypeIIOccurrenceCoverage.cs']:
 p=op/name;s=p.read_text().replace('ReadAsync(TypeIIPeriod period','ReadAsync(TypeIIPeriodReadSnapshot period').replace('ProveAsync(TypeIIPeriod period','ProveAsync(TypeIIPeriodReadSnapshot period')
 s=s.replace('period.Current','period.View').replace('period.Stream','period.Owner.Stream')
 p.write_text(s)
print('Typed native Unit close approval/freeze and common root executor prepared')
