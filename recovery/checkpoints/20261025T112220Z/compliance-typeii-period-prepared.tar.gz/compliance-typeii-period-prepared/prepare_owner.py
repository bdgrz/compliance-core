from pathlib import Path
import re
root=Path('/tmp/compliance-typeii-period-prepared');w=root/'work';op=w/'src/Compliance.Core/Features/Operations'
old=(root/'base/src/Compliance.Core/Features/Operations/TypeIIPeriod.cs').read_text()
# Reuse existing admission/fence guards while replacing historical dictionaries with the one pending fact.
methods=old[old.index('    public Result PrepareOpeningAcceptance()'):old.index('    /// <summary>\n    ///     Validates an amendment')]
methods=methods.replace('_current is null && _accepted.Count == 0','Header is null && !_openingAccepted')
methods=methods.replace('StaleRevision()', 'StaleRevision()')
a=old[old.index('    public Result AcceptAmendment('):old.index('    /// <summary>\n    ///     Applies the frozen opening')]
a=a.replace('_current is null','Header is null').replace('_pending != amendmentId || _accepted[amendmentId]','PendingOperationId != amendmentId || _pendingFact')
a=a.replace('_pending != operation.RootOperationId || operation.Owner != Stream ||\n            _accepted[operation.RootOperationId]','PendingOperationId != operation.RootOperationId || operation.Owner != Stream ||\n            _pendingFact')
a=a.replace('_pending is not null','_pendingFact is not null')
methods+=a
text='''using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Versioning;
using Bdgrz.Compliance.Hosting.Persistence;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Compact native period authority; full populations, source bodies and histories are composed by TypeIIPeriodReader.</summary>
public sealed class TypeIIPeriod : Aggregate
{
    public const string Area = "type-ii-periods";
    readonly Uuid _tenantId;
    readonly Uuid _programId;
    readonly Uuid _selectedRoot;
    readonly Uuid _selectedEvent;
    DomainEvent? _pendingFact;
    DomainEvent? _selectedAccepted;
    DomainEvent? _selectedTerminal;
    DomainEvent? _selectedSource;
    bool _openingAccepted;

    public TypeIIPeriod(Uuid tenantId, Uuid programId, Uuid periodId, Uuid selectedLogicalId = default,
        Uuid selectedRootId = default, Uuid selectedEventId = default)
        : base(periodId, new EventStreamAddress(tenantId.ToString(), Area, periodId.ToString()))
    {
        (_tenantId, _programId, _selectedRoot, _selectedEvent) = (tenantId, programId,
            selectedRootId == Uuid.Empty ? selectedLogicalId : selectedRootId, selectedEventId);
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<TypeIIPeriodOpeningAccepted>(ApplyFact);
        On<TypeIIPeriodAmendmentAccepted>(ApplyFact);
        On<TypeIIPeriodOpeningRejected>(ApplyFact);
        On<TypeIIPeriodAmendmentCanceled>(ApplyFact);
        On<ObservationPeriodStarted>(ApplyFact);
        On<ObservationPeriodAmended>(ApplyFact);
        On<DueControlOccurrencesGenerated>(ApplyFact);
        On<ObservationPeriodCloseProposed>(ApplyFact);
        On<TypeIIPeriodCloseApproved>(ApplyFact);
        On<ObservationPeriodCloseFrozen>(ApplyFact);
        On<TypeIIPeriodCloseAmended>(ApplyFact);
    }
    public NativeAcceptance Acceptance { get; }
    public long NativeSequence { get; private set; }
    public TypeIIPeriodAuthorityHeader? Header { get; private set; }
    public ImmutableContentRef? CurrentContent { get; private set; }
    public long Revision => Header?.Revision ?? 0;
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;
    public Uuid? PendingOperationId => (_pendingFact as INativeOperationFact)?.Operation.RootOperationId;
    public DomainEvent? Pending => _pendingFact;
    public TypeIIPeriodCalendarAuthorization? CalendarAuthorization { get; private set; }
    public ImmutableContentRef? CalendarIntent { get; private set; }
    public DomainEvent? AcceptedFor(Uuid operationId) => PendingOperationId == operationId ? _pendingFact :
        operationId == _selectedRoot ? _selectedAccepted : null;
    public DomainEvent? TerminalFor(Uuid operationId) => operationId == _selectedRoot ? _selectedTerminal : null;
    public bool IsFenced(Uuid operationId) => TerminalFor(operationId) is TypeIIPeriodOpeningRejected or TypeIIPeriodAmendmentCanceled;
    public bool IsApplied(Uuid operationId) => TerminalFor(operationId) is ObservationPeriodStarted or ObservationPeriodAmended;
    public DomainEvent? FactById(Uuid eventId) => eventId == _selectedEvent ? _selectedSource : null;
    public static Uuid GenerationLogicalId(Uuid periodId, string generationKey) =>
        TypeIIPeriodRules.GenerationLogicalId(periodId, generationKey);
    public static ImmutableContentRef? IntentOf(DomainEvent? accepted) => accepted switch
    {
        TypeIIPeriodOpeningAccepted opening => opening.Intent,
        TypeIIPeriodAmendmentAccepted amendment => amendment.Intent,
        _ => null,
    };

'''+methods+'''
    /// <summary>Rechecks the exact physical/native cut and verified local transition inside the owning OCC append.</summary>
    public Result Append(DomainEvent value, TypeIIPeriodView? before, TypeIIPeriodView after,
        long preparedSequence, ulong preparedPosition)
    {
        if (NativeSequence != preparedSequence || CommittedStreamPosition != preparedPosition)
            return Failure("The period changed while its exact immutable content was prepared.", true);
        if (value is not ITypeIIPeriodStateFact fact ||
            (before is null ? CurrentContent is not null || Header is not null :
                CurrentContent is null || ContentDigest.OfJson(before) != CurrentContent.Sha256 ||
                TypeIIPeriodContent.Header(before) != Header) ||
            fact.CurrentContent.Schema != TypeIIPeriodContent.StateSchema ||
            ContentDigest.OfJson(after) != fact.CurrentContent.Sha256 ||
            TypeIIPeriodContent.Header(after) != fact.Header)
            return Failure("The period's prepared content does not match its exact native authority.");
        var rules = new TypeIIPeriodRules(_tenantId, _programId, Id);
        var transition = TypeIIPeriodContent.Transition(value);
        if (rules.ValidateState(after) is not null ||
            (before is null ? transition != "start" || !TypeIIPeriodRules.ValidOpeningState(after) :
                transition == "generation" ? !TypeIIPeriodContent.SameGenerationState(before, after) :
                !TypeIIPeriodRules.ValidTransition(before, after, fact.ActorMemberId, transition)))
            return Failure("The prepared Type II period transition is invalid.");
        try
        {
            ValidateStateFact(value, fact);
            if (DomainEventPayload.Size(value) > DomainEventPayload.MaximumBytes)
                return Failure("The compact period event exceeds the bounded payload size.");
        }
        catch (InvalidOperationException)
        {
            return Failure("The period mutation differs from its exact local native authority.");
        }
        RaiseEvent(value);
        return Result.Success;
    }

    void ApplyFact(DomainEvent value)
    {
        if (value is ITypeIIPeriodStateFact fact)
        {
            ValidateStateFact(value, fact);
            Header = fact.Header;
            CurrentContent = fact.CurrentContent;
            if (value is ObservationPeriodStarted started)
                Settle(started.Operation, started.Change, started.CalendarAuthorizationId, started.CalendarGeneration);
            else if (value is ObservationPeriodAmended amended)
                Settle(amended.Operation, amended.Change, amended.CalendarAuthorizationId, amended.CalendarGeneration);
            else if (value is ObservationPeriodCloseFrozen)
            {
                CalendarAuthorization = null;
                CalendarIntent = null;
            }
        }
        else if (value is TypeIIPeriodOpeningAccepted opening)
            Accept(opening, opening.Owner, opening.Revision, opening.Generation, opening.Operation, opening.FirstResponse, true);
        else if (value is TypeIIPeriodAmendmentAccepted amendment)
            Accept(amendment, amendment.Owner, amendment.Revision, amendment.Generation, amendment.Operation, amendment.FirstResponse, false);
        else if (value is TypeIIPeriodOpeningRejected rejected)
            Fence(rejected, rejected.Owner, rejected.Operation, rejected.Intent, true);
        else if (value is TypeIIPeriodAmendmentCanceled canceled)
            Fence(canceled, canceled.Owner, canceled.Operation, canceled.Intent, false);
        else
            throw new InvalidOperationException("The Type II period has another native fact kind.");
        NativeSequence++;
        Acceptance.Observe(value);
        if (value.Metadata?.EventId == _selectedEvent)
            _selectedSource = value;
    }

    void Accept(DomainEvent fact, EventStreamAddress owner, long revision, long generation,
        OperationProvenance operation, ImmutableContentRef? firstResponse, bool opening)
    {
        if (_pendingFact is not null || owner != Stream || operation.Owner != Stream ||
            operation.FirstOwner is { } first && first != Stream || operation.AffectedOwner != Stream ||
            operation.ExpectedRevisionOwner != Stream || operation.LogicalId != operation.RootOperationId ||
            revision != Revision || generation != TypeIIRangeEffects.Generation || firstResponse?.Schema != FirstResponses.Schema ||
            (opening ? Header is not null || _openingAccepted || operation.RootOperationId != Id : Header is null))
            throw new InvalidOperationException("A period accepts one exact pending root at its own revision.");
        _pendingFact = fact;
        _openingAccepted |= opening;
        if (operation.RootOperationId == _selectedRoot)
            _selectedAccepted = fact;
    }

    void Fence(DomainEvent fact, EventStreamAddress owner, OperationProvenance operation,
        ImmutableContentRef intent, bool opening)
    {
        if (_pendingFact is null || PendingOperationId != operation.RootOperationId || owner != Stream ||
            operation.Owner != Stream || (_pendingFact is TypeIIPeriodOpeningAccepted) != opening || IntentOf(_pendingFact) != intent)
            throw new InvalidOperationException("Only the exact pending period operation can be fenced.");
        if (operation.RootOperationId == _selectedRoot)
            _selectedTerminal = fact;
        _pendingFact = null;
    }

    void Settle(OperationProvenance operation, ImmutableContentRef intent, Uuid authorizationId, long generation)
    {
        _pendingFact = null;
        CalendarAuthorization = new TypeIIPeriodCalendarAuthorization(authorizationId, generation);
        CalendarIntent = intent;
    }

    void ValidateStateFact(DomainEvent value, ITypeIIPeriodStateFact fact)
    {
        var after = fact.Header;
        var operation = fact.Operation;
        if (after is null || fact.TenantId != _tenantId || fact.SubjectId != Id ||
            after.TenantId != _tenantId || after.ProgramId != _programId || after.PeriodId != Id ||
            after.Revision != Revision + 1 || fact.Revision != after.Revision || fact.NativeSequence != NativeSequence + 1 ||
            after.ExpectedOccurrenceCount is < 1 or > 10000 || after.CloseSnapshotCount is < 0 or > 64 ||
            after.PeriodStart == default || after.PeriodEnd < after.PeriodStart ||
            fact.CurrentContent.Schema != TypeIIPeriodContent.StateSchema || fact.CurrentContent.Bytes <= 0 ||
            operation.Owner != Stream || operation.AffectedOwner != Stream || operation.ExpectedRevisionOwner != Stream ||
            operation.FirstOwner is { } first && first != Stream || operation.Actor.Kind != "member" ||
            !Uuid.TryParse(operation.Actor.Id, out var member) || member == Uuid.Empty || member != fact.ActorMemberId ||
            fact.OperationResult?.Schema != "mutation-result-content.v1")
            throw new InvalidOperationException("The compact Type II period native authority is invalid.");
        if (Header is { } prior && (after.ExaminationId != prior.ExaminationId || after.TypeIIPlanId != prior.TypeIIPlanId ||
            after.TypeIIPlanVersion != prior.TypeIIPlanVersion || after.TypeIIPlanContentSha256 != prior.TypeIIPlanContentSha256 ||
            after.OpeningSnapshotId != prior.OpeningSnapshotId || after.OpeningSnapshotSha256 != prior.OpeningSnapshotSha256 ||
            after.ExpectedOccurrenceCount != prior.ExpectedOccurrenceCount || after.ExpectedOccurrencesSha256 != prior.ExpectedOccurrencesSha256 ||
            after.CloseSnapshotCount < prior.CloseSnapshotCount || after.CloseSnapshotCount > prior.CloseSnapshotCount + 1))
            throw new InvalidOperationException("The period cannot rewrite its admitted identity or expected population.");
        if (value is ObservationPeriodStarted started)
            RequirePending(started.Operation, started.Change, started.CalendarAuthorizationId, started.CalendarGeneration, true);
        else if (value is ObservationPeriodAmended amended)
            RequirePending(amended.Operation, amended.Change, amended.CalendarAuthorizationId, amended.CalendarGeneration, false);
        else
        {
            if (Header is null || _pendingFact is not null || operation.RootOperationId != operation.LogicalId ||
                operation.CausationEventId is not null || fact.FirstResponse?.Schema != FirstResponses.Schema ||
                value is not DueControlOccurrencesGenerated && operation.OriginalExpectedRevision != (ulong)Revision)
                throw new InvalidOperationException("A period decision requires its exact current root and no pending range change.");
            var kind = value switch
            {
                DueControlOccurrencesGenerated => nameof(GenerateDueControlOccurrences),
                ObservationPeriodCloseProposed => nameof(RecordTypeIIPeriodCloseValidation),
                TypeIIPeriodCloseApproved => nameof(ApproveTypeIIPeriodClose),
                ObservationPeriodCloseFrozen => nameof(FreezeTypeIIPeriodClose),
                TypeIIPeriodCloseAmended => nameof(AmendTypeIIPeriodClose),
                _ => throw new InvalidOperationException("The period decision has another kind."),
            };
            if (operation.CommandKind != kind)
                throw new InvalidOperationException("The period decision has another authored command kind.");
        }
        if (value is DueControlOccurrencesGenerated generation && (Header?.Status != "active" || after.Status != "active" ||
            operation.LogicalId != GenerationLogicalId(Id, generation.GenerationKey) ||
            generation.ThroughDate < after.PeriodStart || generation.ThroughDate > after.PeriodEnd ||
            after.UpdatedAt != Header.UpdatedAt || after.ActorMemberId != Header.ActorMemberId))
            throw new InvalidOperationException("A generation must preserve its admitted period authority.");
        if (value is ObservationPeriodCloseProposed && (Header?.Status is not ("active" or "close_ready" or "close_blocked") ||
            after.Status is not ("close_ready" or "close_blocked") || after.ValidatorMemberId != member ||
            after.ValidatedAt != operation.AcceptedAt || DateOnly.FromDateTime(operation.AcceptedAt.UtcDateTime) <= after.PeriodEnd))
            throw new InvalidOperationException("A close reconciliation must follow the complete observation interval.");
        if (value is TypeIIPeriodCloseApproved && (Header?.Status != "close_ready" || after.Status != "close_approved" ||
            Header.ValidatorMemberId == member || after.ApproverMemberId != member || after.ValidationSha256 != Header.ValidationSha256))
            throw new InvalidOperationException("A close approval requires an independent executive over the exact ready validation.");
        if (value is ObservationPeriodCloseFrozen frozen && (Header?.Status != "close_approved" || after.Status != "closed" ||
            Header.ApproverMemberId != member || CalendarAuthorization is not { } live ||
            live.AuthorizationId != frozen.CalendarAuthorizationId || live.Generation != frozen.CalendarGeneration ||
            CalendarIntent != frozen.CalendarIntent || after.CloseSnapshotCount != 1 || after.LatestCloseVersion != 1 ||
            after.ValidationSha256 != Header.ValidationSha256 || after.ApprovalSha256 != Header.ApprovalSha256))
            throw new InvalidOperationException("A freeze requires its exact approving executive and live calendar permit.");
        if (value is TypeIIPeriodCloseAmended && (Header?.Status != "closed" || after.Status != "closed" ||
            after.CloseSnapshotCount != Header.CloseSnapshotCount + 1 || after.LatestCloseVersion != Header.LatestCloseVersion + 1))
            throw new InvalidOperationException("A close amendment advances the immutable terminal lineage.");
    }

    void RequirePending(OperationProvenance operation, ImmutableContentRef change, Uuid authorizationId,
        long generation, bool opening)
    {
        if (_pendingFact is null || PendingOperationId != operation.RootOperationId ||
            (_pendingFact is TypeIIPeriodOpeningAccepted) != opening || IntentOf(_pendingFact) != change ||
            authorizationId != operation.RootOperationId || generation <= 0 ||
            opening != (Header is null))
            throw new InvalidOperationException("A period apply must answer its exact pending range admission and calendar permit.");
        if (operation.RootOperationId == _selectedRoot)
            _selectedTerminal = null;
    }

    CommandFailure StaleRevision() => VersionedRecordRules.StaleRevision("Type II period", Revision);
    static Result Failure(string message, bool transient = false) =>
        Result.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
'''
# Record only the selected terminal; reducer remains bounded for arbitrarily long period histories.
text=text.replace('            ValidateStateFact(value, fact);\n            Header', '''            ValidateStateFact(value, fact);
            if (fact.Operation.RootOperationId == _selectedRoot && value is ObservationPeriodStarted or ObservationPeriodAmended)
                _selectedTerminal = value;
            Header''')
# No field called _pending remains in generated methods.
assert '_pending ' not in text
(op/'TypeIIPeriod.cs').write_text(text)
print('Compact native owner prepared')
