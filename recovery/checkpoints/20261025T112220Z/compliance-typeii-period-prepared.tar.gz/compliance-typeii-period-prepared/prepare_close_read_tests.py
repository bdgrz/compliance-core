from pathlib import Path
p=Path('/tmp/compliance-typeii-period-prepared/work/test/Compliance.Tests/Features/Operations/ObservationPeriodReadHandlerTests.cs');s=p.read_text()
s='using Bdgrz.Compliance.Features.AuditPopulations;\nusing Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Features.Snapshots;\n'+s
idx=s.index('    static RequestContext<T> Context')
s=s[:idx]+'''    [Fact]
    public async Task ShouldReadExactHistoricalCloseGivenLaterImmutableAmendment()
    {
        // Arrange
        await using var fixture = new Fixture();
        var period = await fixture.SeedClosedAsync();
        var original = period.Current!.CloseSnapshots[0];
        await fixture.AmendClosedAsync(period);
        await fixture.ProjectAsync();

        // Act
        var result = await fixture.CloseAsync(original.CloseSnapshotId);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(period.Id, result.Value!.PeriodId);
        Assert.Equal(original.CloseSnapshotId, result.Value.Snapshot.CloseSnapshotId);
        Assert.Equal(original.ContentSha256, result.Value.Snapshot.ContentSha256);
        Assert.Equal(2, result.Value.CloseSnapshots.Count);
        Assert.Equal(original.CloseSnapshotId, result.Value.CloseSnapshots[^1].AmendsCloseSnapshotId);
    }

    [Fact]
    public async Task ShouldReturnConflictGivenScopedCloseIdentityIsAmbiguousAcrossPeriods()
    {
        // Arrange
        await using var fixture = new Fixture();
        var close = Uuid.CreateVersion4();
        await fixture.SeedClosedAsync(close);
        await fixture.SeedClosedAsync(close);
        await fixture.ProjectAsync();

        // Act
        var result = await fixture.CloseAsync(close);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.False(result.Error!.IsTransient);
        Assert.Null(result.Value);
        Assert.Equal(2, (await fixture.Directory.FindAsync(fixture.Tenant, fixture.Program, close)).Count);
    }

    [Theory]
    [InlineData("tenant")]
    [InlineData("program")]
    [InlineData("close")]
    public async Task ShouldHideHistoricalCloseGivenAnotherScopeOrIdentity(string changed)
    {
        // Arrange
        await using var fixture = new Fixture();
        var period = await fixture.SeedClosedAsync();
        var close = period.Current!.CloseSnapshots[0].CloseSnapshotId;
        await fixture.ProjectAsync();

        // Act
        var result = await fixture.CloseAsync(changed == "close" ? Uuid.CreateVersion4() : close,
            tenant: changed == "tenant" ? Uuid.CreateVersion4() : fixture.Tenant,
            program: changed == "program" ? Uuid.CreateVersion4() : fixture.Program);

        // Assert
        Assert.Equal(RequestErrorKind.NotFound, result.Error?.Kind);
    }

    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ShouldReturnTypedFailureGivenHistoricalCloseBodyCannotBeVerified(bool unavailable)
    {
        // Arrange
        await using var fixture = new Fixture();
        var period = await fixture.SeedClosedAsync();
        await fixture.ProjectAsync();
        var reader = new TypeIIPeriodReader(fixture.Reader, fixture.Events, new FaultedContent(fixture.Content, unavailable));
        var handler = new GetObservationPeriodCloseHandler(fixture.Directory,
            new ObservationPeriodDirectoryReadConsistency(fixture.Directory, fixture.Events), reader);

        // Act
        var result = await handler.HandleAsync(Context(new GetObservationPeriodClose(fixture.Tenant, fixture.Program,
            period.Current!.CloseSnapshots[0].CloseSnapshotId)), CancellationToken.None);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.Equal(unavailable, result.Error!.IsTransient);
        Assert.Null(result.Value);
    }

    [Fact]
    public async Task ShouldReturnPendingConflictGivenCloseIdentityHasNotReachedItsNativeSource()
    {
        // Arrange
        await using var fixture = new Fixture();
        var period = await fixture.SeedClosedAsync();

        // Act
        var result = await fixture.CloseAsync(period.Current!.CloseSnapshots[0].CloseSnapshotId);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.True(result.Error!.IsTransient);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldRetryHistoricalCloseGivenNativeSourceChangesDuringLocatorRead(bool project)
    {
        // Arrange
        await using var fixture = new Fixture();
        var period = await fixture.SeedClosedAsync();
        await fixture.ProjectAsync();
        var directory = new HookedCloseDirectory(fixture.Directory, async () =>
        {
            await fixture.SeedAsync(Now.AddMinutes(1));
            if (project)
                await fixture.ProjectAsync();
        });
        var handler = new GetObservationPeriodCloseHandler(directory,
            new ObservationPeriodDirectoryReadConsistency(fixture.Directory, fixture.Events),
            new TypeIIPeriodReader(fixture.Reader, fixture.Events, fixture.Content));

        // Act
        var result = await handler.HandleAsync(Context(new GetObservationPeriodClose(fixture.Tenant, fixture.Program,
            period.Current!.CloseSnapshots[0].CloseSnapshotId)), CancellationToken.None);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.True(result.Error!.IsTransient);
        Assert.Null(result.Value);
    }

'''+s[idx:]
idx=s.index('        public Task<Result<ObservationPeriodView>> GetAsync')
s=s[:idx]+'''        public async Task<TypeIIPeriodRules> SeedClosedAsync(Uuid? closeId = null)
        {
            var period = await SeedAsync(Now);
            var expected = period.Current!.ExpectedOccurrences.Select(item => item.OccurrenceId).ToArray();
            var at = Now.AddYears(1);
            Assert.Null(period.RecordCloseValidation(period.Revision, new TypeIIPeriodCloseValidationContent(
                period.Current.OpeningSourceReferences, expected, expected, [], [], []), Uuid.CreateVersion4(), "Close validator", at));
            Assert.Null(period.ApproveClose(period.Revision, [], "Reviewed exact close.", Member, "CEO", "Executive approver", at.AddMinutes(1)));
            Assert.Null(period.FreezeClose(period.Revision, new TypeIIPeriodCloseSnapshotContent(closeId ?? Uuid.CreateVersion4(),
                period.Current.CloseValidation!.SourceReferences, expected, []), Member, "CEO", at.AddMinutes(2)));
            await TypeIIPeriodSeeds.AppendAsync(Reader, Writer, Content, period);
            return period;
        }
        public async Task AmendClosedAsync(TypeIIPeriodRules period)
        {
            var prior = period.Current!.CloseSnapshots[^1];
            var at = Now.AddYears(1).AddDays(1);
            var source = prior.SourceReferences[0] with { VersionId = Uuid.CreateVersion4(), Version = prior.SourceReferences[0].Version + 1,
                ContentSha256 = new string('f', 64) };
            var operation = RootOperation.Provenance(Uuid.CreateVersion5(period.Id, "seed:" + nameof(AmendTypeIIPeriodClose) + ":" + (period.Revision + 1)),
                nameof(AmendTypeIIPeriodClose), period.Stream, ActorReference.ForMember(Member, "Executive approver"),
                period.Revision, new string('e', 64), at);
            var publication = await Content.WriteJsonAsync(Tenant.ToString(), Uuid.CreateVersion4(), SnapshotSourcePublicationManifest.Schema,
                new SnapshotSourcePublicationManifest(Tenant, Program, period.Current.ExaminationId, []));
            var reconciliation = new TypeIIPeriodCloseValidationContent([source], prior.ExpectedOccurrenceIds, prior.ExpectedOccurrenceIds,
                [], [], prior.AcknowledgedMaterialItemIds) { SourceContentManifest = publication, RecordedThrough = at };
            var proof = await new TypeIIPeriodCloseMaterialReader(Events, Content).FreezeAsync(period.Current, prior, reconciliation, operation, CancellationToken.None);
            var evidence = await Content.ReadJsonAsync<TypeIIPeriodCloseMaterialProof>(Tenant.ToString(), proof);
            Assert.Null(period.AmendClose(period.Revision, new TypeIIPeriodCloseSnapshotContent(Uuid.CreateVersion4(), [source],
                prior.ExpectedOccurrenceIds, prior.AcknowledgedMaterialItemIds) { SourceContentManifest = publication },
                "Correct the exact source version.", evidence.ChangedRecordIds, evidence.AffectedExaminationMaterialIds,
                Member, "CEO", "Executive approver", at, proof));
            await TypeIIPeriodSeeds.AppendAsync(Reader, Writer, Content, period);
        }
        public Task<Result<ObservationPeriodCloseView>> CloseAsync(Uuid closeId, Uuid? tenant = null, Uuid? program = null) =>
            new GetObservationPeriodCloseHandler(Directory, new ObservationPeriodDirectoryReadConsistency(Directory, Events),
                new TypeIIPeriodReader(Reader, Events, Content)).HandleAsync(Context(new GetObservationPeriodClose(
                    tenant ?? Tenant, program ?? Program, closeId)), CancellationToken.None).AsTask();
'''+s[idx:]
s=s.replace('''                if (record.Event is ObservationPeriodStarted started)
                    await Directory.ApplyAsync(started);
                cursor = record.NextCursor;''','''                if (record.Event is ObservationPeriodStarted started)
                    await Directory.ApplyAsync(started);
                else if (record.Event is ObservationPeriodCloseFrozen frozen)
                    await Directory.ApplyAsync(frozen);
                else if (record.Event is TypeIIPeriodCloseAmended amended)
                    await Directory.ApplyAsync(amended);
                cursor = record.NextCursor;''')
idx=s.rindex('}')
s=s[:idx]+'''    sealed class HookedCloseDirectory(IObservationPeriodCloseDirectoryReader inner, Func<Task> afterRead) : IObservationPeriodCloseDirectoryReader
    {
        public async ValueTask<IReadOnlyList<ObservationPeriodCloseIdentity>> FindAsync(Uuid tenantId, Uuid programId, Uuid closeId, CancellationToken ct = default)
        {
            var values = await inner.FindAsync(tenantId, programId, closeId, ct);
            await afterRead();
            return values;
        }
    }

    sealed class FaultedContent(IImmutableContentStore inner, bool unavailable) : IImmutableContentStore
    {
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid id, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default) => inner.WriteVerifiedAsync(realm, id, schema, mediaType, bytes, ct);
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default) =>
            throw (unavailable ? new ImmutableContentUnavailableException("The exact historical close body is absent.") :
                new ImmutableContentIntegrityException("The exact historical close body is corrupt."));
    }
'''+s[idx:]
p.write_text(s)
print('Scoped historical close query tests cover immutable lineage, collisions, scope, typed source failures and source-cut races')
