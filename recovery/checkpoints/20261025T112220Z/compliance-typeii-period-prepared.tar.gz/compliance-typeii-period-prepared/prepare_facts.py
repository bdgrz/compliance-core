from pathlib import Path
import re
w=Path('/tmp/compliance-typeii-period-prepared/work')
ops=w/'src/Compliance.Common/Features/Operations'
(ops/'TypeIIPeriodAuthorityHeader.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>Bounded current period authority; source bodies, populations and decision history remain immutable content.</summary>
public sealed record TypeIIPeriodAuthorityHeader(
    Uuid TenantId, Uuid ProgramId, Uuid PeriodId, long Revision, string Status,
    Uuid ExaminationId, Uuid TypeIIPlanId, int TypeIIPlanVersion, string TypeIIPlanContentSha256,
    DateOnly PeriodStart, DateOnly PeriodEnd, Uuid OpeningSnapshotId, string OpeningSnapshotSha256,
    int ExpectedOccurrenceCount, string ExpectedOccurrencesSha256,
    string? ValidationSha256, string? ValidationStatus, Uuid? ValidatorMemberId, DateTimeOffset? ValidatedAt,
    string? ApprovalSha256, Uuid? ApproverMemberId, string? ApproverRole, DateTimeOffset? ApprovedAt,
    int CloseSnapshotCount, Uuid? LatestCloseSnapshotId, int? LatestCloseVersion, string? LatestCloseSha256,
    Uuid? CloseActorMemberId, string? CloseActorRole, long? CloseOriginalExpectedRevision,
    Uuid ActorMemberId, DateTimeOffset UpdatedAt);
''')
(ops/'ITypeIIPeriodStateFact.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Operations;

/// <summary>One compact state advance at an exact period native sequence.</summary>
public interface ITypeIIPeriodStateFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid SubjectId { get; }
    long Revision { get; }
    Uuid? ActorMemberId { get; }
    DateTimeOffset OccurredAt { get; }
    long NativeSequence { get; }
    TypeIIPeriodAuthorityHeader Header { get; }
    ImmutableContentRef CurrentContent { get; }
}
''')
paths={
'ObservationPeriodStarted': ('Operations','bdgrz.operations.observation-period-started',1,True),
'ObservationPeriodAmended': ('Operations','bdgrz.operations.observation-period-amended',1,True),
'ObservationPeriodCloseProposed': ('AuditPopulations','bdgrz.auditpopulations.observation-period-close-proposed',4,False),
'TypeIIPeriodCloseApproved': ('AuditPopulations','bdgrz.auditpopulations.type-i-i-period-close-approved',3,False),
'ObservationPeriodCloseFrozen': ('AuditPopulations','bdgrz.auditpopulations.observation-period-close-frozen',1,True),
'TypeIIPeriodCloseAmended': ('AuditPopulations','bdgrz.auditpopulations.type-i-i-period-close-amended',3,False)}
for name,(area,disc,version,calendar) in paths.items():
    fields='''    Uuid TenantId,
    Uuid SubjectId,
    long Revision,
    Uuid? ActorMemberId,
    ImmutableContentRef Change,
    DateTimeOffset OccurredAt,
    OperationProvenance Operation,'''
    if calendar:
        fields+='''
    Uuid CalendarAuthorizationId,
    long CalendarGeneration,'''
    fields+='''
    ImmutableContentRef? FirstResponse,
    ImmutableContentRef? OperationResult,
    long NativeSequence,
    TypeIIPeriodAuthorityHeader Header,
    ImmutableContentRef CurrentContent'''
    if name=='ObservationPeriodCloseFrozen': fields+=',\n    ImmutableContentRef CalendarIntent'
    text=f'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Operations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.{area};

/// <summary>Compact native period authority advance with independently verified immutable current content.</summary>
[Discriminator("{disc}", {version})]
public sealed record {name}(
{fields}) : DomainEvent, ITypeIIPeriodStateFact;
'''
    if area=='Operations': text=text.replace('using Bdgrz.Compliance.Features.Operations;\n','')
    (w/f'src/Compliance.Common/Features/{area}/{name}.cs').write_text(text)
p=ops/'DueControlOccurrencesGenerated.cs';s=p.read_text()
s=s.replace('[Discriminator("bdgrz.operations.due-control-occurrences-generated", 3)]','[Discriminator("bdgrz.operations.due-control-occurrences-generated", 1)]')
s=s.replace(') : DomainEvent, INativeOperationFact;', ''') : DomainEvent, ITypeIIPeriodStateFact
{
    public long NativeSequence { get; init; }
    public TypeIIPeriodAuthorityHeader Header { get; init; } = null!;
    public ImmutableContentRef CurrentContent { get; init; } = null!;
}
''')
p.write_text(s)
print('Seven compact state facts and bounded authority header prepared')
