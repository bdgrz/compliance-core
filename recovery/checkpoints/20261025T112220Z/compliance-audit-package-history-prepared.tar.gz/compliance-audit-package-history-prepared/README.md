# Audit package manifest bounded authority

Prepared offline only. Root owns formatting, compilation/analyzers, old-code RED qualification, focused/full tests, direct Jev, integration and Git. No preparing-agent runtime or main changes.

The manifest no longer retains lifetime facts, version dictionaries, or frozen-version sets. It retains its current version/ref/frozen flag, one explicitly selected version/ref/frozen flag, one selected native acceptance, latest fact, and a bounded rolling commitment to its actual replay payload/metadata prefix. `AuditPackageManifestHistory` reconstructs and verifies complete history outside the Aggregate against the hydrated native and physical cut using installed `NativeOwnerHistory`. The new Aggregate reader wrapper finalizes the cut for query and executor hydration. Duplicate command bindings, unselected frozen history, native roots and successful build causation remain checked.

Build/delivery preparation receives unpublished proof tokens bound to exact complete native prefix, selected admission/root/generation and proof tuples. Tokens are never durable or public authority. Any source change between mutable preparation and final append makes the root/callback retry. Existing native acceptance still resolves exact replay before current source reads, archive verification or candidate writes. Current personal authorization stays before retry. Historical build/delivery effects use explicitly selected versions; independent delivery children remain unchanged.

No event payload/discriminator/version, public DTO/route, source-use pair, receipt cutoff, archive output/publisher byte format, or callback protocol changes. Existing actual ZIP and publication tests are retained. `AuditPackageReader` now receives `IDomainEventReader` as third constructor dependency; SourceVerifier third, RecordBuildResult eighth, MaterializeDelivery sixth. Public four-argument `ReadAsync(tenant, program, package, ct)` remains; selection overload is internal and token-last. Snapshot/VerifiedBuild now expose an explicit external History snapshot. Owner Facts/FactById/VersionContent APIs are removed rather than aliased to a hidden history collection.

The actual-native test seed now requires `(reader, writer, events, content, view, ct)` for Write/Append; it selects and raw-verifies a fresh exact native owner before every append. `PackageSeeds.Configure(services, events)` supplies the same reader finalization to isolated fixture executors. Foreign fixture changes only pass their existing correct event source/reader. No acceptance names or assertions are removed.

## Applying and validating

- `behavioral-red.patch`: one standalone old-API test, no implementation dependency. It composes **32 legitimately built predecessor versions / 96 actual native facts** with existing Rules/PackageSeeds, then hydrates and measures retained owner collections. The earlier draft-only fixture was invalid because Amend requires a generated predecessor; root was explicitly told not to count that initial failure.
- `after-red.patch`: complete final source/test delta after that exact RED file is present.
- Alternatively `implementation.patch` + `tests.patch`, or `full.patch`, from the exact captured baselines.
- All three sequences reconstruct the same hashes (`reconstruction.json`).
- Root focused filter: `FullyQualifiedName~Features.AuditPackages|FullyQualifiedName~Features.Examinations.RecordManagement|FullyQualifiedName~Features.Examinations.RecordExaminationOutcome|FullyQualifiedName~TypeIIPeriodCommandHandlerTests`.
- Unit/API acceptance remains root-owned. New tests cover bounded command memory, captured historical version composition, missing/contradictory full source cuts, unselected direct append refusal, stale prepared build proof, and exact original build root.

`PersistenceServiceCollectionExtensions.cs` is the only drifted existing baseline at handoff: compose the **new AuditPackageManifestAggregateReader decoration and using only**, retaining root's current Advisor/Readiness/other wrappers. Never overwrite it wholesale. Root may have the temporary old-API boundary test installed; that is not an uncaptured preexisting file.

## Qualifications

This package is not runtime-qualified until root tests it. Existing legacy optional `OperationProvenance.FirstOwner == null` normalizes to its own manifest stream only for unchanged persisted native facts; all new root/seed producers explicitly write FirstOwner. No legacy event converter or migration authority is fabricated. Global/bare manifest/delivery lookup contracts remain outside this owning history change; current scoped Get/List are retained.

ExaminationEngagement still retains inline full views and lifetime baseline history. It is the separate next coherent native-owner/source/read stage, **not completed or externally blocked by this handoff**.
