from pathlib import Path
r=Path('/tmp/compliance-audit-package-history-prepared/work')
p=r/'test/Compliance.Tests/Testing/PackageSeeds.cs'
s=p.read_text().replace('using Cntryl.Portia;','using Cntryl.Portia;\nusing Microsoft.Extensions.DependencyInjection;')
a=s.index('    public static Task WriteAsync('); b=s.index('        var unit =',a)
s=s[:a]+'''    public static Task WriteAsync(IAggregateReader reader, IAggregateWriter writer, IDomainEventReader events,
        IImmutableContentStore content, AuditPackageView view, CancellationToken ct = default) =>
        SaveAsync(reader, writer, events, content, view, ct);
    public static Task AppendAsync(IAggregateReader reader, IAggregateWriter writer, IDomainEventReader events,
        IImmutableContentStore content, AuditPackageView view, CancellationToken ct = default) =>
        SaveAsync(reader, writer, events, content, view, ct);

    public static void Configure(IServiceCollection services, IDomainEventReader events)
    {
        var original = services.Last(item => !item.IsKeyedService && item.ServiceType == typeof(IAggregateReader));
        var key = new object();
        services.Remove(original);
        if (original.ImplementationInstance is { } instance)
            services.Add(ServiceDescriptor.KeyedSingleton(typeof(IAggregateReader), key, instance));
        else if (original.ImplementationFactory is { } factory)
            services.Add(ServiceDescriptor.DescribeKeyed(typeof(IAggregateReader), key,
                (provider, _) => factory(provider), original.Lifetime));
        else
            services.Add(ServiceDescriptor.DescribeKeyed(typeof(IAggregateReader), key,
                original.ImplementationType!, original.Lifetime));
        services.Add(ServiceDescriptor.Describe(typeof(IAggregateReader), provider =>
            new AuditPackageManifestAggregateReader(provider.GetRequiredKeyedService<IAggregateReader>(key), events),
            original.Lifetime));
    }

    static async Task SaveAsync(IAggregateReader reader, IAggregateWriter writer, IDomainEventReader events,
        IImmutableContentStore content, AuditPackageView view, CancellationToken ct)
    {
        var tenant = view.TenantId;
        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, view.AuditPackageId), ct);
        var history = await AuditPackageManifestHistory.ReadAsync(events, owner, ct);
        async Task SelectAsync(OperationProvenance operation, long version)
        {
            owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, view.AuditPackageId,
                operation.LogicalId, operation.CommandKind, version), ct);
            history = await AuditPackageManifestHistory.ReadAsync(events, owner, ct);
        }
        async Task SaveOwnerAsync()
        {
            await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
            owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, view.AuditPackageId), ct);
            history = await AuditPackageManifestHistory.ReadAsync(events, owner, ct);
        }
''' + s[b:]
s=s.replace('owner.VersionContent(version.PackageVersion) is null','!owner.HasVersion(version.PackageVersion)').replace('owner.Facts','history.Facts')
s=s.replace('await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);','await SaveOwnerAsync();')
# Undo replacement inside local save helper.
s=s.replace('async Task SaveOwnerAsync()\n        {\n            await SaveOwnerAsync();','async Task SaveOwnerAsync()\n        {\n            await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);')
s=s.replace('                Assert.True((version.PackageVersion == 1','                await SelectAsync(operation, version.PackageVersion);\n                Assert.True((version.PackageVersion == 1')
s=s.replace('                    Assert.True(owner.AdmitBuild','                    await SelectAsync(operation, version.PackageVersion);\n                    Assert.True(owner.AdmitBuild')
s=s.replace('                Assert.True(owner.RecordBuilt','                await SelectAsync(operationBuilt, version.PackageVersion);\n                var buildProof = AuditPackagePreparedProof.ForBuild(history, source, version.PackageVersion, build.BuildAttemptId);\n                Assert.True(buildProof.IsSuccess);\n                Assert.True(owner.RecordBuilt')
s=s.replace('source, successful, unitResult).IsSuccess','source, successful, unitResult, buildProof.Value!).IsSuccess')
s=s.replace('                    Assert.True(owner.RecordValidation','                    await SelectAsync(operation, version.PackageVersion);\n                    Assert.True(owner.RecordValidation')
s=s.replace('                    Assert.True(owner.ApproveOverride','                    await SelectAsync(operation, version.PackageVersion);\n                    Assert.True(owner.ApproveOverride')
s=s.replace('                Assert.True(owner.ApproveDisclosure','                await SelectAsync(operation, version.PackageVersion);\n                Assert.True(owner.ApproveDisclosure')
s=s.replace('                    Assert.True(owner.AdmitDelivery','                    await SelectAsync(operation, version.PackageVersion);\n                    var deliveryProof = AuditPackagePreparedProof.ForDelivery(history, version.PackageVersion,\n                        NativeFactReference.Of(owner.Stream, build), NativeFactReference.Of(owner.Stream, disclosure), proofs);\n                    Assert.True(deliveryProof.IsSuccess);\n                    Assert.True(owner.AdmitDelivery')
s=s.replace('proofs, response).IsSuccess','proofs, response, deliveryProof.Value!).IsSuccess')
s=s.replace('                if (reader is not null)\n                    child = await reader.HydrateAsync(child, ct);','                child = await reader.HydrateAsync(child, ct);')
s=s.replace('new string(\'a\', 64), at, owner.Stream, owner.Stream);',"new string('a', 64), at, owner.Stream, owner.Stream, owner.Stream);")
p.write_text(s)
p=r/'src/Compliance.Core/Features/AuditPackages/MaterializeRecordedAuditPackageDeliveryHandler.cs';s=p.read_text().replace('IImmutableContentStore content, TimeProvider clock)','IImmutableContentStore content, TimeProvider clock, IDomainEventReader events)').replace('var admitted = (AuditPackageDeliveryAdmitted)parent.FactById(command.Source.EventId)!;','var history = await AuditPackageManifestHistory.ReadAsync(events, parent, ct).ConfigureAwait(false);\n            var admitted = (AuditPackageDeliveryAdmitted)history.FactById(command.Source.EventId)!;');p.write_text(s)
p=r/'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.Operations;','using Bdgrz.Compliance.Features.Operations;\nusing Bdgrz.Compliance.Features.AuditPackages;').replace('        Decorate<IRequestBus>', '        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new AuditPackageManifestAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n        Decorate<IRequestBus>');p.write_text(s)
