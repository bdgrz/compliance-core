from pathlib import Path
import re,shutil
main=Path('/Users/jrepanich/Code/bdgrz/compliance-core'); root=Path('/tmp/compliance-audit-package-history-prepared'); work=root/'work'; base=root/'base'
foreign=['test/Compliance.Tests/Features/Examinations/RecordManagementRepresentationLetterHandlerTests.cs','test/Compliance.Tests/Features/Examinations/RecordExaminationOutcomeHandlerTests.cs','test/Compliance.Tests/Features/Examinations/RecordManagementExaminationReviewHandlerTests.cs','test/Compliance.Tests/Features/Examinations/RecordManagementAssertionHandlerTests.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.NativeOwners.cs']
for rel in foreign:
 if not (base/rel).exists():
  (base/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(main/rel,base/rel)
  (work/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(main/rel,work/rel)
# Replace calls with source expressions chosen from actual fixtures.
for p in work.rglob('*.cs'):
 s=p.read_text()
 if p.name=='PackageSeeds.cs':continue
 # Known actual fixture sources. Most owning tests share Amend fixture PeriodEvents.
 if p.name=='AuditPackageReadHandlerTests.cs': ev='fixture.Events'; own='Events'
 elif p.name=='RecordManagementAssertionHandlerTests.cs':ev='fixture.Events';own='Events'
 elif p.name=='TypeIIPeriodCommandHandlerTests.NativeOwners.cs':ev='fixture.Host.Events';own='Events'
 elif p.name=='AuditPackageManifestHistoryBoundaryTests.cs':ev='events';own='events'
 elif p.name in ('AuditPackageTests.cs','AuditPackageReadHttpTests.cs'):ev='events' if p.name=='AuditPackageTests.cs' else '_events';own=ev
 elif p.name=='SnapshotSourcePublicationTests.cs':ev='fixture.Events';own='Events'
 else:ev='fixture.PeriodEvents';own='PeriodEvents'
 s=s.replace('PackageSeeds.AppendAsync(fixture.Reader, fixture.Writer, ',f'PackageSeeds.AppendAsync(fixture.Reader, fixture.Writer, {ev}, ')
 s=s.replace('PackageSeeds.AppendAsync(Inner.Reader, Inner.Writer, ','PackageSeeds.AppendAsync(Inner.Reader, Inner.Writer, Inner.PeriodEvents, ')
 s=s.replace('PackageSeeds.AppendAsync(reader, writer, ','PackageSeeds.AppendAsync(reader, writer, events, ')
 s=s.replace('PackageSeeds.WriteAsync(Writer, ',f'PackageSeeds.WriteAsync(Reader, Writer, {own}, ')
 s=s.replace('PackageSeeds.WriteAsync(writer, ',f'PackageSeeds.WriteAsync(reader, writer, {ev}, ')
 s=s.replace('PackageSeeds.WriteAsync(fixture.Writer, ','PackageSeeds.WriteAsync(fixture.Reader, fixture.Writer, fixture.Host.Events, ')
 # constructors generally straightforward2args; complex inner fault stores handled after.
 for prefix,event in [('fixture.Inner.Reader','fixture.Inner.PeriodEvents'),('Inner.Reader','Inner.PeriodEvents'),('fixture.Reader',ev),('Reader',own),('reader','fixture.PeriodEvents' if p.name=='CreateAuditPackageHandlerTests.cs' else ev)]:
  for cls in ['AuditPackageReader','AuditPackageSourceVerifier']:
   pattern=r'new '+cls+r'\('+re.escape(prefix)+r', ([\w.]+)\)'
   s=re.sub(pattern,lambda m: 'new '+cls+'('+prefix+', '+m.group(1)+', '+event+')',s)
 if p.name=='AmendAuditPackageHandlerTests.cs':
  s=s.replace('public AuditPackageReader Packages => new(Reader, ContentStore);','public AuditPackageReader Packages => new(Reader, ContentStore, PeriodEvents);')
  s=s.replace('services.AddPortia();','services.AddPortia();\n            PackageSeeds.Configure(services, PeriodEvents);')
 if p.name=='AuditPackageTests.cs':
  s=s.replace('services.AddSingleton<IEventStore>(new InMemoryEventStore());','var events = new InMemoryEventStore();\n        services.AddSingleton<IEventStore>(events);')
 if p.name=='AuditPackageReadHttpTests.cs':
  s=s.replace('var writer = scope.ServiceProvider.GetRequiredService<IAggregateWriter>();','var writer = scope.ServiceProvider.GetRequiredService<IAggregateWriter>();\n            var reader = scope.ServiceProvider.GetRequiredService<IAggregateReader>();')
 p.write_text(s)
