from pathlib import Path
import difflib,hashlib,json,subprocess,tempfile,shutil,re
r=Path('/tmp/compliance-audit-package-history-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
changed=sorted(str(f.relative_to(r/'work')) for f in (r/'work').rglob('*') if f.is_file() and (not (r/'base'/f.relative_to(r/'work')).exists() or f.read_bytes()!=(r/'base'/f.relative_to(r/'work')).read_bytes()))
def diff(paths,before=None):
 text=''
 for path in paths:
  b=(before or {}).get(path, (r/'base'/path).read_bytes() if (r/'base'/path).exists() else b'')
  a=(r/'work'/path).read_bytes()
  text+=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+path if b else '/dev/null',tofile='b/'+path))
 return text
sources=[p for p in changed if p.startswith('src/')];tests=[p for p in changed if p.startswith('test/')]
redfile='test/Compliance.Tests/Features/AuditPackages/AuditPackageManifestHistoryBoundaryTests.cs'
oldred=(r/'work'/redfile).read_text().replace('PackageSeeds.WriteAsync(reader, writer, events, content,','PackageSeeds.WriteAsync(writer, content,').replace('PackageSeeds.AppendAsync(reader, writer, events, content,','PackageSeeds.AppendAsync(reader, writer, content,')
(r/'behavioral-red.patch').write_text(''.join(difflib.unified_diff([],oldred.splitlines(True),fromfile='/dev/null',tofile='b/'+redfile)))
for name,paths,before in [('full.patch',changed,None),('implementation.patch',sources,None),('tests.patch',tests,None),('after-red.patch',changed,{redfile:oldred.encode()})]:
 (r/name).write_text(diff(paths,before))
manifest=[]
for p in changed:
 b=(r/'base'/p).read_bytes() if (r/'base'/p).exists() else None;a=(r/'work'/p).read_bytes()
 manifest.append({'path':p,'before':sha(b) if b is not None else None,'after':sha(a),'kind':'source' if p.startswith('src/') else 'test','currentMainMatchesBefore':((repo/p).read_bytes()==b) if (repo/p).exists() else b is None})
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checks=[]
for name,seq in [('full',['full.patch']),('partitioned',['tests.patch','implementation.patch']),('red-then-green',['behavioral-red.patch','after-red.patch'])]:
 with tempfile.TemporaryDirectory(prefix='audit-package-reconstruct-') as d:
  d=Path(d)
  for p in changed:
   b=r/'base'/p
   if b.exists():(d/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b,d/p)
  for patch in seq:
   proc=subprocess.run(['patch','--batch','-p1','-d',str(d),'-i',str(r/patch)],capture_output=True,text=True)
   if proc.returncode:raise SystemExit((name,patch,proc.stdout,proc.stderr))
  mismatches=[p for p in changed if not (d/p).exists() or (d/p).read_bytes()!=(r/'work'/p).read_bytes()]
  if mismatches:raise SystemExit((name,mismatches))
  checks.append({'sequence':name,'exactFiles':len(changed),'passed':True})
(r/'reconstruction.json').write_text(json.dumps(checks,indent=2)+'\n')
newtests=[]
for p in tests:
 before=(r/'base'/p).read_text() if (r/'base'/p).exists() else''
 after=(r/'work'/p).read_text()
 old=set(re.findall(r'\b(Should\w+)\s*\(',before))
 newtests += [{'path':p,'name':n} for n in re.findall(r'\b(Should\w+)\s*\(',after) if n not in old]
print(json.dumps({'changed':len(changed),'source':len(sources),'tests':len(tests),'newMethods':len(newtests),'driftedBaseline':[m['path'] for m in manifest if not m['currentMainMatchesBefore']],'patchHashes':{p:sha((r/p).read_bytes()) for p in ['behavioral-red.patch','implementation.patch','tests.patch','after-red.patch','full.patch']},'reconstruction':checks},indent=2))
