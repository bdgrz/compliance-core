from pathlib import Path
p=Path('/tmp/compliance-finding-native-prepared/work/src/Compliance.Core/Features/Remediation')
f=p/'FindingClosureFailureProof.cs';f.write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Remediation;

/// <summary>The permanent mismatch bound to one exact closure admission, intent, root and generation.</summary>
public sealed record FindingClosureFailureProof(Uuid ProgramId, Uuid FindingId, string Reason, Uuid? ActionId,
    NativeFactReference Admission, ImmutableContentRef Intent, Uuid RootOperationId, long Generation);
''')
f=p/'FindingContent.cs';s=f.read_text().replace('FindingClosureCanceled.FailureProof.v1','FindingClosureCanceled.FailureProof.v2');f.write_text(s)
f=p/'FindingClosureFences.cs';s=f.read_text().replace('                actionId), ct)','                actionId, source, intentReference, intent.Header.RootOperationId, (long)intent.ParentGeneration), ct)');f.write_text(s)
f=p/'AbortFindingClosureHandler.cs';s=f.read_text();needle='''        catch (ImmutableContentIntegrityException exception)
        {
            return SourceUseReceiverSupport.Permanent($"The failure proof cannot be verified: {exception.Message}");
        }''';s=s.replace(needle,'''        catch (ImmutableContentUnavailableException exception)
        {
            return SourceUseReceiverSupport.Transient($"The failure proof is not available yet: {exception.Message}");
        }
'''+needle)
s=s.replace('''        var stream = new FindingAggregate(tenant, proof.ProgramId, proof.FindingId).Stream;''','''        if (command.FailureProof.Schema != FindingContent.FailureSchema || proof.ProgramId == Uuid.Empty ||
            proof.FindingId == Uuid.Empty || proof.RootOperationId != command.OperationId ||
            proof.Generation != command.Generation || string.IsNullOrWhiteSpace(proof.Reason))
            return SourceUseReceiverSupport.Permanent("The failure proof is not bound to this exact closure operation.");
        var stream = new FindingAggregate(tenant, proof.ProgramId, proof.FindingId).Stream;''')
needle='''                if (accepted.Generation != command.Generation ||
                    intent.Header.RootOperationId != command.OperationId)
                    return SourceUseReceiverSupport.Permanent("The abort differs from the accepted closure.");''';assert needle in s
s=s.replace(needle,'''                if (accepted.Generation != command.Generation || intent.Header.RootOperationId != command.OperationId ||
                    proof.Admission != NativeFactReference.Of(finding.Stream, accepted) || proof.Intent != accepted.Intent ||
                    intent.Header.FirstOwner != finding.Stream || intent.ParentKind != ClosureParentKind.Finding ||
                    intent.ParentId != proof.FindingId || intent.ParentGeneration != (ulong)command.Generation)
                    return SourceUseReceiverSupport.Permanent("The abort differs from the exact accepted closure proof.");
                if (proof.ActionId is { } actionId)
                {
                    IReadOnlyList<AdmittedChild> children;
                    try
                    {
                        children = await ImmutableSelectionManifests.ReadAsync<AdmittedChild>(content, tenant.ToString(),
                            intent.AdmittedChildren, ct).ConfigureAwait(false);
                    }
                    catch (ImmutableContentIntegrityException exception)
                    {
                        return Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict,
                            $"The frozen admitted action set cannot be verified: {exception.Message}",
                            exception is ImmutableContentUnavailableException));
                    }
                    if (children.All(child => child.ChildId != actionId))
                        return SourceUseReceiverSupport.Permanent("The failure proof action is outside the frozen closure selection.");
                }''')
s=s.replace('''                catch (ImmutableContentIntegrityException exception)
                {
                    return SourceUseReceiverSupport.Permanent($"The frozen closure cannot be verified: {exception.Message}");
                }''','''                catch (ImmutableContentIntegrityException exception)
                {
                    return Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict,
                        $"The frozen closure cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException));
                }''')
f.write_text(s)
# Missing immutable frozen settlement selections remain retryable; corruption remains permanent.
for name,phrase in [('SettleCorrectiveActionFindingClosureUseHandler','The frozen closure source uses'),('FindingClosureFences','The admitted action manifest')]:
 f=p/(name+'.cs');s=f.read_text();mark='        catch (ImmutableContentIntegrityException exception)\n        {';a=s.index(mark)
 if name=='SettleCorrectiveActionFindingClosureUseHandler':
  b=s.index('\n        }',a)+len('\n        }');s=s[:a]+'''        catch (ImmutableContentIntegrityException exception)
        {
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen closure source uses cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException));
        }'''+s[b:]
 else:
  b=s.index('\n        }',a)+len('\n        }');s=s[:a]+'''        catch (ImmutableContentIntegrityException exception)
        {
            return Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The admitted action manifest cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException));
        }'''+s[b:]
 f.write_text(s)
