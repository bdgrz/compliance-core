from pathlib import Path
p=Path('/tmp/compliance-finding-native-prepared/work/test/Compliance.Tests/Features/Remediation');p.mkdir(parents=True,exist_ok=True)
p.joinpath('FindingCancellationProofBindingTests.cs').write_text('''using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Tests.Features.Operations;
using Bdgrz.Compliance.Tests.Features.Readiness;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.Remediation;

public sealed class FindingCancellationProofBindingTests
{
    [Fact]
    public async Task ShouldPreserveLaterPendingClosureAndHeldSourcesGivenEarlierUnboundFailureProof()
    {
        // Arrange: an unfinished action causes the first real closure to cancel and settle.
        var fixture = await OperationsFixture.CreateAsync();
        await using var provider = fixture.Provider;
        var finding = await fixture.RaiseFindingAsync(fixture.OwnerMemberId);
        finding = await fixture.AddActionAsync(finding, fixture.OwnerMemberId, fixture.Today.AddDays(7));
        var actionId = Assert.Single(finding.CorrectiveActions).ActionId;
        var first = fixture.Close(finding);
        await PersonalReadinessClosureTransportTests.CloseHttpAsync(provider, fixture.ApproverUserId, first);
        Assert.Equal(ProcessState.Completed, (await fixture.RunClosureAsync(finding.FindingId, first.CommandId)).State);
        finding = await fixture.GetFindingAsync(finding.FindingId);
        finding = await fixture.CompleteActionAsync(fixture.OwnerUserId, finding, actionId);
        var later = fixture.Close(finding);
        await PersonalReadinessClosureTransportTests.CloseHttpAsync(provider, fixture.ApproverUserId, later);
        var process = await fixture.StartClosureAsync(finding.FindingId, later.CommandId);
        var acquire = await fixture.ClosureStepAsync(process, "acquire", nameof(AuthorizeCorrectiveActionFindingClosureUse),
            Assert.Single(process.Targets));
        Assert.IsType<ReceiverOutcome.Applied>((await fixture.SendReceiverAsync(acquire)).Value);
        var held = await fixture.ActionAsync(finding.FindingId, actionId);
        Assert.True(held.Uses.HasActiveUse);
        // This is the actual old four-field proof shape. It has no binding to the earlier root or admission.
        var bytes = JsonSerializer.SerializeToUtf8Bytes(new
        {
            program_id = fixture.ProgramId.ToString(), finding_id = finding.FindingId.ToString(),
            reason = "The earlier action was not completed.", action_id = actionId.ToString(),
        });
        var oldProof = await fixture.Content.WriteVerifiedAsync(fixture.TenantId.ToString(), Uuid.CreateVersion4(),
            FindingContent.FailureSchema, "application/json", bytes);
        var stream = await fixture.FindingStreamAsync(finding.FindingId);
        var abort = new AbortFindingClosure(Uuid.CreateVersion4(), later.CommandId, stream.Stream,
            stream.Generation, 0, oldProof);

        // Act
        var refused = await fixture.SendReceiverAsync(abort);
        var after = await fixture.FindingStreamAsync(finding.FindingId);
        var stillHeld = await fixture.ActionAsync(finding.FindingId, actionId);

        // Assert
        Assert.False(refused.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, refused.Error!.Kind);
        Assert.False(refused.Error.IsTransient);
        Assert.Equal(later.CommandId, after.PendingClosure!.Operation.RootOperationId);
        Assert.Equal(stream.Version, after.Version);
        Assert.True(stillHeld.Uses.HasActiveUse);
        Assert.Equal(held.Version, stillHeld.Version);
    }
}
''')
p.joinpath('FindingNativeHistoryTests.cs').write_text('''using System.Collections;
using System.Reflection;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.Remediation;

public sealed class FindingNativeHistoryTests
{
    [Fact]
    public void ShouldKeepBoundedCommandAuthorityGivenManyCanceledClosureAttempts()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var id = Uuid.CreateVersion4();
        var actionId = Uuid.CreateVersion4();
        var source = new FindingAggregate(tenant, program, id, actionId);
        var actor = ActorReference.ForMember(Uuid.CreateVersion4(), "Lead");
        var terms = new FindingRaiseTerms(new FindingSource("manual", null, null, "Original source text."),
            "Retained access", "Access survived offboarding.", "high", "VPN", Uuid.CreateVersion4(),
            new DateOnly(2026, 10, 15), actor, NativeFacts.Now);
        Assert.True(source.Raise(NativeFacts.Root(source, id, nameof(RaiseFinding), null), terms,
            NativeFacts.Ref(FindingContent.LinksSchema), NativeFacts.Ref(), NativeFacts.Ref(), null).IsSuccess);
        Assert.True(source.AdmitAction(NativeFacts.Root(source, actionId, nameof(AddCorrectiveAction), 1),
            NativeFacts.Ref(ChildAdmissionIntent.Schema), NativeFacts.Ref()).IsSuccess);
        for (var index = 0; index < 128; index++)
        {
            var root = Uuid.CreateVersion4();
            var operation = NativeFacts.Root(source, root, nameof(CloseFinding), source.Revision);
            Assert.True(source.AcceptClosure(operation, NativeFacts.Ref(ClosureIntent.Schema), NativeFacts.Ref()).IsSuccess);
            var child = operation with
            {
                LogicalId = Uuid.CreateVersion4(), CommandKind = nameof(AbortFindingClosure),
                CausationEventId = source.PendingClosure!.Metadata.EventId,
            };
            Assert.True(source.CancelClosure(child, NativeFacts.Ref(FindingContent.FailureSchema)).IsSuccess);
        }
        var facts = NativeFacts.Raised(source);

        // Act
        var owner = NativeFacts.Replay(new FindingAggregate(tenant, program, id), facts);
        var retained = typeof(FindingAggregate).GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
            .Where(field => field.GetValue(owner) is ICollection { Count: > 1 }).ToArray();

        // Assert
        Assert.Empty(retained);
        Assert.Equal(258, owner.Revision);
        Assert.Equal(1, owner.Generation);
        Assert.Null(owner.PendingClosure);
        Assert.Null(owner.Closed);
        Assert.Equal("Original source text.", owner.Raised!.Source.SourceText);
        Assert.Equal((ulong)facts.Length, owner.Version);
    }
}
''')
p.joinpath('FindingNativePreparationTests.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Remediation;
using Bdgrz.Compliance.Tests.Features.Operations;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Remediation;

public sealed class FindingNativePreparationTests
{
    [Fact]
    public async Task ShouldAdmitActionOnRetryGivenPriorPreparationContentWasWrittenBeforeAdmissionFailed()
    {
        // Arrange
        var fixture = await OperationsFixture.CreateAsync();
        await using var provider = fixture.Provider;
        var finding = await fixture.RaiseFindingAsync(fixture.OwnerMemberId);
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var executor = services.GetRequiredService<IAggregateExecutor>();
        var content = new LostPreparation(fixture.Content);
        var clock = new MovingClock();
        var request = new AddCorrectiveAction(Uuid.CreateVersion4(), fixture.TenantId, fixture.ProgramId,
            finding.FindingId, finding.Revision, "Remove stale access.", fixture.OwnerMemberId, fixture.Today.AddDays(7));
        var handler = new AddCorrectiveActionHandler(new NativeOperationExecutor(reader, executor, content), reader,
            content, clock);
        var context = new RequestContext<AddCorrectiveAction>(request, ProgramManagementServices.Actor(fixture.LeadUserId));
        await Assert.ThrowsAsync<IOException>(async () => await handler.HandleAsync(context, CancellationToken.None));
        Assert.Equal(finding.Revision, (await fixture.FindingStreamAsync(finding.FindingId)).Revision);
        clock.Now = clock.Now.AddDays(1);

        // Act
        var retry = await handler.HandleAsync(context, CancellationToken.None);
        var after = await fixture.FindingStreamAsync(finding.FindingId);

        // Assert
        Assert.True(retry.IsSuccess, retry.Error?.Message);
        Assert.Equal(request.ActionId, retry.Value!.OperationId);
        Assert.Equal(clock.Now, retry.Value.AcceptedAt);
        Assert.Equal(finding.Revision + 1, after.Revision);
        Assert.Equal(1, content.Interruptions);
    }

    sealed class LostPreparation(IImmutableContentStore inner) : IImmutableContentStore
    {
        bool _armed = true;
        public int Interruptions { get; private set; }
        public async Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema,
            string mediaType, ReadOnlyMemory<byte> bytes, CancellationToken ct = default)
        {
            var reference = await inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
            if (_armed && schema == FindingContent.AcknowledgmentSchema)
            {
                _armed = false;
                Interruptions++;
                throw new IOException("The connection was lost after preparation bytes were stored, before native admission.");
            }
            return reference;
        }
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference,
            CancellationToken ct = default) => inner.ReadVerifiedAsync(realm, reference, ct);
    }

    sealed class MovingClock : TimeProvider
    {
        public DateTimeOffset Now { get; set; } = DateTimeOffset.UtcNow;
        public override DateTimeOffset GetUtcNow() => Now;
    }
}
''')
