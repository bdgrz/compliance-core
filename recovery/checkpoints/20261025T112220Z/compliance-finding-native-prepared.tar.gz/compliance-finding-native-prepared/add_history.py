from pathlib import Path
p=Path('/tmp/compliance-finding-native-prepared/work/src/Compliance.Core/Features/Remediation')
p.joinpath('FindingHistorySnapshot.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Remediation;

/// <summary>Explicit verified read composition; these historical collections are never retained by command authority.</summary>
public sealed class FindingHistorySnapshot(IReadOnlyList<DomainEvent> facts)
{
    /// <summary>All native finding facts at the verified exact physical cut.</summary>
    public IReadOnlyList<DomainEvent> Facts { get; } = facts;
    /// <summary>Every admitted child in original admission order.</summary>
    public IReadOnlyList<CorrectiveActionAdmitted> Admitted => Facts.OfType<CorrectiveActionAdmitted>().ToArray();
    /// <summary>Every recorded acceptance link.</summary>
    public IReadOnlyList<FindingAcceptanceLinkedV2> Acceptances => Facts.OfType<FindingAcceptanceLinkedV2>().ToArray();
    /// <summary>Every closed generation, including superseded closures.</summary>
    public IReadOnlyList<FindingClosedV2> ClosureHistory => Facts.OfType<FindingClosedV2>().ToArray();
    /// <summary>The exact immutable source fact.</summary>
    public DomainEvent? FactById(Uuid eventId) => Facts.FirstOrDefault(fact => fact.Metadata.EventId == eventId);
    /// <summary>The exact historical closure admission.</summary>
    public FindingClosureAccepted? AcceptedClosure(Uuid rootOperationId) => Facts.OfType<FindingClosureAccepted>()
        .FirstOrDefault(fact => fact.Operation.RootOperationId == rootOperationId);
    /// <summary>The exact historical closure decision or cancellation.</summary>
    public DomainEvent? TerminalClosure(Uuid rootOperationId) => Facts.FirstOrDefault(fact => fact switch
    {
        FindingClosedV2 closed => closed.Operation.RootOperationId == rootOperationId,
        FindingClosureCanceled canceled => canceled.Operation.RootOperationId == rootOperationId,
        _ => false,
    });
}
''')
p.joinpath('FindingHistory.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Remediation;

/// <summary>Verifies full immutable finding history transiently at a compact owner's exact hydrated cut.</summary>
public static class FindingHistory
{
    /// <summary>Reads complete history and verifies scope, predecessor, unique identities and current compact authority.</summary>
    public static async Task<FindingHistorySnapshot> ReadAsync(IDomainEventReader events, FindingAggregate owner,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(owner);
        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, owner, ct).ConfigureAwait(false);
        if (facts.Count != owner.Revision || facts.Count > 0 && (owner.Latest is null ||
            ContentDigest.Sha256(facts[^1], facts[^1].GetType()) != ContentDigest.Sha256(owner.Latest, owner.Latest.GetType())))
            throw Invalid("The finding history differs from its exact hydrated cut.");
        var operations = new HashSet<Uuid>();
        var actions = new HashSet<Uuid>();
        var closures = new HashSet<Uuid>();
        long generation = 0;
        FindingClosureAccepted? pending = null;
        FindingClosedV2? closed = null;
        for (var index = 0; index < facts.Count; index++)
        {
            var fact = facts[index];
            if (fact is not INativeOperationFact native || native.Operation.Owner != owner.Stream ||
                native.Operation.LogicalId == Uuid.Empty || !operations.Add(native.Operation.LogicalId))
                throw Invalid("The finding history has another owner or repeats a logical operation.");
            var operation = native.Operation;
            var revision = index + 1L;
            var writable = index > 0 && pending is null && closed is null;
            var valid = false;
            switch (fact)
            {
                case FindingRaisedV2 raised:
                    valid = index == 0 && Scope(raised.TenantId, raised.ProgramId, raised.FindingId) &&
                        raised.Revision == 1 && operation.LogicalId == owner.FindingId;
                    generation = 1;
                    break;
                case FindingRevisedV2 revised:
                    valid = writable && Scope(revised.TenantId, revised.ProgramId, revised.FindingId) &&
                        revised.Revision == revision;
                    break;
                case CorrectiveActionAdmitted admitted:
                    valid = writable && admitted.Owner == owner.Stream && admitted.Revision == revision &&
                        admitted.Generation == generation && actions.Add(operation.LogicalId);
                    break;
                case FindingAcceptanceLinkedV2 linked:
                    valid = writable && Scope(linked.TenantId, linked.ProgramId, linked.FindingId) &&
                        linked.Revision == revision;
                    break;
                case FindingClosureAccepted accepted:
                    valid = writable && actions.Count > 0 && accepted.Owner == owner.Stream &&
                        accepted.Revision == revision && accepted.Generation == generation &&
                        operation.RootOperationId == operation.LogicalId && closures.Add(operation.RootOperationId);
                    pending = accepted;
                    break;
                case FindingClosedV2 finished:
                    valid = pending is not null && Scope(finished.TenantId, finished.ProgramId, finished.FindingId) &&
                        finished.Revision == revision && finished.FindingGeneration == generation &&
                        finished.Intent == pending.Intent && operation.RootOperationId == pending.Operation.RootOperationId;
                    pending = null;
                    closed = finished;
                    break;
                case FindingClosureCanceled canceled:
                    valid = pending is not null && canceled.Owner == owner.Stream && canceled.Revision == revision &&
                        canceled.Generation == generation && canceled.Intent == pending.Intent &&
                        operation.RootOperationId == pending.Operation.RootOperationId;
                    pending = null;
                    break;
                case FindingReopenedV2 reopened:
                    valid = index > 0 && closed is not null && Scope(reopened.TenantId, reopened.ProgramId,
                        reopened.FindingId) && reopened.Revision == revision;
                    closed = null;
                    generation++;
                    break;
            }
            if (!valid)
                throw Invalid("The finding history contains another scope, predecessor, action identity or closure generation.");
        }
        if (generation != owner.Generation || actions.Count != owner.AdmittedCount ||
            pending?.Metadata.EventId != owner.PendingClosure?.Metadata.EventId ||
            closed?.Metadata.EventId != owner.Closed?.Metadata.EventId)
            throw Invalid("The finding history does not reproduce current compact authority.");
        return new FindingHistorySnapshot(facts);

        bool Scope(Uuid tenant, Uuid program, Uuid finding) => tenant == owner.TenantId &&
            program == owner.ProgramId && finding == owner.FindingId;
    }

    static ImmutableContentIntegrityException Invalid(string message) => new(message);
}
''')
