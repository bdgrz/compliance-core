from pathlib import Path
p=Path('/tmp/compliance-finding-native-prepared/work/src/Compliance.Core/Features/Remediation')
for name,outtype,logical in [('RaiseFindingHandler','FindingRegistration','request.FindingId'),('ReviseFindingHandler','FindingView','request.CommandId'),('ReopenFindingHandler','FindingView','request.CommandId'),('LinkFindingAcceptanceHandler','FindingView','request.CommandId'),('AddCorrectiveActionHandler','OperationAcceptedResponse','request.ActionId')]:
 f=p/(name+'.cs');s=f.read_text();a=s.index('        var snapshot = await reader.HydrateAsync(');b=s.index('        var provenance =',a)
 s=s[:a]+'''        var snapshot = new FindingAggregate(request.TenantId, request.ProgramId,
            request.FindingId, '''+logical+''');
'''+s[b:]
 s=s.replace('FindingCommands.Digest(request), now);','FindingCommands.Digest(request), now) with { FirstOwner = snapshot.Stream };')
 a=s.index('        if (snapshot.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');start=s.index('\n        {',a)+len('\n        {');end=s.index('\n        }\n\n        var outcome =',start)
 body=s[start:end].replace('snapshot.', 'owner.').replace('ComposeAsync(snapshot,','ComposeAsync(owner,').replace(', ct)', ', token)').replace(', ct\n', ', token\n').replace('Result<'+outtype+'>.Failure','Result<FirstResponseDescriptor>.Failure')
 if name=='AddCorrectiveActionHandler':body=body.replace('return Failure(RequestErrorKind.Conflict, "A corrective action identity cannot be reused.");','return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,\n                    "A corrective action identity cannot be reused."));')
 s=s[:a]+'''        async ValueTask<Result<FirstResponseDescriptor>> PrepareAsync(FindingAggregate owner, CancellationToken token)
        {'''+body+'''
            return Result<FirstResponseDescriptor>.Success(response!);
        }
'''+s[end+len('\n        }'):]
 if name=='RaiseFindingHandler':s=s.replace('finding => FindingCommands.Prepared(finding.PrepareRaise(), response),','PrepareAsync,')
 else:
  import re
  s=re.sub(r'finding => FindingCommands.Prepared\(finding.Prepare(?:Write|Reopen)\(request\.(?:ExpectedRevision|ExpectedFindingRevision)\), response\),','PrepareAsync,',s)
 if name in ['ReviseFindingHandler','ReopenFindingHandler']:
  s=s.replace('NativeOperationExecutor operations, IAggregateReader reader,\n    FindingReader findings','NativeOperationExecutor operations, FindingReader findings')
 s=s.replace('\n\n\n','\n\n');f.write_text(s)
f=p/'CloseFindingHandler.cs';s=f.read_text().replace('NativeOperationExecutor operations, IAggregateReader reader,','NativeOperationExecutor operations, IDomainEventReader events,')
a=s.index('        var snapshot = await reader.HydrateAsync(');b=s.index('        var provenance =',a)
s=s[:a]+'''        var snapshot = new FindingAggregate(request.TenantId, request.ProgramId,
            request.FindingId, request.CommandId);
'''+s[b:]
s=s.replace('FindingCommands.Digest(request), now);','FindingCommands.Digest(request), now) with { FirstOwner = snapshot.Stream };')
a=s.index('        if (snapshot.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');b=s.index('\n        var outcome =',a)
s=s[:a]+'''        async ValueTask<Result<FirstResponseDescriptor>> PrepareAsync(FindingAggregate owner, CancellationToken token)
        {
            var frozen = await FreezeAsync(request, owner, provenance, actor, actorReference, now, token)
                .ConfigureAwait(false);
            if (!frozen.IsSuccess)
                return Result<FirstResponseDescriptor>.Failure(frozen.Error!);
            (intent, response) = frozen.Value;
            return Result<FirstResponseDescriptor>.Success(response);
        }
'''+s[b:]
s=s.replace('finding => FindingCommands.Prepared(finding.PrepareClosure(request.ExpectedRevision), response),','PrepareAsync,')
s=s.replace('        var owners = new List<Uuid> { finding.OwnerMemberId };','        var source = await FindingHistory.ReadAsync(events, finding, ct).ConfigureAwait(false);\n        var owners = new List<Uuid> { finding.OwnerMemberId };').replace('finding.Admitted','source.Admitted')
s=s.replace('$"The admitted action cannot be verified yet: {exception.Message}",\n                    true)','$"The admitted action cannot be verified: {exception.Message}",\n                    exception is ImmutableContentUnavailableException)');f.write_text(s)
