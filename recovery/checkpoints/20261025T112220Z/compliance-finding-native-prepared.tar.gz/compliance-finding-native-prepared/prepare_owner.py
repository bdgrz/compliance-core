from pathlib import Path
import shutil,re
p=Path('/tmp/compliance-finding-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');prior=Path('/tmp/compliance-corrective-action-prepared/work')
paths=['FindingAggregate.cs','FindingReader.cs','FindingClosure.cs','FindingClosureVerifier.cs','AddCorrectiveActionHandler.cs','CloseFindingHandler.cs','RaiseFindingHandler.cs','RaiseOccurrenceFindingHandler.cs','ReviseFindingHandler.cs','ReopenFindingHandler.cs','LinkFindingAcceptanceHandler.cs','CompleteFindingClosureHandler.cs','AbortFindingClosureHandler.cs','AuthorizeCorrectiveActionFindingClosureUseHandler.cs','SettleCorrectiveActionFindingClosureUseHandler.cs','MaterializeCorrectiveActionHandler.cs','FindingClosureFences.cs','FindingClosureFailureProof.cs','FindingContent.cs','RoutedFinding.cs']
paths=['src/Compliance.Core/Features/Remediation/'+x for x in paths]+['src/Compliance.Core/Features/Examinations/FindingTypeIBaselineSourceContributor.cs','test/Compliance.Tests/Features/Operations/OperationsFixture.cs','test/Compliance.Tests/Features/Remediation/FindingClosureTests.cs','test/Compliance.Tests/Features/Remediation/OccurrenceFindingTests.cs','test/Compliance.Tests/Features/Remediation/FindingClosureContentRecoveryTests.cs','test/Compliance.Tests/Features/Remediation/FindingProcessReactorTests.cs','test/Compliance.Tests/Features/Remediation/FindingIdentifiedOperationTests.cs','test/Compliance.Tests/Testing/FindingProcesses.cs','test/Compliance.Tests/Testing/FindingSeed.cs']
for rel in paths:
 src=prior/rel if (prior/rel).exists() else repo/rel
 if not src.exists():continue
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,f)
f=p/'work/src/Compliance.Core/Features/Remediation/FindingAggregate.cs';s=f.read_text()
a=s.index('    readonly List<CorrectiveActionAdmitted>');b=s.index('    FindingRaisedV2?',a)
s=s[:a]+'''    readonly Uuid _selectedClosureRoot;
    CorrectiveActionAdmitted? _selectedAdmission;
    FindingClosureAccepted? _selectedClosure;
    DomainEvent? _selectedTerminal;
    DomainEvent? _latest;
    long _admittedCount;
'''+s[b:]
s=s.replace('Uuid selectedLogicalId = default)','Uuid selectedLogicalId = default,\n        Uuid selectedClosureRoot = default)').replace('        Acceptance = new NativeAcceptance(selectedLogicalId);','        Acceptance = new NativeAcceptance(selectedLogicalId);\n        _selectedClosureRoot = selectedClosureRoot;')
a=s.index('    /// <summary>The corrective actions admitted so far');b=s.index('    /// <summary>Checks that the finding can take an ordinary write',a)
s=s[:a]+'''    /// <summary>The number of admitted actions across this finding's generations.</summary>
    public long AdmittedCount => _admittedCount;

    /// <summary>The closure accepted and not yet closed or canceled, which seals action admission.</summary>
    public FindingClosureAccepted? PendingClosure => _pending;

    /// <summary>The closure fact of the current generation; null while open or after a reopen.</summary>
    public FindingClosedV2? Closed => _closed;

    /// <summary>The latest committed native fact of this owner.</summary>
    public DomainEvent? Latest => _latest;

    /// <summary>The tenant of this finding.</summary>
    public Uuid TenantId => _tenantId;

    /// <summary>Whether the selected logical action identity has already been admitted.</summary>
    public bool HasAdmitted(Uuid actionId) => actionId == Acceptance.SelectedLogicalId
        ? _selectedAdmission is not null
        : throw new InvalidOperationException("Select the action identity before hydrating its admission guard.");

    /// <summary>The pending or explicitly selected historical closure admission.</summary>
    public FindingClosureAccepted? AcceptedClosure(Uuid rootOperationId) =>
        _pending?.Operation.RootOperationId == rootOperationId ? _pending
        : _selectedClosureRoot == rootOperationId ? _selectedClosure
        : throw new InvalidOperationException("Select the historical closure root before hydrating it.");

    /// <summary>The explicitly selected closure terminal fact; absence is relative to this exact hydrated cut.</summary>
    public DomainEvent? TerminalClosure(Uuid rootOperationId) => _selectedClosureRoot == rootOperationId
        ? _selectedTerminal
        : throw new InvalidOperationException("Select the historical closure root before hydrating its terminal fact.");

'''+s[b:]
s=s.replace('_admitted.Count == 0','_admittedCount == 0').replace('_admittedIds.Contains(operation.LogicalId)','HasAdmitted(operation.LogicalId)')
s=s.replace(' ||\n            !_admittedIds.Add(ev.Operation.LogicalId)', ' ||\n            ev.Operation.LogicalId == Acceptance.SelectedLogicalId && _selectedAdmission is not null')
s=s.replace('        _admitted.Add(ev);','        _admittedCount = checked(_admittedCount + 1);\n        if (ev.Operation.LogicalId == Acceptance.SelectedLogicalId)\n            _selectedAdmission = ev;')
s=s.replace('        _acceptances.Add(ev);\n','').replace(' ||\n            !_accepted.TryAdd(ev.Operation.RootOperationId, ev)', ' ||\n            ev.Operation.RootOperationId == _selectedClosureRoot && _selectedClosure is not null')
s=s.replace('        _pending = ev;','        _pending = ev;\n        if (ev.Operation.RootOperationId == _selectedClosureRoot)\n            _selectedClosure = ev;')
s=s.replace('        _terminal[ev.Operation.RootOperationId] = ev;','        if (ev.Operation.RootOperationId == _selectedClosureRoot)\n            _selectedTerminal = ev;').replace('        _closures.Add(ev);\n','').replace('_facts.Add(ev);','_latest = ev;').replace('_facts.Add(fact);','_latest = fact;')
assert not any(x in s for x in ['_facts','_admittedIds','_acceptances','_closures','_accepted.','_terminal[','_admitted.'])
f.write_text(s)
