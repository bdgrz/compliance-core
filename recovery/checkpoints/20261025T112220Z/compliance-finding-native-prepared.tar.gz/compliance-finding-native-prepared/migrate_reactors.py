from pathlib import Path
import shutil
p=Path('/tmp/compliance-finding-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');d=p/'work/src/Compliance.Core/Features/Remediation'
for name in ['FindingClosureReactor','CorrectiveActionMaterializationReactor','ControlOccurrenceFindingReactor','IndependentChildMaterialization']:
 rel='src/Compliance.Core/Features/Remediation/'+name+'.cs'
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,f)
d.joinpath('FindingReactorSources.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Remediation;

/// <summary>Verifies the exact committed typed trigger, including its actual physical source position, before any reaction.</summary>
internal static class FindingReactorSources
{
    public static async Task VerifyAsync<TEvent>(ISourceFactResolver resolver, IImmutableContentStore content,
        EventStreamPattern pattern, IReactorContext<TEvent> context, EventStreamAddress expected,
        CancellationToken ct) where TEvent : DomainEvent
    {
        if (pattern.IsTenantTemplate || pattern.Realm != expected.Realm || context.Source.Stream != expected ||
            context.Trigger is not INativeOperationFact native || native.Operation.Owner != expected ||
            context.Source.Event.GetType() != typeof(TEvent) || context.Trigger.Metadata.IsAudit)
            throw new ImmutableContentIntegrityException("The remediation reaction has another exact tenant or native source owner.");
        var (_, actual, _) = await SourceFactProofs.BuildAsync<TEvent>(resolver, content, expected.Realm,
            NativeFactReference.Of(expected, context.Trigger), context.Source.ResourceOffset, ct).ConfigureAwait(false);
        if (actual.Metadata != context.Trigger.Metadata || actual.Metadata != context.Source.Event.Metadata ||
            ContentDigest.Sha256(actual, typeof(TEvent)) != ContentDigest.Sha256(context.Trigger, typeof(TEvent)) ||
            ContentDigest.Sha256(actual, typeof(TEvent)) != ContentDigest.Sha256(context.Source.Event, typeof(TEvent)))
            throw new ImmutableContentIntegrityException("The remediation trigger differs from its exact committed typed source bytes.");
    }
}
''')
f=d/'FindingClosureReactor.cs';s=f.read_text().replace('using Bdgrz.Compliance.Features.NativeOperations;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.SourceFacts;').replace('    IImmutableContentStore content)','    IImmutableContentStore content, ISourceFactResolver sources)').replace('        var accepted = context.Trigger;','        var accepted = context.Trigger;\n        await FindingReactorSources.VerifyAsync(sources, content, Pattern, context, accepted.Owner, ct)\n            .ConfigureAwait(false);').replace('$"The frozen closure cannot be verified yet: {exception.Message}", true)','$"The frozen closure cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException)');f.write_text(s)
f=d/'CorrectiveActionMaterializationReactor.cs';s=f.read_text().replace('using Bdgrz.Compliance.Features.Processes;','using Bdgrz.Compliance.Features.Processes;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.SourceFacts;').replace('    ProcessRootReaction process)','    ProcessRootReaction process, IImmutableContentStore content, ISourceFactResolver sources)').replace('''public async ValueTask HandleAsync(IReactorContext<CorrectiveActionAdmitted> context, CancellationToken ct) =>
        _ = await''','''public async ValueTask HandleAsync(IReactorContext<CorrectiveActionAdmitted> context, CancellationToken ct)
    {
        await FindingReactorSources.VerifyAsync(sources, content, Pattern, context, context.Trigger.Owner, ct)
            .ConfigureAwait(false);
        _ = await''').replace('ct).ConfigureAwait(false);\n}', 'ct).ConfigureAwait(false);\n    }\n}');f.write_text(s)
f=d/'ControlOccurrenceFindingReactor.cs';s=f.read_text().replace('using System.Globalization;','using System.Globalization;\nusing Bdgrz.Compliance.Features.SourceFacts;').replace('    IRequestBus bus, IImmutableContentStore content)','    IRequestBus bus, IImmutableContentStore content, ISourceFactResolver sources)')
s=s.replace('        var ev = context.Trigger;','        var ev = context.Trigger;\n        await FindingReactorSources.VerifyAsync(sources, content, Pattern, context,\n            new ControlOccurrence(ev.TenantId, ev.ProgramId, ev.ControlId, ev.OccurrenceId).Stream, ct).ConfigureAwait(false);')
s=s.replace('$"The occurrence content cannot be verified yet: {exception.Message}", true)','$"The occurrence content cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException)');f.write_text(s)
f=d/'IndependentChildMaterialization.cs';s=f.read_text().replace('''        catch (ImmutableContentIntegrityException exception)
        {
            throw new SourceFactVerificationException($"The frozen admission cannot be verified yet: {exception.Message}");
        }''','''        catch (ImmutableContentUnavailableException exception)
        {
            throw new SourceFactUnavailableException($"The frozen admission is not available yet: {exception.Message}");
        }
        catch (ImmutableContentIntegrityException exception)
        {
            throw new SourceFactVerificationException($"The frozen admission cannot be verified: {exception.Message}");
        }''');f.write_text(s)
# Root cancellation retries always carry the original failure proof once a terminal fact exists.
f=d/'FindingClosureFences.cs';s=f.read_text().replace('''        var proof = await FindingContent.WriteDeterministicAsync(content, closure.TenantId, intent.Header.RootOperationId,
            FindingContent.FailureSchema,''','''        var proof = finding.TerminalClosure(intent.Header.RootOperationId) is FindingClosureCanceled canceledClosure
            ? canceledClosure.SourceProofs ?? throw new ImmutableContentIntegrityException("The cancellation has no exact failure proof.")
            : await FindingContent.WriteAsync(content, closure.TenantId, FindingContent.FailureSchema,''');f.write_text(s)
