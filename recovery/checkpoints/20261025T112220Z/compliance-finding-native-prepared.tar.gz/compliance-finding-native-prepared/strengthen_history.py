from pathlib import Path
p=Path('/tmp/compliance-finding-native-prepared/work');f=p/'src/Compliance.Core/Features/Remediation/FindingHistory.cs';s=f.read_text()
s=s.replace('''                        raised.Revision == 1 && operation.LogicalId == owner.FindingId;''','''                        raised.Revision == 1 && operation.LogicalId == owner.FindingId &&
                        raised.RaisedBy == operation.Actor && raised.RaisedAt == operation.AcceptedAt &&
                        NativeOwnerHistory.IsOwnRoot(owner, operation, operation.CommandKind, null);''')
s=s.replace('''                        revised.Revision == revision;''','''                        revised.Revision == revision && revised.RevisedBy == operation.Actor &&
                        revised.RevisedAt == operation.AcceptedAt &&
                        NativeOwnerHistory.IsOwnRoot(owner, operation, nameof(ReviseFinding), (ulong)index);''')
s=s.replace('''                        admitted.Generation == generation && actions.Add(operation.LogicalId);''','''                        admitted.Generation == generation && actions.Add(operation.LogicalId) &&
                        (NativeOwnerHistory.IsOwnRoot(owner, operation, nameof(AddCorrectiveAction), (ulong)index) ||
                            index == 1 && owner.Raised is { CreationKind: "routed" } initial &&
                            operation.CommandKind == "AdmitCorrectiveAction" && operation.RootOperationId == owner.FindingId &&
                            operation.Actor == initial.Operation.Actor && operation.Episode == initial.Operation.Episode &&
                            operation.AuthoredIntentSha256 == initial.Operation.AuthoredIntentSha256 &&
                            operation.OriginalExpectedRevision is null && operation.CausationEventId is null &&
                            (operation.FirstOwner ?? operation.Owner) == owner.Stream &&
                            operation.AffectedOwner == owner.Stream && operation.ExpectedRevisionOwner == owner.Stream);''')
s=s.replace('''                        linked.Revision == revision;''','''                        linked.Revision == revision &&
                        NativeOwnerHistory.IsOwnRoot(owner, operation, nameof(LinkFindingAcceptance), (ulong)index);''')
s=s.replace('''                        operation.RootOperationId == operation.LogicalId && closures.Add(operation.RootOperationId);''','''                        NativeOwnerHistory.IsOwnRoot(owner, operation, nameof(CloseFinding), (ulong)index) &&
                        closures.Add(operation.RootOperationId);''')
s=s.replace('''                        finished.Intent == pending.Intent && operation.RootOperationId == pending.Operation.RootOperationId;''','''                        finished.Intent == pending.Intent && Child(operation, pending, nameof(CompleteFindingClosure));''')
s=s.replace('''                        operation.RootOperationId == pending.Operation.RootOperationId;''','''                        Child(operation, pending, nameof(AbortFindingClosure));''')
s=s.replace('''                        reopened.FindingId) && reopened.Revision == revision;''','''                        reopened.FindingId) && reopened.Revision == revision &&
                        reopened.ReopenedBy == operation.Actor && reopened.ReopenedAt == operation.AcceptedAt &&
                        NativeOwnerHistory.IsOwnRoot(owner, operation, nameof(ReopenFinding), (ulong)index);''')
needle='''        bool Scope(Uuid tenant, Uuid program, Uuid finding) => tenant == owner.TenantId &&
            program == owner.ProgramId && finding == owner.FindingId;''';assert needle in s
s=s.replace(needle,needle+'''
        bool Child(OperationProvenance operation, FindingClosureAccepted admission, string kind) =>
            operation.Owner == owner.Stream && (operation.FirstOwner ?? operation.Owner) == owner.Stream &&
            operation.AffectedOwner == owner.Stream && operation.ExpectedRevisionOwner == owner.Stream &&
            operation.RootOperationId == admission.Operation.RootOperationId && operation.CommandKind == kind &&
            operation.CausationEventId == admission.Metadata.EventId && operation.Actor == admission.Operation.Actor &&
            operation.Episode == admission.Operation.Episode && operation.OriginalExpectedRevision == admission.Operation.OriginalExpectedRevision &&
            operation.AuthoredIntentSha256 == admission.Operation.AuthoredIntentSha256 && operation.AcceptedAt != default;''')
f.write_text(s)
f=p/'test/Compliance.Tests/Testing/FindingSeed.cs';s=f.read_text().replace('"CompleteFindingClosure", intent, operation, finding.Stream, at);','"CompleteFindingClosure", intent, operation, finding.Stream, at, finding.PendingClosure!.Metadata.EventId);').replace('OperationProvenance root, EventStreamAddress owner, DateTimeOffset at) => new(commandId, root.RootOperationId,\n            null, kind','OperationProvenance root, EventStreamAddress owner, DateTimeOffset at, Uuid? cause = null) => new(commandId, root.RootOperationId,\n            cause, kind');f.write_text(s)
f=p/'src/Compliance.Core/Features/Remediation/FindingReactorSources.cs';s=f.read_text();a=s.index('        if (pattern.IsTenantTemplate');body=s[a:s.rindex('\n    }')];s=s[:a]+'''        try
        {
'''+''.join('    '+line+'\n' for line in body.splitlines())+'''        }
        catch (SourceFactVerificationException error)
        {
            throw new ReactionCommandFailedException(new RequestError(RequestErrorKind.Conflict,
                $"The exact remediation source cannot be verified: {error.Message}", error is SourceFactUnavailableException));
        }
        catch (ImmutableContentIntegrityException error)
        {
            throw new ReactionCommandFailedException(new RequestError(RequestErrorKind.Conflict,
                $"The exact remediation bytes cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }
}
''';f.write_text(s)
f=p/'src/Compliance.Core/Features/Remediation/CompleteFindingClosureHandler.cs';s=f.read_text().replace('''                return SourceUseReceiverSupport.Permanent($"The frozen waiver proof cannot be verified: {exception.Message}");''','''                return Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict,
                    $"The frozen waiver proof cannot be verified: {exception.Message}", exception is ImmutableContentUnavailableException));''');f.write_text(s)
f=p/'src/Compliance.Core/Features/Remediation/ReopenFindingHandler.cs';s=f.read_text().replace('                ct).ConfigureAwait(false);','                token).ConfigureAwait(false);');f.write_text(s)
