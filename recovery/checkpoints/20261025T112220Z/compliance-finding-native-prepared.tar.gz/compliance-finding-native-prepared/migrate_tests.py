from pathlib import Path
import re,shutil
p=Path('/tmp/compliance-finding-native-prepared');w=p/'work';d=w/'test/Compliance.Tests/Features/Remediation'
f=w/'test/Compliance.Tests/Features/Operations/OperationsFixture.cs';s=f.read_text().replace('public async Task<FindingAggregate> FindingStreamAsync(Uuid findingId)','public async Task<FindingAggregate> FindingStreamAsync(Uuid findingId, Uuid selectedClosureRoot = default)').replace('.HydrateAsync(new FindingAggregate(TenantId, ProgramId, findingId));\n    }\n\n    public async Task<FindingHistorySnapshot>', '.HydrateAsync(new FindingAggregate(TenantId, ProgramId, findingId, selectedClosureRoot: selectedClosureRoot));\n    }\n\n    public async Task<FindingHistorySnapshot>');f.write_text(s)
for name in ['FindingClosureTests','FindingClosureContentRecoveryTests']:
 f=d/(name+'.cs');s=f.read_text();pieces=re.split(r'(?=    \[(?:Fact|Theory)\])',s)
 for i,t in enumerate(pieces):
  for var in set(re.findall(r'\b(\w+)\.TerminalClosure\(close.CommandId\)',t)):
   t=t.replace('var '+var+' = await fixture.FindingStreamAsync(finding.FindingId);','var '+var+' = await fixture.FindingStreamAsync(finding.FindingId, close.CommandId);')
  pieces[i]=t
 s=''.join(pieces).replace('Assert.Single((await fixture.FindingStreamAsync(finding.FindingId)).Admitted);','Assert.Single((await fixture.FindingHistoryAsync(finding.FindingId)).Admitted);').replace('Assert.Single(after.ClosureHistory);','Assert.Single((await fixture.FindingHistoryAsync(finding.FindingId)).ClosureHistory);')
 if name=='FindingClosureContentRecoveryTests':s=s.replace('new FindingClosureVerifier(reader, content),','new FindingClosureVerifier(reader, content, services.GetRequiredService<IDomainEventReader>()),')
 f.write_text(s)
f=d/'FindingProcessReactorTests.cs';f.write_text(f.read_text().replace('Assert.Single(closedTwice.ClosureHistory);','Assert.Single((await fixture.FindingHistoryAsync(finding.FindingId)).ClosureHistory);'))
f=d/'OccurrenceFindingTests.cs';s=f.read_text().replace('        var before = await fixture.GetFindingAsync(findingId);','        var source = await fixture.FindingHistoryAsync(findingId);\n        var before = await fixture.GetFindingAsync(findingId);').replace('stream.Facts.Select','source.Facts.Select').replace('Assert.Single(stream.Admitted)','Assert.Single(source.Admitted)');f.write_text(s)
rel='test/Compliance.Tests/Features/Remediation/CorrectiveActionMaterializationContentTests.cs'
for side in ['base','work']:
 f=p/side/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(Path('/tmp/compliance-corrective-action-prepared/work')/rel,f)
f=w/rel;s=f.read_text().replace('new UnreadableContent(unavailable), TimeProvider.System);','new UnreadableContent(unavailable), TimeProvider.System, services.GetRequiredService<IDomainEventReader>());');f.write_text(s)
