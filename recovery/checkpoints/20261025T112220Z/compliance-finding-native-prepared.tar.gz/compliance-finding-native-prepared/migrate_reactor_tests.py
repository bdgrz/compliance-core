from pathlib import Path
p=Path('/tmp/compliance-finding-native-prepared/work/test/Compliance.Tests/Features/Remediation')
f=p/'OccurrenceFindingTests.cs';s=f.read_text().replace('using Bdgrz.Compliance.Hosting.Persistence;','using Bdgrz.Compliance.Hosting.Persistence;\nusing Bdgrz.Compliance.Features.SourceFacts;\nusing Bdgrz.Compliance.Tests.Testing;')
s=s.replace('    static readonly Uuid OccurrenceId = Uuid.CreateVersion4();','''    static readonly ControlBusinessWindow Window = new ControlCalendarWindow(new DateOnly(2026, 10, 1),
        new DateOnly(2026, 11, 1));
    static readonly Uuid OccurrenceId = ControlOccurrenceIdentity.Of(TenantId, ProgramId, ControlId, Window);''')
s=s.replace('''        var scenario = new ReactorScenario(new TenantId(TenantId.ToString()))
            .Given(await AttestedAsync(attestation, 2));''','''        var attested = await AttestedAsync(attestation, 2);
        var scenario = new ReactorScenario(new TenantId(TenantId.ToString()));''')
s=s.replace('''        var first = new ReactorScenario(new TenantId(TenantId.ToString())).Given(attested);
        var replay = new ReactorScenario(new TenantId(TenantId.ToString())).Given(attested);''','''        var first = new ReactorScenario(new TenantId(TenantId.ToString()));
        var replay = new ReactorScenario(new TenantId(TenantId.ToString()));''')
s=s.replace('''first.Requests, Content));''','''first.Requests, Content, await SourcesAsync(first, attested)));''').replace('''replay.Requests, Content));''','''replay.Requests, Content, await SourcesAsync(replay, attested)));''')
s=s.replace('''        var scenario = new ReactorScenario(new TenantId(TenantId.ToString()))
            .Given(await AttestedAsync(Attestation("complete", null), 2))
            .Given(await AttestedAsync(Attestation("not_applicable", "No changes shipped."), 3));''','''        var complete = await AttestedAsync(Attestation("complete", null), 2);
        var notApplicable = await AttestedAsync(Attestation("not_applicable", "No changes shipped."), 3);
        var scenario = new ReactorScenario(new TenantId(TenantId.ToString()));''')
s=s.replace('''        var scenario = new ReactorScenario(new TenantId(TenantId.ToString())).Given(
            new ControlOccurrenceReviewed(TenantId, ProgramId, ControlId, OccurrenceId, 3, review, Provenance(),
                review, null));''','''        var reviewed = new ControlOccurrenceReviewed(TenantId, ProgramId, ControlId, OccurrenceId, 3, review,
            Provenance(), review, null);
        var scenario = new ReactorScenario(new TenantId(TenantId.ToString()));''')
# Scope each test so only its own exact native prefix enters its scenario and resolver.
import re
parts=re.split(r'(?=    \[Fact\])',s)
for i,t in enumerate(parts):
 if 'new ControlOccurrenceFindingReactor' not in t or 'first.Requests' in t:continue
 args='complete, notApplicable' if 'var notApplicable' in t else 'reviewed' if 'var reviewed = new ControlOccurrenceReviewed' in t else 'attested'
 t=t.replace('scenario.Requests, Content));',f'scenario.Requests, Content, await SourcesAsync(scenario, {args})));')
 parts[i]=t
s=''.join(parts)
needle='    static OperationProvenance Provenance()';assert needle in s
s=s.replace(needle,'''    static async Task<ISourceFactResolver> SourcesAsync(ReactorScenario scenario, params DomainEvent[] triggers)
    {
        var owner = new ControlOccurrence(TenantId, ProgramId, ControlId, OccurrenceId);
        var now = DateTimeOffset.UtcNow;
        var actor = ActorReference.ForMember(Uuid.CreateVersion4(), "Owner");
        var terms = new ControlOccurrenceTerms("recurring", Uuid.CreateVersion4(), Uuid.CreateVersion4(),
            new DateOnly(2026, 10, 1), new DateOnly(2026, 10, 31), new DateOnly(2026, 11, 5), null,
            new OperatingHolder("member", Uuid.CreateVersion4()), actor, now, Window);
        Assert.True(owner.Materialize(NativeFacts.Root(owner, Uuid.CreateVersion4(),
            nameof(MaterializeControlOccurrence), null), terms, NativeFacts.Ref()).IsSuccess);
        var prefix = new List<DomainEvent>(new AggregateScenario<ControlOccurrence>(owner).PendingEvents);
        if (triggers[0] is ControlOccurrenceReviewed)
            prefix.Add(DomainEventSeed.Attach(await AttestedAsync(Attestation("complete", null), 2), OccurrenceId, 2));
        foreach (var trigger in triggers)
        {
            var version = trigger switch
            {
                ControlOccurrenceAttested attested => attested.Revision,
                ControlOccurrenceReviewed reviewed => reviewed.Revision,
                _ => throw new InvalidOperationException("The scenario requires an actual occurrence source."),
            };
            if (trigger.AttachedMetadata is null)
                DomainEventSeed.Attach(trigger, OccurrenceId, (ulong)version);
            prefix.Add(trigger);
        }
        var store = new InMemoryEventStore();
        await store.AppendAsync(owner.Stream, 0, prefix.ToArray(), CancellationToken.None);
        scenario.Given(prefix.ToArray());
        return new EventStoreSourceFactResolver(store);
    }

'''+needle)
f.write_text(s)
f=p/'FindingProcessReactorTests.cs';s=f.read_text().replace('using Cntryl.Portia;','using Cntryl.Portia;\nusing Cntryl.Portia.Testing;\nusing Bdgrz.Compliance.Features.SourceFacts;')
s=s.replace('''            scope.ServiceProvider.GetRequiredService<ProcessRootReaction>());''','''            scope.ServiceProvider.GetRequiredService<ProcessRootReaction>(),
            scope.ServiceProvider.GetRequiredService<Bdgrz.Compliance.Features.Content.IImmutableContentStore>(),
            scope.ServiceProvider.GetRequiredService<ISourceFactResolver>());
        await new ReactorScenario(new TenantId(fixture.TenantId.ToString())).RunAsync(reactor);''')
s=s.replace('''scope.ServiceProvider.GetRequiredService<Bdgrz.Compliance.Features.Content.IImmutableContentStore>());''','''scope.ServiceProvider.GetRequiredService<Bdgrz.Compliance.Features.Content.IImmutableContentStore>(),
            scope.ServiceProvider.GetRequiredService<ISourceFactResolver>());
        await new ReactorScenario(new TenantId(fixture.TenantId.ToString())).RunAsync(reactor);''')
f.write_text(s)
