from pathlib import Path
p=Path('/tmp/compliance-finding-native-prepared/work/src/Compliance.Core/Features/Remediation');f=p/'RoutedFinding.cs';s=f.read_text()
a=s.index('    public static async ValueTask<Result> RaiseAsync<TRequest>');body=s[a:];signature=body[:body.index('\n    {')];core=signature.replace('public static async ValueTask<Result> RaiseAsync','static async ValueTask<Result> RaiseCoreAsync').replace('DateTimeOffset now, CancellationToken ct)','DateTimeOffset now, Func<CancellationToken, ValueTask<Result<RoutedFindingSource>>>? prepareSource,\n        CancellationToken ct)')
wrapper=signature.replace('public static async ValueTask<Result>','public static ValueTask<Result>')+''' =>
        RaiseCoreAsync(operations, reader, content, context, commandKind, request, tenantId, programId, findingId,
            source, title, affectedScope, ownerMemberId, links, correctiveAction, actor, now, null, ct);

    /// <summary>Resolves mutable routed source terms only after exact native acceptance has been checked.</summary>
    public static ValueTask<Result> RaiseFromSourceAsync<TRequest>(NativeOperationExecutor operations,
        IAggregateReader reader, IImmutableContentStore content, IExecutionContext context, string commandKind,
        TRequest request, Uuid tenantId, Uuid programId, Uuid findingId, ActorReference actor, DateTimeOffset now,
        Func<CancellationToken, ValueTask<Result<RoutedFindingSource>>> prepareSource, CancellationToken ct)
        where TRequest : notnull =>
        RaiseCoreAsync(operations, reader, content, context, commandKind, request, tenantId, programId, findingId,
            null!, string.Empty, string.Empty, Uuid.Empty, [], null, actor, now, prepareSource, ct);

'''
s=s[:a]+wrapper+core+body[len(signature):]
a=s.index('        var snapshot = await reader.HydrateAsync(');b=s.index('        var provenance =',a)
s=s[:a]+'''        var snapshot = new FindingAggregate(tenantId, programId, findingId, findingId);
'''+s[b:]
s=s.replace('FindingCommands.Digest(request), now);','FindingCommands.Digest(request), now) with { FirstOwner = snapshot.Stream };')
a=s.index('        if (snapshot.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');start=s.index('\n        {',a)+len('\n        {');end=s.index('\n        }\n\n        var outcome =',start)
body=s[start:end].replace('snapshot.', 'owner.').replace(', ct)', ', token)').replace(', ct\n', ', token\n').replace('Result.Failure','Result<FirstResponseDescriptor>.Failure')
source='''
            if (prepareSource is not null)
            {
                var resolved = await prepareSource(token).ConfigureAwait(false);
                if (!resolved.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(resolved.Error!);
                var selected = resolved.Value!;
                (source, title, affectedScope, ownerMemberId, links, correctiveAction) = (selected.Source,
                    selected.Title, selected.AffectedScope, selected.OwnerMemberId, selected.Links, selected.CorrectiveAction);
            }'''
s=s[:a]+'''        async ValueTask<Result<FirstResponseDescriptor>> PrepareAsync(FindingAggregate owner, CancellationToken token)
        {'''+source+body+'''
            return Result<FirstResponseDescriptor>.Success(response!);
        }
'''+s[end+len('\n        }'):]
s=s.replace('finding => FindingCommands.Prepared(finding.PrepareRaise(), response),','PrepareAsync,').replace('root.AuthoredIntentSha256, now, stream, stream);','root.AuthoredIntentSha256, now, stream, stream, stream);').replace('\n\n\n','\n\n')
# Before any admission, a tentative content id must not become an irreversible request claim.
s=s.replace('FindingContent.WriteDeterministicAsync(content, tenantId, authored.ActionId,','FindingContent.WriteAsync(content, tenantId,')
f.write_text(s)
p.joinpath('RoutedFindingSource.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Remediation;

/// <summary>The source terms selected inside one native routed-raise preparation.</summary>
internal sealed record RoutedFindingSource(FindingSource Source, string Title, string AffectedScope,
    Uuid OwnerMemberId, IReadOnlyList<FindingLink> Links, string? CorrectiveAction);
''')
f=p/'RaiseOccurrenceFindingHandler.cs';s=f.read_text();a=s.index('        var snapshot = await operatingReader.');b=s.index('\n    }\n}',a)
s=s[:a]+'''        var now = clock.GetUtcNow();
        var actor = ActorReference.ForSystemProcess(ProcessId, ControlOccurrenceFindingReactor.WorkloadName);
        async ValueTask<Result<RoutedFindingSource>> PrepareSourceAsync(CancellationToken token)
        {
            var snapshot = await operatingReader.ReadOccurrenceAsync(request.TenantId, request.ProgramId, request.ControlId,
                request.OccurrenceId, token).ConfigureAwait(false);
            var today = DateOnly.FromDateTime(now.UtcDateTime);
            if (snapshot.ReadOccurrence(request.ControlId, request.OccurrenceId,
                    new Dictionary<Uuid, DateOnly?>(), today) is not { Revision: > 0 } occurrence ||
                occurrence.Attestations.Count == 0)
                return Result<RoutedFindingSource>.Failure(new RequestError(RequestErrorKind.NotFound,
                    "The control occurrence was not found."));
            var owner = snapshot.CurrentPlan(request.ControlId)?.Owner is { Kind: "member" } member
                ? member.Id
                : occurrence.Reviews.Count > 0
                    ? occurrence.Reviews[^1].ReviewerMemberId
                    : occurrence.Attestations[^1].RecorderMemberId;
            var requestedAction = request.SourceKind == "occurrence_review";
            return Result<RoutedFindingSource>.Success(new RoutedFindingSource(
                new FindingSource(request.SourceKind, request.OccurrenceId, request.SourceVersion, request.SourceText),
                requestedAction ? "Requested action from control review" : "Control occurrence exception",
                $"Control {request.ControlId}, occurrence {request.OccurrenceId}", owner,
                [new FindingLink("control", request.ControlId.ToString()),
                    new FindingLink("control_occurrence", request.OccurrenceId.ToString())],
                requestedAction ? request.SourceText : null));
        }
        return await RoutedFinding.RaiseFromSourceAsync(operations, reader, content, context, "RaiseOccurrenceFinding",
            request, request.TenantId, request.ProgramId, request.FindingId, actor, now, PrepareSourceAsync, ct)
            .ConfigureAwait(false);'''+s[b:];f.write_text(s)
# Fresh pre-admission content ids, preserving exact logical intent and bytes.
for name in ['AddCorrectiveActionHandler','CloseFindingHandler']:
 f=p/(name+'.cs');s=f.read_text()
 import re
 s=re.sub(r'FindingContent.WriteDeterministicAsync\(content, (request.TenantId|tenant), request\.(ActionId|CommandId),',r'FindingContent.WriteAsync(content, \1,',s)
 if name=='CloseFindingHandler':s=s.replace('Uuid.CreateVersion5(request.CommandId, "admitted-children")','Uuid.CreateVersion4()').replace('Uuid.CreateVersion5(request.CommandId, "source-uses")','Uuid.CreateVersion4()')
 f.write_text(s)
