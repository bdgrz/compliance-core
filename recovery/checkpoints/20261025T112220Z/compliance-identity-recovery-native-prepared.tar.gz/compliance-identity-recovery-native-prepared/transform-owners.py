from pathlib import Path
root=Path('/tmp/compliance-identity-recovery-native-prepared/prepared')
p=root/'src/Compliance.Core/Features/UserIdentities/UserIdentity.cs'
s=p.read_text().replace('    readonly Dictionary<Uuid, RecoveryProtection> _protections = [];\n    readonly HashSet<Uuid> _settled = [];','    readonly Uuid _selectedChallengeId;\n    bool _selectedSettled;\n    Uuid? _protectionChallengeId;\n    RecoveryProtection? _protection;')
s=s.replace('identityId, null, null, Uuid.Empty, null)', 'identityId, null, null, Uuid.Empty, null, Uuid.Empty)')
s=s.replace('provider, identifier, Uuid.Empty, null)', 'provider, identifier, Uuid.Empty, null, Uuid.Empty)')
s=s.replace('public UserIdentity(Uuid identityId, Uuid selectedCommandId, string selectedCommandKind)', 'public UserIdentity(Uuid identityId, Uuid selectedCommandId, string? selectedCommandKind, Uuid selectedChallengeId)')
s=s.replace('identityId, null, null, selectedCommandId, selectedCommandKind)', 'identityId, null, null, selectedCommandId, selectedCommandKind, selectedChallengeId)')
s=s.replace('public UserIdentity(string provider, string identifier, Uuid selectedCommandId, string selectedCommandKind)', 'public UserIdentity(string provider, string identifier, Uuid selectedCommandId, string? selectedCommandKind,\n        Uuid selectedChallengeId)')
s=s.replace('provider, identifier, selectedCommandId, selectedCommandKind)', 'provider, identifier, selectedCommandId, selectedCommandKind, selectedChallengeId)')
s=s.replace('string? selectedCommandKind)\n        : base', 'string? selectedCommandKind, Uuid selectedChallengeId)\n        : base')
s=s.replace('        Acceptance = new NativeAcceptance(selectedCommandId, selectedCommandKind);', '        _selectedChallengeId = selectedChallengeId;\n        Acceptance = new NativeAcceptance(selectedCommandId, selectedCommandKind);')
s=s.replace('    internal NativeAcceptance Acceptance { get; }', '    internal NativeAcceptance Acceptance { get; }\n\n    internal Uuid SelectedChallengeId => _selectedChallengeId;\n    internal IdentityOwnerReplayCut ReplayCut { get; } = new();\n    internal Uuid? ProtectionChallengeId => _protectionChallengeId;\n    internal RecoveryProtection? Protection => _protection;\n\n    /// <summary>Selects a historical challenge explicitly; no command hash is reversed into a challenge.</summary>\n    public UserIdentity(Uuid identityId, Uuid selectedChallengeId)\n        : this(identityId, null, null, Uuid.Empty, null, selectedChallengeId)\n    {\n    }')
s=s.replace('=> _protections.ContainsKey(challengeId);', '=> _protectionChallengeId == challengeId;')
s=s.replace('public bool IsSettledFor(Uuid challengeId) => _settled.Contains(challengeId);', '''public bool IsSettledFor(Uuid challengeId)
    {
        if (challengeId == _selectedChallengeId && challengeId != Uuid.Empty)
            return _selectedSettled;
        if (CommittedStreamPosition == 0 && !_selectedSettled)
            return false;
        throw new InvalidOperationException("Historical settlement authority requires its explicitly selected challenge.");
    }''')
s=s.replace('_protections.Values.Any(protection => userId != protection.AccountId)', '_protection is { } protection && userId != protection.AccountId')
s=s.replace('_protections.Count > 0', '_protection is not null')
s=s.replace('if (_settled.Contains(challengeId))', 'if (IsSettledFor(challengeId))')
old='''        foreach (var (otherChallenge, other) in _protections)
        {
            if (otherChallenge == challengeId)
                continue;
            return other.AccountId == accountId
                ? new ProtectionDecision(ProtectionOutcome.Wait, "Another recovery of this account holds the slot.")
                : new ProtectionDecision(ProtectionOutcome.Conflict,
                    "Another account's recovery holds the slot.");
        }'''
new='''        if (_protection is { } other && _protectionChallengeId != challengeId)
            return other.AccountId == accountId
                ? new ProtectionDecision(ProtectionOutcome.Wait, "Another recovery of this account holds the slot.")
                : new ProtectionDecision(ProtectionOutcome.Conflict,
                    "Another account's recovery holds the slot.");'''
assert old in s;s=s.replace(old,new)
s=s.replace('!_protections.TryGetValue(challengeId, out var protection) || protection.AccountId != accountId ||', '_protectionChallengeId != challengeId || _protection is not { } protection || protection.AccountId != accountId ||')
s=s.replace('!_protections.TryGetValue(challengeId, out var protection) || protection.AccountId != _userId ||', '_protectionChallengeId != challengeId || _protection is not { } protection || protection.AccountId != _userId ||')
start=s.index('        _registrationProof = new IdentityRegistrationProof(')
end=s.index('\n    }',start)
s=s[:start]+'''        // A hydrated proof is bound by the full reader to its actual physical record. A fresh first
        // registration has no predecessor records; it is the only unsaved case used by aggregate scenarios.
        _registrationProof = registered.Metadata.AggregateVersion == 1 && CommittedStreamPosition == 0
            ? RegistrationProof(registered, 0)
            : null;'''+s[end:]
start=s.index('    void Apply(RecoveryIdentityProtected protectedFact)')
end=s.index('    Result<AuthenticatedUserIdentity> Registered()',start)
s=s[:start]+'''    void Apply(RecoveryIdentityProtected protectedFact)
    {
        Acceptance.Observe(protectedFact);
        if (protectedFact.Owner != Stream || protectedFact.ChallengeId == Uuid.Empty ||
            protectedFact.AccountId == Uuid.Empty || _protection is not null ||
            protectedFact.ChallengeId == _selectedChallengeId && _selectedSettled)
            throw new InvalidOperationException("The recovery protection does not match its identity slot.");
        (_protectionChallengeId, _protection) = (protectedFact.ChallengeId,
            new RecoveryProtection(protectedFact.AccountId, protectedFact.Role));
    }

    void Apply(RecoveryIdentityProtectionSettled settled)
    {
        Acceptance.Observe(settled);
        if (settled.Owner != Stream || settled.ChallengeId == Uuid.Empty ||
            settled.ChallengeId == _selectedChallengeId && _selectedSettled)
            throw new InvalidOperationException("The recovery protection settlement does not match its identity slot.");
        if (settled.ChallengeId == _selectedChallengeId)
            _selectedSettled = true;
        if (_protectionChallengeId == settled.ChallengeId)
            (_protectionChallengeId, _protection) = (null, null);
    }

    protected override void Apply(DomainEvent fact)
    {
        base.Apply(fact);
        ReplayCut.Observe(fact);
    }

    internal void BindRegistrationProof(UserIdentityRegistered registered, ulong physicalPosition)
    {
        if (_registration != registered || _registration.Metadata != registered.Metadata)
            throw new InvalidOperationException("The registration proof does not match the compact identity authority.");
        _registrationProof = RegistrationProof(registered, physicalPosition);
    }

    static IdentityRegistrationProof RegistrationProof(UserIdentityRegistered registered, ulong position) =>
        new(registered.Metadata.AggregateId, registered.Metadata.EventId, registered.Metadata.AggregateVersion, position,
            Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(registered,
                ComplianceCoreJsonContext.Default.UserIdentityRegistered))));

'''+s[end:]
s=s.replace('    sealed record RecoveryProtection(', '    internal sealed record RecoveryProtection(')
# Guard all mutation/audit admission from a verified committed prefix. Preparers are also guarded independently.
for signature,returnType in [('public Result<AuthenticatedUserIdentity> Register(', 'Result<AuthenticatedUserIdentity>'),('public Result<AuthenticatedUserIdentity> Authenticate()', 'Result<AuthenticatedUserIdentity>'),('public Result Revoke(', 'Result'),('public Result<AuthenticatedUserIdentity> ObserveAuthenticatedProfile(', 'Result<AuthenticatedUserIdentity>'),('public Result Protect(', 'Result'),('public Result Settle(', 'Result'),('public Result RegisterRecovered(', 'Result'),('public Result RevokeRecovered(', 'Result')]:
 i=s.index(signature); b=s.index('\n    {',i)+len('\n    {')
 s=s[:b]+f'\n        var cut = ReplayCut.Require(this);\n        if (!cut.IsSuccess)\n            return {returnType}.Failure(cut.Error!);'+s[b:]
p.write_text(s)

p=root/'src/Compliance.Core/Features/UserIdentities/EmailAddress.cs';s=p.read_text()
s=s.replace('    readonly Dictionary<Uuid, RecoveryClaim> _claims = [];\n    readonly HashSet<Uuid> _completedRecoveries = [];','    readonly Uuid _selectedChallengeId;\n    RecoveryClaim? _selectedClaim;\n    bool _selectedCompleted;\n    RecoveryClaim? _currentClaim;')
s=s.replace('public EmailAddress(string address, Uuid selectedLogicalId, string? selectedCommandKind)', 'public EmailAddress(string address, Uuid selectedLogicalId, string? selectedCommandKind,\n        Uuid selectedChallengeId = default)')
s=s.replace('Normalize(address), selectedLogicalId, selectedCommandKind)', 'Normalize(address), selectedLogicalId, selectedCommandKind, selectedChallengeId)')
s=s.replace('public EmailAddress(Uuid addressId, Uuid selectedLogicalId, string? selectedCommandKind)', 'public EmailAddress(Uuid addressId, Uuid selectedLogicalId, string? selectedCommandKind,\n        Uuid selectedChallengeId = default)')
s=s.replace('addressId, null, selectedLogicalId, selectedCommandKind)', 'addressId, null, selectedLogicalId, selectedCommandKind, selectedChallengeId)')
s=s.replace('EmailAddress(Uuid addressId, string? address, Uuid selectedLogicalId, string? selectedCommandKind)', 'EmailAddress(Uuid addressId, string? address, Uuid selectedLogicalId, string? selectedCommandKind, Uuid selectedChallengeId)')
s=s.replace('        _address = address;','        _address = address;\n        _selectedChallengeId = selectedChallengeId;',1)
s=s.replace('    public NativeAcceptance Acceptance { get; }','    public NativeAcceptance Acceptance { get; }\n\n    internal Uuid SelectedChallengeId => _selectedChallengeId;\n    internal IdentityOwnerReplayCut ReplayCut { get; } = new();')
s=s.replace('RecoveryClaim? CurrentClaim => _recoveryChallengeId is { } current ? _claims.GetValueOrDefault(current) : null;', 'RecoveryClaim? CurrentClaim => _currentClaim;')
s=s.replace('public RecoveryClaim? ClaimOf(Uuid challengeId) => _claims.GetValueOrDefault(challengeId);', '''public RecoveryClaim? ClaimOf(Uuid challengeId)
    {
        if (challengeId == _recoveryChallengeId)
            return _currentClaim;
        if (challengeId == _selectedChallengeId && challengeId != Uuid.Empty)
            return _selectedClaim;
        if (CommittedStreamPosition == 0 && _selectedClaim is null)
            return null;
        throw new InvalidOperationException("Historical recovery claims require their explicitly selected challenge.");
    }''')
s=s.replace('public bool IsRecoveryChallengeCompleted(Uuid challengeId) => _completedRecoveries.Contains(challengeId);', '''public bool IsRecoveryChallengeCompleted(Uuid challengeId)
    {
        if (challengeId == _recoveryChallengeId)
            return _recoveryCompleted;
        if (challengeId == _selectedChallengeId && challengeId != Uuid.Empty)
            return _selectedCompleted;
        if (CommittedStreamPosition == 0 && !_selectedCompleted)
            return false;
        throw new InvalidOperationException("Historical recovery completions require their explicitly selected challenge.");
    }''')
s=s.replace('_claims.ContainsKey(challengeId)', 'ClaimOf(challengeId) is not null')
s=s.replace('!_claims.TryGetValue(challengeId, out var claim)', 'ClaimOf(challengeId) is not { } claim')
s=s.replace('_completedRecoveries.Contains(challengeId)', 'IsRecoveryChallengeCompleted(challengeId)')
s=s.replace('        _recoveryCompleted = false;', '        _recoveryCompleted = false;\n        _currentClaim = null;')
s=s.replace('_claims.ContainsKey(claimed.ChallengeId)', '_currentClaim is not null')
s=s.replace('        _claims[claimed.ChallengeId] = new RecoveryClaim(claimed.OldIdentityId, claimed.ReplacementIdentityId, claimed);', '''        _currentClaim = new RecoveryClaim(claimed.OldIdentityId, claimed.ReplacementIdentityId, claimed);
        if (claimed.ChallengeId == _selectedChallengeId)
            _selectedClaim = _currentClaim;''')
s=s.replace('!_claims.TryGetValue(completed.ChallengeId, out var claim)', 'ClaimOf(completed.ChallengeId) is not { } claim')
s=s.replace('!_completedRecoveries.Add(completed.ChallengeId)', 'IsRecoveryChallengeCompleted(completed.ChallengeId)')
s=s.replace('        // Only the completed challenge is marked;', '        if (completed.ChallengeId == _selectedChallengeId)\n            _selectedCompleted = true;\n\n        // Only the completed challenge is marked;')
# An unselected historical completion is validated by complete history, while the fold keeps only current/selected authority.
s=s.replace('''        if (_owner != completed.UserId || ClaimOf(completed.ChallengeId) is not { } claim ||
            claim.OldIdentityId != completed.OldIdentityId ||
            claim.ReplacementIdentityId != completed.ReplacementIdentityId ||
            IsRecoveryChallengeCompleted(completed.ChallengeId))''','''        var claim = completed.ChallengeId == _recoveryChallengeId ? _currentClaim
            : completed.ChallengeId == _selectedChallengeId ? _selectedClaim : null;
        if (_owner != completed.UserId ||
            (completed.ChallengeId == _recoveryChallengeId || completed.ChallengeId == _selectedChallengeId) &&
            (claim is null || claim.OldIdentityId != completed.OldIdentityId ||
                claim.ReplacementIdentityId != completed.ReplacementIdentityId ||
                (completed.ChallengeId == _recoveryChallengeId ? _recoveryCompleted : _selectedCompleted)))''')
idx=s.index('    static Uuid CreateId(')
s=s[:idx]+'''    protected override void Apply(DomainEvent fact)
    {
        base.Apply(fact);
        ReplayCut.Observe(fact);
    }

'''+s[idx:]
# Committed mutation preparation must select exactly the business challenge being decided.
for signature in ['public Result PrepareIssueChallenge(', 'public Result PrepareIssueRecoveryChallenge(', 'public Result PrepareClaimIdentityRecovery(', 'public Result PrepareCompleteIdentityRecovery(', 'public Result PrepareCompleteChallenge(', 'public Result PrepareReserve(']:
 i=s.index(signature); b=s.index('\n    {',i)+len('\n    {')
 s=s[:b]+'''\n        var cut = ReplayCut.Require(this);
        if (!cut.IsSuccess)
            return cut;'''+s[b:]
p.write_text(s)
