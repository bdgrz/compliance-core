from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,sys
root=Path('/tmp/compliance-identity-recovery-native-prepared');prepared=root/'prepared';baseline=root/'baseline';release=root/'releases/001'
if release.exists():raise SystemExit('Release 001 already exists; create a new release instead of rewriting immutable artifacts.')
release.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=[]
for p in sorted(prepared.rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(prepared));before=baseline/rel
 if before.exists() and before.read_bytes()==p.read_bytes():continue
 changed.append({'path':rel,'beforeSha256':sha(before.read_bytes()) if before.exists() else None,'afterSha256':sha(p.read_bytes()),'kind':'production' if rel.startswith('src/') else 'tests'})
red={}
for folder in ['red','admission-red','receiver-red','unit-red']:
 for p in (root/folder).rglob('*.cs'):red[str(p.relative_to(root/folder))]=p.read_bytes()
def make_patch(entries,qualified=False):
 out=''
 for e in entries:
  rel=e['path'];old=red.get(rel) if qualified and rel in red else ((baseline/rel).read_bytes() if (baseline/rel).exists() else None);new=(prepared/rel).read_bytes()
  if old==new:continue
  out+=''.join(difflib.unified_diff(old.decode().splitlines(True) if old is not None else [],new.decode().splitlines(True),fromfile='a/'+rel if old is not None else '/dev/null',tofile='b/'+rel))
 return out
for name,entries,qualified in [('full.patch',changed,False),('implementation.patch',[e for e in changed if e['kind']=='production'],False),('tests.patch',[e for e in changed if e['kind']=='tests'],False),('tests-from-qualified-red.patch',[e for e in changed if e['kind']=='tests'],True)]:
 (release/name).write_text(make_patch(entries,qualified))
for e in changed:
 rel=e['path'];dst=release/'files'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(prepared/rel,dst)
 if (baseline/rel).exists():
  dst=release/'baseline'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(baseline/rel,dst)
 if rel in red:e['qualifiedRedBeforeSha256']=sha(red[rel])
(release/'production-files.txt').write_text(''.join(e['path']+'\n' for e in changed if e['kind']=='production'))
manifest={'release':1,'baselineHeadReportedByRoot':'5e784ab0cf81b9432b14356f08b345c86c5782c2','sourceAuthority':'Exact before/after SHA256 bytes; root may have later unrelated changes. Shared persistence diff is narrow and must preserve all other readers/lifetimes.','runtimeExecutedByAgent':False,'files':changed,'filters':['FullyQualifiedName~IdentityRecoveryLifetimeTests','FullyQualifiedName~IdentityRecoveryAdmissionPreparationTests','FullyQualifiedName~IdentityRecoveryReceiverPreparationTests','FullyQualifiedName~EmailAcknowledgmentPreparationTests','FullyQualifiedName~IdentityOwnerHistoryTests','FullyQualifiedName~UserIdentities'],'rootReportedQualification':{'lifetimeV2':'5 failed / 3 passed against old APIs; two compaction cases, two missing-dependency classification cases and one equal-winner failure; corrupt2/cancellation1 positive','admission':'3 failed; first2 genuine equal-winner-loss failures; third already rejects stale claim correctly and is proposed exact-cut classification gate, not an authorization vulnerability','receiver':'4 failed; all actual obsolete dependency paths reached','unitCandidateReplay':'not yet reported'},'patches':{name:sha((release/name).read_bytes()) for name in ['full.patch','implementation.patch','tests.patch','tests-from-qualified-red.patch']}}
(release/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Verify exact reconstruction using only patches and immutable baseline bytes, in package-local directories.
results=[]
for scenario,patches,q in [('full',['full.patch'],False),('split',['implementation.patch','tests.patch'],False),('qualified-red',['implementation.patch','tests-from-qualified-red.patch'],True)]:
 target=release/'reconstruction'/scenario;shutil.copytree(baseline,target)
 if q:
  for rel,b in red.items():
   p=target/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for patch in patches:
  ran=subprocess.run(['patch','-p1','--batch','--forward','--input',str(release/patch)],cwd=target,capture_output=True,text=True)
  if ran.returncode:raise SystemExit(f'{scenario} failed {patch}: {ran.stdout}{ran.stderr}')
 mismatches=[e['path'] for e in changed if not (target/e['path']).exists() or sha((target/e['path']).read_bytes())!=e['afterSha256']]
 if mismatches:raise SystemExit(f'{scenario}: hash mismatch {mismatches}')
 results.append({'scenario':scenario,'filesVerified':len(changed),'matchedEveryAfterHash':True})
(release/'reconstruction-proof.json').write_text(json.dumps(results,indent=2)+'\n')
# Python/tree-sitter is syntax inspection only; C# compilation and runtime gates remain root-owned.
sys.path.insert(0,str(root/'static-parser'))
from tree_sitter import Parser,Language
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));parse=[]
for e in changed:
 if not e['path'].endswith('.cs'):continue
 p=prepared/e['path'];t=parser.parse(p.read_bytes());parse.append({'path':e['path'],'treeSitterHasError':t.root_node.has_error,'note':'Grammar limitations exist for previously compiled test syntax; not a C# compile result.' if t.root_node.has_error else 'Syntax parsed; no type/analyzer/runtime claim.'})
(release/'static-syntax-inspection.json').write_text(json.dumps(parse,indent=2)+'\n')
summary={'files':len(changed),'productionFiles':sum(e['kind']=='production' for e in changed),'testFiles':sum(e['kind']=='tests' for e in changed),'manifestSha256':sha((release/'manifest.json').read_bytes()),'patches':manifest['patches'],'reconstruction':results,'productionSyntaxErrors':[e['path'] for e in parse if e['path'].startswith('src/') and e['treeSitterHasError']]}
print(json.dumps(summary,indent=2))
