from pathlib import Path
import shutil,json,hashlib,re
p=Path('/tmp/compliance-identity-recovery-native-prepared');root=p/'prepared';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
extras=[]
def ensure(rel):
 src=repo/rel;b=p/'baseline'/rel;t=root/rel
 if not b.exists():
  b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,b)
  extras.append({'path':rel,'sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
 if not t.exists():
  t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b,t)
 return t
def edit(rel,changes):
 f=ensure(rel);s=f.read_text()
 for old,new in changes:
  assert old in s,(rel,old);s=s.replace(old,new)
 f.write_text(s)
base='src/Compliance.Core/Features/UserIdentities/'
for name in ['ProtectRecoveryIdentityHandler','SettleRecoveryIdentityProtectionHandler','RevokeRecoveredOldIdentityHandler']:
 command=name.removesuffix('Handler')
 edit(base+name+'.cs',[(f'nameof({command}))',f'nameof({command}), request.ChallengeId)')])
edit(base+'RegisterRecoveredIdentityHandler.cs', [('nameof(RegisterRecoveredIdentity)),','nameof(RegisterRecoveredIdentity), request.ChallengeId),')])
edit(base+'AcceptProtectedIdentityRecoveryHandler.cs', [('new UserIdentity(frozen.OldIdentityId)', 'new UserIdentity(frozen.OldIdentityId, request.ChallengeId)'),('new UserIdentity(frozen.ReplacementIdentityId)', 'new UserIdentity(frozen.ReplacementIdentityId, request.ChallengeId)')])
edit(base+'RejectIdentityRecoveryPreparationHandler.cs', [('new UserIdentity(conflict.IdentityId)', 'new UserIdentity(conflict.IdentityId, request.ChallengeId)')])
edit(base+'IdentityRecoveryEffects.cs', [('new UserIdentity(identity)', 'new UserIdentity(identity, intent.ChallengeId)')])
edit(base+'CompleteEmailRecoveryChallengeHandler.cs', [('nameof(CompleteEmailRecoveryChallenge))', 'nameof(CompleteEmailRecoveryChallenge), request.ChallengeId)')])
edit(base+'SendIdentityRecoveryNoticeHandler.cs', [('new EmailAddress(recipient)', 'new EmailAddress(recipient, Uuid.Empty, null, request.ChallengeId)')])
for name in ['StartIdentityRecoveryHandler','CompleteIdentityRecoveryHandler','IssueEmailChallengeHandler','CompleteEmailChallengeHandler']:
 edit(base+name+'.cs',[('request.ChallengeId, CommandKind)', 'request.ChallengeId, CommandKind, request.ChallengeId)')])
edit('src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs', [('using Bdgrz.Compliance.Features.Work;', 'using Bdgrz.Compliance.Features.Work;\nusing Bdgrz.Compliance.Features.UserIdentities;'),('        Decorate<IRequestBus>(services,', '        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new IdentityOwnerAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n        Decorate<IRequestBus>(services,')])
# Public scalar auth methods have always supported direct in-memory domain scenarios; the installed reader validates their history.
f=root/base/'UserIdentity.cs';s=f.read_text()
for signature in ['public Result<AuthenticatedUserIdentity> Register(', 'public Result<AuthenticatedUserIdentity> Authenticate()', 'public Result Revoke(', 'public Result<AuthenticatedUserIdentity> ObserveAuthenticatedProfile(']:
 start=s.index(signature);end=s.index('\n    }',start);section=s[start:end]
 section=re.sub(r'\n        var cut = ReplayCut.Require\(this\);\n        if \(!cut.IsSuccess\)\n            return (?:Result<AuthenticatedUserIdentity>|Result).Failure\(cut.Error!\);','',section)
 s=s[:start]+section+s[end:]
# Explicit provider/subject historical selection used by domain scenarios and genuine recovery producers.
mark='    /// <summary>Hydrates an identity by id for one logical recovery operation selected by command id and kind.</summary>'
s=s.replace(mark,'''    /// <summary>Selects a historical challenge on the exact provider and subject slot.</summary>
    public UserIdentity(string provider, string identifier, Uuid selectedChallengeId)
        : this(CreateIdentityId(provider, identifier), provider, identifier, Uuid.Empty, null, selectedChallengeId)
    {
    }

'''+mark)
f.write_text(s)
# Match original DI lifetime preservation convention in every in-memory real recovery/delivery host.
wrapper=repo/'test/Compliance.Tests/Testing/VerifiedPracticeCommitmentServices.cs'
s=wrapper.read_text().replace('using Bdgrz.Compliance.Features.AccessControl;', 'using Bdgrz.Compliance.Features.UserIdentities;').replace('VerifiedPracticeCommitmentServices','VerifiedIdentityOwnerServices').replace('AddVerifiedPracticeCommitmentReader','AddVerifiedIdentityOwnerReader').replace('PracticeCommitmentAggregateReader','IdentityOwnerAggregateReader')
f=root/'test/Compliance.Tests/Testing/VerifiedIdentityOwnerServices.cs';f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
for rel in ['test/Compliance.Tests/Testing/IdentityRecoveryHost.cs','test/Compliance.Tests/Testing/EmailChallengeDeliveryHost.cs']:
 edit(rel,[('        Provider = services.BuildServiceProvider();','        services.AddVerifiedIdentityOwnerReader();\n        Provider = services.BuildServiceProvider();')])
# Readers select their actual business challenge from DTOs; selectors never derive from command IDs.
edit('test/Compliance.Tests/Testing/IdentityRecoveryHost.cs', [('public async Task<UserIdentity> IdentityAsync(Uuid identityId) => await Reader.HydrateAsync(new UserIdentity(identityId));', 'public async Task<UserIdentity> IdentityAsync(Uuid identityId, Uuid selectedChallengeId = default) =>\n        await Reader.HydrateAsync(new UserIdentity(identityId, selectedChallengeId));'),('public async Task<EmailAddress> AddressAsync(string email = Email) => await Reader.HydrateAsync(new EmailAddress(email));', 'public async Task<EmailAddress> AddressAsync(string email = Email, Uuid selectedChallengeId = default) =>\n        await Reader.HydrateAsync(new EmailAddress(email, Uuid.Empty, null, selectedChallengeId));')])
# Existing per-challenge assertions keep names and semantics while explicitly selecting the queried history.
rel='test/Compliance.Tests/Features/UserIdentities/IdentityRecoveryProcessTests.cs';f=ensure(rel);s=f.read_text()
s=re.sub(r'host.IdentityAsync\((account.OldIdentityId|NewIdentity)\)',r'host.IdentityAsync(\1, challenge)',s)
# The two concurrent recovery assertions deliberately inspect separate selected challenges.
s=s.replace('host.IdentityAsync(account.OldIdentityId, challenge)).IsProtectedFor(second)', 'host.IdentityAsync(account.OldIdentityId, second)).IsProtectedFor(second)')
s=s.replace('host.IdentityAsync(account.OldIdentityId, challenge)).IsProtectedFor(first)', 'host.IdentityAsync(account.OldIdentityId, first)).IsProtectedFor(first)')
# Variables from the completion tests select the historical first challenge after a newer challenge is issued.
s=s.replace('var address = await host.AddressAsync();', 'var address = await host.AddressAsync(selectedChallengeId: challenge);')
for match in list(re.finditer(r'    public async Task (Should\w+)\(',s)):
 start=match.start();end=s.find('\n    [',start+1)
 if end<0:end=len(s)
 block=s[start:end]
 if 'IsRecoveryChallengeCompleted(first)' in block:
  block=block.replace('selectedChallengeId: challenge','selectedChallengeId: first')
  s=s[:start]+block+s[end:]
f.write_text(s)
# Qualify revised GREEN variants of the frozen old-API tests; the old-API RED bytes stay untouched.
f=root/'test/Compliance.Tests/Features/UserIdentities/IdentityRecoveryLifetimeTests.cs';s=f.read_text().replace('host.IdentityAsync(account.OldIdentityId);','host.IdentityAsync(account.OldIdentityId, earliest);').replace('host.AddressAsync();','host.AddressAsync(selectedChallengeId: earliest);');f.write_text(s)
# Pure domain scenarios name their selected settlement challenge explicitly.
rel='test/Compliance.Tests/Features/UserIdentities/UserIdentityRecoveryProtectionTests.cs';f=ensure(rel);s=f.read_text()
s=s.replace('var held = Uuid.CreateVersion4();\n        var identity = new UserIdentity("issuer", "replacement");','var held = Uuid.CreateVersion4();\n        var identity = new UserIdentity("issuer", "replacement", held);')
s=s.replace('var challenge = Uuid.CreateVersion4();\n        var identity = new UserIdentity("issuer", "replacement");','var challenge = Uuid.CreateVersion4();\n        var identity = new UserIdentity("issuer", "replacement", challenge);')
f.write_text(s)
# Additional baseline bytes are separate from the initial immutable 209-file inventory.
(p/'additional-baseline-manifest.json').write_text(json.dumps(extras,indent=2)+'\n')
