# Identity recovery release 001 (frozen; offline preparation only)

- Immutable release: `/tmp/compliance-identity-recovery-native-prepared/releases/001`.
- Manifest SHA256: `5c70c590c3b776e00897a49192a6e1494ca7d4869bde2d54502a9f418ba12d4c`.
- Exact old bytes: `releases/001/baseline`; absent paths are clean-baseline additions.
- Exact new bytes: `releases/001/files` (all 44 changed files).
- Full reconstructed package source: `releases/001/reconstruction/full`.
- 33 production files and 11 test files. `production-files.txt` is the per-production-file Jev inventory.
- Full patch: `5e1e5cba749dd4ccc0c93d992eaaf63ae10fa1da717a0ac2147c758602cc8555`.
- Implementation patch: `e126a702ffe2334911b8c650042b6d25f8cdd850cc53aa720c2ef5e8ec7eed32`.
- Clean-baseline tests patch: `3a3c53218f074dbe08f35821d20d496456ffddde768eaad1bddd41c7892e0ee0`.
- Qualified-RED tests delta: `133c97a89c1d118fd971da46d67cda00eb5dc44aab391d8c27e56281d49d8220`.
- Each alternative reconstructs all 44 after hashes exactly; see reconstruction-proof.json. Only syntax inspection ran here; all production syntax parsed. No .NET, Git, Jev, GitHub, broker, external delivery, deployment or main-tree mutation was performed by this agent.

## Behavior and boundaries

UserIdentity retains a single valid active protection, one explicitly selected historical settlement and fixed identity/registration/revocation facts. The active protection was already bounded by valid decisions; `_settled` was the true lifetime collection. EmailAddress retains the current slot/claim/completion plus one explicitly selected historical claim/completion. Complete transient history readers retain every settlement, claim and completion; there is no pruning, expiry, count cap, dropped history, all-history owner alias or arbitrary callback authority.

Actual ChallengeId selectors come from the DTOs in protection, acceptance, recovered registration/revocation, settlement, email completion, notice, delivery and recovery query consumers. Unselected historical queries fail explicitly instead of returning false absence. Historical completion/notice remain independent of a newer current challenge. Default and executor-internal reads share a lifetime-preserving IdentityOwnerAggregateReader decorator after all existing persistence reader wrappers.

NativeOwnerHistory validates the complete actual physical/native prefix. Stable payload/identity and saved full-metadata commitments verify raw replay, including unselected historical records. Metadata attribution added by save is treated as a newly durable suffix; previously observed metadata prefixes remain compared before finalization. Every preparation cut includes physical/native positions plus payload and full metadata commitments. Registration proofs bind the actual raw record ResourceOffset; recovery effect proofs find the actual record on the exact scoped stream and call the installed explicit-position SourceFactProofs overload. Native versions are never used as physical offsets. Current independent audit-session behavior is preserved.

CompleteIdentityRecovery performs mutable identity reads and immutable candidate writes inside NativeOperationExecutor's receipt-first async preparation. It captures the old identity actually read and guards the originally prepared email cut through append. The first random continuation account candidate is frozen once. Materialize validates actual claim source/DTO bindings before receipt knowledge and validates the exact frozen header/candidate before first mutation. NativeReceiverPreparation handles expected failed preparation and equal winners. Protect/Accept/Reject mutable owner reads, Register's optional presentation read, and CompleteAccepted's candidate proof write run after native receipt knowledge. Necessary immutable source/intent/DTO validation remains first where accepted facts do not contain all request fields. Root Unit candidates are written inside native preparation. Cancellation and corruption retain distinct meanings; missing exact immutable/source dependencies remain pending.

All occupied Common event tags, payload versions, intent/result schemas, token/key handling, source proof fields, actor/episode conventions and historical FirstOwner-null semantics remain unchanged. No implicit migration or invented source/hold protocol is introduced. App session authentication reads need no constructor change because they use current identity authority through the default verified reader.

## RED qualification and acceptance limits

Root reported original v2 lifetime/dependency suite: 5 genuine failures, 3 positive controls (corrupt2/cancellation1), and the receiver suite: 4 genuine obsolete-dependency failures. Root reported admission cases1-2 as genuine lost equal-winning acknowledgment failures. Admission case3 already preserved the new current slot and rejected an obsolete claim on old code; its proposed transient-Conflict first-attempt expectation is an exact-cut design/classification gate, not an authorization vulnerability. The GREEN variant additionally proves a fresh retry still receives permanent Forbidden and appends no old claim.

EmailAcknowledgmentPreparationTests RED4 was frozen separately before production application; root owns its old-API qualification. Original RED source/patch/manifests remain outside release001 in red/, admission-red/, receiver-red/, unit-red/, plus revision1 historical artifacts. Do not rewrite those evidence bytes.

Root owns C# compilation/analyzers, focused/full/HTTP tests, format, direct Jev per production file, exact-head review, Git and merge. This package does not claim any of those gates passed. No new GitHub issues were created.
