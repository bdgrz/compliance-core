from pathlib import Path
base=Path('/tmp/compliance-identity-recovery-native-prepared/prepared/src/Compliance.Core/Features/UserIdentities')
replacements={
'IssueEmailChallengeHandler.cs':('''            address => address.PrepareIssueChallenge(request.UserId, request.ChallengeId, hash, expiresAt, now, keyId)
                is { IsSuccess: false } failed
                ? Result<FirstResponseDescriptor>.Failure(failed.Error!)
                : Result<FirstResponseDescriptor>.Success(response),''','''            address => preparation.Prepare(address,
                address.PrepareIssueChallenge(request.UserId, request.ChallengeId, hash, expiresAt, now, keyId), response),''', '''            (EmailAddress address, ImmutableContentRef frozen) => address.IssueChallenge(provenance, frozen,
                request.UserId, request.ChallengeId, hash, expiresAt, now, keyId))''','''            (EmailAddress address, ImmutableContentRef frozen) => preparation.Apply(address,
                () => address.IssueChallenge(provenance, frozen, request.UserId, request.ChallengeId, hash, expiresAt, now, keyId)))''','var preparation = new IdentityOwnerPreparation();'),
'CompleteEmailChallengeHandler.cs':('''            address => address.PrepareCompleteChallenge(request.UserId, request.ChallengeId, request.Token, now)
                is { IsSuccess: false } failed
                ? Result<FirstResponseDescriptor>.Failure(failed.Error!)
                : Result<FirstResponseDescriptor>.Success(response),''','''            address => preparation.Prepare(address,
                address.PrepareCompleteChallenge(request.UserId, request.ChallengeId, request.Token, now), response),''','''            (EmailAddress address, ImmutableContentRef frozen) => address.CompleteChallenge(provenance, frozen,
                request.UserId, request.ChallengeId, request.Token, now))''','''            (EmailAddress address, ImmutableContentRef frozen) => preparation.Apply(address,
                () => address.CompleteChallenge(provenance, frozen, request.UserId, request.ChallengeId, request.Token, now)))''','var preparation = new IdentityOwnerPreparation(current);'),
'ReserveEmailHandler.cs':('''            address => address.PrepareReserve(request.UserId, request.ExpectedRevision)
                is { IsSuccess: false } failed
                ? Result<FirstResponseDescriptor>.Failure(failed.Error!)
                : Result<FirstResponseDescriptor>.Success(response),''','''            address => preparation.Prepare(address,
                address.PrepareReserve(request.UserId, request.ExpectedRevision), response),''','''            (EmailAddress address, ImmutableContentRef frozen) => address.Reserve(provenance, frozen, request.UserId,
                request.ExpectedRevision))''','''            (EmailAddress address, ImmutableContentRef frozen) => preparation.Apply(address,
                () => address.Reserve(provenance, frozen, request.UserId, request.ExpectedRevision)))''','var preparation = new IdentityOwnerPreparation(current);'),
'StartIdentityRecoveryHandler.cs':('''            address => address.PrepareIssueRecoveryChallenge(address.Owner ?? Uuid.Empty, request.ChallengeId, hash,
                expiresAt, now, tokenKeys.ActiveKeyId, deliveryFailed) is { IsSuccess: false } failed
                ? Result<FirstResponseDescriptor>.Failure(failed.Error!)
                : Result<FirstResponseDescriptor>.Success(response),''','''            address => preparation.Prepare(address,
                address.PrepareIssueRecoveryChallenge(address.Owner ?? Uuid.Empty, request.ChallengeId, hash,
                    expiresAt, now, tokenKeys.ActiveKeyId, deliveryFailed), response),''','''            (EmailAddress address, ImmutableContentRef frozen) => address.IssueRecoveryChallenge(provenance, frozen,
                address.Owner ?? Uuid.Empty, request.ChallengeId, hash, expiresAt, now, tokenKeys.ActiveKeyId,
                deliveryFailed))''','''            (EmailAddress address, ImmutableContentRef frozen) => preparation.Apply(address,
                () => address.IssueRecoveryChallenge(provenance, frozen, address.Owner ?? Uuid.Empty, request.ChallengeId,
                    hash, expiresAt, now, tokenKeys.ActiveKeyId, deliveryFailed)))''','var preparation = new IdentityOwnerPreparation(current);'),
'CompleteIdentityRecoveryHandler.cs':('''            current => current.PrepareClaimIdentityRecovery(userId, request.ChallengeId, request.Token,
                request.OldIdentityId, replacementId, now) is { IsSuccess: false } failed
                ? Result<FirstResponseDescriptor>.Failure(failed.Error!)
                : Result<FirstResponseDescriptor>.Success(response),''','''            current => preparation.Prepare(current,
                current.PrepareClaimIdentityRecovery(userId, request.ChallengeId, request.Token,
                    request.OldIdentityId, replacementId, now), response),''','''            (EmailAddress current, ImmutableContentRef frozen) => current.ClaimIdentityRecovery(provenance, intent,
                frozen, actor, emailProof, replacementProof, now, userId, request.ChallengeId, request.Token,
                request.OldIdentityId, replacementId, now))''','''            (EmailAddress current, ImmutableContentRef frozen) => preparation.Apply(current,
                () => current.ClaimIdentityRecovery(provenance, intent, frozen, actor, emailProof, replacementProof, now,
                    userId, request.ChallengeId, request.Token, request.OldIdentityId, replacementId, now)))''','var preparation = new IdentityOwnerPreparation(address);')}
for name,(oldpre,newpre,oldapp,newapp,decl) in replacements.items():
 p=base/name;s=p.read_text();assert oldpre in s,name;assert oldapp in s,name;s=s.replace(oldpre,newpre).replace(oldapp,newapp)
 if name in ['StartIdentityRecoveryHandler.cs','CompleteIdentityRecoveryHandler.cs']:
  marker='        var accepted = await operations.ExecuteAsync('
 else:
  marker='        return EmailAddressOperations.Of(await operations.ExecuteAsync('
 assert marker in s,name;s=s.replace(marker,'        '+decl+'\n'+marker,1);p.write_text(s)
