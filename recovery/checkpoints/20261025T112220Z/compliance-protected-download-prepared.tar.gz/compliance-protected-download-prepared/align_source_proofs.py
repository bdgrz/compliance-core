from prep_common import *
common='src/Compliance.Common/Features/Evidence/'
p=root/'work'/common/'ArtifactDownloadTerminalSourceProof.cs';s=p.read_text();s=s.replace('    public abstract NativeFactReference Reference { get; }','''    [JsonIgnore] public abstract SourceFactProof Proof { get; }
    [JsonIgnore] public bool IsIssued => Proof is SourceFactProof<EvidenceArtifactDownloadIssued>;
    [JsonIgnore] public NativeFactReference Reference => new(Proof.Source, Proof.EventId, Proof.OwnerRevision);''')
s=s.replace('public sealed record IssuedArtifactDownloadSourceProof(SourceFactProof<EvidenceArtifactDownloadIssued> Proof)', 'public sealed record IssuedArtifactDownloadSourceProof(SourceFactProof<EvidenceArtifactDownloadIssued> Fact)')
s=s.replace('public sealed record CanceledArtifactDownloadSourceProof(SourceFactProof<ArtifactDownloadGrantCanceled> Proof)', 'public sealed record CanceledArtifactDownloadSourceProof(SourceFactProof<ArtifactDownloadGrantCanceled> Fact)')
s=s.replace('[JsonIgnore] public override NativeFactReference Reference => new(Proof.Source, Proof.EventId, Proof.OwnerRevision);','[JsonIgnore] public override SourceFactProof Proof => Fact;')
p.write_text(s)
for cmd in ['SettleAdvisorArtifactDownloadUse','SettleArtifactHandlingDownloadUse','SettleArtifactDownloadAvailabilityUse']:
 name=cmd+'SourceProof'
 put(common+name+'.cs','''using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Evidence;

'''+f'''/// <summary>The selected closed native issued-or-canceled source union for this settlement.</summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "kind", UnknownDerivedTypeHandling = JsonUnknownDerivedTypeHandling.FailSerialization)]
[JsonDerivedType(typeof(IssuedProof), "issued")]
[JsonDerivedType(typeof(CanceledProof), "canceled")]
public abstract record {name} : ArtifactDownloadTerminalSourceProof
{{
    private protected {name}() {{ }}
    public sealed record IssuedProof(SourceFactProof<EvidenceArtifactDownloadIssued> Fact) : {name}
    {{
        [JsonIgnore] public override SourceFactProof Proof => Fact;
    }}
    public sealed record CanceledProof(SourceFactProof<ArtifactDownloadGrantCanceled> Fact) : {name}
    {{
        [JsonIgnore] public override SourceFactProof Proof => Fact;
    }}
    public static {name} Of(ArtifactDownloadTerminalSourceProof value) => value.Proof switch
    {{
        SourceFactProof<EvidenceArtifactDownloadIssued> fact => new IssuedProof(fact),
        SourceFactProof<ArtifactDownloadGrantCanceled> fact => new CanceledProof(fact),
        _ => throw new ArgumentException("The terminal proof has no selected native grant variant.", nameof(value)),
    }};
}}
''')
 p=root/'work'/common/(cmd+'.cs');s=p.read_text().replace('ArtifactDownloadTerminalSourceProof Source',name+' Source').replace('Source is IssuedArtifactDownloadSourceProof','Source.IsIssued');p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Evidence/ArtifactDownloadSourceVerifier.cs';s=p.read_text().replace('switch (terminal)','switch (terminal.Proof)').replace('case IssuedArtifactDownloadSourceProof issued:', 'case SourceFactProof<EvidenceArtifactDownloadIssued> issued:').replace('resolver.VerifyAsync(issued.Proof','resolver.VerifyAsync(issued').replace('VerifyLocatorAsync(issued.Proof','VerifyLocatorAsync(issued').replace('case CanceledArtifactDownloadSourceProof canceled:', 'case SourceFactProof<ArtifactDownloadGrantCanceled> canceled:').replace('resolver.VerifyAsync(canceled.Proof','resolver.VerifyAsync(canceled').replace('VerifyLocatorAsync(canceled.Proof','VerifyLocatorAsync(canceled')
s=s.replace('use.Requirement != expected ||\n            operation.Owner', 'use.Requirement != expected || use.Disposition != disposition ||\n            operation.Owner')
p.write_text(s)
p=root/'work/src/Compliance.Core/Features/Evidence/ArtifactDownloadProcess.cs';s=p.read_text()
for cmd in ['SettleAdvisorArtifactDownloadUse','SettleArtifactHandlingDownloadUse','SettleArtifactDownloadAvailabilityUse']:
 s=s.replace(f'new {cmd}(step.CommandId, source,',f'new {cmd}(step.CommandId, {cmd}SourceProof.Of(source),')
p.write_text(s)
