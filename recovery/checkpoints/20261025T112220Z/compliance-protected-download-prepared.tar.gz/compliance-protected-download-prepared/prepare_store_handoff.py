from prep_common import *
import difflib, hashlib, json, subprocess
storefiles=[
'src/Compliance.Core/Features/Content/ProtectedResponseScope.cs',
'src/Compliance.Core/Features/Content/IProtectedResponseContentStore.cs',
'src/Compliance.Core/Features/Content/ProtectedResponseKeyRing.cs',
'src/Compliance.Core/Features/Content/AesProtectedResponseContentStore.cs',
' test/Compliance.Tests/Features/Content/AesProtectedResponseContentStoreTests.cs'.strip(),
]
put('docs/architecture/protected-response-storage.md','''# Protected response content storage

`AesProtectedResponseContentStore` persists encrypted original response bodies through `IImmutableContentStore`. It never generates a host-local or process-lifetime encryption key.

Configure `ProtectedResponses:ActiveKeyVersionId` and base64 AES keys under `ProtectedResponses:Keys:<version>`. Every decoded key is exactly 32 bytes. Equivalent environment variable names use double underscores, for example `ProtectedResponses__ActiveKeyVersionId` and `ProtectedResponses__Keys__version_1`. API and worker hosts must receive the same configured persistent key ring. Key values belong in the existing secret configuration source, never source control or logs.

Missing configuration fails closed when a new protected result is requested. Invalid key encoding, invalid key version identifiers, a missing configured active version or a key of the wrong size fails composition. Rotation selects a new active version while retaining all older versions needed by supported original-result replay. Restarting a host with the retained ring can read earlier ciphertext. Removing a needed decryption key leaves that result unavailable; it never mints a replacement capability. Disposal must follow the selected fail-closed replay-retention policy.

The version-one envelope contains a fixed versioned magic header, length-prefixed content identity/key version/result schema, a fresh 96-bit nonce, ciphertext and a 128-bit GCM tag. Its SHA-256 and byte length cover the complete envelope. Additional authenticated data includes the header, realm, all affected-owner address components, root operation UUID and original actor kind/identity. Display text is not actor identity. Authentication refuses swaps across actor, owner, realm, operation, schema, object identity or key version even if an adapter incorrectly returns bytes from another scope.

The store bounds plaintext to one MiB, verifies publication metadata, reads the envelope back, authenticates it and compares the round-trip plaintext before publishing a reference. No raw ticket/body is placed in the immutable storage adapter or an exception message. Read operations verify envelope metadata and digest again at the encryption boundary.

This storage subset does not enable the protected artifact download API. The selected admission/grant protocol remains separate until its independent first-owner collision and source-settlement recovery gate is resolved.
''')
storefiles.append('docs/architecture/protected-response-storage.md')
def export(name,files):
 out=[]
 for f in files:
  b=root/'base'/f;w=root/'work'/f
  out.extend(difflib.unified_diff(b.read_text().splitlines(True) if b.exists() else [],w.read_text().splitlines(True),
   fromfile='a/'+f if b.exists() else '/dev/null',tofile='b/'+f))
 (root/name).write_text(''.join(out))
export('aes-store-implementation.patch',[f for f in storefiles if not f.startswith('test/')])
export('aes-store-tests.patch',[f for f in storefiles if f.startswith('test/')])
shared={'independentStoreOnly':True,'registrations':['services.AddSingleton(ProtectedResponseKeyRing.FromConfiguration(configuration));','services.AddSingleton<IProtectedResponseContentStore, AesProtectedResponseContentStore>();'],'namespace':'Bdgrz.Compliance.Features.Content','jsonRootsRequired':[],'routesRequired':[],'protocolCutoverAllowed':False,'configuration':'ProtectedResponses:ActiveKeyVersionId; ProtectedResponses:Keys:<version> base64 exactly32bytes; no ephemeral fallback','focusedFilter':'FullyQualifiedName~AesProtectedResponseContentStoreTests'}
(root/'aes-store-shared-wiring-deltas.json').write_text(json.dumps(shared,indent=2)+'\n')
manifest={'subset':'Configured AES-256-GCM protected result storage only','headAtExport':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'validation':{'syntax':'all source and tests parsed without errors','build':'not run; parent owns runtime slot','runtimeTests':'not run'},'files':[{'path':f,'baseSha256':hashlib.sha256((root/'base'/f).read_bytes()).hexdigest() if (root/'base'/f).exists() else None,'sha256':hashlib.sha256((root/'work'/f).read_bytes()).hexdigest()}for f in storefiles]}
(root/'aes-store-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
allfiles=sorted(p.relative_to(root/'work').as_posix() for p in (root/'work').rglob('*') if p.is_file())
protocol=[f for f in allfiles if f not in storefiles]
export('protocol-unqualified-implementation.patch',[f for f in protocol if not f.startswith('test/')])
export('protocol-unqualified-tests.patch',[f for f in protocol if f.startswith('test/')])
(root/'protocol-unqualified-manifest.json').write_text(json.dumps({'qualified':False,'shipPublicCutover':False,'blocker':'S31-qualification-blocker.md','validation':'syntax only; no build/runtime/Jev','files':[{'path':f,'baseSha256':hashlib.sha256((root/'base'/f).read_bytes()).hexdigest() if (root/'base'/f).exists() else None,'sha256':hashlib.sha256((root/'work'/f).read_bytes()).hexdigest()}for f in protocol]},indent=2)+'\n')
print('store files',len(storefiles),'preserved unqualified protocol files',len(protocol))
