from prep_common import *
common='src/Compliance.Common/Features/Evidence/'
core='src/Compliance.Core/Features/Evidence/'
p=root/'work'/common/'IssueArtifactDownload.cs'
s=p.read_text()
a=s.index('    [JsonIgnore(Condition')
s=s[:a]+'''    Uuid? _programId;
    Uuid? _advisorHandoffId;
    AdvisorRecordVersion? _selectedSource;

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Uuid? ProgramId { get => _programId; init { _programId = value; ProgramIdSpecified = true; } }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Uuid? AdvisorHandoffId { get => _advisorHandoffId; init { _advisorHandoffId = value; AdvisorHandoffIdSpecified = true; } }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public AdvisorRecordVersion? SelectedSource { get => _selectedSource; init { _selectedSource = value; SelectedSourceSpecified = true; } }

    [JsonIgnore]
    public bool ProgramIdSpecified { get; private init; }

    [JsonIgnore]
    public bool AdvisorHandoffIdSpecified { get; private init; }

    [JsonIgnore]
    public bool SelectedSourceSpecified { get; private init; }
}
'''
p.write_text(s)
put(core+'ArtifactDownloadAuthoredIntent.cs','''using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Canonical authored scope, including omitted versus explicitly supplied optional fields.</summary>
public sealed record ArtifactDownloadAuthoredIntent(Uuid CommandId, Uuid TenantId, Uuid ArtifactId,
    string Purpose, long ExpectedArtifactRevision, bool ProgramIdSpecified, Uuid? ProgramId,
    bool AdvisorHandoffIdSpecified, Uuid? AdvisorHandoffId, bool SelectedSourceSpecified,
    AdvisorRecordVersion? SelectedSource)
{
    public static ArtifactDownloadAuthoredIntent Of(IssueArtifactDownload request) => new(request.CommandId,
        request.TenantId, request.ArtifactId, request.Purpose.Trim(), request.ExpectedArtifactRevision,
        request.ProgramIdSpecified, request.ProgramId, request.AdvisorHandoffIdSpecified, request.AdvisorHandoffId,
        request.SelectedSourceSpecified, request.SelectedSource);
}
''')
p=copy(core+'EvidenceArtifact.cs');s=p.read_text()
s='using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.SourceUse;\n'+s
s=s.replace('public sealed class EvidenceArtifact : Aggregate','public sealed partial class EvidenceArtifact : Aggregate, ISourceUseOwner')
s=s.replace('public EvidenceArtifact(Uuid tenantId, Uuid id)','public EvidenceArtifact(Uuid tenantId, Uuid id, Uuid selectedLogicalId = default)')
s=s.replace('        _tenantId = tenantId;','        _tenantId = tenantId;\n        Acceptance = new NativeAcceptance(selectedLogicalId);\n        Uses = new SourceUseReservations(Stream);\n        InitializeDownloads();',1)
s=s.replace('        On<EvidenceArtifactDownloadIssued>(ApplyDownload);\n','')
a=s.index('    public CommandFailure? RecordDownload(');b=s.index('    // Only a malware quarantine',a)
s=s[:a]+s[b:]
p.write_text(s)
put(core+'EvidenceArtifact.Downloads.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

public sealed partial class EvidenceArtifact
{
    readonly List<DomainEvent> _downloadFacts = [];
    public NativeAcceptance Acceptance { get; }
    public SourceUseReservations Uses { get; }
    public IReadOnlyList<DomainEvent> DownloadFacts => _downloadFacts;

    void InitializeDownloads()
    {
        On<EvidenceArtifactDownloadRequested>(fact =>
        {
            if (fact.Owner != Stream || fact.Revision != Revision || fact.Generation != 1 ||
                State != EvidenceArtifactStates.Available || fact.FirstResponse is null || fact.OperationResult is not null ||
                fact.Operation.Owner != Stream || fact.Operation.RootOperationId != fact.Operation.LogicalId)
                throw new InvalidOperationException("The artifact download admission is invalid.");
            Acceptance.Observe(fact);
            Uses.ApplyGranted(SourceUsePurpose.ArtifactDownload, fact);
            _downloadFacts.Add(fact);
        });
        On<ArtifactDownloadAvailabilityUseSettled>(fact =>
        {
            if (fact.Owner != Stream || fact.Revision != Revision || fact.Generation != 1 ||
                fact.Operation.Owner != Stream || fact.FirstResponse is not null || fact.OperationResult is not null)
                throw new InvalidOperationException("The artifact availability settlement is invalid.");
            Acceptance.Observe(fact);
            Uses.ApplySettled(SourceUsePurpose.ArtifactDownload, fact);
            _downloadFacts.Add(fact);
        });
    }

    public Result PrepareDownload(long expectedRevision)
    {
        if (!IsCreated)
            return Result.Failure(new RequestError(RequestErrorKind.NotFound, "The evidence artifact was not found."));
        if (State != EvidenceArtifactStates.Available || StateReason is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "Only available inspected evidence can be downloaded."));
        return expectedRevision == Revision ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict,
            "The expected artifact content revision is stale."));
    }

    public Result AdmitDownload(OperationProvenance operation, EvidenceDownloadIntent intent,
        ImmutableContentRef reference, ImmutableContentRef firstResponse)
    {
        if (operation.Owner != Stream || operation.AffectedOwner != Stream || operation.ExpectedRevisionOwner != Stream ||
            operation.RootOperationId != operation.LogicalId || operation.LogicalId != intent.GrantId ||
            intent.ArtifactId != Id || intent.ContentSha256 != ContentSha256 || intent.ContentLength != ContentLength ||
            intent.ArtifactRevision != (ulong)Revision || operation.OriginalExpectedRevision != (ulong)Revision ||
            intent.Header != ArtifactDownloadProtocol.Header(operation) || reference.Schema != EvidenceDownloadIntent.Schema)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The download admission differs from the exact artifact authority."));
        var prepared = PrepareDownload((long)intent.ArtifactRevision);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new EvidenceArtifactDownloadRequested(Stream, Revision, 1, reference, null, operation,
            firstResponse, null));
        return Result.Success;
    }

    public Result SettleDownloadAvailability(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        if (operation.Owner != Stream || generation != 1)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The availability settlement names another owner or generation."));
        RaiseEvent(new ArtifactDownloadAvailabilityUseSettled(Stream, Revision, generation, intent, null, operation,
            null, null));
        return Result.Success;
    }
}
''')
put(core+'ArtifactDownloadProtocol.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Exact identities and immutable schemas shared by admission, receivers and authorized result reads.</summary>
public static class ArtifactDownloadProtocol
{
    public const string LinkSchema = "evidence-artifact-download-link.v1";
    public const string RequirementsSchema = "artifact-download-source-requirement.v1";
    public const string ProofsSchema = "artifact-download-authorization-proofs.v1";
    public const string MutationResultSchema = "mutation-result-content.v1";
    public const long Generation = 1;

    public static DurableIntentHeader Header(OperationProvenance operation) => new(operation.RootOperationId,
        operation.FirstOwner ?? operation.Owner, operation.AffectedOwner, operation.ExpectedRevisionOwner,
        operation.Actor, operation.Episode, operation.OriginalExpectedRevision, operation.AuthoredIntentSha256,
        operation.AcceptedAt);

    public static ReservationKey Key(EvidenceDownloadIntent intent, EventStreamAddress target) => new(intent.GrantId,
        intent.Header.FirstOwner, Generation, target, SourceUseReservations.PurposeName(SourceUsePurpose.ArtifactDownload));

    public static ProtectedResponseScope Scope(EvidenceDownloadIntent intent) => new(intent.Header.FirstOwner.Realm,
        intent.Header.AffectedOwner, intent.GrantId, intent.Header.OriginalActor);

    public static async Task<T> ReadAsync<T>(IImmutableContentStore content, string realm,
        ImmutableContentRef reference, string schema, CancellationToken ct) where T : notnull
    {
        if (reference.Schema != schema)
            throw new ImmutableContentIntegrityException("The artifact download content has another schema.");
        return await content.ReadJsonAsync<T>(realm, reference, ct).ConfigureAwait(false);
    }
}
''')
put(core+'ArtifactDownloadGrant.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>One immutable protected original result, or its receiving pre-issue cancellation fence.</summary>
public sealed class ArtifactDownloadGrant : Aggregate
{
    public const string Area = "artifact-download-grants";
    readonly Uuid _tenantId;
    public NativeAcceptance Acceptance { get; }
    public EvidenceArtifactDownloadIssued? Issued { get; private set; }
    public ArtifactDownloadGrantCanceled? Canceled { get; private set; }
    public DomainEvent? Terminal => (DomainEvent?)Issued ?? Canceled;

    public ArtifactDownloadGrant(Uuid tenantId, Uuid grantId, Uuid selectedLogicalId = default)
        : base(grantId, new EventStreamAddress(tenantId.ToString(), Area, grantId.ToString()))
    {
        _tenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<EvidenceArtifactDownloadIssued>(fact =>
        {
            if (Terminal is not null || fact.TenantId != _tenantId || fact.GrantId != Id || fact.Revision != 1 ||
                fact.Operation.Owner != Stream || fact.Operation.RootOperationId != Id ||
                fact.Operation.Actor != fact.IssuedBy || fact.IssuedAt == default ||
                fact.FirstResponse is not null || fact.OperationResult is null)
                throw new InvalidOperationException("A protected grant is issued once on its own owner.");
            Acceptance.Observe(fact);
            Issued = fact;
        });
        On<ArtifactDownloadGrantCanceled>(fact =>
        {
            if (Terminal is not null || fact.Owner != Stream || fact.GrantId != Id || fact.Revision != 1 ||
                fact.Generation != ArtifactDownloadProtocol.Generation || fact.Operation.Owner != Stream ||
                fact.Operation.RootOperationId != Id || fact.FirstResponse is not null || fact.OperationResult is null)
                throw new InvalidOperationException("A grant cancellation fences issuance once on its own owner.");
            Acceptance.Observe(fact);
            Canceled = fact;
        });
    }

    public Result Issue(OperationProvenance operation, EvidenceDownloadIntent intent, ImmutableContentRef reference,
        ImmutableContentRef proofs, DateTimeOffset decisionAt, ImmutableContentRef result)
    {
        if (Terminal is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The grant already has its immutable terminal outcome."));
        if (!Matches(operation, intent, reference) || operation.CommandKind != nameof(IssueProtectedArtifactDownloadGrant) ||
            decisionAt < intent.Header.AcceptedAt || operation.AcceptedAt != decisionAt || result.Schema != ArtifactDownloadProtocol.MutationResultSchema)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The protected result differs from its admitted operation."));
        RaiseEvent(new EvidenceArtifactDownloadIssued(_tenantId, intent.ArtifactId, 1, intent.GrantId,
            intent.ContentSha256, intent.ContentLength, intent.Purpose, intent.Header.OriginalActor, decisionAt,
            operation, reference, Id, null, result));
        return Result.Success;
    }

    public Result Cancel(OperationProvenance operation, EvidenceDownloadIntent intent, ImmutableContentRef reference,
        ImmutableContentRef proof, ImmutableContentRef result)
    {
        if (Terminal is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "A committed grant recovers forward and cannot be canceled."));
        if (!Matches(operation, intent, reference) || operation.CommandKind != nameof(CancelProtectedArtifactDownloadGrant))
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The cancellation differs from its admitted operation."));
        RaiseEvent(new ArtifactDownloadGrantCanceled(Stream, 1, ArtifactDownloadProtocol.Generation, reference, proof,
            operation, Id, null, result));
        return Result.Success;
    }

    bool Matches(OperationProvenance operation, EvidenceDownloadIntent intent, ImmutableContentRef reference) =>
        operation.Owner == Stream && operation.AffectedOwner == Stream && operation.ExpectedRevisionOwner == Stream &&
        operation.FirstOwner == intent.Header.FirstOwner && operation.RootOperationId == Id && intent.GrantId == Id &&
        operation.Actor == intent.Header.OriginalActor && operation.Episode == intent.Header.Episode &&
        operation.AuthoredIntentSha256 == intent.Header.AuthoredIntentSha256 &&
        operation.OriginalExpectedRevision == intent.Header.OriginalExpectedRevision &&
        reference.Schema == EvidenceDownloadIntent.Schema;
}
''')
