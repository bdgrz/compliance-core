from prep_common import *
common='src/Compliance.Common/Features/Evidence/'
core='src/Compliance.Core/Features/Evidence/'
base='''using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

'''
for name,extra,idprop in [('AuthorizeAdvisorArtifactDownloadUse','Uuid HandoffId, Uuid ArtifactId, AdvisorRecordVersion SelectedSource','HandoffId'),('AuthorizeArtifactHandlingDownloadUse','Uuid ArtifactId, long PolicyVersion','ArtifactId')]:
 put(common+name+'.cs',base+f'''/// <summary>Acquires the exact frozen download use on its authoritative source owner.</summary>
[Discriminator("bdgrz.artifact-download.{name.lower()}", 1)]
public sealed record {name}(Uuid CommandId, SourceFactProof<EvidenceArtifactDownloadRequested> Source,
    EventStreamAddress Target, Uuid OperationId, long Generation, long? ExpectedRevision,
    ImmutableContentRef Intent, {extra}) : ISourceUseAuthorization, IArtifactDownloadReceiver
{{
    Uuid IIdentifiedRequest.RequestId => CommandId;
    NativeFactReference ISourceUseAuthorization.Source => new(Source.Source, Source.EventId, Source.OwnerRevision);
    [JsonIgnore] public Uuid SourceOwnerId => {idprop};
    [JsonIgnore] public Uuid SourceContentEventId => Uuid.Empty;
    [JsonIgnore] public ulong ExpectedContentRevision => 0;
}}
''')
put(common+'ArtifactDownloadTerminalSourceProof.cs',base+'''/// <summary>Closed issued-or-canceled grant proof; neither variant contains a plaintext result.</summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "kind", UnknownDerivedTypeHandling = JsonUnknownDerivedTypeHandling.FailSerialization)]
[JsonDerivedType(typeof(IssuedArtifactDownloadSourceProof), "issued")]
[JsonDerivedType(typeof(CanceledArtifactDownloadSourceProof), "canceled")]
public abstract record ArtifactDownloadTerminalSourceProof
{
    private protected ArtifactDownloadTerminalSourceProof() { }
    public abstract NativeFactReference Reference { get; }
}

public sealed record IssuedArtifactDownloadSourceProof(SourceFactProof<EvidenceArtifactDownloadIssued> Proof)
    : ArtifactDownloadTerminalSourceProof
{
    [JsonIgnore] public override NativeFactReference Reference => new(Proof.Source, Proof.EventId, Proof.OwnerRevision);
}

public sealed record CanceledArtifactDownloadSourceProof(SourceFactProof<ArtifactDownloadGrantCanceled> Proof)
    : ArtifactDownloadTerminalSourceProof
{
    [JsonIgnore] public override NativeFactReference Reference => new(Proof.Source, Proof.EventId, Proof.OwnerRevision);
}
''')
for name in ['SettleAdvisorArtifactDownloadUse','SettleArtifactHandlingDownloadUse','SettleArtifactDownloadAvailabilityUse']:
 put(common+name+'.cs',base+f'''/// <summary>Settles from an exact native issued grant or its receiving cancellation fence.</summary>
[Discriminator("bdgrz.artifact-download.{name.lower()}", 1)]
public sealed record {name}(Uuid CommandId, ArtifactDownloadTerminalSourceProof Source,
    EventStreamAddress Target, Uuid OperationId, long Generation, long? ExpectedRevision, ImmutableContentRef Intent,
    Uuid ArtifactId) : ISourceUseSettlement, IArtifactDownloadReceiver
{{
    Uuid IIdentifiedRequest.RequestId => CommandId;
    NativeFactReference ISourceUseSettlement.Source => Source.Reference;
    [JsonIgnore] public Uuid SourceOwnerId => ArtifactId;
    [JsonIgnore] public SourceUseSettlementDisposition Disposition => Source is IssuedArtifactDownloadSourceProof
        ? SourceUseSettlementDisposition.Completed : SourceUseSettlementDisposition.Canceled;
}}
''')
# Owner reservations; their own business content revisions remain the source pin across grant/settle facts.
ret='src/Compliance.Core/Features/Retention/'
put(ret+'EvidenceHandlingPolicy.Downloads.cs','''using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

public sealed partial class EvidenceHandlingPolicy
{
    public NativeAcceptance Acceptance { get; }
    public SourceUseReservations Uses { get; }
    readonly List<DomainEvent> _downloadFacts = [];
    public IReadOnlyList<DomainEvent> DownloadFacts => _downloadFacts;

    void InitializeDownloadUses()
    {
        On<ArtifactHandlingDownloadUseAuthorized>(fact => ApplyDownload(fact, granted: true));
        On<ArtifactHandlingDownloadUseSettled>(fact => ApplyDownload(fact, granted: false));
    }

    void ApplyDownload(ISourceUseFact fact, bool granted)
    {
        if (fact.Owner != Stream || fact.Operation.Owner != Stream || fact.Generation != ArtifactDownloadProtocol.Generation ||
            fact.FirstResponse is not null)
            throw new InvalidOperationException("The handling download use belongs to its exact owner and generation.");
        Acceptance.Observe((DomainEvent)fact);
        if (granted)
            Uses.ApplyGranted(SourceUsePurpose.ArtifactDownload, fact);
        else
            Uses.ApplySettled(SourceUsePurpose.ArtifactDownload, fact);
        _downloadFacts.Add((DomainEvent)fact);
    }

    public Result GrantDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new ArtifactHandlingDownloadUseAuthorized(Stream, Revision, generation, intent, null, operation, null, null));
        return Result.Success;
    }

    public Result SettleDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new ArtifactHandlingDownloadUseSettled(Stream, Revision, generation, intent, null, operation, null, null));
        return Result.Success;
    }
}
''')
p=copy('src/Compliance.Core/Features/AdvisorCollaboration/AdvisorHandoff.cs');s=p.read_text()
s='using Bdgrz.Compliance.Features.SourceUse;\n'+s
s=s.replace('public sealed class AdvisorHandoff : Aggregate','public sealed partial class AdvisorHandoff : Aggregate, ISourceUseOwner')
s=s.replace('        Acceptance = new NativeAcceptance(selectedLogicalId);','        Acceptance = new NativeAcceptance(selectedLogicalId);\n        Uses = new SourceUseReservations(Stream);\n        InitializeDownloadUses();',1)
# End and selection replacement are conflicting writers; a held source remains ready and exact until terminal grant.
s=s.replace('    public Result PrepareRevise(long expectedRevision)\n    {','    public Result PrepareRevise(long expectedRevision)\n    {\n        if (Uses.HasActiveUse)\n            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The shared selection is held by an admitted download.", true));')
s=s.replace('    public Result PrepareEnd(long expectedRevision)\n    {','    public Result PrepareEnd(long expectedRevision)\n    {\n        if (Uses.HasActiveUse)\n            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The shared selection is held by an admitted download.", true));')
p.write_text(s)
put('src/Compliance.Core/Features/AdvisorCollaboration/AdvisorHandoff.Downloads.cs','''using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AdvisorCollaboration;

public sealed partial class AdvisorHandoff
{
    public SourceUseReservations Uses { get; }

    void InitializeDownloadUses()
    {
        On<AdvisorArtifactDownloadUseAuthorized>(fact => ApplyDownload(fact, fact.Revision, granted: true));
        On<AdvisorArtifactDownloadUseSettled>(fact => ApplyDownload(fact, fact.Revision, granted: false));
    }

    void ApplyDownload(ISourceUseFact fact, long revision, bool granted)
    {
        if (fact.Owner != Stream || fact.Operation.Owner != Stream || revision != _revision + 1 ||
            fact.Generation != ArtifactDownloadProtocol.Generation || fact.FirstResponse is not null ||
            granted && (!IsCreated || Status != ReadyForReview))
            throw new InvalidOperationException("The advisor artifact use belongs to the exact handoff at its next revision.");
        Acceptance.Observe((DomainEvent)fact);
        if (granted)
            Uses.ApplyGranted(SourceUsePurpose.ArtifactDownload, fact);
        else
            Uses.ApplySettled(SourceUsePurpose.ArtifactDownload, fact);
        Advance((DomainEvent)fact, fact.Operation.AcceptedAt);
    }

    public Result GrantArtifactDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new AdvisorArtifactDownloadUseAuthorized(Stream, Revision + 1, generation, intent, null, operation, null, null));
        return Result.Success;
    }

    public Result SettleArtifactDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new AdvisorArtifactDownloadUseSettled(Stream, Revision + 1, generation, intent, null, operation, null, null));
        return Result.Success;
    }
}
''')
# Keep optional source content-bound policy valid after a clean inspection of the same immutable upload.
p=root/'work'/core/'EvidenceDownloadAdmission.cs';s=p.read_text().replace(' || applied.SourceState != EvidenceArtifactStates.Available','');p.write_text(s)
