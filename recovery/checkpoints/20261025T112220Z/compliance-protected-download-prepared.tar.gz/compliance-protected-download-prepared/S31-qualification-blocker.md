# S31 protected download protocol remains unqualified

Do not apply the public handler/owner/process cutover or its shared registrations/routes. The independently qualified candidate subset is the AES store only, exported separately. No main source was edited and no runtime check was run here.

Selected identity collision:

- `remaining-command-identities.json` selects `IssueArtifactDownload` admission on each `EvidenceArtifact` with caller `CommandId`.
- `durable-intent-schemas.json` requires `EvidenceDownloadIntent.GrantId == root CommandId`.
- `target-owner-extensions.json` selects independent `ArtifactDownloadGrant` identity `tenant / GrantId (= root CommandId)`, with one immutable Issued or Canceled result.
- The installed `NativeOperationExecutor` resolves logical IDs on one owner. It has no realm-wide first-owner binding. Two different artifact owners can concurrently accept the same UUID and pin their availability before either child grant exists.
- Their child grants collide. The first grant wins its immutable terminal fact. The second artifact admission cannot accept a second cancellation fence on that same already-terminal grant owner, and the foreign first-owner fact is invalid authority for settling the second admission's pins.

The prepared code fails closed before replay/decrypt/settlement when a terminal grant has a different exact first owner or immutable intent. This prevents disclosure and incorrect settlement, but leaves a quarantined process with held sources for the losing admission. A fail-closed check is not complete lifecycle recovery. Shipping this public cutover would therefore be unsafe.

A selected-contract decision or independently atomic realm binding/fence is needed before this protocol can ship. No global lookup/authority has been invented. Existing #1042/#1055 are the local ledger references; no new GitHub issue was created. Bare-operation routes remain disabled.

An additive internal `Target: EventStreamAddress` on CancelProtectedArtifactDownloadGrant preserves every selected field and supplies realm routing for its opaque failure-proof ref. This does not add a public lookup contract.

The unqualified source/tests are preserved as `protocol-unqualified-{implementation,tests}.patch` and `protocol-unqualified-manifest.json`. They have syntax-only inspection; compile/runtime/Jev and the missing collision recovery gate remain outstanding. The standalone old-API regression is preserved separately as behavioral-red.patch.
