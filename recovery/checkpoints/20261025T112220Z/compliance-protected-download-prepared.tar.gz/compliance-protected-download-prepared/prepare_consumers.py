from prep_common import *
# Evidence metadata accepts safe download authority/audit facts without changing content availability revision.
p=copy('src/Compliance.Core/Features/Evidence/EvidenceArtifactMetadataRead.cs');s=p.read_text()
a=s.index('                case EvidenceArtifactDownloadIssued ev');b=s.index('                default:',a)
s=s[:a]+'''                case EvidenceArtifactDownloadRequested ev when ev.Owner == artifact.Stream &&
                    ev.Generation == ArtifactDownloadProtocol.Generation && ev.Revision == artifact.Revision &&
                    ev.Operation.Owner == artifact.Stream && ev.Operation.CommandKind == nameof(IssueArtifactDownload) &&
                    ev.Intent.Schema == EvidenceDownloadIntent.Schema && ev.FirstResponse is not null:
                    break;
                case ArtifactDownloadAvailabilityUseSettled ev when ev.Owner == artifact.Stream &&
                    ev.Generation == ArtifactDownloadProtocol.Generation && ev.Revision == artifact.Revision &&
                    ev.Operation.Owner == artifact.Stream && ev.Intent.Schema == SourceUse.SourceUseAuthorizationIntent.Schema:
                    break;
'''+s[b:]
p.write_text(s)
# Advisor directory must project all use facts so its logical and physical cursors remain contiguous.
p=copy('src/Compliance.Core/Features/AdvisorCollaboration/AdvisorHandoffDirectoryProjector.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Evidence;\n'+s
s=s.replace('      IProjectorHandler<AdvisorFeedbackAdmitted>','      IProjectorHandler<AdvisorFeedbackAdmitted>,\n      IProjectorHandler<AdvisorArtifactDownloadUseAuthorized>,\n      IProjectorHandler<AdvisorArtifactDownloadUseSettled>')
pos=s.rfind('}')
s=s[:pos]+'''    public ValueTask HandleAsync(AdvisorArtifactDownloadUseAuthorized ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);

    public ValueTask HandleAsync(AdvisorArtifactDownloadUseSettled ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);
'''+s[pos:]
p.write_text(s)
p=copy('src/Compliance.Core/Features/AdvisorCollaboration/FitzAdvisorHandoffDirectory.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Evidence;\nusing Bdgrz.Compliance.Features.SourceUse;\n'+s
s=s.replace('            AdvisorFeedbackAdmitted ev => TenantOf(ev),','''            AdvisorFeedbackAdmitted ev => TenantOf(ev),
            AdvisorArtifactDownloadUseAuthorized ev => Uuid.Parse(ev.Owner.Realm, System.Globalization.CultureInfo.InvariantCulture),
            AdvisorArtifactDownloadUseSettled ev => Uuid.Parse(ev.Owner.Realm, System.Globalization.CultureInfo.InvariantCulture),''')
s=s.replace('            case AdvisorFeedbackAdmitted admitted:', '''            case AdvisorArtifactDownloadUseAuthorized authorized:
                await ApplyDownloadUseAsync(authorized, authorized.Revision, granted: true, ct).ConfigureAwait(false);
                break;
            case AdvisorArtifactDownloadUseSettled settled:
                await ApplyDownloadUseAsync(settled, settled.Revision, granted: false, ct).ConfigureAwait(false);
                break;
            case AdvisorFeedbackAdmitted admitted:''')
pos=s.index('    async ValueTask ApplyFeedbackAdmittedAsync')
s=s[:pos]+'''    async ValueTask ApplyDownloadUseAsync(ISourceUseFact fact, long revision, bool granted, CancellationToken ct)
    {
        var ev = (DomainEvent)fact;
        if (fact.Owner.Area != AdvisorHandoff.Area || fact.Generation != ArtifactDownloadProtocol.Generation ||
            !Uuid.TryParse(fact.Owner.Resource, System.Globalization.CultureInfo.InvariantCulture, out var handoffId) ||
            fact.Operation.Owner != fact.Owner || fact.Operation.AcceptedAt == default)
            throw InvalidEvent();
        var current = await AdvisorHandoffDirectorySchema.Handoffs.GetAsync(Transaction, handoffId, ct)
            .ConfigureAwait(false) ?? throw new InvalidOperationException("An advisor download use projected before handoff creation.");
        if (IsAlreadyProjected(current, ev))
            return;
        if (revision != current.Revision + 1 || fact.Operation.AcceptedAt < current.UpdatedAt ||
            granted && current.Status != AdvisorHandoff.ReadyForReview)
            throw InvalidEvent();
        await ReplaceAsync(current, WithEventMetadata(current with
        {
            Revision = revision,
            UpdatedAt = fact.Operation.AcceptedAt,
        }, ev), ct).ConfigureAwait(false);
    }

'''+s[pos:]
p.write_text(s)
# Type I evidence source content revisions exclude the newly separated download/usage history.
p=copy('src/Compliance.Core/Features/Examinations/EvidenceGovernanceTypeIBaselineSourceContributor.cs');s=p.read_text()
s='using Bdgrz.Compliance.Features.SourceUse;\n'+s
s=s.replace('artifactGroup.Key, through, artifact.Value.AsOfRevision, ct)', 'artifactGroup.Key, through, artifact.Value.AsOfPhysicalPosition, ct)')
s=s.replace('        long asOfRevision = 0;', '        long asOfRevision = 0;\n        long asOfPhysicalPosition = 0;')
s=s.replace('                asOfRevision++;\n                try', '''                asOfPhysicalPosition = index + 1;
                if (item.Event is EvidenceArtifactDownloadRequested or ArtifactDownloadAvailabilityUseSettled)
                {
                    priorOccurredAt = metadata.OccurredOn;
                    continue;
                }
                asOfRevision++;
                try''')
s=s.replace('aggregate.Revision != first.Value.Count ||', 'aggregate.Revision != first.Value.Count(item => item.Event is EvidenceArtifactRegistered or EvidenceArtifactInspected or EvidenceArtifactQuarantineReleased) ||')
s=s.replace('new(registration, state, reason, asOfRevision,\n            Array.AsReadOnly', 'new(registration, state, reason, asOfRevision, asOfPhysicalPosition,\n            Array.AsReadOnly')
a=s.index('            case EvidenceArtifactDownloadIssued ev when');b=s.index('            default:',a)
s=s[:a]+'''            case EvidenceArtifactDownloadRequested ev when registration is not null &&
                state == EvidenceArtifactStates.Available && reason is null &&
                ev.Owner == EvidenceStreams.Address(tenantId, artifactId) && ev.Generation == ArtifactDownloadProtocol.Generation &&
                ev.Operation.Owner == ev.Owner && ev.Operation.CommandKind == nameof(IssueArtifactDownload) &&
                ev.Operation.AcceptedAt == occurredOn && ev.Intent.Schema == EvidenceDownloadIntent.Schema && ev.FirstResponse is not null:
                return true;
            case ArtifactDownloadAvailabilityUseSettled ev when registration is not null &&
                ev.Owner == EvidenceStreams.Address(tenantId, artifactId) && ev.Generation == ArtifactDownloadProtocol.Generation &&
                ev.Operation.Owner == ev.Owner && ev.Operation.AcceptedAt == occurredOn && ev.Intent.Schema == SourceUseAuthorizationIntent.Schema:
                return true;
'''+s[b:]
# Classification reader checks physical continuity separately from content revision continuity.
a=s.index('        foreach (var record in read.Value)', s.index('ReadHandlingPolicyAsOfAsync(' ,s.index('static bool TryApplyArtifactEvent')))
b=s.index('\n        var policy = await aggregates.HydrateAsync',a)
s=s[:a]+'''        foreach (var record in read.Value)
        {
            if (record.Stream != stream || record.Event?.Metadata is not { } metadata ||
                metadata.AggregateId != policyId || metadata.EventId == Uuid.Empty ||
                !eventIds.Add(metadata.EventId) || metadata.AggregateVersion != expectedVersion ||
                metadata.OccurredOn == default || priorOccurredAt is { } prior && metadata.OccurredOn < prior)
                return InvalidHistory<EvidenceHandlingPolicyView?>();
            if (record.Event is ArtifactHandlingDownloadUseAuthorized or ArtifactHandlingDownloadUseSettled)
            {
                var use = (ISourceUseFact)record.Event;
                if (use.Owner != stream || use.Operation.Owner != stream || use.Generation != ArtifactDownloadProtocol.Generation ||
                    use.Operation.AcceptedAt != metadata.OccurredOn || use.Intent.Schema != SourceUseAuthorizationIntent.Schema)
                    return InvalidHistory<EvidenceHandlingPolicyView?>();
            }
            else
            {
                if (!TryReadHandlingPolicyEvent(record.Event, tenantId, artifactId, (ulong)states.Count + 1,
                        metadata.OccurredOn, states, out var state))
                    return InvalidHistory<EvidenceHandlingPolicyView?>();
                states.Add(state);
            }
            expectedVersion++;
            priorOccurredAt = metadata.OccurredOn;
        }
'''+s[b:]
s=s.replace('StateReason, long AsOfRevision, IReadOnlyList<EvidenceGovernanceSourceEvent> Events)', 'StateReason, long AsOfRevision, long AsOfPhysicalPosition, IReadOnlyList<EvidenceGovernanceSourceEvent> Events)')
p.write_text(s)
