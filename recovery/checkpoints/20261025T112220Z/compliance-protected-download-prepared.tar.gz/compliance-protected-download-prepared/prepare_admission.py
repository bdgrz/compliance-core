from prep_common import *
core='src/Compliance.Core/Features/Evidence/'
p=root/'work'/core/'EvidenceArtifact.cs';s=p.read_text().replace('    EvidenceArtifactRegistered? _registration;','    EvidenceArtifactRegistered? _registration;\n    DomainEvent? _availabilityFact;')
s=s.replace('            _revision++;','            _revision++;\n            _availabilityFact = ev;',1)
s=s.replace('        _quarantineRelease = ev;','        _quarantineRelease = ev;\n        _availabilityFact = ev;')
s=s.replace('    internal EvidenceArtifactRegistered? Registration => _registration;','    internal EvidenceArtifactRegistered? Registration => _registration;\n    internal DomainEvent? AvailabilityFact => _availabilityFact;')
p.write_text(s)
# Retain classification source fact explicitly, since physical use facts do not change content identity.
p=copy('src/Compliance.Core/Features/Retention/EvidenceHandlingPolicy.cs');s=p.read_text()
s=s.replace('public sealed class EvidenceHandlingPolicy : Aggregate','public sealed partial class EvidenceHandlingPolicy : Aggregate, ISourceUseOwner')
s='using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.SourceUse;\n'+s
s=s.replace('    EvidenceHandlingPolicyView? _current;','    EvidenceHandlingPolicyView? _current;\n    DomainEvent? _contentFact;\n    internal DomainEvent? ContentFact => _contentFact;')
s=s.replace('public EvidenceHandlingPolicy(Uuid tenantId, Uuid artifactId)','public EvidenceHandlingPolicy(Uuid tenantId, Uuid artifactId, Uuid selectedLogicalId = default)')
s=s.replace('        _tenantId = tenantId;','        Acceptance = new NativeAcceptance(selectedLogicalId);\n        Uses = new SourceUseReservations(Stream);\n        InitializeDownloadUses();\n        _tenantId = tenantId;',1)
s=s.replace('On<ArtifactHandlingPolicyAssigned>(Apply);','On<ArtifactHandlingPolicyAssigned>(fact => { Apply(fact); _contentFact = fact; });')
s=s.replace('On<ArtifactHandlingPolicyRevised>(Apply);','On<ArtifactHandlingPolicyRevised>(fact => { Apply(fact); _contentFact = fact; });')
s=s.replace('        var revision = Revision + 1;','        if (Uses.HasActiveUse)\n            return Result.Failure(new RequestError(RequestErrorKind.Conflict,\n                "The current handling classification is held by an admitted download.", true));\n\n        var revision = Revision + 1;',1)
p.write_text(s)
put(core+'EvidenceDownloadAdmission.cs','''using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Freezes complete exact handling and optional handoff requirements before the artifact admission.</summary>
sealed class EvidenceDownloadAdmission(IAggregateReader reader, IImmutableContentStore content,
    AdvisorHandoffReader handoffs, EvidenceArtifactMetadataRead metadata)
{
    public async Task<EvidenceDownloadIntent> FreezeAsync(EvidenceArtifact artifact, IssueArtifactDownload request,
        OperationProvenance operation, CancellationToken ct)
    {
        var realm = artifact.Stream.Realm;
        var captured = await metadata.GetCapturedAsync(request.TenantId, request.ArtifactId, ct).ConfigureAwait(false);
        if (!captured.IsSuccess || captured.Value.AvailabilityRecordedAt is not { } available ||
            available > operation.AcceptedAt || artifact.AvailabilityFact is not { } availableFact ||
            captured.Value.Metadata.ContentSha256 != artifact.ContentSha256 || captured.Value.Metadata.ContentLength != artifact.ContentLength)
            throw new ImmutableContentUnavailableException("The exact available inspected artifact is not readable yet.");
        var policy = await reader.HydrateAsync(new EvidenceHandlingPolicy(request.TenantId, request.ArtifactId), ct)
            .ConfigureAwait(false);
        var applied = policy.Current;
        if (applied is not null && (applied.Source.ContentSha256 != artifact.ContentSha256 ||
                applied.ContentLength != artifact.ContentLength || applied.SourceState != EvidenceArtifactStates.Available))
            throw new ImmutableContentIntegrityException("The handling classification concerns another artifact identity or state.");
        var policyFacts = new EvidenceDownloadPinnedFacts("handling", request.ArtifactId, artifact.ContentSha256!,
            artifact.ContentLength!.Value, applied?.PolicyVersion ?? EvidenceHandlingPolicy.CurrentPolicyVersion,
            applied?.HandlingClass ?? artifact.Content!.HandlingClass, null, null, null, null, null);
        var requiredFacts = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), EvidenceDownloadPinnedFacts.Schema,
            policyFacts, ct).ConfigureAwait(false);
        var requirements = new List<SourceUseRequirement>
        {
            new(policy.Stream, NativeFactReference.Of(policy.ContentFact is null ? artifact.Stream : policy.Stream,
                policy.ContentFact ?? availableFact), (ulong)policy.Revision, SourceUsePurpose.ArtifactDownload, requiredFacts),
        };
        if (request.ProgramId is { } program && request.AdvisorHandoffId is { } handoffId && request.SelectedSource is { } selected)
        {
            var snapshot = await handoffs.ReadAsync(request.TenantId, program, handoffId, ct).ConfigureAwait(false);
            var handoff = snapshot.Handoff;
            if (handoff.ProgramId != program || handoff.Status != AdvisorHandoff.ReadyForReview ||
                !snapshot.Selection.Contains(selected) || handoff.ExpiresOn < DateOnly.FromDateTime(operation.AcceptedAt.UtcDateTime))
                throw new ImmutableContentIntegrityException("The exact selected source is not shared by a ready unexpired handoff.");
            var selectionFact = handoff.Facts.Last(fact => fact is AdvisorHandoffCreated or AdvisorHandoffSelectionRevised);
            var until = new DateTimeOffset(handoff.ExpiresOn.AddDays(1).ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc));
            var handoffFacts = new EvidenceDownloadPinnedFacts("handoff", request.ArtifactId, artifact.ContentSha256!,
                artifact.ContentLength.Value, 0, policyFacts.HandlingClass, program, handoffId, selected,
                handoff.SelectionManifest, until);
            var reference = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), EvidenceDownloadPinnedFacts.Schema,
                handoffFacts, ct).ConfigureAwait(false);
            requirements.Add(new SourceUseRequirement(handoff.Stream, NativeFactReference.Of(handoff.Stream, selectionFact),
                (ulong)handoff.Revision, SourceUsePurpose.ArtifactDownload, reference));
        }
        var manifest = await content.WriteSelectionAsync(realm, Uuid.CreateVersion4(), ArtifactDownloadProtocol.RequirementsSchema,
            requirements.OrderBy(row => row.SourceOwner.ToString(), StreamKeyOrder.Instance).ToArray(), SelectionOrder.CanonicalKey,
            ct).ConfigureAwait(false);
        return new EvidenceDownloadIntent(ArtifactDownloadProtocol.Header(operation), request.CommandId, request.ArtifactId,
            artifact.ContentSha256!, artifact.ContentLength!.Value, (ulong)artifact.Revision, request.Purpose.Trim(),
            request.ProgramId, request.AdvisorHandoffId, request.SelectedSource, manifest, ArtifactContentLimits.MaxDeliveryLifetime);
    }
}
''')
put(core+'IssueArtifactDownloadHandler.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Admits and pins a personal download; every exact write retry returns its original fixed 202.</summary>
sealed class IssueArtifactDownloadHandler(EvidenceArtifactDownloadAccess access, EvidenceDownloadAdmission admission,
    NativeOperationExecutor operations, IImmutableContentStore content, IProtectedResponseContentStore protectedContent,
    TimeProvider clock) : IRequestHandler<IssueArtifactDownload, OperationAcceptedResponse>
{
    public async ValueTask<Result<OperationAcceptedResponse>> HandleAsync(IRequestContext<IssueArtifactDownload> context,
        CancellationToken ct)
    {
        var request = context.Request;
        if (!PersonalHttpActor(context.Actor, context.Invocation, request.TenantId, out var actor))
            return Failure(RequestErrorKind.Forbidden, "Artifact downloads require a personal HTTP request.");
        var allowed = await access.RequireAsync(context, request.TenantId, request.ArtifactId, request.ProgramId,
            request.AdvisorHandoffId, request.SelectedSource, ct).ConfigureAwait(false);
        if (!allowed.IsSuccess)
            return Result<OperationAcceptedResponse>.Failure(allowed.Error!);
        if (request.CommandId == Uuid.Empty || request.TenantId == Uuid.Empty || request.ArtifactId == Uuid.Empty ||
            request.ExpectedArtifactRevision < 0 || string.IsNullOrWhiteSpace(request.Purpose) ||
            request.Purpose.Trim().Length > EvidenceRules.MaximumTextLength)
            return Failure(RequestErrorKind.Validation, "A download requires exact identities, a nonnegative revision and a bounded purpose.");
        var owner = new EvidenceArtifact(request.TenantId, request.ArtifactId, request.CommandId);
        var operation = RootOperation.Provenance(request.CommandId, nameof(IssueArtifactDownload), owner.Stream, actor,
            request.ExpectedArtifactRevision, AuthoredIntentDigest.Compute(ArtifactDownloadAuthoredIntent.Of(request)), clock.GetUtcNow());
        EvidenceDownloadIntent? intent = null;
        ImmutableContentRef? reference = null;
        try
        {
            var outcome = await operations.ExecuteAsync(new NativeOperation<EvidenceArtifact>(AcceptedOperationBinding.Of(operation),
                () => new EvidenceArtifact(request.TenantId, request.ArtifactId, request.CommandId), aggregate => aggregate.Acceptance,
                async (aggregate, token) =>
                {
                    var prepared = aggregate.PrepareDownload(request.ExpectedArtifactRevision);
                    if (!prepared.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(prepared.Error!);
                    try
                    {
                        protectedContent.RequireConfigured();
                        intent = await admission.FreezeAsync(aggregate, request, operation, token).ConfigureAwait(false);
                        reference = await content.WriteJsonAsync(owner.Stream.Realm, Uuid.CreateVersion4(), EvidenceDownloadIntent.Schema,
                            intent, token).ConfigureAwait(false);
                        var body = await content.WriteJsonAsync(owner.Stream.Realm, Uuid.CreateVersion4(), "operation-accepted-response.v1",
                            new OperationAcceptedResponse(request.CommandId,
                                $"/api/v1/tenants/{request.TenantId}/operations/{request.CommandId}", operation.AcceptedAt), token).ConfigureAwait(false);
                        return Result<FirstResponseDescriptor>.Success(new FirstResponseDescriptor(202,
                            ImmutableContentStoreExtensions.JsonMediaType, "operation-accepted-response.v1", new StandardResponseBody(body)));
                    }
                    catch (ImmutableContentUnavailableException)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "Download authority or protected response storage is not available yet.", true));
                    }
                    catch (ImmutableContentIntegrityException)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The exact download authority cannot be verified."));
                    }
                }, (aggregate, frozen) => aggregate.AdmitDownload(operation, intent!, reference!, frozen)), context, ct)
                .ConfigureAwait(false);
            return await NativeContent.ResponseAsync<OperationAcceptedResponse>(content, request.TenantId, outcome, ct)
                .ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException)
        {
            return Failure(RequestErrorKind.Conflict, "The original download acceptance is not available yet.", true);
        }
        catch (ImmutableContentIntegrityException)
        {
            return Failure(RequestErrorKind.Conflict, "The original download acceptance cannot be verified.");
        }
    }

    internal static bool PersonalHttpActor(System.Security.Claims.ClaimsPrincipal principal, RequestInvocation invocation,
        Uuid tenantId, out ActorReference actor)
    {
        actor = null!;
        if (invocation is not HttpInvocation || RequestActor.IsSystem(principal) ||
            !UserIdentityClaims.TryGetBdgrzSubject(principal, out var user))
            return false;
        actor = ActorReference.ForMember(RbacIds.Member(tenantId, user), UserIdentityClaims.BdgrzDisplay(principal, user));
        return true;
    }

    static Result<OperationAcceptedResponse> Failure(RequestErrorKind kind, string message, bool transient = false) =>
        Result<OperationAcceptedResponse>.Failure(new RequestError(kind, message, transient));
}
''')
