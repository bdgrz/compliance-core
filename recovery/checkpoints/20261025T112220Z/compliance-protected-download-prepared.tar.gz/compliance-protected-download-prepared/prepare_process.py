from prep_common import *
core='src/Compliance.Core/Features/Evidence/'
put(core+'ArtifactDownloadProcess.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Canonical source acquisition, verified protected issue, then complete source settlement.</summary>
public static class ArtifactDownloadProcess
{
    public const string Name = "ArtifactDownloadProcess";
    public static ProcessDefinition Definition() => new(Name, [nameof(EvidenceArtifactDownloadRequested)], true,
    [
        new ProcessStageDefinition("acquire", [nameof(AuthorizeAdvisorArtifactDownloadUse), nameof(AuthorizeArtifactHandlingDownloadUse)])
            { Targeting = StageTargeting.Interleaved },
        new ProcessStageDefinition("issue", [nameof(IssueProtectedArtifactDownloadGrant)], PerTarget: true),
        new ProcessStageDefinition("settle", [nameof(SettleAdvisorArtifactDownloadUse), nameof(SettleArtifactHandlingDownloadUse),
            nameof(SettleArtifactDownloadAvailabilityUse)]) { Targeting = StageTargeting.Interleaved },
    ], [nameof(CancelProtectedArtifactDownloadGrant)], CreateAsync);

    static async ValueTask<IRequest<ReceiverOutcome>?> CreateAsync(ProcessStep step, IServiceProvider services, CancellationToken ct)
    {
        var content = services.GetRequiredService<IImmutableContentStore>();
        var resolver = services.GetRequiredService<ISourceFactResolver>();
        var reader = services.GetRequiredService<IAggregateReader>();
        var verifier = services.GetRequiredService<ArtifactDownloadSourceVerifier>();
        var tenant = Uuid.Parse(step.Record.Key.Realm, CultureInfo.InvariantCulture);
        var proven = await SourceFactProofs.BuildAsync<EvidenceArtifactDownloadRequested>(resolver, content,
            step.Record.Key.Realm, step.Record.Source, ct).ConfigureAwait(false);
        var original = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, step.Record.Key.Realm,
            step.Record.Intent, EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
        var download = await verifier.AdmissionAsync(proven.Proof, step.Record.Intent, step.Record.Key.RootOperationId,
            original.ArtifactId, ArtifactDownloadProtocol.Generation, ct).ConfigureAwait(false);
        var intent = download.Intent;
        var grant = new ArtifactDownloadGrant(tenant, intent.GrantId).Stream;
        var expectedTargets = download.Requirements.Select(row => row.SourceOwner.ToString())
            .Append(intent.Header.FirstOwner.ToString()).Append(grant.ToString()).Distinct(StringComparer.Ordinal).Order(StreamKeyOrder.Instance).ToArray();
        if (!step.Record.Targets.SequenceEqual(expectedTargets, StringComparer.Ordinal) || step.Record.Episode != intent.Header.Episode)
            throw new ImmutableContentIntegrityException("The download process targets differ from its exact complete frozen selection.");
        if (step.Receiver == nameof(CancelProtectedArtifactDownloadGrant))
        {
            var failure = await FailureAsync(step, download, services, ct).ConfigureAwait(false);
            return new CancelProtectedArtifactDownloadGrant(step.CommandId, grant, intent.GrantId, intent.GrantId,
                ArtifactDownloadProtocol.Generation, failure);
        }
        if (step.Receiver == nameof(IssueProtectedArtifactDownloadGrant))
        {
            if (step.Target != grant.ToString())
                return null;
            var proofs = download.Requirements.Select(row => step.Record.Facts.TryGetValue(ProcessRecord.FactKey(
                row.SourceOwner.Area == AdvisorHandoff.Area ? nameof(AuthorizeAdvisorArtifactDownloadUse) : nameof(AuthorizeArtifactHandlingDownloadUse),
                row.SourceOwner.ToString()), out var proof) ? proof : throw new ImmutableContentUnavailableException("A required source acquisition has no committed proof yet.")).ToArray();
            var proofContent = await content.WriteJsonAsync(step.Record.Key.Realm, Uuid.CreateVersion5(step.CommandId, ArtifactDownloadProtocol.ProofsSchema),
                ArtifactDownloadProtocol.ProofsSchema, (IReadOnlyList<NativeFactReference>)proofs, ct).ConfigureAwait(false);
            return new IssueProtectedArtifactDownloadGrant(step.CommandId, proven.Proof, grant, intent.GrantId,
                ArtifactDownloadProtocol.Generation, null, step.Record.Intent, intent.GrantId, intent.ArtifactId, proofContent);
        }
        var requirement = download.Requirements.SingleOrDefault(row => row.SourceOwner.ToString() == step.Target);
        if (step.Stage == "acquire")
        {
            if (requirement is null)
                return null;
            var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
            if (step.Receiver == nameof(AuthorizeAdvisorArtifactDownloadUse) && facts.Kind == "handoff")
                return new AuthorizeAdvisorArtifactDownloadUse(step.CommandId, proven.Proof, requirement.SourceOwner, intent.GrantId,
                    ArtifactDownloadProtocol.Generation, null, await UseIntentAsync(content, intent, step.Record.Intent, requirement, step.CommandId, null, ct).ConfigureAwait(false),
                    intent.AdvisorHandoffId!.Value, intent.ArtifactId, intent.SelectedSource!);
            if (step.Receiver == nameof(AuthorizeArtifactHandlingDownloadUse) && facts.Kind == "handling")
                return new AuthorizeArtifactHandlingDownloadUse(step.CommandId, proven.Proof, requirement.SourceOwner, intent.GrantId,
                    ArtifactDownloadProtocol.Generation, null, await UseIntentAsync(content, intent, step.Record.Intent, requirement, step.CommandId, null, ct).ConfigureAwait(false),
                    intent.ArtifactId, facts.PolicyVersion);
            return null;
        }
        if (step.Stage != "settle" || step.Target == grant.ToString())
            return null;
        var terminal = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, intent.GrantId), ct).ConfigureAwait(false);
        ArtifactDownloadTerminalSourceProof source;
        if (terminal.Issued is { } issued)
            source = new IssuedArtifactDownloadSourceProof((await SourceFactProofs.BuildAsync<EvidenceArtifactDownloadIssued>(resolver, content,
                step.Record.Key.Realm, NativeFactReference.Of(grant, issued), ct).ConfigureAwait(false)).Proof);
        else if (terminal.Canceled is { } canceled)
            source = new CanceledArtifactDownloadSourceProof((await SourceFactProofs.BuildAsync<ArtifactDownloadGrantCanceled>(resolver, content,
                step.Record.Key.Realm, NativeFactReference.Of(grant, canceled), ct).ConfigureAwait(false)).Proof);
        else
            throw new ImmutableContentUnavailableException("No native issued grant or receiving cancellation fence is visible yet.");
        var disposition = source is IssuedArtifactDownloadSourceProof ? SourceUseSettlementDisposition.IrreversibleDecision : SourceUseSettlementDisposition.Canceled;
        if (step.Target == intent.Header.FirstOwner.ToString())
        {
            if (step.Receiver != nameof(SettleArtifactDownloadAvailabilityUse))
                return null;
            requirement = new SourceUseRequirement(intent.Header.FirstOwner, step.Record.Source, intent.ArtifactRevision,
                SourceUsePurpose.ArtifactDownload, step.Record.Intent);
        }
        if (requirement is null)
            throw new ImmutableContentIntegrityException("The settlement names an unselected source.");
        var use = await UseIntentAsync(content, intent, step.Record.Intent, requirement, step.CommandId, disposition, ct).ConfigureAwait(false);
        if (step.Receiver == nameof(SettleArtifactDownloadAvailabilityUse) && requirement.SourceOwner == intent.Header.FirstOwner)
            return new SettleArtifactDownloadAvailabilityUse(step.CommandId, source, requirement.SourceOwner, intent.GrantId,
                ArtifactDownloadProtocol.Generation, null, use, intent.ArtifactId);
        if (step.Receiver == nameof(SettleAdvisorArtifactDownloadUse) && requirement.SourceOwner.Area == AdvisorHandoff.Area)
            return new SettleAdvisorArtifactDownloadUse(step.CommandId, source, requirement.SourceOwner, intent.GrantId,
                ArtifactDownloadProtocol.Generation, null, use, intent.ArtifactId);
        if (step.Receiver == nameof(SettleArtifactHandlingDownloadUse) && requirement.SourceOwner.Area == "evidence-handling-policies")
            return new SettleArtifactHandlingDownloadUse(step.CommandId, source, requirement.SourceOwner, intent.GrantId,
                ArtifactDownloadProtocol.Generation, null, use, intent.ArtifactId);
        return null;
    }

    static Task<ImmutableContentRef> UseIntentAsync(IImmutableContentStore content, EvidenceDownloadIntent intent,
        ImmutableContentRef parent, SourceUseRequirement requirement, Uuid commandId, SourceUseSettlementDisposition? disposition,
        CancellationToken ct) => content.WriteJsonAsync(intent.Header.FirstOwner.Realm,
            Uuid.CreateVersion5(commandId, "artifact-download-command-intent"), SourceUseAuthorizationIntent.Schema,
            new SourceUseAuthorizationIntent(intent.Header, parent, ArtifactDownloadProtocol.Key(intent, requirement.SourceOwner), requirement,
                null, disposition), ct);

    static async Task<ImmutableContentRef> FailureAsync(ProcessStep step, VerifiedArtifactDownload download,
        IServiceProvider services, CancellationToken ct)
    {
        var content = services.GetRequiredService<IImmutableContentStore>();
        var reader = services.GetRequiredService<IAggregateReader>();
        var verifier = services.GetRequiredService<ArtifactDownloadSourceVerifier>();
        var tenant = Uuid.Parse(step.Record.Key.Realm, CultureInfo.InvariantCulture);
        var intent = download.Intent;
        var current = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, intent.GrantId), ct).ConfigureAwait(false);
        if (current.Canceled is { SourceProofs: { } original })
            return original;
        var now = services.GetRequiredService<TimeProvider>().GetUtcNow();
        string? reason = current.Issued is not null ? "recover_forward" : null;
        EventStreamAddress? failedSource = null;
        ImmutableContentRef? ticketObservation = null;
        if (reason is null)
        {
            foreach (var requirement in download.Requirements)
            {
                var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
                if (facts.ValidUntil is { } until && now >= until)
                {
                    reason = ArtifactDownloadFailureProof.SourceExpired;
                    failedSource = requirement.SourceOwner;
                    break;
                }
                var pinned = facts.Kind == "handling"
                    ? ArtifactDownloadUsePins.Policy(await reader.HydrateAsync(new EvidenceHandlingPolicy(tenant, intent.ArtifactId), ct).ConfigureAwait(false), requirement)
                    : ArtifactDownloadUsePins.Handoff(await reader.HydrateAsync(new AdvisorHandoff(tenant, intent.ProgramId!.Value, intent.AdvisorHandoffId!.Value), ct).ConfigureAwait(false), requirement);
                if (!pinned)
                {
                    reason = ArtifactDownloadFailureProof.SourceRevoked;
                    failedSource = requirement.SourceOwner;
                    break;
                }
            }
        }
        if (reason is null)
        {
            var issueId = EffectIdentity.CommandId(step.Record.Source.EventId,
                $"{Name}:{nameof(IssueProtectedArtifactDownloadGrant)}", current.Stream.ToString(), intent.Header.Episode);
            var observation = IssueProtectedArtifactDownloadGrantHandler.TicketObservation(download, issueId);
            ticketObservation = ArtifactDownloadCancellationProofs.TicketReference(observation);
            _ = await ArtifactDownloadProtocol.ReadAsync<ArtifactDownloadTicketObservation>(content, step.Record.Key.Realm,
                ticketObservation, ArtifactDownloadTicketObservation.Schema, ct).ConfigureAwait(false);
            reason = ArtifactDownloadFailureProof.TicketInvalid;
        }
        return await content.WriteJsonAsync(step.Record.Key.Realm, Uuid.CreateVersion4(), ArtifactDownloadFailureProof.Schema,
            new ArtifactDownloadFailureProof(intent.GrantId, ArtifactDownloadProtocol.Generation, step.Record.Source,
                step.Record.Intent, reason, failedSource, now, ticketObservation), ct).ConfigureAwait(false);
    }
}
''')
put(core+'ArtifactDownloadAdmissionReactor.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Persists the complete process before advancing the artifact admission checkpoint.</summary>
sealed partial class ArtifactDownloadAdmissionReactor(IProjectionCheckpointStore checkpoints, ProcessRootReaction process,
    IImmutableContentStore content) : Reactor(checkpoints, EventStreamPattern.ForTenant("evidence-artifacts"), WorkloadName),
    IReactorHandler<EvidenceArtifactDownloadRequested>
{
    public const string WorkloadName = "ArtifactDownloadAdmissionV1";
    public async ValueTask HandleAsync(IReactorContext<EvidenceArtifactDownloadRequested> context, CancellationToken ct)
    {
        var intent = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, context.Source.Stream.Realm,
            context.Trigger.Intent, EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
        var requirements = await content.ReadSelectionAsync<SourceUseRequirement>(context.Source.Stream.Realm,
            intent.RequiredSourceUses, ct).ConfigureAwait(false);
        var targets = requirements.Select(row => row.SourceOwner.ToString()).Append(context.Source.Stream.ToString())
            .Append(new ArtifactDownloadGrant(Uuid.Parse(context.Source.Stream.Realm, System.Globalization.CultureInfo.InvariantCulture), intent.GrantId).Stream.ToString());
        _ = await process.StartAsync(ArtifactDownloadProcess.Name, context, context.Trigger.Intent, targets,
            $"reactor:{WorkloadName}", ct).ConfigureAwait(false);
    }
}
''')
put(core+'ArtifactDownloadReceiverAuthorizer.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Internal-only protocol surface; handlers independently bind every source, owner and effect key.</summary>
sealed class ArtifactDownloadReceiverAuthorizer : IRequestAuthorizer<IArtifactDownloadReceiver>
{
    public ValueTask<Result> AuthorizeAsync(IRequestContext<IArtifactDownloadReceiver> context, CancellationToken ct) =>
        ValueTask.FromResult(RequestActor.IsSystem(context.Actor) ? Result.Success : Result.Failure(new RequestError(
            RequestErrorKind.Forbidden, "Only the internal artifact download process may dispatch download effects.")));
}
''')
