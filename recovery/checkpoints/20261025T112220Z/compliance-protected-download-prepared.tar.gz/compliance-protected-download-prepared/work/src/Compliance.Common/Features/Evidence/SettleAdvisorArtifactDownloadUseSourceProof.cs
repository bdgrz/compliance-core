using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>The selected closed native issued-or-canceled source union for this settlement.</summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "kind", UnknownDerivedTypeHandling = JsonUnknownDerivedTypeHandling.FailSerialization)]
[JsonDerivedType(typeof(IssuedProof), "issued")]
[JsonDerivedType(typeof(CanceledProof), "canceled")]
public abstract record SettleAdvisorArtifactDownloadUseSourceProof : ArtifactDownloadTerminalSourceProof
{
    private protected SettleAdvisorArtifactDownloadUseSourceProof() { }
    public sealed record IssuedProof(SourceFactProof<EvidenceArtifactDownloadIssued> Fact) : SettleAdvisorArtifactDownloadUseSourceProof
    {
        [JsonIgnore] public override SourceFactProof Proof => Fact;
    }
    public sealed record CanceledProof(SourceFactProof<ArtifactDownloadGrantCanceled> Fact) : SettleAdvisorArtifactDownloadUseSourceProof
    {
        [JsonIgnore] public override SourceFactProof Proof => Fact;
    }
    public static SettleAdvisorArtifactDownloadUseSourceProof Of(ArtifactDownloadTerminalSourceProof value) => value.Proof switch
    {
        SourceFactProof<EvidenceArtifactDownloadIssued> fact => new IssuedProof(fact),
        SourceFactProof<ArtifactDownloadGrantCanceled> fact => new CanceledProof(fact),
        _ => throw new ArgumentException("The terminal proof has no selected native grant variant.", nameof(value)),
    };
}
