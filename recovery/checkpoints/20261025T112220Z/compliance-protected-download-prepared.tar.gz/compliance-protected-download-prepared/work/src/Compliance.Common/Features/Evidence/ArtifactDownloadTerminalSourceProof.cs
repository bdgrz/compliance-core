using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Closed issued-or-canceled grant proof; neither variant contains a plaintext result.</summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "kind", UnknownDerivedTypeHandling = JsonUnknownDerivedTypeHandling.FailSerialization)]
[JsonDerivedType(typeof(IssuedArtifactDownloadSourceProof), "issued")]
[JsonDerivedType(typeof(CanceledArtifactDownloadSourceProof), "canceled")]
public abstract record ArtifactDownloadTerminalSourceProof
{
    private protected ArtifactDownloadTerminalSourceProof() { }
    [JsonIgnore] public abstract SourceFactProof Proof { get; }
    [JsonIgnore] public bool IsIssued => Proof is SourceFactProof<EvidenceArtifactDownloadIssued>;
    [JsonIgnore] public NativeFactReference Reference => new(Proof.Source, Proof.EventId, Proof.OwnerRevision);
}

public sealed record IssuedArtifactDownloadSourceProof(SourceFactProof<EvidenceArtifactDownloadIssued> Fact)
    : ArtifactDownloadTerminalSourceProof
{
    [JsonIgnore] public override SourceFactProof Proof => Fact;
}

public sealed record CanceledArtifactDownloadSourceProof(SourceFactProof<ArtifactDownloadGrantCanceled> Fact)
    : ArtifactDownloadTerminalSourceProof
{
    [JsonIgnore] public override SourceFactProof Proof => Fact;
}
