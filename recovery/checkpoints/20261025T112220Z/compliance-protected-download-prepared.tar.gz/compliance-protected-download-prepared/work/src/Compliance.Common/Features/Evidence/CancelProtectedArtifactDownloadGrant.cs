using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Processes;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Fences an unissued grant before any source uses are settled.</summary>
[Discriminator("bdgrz.artifact-download-grant.cancel", 1)]
public sealed record CancelProtectedArtifactDownloadGrant(Uuid CommandId, EventStreamAddress Target, Uuid GrantId, Uuid RootOperationId,
    long Generation, ImmutableContentRef FailureProof) : IRequest<ReceiverOutcome>, IIdentifiedRequest,
    IArtifactDownloadReceiver
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}
