using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Processes;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Issues only the protected result of the exact admitted artifact download.</summary>
[Discriminator("bdgrz.artifact-download-grant.issue", 1)]
public sealed record IssueProtectedArtifactDownloadGrant(Uuid CommandId,
    SourceFactProof<EvidenceArtifactDownloadRequested> Source, EventStreamAddress Target, Uuid OperationId,
    long Generation, long? ExpectedRevision, ImmutableContentRef Intent, Uuid GrantId, Uuid ArtifactId,
    ImmutableContentRef AuthorizationProofs) : IRequest<ReceiverOutcome>, IIdentifiedRequest, IArtifactDownloadReceiver
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}
