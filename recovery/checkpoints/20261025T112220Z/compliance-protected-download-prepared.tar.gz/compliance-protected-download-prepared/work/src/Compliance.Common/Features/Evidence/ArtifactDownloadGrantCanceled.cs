using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>ArtifactDownloadGrantCanceled on its authoritative owner; confidential ticket bytes are never carried here.</summary>
[Discriminator("bdgrz.artifact-download-grant.artifact-download-grant-canceled", 1)]
public sealed record ArtifactDownloadGrantCanceled(EventStreamAddress Owner, long Revision, long Generation, ImmutableContentRef Intent, ImmutableContentRef? SourceProofs, OperationProvenance Operation, Uuid GrantId, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult) : DomainEvent, INativeOperationFact;
