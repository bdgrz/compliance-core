using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>EvidenceArtifactDownloadRequested on its authoritative owner; confidential ticket bytes are never carried here.</summary>
[Discriminator("bdgrz.evidence-artifact.evidence-artifact-download-requested", 1)]
public sealed record EvidenceArtifactDownloadRequested(EventStreamAddress Owner, long Revision, long Generation, ImmutableContentRef Intent, ImmutableContentRef? SourceProofs, OperationProvenance Operation, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult) : DomainEvent, ISourceUseFact;
