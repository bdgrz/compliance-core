using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>ArtifactHandlingDownloadUseSettled on its authoritative owner; confidential ticket bytes are never carried here.</summary>
[Discriminator("bdgrz.evidence-handling-policy.artifact-handling-download-use-settled", 1)]
public sealed record ArtifactHandlingDownloadUseSettled(EventStreamAddress Owner, long Revision, long Generation, ImmutableContentRef Intent, ImmutableContentRef? SourceProofs, OperationProvenance Operation, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult) : DomainEvent, ISourceUseFact;
