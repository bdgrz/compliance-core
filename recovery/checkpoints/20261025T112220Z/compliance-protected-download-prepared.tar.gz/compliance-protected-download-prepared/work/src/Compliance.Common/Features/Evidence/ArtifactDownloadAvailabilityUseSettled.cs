using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>ArtifactDownloadAvailabilityUseSettled on its authoritative owner; confidential ticket bytes are never carried here.</summary>
[Discriminator("bdgrz.evidence-artifact.artifact-download-availability-use-settled", 1)]
public sealed record ArtifactDownloadAvailabilityUseSettled(EventStreamAddress Owner, long Revision, long Generation, ImmutableContentRef Intent, ImmutableContentRef? SourceProofs, OperationProvenance Operation, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult) : DomainEvent, ISourceUseFact;
