namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Trusted internal artifact download protocol command; never an HTTP or MCP entry point.</summary>
public interface IArtifactDownloadReceiver;
