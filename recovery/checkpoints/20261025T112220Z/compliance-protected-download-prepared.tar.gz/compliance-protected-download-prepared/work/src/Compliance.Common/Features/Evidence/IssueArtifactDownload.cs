using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Personal HTTP admission of one immutable artifact download operation.</summary>
[Discriminator("bdgrz.evidence.artifact.download.issue", 1)]
public sealed record IssueArtifactDownload(Uuid CommandId, Uuid TenantId, Uuid ArtifactId, string Purpose,
    long ExpectedArtifactRevision) : IRequest<OperationAcceptedResponse>, IClientManagementMutationRequest,
    IIdentifiedRequest, ICallable
{
    Uuid IIdentifiedRequest.RequestId => CommandId;

    Uuid? _programId;
    Uuid? _advisorHandoffId;
    AdvisorRecordVersion? _selectedSource;

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Uuid? ProgramId { get => _programId; init { _programId = value; ProgramIdSpecified = true; } }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Uuid? AdvisorHandoffId { get => _advisorHandoffId; init { _advisorHandoffId = value; AdvisorHandoffIdSpecified = true; } }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public AdvisorRecordVersion? SelectedSource { get => _selectedSource; init { _selectedSource = value; SelectedSourceSpecified = true; } }

    [JsonIgnore]
    public bool ProgramIdSpecified { get; private init; }

    [JsonIgnore]
    public bool AdvisorHandoffIdSpecified { get; private init; }

    [JsonIgnore]
    public bool SelectedSourceSpecified { get; private init; }
}
