using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Acquires the exact frozen download use on its authoritative source owner.</summary>
[Discriminator("bdgrz.artifact-download.authorizeadvisorartifactdownloaduse", 1)]
public sealed record AuthorizeAdvisorArtifactDownloadUse(Uuid CommandId, SourceFactProof<EvidenceArtifactDownloadRequested> Source,
    EventStreamAddress Target, Uuid OperationId, long Generation, long? ExpectedRevision,
    ImmutableContentRef Intent, Uuid HandoffId, Uuid ArtifactId, AdvisorRecordVersion SelectedSource) : ISourceUseAuthorization, IArtifactDownloadReceiver
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
    NativeFactReference ISourceUseAuthorization.Source => new(Source.Source, Source.EventId, Source.OwnerRevision);
    [JsonIgnore] public Uuid SourceOwnerId => HandoffId;
    [JsonIgnore] public Uuid SourceContentEventId => Uuid.Empty;
    [JsonIgnore] public ulong ExpectedContentRevision => 0;
}
