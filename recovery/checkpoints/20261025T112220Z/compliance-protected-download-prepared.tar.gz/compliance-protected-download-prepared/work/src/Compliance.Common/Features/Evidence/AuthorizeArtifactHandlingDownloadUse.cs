using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Acquires the exact frozen download use on its authoritative source owner.</summary>
[Discriminator("bdgrz.artifact-download.authorizeartifacthandlingdownloaduse", 1)]
public sealed record AuthorizeArtifactHandlingDownloadUse(Uuid CommandId, SourceFactProof<EvidenceArtifactDownloadRequested> Source,
    EventStreamAddress Target, Uuid OperationId, long Generation, long? ExpectedRevision,
    ImmutableContentRef Intent, Uuid ArtifactId, long PolicyVersion) : ISourceUseAuthorization, IArtifactDownloadReceiver
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
    NativeFactReference ISourceUseAuthorization.Source => new(Source.Source, Source.EventId, Source.OwnerRevision);
    [JsonIgnore] public Uuid SourceOwnerId => ArtifactId;
    [JsonIgnore] public Uuid SourceContentEventId => Uuid.Empty;
    [JsonIgnore] public ulong ExpectedContentRevision => 0;
}
