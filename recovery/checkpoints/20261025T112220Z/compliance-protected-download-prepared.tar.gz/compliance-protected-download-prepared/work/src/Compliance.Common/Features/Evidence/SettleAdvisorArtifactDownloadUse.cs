using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Settles from an exact native issued grant or its receiving cancellation fence.</summary>
[Discriminator("bdgrz.artifact-download.settleadvisorartifactdownloaduse", 1)]
public sealed record SettleAdvisorArtifactDownloadUse(Uuid CommandId, SettleAdvisorArtifactDownloadUseSourceProof Source,
    EventStreamAddress Target, Uuid OperationId, long Generation, long? ExpectedRevision, ImmutableContentRef Intent,
    Uuid ArtifactId) : ISourceUseSettlement, IArtifactDownloadReceiver
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
    NativeFactReference ISourceUseSettlement.Source => Source.Reference;
    [JsonIgnore] public Uuid SourceOwnerId => ArtifactId;
    [JsonIgnore] public SourceUseSettlementDisposition Disposition => Source.IsIssued
        ? SourceUseSettlementDisposition.IrreversibleDecision : SourceUseSettlementDisposition.Canceled;
}
