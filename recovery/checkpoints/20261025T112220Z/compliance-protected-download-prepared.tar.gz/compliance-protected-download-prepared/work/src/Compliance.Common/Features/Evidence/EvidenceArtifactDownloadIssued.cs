using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>One immutable grant of an original encrypted personal download result.</summary>
[Discriminator("bdgrz.evidence.evidence-artifact-download-issued", 1)]
public sealed record EvidenceArtifactDownloadIssued(Uuid TenantId, Uuid ArtifactId, long Revision, Uuid RequestId, string ContentSha256, long ContentLength, string Purpose, ActorReference IssuedBy, DateTimeOffset IssuedAt, OperationProvenance Operation, ImmutableContentRef Intent, Uuid GrantId, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult, ImmutableContentRef SourceProofs) : DomainEvent, INativeOperationFact;
