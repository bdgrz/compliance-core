using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>The selected closed native issued-or-canceled source union for this settlement.</summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "kind", UnknownDerivedTypeHandling = JsonUnknownDerivedTypeHandling.FailSerialization)]
[JsonDerivedType(typeof(IssuedProof), "issued")]
[JsonDerivedType(typeof(CanceledProof), "canceled")]
public abstract record SettleArtifactDownloadAvailabilityUseSourceProof : ArtifactDownloadTerminalSourceProof
{
    private protected SettleArtifactDownloadAvailabilityUseSourceProof() { }
    public sealed record IssuedProof(SourceFactProof<EvidenceArtifactDownloadIssued> Fact) : SettleArtifactDownloadAvailabilityUseSourceProof
    {
        [JsonIgnore] public override SourceFactProof Proof => Fact;
    }
    public sealed record CanceledProof(SourceFactProof<ArtifactDownloadGrantCanceled> Fact) : SettleArtifactDownloadAvailabilityUseSourceProof
    {
        [JsonIgnore] public override SourceFactProof Proof => Fact;
    }
    public static SettleArtifactDownloadAvailabilityUseSourceProof Of(ArtifactDownloadTerminalSourceProof value) => value.Proof switch
    {
        SourceFactProof<EvidenceArtifactDownloadIssued> fact => new IssuedProof(fact),
        SourceFactProof<ArtifactDownloadGrantCanceled> fact => new CanceledProof(fact),
        _ => throw new ArgumentException("The terminal proof has no selected native grant variant.", nameof(value)),
    };
}
