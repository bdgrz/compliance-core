using System.Globalization;
using System.Text.Json;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Publishes one verified protected original result before appending the irreversible native grant.</summary>
public sealed class IssueProtectedArtifactDownloadGrantHandler(IAggregateReader reader, ReceiverAppend append,
    ArtifactDownloadSourceVerifier verifier, ArtifactDownloadIssueProofs sourceUses, IArtifactContentStore artifacts,
    IImmutableContentStore content, IProtectedResponseContentStore protectedContent, TimeProvider clock)
    : IRequestHandler<IssueProtectedArtifactDownloadGrant, ReceiverOutcome>
{
    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<IssueProtectedArtifactDownloadGrant> context, CancellationToken ct)
    {
        var command = context.Request;
        if (command.CommandId == Uuid.Empty || command.GrantId != command.OperationId || command.ExpectedRevision is not (null or 0) ||
            !Uuid.TryParse(command.Target.Realm, CultureInfo.InvariantCulture, out var tenant) ||
            command.Target != new ArtifactDownloadGrant(tenant, command.GrantId).Stream)
            return ReceiverAppend.Invalid("The protected grant names another owner, operation or revision.");
        try
        {
            var download = await verifier.AdmissionAsync(command.Source, command.Intent, command.OperationId, command.ArtifactId,
                command.Generation, ct).ConfigureAwait(false);
            var intent = download.Intent;
            if (command.CommandId != EffectIdentity.CommandId(command.Source.EventId,
                    $"{ArtifactDownloadProcess.Name}:{nameof(IssueProtectedArtifactDownloadGrant)}", command.Target.ToString(), intent.Header.Episode))
                return ReceiverAppend.Invalid("The protected grant differs from its exact source effect key.");
            var decisionAt = clock.GetUtcNow();
            var operation = SourceUseReceiverSupport.Child(command.CommandId, nameof(IssueProtectedArtifactDownloadGrant),
                command.Source.EventId, intent.Header, command.Target, decisionAt);
            var binding = AcceptedOperationBinding.Of(operation);
            var current = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), ct).ConfigureAwait(false);
            if (!current.HasExactRoot(intent, command.Intent))
                return ReceiverAppend.Invalid("The grant identity belongs to a different first owner or admitted intent.");
            if (Decide(current, binding) is { } existing)
                return existing;
            var authorized = await sourceUses.VerifyAsync(download, command.AuthorizationProofs, decisionAt, ct).ConfigureAwait(false);
            if (!authorized.IsSuccess)
            {
                current = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), ct).ConfigureAwait(false);
                if (!current.HasExactRoot(intent, command.Intent))
                    return ReceiverAppend.Invalid("The grant identity belongs to a different first owner or admitted intent.");
                return Decide(current, binding) ?? ReceiverAppend.Rejected(authorized.Error!.Message);
            }
            var identity = new ArtifactContentReference(tenant, intent.ContentSha256, intent.ContentLength);
            ArtifactDelivery? ticket;
            try
            {
                ticket = await artifacts.IssueDeliveryAsync(identity, intent.MaxDeliveryLifetime, ct).ConfigureAwait(false);
            }
            catch (Exception exception) when (exception is not OperationCanceledException)
            {
                // Adapter exceptions can include a capability URI. Never put those messages in durable process notes or logs.
                return ReceiverAppend.Wait("The bounded ticket adapter is temporarily unavailable.");
            }
            if (ticket is null)
                return ReceiverAppend.Wait("The pinned artifact bytes are not available yet.");
            if (!Valid(ticket, identity, decisionAt, intent.MaxDeliveryLifetime))
            {
                var observation = TicketObservation(download, command.CommandId);
                _ = await content.WriteJsonAsync(command.Target.Realm, TicketObservationId(command.CommandId),
                    ArtifactDownloadTicketObservation.Schema, observation, ct).ConfigureAwait(false);
                return ReceiverAppend.Rejected("The bounded ticket adapter returned an invalid outcome.");
            }
            var link = new EvidenceArtifactDownloadLink(ticket.Location, ticket.ExpiresAt);
            var plaintext = JsonSerializer.SerializeToUtf8Bytes(link, ComplianceCoreJsonContext.Default.EvidenceArtifactDownloadLink);
            var encrypted = await protectedContent.WriteVerifiedAsync(ArtifactDownloadProtocol.Scope(intent), ArtifactDownloadProtocol.LinkSchema,
                plaintext, ct).ConfigureAwait(false);
            var result = new MutationResultContent(ArtifactDownloadProtocol.LinkSchema, new ProtectedResponseBody(encrypted));
            var frozenResult = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion4(), ArtifactDownloadProtocol.MutationResultSchema,
                result, ct).ConfigureAwait(false);
            var verified = await ArtifactDownloadProtocol.ReadAsync<MutationResultContent>(content, command.Target.Realm, frozenResult,
                ArtifactDownloadProtocol.MutationResultSchema, ct).ConfigureAwait(false);
            if (verified != result)
                return ReceiverAppend.Invalid("The opaque protected result descriptor did not verify.");
            return await append.ApplyAsync(() => new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), owner => owner.Acceptance,
                binding, owner => !owner.HasExactRoot(intent, command.Intent)
                    ? ReceiverAppend.Invalid("The grant identity belongs to another first owner or admitted intent.") : owner.Canceled is not null ? ReceiverAppend.Rejected("The receiving grant is canceled; its source uses must settle.")
                    : owner.Issued is not null ? ReceiverAppend.Invalid("The grant was issued by another effect.") : null,
                owner => owner.Issue(operation, intent, command.Intent, command.AuthorizationProofs, decisionAt, frozenResult), context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException)
        {
            return ReceiverAppend.Wait("The exact protected grant content is not available yet.");
        }
        catch (ImmutableContentIntegrityException)
        {
            return ReceiverAppend.Invalid("The exact protected grant content cannot be verified.");
        }
        catch (SourceFactVerificationException)
        {
            return ReceiverAppend.Invalid("The native download source proof cannot be verified.");
        }
    }

    internal static ArtifactDownloadTicketObservation TicketObservation(VerifiedArtifactDownload download, Uuid commandId) =>
        new(NativeFactReference.Of(download.Admission.Owner, download.Admission), download.Reference, commandId, ArtifactDownloadFailureProof.TicketInvalid);
    internal static Uuid TicketObservationId(Uuid commandId) => Uuid.CreateVersion5(commandId, ArtifactDownloadTicketObservation.Schema);

    static Result<ReceiverOutcome>? Decide(ArtifactDownloadGrant owner, AcceptedOperationBinding binding) => owner.Acceptance.Decide(binding) switch
    {
        NativeAcceptanceDecision.Replayed => SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, owner.Acceptance.SelectedFact!)),
        NativeAcceptanceDecision.Conflict => ReceiverAppend.Invalid("The grant effect identity was reused with changed intent."),
        _ => owner.Canceled is not null ? ReceiverAppend.Rejected("The receiving grant is canceled; its source uses must settle.") : null,
    };

    static bool Valid(ArtifactDelivery ticket, ArtifactContentReference identity, DateTimeOffset decisionAt, TimeSpan maximum) =>
        ticket.Content == identity && ticket.Location is { IsAbsoluteUri: true } && ticket.Location.OriginalString.Length <= 8192 &&
        (ticket.Location.Scheme == Uri.UriSchemeHttps && ticket.Location.UserInfo.Length == 0 ||
            ticket.Location.OriginalString.StartsWith("urn:bdgrz:artifact-delivery:", StringComparison.Ordinal)) &&
        ticket.ExpiresAt > decisionAt && ticket.ExpiresAt <= decisionAt + maximum;
}
