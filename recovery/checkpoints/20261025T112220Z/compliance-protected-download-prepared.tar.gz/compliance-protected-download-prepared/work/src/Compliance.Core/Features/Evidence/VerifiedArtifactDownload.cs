using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>The exact native admission and its complete verified source requirements.</summary>
public sealed record VerifiedArtifactDownload(EvidenceArtifactDownloadRequested Admission, EvidenceDownloadIntent Intent,
    ImmutableContentRef Reference, IReadOnlyList<SourceUseRequirement> Requirements);
