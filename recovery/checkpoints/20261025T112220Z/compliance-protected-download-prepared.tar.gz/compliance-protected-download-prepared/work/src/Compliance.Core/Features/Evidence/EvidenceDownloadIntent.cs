using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Complete server-frozen request authority; the original ticket is stored only as protected content.</summary>
public sealed record EvidenceDownloadIntent(DurableIntentHeader Header, Uuid GrantId, Uuid ArtifactId,
    string ContentSha256, long ContentLength, ulong ArtifactRevision, string Purpose, Uuid? ProgramId,
    Uuid? AdvisorHandoffId, AdvisorRecordVersion? SelectedSource, ImmutableSelectionManifest RequiredSourceUses,
    TimeSpan MaxDeliveryLifetime)
{
    public const string Schema = "evidence-download-intent.v1";
}
