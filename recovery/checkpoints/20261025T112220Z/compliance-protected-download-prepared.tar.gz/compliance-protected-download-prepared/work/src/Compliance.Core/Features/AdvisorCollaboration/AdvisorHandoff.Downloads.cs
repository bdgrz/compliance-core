using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AdvisorCollaboration;

public sealed partial class AdvisorHandoff
{
    public SourceUseReservations Uses { get; }

    void InitializeDownloadUses()
    {
        On<AdvisorArtifactDownloadUseAuthorized>(fact => ApplyDownload(fact, fact.Revision, granted: true));
        On<AdvisorArtifactDownloadUseSettled>(fact => ApplyDownload(fact, fact.Revision, granted: false));
    }

    void ApplyDownload(ISourceUseFact fact, long revision, bool granted)
    {
        if (fact.Owner != Stream || fact.Operation.Owner != Stream || revision != _revision + 1 ||
            fact.Generation != ArtifactDownloadProtocol.Generation || fact.FirstResponse is not null ||
            granted && (!IsCreated || Status != ReadyForReview))
            throw new InvalidOperationException("The advisor artifact use belongs to the exact handoff at its next revision.");
        Acceptance.Observe((DomainEvent)fact);
        if (granted)
            Uses.ApplyGranted(SourceUsePurpose.ArtifactDownload, fact);
        else
            Uses.ApplySettled(SourceUsePurpose.ArtifactDownload, fact);
        Advance((DomainEvent)fact, fact.Operation.AcceptedAt);
    }

    public Result GrantArtifactDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new AdvisorArtifactDownloadUseAuthorized(Stream, Revision + 1, generation, intent, null, operation, null, null));
        return Result.Success;
    }

    public Result SettleArtifactDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new AdvisorArtifactDownloadUseSettled(Stream, Revision + 1, generation, intent, null, operation, null, null));
        return Result.Success;
    }
}
