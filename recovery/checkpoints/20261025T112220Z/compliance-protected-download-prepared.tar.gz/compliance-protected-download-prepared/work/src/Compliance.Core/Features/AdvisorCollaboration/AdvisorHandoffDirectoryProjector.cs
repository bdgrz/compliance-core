using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AdvisorCollaboration;

/// <summary>
///     Projects each handoff's lifecycle and feedback admissions into the directory read model. The selection of a
///     creation or revision is read from verified content before it is projected; feedback threads are their own
///     owners and are not projected here.
/// </summary>
public sealed partial class AdvisorHandoffDirectoryProjector(IAdvisorHandoffDirectoryProjection projection,
    IImmutableContentStore content)
    : Projector(projection, EventStreamPattern.ForTenant(AdvisorHandoff.Area),
        FitzAdvisorHandoffDirectory.ProjectorName),
      IProjectorHandler<AdvisorHandoffCreated>,
      IProjectorHandler<AdvisorHandoffSelectionRevised>,
      IProjectorHandler<AdvisorHandoffReadiedForReview>,
      IProjectorHandler<AdvisorHandoffClosed>,
      IProjectorHandler<AdvisorHandoffRevoked>,
      IProjectorHandler<AdvisorFeedbackAdmitted>,
      IProjectorHandler<AdvisorArtifactDownloadUseAuthorized>,
      IProjectorHandler<AdvisorArtifactDownloadUseSettled>
{
    public async ValueTask HandleAsync(AdvisorHandoffCreated ev, IProjectorContext context,
        CancellationToken ct) => await projection.ApplyAsync(ev, await AdvisorContent
            .ReadAsync<IReadOnlyList<AdvisorRecordVersion>>(content, ev.TenantId, ev.RecordVersionsManifest, ct)
            .ConfigureAwait(false), ct).ConfigureAwait(false);

    public async ValueTask HandleAsync(AdvisorHandoffSelectionRevised ev, IProjectorContext context,
        CancellationToken ct) => await projection.ApplyAsync(ev, await AdvisorContent
            .ReadAsync<IReadOnlyList<AdvisorRecordVersion>>(content, ev.TenantId, ev.RecordVersionsManifest, ct)
            .ConfigureAwait(false), ct).ConfigureAwait(false);

    public ValueTask HandleAsync(AdvisorHandoffReadiedForReview ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);

    public ValueTask HandleAsync(AdvisorHandoffClosed ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);

    public ValueTask HandleAsync(AdvisorHandoffRevoked ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);

    public ValueTask HandleAsync(AdvisorFeedbackAdmitted ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);
    public ValueTask HandleAsync(AdvisorArtifactDownloadUseAuthorized ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);

    public ValueTask HandleAsync(AdvisorArtifactDownloadUseSettled ev, IProjectorContext context,
        CancellationToken ct) => projection.ApplyAsync(ev, null, ct);
}
