using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Exact identities and immutable schemas shared by admission, receivers and authorized result reads.</summary>
public static class ArtifactDownloadProtocol
{
    public const string LinkSchema = "evidence-artifact-download-link.v1";
    public const string RequirementsSchema = "artifact-download-source-requirement.v1";
    public const string ProofsSchema = "artifact-download-authorization-proofs.v1";
    public const string MutationResultSchema = "mutation-result-content.v1";
    public const long Generation = 1;

    public static DurableIntentHeader Header(OperationProvenance operation) => new(operation.RootOperationId,
        operation.FirstOwner ?? operation.Owner, operation.AffectedOwner, operation.ExpectedRevisionOwner,
        operation.Actor, operation.Episode, operation.OriginalExpectedRevision, operation.AuthoredIntentSha256,
        operation.AcceptedAt);

    public static ReservationKey Key(EvidenceDownloadIntent intent, EventStreamAddress target) => new(intent.GrantId,
        intent.Header.FirstOwner, Generation, target, SourceUseReservations.PurposeName(SourceUsePurpose.ArtifactDownload));

    public static ProtectedResponseScope Scope(EvidenceDownloadIntent intent) => new(intent.Header.FirstOwner.Realm,
        intent.Header.AffectedOwner, intent.GrantId, intent.Header.OriginalActor);

    public static async Task<T> ReadAsync<T>(IImmutableContentStore content, string realm,
        ImmutableContentRef reference, string schema, CancellationToken ct) where T : notnull
    {
        if (reference.Schema != schema)
            throw new ImmutableContentIntegrityException("The artifact download content has another schema.");
        return await content.ReadJsonAsync<T>(realm, reference, ct).ConfigureAwait(false);
    }
}
