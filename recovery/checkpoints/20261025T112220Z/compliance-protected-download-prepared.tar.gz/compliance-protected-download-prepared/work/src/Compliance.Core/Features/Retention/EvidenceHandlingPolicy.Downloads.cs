using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

public sealed partial class EvidenceHandlingPolicy
{
    public NativeAcceptance Acceptance { get; }
    public SourceUseReservations Uses { get; }
    readonly List<DomainEvent> _downloadFacts = [];
    public IReadOnlyList<DomainEvent> DownloadFacts => _downloadFacts;

    void InitializeDownloadUses()
    {
        On<ArtifactHandlingDownloadUseAuthorized>(fact => ApplyDownload(fact, granted: true));
        On<ArtifactHandlingDownloadUseSettled>(fact => ApplyDownload(fact, granted: false));
    }

    void ApplyDownload(ISourceUseFact fact, bool granted)
    {
        if (fact.Owner != Stream || fact.Operation.Owner != Stream || fact.Generation != ArtifactDownloadProtocol.Generation ||
            fact.FirstResponse is not null)
            throw new InvalidOperationException("The handling download use belongs to its exact owner and generation.");
        Acceptance.Observe((DomainEvent)fact);
        if (granted)
            Uses.ApplyGranted(SourceUsePurpose.ArtifactDownload, fact);
        else
            Uses.ApplySettled(SourceUsePurpose.ArtifactDownload, fact);
        _downloadFacts.Add((DomainEvent)fact);
    }

    public Result GrantDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new ArtifactHandlingDownloadUseAuthorized(Stream, Revision, generation, intent, null, operation, null, null));
        return Result.Success;
    }

    public Result SettleDownloadUse(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        RaiseEvent(new ArtifactHandlingDownloadUseSettled(Stream, Revision, generation, intent, null, operation, null, null));
        return Result.Success;
    }
}
