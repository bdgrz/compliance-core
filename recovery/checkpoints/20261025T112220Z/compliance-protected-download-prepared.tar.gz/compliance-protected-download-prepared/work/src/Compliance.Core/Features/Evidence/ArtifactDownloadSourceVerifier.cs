using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Re-reads native facts and complete immutable requirements; absence never proves a terminal refusal.</summary>
public sealed class ArtifactDownloadSourceVerifier(IAggregateReader reader, ISourceFactResolver resolver,
    IImmutableContentStore content)
{
    public async Task<VerifiedArtifactDownload> AdmissionAsync(SourceFactProof<EvidenceArtifactDownloadRequested> proof,
        ImmutableContentRef reference, Uuid rootOperationId, Uuid artifactId, long generation, CancellationToken ct)
    {
        var verified = await resolver.VerifyAsync(proof, ct).ConfigureAwait(false);
        await VerifyLocatorAsync(proof, ct).ConfigureAwait(false);
        var fact = verified.Facts;
        var intent = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, proof.Source.Realm,
            reference, EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
        var tenant = Uuid.Parse(proof.Source.Realm, CultureInfo.InvariantCulture);
        var source = new EvidenceArtifact(tenant, artifactId).Stream;
        if (proof.Source != source || fact.Owner != source || fact.Intent != reference || fact.Generation != generation ||
            generation != ArtifactDownloadProtocol.Generation || rootOperationId != intent.GrantId ||
            fact.Operation.RootOperationId != rootOperationId || fact.Operation.LogicalId != rootOperationId ||
            fact.Operation.CommandKind != nameof(IssueArtifactDownload) || intent.ArtifactId != artifactId ||
            intent.Header != ArtifactDownloadProtocol.Header(fact.Operation) || intent.Header.FirstOwner != source ||
            intent.Header.AffectedOwner != source || intent.Header.ExpectedRevisionOwner != source ||
            intent.Header.OriginalActor is not { Kind: "member", Id.Length: > 0 } ||
            !Uuid.TryParse(intent.Header.OriginalActor.Id, CultureInfo.InvariantCulture, out var memberId) || memberId == Uuid.Empty ||
            intent.ArtifactRevision != (ulong)fact.Revision || intent.Header.OriginalExpectedRevision != intent.ArtifactRevision ||
            intent.ContentLength <= 0 || intent.MaxDeliveryLifetime <= TimeSpan.Zero ||
            intent.MaxDeliveryLifetime > ArtifactContentLimits.MaxDeliveryLifetime ||
            string.IsNullOrWhiteSpace(intent.Purpose))
            throw new ImmutableContentIntegrityException("The download differs from its exact native personal admission.");
        var requirements = await content.ReadSelectionAsync<SourceUseRequirement>(proof.Source.Realm,
            intent.RequiredSourceUses, ct).ConfigureAwait(false);
        if (intent.RequiredSourceUses.ItemSchema != ArtifactDownloadProtocol.RequirementsSchema ||
            requirements.Count != (intent.AdvisorHandoffId is null ? 1 : 2) ||
            requirements.Select(row => row.SourceOwner).Distinct().Count() != requirements.Count ||
            !requirements.Select(row => row.SourceOwner.ToString()).SequenceEqual(requirements.Select(row => row.SourceOwner.ToString()).Order(StreamKeyOrder.Instance)))
            throw new ImmutableContentIntegrityException("The complete download source selection is invalid.");
        var handling = new EvidenceHandlingPolicy(tenant, artifactId).Stream;
        if (requirements.Count(row => row.SourceOwner == handling) != 1 ||
            requirements.Any(row => row.SourceOwner.Realm != source.Realm || row.Purpose != SourceUsePurpose.ArtifactDownload))
            throw new ImmutableContentIntegrityException("The mandatory handling use is absent or duplicated.");
        foreach (var requirement in requirements)
        {
            var facts = await PinnedAsync(requirement, ct).ConfigureAwait(false);
            if (facts.ArtifactId != artifactId || facts.ContentSha256 != intent.ContentSha256 || facts.ContentLength != intent.ContentLength)
                throw new ImmutableContentIntegrityException("A source use pins another artifact content identity.");
            if (requirement.SourceOwner == handling)
            {
                if (facts.Kind != "handling" || facts.PolicyVersion != EvidenceHandlingPolicy.CurrentPolicyVersion ||
                    facts.HandoffId is not null || facts.ProgramId is not null || facts.ValidUntil is not null)
                    throw new ImmutableContentIntegrityException("The explicit handling policy use is invalid.");
            }
            else if (intent.ProgramId is not { } program || intent.AdvisorHandoffId is not { } handoff ||
                intent.SelectedSource is not { } selected || facts.Kind != "handoff" || facts.ProgramId != program ||
                facts.HandoffId != handoff || facts.SelectedSource != selected || facts.Selection is null ||
                facts.ValidUntil is null || requirement.SourceOwner != new AdvisorHandoff(tenant, program, handoff).Stream)
                throw new ImmutableContentIntegrityException("The optional handoff use differs from the exact selected source.");
        }
        if ((intent.AdvisorHandoffId is null) != (intent.ProgramId is null) ||
            (intent.AdvisorHandoffId is null) != (intent.SelectedSource is null))
            throw new ImmutableContentIntegrityException("The optional download source variant is incomplete.");
        return new VerifiedArtifactDownload(fact, intent, reference, requirements);
    }

    public Task<EvidenceDownloadPinnedFacts> PinnedAsync(SourceUseRequirement requirement, CancellationToken ct) =>
        ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadPinnedFacts>(content, requirement.SourceOwner.Realm,
            requirement.RequiredFacts, EvidenceDownloadPinnedFacts.Schema, ct);

    public async Task<SourceUseSource> AuthorizationAsync(SourceFactProof<EvidenceArtifactDownloadRequested> source,
        ImmutableContentRef useIntent, EventStreamAddress target, Uuid operationId, long generation, Uuid artifactId,
        string commandKind, Uuid commandId, CancellationToken ct)
    {
        var use = await ArtifactDownloadProtocol.ReadAsync<SourceUseAuthorizationIntent>(content, target.Realm,
            useIntent, SourceUseAuthorizationIntent.Schema, ct).ConfigureAwait(false);
        var download = await AdmissionAsync(source, use.ParentIntent, operationId, artifactId, generation, ct).ConfigureAwait(false);
        var expected = download.Requirements.SingleOrDefault(row => row.SourceOwner == target)
            ?? throw new ImmutableContentIntegrityException("The download did not select this source owner.");
        if (use.Header != download.Intent.Header || use.Requirement != expected || use.Grant is not null ||
            use.Disposition is not null || use.Reservation != ArtifactDownloadProtocol.Key(download.Intent, target) ||
            commandId != EffectIdentity.CommandId(source.EventId, $"{ArtifactDownloadProcess.Name}:{commandKind}",
                target.ToString(), download.Intent.Header.Episode))
            throw new ImmutableContentIntegrityException("The source use differs from the exact download effect.");
        var grant = await reader.HydrateAsync(new ArtifactDownloadGrant(Uuid.Parse(target.Realm, CultureInfo.InvariantCulture), operationId), ct)
            .ConfigureAwait(false);
        return new SourceUseSource(download.Intent.Header, download.Reference, use.Reservation, expected,
            commandKind, null, grant.Canceled is not null ? "The receiving grant was canceled before this acquisition." : null)
        { RequiresAbort = grant.Canceled is not null };
    }

    public async Task<SourceUseSource> SettlementAsync(ArtifactDownloadTerminalSourceProof terminal,
        ImmutableContentRef useIntent, EventStreamAddress target, Uuid operationId, long generation, Uuid artifactId,
        string commandKind, Uuid commandId, CancellationToken ct)
    {
        var use = await ArtifactDownloadProtocol.ReadAsync<SourceUseAuthorizationIntent>(content, target.Realm,
            useIntent, SourceUseAuthorizationIntent.Schema, ct).ConfigureAwait(false);
        ImmutableContentRef reference;
        OperationProvenance operation;
        SourceUseSettlementDisposition disposition;
        switch (terminal.Proof)
        {
            case SourceFactProof<EvidenceArtifactDownloadIssued> issued:
                var committed = await resolver.VerifyAsync(issued, ct).ConfigureAwait(false);
                await VerifyLocatorAsync(issued, ct).ConfigureAwait(false);
                reference = committed.Facts.Intent;
                operation = committed.Facts.Operation;
                disposition = SourceUseSettlementDisposition.IrreversibleDecision;
                break;
            case SourceFactProof<ArtifactDownloadGrantCanceled> canceled:
                var fenced = await resolver.VerifyAsync(canceled, ct).ConfigureAwait(false);
                await VerifyLocatorAsync(canceled, ct).ConfigureAwait(false);
                reference = fenced.Facts.Intent;
                operation = fenced.Facts.Operation;
                disposition = SourceUseSettlementDisposition.Canceled;
                break;
            default:
                throw new ImmutableContentIntegrityException("The settlement has no selected native terminal proof.");
        }
        var intent = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, target.Realm, reference,
            EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
        var grantOwner = new ArtifactDownloadGrant(Uuid.Parse(target.Realm, CultureInfo.InvariantCulture), intent.GrantId).Stream;
        var requirements = await content.ReadSelectionAsync<SourceUseRequirement>(target.Realm, intent.RequiredSourceUses, ct).ConfigureAwait(false);
        var tenant = Uuid.Parse(target.Realm, CultureInfo.InvariantCulture);
        var artifact = await reader.HydrateAsync(new EvidenceArtifact(tenant, intent.ArtifactId), ct).ConfigureAwait(false);
        var admission = artifact.DownloadFacts.OfType<EvidenceArtifactDownloadRequested>().SingleOrDefault(fact =>
            fact.Operation.RootOperationId == intent.GrantId && fact.Intent == reference);
        if (admission is null)
            throw new ImmutableContentUnavailableException("The exact native admission is not available yet.");
        if (operation.CausationEventId != admission.Metadata.EventId || intent.Header != ArtifactDownloadProtocol.Header(admission.Operation))
            throw new ImmutableContentIntegrityException("The terminal grant names another native admission.");
        var expected = target == intent.Header.FirstOwner
            ? new SourceUseRequirement(target, NativeFactReference.Of(target, admission), intent.ArtifactRevision,
                SourceUsePurpose.ArtifactDownload, reference)
            : requirements.SingleOrDefault(row => row.SourceOwner == target);
        if (expected is null || use.ParentIntent != reference || use.Header != intent.Header ||
            use.Reservation != ArtifactDownloadProtocol.Key(intent, target) || use.Requirement != expected || use.Disposition != disposition ||
            operation.Owner != grantOwner || terminal.Reference.Stream != grantOwner || operation.RootOperationId != intent.GrantId ||
            operation.FirstOwner != intent.Header.FirstOwner || operation.Actor != intent.Header.OriginalActor ||
            operation.AuthoredIntentSha256 != intent.Header.AuthoredIntentSha256 || operationId != intent.GrantId ||
            intent.ArtifactId != artifactId || generation != ArtifactDownloadProtocol.Generation ||
            commandId != EffectIdentity.CommandId(operation.CausationEventId!.Value, $"{ArtifactDownloadProcess.Name}:{commandKind}",
                target.ToString(), intent.Header.Episode))
            throw new ImmutableContentIntegrityException("The settlement differs from the exact terminal grant and frozen source key.");
        return new SourceUseSource(intent.Header, reference, use.Reservation, expected, commandKind, disposition, null);
    }

    async Task VerifyLocatorAsync<T>(SourceFactProof<T> proof, CancellationToken ct) where T : DomainEvent
    {
        var locator = await ArtifactDownloadProtocol.ReadAsync<SourceFactLocator>(content, proof.Source.Realm,
            proof.RequiredFacts, SourceFactProofs.RequiredFactsSchema, ct).ConfigureAwait(false);
        if (locator.Source != proof.Source || locator.EventId != proof.EventId || locator.ResourcePosition != proof.PhysicalPosition ||
            locator.AggregateVersion != proof.OwnerRevision || locator.PayloadSha256 != proof.PayloadSha256 ||
            locator.GlobalPosition != proof.GlobalPosition || locator.RealmPosition != proof.RealmPosition)
            throw new ImmutableContentIntegrityException("The proof locator differs from the exact source record.");
    }
}
