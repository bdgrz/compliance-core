using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Internal-only protocol surface; handlers independently bind every source, owner and effect key.</summary>
sealed class ArtifactDownloadReceiverAuthorizer : IRequestAuthorizer<IArtifactDownloadReceiver>
{
    public ValueTask<Result> AuthorizeAsync(IRequestContext<IArtifactDownloadReceiver> context, CancellationToken ct) =>
        ValueTask.FromResult(RequestActor.IsSystem(context.Actor) ? Result.Success : Result.Failure(new RequestError(
            RequestErrorKind.Forbidden, "Only the internal artifact download process may dispatch download effects.")));
}
