using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Holds the exact applied classification, or the explicit immutable default version.</summary>
public sealed class AuthorizeArtifactHandlingDownloadUseHandler(IAggregateReader reader, IAggregateExecutor executor,
    IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier, TimeProvider clock)
    : AuthorizeSourceUseHandler<EvidenceHandlingPolicy, AuthorizeArtifactHandlingDownloadUse>(reader, executor, content, clock)
{
    protected override EvidenceHandlingPolicy Open(AuthorizeArtifactHandlingDownloadUse request, Uuid selectedCommandId) =>
        new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), request.ArtifactId, selectedCommandId);

    protected override ValueTask<Result<SourceUseSource>> VerifyAsync(AuthorizeArtifactHandlingDownloadUse request, CancellationToken ct) =>
        ArtifactDownloadUsePins.VerifyAsync(async () =>
        {
            var source = await verifier.AuthorizationAsync(request.Source, request.Intent, request.Target, request.OperationId,
                request.Generation, request.ArtifactId, nameof(AuthorizeArtifactHandlingDownloadUse), request.CommandId, ct).ConfigureAwait(false);
            var facts = await verifier.PinnedAsync(source.Requirement, ct).ConfigureAwait(false);
            if (request.ExpectedRevision is not null || facts.PolicyVersion != request.PolicyVersion || facts.Kind != "handling")
                throw new ImmutableContentIntegrityException("The download use names another exact policy version.");
            return source;
        });

    protected override async ValueTask<Result> VerifyPinnedAsync(EvidenceHandlingPolicy owner, SourceUseRequirement requirement, CancellationToken ct)
    {
        var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
        return IsPinned(owner, requirement) && (owner.Current is not { } current ||
            current.Source.ContentSha256 == facts.ContentSha256 && current.ContentLength == facts.ContentLength &&
            current.HandlingClass == facts.HandlingClass && current.PolicyVersion == facts.PolicyVersion)
            ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict, "The exact handling classification changed before acquisition."));
    }

    protected override bool IsPinned(EvidenceHandlingPolicy owner, SourceUseRequirement requirement) => ArtifactDownloadUsePins.Policy(owner, requirement);
    protected override Func<EvidenceHandlingPolicy, OperationProvenance, ImmutableContentRef, long, Result> GrantOperation() =>
        (EvidenceHandlingPolicy owner, OperationProvenance operation, ImmutableContentRef intent, long generation) => owner.GrantDownloadUse(operation, intent, generation);
    protected override ValueTask<Result<ReceiverOutcome>> RefuseAsync(AuthorizeArtifactHandlingDownloadUse request,
        SourceUseSource source, string reason, IExecutionContext context, CancellationToken ct) =>
        ValueTask.FromResult(ReceiverAppend.Rejected("The frozen handling source cannot grant this download use."));
}
