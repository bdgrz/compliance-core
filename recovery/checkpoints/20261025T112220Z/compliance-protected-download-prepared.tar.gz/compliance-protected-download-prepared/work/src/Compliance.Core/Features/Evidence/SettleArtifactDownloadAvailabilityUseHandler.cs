using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Releases this exact source only after its native grant or receiving cancellation fence.</summary>
public sealed class SettleArtifactDownloadAvailabilityUseHandler(IAggregateReader reader, IAggregateExecutor executor,
    IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier, TimeProvider clock)
    : SettleSourceUseHandler<EvidenceArtifact, SettleArtifactDownloadAvailabilityUse>(reader, executor, content, clock)
{
    protected override EvidenceArtifact Open(SettleArtifactDownloadAvailabilityUse request, Uuid selectedCommandId) => new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), request.ArtifactId, selectedCommandId);
    protected override ValueTask<Result<SourceUseSource>> VerifyAsync(SettleArtifactDownloadAvailabilityUse request, CancellationToken ct) =>
        ArtifactDownloadUsePins.VerifyAsync(() => verifier.SettlementAsync(request.Source, request.Intent, request.Target,
            request.OperationId, request.Generation, request.ArtifactId, nameof(SettleArtifactDownloadAvailabilityUse), request.CommandId, ct));
    protected override Func<EvidenceArtifact, OperationProvenance, ImmutableContentRef, long, Result> SettleOperation() =>
        (EvidenceArtifact owner, OperationProvenance operation, ImmutableContentRef intent, long generation) => owner.SettleDownloadAvailability(operation, intent, generation);
}
