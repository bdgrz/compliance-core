using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Verifiable receiving cancellation authority bound to the exact admitted operation and failed source.</summary>
public sealed record ArtifactDownloadFailureProof(Uuid GrantId, long Generation,
    NativeFactReference Admission, ImmutableContentRef Intent, string Reason, EventStreamAddress? SourceOwner,
    DateTimeOffset DecisionAt, ImmutableContentRef? TicketObservation)
{
    public const string Schema = "artifact-download-failure-proof.v1";
    public const string SourceRevoked = "source_revoked";
    public const string SourceExpired = "source_expired";
    public const string ContentUnavailable = "content_unavailable";
    public const string TicketInvalid = "ticket_invalid";
}
