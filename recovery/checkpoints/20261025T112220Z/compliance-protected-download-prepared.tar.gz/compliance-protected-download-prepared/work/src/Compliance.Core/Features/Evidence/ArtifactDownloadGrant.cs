using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>One immutable protected original result, or its receiving pre-issue cancellation fence.</summary>
public sealed class ArtifactDownloadGrant : Aggregate
{
    public const string Area = "artifact-download-grants";
    readonly Uuid _tenantId;
    public NativeAcceptance Acceptance { get; }
    public EvidenceArtifactDownloadIssued? Issued { get; private set; }
    public ArtifactDownloadGrantCanceled? Canceled { get; private set; }
    public DomainEvent? Terminal => (DomainEvent?)Issued ?? Canceled;

    public ArtifactDownloadGrant(Uuid tenantId, Uuid grantId, Uuid selectedLogicalId = default)
        : base(grantId, new EventStreamAddress(tenantId.ToString(), Area, grantId.ToString()))
    {
        _tenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<EvidenceArtifactDownloadIssued>(fact =>
        {
            if (Terminal is not null || fact.TenantId != _tenantId || fact.GrantId != Id || fact.Revision != 1 ||
                fact.Operation.Owner != Stream || fact.Operation.RootOperationId != Id ||
                fact.Operation.Actor != fact.IssuedBy || fact.IssuedAt == default ||
                fact.FirstResponse is not null || fact.OperationResult is null)
                throw new InvalidOperationException("A protected grant is issued once on its own owner.");
            Acceptance.Observe(fact);
            Issued = fact;
        });
        On<ArtifactDownloadGrantCanceled>(fact =>
        {
            if (Terminal is not null || fact.Owner != Stream || fact.GrantId != Id || fact.Revision != 1 ||
                fact.Generation != ArtifactDownloadProtocol.Generation || fact.Operation.Owner != Stream ||
                fact.Operation.RootOperationId != Id || fact.FirstResponse is not null || fact.OperationResult is null)
                throw new InvalidOperationException("A grant cancellation fences issuance once on its own owner.");
            Acceptance.Observe(fact);
            Canceled = fact;
        });
    }

    public bool HasExactRoot(EvidenceDownloadIntent intent, ImmutableContentRef reference) => Terminal switch
    {
        EvidenceArtifactDownloadIssued fact => fact.Intent == reference && fact.Operation.FirstOwner == intent.Header.FirstOwner &&
            fact.Operation.RootOperationId == intent.GrantId && fact.ArtifactId == intent.ArtifactId && fact.Operation.Actor == intent.Header.OriginalActor,
        ArtifactDownloadGrantCanceled fact => fact.Intent == reference && fact.Operation.FirstOwner == intent.Header.FirstOwner &&
            fact.Operation.RootOperationId == intent.GrantId && fact.Operation.Actor == intent.Header.OriginalActor,
        _ => true,
    };

    public Result Issue(OperationProvenance operation, EvidenceDownloadIntent intent, ImmutableContentRef reference,
        ImmutableContentRef proofs, DateTimeOffset decisionAt, ImmutableContentRef result)
    {
        if (Terminal is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The grant already has its immutable terminal outcome."));
        if (!Matches(operation, intent, reference) || operation.CommandKind != nameof(IssueProtectedArtifactDownloadGrant) ||
            decisionAt < intent.Header.AcceptedAt || operation.AcceptedAt != decisionAt || result.Schema != ArtifactDownloadProtocol.MutationResultSchema)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The protected result differs from its admitted operation."));
        RaiseEvent(new EvidenceArtifactDownloadIssued(_tenantId, intent.ArtifactId, 1, intent.GrantId,
            intent.ContentSha256, intent.ContentLength, intent.Purpose, intent.Header.OriginalActor, decisionAt,
            operation, reference, Id, null, result, proofs));
        return Result.Success;
    }

    public Result Cancel(OperationProvenance operation, EvidenceDownloadIntent intent, ImmutableContentRef reference,
        ImmutableContentRef proof, ImmutableContentRef result)
    {
        if (Terminal is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "A committed grant recovers forward and cannot be canceled."));
        if (!Matches(operation, intent, reference) || operation.CommandKind != nameof(CancelProtectedArtifactDownloadGrant))
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The cancellation differs from its admitted operation."));
        RaiseEvent(new ArtifactDownloadGrantCanceled(Stream, 1, ArtifactDownloadProtocol.Generation, reference, proof,
            operation, Id, null, result));
        return Result.Success;
    }

    bool Matches(OperationProvenance operation, EvidenceDownloadIntent intent, ImmutableContentRef reference) =>
        operation.Owner == Stream && operation.AffectedOwner == Stream && operation.ExpectedRevisionOwner == Stream &&
        operation.FirstOwner == intent.Header.FirstOwner && operation.RootOperationId == Id && intent.GrantId == Id &&
        operation.Actor == intent.Header.OriginalActor && operation.Episode == intent.Header.Episode &&
        operation.AuthoredIntentSha256 == intent.Header.AuthoredIntentSha256 &&
        operation.OriginalExpectedRevision == intent.Header.OriginalExpectedRevision &&
        reference.Schema == EvidenceDownloadIntent.Schema;
}
