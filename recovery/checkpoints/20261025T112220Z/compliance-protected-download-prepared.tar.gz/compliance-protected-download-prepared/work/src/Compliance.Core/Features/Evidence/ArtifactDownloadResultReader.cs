using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>First-owner-scoped internal read seam; bare-operation public routing remains a separate blocked contract.</summary>
sealed class ArtifactDownloadResultReader(IAggregateReader reader, EvidenceArtifactDownloadAccess access,
    EvidenceArtifactMetadataRead metadata, IImmutableContentStore content, IProtectedResponseContentStore protectedContent)
{
    public async ValueTask<Result<EvidenceArtifactDownloadLink>> ReadAsync(IRequestContext context, Uuid tenantId,
        Uuid artifactId, Uuid operationId, CancellationToken ct)
    {
        if (!IssueArtifactDownloadHandler.PersonalHttpActor(context.Actor, context.Invocation, tenantId, out var actor))
            return Missing();
        var artifact = await reader.HydrateAsync(new EvidenceArtifact(tenantId, artifactId), ct).ConfigureAwait(false);
        var admitted = artifact.DownloadFacts.OfType<EvidenceArtifactDownloadRequested>().SingleOrDefault(fact =>
            fact.Operation.RootOperationId == operationId);
        if (admitted is null || admitted.Operation.Actor.Kind != actor.Kind || admitted.Operation.Actor.Id != actor.Id)
            return Missing();
        try
        {
            var intent = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, tenantId.ToString(), admitted.Intent,
                EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
            if (intent.Header != ArtifactDownloadProtocol.Header(admitted.Operation) || intent.ArtifactId != artifactId || intent.GrantId != operationId)
                throw new ImmutableContentIntegrityException("The original download intent differs from its native admission.");
            var authorized = await access.RequireAsync(context, tenantId, artifactId, intent.ProgramId, intent.AdvisorHandoffId,
                intent.SelectedSource, ct).ConfigureAwait(false);
            if (!authorized.IsSuccess)
                return Result<EvidenceArtifactDownloadLink>.Failure(authorized.Error!);
            var current = await metadata.GetAsync(tenantId, artifactId, ct).ConfigureAwait(false);
            if (!current.IsSuccess || current.Value.State != EvidenceArtifactStates.Available ||
                current.Value.ContentSha256 != intent.ContentSha256 || current.Value.ContentLength != intent.ContentLength)
                return Missing();
            var grant = await reader.HydrateAsync(new ArtifactDownloadGrant(tenantId, operationId), ct).ConfigureAwait(false);
            if (!grant.HasExactRoot(intent, admitted.Intent))
                return Missing();
            if (grant.Terminal is not INativeOperationFact terminal)
                return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The download remains pending.", true));
            var resultReference = grant.Issued?.OperationResult ?? grant.Canceled!.OperationResult!;
            var result = await ArtifactDownloadProtocol.ReadAsync<MutationResultContent>(content, tenantId.ToString(), resultReference,
                ArtifactDownloadProtocol.MutationResultSchema, ct).ConfigureAwait(false);
            if (grant.Canceled is not null)
            {
                if (result.Schema != "request-error.v1" || result.Value is not StandardResponseBody error)
                    throw new ImmutableContentIntegrityException("The canceled download does not carry its frozen error result.");
                return Result<EvidenceArtifactDownloadLink>.Failure(await ArtifactDownloadProtocol.ReadAsync<RequestError>(content,
                    tenantId.ToString(), error.Content, "request-error.v1", ct).ConfigureAwait(false));
            }
            if (grant.Issued!.Intent != admitted.Intent || terminal.Operation.RootOperationId != operationId ||
                terminal.Operation.FirstOwner != artifact.Stream || terminal.Operation.Actor != intent.Header.OriginalActor ||
                result.Schema != ArtifactDownloadProtocol.LinkSchema || result.Value is not ProtectedResponseBody secret)
                throw new ImmutableContentIntegrityException("The original download result differs from its admitted authority.");
            // Authorization and original actor matching precede this read. Expiry is intentionally not renewed or rejected.
            var bytes = await protectedContent.ReadVerifiedAsync(ArtifactDownloadProtocol.Scope(intent), secret.Content, ct).ConfigureAwait(false);
            var link = JsonSerializer.Deserialize(bytes.Span, ComplianceCoreJsonContext.Default.EvidenceArtifactDownloadLink)
                ?? throw new ImmutableContentIntegrityException("The protected original download result is absent.");
            return Result<EvidenceArtifactDownloadLink>.Success(link);
        }
        catch (ImmutableContentUnavailableException)
        {
            return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The original protected result is not available yet.", true));
        }
        catch (ImmutableContentIntegrityException)
        {
            return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The original protected result cannot be verified."));
        }
        catch (JsonException)
        {
            return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The original protected result is invalid."));
        }
    }

    static Result<EvidenceArtifactDownloadLink> Missing() => Result<EvidenceArtifactDownloadLink>.Failure(
        new RequestError(RequestErrorKind.NotFound, "The artifact download was not found or is no longer disclosed to this actor."));
}
