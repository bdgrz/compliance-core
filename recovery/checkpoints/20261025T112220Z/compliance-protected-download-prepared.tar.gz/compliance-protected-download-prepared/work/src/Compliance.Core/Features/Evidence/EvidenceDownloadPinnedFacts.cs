using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Exact source content and temporal boundary frozen at admission; no delivery capability.</summary>
public sealed record EvidenceDownloadPinnedFacts(string Kind, Uuid ArtifactId, string ContentSha256,
    long ContentLength, long PolicyVersion, string HandlingClass, Uuid? ProgramId, Uuid? HandoffId,
    AdvisorRecordVersion? SelectedSource, ImmutableContentRef? Selection, DateTimeOffset? ValidUntil)
{
    public const string Schema = "evidence-download-pinned-facts.v1";
}
