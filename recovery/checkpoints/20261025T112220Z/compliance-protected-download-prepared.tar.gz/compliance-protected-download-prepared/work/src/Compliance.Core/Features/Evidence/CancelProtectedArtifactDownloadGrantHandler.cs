using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Atomically fences a pre-issue receiving owner; a committed issue always recovers forward.</summary>
public sealed class CancelProtectedArtifactDownloadGrantHandler(IAggregateReader reader, ISourceFactResolver resolver,
    ReceiverAppend append, IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier,
    ArtifactDownloadCancellationProofs failures, TimeProvider clock)
    : IRequestHandler<CancelProtectedArtifactDownloadGrant, ReceiverOutcome>
{
    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<CancelProtectedArtifactDownloadGrant> context, CancellationToken ct)
    {
        var command = context.Request;
        if (command.CommandId == Uuid.Empty || command.GrantId != command.RootOperationId ||
            command.Generation != ArtifactDownloadProtocol.Generation ||
            !Uuid.TryParse(command.Target.Realm, CultureInfo.InvariantCulture, out var tenant) ||
            command.Target != new ArtifactDownloadGrant(tenant, command.GrantId).Stream)
            return ReceiverAppend.Invalid("The cancellation names another grant owner, root or generation.");
        try
        {
            var failure = await ArtifactDownloadProtocol.ReadAsync<ArtifactDownloadFailureProof>(content, command.Target.Realm,
                command.FailureProof, ArtifactDownloadFailureProof.Schema, ct).ConfigureAwait(false);
            if (failure.Admission.Stream.Realm != command.Target.Realm || failure.GrantId != command.GrantId ||
                failure.Generation != command.Generation || failure.Intent.Schema != EvidenceDownloadIntent.Schema)
                return ReceiverAppend.Invalid("The failure proof belongs to another grant, realm or generation.");
            var proven = await SourceFactProofs.BuildAsync<EvidenceArtifactDownloadRequested>(resolver, content,
                command.Target.Realm, failure.Admission, ct).ConfigureAwait(false);
            var frozen = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, command.Target.Realm,
                failure.Intent, EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
            var download = await verifier.AdmissionAsync(proven.Proof, failure.Intent, command.RootOperationId,
                frozen.ArtifactId, command.Generation, ct).ConfigureAwait(false);
            if (command.CommandId != EffectIdentity.CommandId(failure.Admission.EventId,
                    $"{ArtifactDownloadProcess.Name}:{nameof(CancelProtectedArtifactDownloadGrant)}", "-", frozen.Header.Episode))
                return ReceiverAppend.Invalid("The cancellation differs from its exact root effect key.");
            var operation = SourceUseReceiverSupport.Child(command.CommandId, nameof(CancelProtectedArtifactDownloadGrant),
                failure.Admission.EventId, frozen.Header, command.Target, clock.GetUtcNow());
            var current = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), ct).ConfigureAwait(false);
            if (!current.HasExactRoot(frozen, failure.Intent))
                return ReceiverAppend.Invalid("The grant identity belongs to another first owner or admitted intent.");
            if (current.Issued is { } issued)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(current.Stream, issued));
            var binding = AcceptedOperationBinding.Of(operation);
            if (current.Acceptance.Decide(binding) == NativeAcceptanceDecision.Replayed)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(current.Stream, current.Acceptance.SelectedFact!));
            if (!await failures.IsProvenAsync(download, failure, clock.GetUtcNow(), ct).ConfigureAwait(false))
                return ReceiverAppend.Invalid("The cancellation does not prove an exact selected source failure or adapter refusal.");
            var error = new RequestError(RequestErrorKind.Conflict, "The protected artifact download was canceled before issuance.");
            var body = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion4(), "request-error.v1", error, ct).ConfigureAwait(false);
            var result = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion4(), ArtifactDownloadProtocol.MutationResultSchema,
                new MutationResultContent("request-error.v1", new StandardResponseBody(body)), ct).ConfigureAwait(false);
            return await append.ApplyAsync(() => new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), owner => owner.Acceptance,
                binding, owner => !owner.HasExactRoot(frozen, failure.Intent)
                    ? ReceiverAppend.Invalid("The grant identity belongs to another first owner or admitted intent.") : owner.Issued is { } winner
                    ? SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, winner)) : null,
                owner => owner.Cancel(operation, frozen, failure.Intent, command.FailureProof, result), context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException)
        {
            return ReceiverAppend.Wait("The exact cancellation authority is not available yet.");
        }
        catch (ImmutableContentIntegrityException)
        {
            return ReceiverAppend.Invalid("The exact cancellation authority cannot be verified.");
        }
        catch (SourceFactVerificationException)
        {
            return ReceiverAppend.Invalid("The cancellation admission proof cannot be verified.");
        }
    }
}
