using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Canonical authored scope, including omitted versus explicitly supplied optional fields.</summary>
public sealed record ArtifactDownloadAuthoredIntent(Uuid CommandId, Uuid TenantId, Uuid ArtifactId,
    string Purpose, long ExpectedArtifactRevision, bool ProgramIdSpecified, Uuid? ProgramId,
    bool AdvisorHandoffIdSpecified, Uuid? AdvisorHandoffId, bool SelectedSourceSpecified,
    AdvisorRecordVersion? SelectedSource)
{
    public static ArtifactDownloadAuthoredIntent Of(IssueArtifactDownload request) => new(request.CommandId,
        request.TenantId, request.ArtifactId, request.Purpose.Trim(), request.ExpectedArtifactRevision,
        request.ProgramIdSpecified, request.ProgramId, request.AdvisorHandoffIdSpecified, request.AdvisorHandoffId,
        request.SelectedSourceSpecified, request.SelectedSource);
}
