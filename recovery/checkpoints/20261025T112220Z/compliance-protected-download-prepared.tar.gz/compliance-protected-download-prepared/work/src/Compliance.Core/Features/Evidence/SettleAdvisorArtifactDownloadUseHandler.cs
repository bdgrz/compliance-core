using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Releases this exact source only after its native grant or receiving cancellation fence.</summary>
public sealed class SettleAdvisorArtifactDownloadUseHandler(IAggregateReader reader, IAggregateExecutor executor,
    IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier, TimeProvider clock)
    : SettleSourceUseHandler<AdvisorHandoff, SettleAdvisorArtifactDownloadUse>(reader, executor, content, clock)
{
    protected override AdvisorHandoff Open(SettleAdvisorArtifactDownloadUse request, Uuid selectedCommandId) => new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), Uuid.Empty, Uuid.Parse(request.Target.Resource, CultureInfo.InvariantCulture), selectedCommandId);
    protected override ValueTask<Result<SourceUseSource>> VerifyAsync(SettleAdvisorArtifactDownloadUse request, CancellationToken ct) =>
        ArtifactDownloadUsePins.VerifyAsync(() => verifier.SettlementAsync(request.Source, request.Intent, request.Target,
            request.OperationId, request.Generation, request.ArtifactId, nameof(SettleAdvisorArtifactDownloadUse), request.CommandId, ct));
    protected override Func<AdvisorHandoff, OperationProvenance, ImmutableContentRef, long, Result> SettleOperation() =>
        (AdvisorHandoff owner, OperationProvenance operation, ImmutableContentRef intent, long generation) => owner.SettleArtifactDownloadUse(operation, intent, generation);
}
