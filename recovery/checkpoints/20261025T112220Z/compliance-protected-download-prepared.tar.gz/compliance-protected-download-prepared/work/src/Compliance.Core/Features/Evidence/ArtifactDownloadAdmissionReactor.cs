using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Persists the complete process before advancing the artifact admission checkpoint.</summary>
sealed partial class ArtifactDownloadAdmissionReactor(IProjectionCheckpointStore checkpoints, ProcessRootReaction process,
    IImmutableContentStore content) : Reactor(checkpoints, EventStreamPattern.ForTenant("evidence-artifacts"), WorkloadName),
    IReactorHandler<EvidenceArtifactDownloadRequested>
{
    public const string WorkloadName = "ArtifactDownloadAdmissionV1";
    public async ValueTask HandleAsync(IReactorContext<EvidenceArtifactDownloadRequested> context, CancellationToken ct)
    {
        var intent = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, context.Source.Stream.Realm,
            context.Trigger.Intent, EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
        var requirements = await content.ReadSelectionAsync<SourceUseRequirement>(context.Source.Stream.Realm,
            intent.RequiredSourceUses, ct).ConfigureAwait(false);
        var targets = requirements.Select(row => row.SourceOwner.ToString()).Append(context.Source.Stream.ToString())
            .Append(new ArtifactDownloadGrant(Uuid.Parse(context.Source.Stream.Realm, System.Globalization.CultureInfo.InvariantCulture), intent.GrantId).Stream.ToString());
        _ = await process.StartAsync(ArtifactDownloadProcess.Name, context, context.Trigger.Intent, targets,
            $"reactor:{WorkloadName}", ct).ConfigureAwait(false);
    }
}
