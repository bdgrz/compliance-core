using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Freezes complete exact handling and optional handoff requirements before the artifact admission.</summary>
sealed class EvidenceDownloadAdmission(IAggregateReader reader, IImmutableContentStore content,
    AdvisorHandoffReader handoffs, EvidenceArtifactMetadataRead metadata)
{
    public async Task<EvidenceDownloadIntent> FreezeAsync(EvidenceArtifact artifact, IssueArtifactDownload request,
        OperationProvenance operation, CancellationToken ct)
    {
        var realm = artifact.Stream.Realm;
        var captured = await metadata.GetCapturedAsync(request.TenantId, request.ArtifactId, ct).ConfigureAwait(false);
        if (!captured.IsSuccess || captured.Value.AvailabilityRecordedAt is not { } available ||
            available > operation.AcceptedAt || artifact.AvailabilityFact is not { } availableFact ||
            captured.Value.Metadata.ContentSha256 != artifact.ContentSha256 || captured.Value.Metadata.ContentLength != artifact.ContentLength)
            throw new ImmutableContentUnavailableException("The exact available inspected artifact is not readable yet.");
        var policy = await reader.HydrateAsync(new EvidenceHandlingPolicy(request.TenantId, request.ArtifactId), ct)
            .ConfigureAwait(false);
        var applied = policy.Current;
        if (applied is not null && (applied.Source.ContentSha256 != artifact.ContentSha256 ||
                applied.ContentLength != artifact.ContentLength))
            throw new ImmutableContentIntegrityException("The handling classification concerns another artifact identity or state.");
        var policyFacts = new EvidenceDownloadPinnedFacts("handling", request.ArtifactId, artifact.ContentSha256!,
            artifact.ContentLength!.Value, applied?.PolicyVersion ?? EvidenceHandlingPolicy.CurrentPolicyVersion,
            applied?.HandlingClass ?? artifact.Content!.HandlingClass, null, null, null, null, null);
        var requiredFacts = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), EvidenceDownloadPinnedFacts.Schema,
            policyFacts, ct).ConfigureAwait(false);
        var requirements = new List<SourceUseRequirement>
        {
            new(policy.Stream, NativeFactReference.Of(policy.ContentFact is null ? artifact.Stream : policy.Stream,
                policy.ContentFact ?? availableFact), (ulong)policy.Revision, SourceUsePurpose.ArtifactDownload, requiredFacts),
        };
        if (request.ProgramId is { } program && request.AdvisorHandoffId is { } handoffId && request.SelectedSource is { } selected)
        {
            var snapshot = await handoffs.ReadAsync(request.TenantId, program, handoffId, ct).ConfigureAwait(false);
            var handoff = snapshot.Handoff;
            if (handoff.ProgramId != program || handoff.Status != AdvisorHandoff.ReadyForReview ||
                !snapshot.Selection.Contains(selected) || handoff.ExpiresOn < DateOnly.FromDateTime(operation.AcceptedAt.UtcDateTime))
                throw new ImmutableContentIntegrityException("The exact selected source is not shared by a ready unexpired handoff.");
            var selectionFact = handoff.Facts.Last(fact => fact is AdvisorHandoffCreated or AdvisorHandoffSelectionRevised);
            var until = new DateTimeOffset(handoff.ExpiresOn.AddDays(1).ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc));
            var handoffFacts = new EvidenceDownloadPinnedFacts("handoff", request.ArtifactId, artifact.ContentSha256!,
                artifact.ContentLength.Value, 0, policyFacts.HandlingClass, program, handoffId, selected,
                handoff.SelectionManifest, until);
            var reference = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), EvidenceDownloadPinnedFacts.Schema,
                handoffFacts, ct).ConfigureAwait(false);
            requirements.Add(new SourceUseRequirement(handoff.Stream, NativeFactReference.Of(handoff.Stream, selectionFact),
                (ulong)handoff.Revision, SourceUsePurpose.ArtifactDownload, reference));
        }
        var manifest = await content.WriteSelectionAsync(realm, Uuid.CreateVersion4(), ArtifactDownloadProtocol.RequirementsSchema,
            requirements.OrderBy(row => row.SourceOwner.ToString(), StreamKeyOrder.Instance).ToArray(), SelectionOrder.CanonicalKey,
            ct).ConfigureAwait(false);
        return new EvidenceDownloadIntent(ArtifactDownloadProtocol.Header(operation), request.CommandId, request.ArtifactId,
            artifact.ContentSha256!, artifact.ContentLength!.Value, (ulong)artifact.Revision, request.Purpose.Trim(),
            request.ProgramId, request.AdvisorHandoffId, request.SelectedSource, manifest, ArtifactContentLimits.MaxDeliveryLifetime);
    }
}
