using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>A bounded verified adapter refusal, with no raw URL, exception message or capability token.</summary>
public sealed record ArtifactDownloadTicketObservation(NativeFactReference Admission, ImmutableContentRef Intent,
    Uuid IssueCommandId, string Reason)
{
    public const string Schema = "artifact-download-ticket-observation.v1";
}
