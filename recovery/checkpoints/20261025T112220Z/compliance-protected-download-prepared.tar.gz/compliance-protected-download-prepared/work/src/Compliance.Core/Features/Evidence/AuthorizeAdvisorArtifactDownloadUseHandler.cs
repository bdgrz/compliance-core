using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Holds only an actually selected ready handoff source; ordinary members create no optional use.</summary>
public sealed class AuthorizeAdvisorArtifactDownloadUseHandler(IAggregateReader reader, IAggregateExecutor executor,
    IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier, AdvisorHandoffReader handoffs, TimeProvider clock)
    : AuthorizeSourceUseHandler<AdvisorHandoff, AuthorizeAdvisorArtifactDownloadUse>(reader, executor, content, clock)
{
    protected override AdvisorHandoff Open(AuthorizeAdvisorArtifactDownloadUse request, Uuid selectedCommandId) =>
        new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), Uuid.Empty, request.HandoffId, selectedCommandId);

    protected override ValueTask<Result<SourceUseSource>> VerifyAsync(AuthorizeAdvisorArtifactDownloadUse request, CancellationToken ct) =>
        ArtifactDownloadUsePins.VerifyAsync(async () =>
        {
            var source = await verifier.AuthorizationAsync(request.Source, request.Intent, request.Target, request.OperationId,
                request.Generation, request.ArtifactId, nameof(AuthorizeAdvisorArtifactDownloadUse), request.CommandId, ct).ConfigureAwait(false);
            var facts = await verifier.PinnedAsync(source.Requirement, ct).ConfigureAwait(false);
            if (request.ExpectedRevision is not null || facts.HandoffId != request.HandoffId || facts.SelectedSource != request.SelectedSource || facts.Kind != "handoff")
                throw new ImmutableContentIntegrityException("The use names another optional selected source.");
            return source;
        });

    protected override async ValueTask<Result> VerifyPinnedAsync(AdvisorHandoff owner, SourceUseRequirement requirement, CancellationToken ct)
    {
        var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
        var snapshot = await handoffs.ReadAsync(owner, Uuid.Parse(owner.Stream.Realm, CultureInfo.InvariantCulture), ct).ConfigureAwait(false);
        return IsPinned(owner, requirement) && owner.ProgramId == facts.ProgramId && owner.SelectionManifest == facts.Selection &&
            facts.SelectedSource is { } selected && snapshot.Selection.Contains(selected) && facts.ValidUntil is { } until && clock.GetUtcNow() < until
            ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict, "The selected handoff source changed or expired before acquisition."));
    }

    protected override bool IsPinned(AdvisorHandoff owner, SourceUseRequirement requirement) => ArtifactDownloadUsePins.Handoff(owner, requirement);
    protected override Func<AdvisorHandoff, OperationProvenance, ImmutableContentRef, long, Result> GrantOperation() =>
        (AdvisorHandoff owner, OperationProvenance operation, ImmutableContentRef intent, long generation) => owner.GrantArtifactDownloadUse(operation, intent, generation);
    protected override ValueTask<Result<ReceiverOutcome>> RefuseAsync(AuthorizeAdvisorArtifactDownloadUse request,
        SourceUseSource source, string reason, IExecutionContext context, CancellationToken ct) =>
        ValueTask.FromResult(ReceiverAppend.Rejected("The frozen handoff source cannot grant this download use."));
}
