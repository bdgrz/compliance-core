using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Source identity stays content-bound while reservation facts advance the physical stream.</summary>
static class ArtifactDownloadUsePins
{
    public static bool Policy(EvidenceHandlingPolicy owner, SourceUseRequirement requirement) =>
        requirement.SourceOwner == owner.Stream && requirement.ResourceRevision == (ulong)owner.Revision &&
        (owner.ContentFact is null ? requirement.ResourceRevision == 0 :
            NativeFactReference.Of(owner.Stream, owner.ContentFact) == requirement.ContentEvent);

    public static bool Handoff(AdvisorHandoff owner, SourceUseRequirement requirement)
    {
        var selected = owner.Facts.LastOrDefault(fact => fact is AdvisorHandoffCreated or AdvisorHandoffSelectionRevised);
        return owner.IsCreated && owner.Status == AdvisorHandoff.ReadyForReview && selected is not null &&
            requirement.SourceOwner == owner.Stream && NativeFactReference.Of(owner.Stream, selected) == requirement.ContentEvent;
    }

    public static async ValueTask<Result<SourceUseSource>> VerifyAsync(Func<Task<SourceUseSource>> verify)
    {
        try
        {
            return Result<SourceUseSource>.Success(await verify().ConfigureAwait(false));
        }
        catch (ImmutableContentUnavailableException)
        {
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict, "The exact download source content is not available yet.", true));
        }
        catch (SourceFactVerificationException)
        {
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict, "The native download source proof cannot be verified."));
        }
        catch (ImmutableContentIntegrityException)
        {
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict, "The exact download source content cannot be verified."));
        }
    }
}
