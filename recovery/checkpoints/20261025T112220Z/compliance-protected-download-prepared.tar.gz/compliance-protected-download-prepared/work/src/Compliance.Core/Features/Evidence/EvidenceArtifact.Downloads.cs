using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

public sealed partial class EvidenceArtifact
{
    readonly List<DomainEvent> _downloadFacts = [];
    public NativeAcceptance Acceptance { get; }
    public SourceUseReservations Uses { get; }
    public IReadOnlyList<DomainEvent> DownloadFacts => _downloadFacts;

    void InitializeDownloads()
    {
        On<EvidenceArtifactDownloadRequested>(fact =>
        {
            if (fact.Owner != Stream || fact.Revision != Revision || fact.Generation != 1 ||
                State != EvidenceArtifactStates.Available || fact.FirstResponse is null || fact.OperationResult is not null ||
                fact.Operation.Owner != Stream || fact.Operation.RootOperationId != fact.Operation.LogicalId)
                throw new InvalidOperationException("The artifact download admission is invalid.");
            Acceptance.Observe(fact);
            Uses.ApplyGranted(SourceUsePurpose.ArtifactDownload, fact);
            _downloadFacts.Add(fact);
        });
        On<ArtifactDownloadAvailabilityUseSettled>(fact =>
        {
            if (fact.Owner != Stream || fact.Revision != Revision || fact.Generation != 1 ||
                fact.Operation.Owner != Stream || fact.FirstResponse is not null || fact.OperationResult is not null)
                throw new InvalidOperationException("The artifact availability settlement is invalid.");
            Acceptance.Observe(fact);
            Uses.ApplySettled(SourceUsePurpose.ArtifactDownload, fact);
            _downloadFacts.Add(fact);
        });
    }

    public Result PrepareDownload(long expectedRevision)
    {
        if (!IsCreated)
            return Result.Failure(new RequestError(RequestErrorKind.NotFound, "The evidence artifact was not found."));
        if (State != EvidenceArtifactStates.Available || StateReason is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "Only available inspected evidence can be downloaded."));
        return expectedRevision == Revision ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict,
            "The expected artifact content revision is stale."));
    }

    public Result AdmitDownload(OperationProvenance operation, EvidenceDownloadIntent intent,
        ImmutableContentRef reference, ImmutableContentRef firstResponse)
    {
        if (operation.Owner != Stream || operation.AffectedOwner != Stream || operation.ExpectedRevisionOwner != Stream ||
            operation.RootOperationId != operation.LogicalId || operation.LogicalId != intent.GrantId ||
            intent.ArtifactId != Id || intent.ContentSha256 != ContentSha256 || intent.ContentLength != ContentLength ||
            intent.ArtifactRevision != (ulong)Revision || operation.OriginalExpectedRevision != (ulong)Revision ||
            intent.Header != ArtifactDownloadProtocol.Header(operation) || reference.Schema != EvidenceDownloadIntent.Schema)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The download admission differs from the exact artifact authority."));
        var prepared = PrepareDownload((long)intent.ArtifactRevision);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new EvidenceArtifactDownloadRequested(Stream, Revision, 1, reference, null, operation,
            firstResponse, null));
        return Result.Success;
    }

    public Result SettleDownloadAvailability(OperationProvenance operation, ImmutableContentRef intent, long generation)
    {
        if (operation.Owner != Stream || generation != 1)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The availability settlement names another owner or generation."));
        RaiseEvent(new ArtifactDownloadAvailabilityUseSettled(Stream, Revision, generation, intent, null, operation,
            null, null));
        return Result.Success;
    }
}
