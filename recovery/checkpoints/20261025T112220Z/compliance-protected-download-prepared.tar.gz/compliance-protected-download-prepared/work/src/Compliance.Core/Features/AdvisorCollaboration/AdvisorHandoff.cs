using Bdgrz.Compliance.Features.SourceUse;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AdvisorCollaboration;

/// <summary>
///     One handoff: its small selection and readiness state, its revocation and closure, and the admission authority
///     for feedback. The logical revision counts every fact of this handoff stream and the generation starts at one
///     and advances on every selection revision. Feedback is admitted here, against an exactly selected version while
///     the handoff is ready, unrevoked and unclosed, and materialized as its own <see cref="AdvisorFeedbackThread" />;
///     revocation, closure and feedback admission share this one stream, so an admission either precedes a revocation
///     or is refused by it. The selection is verified content referenced by the latest selection fact; reducers never
///     read content or another owner.
/// </summary>
public sealed partial class AdvisorHandoff : Aggregate, ISourceUseOwner
{
    /// <summary>Stream area of every handoff (the realm is the tenant).</summary>
    public const string Area = "advisor-handoffs";

    /// <summary>The largest selection one handoff can hold.</summary>
    public const int MaximumSelectionCount = 100;

    /// <summary>The handoff status vocabulary.</summary>
    public const string Draft = "draft";
    public const string ReadyForReview = "ready_for_review";
    public const string Closed = "closed";
    public const string Revoked = "revoked";

    readonly Uuid _tenantId;
    readonly Uuid _handoffId;
    readonly List<AdvisorFeedbackAdmitted> _admitted = [];
    readonly HashSet<Uuid> _admittedIds = [];
    readonly List<DomainEvent> _facts = [];
    AdvisorHandoffCreated? _createdFact;
    ImmutableContentRef? _manifest;
    Uuid _programId;
    string _status = "missing";
    long _revision;
    long _generation;
    DateTimeOffset? _updatedAt;
    bool _wasReadyForReview;

    /// <summary>Opens one handoff, selecting the logical operation to resolve.</summary>
    public AdvisorHandoff(Uuid tenantId, Uuid programId, Uuid handoffId, Uuid selectedLogicalId = default)
        : base(handoffId, new EventStreamAddress(tenantId.ToString(), Area, handoffId.ToString()))
    {
        (_tenantId, _programId, _handoffId) = (tenantId, programId, handoffId);
        Acceptance = new NativeAcceptance(selectedLogicalId);
        Uses = new SourceUseReservations(Stream);
        InitializeDownloadUses();
        On<AdvisorHandoffCreated>(Apply);
        On<AdvisorHandoffSelectionRevised>(Apply);
        On<AdvisorHandoffReadiedForReview>(Apply);
        On<AdvisorHandoffClosed>(Apply);
        On<AdvisorHandoffRevoked>(Apply);
        On<AdvisorFeedbackAdmitted>(Apply);
    }

    /// <summary>Acceptance of the logical operation this hydration was selected for.</summary>
    public NativeAcceptance Acceptance { get; }

    /// <summary>True once the handoff was created.</summary>
    public bool IsCreated => _createdFact is not null;

    /// <summary>The program the handoff belongs to.</summary>
    public Uuid ProgramId => _programId;

    /// <summary>The current status: draft, ready for review, closed or revoked.</summary>
    public string Status => _status;

    /// <summary>The logical revision: the number of facts of this handoff.</summary>
    public long Revision => _revision;

    /// <summary>The selection generation: one at creation, plus one for every selection revision.</summary>
    public long Generation => _generation;

    /// <summary>The purpose stated at creation.</summary>
    public string? Purpose => _createdFact?.Purpose;

    /// <summary>The last day the handoff stays shared.</summary>
    public DateOnly ExpiresOn => _createdFact?.ExpiresOn ?? default;

    /// <summary>Who created the handoff.</summary>
    public ActorReference? CreatedBy => _createdFact?.CreatedBy;

    /// <summary>When the handoff was created.</summary>
    public DateTimeOffset? CreatedAt => _createdFact?.CreatedAt;

    /// <summary>When the latest fact was recorded.</summary>
    public DateTimeOffset? UpdatedAt => _updatedAt;

    /// <summary>The ended handoff this selection is compared with.</summary>
    public Uuid? ComparedToHandoffId => _createdFact?.ComparedToHandoffId;

    /// <summary>True once the handoff was opened for review at least once.</summary>
    public bool WasReadyForReview => _wasReadyForReview;

    /// <summary>The verified content of the current selection, once created.</summary>
    public ImmutableContentRef? SelectionManifest => _manifest;

    /// <summary>The feedback admitted so far, in admission order.</summary>
    public IReadOnlyList<AdvisorFeedbackAdmitted> Admitted => _admitted;

    /// <summary>Every fact in order.</summary>
    public IReadOnlyList<DomainEvent> Facts => _facts;

    /// <summary>True when feedback with this id was admitted.</summary>
    public bool HasAdmitted(Uuid feedbackId) => _admittedIds.Contains(feedbackId);

    /// <summary>The fact with this event id.</summary>
    public DomainEvent? FactById(Uuid eventId) => _facts.FirstOrDefault(fact => fact.Metadata?.EventId == eventId);

    /// <summary>True while the handoff can still change: it was created and is neither closed nor revoked.</summary>
    public bool IsOpen => IsCreated && _status is Draft or ReadyForReview;

    /// <summary>Checks that the handoff does not exist yet.</summary>
    public Result PrepareCreate() => IsCreated
        ? Result.Failure(new RequestError(RequestErrorKind.Conflict, "The handoff already exists with different content."))
        : Result.Success;

    /// <summary>Checks that the selection of an open handoff can be revised at the expected revision.</summary>
    public Result PrepareRevise(long expectedRevision)
    {
        if (Uses.HasActiveUse)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The shared selection is held by an admitted download.", true));
        if (!IsCreated)
            return Missing();
        if (!IsOpen)
            return Conflict("Only an open handoff can be revised.");
        return expectedRevision == _revision ? Result.Success : Stale();
    }

    /// <summary>Checks that a draft handoff can be opened for review at the expected revision.</summary>
    public Result PrepareReady(long expectedRevision, DateOnly today)
    {
        if (!IsCreated)
            return Missing();
        if (!IsOpen || _status != Draft)
            return Conflict("Only a draft handoff can be marked ready for review.");
        if (expectedRevision != _revision)
            return Stale();
        return ExpiresOn < today
            ? Result.Failure(new RequestError(RequestErrorKind.Validation,
                "A handoff requires an active exact selection and valid actor before it can be shared."))
            : Result.Success;
    }

    /// <summary>Checks that an open handoff can be closed or revoked at the expected revision.</summary>
    public Result PrepareEnd(long expectedRevision)
    {
        if (Uses.HasActiveUse)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The shared selection is held by an admitted download.", true));
        if (!IsCreated)
            return Missing();
        if (!IsOpen)
            return Conflict("Only an open handoff can be closed or revoked.");
        return expectedRevision == _revision ? Result.Success : Stale();
    }

    /// <summary>
    ///     Checks that feedback can be admitted at the expected revision: the handoff is ready, unrevoked, unclosed and
    ///     unexpired, and the feedback identity was not admitted before. The caller proves the source is selected at
    ///     exactly this revision.
    /// </summary>
    public Result PrepareAdmit(long expectedRevision, DateOnly today)
    {
        if (!IsCreated)
            return Missing();
        if (expectedRevision != _revision)
            return Stale();
        if (_status != ReadyForReview || !IsOpen)
            return Conflict("Feedback is accepted only while the handoff is ready for review.");
        return ExpiresOn < today
            ? Conflict("Feedback is accepted only while the handoff is shared and unexpired.")
            : Result.Success;
    }

    /// <summary>Creates the handoff as the root native fact of its operation.</summary>
    public Result Create(OperationProvenance operation, ImmutableContentRef manifest, string purpose,
        DateOnly expiresOn, ActorReference createdBy, DateTimeOffset createdAt, Uuid? comparedToHandoffId,
        ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(manifest);
        if (operation.Owner != Stream || operation.LogicalId != _handoffId)
            return Result.Failure(new RequestError(RequestErrorKind.Validation,
                "A creation is the logical operation of its own handoff."));
        var prepared = PrepareCreate();
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new AdvisorHandoffCreated(_tenantId, _programId, _handoffId, manifest, purpose, expiresOn,
            createdBy, createdAt, comparedToHandoffId, operation, firstResponse, operationResult));
        return Result.Success;
    }

    /// <summary>Revises the selection as the root native fact of its operation; the generation advances.</summary>
    public Result ReviseSelection(OperationProvenance operation, ImmutableContentRef manifest, string changeReason,
        ActorReference revisedBy, DateTimeOffset revisedAt, ImmutableContentRef firstResponse,
        ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(manifest);
        var prepared = PrepareOwn(operation, PrepareRevise);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new AdvisorHandoffSelectionRevised(_tenantId, _programId, _handoffId, _revision + 1, manifest,
            changeReason, revisedBy, revisedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    /// <summary>Opens the draft handoff for review as the root native fact of its operation.</summary>
    public Result MarkReady(OperationProvenance operation, ActorReference readiedBy, DateTimeOffset readiedAt,
        ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        var prepared = PrepareOwn(operation, expected => PrepareReady(expected, DateOnly.FromDateTime(readiedAt.UtcDateTime)));
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new AdvisorHandoffReadiedForReview(_tenantId, _programId, _handoffId, _revision + 1, readiedBy,
            readiedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    /// <summary>Closes the handoff as the root native fact of its operation.</summary>
    public Result Close(OperationProvenance operation, string rationale, ActorReference closedBy,
        DateTimeOffset closedAt, ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        var prepared = PrepareOwn(operation, PrepareEnd);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new AdvisorHandoffClosed(_tenantId, _programId, _handoffId, _revision + 1, rationale, closedBy,
            closedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    /// <summary>Revokes the handoff as the root native fact of its operation.</summary>
    public Result Revoke(OperationProvenance operation, string rationale, ActorReference revokedBy,
        DateTimeOffset revokedAt, ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        var prepared = PrepareOwn(operation, PrepareEnd);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new AdvisorHandoffRevoked(_tenantId, _programId, _handoffId, _revision + 1, rationale, revokedBy,
            revokedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    /// <summary>Admits one feedback contribution for the current generation as the root native fact of its operation.</summary>
    public Result AdmitFeedback(OperationProvenance operation, ImmutableContentRef intent, DateOnly today,
        ImmutableContentRef firstResponse)
    {
        ArgumentNullException.ThrowIfNull(operation);
        ArgumentNullException.ThrowIfNull(intent);
        var prepared = PrepareOwn(operation, expected => PrepareAdmit(expected, today));
        if (!prepared.IsSuccess)
            return prepared;
        if (_admittedIds.Contains(operation.LogicalId))
            return Conflict("The feedback identifier already has different content.");
        RaiseEvent(new AdvisorFeedbackAdmitted(Stream, _revision + 1, _generation, intent, null, operation,
            firstResponse, null));
        return Result.Success;
    }

    void Apply(AdvisorHandoffCreated ev)
    {
        Acceptance.Observe(ev);
        if (_createdFact is not null || ev.TenantId != _tenantId || ev.HandoffId != _handoffId ||
            ev.ProgramId == Uuid.Empty || ev.Operation.Owner != Stream || ev.Operation.LogicalId != _handoffId ||
            ev.ComparedToHandoffId is { } comparedTo && (comparedTo == Uuid.Empty || comparedTo == _handoffId))
            throw new InvalidOperationException("A handoff stream is created once, by its own operation.");
        _createdFact = ev;
        _programId = ev.ProgramId;
        _manifest = ev.RecordVersionsManifest;
        _revision = 1;
        _generation = 1;
        _status = Draft;
        _updatedAt = ev.CreatedAt;
        _facts.Add(ev);
    }

    void Apply(AdvisorHandoffSelectionRevised ev)
    {
        Acceptance.Observe(ev);
        EnsureOpen(ev.TenantId, ev.ProgramId, ev.HandoffId, ev.Revision, ev.Operation);
        _manifest = ev.RecordVersionsManifest;
        _generation++;
        _status = Draft;
        Advance(ev, ev.RevisedAt);
    }

    void Apply(AdvisorHandoffReadiedForReview ev)
    {
        Acceptance.Observe(ev);
        EnsureOpen(ev.TenantId, ev.ProgramId, ev.HandoffId, ev.Revision, ev.Operation);
        if (_status != Draft)
            throw new InvalidOperationException("Only a draft handoff is readied for review.");
        _status = ReadyForReview;
        _wasReadyForReview = true;
        Advance(ev, ev.ReadiedAt);
    }

    void Apply(AdvisorHandoffClosed ev)
    {
        Acceptance.Observe(ev);
        EnsureOpen(ev.TenantId, ev.ProgramId, ev.HandoffId, ev.Revision, ev.Operation);
        _status = Closed;
        Advance(ev, ev.ClosedAt);
    }

    void Apply(AdvisorHandoffRevoked ev)
    {
        Acceptance.Observe(ev);
        EnsureOpen(ev.TenantId, ev.ProgramId, ev.HandoffId, ev.Revision, ev.Operation);
        _status = Revoked;
        Advance(ev, ev.RevokedAt);
    }

    void Apply(AdvisorFeedbackAdmitted ev)
    {
        Acceptance.Observe(ev);
        if (!IsCreated || _status != ReadyForReview || ev.Owner != Stream || ev.Revision != _revision + 1 ||
            ev.Generation != _generation || ev.Operation.Owner != Stream || !_admittedIds.Add(ev.Operation.LogicalId))
            throw new InvalidOperationException(
                "Feedback is admitted once, for the current ready generation, at the next revision.");
        _admitted.Add(ev);
        Advance(ev, ev.Operation.AcceptedAt);
    }

    void EnsureOpen(Uuid tenantId, Uuid programId, Uuid handoffId, long revision, OperationProvenance operation)
    {
        if (!IsOpen || tenantId != _tenantId || programId != _programId || handoffId != _handoffId ||
            revision != _revision + 1 || operation.Owner != Stream)
            throw new InvalidOperationException("A handoff fact follows the creation at the next revision of an open handoff.");
    }

    void Advance(DomainEvent fact, DateTimeOffset occurredAt)
    {
        _revision++;
        _updatedAt = occurredAt;
        _facts.Add(fact);
    }

    Result PrepareOwn(OperationProvenance operation, Func<long, Result> prepare)
    {
        if (operation.Owner != Stream || operation.OriginalExpectedRevision is not { } expected)
            return Result.Failure(new RequestError(RequestErrorKind.Validation,
                "A handoff write is a root operation of its own handoff with an expected revision."));
        return prepare((long)expected);
    }

    static Result Missing() => Result.Failure(new RequestError(RequestErrorKind.NotFound,
        "The advisor handoff was not found in the requested program."));

    static Result Conflict(string message) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message));

    Result Stale() => Result.Failure(new RequestError(RequestErrorKind.Conflict,
        $"The handoff revision is stale; the current revision is {_revision}."));
}
