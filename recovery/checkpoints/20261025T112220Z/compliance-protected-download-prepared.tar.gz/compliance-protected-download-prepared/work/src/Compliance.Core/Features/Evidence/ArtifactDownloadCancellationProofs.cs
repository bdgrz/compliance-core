using System.Globalization;
using System.Text.Json;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Cancellation requires a concrete immutable source mismatch/expiry or verified adapter refusal.</summary>
public sealed class ArtifactDownloadCancellationProofs(IAggregateReader reader, IImmutableContentStore content,
    ArtifactDownloadSourceVerifier verifier)
{
    public async Task<bool> IsProvenAsync(VerifiedArtifactDownload download, ArtifactDownloadFailureProof failure,
        DateTimeOffset now, CancellationToken ct)
    {
        var intent = download.Intent;
        if (failure.GrantId != intent.GrantId || failure.Generation != ArtifactDownloadProtocol.Generation ||
            failure.Intent != download.Reference || failure.Admission != NativeFactReference.Of(download.Admission.Owner, download.Admission) ||
            failure.DecisionAt < intent.Header.AcceptedAt || failure.DecisionAt > now)
            return false;
        if (failure.Reason == ArtifactDownloadFailureProof.TicketInvalid)
        {
            if (failure.SourceOwner is not null || failure.TicketObservation is not { } reference)
                return false;
            var target = new ArtifactDownloadGrant(Uuid.Parse(intent.Header.FirstOwner.Realm, CultureInfo.InvariantCulture), intent.GrantId).Stream;
            var commandId = EffectIdentity.CommandId(download.Admission.Metadata.EventId,
                $"{ArtifactDownloadProcess.Name}:{nameof(IssueProtectedArtifactDownloadGrant)}", target.ToString(), intent.Header.Episode);
            var expected = IssueProtectedArtifactDownloadGrantHandler.TicketObservation(download, commandId);
            if (reference != TicketReference(expected))
                return false;
            var observed = await ArtifactDownloadProtocol.ReadAsync<ArtifactDownloadTicketObservation>(content,
                target.Realm, reference, ArtifactDownloadTicketObservation.Schema, ct).ConfigureAwait(false);
            return observed == expected;
        }
        var requirement = download.Requirements.SingleOrDefault(row => row.SourceOwner == failure.SourceOwner);
        if (requirement is null || failure.TicketObservation is not null)
            return false;
        var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
        if (failure.Reason == ArtifactDownloadFailureProof.SourceExpired)
            return facts.ValidUntil is { } until && failure.DecisionAt >= until;
        if (failure.Reason != ArtifactDownloadFailureProof.SourceRevoked)
            return false;
        var tenant = Uuid.Parse(intent.Header.FirstOwner.Realm, CultureInfo.InvariantCulture);
        if (facts.Kind == "handling")
        {
            var policy = await reader.HydrateAsync(new EvidenceHandlingPolicy(tenant, intent.ArtifactId), ct).ConfigureAwait(false);
            return !ArtifactDownloadUsePins.Policy(policy, requirement);
        }
        var handoff = await reader.HydrateAsync(new AdvisorHandoff(tenant, intent.ProgramId!.Value, intent.AdvisorHandoffId!.Value), ct)
            .ConfigureAwait(false);
        return !ArtifactDownloadUsePins.Handoff(handoff, requirement);
    }

    public static ImmutableContentRef TicketReference(ArtifactDownloadTicketObservation value)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(value, ComplianceCoreJsonContext.Default.ArtifactDownloadTicketObservation);
        return new ImmutableContentRef(IssueProtectedArtifactDownloadGrantHandler.TicketObservationId(value.IssueCommandId),
            ContentDigest.Sha256(bytes), bytes.Length, ImmutableContentStoreExtensions.JsonMediaType, ArtifactDownloadTicketObservation.Schema);
    }
}
