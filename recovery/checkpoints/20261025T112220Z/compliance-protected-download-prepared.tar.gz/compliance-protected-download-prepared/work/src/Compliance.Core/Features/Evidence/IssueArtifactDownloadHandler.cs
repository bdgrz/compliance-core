using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Admits and pins a personal download; every exact write retry returns its original fixed 202.</summary>
sealed class IssueArtifactDownloadHandler(EvidenceArtifactDownloadAccess access, EvidenceDownloadAdmission admission,
    NativeOperationExecutor operations, IImmutableContentStore content, IProtectedResponseContentStore protectedContent,
    TimeProvider clock) : IRequestHandler<IssueArtifactDownload, OperationAcceptedResponse>
{
    public async ValueTask<Result<OperationAcceptedResponse>> HandleAsync(IRequestContext<IssueArtifactDownload> context,
        CancellationToken ct)
    {
        var request = context.Request;
        if (!PersonalHttpActor(context.Actor, context.Invocation, request.TenantId, out var actor))
            return Failure(RequestErrorKind.Forbidden, "Artifact downloads require a personal HTTP request.");
        var allowed = await access.RequireAsync(context, request.TenantId, request.ArtifactId, request.ProgramId,
            request.AdvisorHandoffId, request.SelectedSource, ct).ConfigureAwait(false);
        if (!allowed.IsSuccess)
            return Result<OperationAcceptedResponse>.Failure(allowed.Error!);
        if (request.CommandId == Uuid.Empty || request.TenantId == Uuid.Empty || request.ArtifactId == Uuid.Empty ||
            request.ExpectedArtifactRevision < 0 || string.IsNullOrWhiteSpace(request.Purpose) ||
            request.Purpose.Trim().Length > EvidenceRules.MaximumTextLength)
            return Failure(RequestErrorKind.Validation, "A download requires exact identities, a nonnegative revision and a bounded purpose.");
        var owner = new EvidenceArtifact(request.TenantId, request.ArtifactId, request.CommandId);
        var operation = RootOperation.Provenance(request.CommandId, nameof(IssueArtifactDownload), owner.Stream, actor,
            request.ExpectedArtifactRevision, AuthoredIntentDigest.Compute(ArtifactDownloadAuthoredIntent.Of(request)), clock.GetUtcNow());
        EvidenceDownloadIntent? intent = null;
        ImmutableContentRef? reference = null;
        try
        {
            var outcome = await operations.ExecuteAsync(new NativeOperation<EvidenceArtifact>(AcceptedOperationBinding.Of(operation),
                () => new EvidenceArtifact(request.TenantId, request.ArtifactId, request.CommandId), aggregate => aggregate.Acceptance,
                async (aggregate, token) =>
                {
                    var prepared = aggregate.PrepareDownload(request.ExpectedArtifactRevision);
                    if (!prepared.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(prepared.Error!);
                    try
                    {
                        protectedContent.RequireConfigured();
                        intent = await admission.FreezeAsync(aggregate, request, operation, token).ConfigureAwait(false);
                        reference = await content.WriteJsonAsync(owner.Stream.Realm, Uuid.CreateVersion4(), EvidenceDownloadIntent.Schema,
                            intent, token).ConfigureAwait(false);
                        var body = await content.WriteJsonAsync(owner.Stream.Realm, Uuid.CreateVersion4(), "operation-accepted-response.v1",
                            new OperationAcceptedResponse(request.CommandId,
                                $"/api/v1/tenants/{request.TenantId}/operations/{request.CommandId}", operation.AcceptedAt), token).ConfigureAwait(false);
                        return Result<FirstResponseDescriptor>.Success(new FirstResponseDescriptor(202,
                            ImmutableContentStoreExtensions.JsonMediaType, "operation-accepted-response.v1", new StandardResponseBody(body)));
                    }
                    catch (ImmutableContentUnavailableException)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "Download authority or protected response storage is not available yet.", true));
                    }
                    catch (ImmutableContentIntegrityException)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The exact download authority cannot be verified."));
                    }
                }, (aggregate, frozen) => aggregate.AdmitDownload(operation, intent!, reference!, frozen)), context, ct)
                .ConfigureAwait(false);
            return await NativeContent.ResponseAsync<OperationAcceptedResponse>(content, request.TenantId, outcome, ct)
                .ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException)
        {
            return Failure(RequestErrorKind.Conflict, "The original download acceptance is not available yet.", true);
        }
        catch (ImmutableContentIntegrityException)
        {
            return Failure(RequestErrorKind.Conflict, "The original download acceptance cannot be verified.");
        }
    }

    internal static bool PersonalHttpActor(System.Security.Claims.ClaimsPrincipal principal, RequestInvocation invocation,
        Uuid tenantId, out ActorReference actor)
    {
        actor = null!;
        if (invocation is not HttpInvocation || RequestActor.IsSystem(principal) ||
            !UserIdentityClaims.TryGetBdgrzSubject(principal, out var user))
            return false;
        actor = ActorReference.ForMember(RbacIds.Member(tenantId, user), UserIdentityClaims.BdgrzDisplay(principal, user));
        return true;
    }

    static Result<OperationAcceptedResponse> Failure(RequestErrorKind kind, string message, bool transient = false) =>
        Result<OperationAcceptedResponse>.Failure(new RequestError(kind, message, transient));
}
