using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>All source uses must still be held, content-bound and temporally valid at the irreversible decision.</summary>
public sealed class ArtifactDownloadIssueProofs(IAggregateReader reader, IImmutableContentStore content,
    ArtifactDownloadSourceVerifier verifier)
{
    public async Task<Result> VerifyAsync(VerifiedArtifactDownload download, ImmutableContentRef proofs,
        DateTimeOffset decisionAt, CancellationToken ct)
    {
        var intent = download.Intent;
        if (decisionAt < intent.Header.AcceptedAt)
            return Invalid("The grant decision predates its accepted request.");
        var tenant = Uuid.Parse(intent.Header.FirstOwner.Realm, CultureInfo.InvariantCulture);
        var artifact = await reader.HydrateAsync(new EvidenceArtifact(tenant, intent.ArtifactId), ct).ConfigureAwait(false);
        var availability = artifact.Uses.Find(ArtifactDownloadProtocol.Key(intent, artifact.Stream));
        if (availability is not { IsActive: true } || availability.GrantFact is not EvidenceArtifactDownloadRequested fact ||
            fact.Metadata.EventId != download.Admission.Metadata.EventId || artifact.State != EvidenceArtifactStates.Available ||
            artifact.ContentSha256 != intent.ContentSha256 || artifact.ContentLength != intent.ContentLength ||
            artifact.Revision != (long)intent.ArtifactRevision)
            return Invalid("The exact admitted artifact availability is no longer held.");
        var grants = await ArtifactDownloadProtocol.ReadAsync<IReadOnlyList<NativeFactReference>>(content,
            artifact.Stream.Realm, proofs, ArtifactDownloadProtocol.ProofsSchema, ct).ConfigureAwait(false);
        if (grants.Count != download.Requirements.Count || grants.Select(grant => grant.Stream).Distinct().Count() != grants.Count ||
            !grants.Select(grant => grant.Stream.ToString()).SequenceEqual(download.Requirements.Select(row => row.SourceOwner.ToString())))
            return Invalid("The grant does not contain the complete canonically ordered required source proofs.");
        foreach (var requirement in download.Requirements)
        {
            var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
            if (facts.ValidUntil is { } until && decisionAt >= until)
                return Invalid("A required source expired before the irreversible download decision.");
            ISourceUseOwner source;
            if (facts.Kind == "handling")
            {
                var policy = await reader.HydrateAsync(new EvidenceHandlingPolicy(tenant, intent.ArtifactId), ct).ConfigureAwait(false);
                if (!ArtifactDownloadUsePins.Policy(policy, requirement))
                    return Invalid("The held handling source changed before the irreversible decision.");
                source = policy;
            }
            else
            {
                var handoff = await reader.HydrateAsync(new AdvisorHandoff(tenant, intent.ProgramId!.Value, intent.AdvisorHandoffId!.Value), ct)
                    .ConfigureAwait(false);
                if (!ArtifactDownloadUsePins.Handoff(handoff, requirement) || handoff.ProgramId != intent.ProgramId ||
                    handoff.SelectionManifest != facts.Selection)
                    return Invalid("The held selected handoff source changed before the irreversible decision.");
                source = handoff;
            }
            var held = source.Uses.Find(ArtifactDownloadProtocol.Key(intent, requirement.SourceOwner));
            var expected = grants.Single(grant => grant.Stream == requirement.SourceOwner);
            if (held is not { IsActive: true, GrantFact: ISourceUseFact granted } ||
                NativeFactReference.Of(requirement.SourceOwner, held.GrantFact) != expected ||
                granted.Operation.RootOperationId != intent.GrantId || granted.Operation.FirstOwner != intent.Header.FirstOwner ||
                granted.Generation != ArtifactDownloadProtocol.Generation)
                return Invalid("An exact required source authorization is not held for this operation.");
            var use = await ArtifactDownloadProtocol.ReadAsync<SourceUseAuthorizationIntent>(content, source.Stream.Realm,
                granted.Intent, SourceUseAuthorizationIntent.Schema, ct).ConfigureAwait(false);
            if (use.Header != intent.Header || use.ParentIntent != download.Reference || use.Requirement != requirement ||
                use.Reservation != ArtifactDownloadProtocol.Key(intent, source.Stream) || use.Grant is not null || use.Disposition is not null)
                return Invalid("A source authorization does not bind the exact frozen requirement and root.");
        }
        return Result.Success;
    }

    static Result Invalid(string message) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message));
}
