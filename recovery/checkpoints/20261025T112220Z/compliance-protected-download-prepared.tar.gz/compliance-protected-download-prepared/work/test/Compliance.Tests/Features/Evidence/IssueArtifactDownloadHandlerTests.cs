using System.Text;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Bdgrz.Compliance.Hosting.Persistence;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz.Testing;
using System.Security.Claims;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.Retention;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Evidence;

public sealed partial class IssueArtifactDownloadHandlerTests
{
    static readonly DateTimeOffset Now = new(2026, 10, 17, 16, 0, 0, TimeSpan.Zero);

    [Fact]
    public async Task ShouldIssueShortLivedAttributedDeliveryGivenAvailableExactArtifactGrant()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Type I audit review", 2);
        var handler = fixture.Handler();

        // Act
        var result = await handler.HandleAsync(fixture.Context(request), CancellationToken.None);
        var completed = await fixture.DriveAsync(request);
        var retained = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));
        var grant = await fixture.Reader.HydrateAsync(new ArtifactDownloadGrant(fixture.TenantId, request.CommandId));
        var original = await fixture.ResultReader().ReadAsync(fixture.Context(request), fixture.TenantId, artifactId,
            request.CommandId, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(request.CommandId, result.Value.OperationId);
        Assert.Equal(ProcessState.Completed, completed.State);
        Assert.True(original.IsSuccess, original.Error?.Message);
        Assert.Equal(Now.AddMinutes(5), original.Value.ExpiresAt);
        Assert.StartsWith("urn:bdgrz:artifact-delivery:", original.Value.Location.ToString());
        Assert.Equal(2, retained.Revision);
        Assert.Equal(4UL, retained.CommittedStreamPosition);
        var issued = Assert.IsType<EvidenceArtifactDownloadIssued>(grant.Issued);
        Assert.Equal(fixture.TenantId, issued.TenantId);
        Assert.Equal(artifactId, issued.ArtifactId);
        Assert.Equal("Type I audit review", issued.Purpose);
        Assert.Equal(ActorReference.ForMember(RbacIds.Member(fixture.TenantId, fixture.UserId),
            "lead@example.test"), issued.IssuedBy);
    }

    [Theory]
    [InlineData(EvidenceInspectionOutcome.Malware)]
    [InlineData(EvidenceInspectionOutcome.SecretDetected)]
    public async Task ShouldRefuseDeliveryWithoutAppendGivenUnavailableArtifact(EvidenceInspectionOutcome outcome)
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(outcome);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Type I audit review", 2);

        // Act
        var result = await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None);
        var retained = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.Equal(2, retained.Revision);
        Assert.Equal(2UL, retained.CommittedStreamPosition);
    }

    [Fact]
    public async Task ShouldRequirePersonalHttpInvocationGivenDownloadRequest()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Type I audit review", 2);
        var context = new Cntryl.Portia.RequestContext<IssueArtifactDownload>(request,
            new RequestDispatchContext(RequestActor.System, new HttpInvocation("POST", "/test", "/test", "test")));

        // Act
        var result = await fixture.Handler().HandleAsync(context, CancellationToken.None);
        var retained = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));

        // Assert
        Assert.Equal(RequestErrorKind.Forbidden, result.Error?.Kind);
        Assert.Equal(2UL, retained.CommittedStreamPosition);
    }

    [Fact]
    public async Task ShouldRequireSeparateArtifactGrantGivenKnownContentIdentity()
    {
        // Arrange
        await using var fixture = new Fixture(allow: false);
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Type I audit review", 2);

        // Act
        var result = await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None);
        var retained = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));

        // Assert
        Assert.Equal(RequestErrorKind.NotFound, result.Error?.Kind);
        Assert.Equal(2UL, retained.CommittedStreamPosition);
    }

    [Fact]
    public async Task ShouldIssueSelectedEvidenceDownloadGivenActiveAdvisorHandoff()
    {
        // Arrange
        await using var fixture = new Fixture(allow: false);
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var metadata = await new EvidenceArtifactMetadataRead(fixture.Reader, fixture.Events)
            .GetAsync(fixture.TenantId, artifactId, CancellationToken.None);
        Assert.True(metadata.IsSuccess, metadata.Error?.Message);
        var selected = AdvisorRecordVersion.EvidenceArtifact(artifactId, revision: 2,
            metadata.Value.SourcePosition, metadata.Value.ContentSha256, Uuid.CreateVersion4());
        var request = await fixture.AdvisorRequestAsync(artifactId, selected);
        var sharedAccess = new EvidenceArtifactDownloadAccess(new FixedArtifactPermission(false),
            new FixedAdvisorSourceAuthorization(allow: true),
            new FixedCurrentSourceResolver());

        // Act
        var result = await fixture.Handler(sharedAccess).HandleAsync(fixture.Context(request),
            CancellationToken.None);
        var retained = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId,
            artifactId));

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(2, retained.Revision);
    }

    sealed class Fixture : IAsyncDisposable
    {
        readonly ServiceProvider _provider;
        readonly AsyncServiceScope _scope;
        readonly LocalArtifactContentStore _store;
        readonly string _root = Path.Combine(Path.GetTempPath(), $"bdgrz-evidence-download-{Guid.NewGuid():N}");
        public Uuid TenantId { get; } = Uuid.CreateVersion4();
        public Uuid UserId { get; } = Uuid.CreateVersion4();
        public FixedTimeProvider Clock { get; } = new(Now);
        public RecordingContentStore Content { get; }
        public CountingProtectedStore Protected { get; }
        public CountingArtifactStore Artifacts { get; }
        public IServiceProvider Services => _scope.ServiceProvider;
        public IAggregateReader Reader { get; }
        public IAggregateWriter Writer { get; }
        public IAggregateExecutor Executor { get; }
        public IDomainEventReader Events { get; }
        public EvidenceArtifactDownloadAccess Access { get; }
        ClaimsPrincipal Actor => new(new ClaimsIdentity(
            [new Claim("iss", "bdgrz"), new Claim("sub", UserId.ToString()),
                new Claim("email", "lead@example.test")], "BdgrzSession"));

        public Fixture(bool allow = true)
        {
            var services = new ServiceCollection();
            var events = new InMemoryEventStore();
            services.AddSingleton<IEventStore>(events);
            services.AddSingleton<IDomainEventReader>(events);
            var kv = new PersistenceKvClient(new InMemoryKvClient());
            Content = new RecordingContentStore(new FitzKvImmutableContentStore(kv));
            Protected = new CountingProtectedStore(new AesProtectedResponseContentStore(Content,
                new ProtectedResponseKeyRing("test-key-v1", new Dictionary<string, byte[]> { ["test-key-v1"] = Enumerable.Repeat((byte)5, 32).ToArray() })));
            _store = new LocalArtifactContentStore(new ArtifactContentStoreOptions(_root, new byte[32],
                ArtifactContentLimits.MaxContentLength), Clock);
            Artifacts = new CountingArtifactStore(_store, Clock);
            services.AddSingleton<TimeProvider>(Clock);
            services.AddSingleton<IImmutableContentStore>(Content);
            services.AddSingleton<IProtectedResponseContentStore>(Protected);
            services.AddSingleton<IArtifactContentStore>(Artifacts);
            services.AddSingleton<IProcessRecordStore>(new FitzKvProcessRecordStore(kv));
            services.AddSingleton(ArtifactDownloadProcess.Definition());
            services.AddSingleton<ProcessCatalog>(provider => new ProcessCatalog(provider.GetServices<ProcessDefinition>()));
            services.AddScoped<ProcessDriver>();
            services.AddScoped<ReceiverAppend>();
            services.AddScoped<ArtifactDownloadSourceVerifier>();
            services.AddScoped<ArtifactDownloadCancellationProofs>();
            services.AddScoped<ArtifactDownloadIssueProofs>();
            services.AddScoped<AdvisorHandoffReader>();
            services.AddScoped<ISourceFactResolver>(provider => new EventStoreSourceFactResolver(provider.GetRequiredService<IDomainEventReader>()));
            services.AddPortia()
                .AddRequestHandler<AuthorizeArtifactHandlingDownloadUseHandler>()
                .AddRequestHandler<AuthorizeAdvisorArtifactDownloadUseHandler>()
                .AddRequestHandler<IssueProtectedArtifactDownloadGrantHandler>()
                .AddRequestHandler<CancelProtectedArtifactDownloadGrantHandler>()
                .AddRequestHandler<SettleArtifactHandlingDownloadUseHandler>()
                .AddRequestHandler<SettleAdvisorArtifactDownloadUseHandler>()
                .AddRequestHandler<SettleArtifactDownloadAvailabilityUseHandler>()
                .AddRequestAuthorizer<ArtifactDownloadReceiverAuthorizer>();
            _provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true });
            _scope = _provider.CreateAsyncScope();
            Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();
            Writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
            Executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();
            Events = _scope.ServiceProvider.GetRequiredService<IDomainEventReader>();
            Access = new(new FixedArtifactPermission(allow));
        }

        public IssueArtifactDownloadHandler Handler(EvidenceArtifactDownloadAccess? access = null) => new(access ?? Access,
            new EvidenceDownloadAdmission(Reader, Content, new AdvisorHandoffReader(Reader, Content), new EvidenceArtifactMetadataRead(Reader, Events)),
            new NativeOperationExecutor(Reader, Executor, Content), Content, Protected, Clock);

        public ArtifactDownloadResultReader ResultReader(EvidenceArtifactDownloadAccess? access = null) => new(Reader,
            access ?? Access, new EvidenceArtifactMetadataRead(Reader, Events), Content, Protected);

        public IssueProtectedArtifactDownloadGrantHandler GrantHandler(IAggregateExecutor? executor = null) => new(Reader,
            new ReceiverAppend(executor ?? Executor), Services.GetRequiredService<ArtifactDownloadSourceVerifier>(),
            Services.GetRequiredService<ArtifactDownloadIssueProofs>(), Artifacts, Content, Protected, Clock);

        public async Task<ProcessRecord> RecordAsync(IssueArtifactDownload request)
        {
            var artifact = await Reader.HydrateAsync(new EvidenceArtifact(TenantId, request.ArtifactId));
            var admitted = Assert.Single(artifact.DownloadFacts.OfType<EvidenceArtifactDownloadRequested>().Where(fact => fact.Operation.LogicalId == request.CommandId));
            var intent = await Content.ReadJsonAsync<EvidenceDownloadIntent>(TenantId.ToString(), admitted.Intent);
            var selected = await Content.ReadSelectionAsync<SourceUseRequirement>(TenantId.ToString(), intent.RequiredSourceUses);
            var source = NativeFactReference.Of(artifact.Stream, admitted);
            return await Services.GetRequiredService<IProcessRecordStore>().CreateIfAbsentAsync(ProcessRecord.Start(
                ProcessKey.ForRoot(ArtifactDownloadProcess.Name, request.CommandId, source), source, intent.Header.Episode, admitted.Intent,
                selected.Select(row => row.SourceOwner.ToString()).Append(artifact.Stream.ToString())
                    .Append(new ArtifactDownloadGrant(TenantId, request.CommandId).Stream.ToString()), Clock.GetUtcNow()));
        }

        public async Task<ProcessRecord> DriveAsync(IssueArtifactDownload request)
        {
            var record = await RecordAsync(request);
            return await Services.GetRequiredService<ProcessDriver>().RunAsync(record.Key, "download-test", new RequestDispatchContext(RequestActor.System));
        }

        public async Task<IRequest<ReceiverOutcome>?> StepAsync(ProcessRecord record, string stage, string receiver, string? target)
        {
            var id = EffectIdentity.CommandId(record.Source.EventId, $"{ArtifactDownloadProcess.Name}:{receiver}", target ?? "-", record.Episode);
            return await ArtifactDownloadProcess.Definition().CreateReceiver(new ProcessStep(record, stage, receiver, target, id), Services, CancellationToken.None);
        }

        public async Task<(ProcessRecord Record, IssueProtectedArtifactDownloadGrant Command)> AcquireAsync(IssueArtifactDownload request)
        {
            var record = await RecordAsync(request);
            foreach (var target in record.Targets)
            {
                foreach (var receiver in ArtifactDownloadProcess.Definition().Stages[0].Receivers)
                {
                    var command = await StepAsync(record, "acquire", receiver, target);
                    if (command is null)
                        continue;
                    var applied = await Services.GetRequiredService<IRequestBus>().SendAsync(command, new RequestDispatchContext(RequestActor.System));
                    Assert.True(applied.IsSuccess, applied.Error?.Message);
                    var fact = applied.Value switch
                    {
                        ReceiverOutcome.Applied added => added.Fact,
                        ReceiverOutcome.Replayed replay => replay.Fact,
                        _ => throw new InvalidOperationException("The test expected an acquired source use."),
                    };
                    record = record with { Facts = new Dictionary<string, NativeFactReference>(record.Facts, StringComparer.Ordinal)
                        { [ProcessRecord.FactKey(receiver, target)] = fact } };
                }
            }
            record = await Services.GetRequiredService<IProcessRecordStore>().ReplaceAsync(record with { StageIndex = 1 }, record.Version);
            var targetGrant = new ArtifactDownloadGrant(TenantId, request.CommandId).Stream.ToString();
            return (record, Assert.IsType<IssueProtectedArtifactDownloadGrant>(await StepAsync(record, "issue", nameof(IssueProtectedArtifactDownloadGrant), targetGrant)));
        }

        public async Task<IssueArtifactDownload> AdvisorRequestAsync(Uuid artifactId, AdvisorRecordVersion selected)
        {
            var program = Uuid.CreateVersion4();
            var id = Uuid.CreateVersion4();
            var handoff = new AdvisorHandoff(TenantId, program, id);
            var actor = ActorReference.ForMember(RbacIds.Member(TenantId, UserId), "Advisor manager");
            var manifest = await Content.WriteJsonAsync(TenantId.ToString(), Uuid.CreateVersion4(), "AdvisorHandoffCreated.RecordVersionsManifest.v1",
                (IReadOnlyList<AdvisorRecordVersion>)new[] { selected });
            var (response, result) = await NativeContent.FreezeUnitAsync(Content, TenantId);
            var frozen = await FirstResponses.FreezeAsync(Content, TenantId.ToString(), response);
            Assert.True(handoff.Create(RootOperation.Provenance(id, nameof(CreateAdvisorHandoff), handoff.Stream, actor, null,
                new string('a', 64), Clock.GetUtcNow()), manifest, "Advisor review", DateOnly.FromDateTime(Now.UtcDateTime), actor,
                Clock.GetUtcNow(), null, frozen, result).IsSuccess);
            await Writer.SaveAsync(handoff, new RequestDispatchContext(RequestActor.System));
            Assert.True(handoff.MarkReady(RootOperation.Provenance(Uuid.CreateVersion4(), nameof(MarkAdvisorHandoffReadyForReview), handoff.Stream,
                actor, handoff.Revision, new string('b', 64), Clock.GetUtcNow()), actor, Clock.GetUtcNow(), frozen, result).IsSuccess);
            await Writer.SaveAsync(handoff, new RequestDispatchContext(RequestActor.System));
            return new IssueArtifactDownload(Uuid.CreateVersion4(), TenantId, artifactId, "Advisor review", 2)
                { ProgramId = program, AdvisorHandoffId = id, SelectedSource = selected };
        }

        public Cntryl.Portia.RequestContext<T> Context<T>(T request) where T : IRequestBase => new(request,
            new RequestDispatchContext(Actor, new HttpInvocation("POST", "/api/v1/evidence/downloads",
                "/api/v1/evidence/downloads", "evidence-download-test")));

        public async Task<Uuid> SeedArtifactAsync(EvidenceInspectionOutcome outcome)
        {
            var bytes = "verified evidence"u8.ToArray();
            var stored = await _store.StoreIfAbsentAsync(TenantId, new MemoryStream(bytes));
            var artifactId = EvidenceIntake.IdFor(TenantId, stored.Content.Sha256);
            var artifact = new EvidenceArtifact(TenantId, artifactId);
            Assert.True(artifact.Register(new EvidenceArtifactContent("Audit evidence", null, "document",
                    "Manual upload", Now.AddMinutes(-2), new DateOnly(2025, 1, 1),
                    new DateOnly(2025, 12, 31), "restricted"),
                stored.Content.Sha256, stored.Content.Length,
                ActorReference.ForMember(RbacIds.Member(TenantId, UserId), "Collector"),
                Now.AddMinutes(-2)).IsSuccess);
            Assert.Null(artifact.RecordInspection(outcome, Now.AddMinutes(-1)));
            await Writer.SaveAsync(artifact, Context(new GetEvidenceArtifactMetadata(TenantId, artifactId)));
            if (outcome == EvidenceInspectionOutcome.Malware)
                Assert.True(await _store.QuarantineAsync(stored.Content));
            if (outcome is EvidenceInspectionOutcome.SecretDetected or EvidenceInspectionOutcome.Invalid)
                Assert.Equal(ArtifactDeletionResult.Deleted, await _store.DeleteAsync(stored.Content));
            return artifactId;
        }

        public async Task<IReadOnlyList<DomainEvent>> ArtifactEventsAsync(Uuid artifactId)
        {
            var list = new List<DomainEvent>();
            await foreach (var record in Events.ReadAsync(EvidenceStreams.Address(TenantId, artifactId)))
                list.Add(record.Event);
            return list;
        }

        public async ValueTask DisposeAsync()
        {
            await _scope.DisposeAsync();
            await _provider.DisposeAsync();
            if (Directory.Exists(_root))
                Directory.Delete(_root, recursive: true);
        }
    }

    sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
    {
        public DateTimeOffset UtcNow { get; set; } = utcNow;
        public override DateTimeOffset GetUtcNow() => UtcNow;
    }

    sealed class FixedArtifactPermission(bool allow) : IAccessGrantScopePermissionAuthorizer
    {
        readonly bool _allow = allow;

        public ValueTask<bool> IsAllowedAsync(Uuid tenantId, Uuid userId, Uuid memberId, Uuid programId,
            string permission, CancellationToken ct = default) => ValueTask.FromResult(_allow);

        public ValueTask<ProgramAccessVisibility> GetProgramVisibilityAsync(Uuid tenantId, Uuid userId,
            Uuid memberId, string permission, CancellationToken ct = default) =>
            ValueTask.FromResult(new ProgramAccessVisibility(_allow, new HashSet<Uuid>()));

        public ValueTask<bool> IsAllowedAtAnyScopeAsync(Uuid tenantId, Uuid userId, Uuid memberId,
            IReadOnlyCollection<AccessGrantScope> scopes, string permission, CancellationToken ct = default) =>
            ValueTask.FromResult(_allow && tenantId != Uuid.Empty && userId != Uuid.Empty &&
                memberId == RbacIds.Member(tenantId, userId) && scopes.Count == 1 &&
                scopes.Single() is
                {
                    Kind: AccessGrantScopeKind.SharedResource,
                    ResourceType: EvidenceArtifactResourceTypes.Artifact,
                    Id: var id
                } && id != Uuid.Empty &&
                permission == RbacPermissions.EvidenceArtifactRead);

        public ValueTask<bool> IsAllowedAtAnyApplicationInventoryScopeAsync(Uuid tenantId, Uuid userId,
            Uuid memberId, string permission, CancellationToken ct = default) => ValueTask.FromResult(_allow);
    }

    sealed class FixedAdvisorSourceAuthorization(bool allow) : IAdvisorSharedSourceAuthorization
    {
        public ValueTask<bool> CanReadSelectedSourceAsync(Uuid tenantId, Uuid programId,
            Uuid handoffId, AdvisorRecordVersion sourceVersion, Uuid userId,
            CancellationToken ct = default) => ValueTask.FromResult(allow);
    }

    sealed class FixedCurrentSourceResolver : IAdvisorRecordVersionResolver
    {
        public ValueTask<Result> RequireCurrentAsync(Uuid tenantId, Uuid programId,
            IReadOnlyList<AdvisorRecordVersion> selection, CancellationToken ct = default) =>
            ValueTask.FromResult(Result.Success);
    }
}
