from prep_common import *
p=copy('test/Compliance.Tests/Features/AdvisorCollaboration/AdvisorRecordVersionResolverTests.cs');s=p.read_text()
a=s.index('        Assert.Null(artifact.RecordDownload(');b=s.index('        var metadata = ',a)
s=s[:a]+'''        await fixture.AdmitDownloadAsync(artifact);
'''+s[b:]
pos=s.index('        public AdvisorRecordVersionResolver Resolver(')
s=s[:pos]+'''        public async Task AdmitDownloadAsync(EvidenceArtifact artifact)
        {
            var content = _scope.ServiceProvider.GetRequiredService<IImmutableContentStore>();
            var request = new IssueArtifactDownload(Uuid.CreateVersion4(), TenantId, artifact.Id, "Advisor review", artifact.Revision);
            var operation = RootOperation.Provenance(request.CommandId, nameof(IssueArtifactDownload), artifact.Stream,
                ActorReference.ForMember(MemberId, "Lead"), artifact.Revision,
                Bdgrz.Compliance.Features.Kernel.AuthoredIntentDigest.Compute(ArtifactDownloadAuthoredIntent.Of(request)), Now.AddMinutes(1));
            var intent = await new EvidenceDownloadAdmission(Reader, content, new AdvisorHandoffReader(Reader, content), Metadata)
                .FreezeAsync(artifact, request, operation, CancellationToken.None);
            var frozen = await content.WriteJsonAsync(TenantId.ToString(), Uuid.CreateVersion4(), EvidenceDownloadIntent.Schema, intent);
            var body = await content.WriteJsonAsync(TenantId.ToString(), Uuid.CreateVersion4(), "operation-accepted-response.v1",
                new OperationAcceptedResponse(request.CommandId, "/pending-download-operation", operation.AcceptedAt));
            var response = await FirstResponses.FreezeAsync(content, TenantId.ToString(), new FirstResponseDescriptor(202,
                ImmutableContentStoreExtensions.JsonMediaType, "operation-accepted-response.v1", new StandardResponseBody(body)));
            Assert.True(artifact.AdmitDownload(operation, intent, frozen, response).IsSuccess);
            await Writer.SaveAsync(artifact, SystemDispatch);
        }

'''+s[pos:]
if 'using Bdgrz.Compliance.Features.NativeOperations;'not in s:s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s
p.write_text(s)
p=copy('test/Compliance.Tests/Features/Examinations/EvidenceGovernanceTypeIBaselineSourceContributorTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Tests.Testing;\n'+s
a=s.index('            var download = new EvidenceArtifactDownloadIssued(');b=s.index('            artifactEventList.Add(',a)
s=s[:a]+'''            var owner = new EvidenceArtifact(TenantId, ArtifactId);
            var operation = RootOperation.Provenance(LaterDownloadRequestId, nameof(IssueArtifactDownload), owner.Stream,
                ActorReference.ForMember(MemberId, "Evidence custodian"), 2, new string('b', 64), AfterTypeIDate);
            var download = new EvidenceArtifactDownloadRequested(owner.Stream, 2, 1, NativeFacts.Ref(EvidenceDownloadIntent.Schema),
                null, operation, NativeFacts.Ref(FirstResponses.Schema), null);
'''+s[b:]
p.write_text(s)
