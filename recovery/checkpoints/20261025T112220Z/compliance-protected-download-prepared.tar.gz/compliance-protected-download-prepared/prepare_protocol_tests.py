from prep_common import *
rel='test/Compliance.Tests/Features/Evidence/ArtifactDownloadProtocolTests.cs'
put(rel,'''using System.Text;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Evidence;

public sealed partial class IssueArtifactDownloadHandlerTests
{
    [Fact]
    public async Task ShouldNotAppendSecondDownloadGivenExactLostResponseRetry()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Type I audit review", 2);
        var context = fixture.Context(request);
        var handler = fixture.Handler();

        // Act
        var first = await handler.HandleAsync(context, CancellationToken.None);
        await fixture.DriveAsync(request);
        fixture.Clock.UtcNow = Now.AddHours(1);
        var retry = await handler.HandleAsync(context, CancellationToken.None);
        var events = await fixture.ArtifactEventsAsync(artifactId);

        // Assert
        Assert.True(first.IsSuccess, first.Error?.Message);
        Assert.True(retry.IsSuccess, retry.Error?.Message);
        Assert.Equal(first.Value, retry.Value);
        Assert.Single(events.OfType<EvidenceArtifactDownloadRequested>());
        Assert.Equal(1, fixture.Artifacts.Issues);
    }

    [Theory]
    [InlineData("purpose")]
    [InlineData("optional_presence")]
    [InlineData("expected_revision")]
    public async Task ShouldRejectChangedAuthoredIntentGivenAcceptedDownloadIdentity(string variant)
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);
        Assert.True((await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var changed = variant switch
        {
            "purpose" => request with { Purpose = "Different review" },
            "optional_presence" => request with { ProgramId = null },
            _ => request with { ExpectedArtifactRevision = 9 },
        };

        // Act
        var result = await fixture.Handler().HandleAsync(fixture.Context(changed), CancellationToken.None);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.Single((await fixture.ArtifactEventsAsync(artifactId)).OfType<EvidenceArtifactDownloadRequested>());
        Assert.Equal(0, fixture.Artifacts.Issues);
    }

    [Fact]
    public async Task ShouldFreezeExplicitDefaultPolicyWithoutHandoffGivenOrdinaryPersonalDownload()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);

        // Act
        var accepted = await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None);
        var record = await fixture.RecordAsync(request);
        var intent = await fixture.Content.ReadJsonAsync<EvidenceDownloadIntent>(fixture.TenantId.ToString(), record.Intent);
        var required = await fixture.Content.ReadSelectionAsync<SourceUseRequirement>(fixture.TenantId.ToString(), intent.RequiredSourceUses);
        var row = Assert.Single(required);
        var pinned = await fixture.Content.ReadJsonAsync<EvidenceDownloadPinnedFacts>(fixture.TenantId.ToString(), row.RequiredFacts);

        // Assert
        Assert.True(accepted.IsSuccess, accepted.Error?.Message);
        Assert.Null(intent.AdvisorHandoffId);
        Assert.Null(intent.SelectedSource);
        Assert.Equal(new EvidenceHandlingPolicy(fixture.TenantId, artifactId).Stream, row.SourceOwner);
        Assert.Equal(0UL, row.ResourceRevision);
        Assert.Equal(EvidenceHandlingPolicy.CurrentPolicyVersion, pinned.PolicyVersion);
        Assert.Equal("restricted", pinned.HandlingClass);
    }

    [Fact]
    public async Task ShouldKeepRawTicketOutOfEveryDurableObjectGivenCompletedProtectedDownload()
    {
        // Arrange
        await using var fixture = new Fixture();
        fixture.Artifacts.UniqueTickets = true;
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);
        Assert.True((await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);

        // Act
        var process = await fixture.DriveAsync(request);
        var original = await fixture.ResultReader().ReadAsync(fixture.Context(request), fixture.TenantId, artifactId, request.CommandId, CancellationToken.None);
        var grant = await fixture.Reader.HydrateAsync(new ArtifactDownloadGrant(fixture.TenantId, request.CommandId));
        var result = await fixture.Content.ReadJsonAsync<MutationResultContent>(fixture.TenantId.ToString(), grant.Issued!.OperationResult!);

        // Assert
        Assert.Equal(ProcessState.Completed, process.State);
        Assert.True(original.IsSuccess, original.Error?.Message);
        Assert.Contains("secret-ticket-1", original.Value.Location.OriginalString, StringComparison.Ordinal);
        Assert.IsType<ProtectedResponseBody>(result.Value);
        Assert.All(fixture.Content.Writes, value => Assert.DoesNotContain("secret-ticket-", Encoding.UTF8.GetString(value), StringComparison.Ordinal));
        Assert.DoesNotContain("secret-ticket-", System.Text.Json.JsonSerializer.Serialize(grant.Issued,
            ComplianceCoreJsonContext.Default.EvidenceArtifactDownloadIssued), StringComparison.Ordinal);
        Assert.DoesNotContain("secret-ticket-", process.Note ?? string.Empty, StringComparison.Ordinal);
    }

    [Fact]
    public async Task ShouldReturnExpiredOriginalAndRequireNewIdentityForRenewalGivenCompletedGrant()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);
        Assert.True((await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        await fixture.DriveAsync(request);
        var original = await fixture.ResultReader().ReadAsync(fixture.Context(request), fixture.TenantId, artifactId, request.CommandId, CancellationToken.None);
        fixture.Clock.UtcNow = Now.AddHours(1);

        // Act
        var expired = await fixture.ResultReader().ReadAsync(fixture.Context(request), fixture.TenantId, artifactId, request.CommandId, CancellationToken.None);
        var next = request with { CommandId = Uuid.CreateVersion4() };
        var accepted = await fixture.Handler().HandleAsync(fixture.Context(next), CancellationToken.None);
        await fixture.DriveAsync(next);
        var renewed = await fixture.ResultReader().ReadAsync(fixture.Context(next), fixture.TenantId, artifactId, next.CommandId, CancellationToken.None);

        // Assert
        Assert.True(expired.IsSuccess, expired.Error?.Message);
        Assert.Equal(original.Value, expired.Value);
        Assert.True(expired.Value.ExpiresAt < fixture.Clock.GetUtcNow());
        Assert.True(accepted.IsSuccess, accepted.Error?.Message);
        Assert.True(renewed.IsSuccess, renewed.Error?.Message);
        Assert.Equal(Now.AddHours(1).AddMinutes(5), renewed.Value.ExpiresAt);
        Assert.NotEqual(original.Value.Location, renewed.Value.Location);
        Assert.Equal(2, fixture.Artifacts.Issues);
    }

    [Fact]
    public async Task ShouldDenyBeforeDecryptGivenCurrentArtifactAuthorizationRevoked()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);
        Assert.True((await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        await fixture.DriveAsync(request);
        var before = fixture.Protected.Reads;

        // Act
        var denied = await fixture.ResultReader(new EvidenceArtifactDownloadAccess(new FixedArtifactPermission(false))).ReadAsync(
            fixture.Context(request), fixture.TenantId, artifactId, request.CommandId, CancellationToken.None);

        // Assert
        Assert.Equal(RequestErrorKind.NotFound, denied.Error?.Kind);
        Assert.Equal(before, fixture.Protected.Reads);
    }

    [Fact]
    public async Task ShouldKeepAvailabilityHeldAndGrantPendingGivenMissingEncryptedResultPublication()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);
        Assert.True((await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var acquired = await fixture.AcquireAsync(request);
        fixture.Protected.FailNextWriteAfterPublication = true;

        // Act
        await Assert.ThrowsAsync<IOException>(async () => await fixture.GrantHandler().HandleAsync(fixture.Context(acquired.Command), CancellationToken.None));
        var pending = await fixture.Reader.HydrateAsync(new ArtifactDownloadGrant(fixture.TenantId, request.CommandId));
        var artifact = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));
        var retried = await fixture.GrantHandler().HandleAsync(fixture.Context(acquired.Command), CancellationToken.None);

        // Assert
        Assert.Null(pending.Terminal);
        Assert.True(artifact.Uses.HasActiveUse);
        Assert.True(retried.IsSuccess, retried.Error?.Message);
        Assert.Equal(2, fixture.Artifacts.Issues);
    }

    [Fact]
    public async Task ShouldRecoverForwardWithoutNewTicketGivenUnknownAppendAfterIssueCommitted()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);
        Assert.True((await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var acquired = await fixture.AcquireAsync(request);

        // Act
        await Assert.ThrowsAsync<TimeoutException>(async () => await fixture.GrantHandler(new CommitThenTimeoutExecutor(fixture.Executor))
            .HandleAsync(fixture.Context(acquired.Command), CancellationToken.None));
        var replay = await fixture.GrantHandler().HandleAsync(fixture.Context(acquired.Command), CancellationToken.None);
        var recovered = await fixture.DriveAsync(request);

        // Assert
        Assert.IsType<ReceiverOutcome.Replayed>(replay.Value);
        Assert.Equal(ProcessState.Completed, recovered.State);
        Assert.Equal(1, fixture.Artifacts.Issues);
        Assert.False((await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId))).Uses.HasActiveUse);
    }

    [Fact]
    public async Task ShouldPreserveWinningOriginalGivenConcurrentEqualEncryptedCandidates()
    {
        // Arrange
        await using var fixture = new Fixture();
        fixture.Artifacts.UniqueTickets = true;
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId, "Audit review", 2);
        Assert.True((await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var acquired = await fixture.AcquireAsync(request);
        var both = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var candidates = 0;
        fixture.Protected.AfterWrite = async () =>
        {
            if (Interlocked.Increment(ref candidates) == 2)
                both.SetResult();
            await both.Task.WaitAsync(TimeSpan.FromSeconds(10));
        };

        // Act
        var outcomes = await Task.WhenAll(fixture.GrantHandler().HandleAsync(fixture.Context(acquired.Command), CancellationToken.None).AsTask(),
            fixture.GrantHandler().HandleAsync(fixture.Context(acquired.Command), CancellationToken.None).AsTask());
        var original = await fixture.ResultReader().ReadAsync(fixture.Context(request), fixture.TenantId, artifactId, request.CommandId, CancellationToken.None);
        fixture.Clock.UtcNow = Now.AddHours(1);
        var repeated = await fixture.ResultReader().ReadAsync(fixture.Context(request), fixture.TenantId, artifactId, request.CommandId, CancellationToken.None);

        // Assert
        Assert.All(outcomes, outcome => Assert.True(outcome.IsSuccess, outcome.Error?.Message));
        Assert.Single(outcomes.Where(outcome => outcome.Value is ReceiverOutcome.Applied));
        Assert.Single(outcomes.Where(outcome => outcome.Value is ReceiverOutcome.Replayed));
        Assert.Equal(2, fixture.Artifacts.Issues);
        Assert.True(original.IsSuccess, original.Error?.Message);
        Assert.Equal(original.Value, repeated.Value);
        Assert.Contains(original.Value.Location.OriginalString, new[] { "https://content.example.test/secret-ticket-1", "https://content.example.test/secret-ticket-2" });
    }

    [Fact]
    public async Task ShouldFenceDelayedIssueBeforeSettlingUsesGivenSourceExpiresAfterAcquisition()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifactId = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var selected = AdvisorRecordVersion.EvidenceArtifact(artifactId, 2, 2, new string('a', 64), Uuid.CreateVersion4());
        var request = await fixture.AdvisorRequestAsync(artifactId, selected);
        var access = new EvidenceArtifactDownloadAccess(new FixedArtifactPermission(false), new FixedAdvisorSourceAuthorization(true), new FixedCurrentSourceResolver());
        Assert.True((await fixture.Handler(access).HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var acquired = await fixture.AcquireAsync(request);
        fixture.Clock.UtcNow = new DateTimeOffset(Now.UtcDateTime.Date.AddDays(1), TimeSpan.Zero);
        await fixture.Services.GetRequiredService<ProcessDriver>().AbortAsync(acquired.Record.Key);

        // Act
        var aborted = await fixture.DriveAsync(request);
        var delayed = await fixture.GrantHandler().HandleAsync(fixture.Context(acquired.Command), CancellationToken.None);
        var grant = await fixture.Reader.HydrateAsync(new ArtifactDownloadGrant(fixture.TenantId, request.CommandId));
        var artifact = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));
        var handoff = await fixture.Reader.HydrateAsync(new AdvisorHandoff(fixture.TenantId, request.ProgramId!.Value, request.AdvisorHandoffId!.Value));
        var policy = await fixture.Reader.HydrateAsync(new EvidenceHandlingPolicy(fixture.TenantId, artifactId));

        // Assert
        Assert.Equal(ProcessState.Aborted, aborted.State);
        Assert.NotNull(grant.Canceled);
        Assert.Null(grant.Issued);
        Assert.IsType<ReceiverOutcome.Rejected>(delayed.Value);
        Assert.False(artifact.Uses.HasActiveUse);
        Assert.False(handoff.Uses.HasActiveUse);
        Assert.False(policy.Uses.HasActiveUse);
        Assert.Equal(0, fixture.Artifacts.Issues);
    }

    sealed class CommitThenTimeoutExecutor(IAggregateExecutor inner) : IAggregateExecutor
    {
        public ValueTask<Result> ExecuteAsync<TAggregate>(TAggregate aggregate, Func<TAggregate, AggregateOutcome> operation,
            IExecutionContext context, CancellationToken ct) where TAggregate : Aggregate => inner.ExecuteAsync(aggregate, operation, context, ct);
        public async ValueTask<Result<T>> ExecuteAsync<TAggregate, T>(TAggregate aggregate, Func<TAggregate, AggregateOutcome<T>> operation,
            IExecutionContext context, CancellationToken ct) where TAggregate : Aggregate
        {
            _ = await inner.ExecuteAsync(aggregate, operation, context, ct);
            throw new TimeoutException("The append response was lost after commit.");
        }
    }

    sealed class RecordingContentStore(IImmutableContentStore inner) : IImmutableContentStore
    {
        readonly List<byte[]> _writes = [];
        public IReadOnlyList<byte[]> Writes { get { lock (_writes) return _writes.ToArray(); } }
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default)
        {
            lock (_writes) _writes.Add(bytes.ToArray());
            return inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        }
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default) =>
            inner.ReadVerifiedAsync(realm, reference, ct);
    }

    sealed class CountingProtectedStore(IProtectedResponseContentStore inner) : IProtectedResponseContentStore
    {
        public int Reads { get; private set; }
        public bool FailNextWriteAfterPublication { get; set; }
        public Func<Task>? AfterWrite { get; set; }
        public void RequireConfigured() => inner.RequireConfigured();
        public async Task<ProtectedResponseContentRef> WriteVerifiedAsync(ProtectedResponseScope scope, string schema,
            ReadOnlyMemory<byte> plaintext, CancellationToken ct = default)
        {
            var reference = await inner.WriteVerifiedAsync(scope, schema, plaintext, ct);
            if (FailNextWriteAfterPublication)
            {
                FailNextWriteAfterPublication = false;
                throw new IOException("The worker stopped after publishing encrypted candidate content.");
            }
            if (AfterWrite is { } wait)
                await wait();
            return reference;
        }
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(ProtectedResponseScope scope, ProtectedResponseContentRef reference, CancellationToken ct = default)
        {
            Reads++;
            return inner.ReadVerifiedAsync(scope, reference, ct);
        }
    }

    sealed class CountingArtifactStore(IArtifactContentStore inner, TimeProvider clock) : IArtifactContentStore
    {
        int _issues;
        public int Issues => _issues;
        public bool UniqueTickets { get; set; }
        public ValueTask<ArtifactDelivery?> IssueDeliveryAsync(ArtifactContentReference content, TimeSpan lifetime, CancellationToken ct = default)
        {
            var issued = Interlocked.Increment(ref _issues);
            return UniqueTickets ? ValueTask.FromResult<ArtifactDelivery?>(new ArtifactDelivery(content,
                new Uri($"https://content.example.test/secret-ticket-{issued}"), clock.GetUtcNow() + lifetime)) : inner.IssueDeliveryAsync(content, lifetime, ct);
        }
        public ValueTask<ArtifactContentWrite> StoreIfAbsentAsync(Uuid tenantId, Stream content, CancellationToken ct = default) => inner.StoreIfAbsentAsync(tenantId, content, ct);
        public ValueTask<Stream?> OpenVerifiedAsync(ArtifactContentReference content, CancellationToken ct = default) => inner.OpenVerifiedAsync(content, ct);
        public ValueTask<bool> PlaceHoldAsync(ArtifactContentReference content, Uuid holdId, CancellationToken ct = default) => inner.PlaceHoldAsync(content, holdId, ct);
        public ValueTask<bool> RemoveHoldAsync(ArtifactContentReference content, Uuid holdId, CancellationToken ct = default) => inner.RemoveHoldAsync(content, holdId, ct);
        public ValueTask<bool> QuarantineAsync(ArtifactContentReference content, CancellationToken ct = default) => inner.QuarantineAsync(content, ct);
        public ValueTask<bool> ReleaseQuarantineAsync(ArtifactContentReference content, CancellationToken ct = default) => inner.ReleaseQuarantineAsync(content, ct);
        public ValueTask<Stream?> OpenQuarantinedAsync(ArtifactContentReference content, CancellationToken ct = default) => inner.OpenQuarantinedAsync(content, ct);
        public ValueTask<ArtifactDeletionResult> DeleteAsync(ArtifactContentReference content, CancellationToken ct = default) => inner.DeleteAsync(content, ct);
    }
}
''')
p=root/'work/test/Compliance.Tests/Features/Evidence/IssueArtifactDownloadHandlerTests.cs';p.write_text(p.read_text().replace('nameof(MarkAdvisorHandoffReady)', 'nameof(MarkAdvisorHandoffReadyForReview)'))
