from prep_common import *
core='src/Compliance.Core/Features/Evidence/'
p=root/'work/src/Compliance.Common/Features/Evidence/CancelProtectedArtifactDownloadGrant.cs';s=p.read_text().replace('Uuid CommandId, Uuid GrantId','Uuid CommandId, EventStreamAddress Target, Uuid GrantId');p.write_text(s)
p=root/'work'/core/'ArtifactDownloadFailureProof.cs';s=p.read_text().replace('    DateTimeOffset DecisionAt)', '    DateTimeOffset DecisionAt, ImmutableContentRef? TicketObservation)');p.write_text(s)
put(core+'ArtifactDownloadTicketObservation.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>A bounded verified adapter refusal, with no raw URL, exception message or capability token.</summary>
public sealed record ArtifactDownloadTicketObservation(NativeFactReference Admission, ImmutableContentRef Intent,
    Uuid IssueCommandId, string Reason)
{
    public const string Schema = "artifact-download-ticket-observation.v1";
}
''')
put(core+'ArtifactDownloadIssueProofs.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>All source uses must still be held, content-bound and temporally valid at the irreversible decision.</summary>
public sealed class ArtifactDownloadIssueProofs(IAggregateReader reader, IImmutableContentStore content,
    ArtifactDownloadSourceVerifier verifier)
{
    public async Task<Result> VerifyAsync(VerifiedArtifactDownload download, ImmutableContentRef proofs,
        DateTimeOffset decisionAt, CancellationToken ct)
    {
        var intent = download.Intent;
        if (decisionAt < intent.Header.AcceptedAt)
            return Invalid("The grant decision predates its accepted request.");
        var tenant = Uuid.Parse(intent.Header.FirstOwner.Realm, CultureInfo.InvariantCulture);
        var artifact = await reader.HydrateAsync(new EvidenceArtifact(tenant, intent.ArtifactId), ct).ConfigureAwait(false);
        var availability = artifact.Uses.Find(ArtifactDownloadProtocol.Key(intent, artifact.Stream));
        if (availability is not { IsActive: true } || availability.GrantFact is not EvidenceArtifactDownloadRequested fact ||
            fact.Metadata.EventId != download.Admission.Metadata.EventId || artifact.State != EvidenceArtifactStates.Available ||
            artifact.ContentSha256 != intent.ContentSha256 || artifact.ContentLength != intent.ContentLength ||
            artifact.Revision != (long)intent.ArtifactRevision)
            return Invalid("The exact admitted artifact availability is no longer held.");
        var grants = await ArtifactDownloadProtocol.ReadAsync<IReadOnlyList<NativeFactReference>>(content,
            artifact.Stream.Realm, proofs, ArtifactDownloadProtocol.ProofsSchema, ct).ConfigureAwait(false);
        if (grants.Count != download.Requirements.Count || grants.Select(grant => grant.Stream).Distinct().Count() != grants.Count ||
            !grants.Select(grant => grant.Stream.ToString()).SequenceEqual(download.Requirements.Select(row => row.SourceOwner.ToString())))
            return Invalid("The grant does not contain the complete canonically ordered required source proofs.");
        foreach (var requirement in download.Requirements)
        {
            var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
            if (facts.ValidUntil is { } until && decisionAt >= until)
                return Invalid("A required source expired before the irreversible download decision.");
            ISourceUseOwner source;
            if (facts.Kind == "handling")
            {
                var policy = await reader.HydrateAsync(new EvidenceHandlingPolicy(tenant, intent.ArtifactId), ct).ConfigureAwait(false);
                if (!ArtifactDownloadUsePins.Policy(policy, requirement))
                    return Invalid("The held handling source changed before the irreversible decision.");
                source = policy;
            }
            else
            {
                var handoff = await reader.HydrateAsync(new AdvisorHandoff(tenant, intent.ProgramId!.Value, intent.AdvisorHandoffId!.Value), ct)
                    .ConfigureAwait(false);
                if (!ArtifactDownloadUsePins.Handoff(handoff, requirement) || handoff.ProgramId != intent.ProgramId ||
                    handoff.SelectionManifest != facts.Selection)
                    return Invalid("The held selected handoff source changed before the irreversible decision.");
                source = handoff;
            }
            var held = source.Uses.Find(ArtifactDownloadProtocol.Key(intent, requirement.SourceOwner));
            var expected = grants.Single(grant => grant.Stream == requirement.SourceOwner);
            if (held is not { IsActive: true, GrantFact: ISourceUseFact granted } ||
                NativeFactReference.Of(requirement.SourceOwner, held.GrantFact) != expected ||
                granted.Operation.RootOperationId != intent.GrantId || granted.Operation.FirstOwner != intent.Header.FirstOwner ||
                granted.Generation != ArtifactDownloadProtocol.Generation)
                return Invalid("An exact required source authorization is not held for this operation.");
            var use = await ArtifactDownloadProtocol.ReadAsync<SourceUseAuthorizationIntent>(content, source.Stream.Realm,
                granted.Intent, SourceUseAuthorizationIntent.Schema, ct).ConfigureAwait(false);
            if (use.Header != intent.Header || use.ParentIntent != download.Reference || use.Requirement != requirement ||
                use.Reservation != ArtifactDownloadProtocol.Key(intent, source.Stream) || use.Grant is not null || use.Disposition is not null)
                return Invalid("A source authorization does not bind the exact frozen requirement and root.");
        }
        return Result.Success;
    }

    static Result Invalid(string message) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message));
}
''')
put(core+'IssueProtectedArtifactDownloadGrantHandler.cs','''using System.Globalization;
using System.Text.Json;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Publishes one verified protected original result before appending the irreversible native grant.</summary>
public sealed class IssueProtectedArtifactDownloadGrantHandler(IAggregateReader reader, ReceiverAppend append,
    ArtifactDownloadSourceVerifier verifier, ArtifactDownloadIssueProofs sourceUses, IArtifactContentStore artifacts,
    IImmutableContentStore content, IProtectedResponseContentStore protectedContent, TimeProvider clock)
    : IRequestHandler<IssueProtectedArtifactDownloadGrant, ReceiverOutcome>
{
    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<IssueProtectedArtifactDownloadGrant> context, CancellationToken ct)
    {
        var command = context.Request;
        if (command.CommandId == Uuid.Empty || command.GrantId != command.OperationId || command.ExpectedRevision is not (null or 0) ||
            !Uuid.TryParse(command.Target.Realm, CultureInfo.InvariantCulture, out var tenant) ||
            command.Target != new ArtifactDownloadGrant(tenant, command.GrantId).Stream)
            return ReceiverAppend.Invalid("The protected grant names another owner, operation or revision.");
        try
        {
            var download = await verifier.AdmissionAsync(command.Source, command.Intent, command.OperationId, command.ArtifactId,
                command.Generation, ct).ConfigureAwait(false);
            var intent = download.Intent;
            if (command.CommandId != EffectIdentity.CommandId(command.Source.EventId,
                    $"{ArtifactDownloadProcess.Name}:{nameof(IssueProtectedArtifactDownloadGrant)}", command.Target.ToString(), intent.Header.Episode))
                return ReceiverAppend.Invalid("The protected grant differs from its exact source effect key.");
            var decisionAt = clock.GetUtcNow();
            var operation = SourceUseReceiverSupport.Child(command.CommandId, nameof(IssueProtectedArtifactDownloadGrant),
                command.Source.EventId, intent.Header, command.Target, decisionAt);
            var binding = AcceptedOperationBinding.Of(operation);
            var current = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), ct).ConfigureAwait(false);
            if (Decide(current, binding) is { } existing)
                return existing;
            var authorized = await sourceUses.VerifyAsync(download, command.AuthorizationProofs, decisionAt, ct).ConfigureAwait(false);
            if (!authorized.IsSuccess)
            {
                current = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), ct).ConfigureAwait(false);
                return Decide(current, binding) ?? ReceiverAppend.Rejected(authorized.Error!.Message);
            }
            var identity = new ArtifactContentReference(tenant, intent.ContentSha256, intent.ContentLength);
            var ticket = await artifacts.IssueDeliveryAsync(identity, intent.MaxDeliveryLifetime, ct).ConfigureAwait(false);
            if (ticket is null)
                return ReceiverAppend.Wait("The pinned artifact bytes are not available yet.");
            if (!Valid(ticket, identity, decisionAt, intent.MaxDeliveryLifetime))
            {
                var observation = TicketObservation(download, command.CommandId);
                _ = await content.WriteJsonAsync(command.Target.Realm, TicketObservationId(command.CommandId),
                    ArtifactDownloadTicketObservation.Schema, observation, ct).ConfigureAwait(false);
                return ReceiverAppend.Rejected("The bounded ticket adapter returned an invalid outcome.");
            }
            var link = new EvidenceArtifactDownloadLink(ticket.Location, ticket.ExpiresAt);
            var plaintext = JsonSerializer.SerializeToUtf8Bytes(link, ComplianceCoreJsonContext.Default.EvidenceArtifactDownloadLink);
            var encrypted = await protectedContent.WriteVerifiedAsync(ArtifactDownloadProtocol.Scope(intent), ArtifactDownloadProtocol.LinkSchema,
                plaintext, ct).ConfigureAwait(false);
            var result = new MutationResultContent(ArtifactDownloadProtocol.LinkSchema, new ProtectedResponseBody(encrypted));
            var frozenResult = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion4(), ArtifactDownloadProtocol.MutationResultSchema,
                result, ct).ConfigureAwait(false);
            var verified = await ArtifactDownloadProtocol.ReadAsync<MutationResultContent>(content, command.Target.Realm, frozenResult,
                ArtifactDownloadProtocol.MutationResultSchema, ct).ConfigureAwait(false);
            if (verified != result)
                return ReceiverAppend.Invalid("The opaque protected result descriptor did not verify.");
            return await append.ApplyAsync(() => new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), owner => owner.Acceptance,
                binding, owner => owner.Canceled is not null ? ReceiverAppend.Rejected("The receiving grant is canceled; its source uses must settle.")
                    : owner.Issued is not null ? ReceiverAppend.Invalid("The grant was issued by another effect.") : null,
                owner => owner.Issue(operation, intent, command.Intent, command.AuthorizationProofs, decisionAt, frozenResult), context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException)
        {
            return ReceiverAppend.Wait("The exact protected grant content is not available yet.");
        }
        catch (ImmutableContentIntegrityException)
        {
            return ReceiverAppend.Invalid("The exact protected grant content cannot be verified.");
        }
        catch (SourceFactVerificationException)
        {
            return ReceiverAppend.Invalid("The native download source proof cannot be verified.");
        }
    }

    internal static ArtifactDownloadTicketObservation TicketObservation(VerifiedArtifactDownload download, Uuid commandId) =>
        new(NativeFactReference.Of(download.Admission.Owner, download.Admission), download.Reference, commandId, ArtifactDownloadFailureProof.TicketInvalid);
    internal static Uuid TicketObservationId(Uuid commandId) => Uuid.CreateVersion5(commandId, ArtifactDownloadTicketObservation.Schema);

    static Result<ReceiverOutcome>? Decide(ArtifactDownloadGrant owner, AcceptedOperationBinding binding) => owner.Acceptance.Decide(binding) switch
    {
        NativeAcceptanceDecision.Replayed => SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, owner.Acceptance.SelectedFact!)),
        NativeAcceptanceDecision.Conflict => ReceiverAppend.Invalid("The grant effect identity was reused with changed intent."),
        _ => owner.Canceled is not null ? ReceiverAppend.Rejected("The receiving grant is canceled; its source uses must settle.") : null,
    };

    static bool Valid(ArtifactDelivery ticket, ArtifactContentReference identity, DateTimeOffset decisionAt, TimeSpan maximum) =>
        ticket.Content == identity && ticket.Location is { IsAbsoluteUri: true } && ticket.Location.OriginalString.Length <= 8192 &&
        (ticket.Location.Scheme == Uri.UriSchemeHttps && ticket.Location.UserInfo.Length == 0 ||
            ticket.Location.OriginalString.StartsWith("urn:bdgrz:artifact-delivery:", StringComparison.Ordinal)) &&
        ticket.ExpiresAt > decisionAt && ticket.ExpiresAt <= decisionAt + maximum;
}
''')
