import difflib,hashlib,json
from pathlib import Path
root=Path('/tmp/compliance-protected-download-prepared')
files=sorted(p.relative_to(root/'work').as_posix() for p in (root/'work').rglob('*') if p.is_file())
for name,pred in [('store-tests.patch',lambda p:p.startswith('test/')),('store-implementation.patch',lambda p:p.startswith('src/'))]:
 out=[]
 for f in files:
  if not pred(f):continue
  b=root/'base'/f;w=root/'work'/f
  old=b.read_text().splitlines(keepends=True) if b.exists() else []
  out.extend(difflib.unified_diff(old,w.read_text().splitlines(keepends=True),fromfile='a/'+f if b.exists() else '/dev/null',tofile='b/'+f))
 (root/name).write_text(''.join(out))
(root/'store-manifest.json').write_text(json.dumps({'scope':'AES protected response store only; protocol follow-on pending','validation':'Tree-sitter syntax clean; no build or runtime test run','files':[{'path':f,'sha256':hashlib.sha256((root/'work'/f).read_bytes()).hexdigest()}for f in files]},indent=2)+'\n')
