from prep_common import *
core='src/Compliance.Core/Features/Evidence/'
put(core+'ArtifactDownloadCancellationProofs.cs','''using System.Globalization;
using System.Text.Json;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Cancellation requires a concrete immutable source mismatch/expiry or verified adapter refusal.</summary>
public sealed class ArtifactDownloadCancellationProofs(IAggregateReader reader, IImmutableContentStore content,
    ArtifactDownloadSourceVerifier verifier)
{
    public async Task<bool> IsProvenAsync(VerifiedArtifactDownload download, ArtifactDownloadFailureProof failure,
        DateTimeOffset now, CancellationToken ct)
    {
        var intent = download.Intent;
        if (failure.GrantId != intent.GrantId || failure.Generation != ArtifactDownloadProtocol.Generation ||
            failure.Intent != download.Reference || failure.Admission != NativeFactReference.Of(download.Admission.Owner, download.Admission) ||
            failure.DecisionAt < intent.Header.AcceptedAt || failure.DecisionAt > now)
            return false;
        if (failure.Reason == ArtifactDownloadFailureProof.TicketInvalid)
        {
            if (failure.SourceOwner is not null || failure.TicketObservation is not { } reference)
                return false;
            var target = new ArtifactDownloadGrant(Uuid.Parse(intent.Header.FirstOwner.Realm, CultureInfo.InvariantCulture), intent.GrantId).Stream;
            var commandId = EffectIdentity.CommandId(download.Admission.Metadata.EventId,
                $"{ArtifactDownloadProcess.Name}:{nameof(IssueProtectedArtifactDownloadGrant)}", target.ToString(), intent.Header.Episode);
            var expected = IssueProtectedArtifactDownloadGrantHandler.TicketObservation(download, commandId);
            if (reference != TicketReference(expected))
                return false;
            var observed = await ArtifactDownloadProtocol.ReadAsync<ArtifactDownloadTicketObservation>(content,
                target.Realm, reference, ArtifactDownloadTicketObservation.Schema, ct).ConfigureAwait(false);
            return observed == expected;
        }
        var requirement = download.Requirements.SingleOrDefault(row => row.SourceOwner == failure.SourceOwner);
        if (requirement is null || failure.TicketObservation is not null)
            return false;
        var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
        if (failure.Reason == ArtifactDownloadFailureProof.SourceExpired)
            return facts.ValidUntil is { } until && failure.DecisionAt >= until;
        if (failure.Reason != ArtifactDownloadFailureProof.SourceRevoked)
            return false;
        var tenant = Uuid.Parse(intent.Header.FirstOwner.Realm, CultureInfo.InvariantCulture);
        if (facts.Kind == "handling")
        {
            var policy = await reader.HydrateAsync(new EvidenceHandlingPolicy(tenant, intent.ArtifactId), ct).ConfigureAwait(false);
            return !ArtifactDownloadUsePins.Policy(policy, requirement);
        }
        var handoff = await reader.HydrateAsync(new AdvisorHandoff(tenant, intent.ProgramId!.Value, intent.AdvisorHandoffId!.Value), ct)
            .ConfigureAwait(false);
        return !ArtifactDownloadUsePins.Handoff(handoff, requirement);
    }

    public static ImmutableContentRef TicketReference(ArtifactDownloadTicketObservation value)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(value, ComplianceCoreJsonContext.Default.ArtifactDownloadTicketObservation);
        return new ImmutableContentRef(IssueProtectedArtifactDownloadGrantHandler.TicketObservationId(value.IssueCommandId),
            ContentDigest.Sha256(bytes), bytes.Length, ImmutableContentStoreExtensions.JsonMediaType, ArtifactDownloadTicketObservation.Schema);
    }
}
''')
put(core+'CancelProtectedArtifactDownloadGrantHandler.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Atomically fences a pre-issue receiving owner; a committed issue always recovers forward.</summary>
public sealed class CancelProtectedArtifactDownloadGrantHandler(IAggregateReader reader, ISourceFactResolver resolver,
    ReceiverAppend append, IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier,
    ArtifactDownloadCancellationProofs failures, TimeProvider clock)
    : IRequestHandler<CancelProtectedArtifactDownloadGrant, ReceiverOutcome>
{
    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<CancelProtectedArtifactDownloadGrant> context, CancellationToken ct)
    {
        var command = context.Request;
        if (command.CommandId == Uuid.Empty || command.GrantId != command.RootOperationId ||
            command.Generation != ArtifactDownloadProtocol.Generation ||
            !Uuid.TryParse(command.Target.Realm, CultureInfo.InvariantCulture, out var tenant) ||
            command.Target != new ArtifactDownloadGrant(tenant, command.GrantId).Stream)
            return ReceiverAppend.Invalid("The cancellation names another grant owner, root or generation.");
        try
        {
            var failure = await ArtifactDownloadProtocol.ReadAsync<ArtifactDownloadFailureProof>(content, command.Target.Realm,
                command.FailureProof, ArtifactDownloadFailureProof.Schema, ct).ConfigureAwait(false);
            if (failure.Admission.Stream.Realm != command.Target.Realm || failure.GrantId != command.GrantId ||
                failure.Generation != command.Generation || failure.Intent.Schema != EvidenceDownloadIntent.Schema)
                return ReceiverAppend.Invalid("The failure proof belongs to another grant, realm or generation.");
            var proven = await SourceFactProofs.BuildAsync<EvidenceArtifactDownloadRequested>(resolver, content,
                command.Target.Realm, failure.Admission, ct).ConfigureAwait(false);
            var frozen = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, command.Target.Realm,
                failure.Intent, EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
            var download = await verifier.AdmissionAsync(proven.Proof, failure.Intent, command.RootOperationId,
                frozen.ArtifactId, command.Generation, ct).ConfigureAwait(false);
            if (command.CommandId != EffectIdentity.CommandId(failure.Admission.EventId,
                    $"{ArtifactDownloadProcess.Name}:{nameof(CancelProtectedArtifactDownloadGrant)}", "-", frozen.Header.Episode))
                return ReceiverAppend.Invalid("The cancellation differs from its exact root effect key.");
            var operation = SourceUseReceiverSupport.Child(command.CommandId, nameof(CancelProtectedArtifactDownloadGrant),
                failure.Admission.EventId, frozen.Header, command.Target, clock.GetUtcNow());
            var current = await reader.HydrateAsync(new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), ct).ConfigureAwait(false);
            if (current.Issued is { } issued)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(current.Stream, issued));
            var binding = AcceptedOperationBinding.Of(operation);
            if (current.Acceptance.Decide(binding) == NativeAcceptanceDecision.Replayed)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(current.Stream, current.Acceptance.SelectedFact!));
            if (!await failures.IsProvenAsync(download, failure, clock.GetUtcNow(), ct).ConfigureAwait(false))
                return ReceiverAppend.Invalid("The cancellation does not prove an exact selected source failure or adapter refusal.");
            var error = new RequestError(RequestErrorKind.Conflict, "The protected artifact download was canceled before issuance.");
            var body = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion4(), "request-error.v1", error, ct).ConfigureAwait(false);
            var result = await content.WriteJsonAsync(command.Target.Realm, Uuid.CreateVersion4(), ArtifactDownloadProtocol.MutationResultSchema,
                new MutationResultContent("request-error.v1", new StandardResponseBody(body)), ct).ConfigureAwait(false);
            return await append.ApplyAsync(() => new ArtifactDownloadGrant(tenant, command.GrantId, command.CommandId), owner => owner.Acceptance,
                binding, owner => owner.Issued is { } winner
                    ? SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, winner)) : null,
                owner => owner.Cancel(operation, frozen, failure.Intent, command.FailureProof, result), context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException)
        {
            return ReceiverAppend.Wait("The exact cancellation authority is not available yet.");
        }
        catch (ImmutableContentIntegrityException)
        {
            return ReceiverAppend.Invalid("The exact cancellation authority cannot be verified.");
        }
        catch (SourceFactVerificationException)
        {
            return ReceiverAppend.Invalid("The cancellation admission proof cannot be verified.");
        }
    }
}
''')
put(core+'ArtifactDownloadResultReader.cs','''using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>First-owner-scoped internal read seam; bare-operation public routing remains a separate blocked contract.</summary>
sealed class ArtifactDownloadResultReader(IAggregateReader reader, EvidenceArtifactDownloadAccess access,
    EvidenceArtifactMetadataRead metadata, IImmutableContentStore content, IProtectedResponseContentStore protectedContent)
{
    public async ValueTask<Result<EvidenceArtifactDownloadLink>> ReadAsync(IRequestContext context, Uuid tenantId,
        Uuid artifactId, Uuid operationId, CancellationToken ct)
    {
        if (!IssueArtifactDownloadHandler.PersonalHttpActor(context.Actor, context.Invocation, tenantId, out var actor))
            return Missing();
        var artifact = await reader.HydrateAsync(new EvidenceArtifact(tenantId, artifactId), ct).ConfigureAwait(false);
        var admitted = artifact.DownloadFacts.OfType<EvidenceArtifactDownloadRequested>().SingleOrDefault(fact =>
            fact.Operation.RootOperationId == operationId);
        if (admitted is null || admitted.Operation.Actor.Kind != actor.Kind || admitted.Operation.Actor.Id != actor.Id)
            return Missing();
        try
        {
            var intent = await ArtifactDownloadProtocol.ReadAsync<EvidenceDownloadIntent>(content, tenantId.ToString(), admitted.Intent,
                EvidenceDownloadIntent.Schema, ct).ConfigureAwait(false);
            var authorized = await access.RequireAsync(context, tenantId, artifactId, intent.ProgramId, intent.AdvisorHandoffId,
                intent.SelectedSource, ct).ConfigureAwait(false);
            if (!authorized.IsSuccess)
                return Result<EvidenceArtifactDownloadLink>.Failure(authorized.Error!);
            var current = await metadata.GetAsync(tenantId, artifactId, ct).ConfigureAwait(false);
            if (!current.IsSuccess || current.Value.State != EvidenceArtifactStates.Available ||
                current.Value.ContentSha256 != intent.ContentSha256 || current.Value.ContentLength != intent.ContentLength)
                return Missing();
            var grant = await reader.HydrateAsync(new ArtifactDownloadGrant(tenantId, operationId), ct).ConfigureAwait(false);
            if (grant.Terminal is not INativeOperationFact terminal)
                return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The download remains pending.", true));
            var resultReference = grant.Issued?.OperationResult ?? grant.Canceled!.OperationResult!;
            var result = await ArtifactDownloadProtocol.ReadAsync<MutationResultContent>(content, tenantId.ToString(), resultReference,
                ArtifactDownloadProtocol.MutationResultSchema, ct).ConfigureAwait(false);
            if (grant.Canceled is not null)
            {
                if (result.Schema != "request-error.v1" || result.Value is not StandardResponseBody error)
                    throw new ImmutableContentIntegrityException("The canceled download does not carry its frozen error result.");
                return Result<EvidenceArtifactDownloadLink>.Failure(await ArtifactDownloadProtocol.ReadAsync<RequestError>(content,
                    tenantId.ToString(), error.Content, "request-error.v1", ct).ConfigureAwait(false));
            }
            if (grant.Issued!.Intent != admitted.Intent || terminal.Operation.RootOperationId != operationId ||
                terminal.Operation.FirstOwner != artifact.Stream || terminal.Operation.Actor != intent.Header.OriginalActor ||
                result.Schema != ArtifactDownloadProtocol.LinkSchema || result.Value is not ProtectedResponseBody secret)
                throw new ImmutableContentIntegrityException("The original download result differs from its admitted authority.");
            // Authorization and original actor matching precede this read. Expiry is intentionally not renewed or rejected.
            var bytes = await protectedContent.ReadVerifiedAsync(ArtifactDownloadProtocol.Scope(intent), secret.Content, ct).ConfigureAwait(false);
            var link = JsonSerializer.Deserialize(bytes.Span, ComplianceCoreJsonContext.Default.EvidenceArtifactDownloadLink)
                ?? throw new ImmutableContentIntegrityException("The protected original download result is absent.");
            return Result<EvidenceArtifactDownloadLink>.Success(link);
        }
        catch (ImmutableContentUnavailableException)
        {
            return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The original protected result is not available yet.", true));
        }
        catch (ImmutableContentIntegrityException)
        {
            return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The original protected result cannot be verified."));
        }
        catch (JsonException)
        {
            return Result<EvidenceArtifactDownloadLink>.Failure(new RequestError(RequestErrorKind.Conflict, "The original protected result is invalid."));
        }
    }

    static Result<EvidenceArtifactDownloadLink> Missing() => Result<EvidenceArtifactDownloadLink>.Failure(
        new RequestError(RequestErrorKind.NotFound, "The artifact download was not found or is no longer disclosed to this actor."));
}
''')
