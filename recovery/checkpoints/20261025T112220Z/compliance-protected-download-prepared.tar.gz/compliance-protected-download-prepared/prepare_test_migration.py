from prep_common import *
rel='test/Compliance.Tests/Features/Evidence/IssueArtifactDownloadHandlerTests.cs';p=copy(rel);s=p.read_text()
s='''using System.Text;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Bdgrz.Compliance.Hosting.Persistence;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz.Testing;
'''+s
s=s.replace('public sealed class IssueArtifactDownloadHandlerTests','public sealed partial class IssueArtifactDownloadHandlerTests')
s=s.replace('new IssueArtifactDownload(fixture.TenantId, artifactId,','new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId,')
s=s.replace('"Type I audit review");','"Type I audit review", 2);').replace('"Advisor review")','"Advisor review", 2)')
s=s.replace('''        var retained = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));
        var events = await fixture.ArtifactEventsAsync(artifactId);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(Now.AddMinutes(5), result.Value.ExpiresAt);
        Assert.StartsWith("urn:bdgrz:artifact-delivery:", result.Value.Location.ToString());
        Assert.Equal(3, retained.Revision);
        Assert.Equal(3UL, retained.CommittedStreamPosition);
        var issued = Assert.IsType<EvidenceArtifactDownloadIssued>(events[^1]);''','''        var completed = await fixture.DriveAsync(request);
        var retained = await fixture.Reader.HydrateAsync(new EvidenceArtifact(fixture.TenantId, artifactId));
        var grant = await fixture.Reader.HydrateAsync(new ArtifactDownloadGrant(fixture.TenantId, request.CommandId));
        var original = await fixture.ResultReader().ReadAsync(fixture.Context(request), fixture.TenantId, artifactId,
            request.CommandId, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(request.CommandId, result.Value.OperationId);
        Assert.Equal(ProcessState.Completed, completed.State);
        Assert.True(original.IsSuccess, original.Error?.Message);
        Assert.Equal(Now.AddMinutes(5), original.Value.ExpiresAt);
        Assert.StartsWith("urn:bdgrz:artifact-delivery:", original.Value.Location.ToString());
        Assert.Equal(2, retained.Revision);
        Assert.Equal(4UL, retained.CommittedStreamPosition);
        var issued = Assert.IsType<EvidenceArtifactDownloadIssued>(grant.Issued);''')
s=s.replace('''        var request = new IssueArtifactDownload(Uuid.CreateVersion4(), fixture.TenantId, artifactId,
            "Advisor review", 2)
        {
            ProgramId = Uuid.CreateVersion4(),
            AdvisorHandoffId = Uuid.CreateVersion4(),
            SelectedSource = selected,
        };''','''        var request = await fixture.AdvisorRequestAsync(artifactId, selected);''')
s=s.replace('        Assert.Equal(3, retained.Revision);','        Assert.Equal(2, retained.Revision);')
s=s.replace('''        public TimeProvider Clock { get; } = new FixedTimeProvider(Now);''','''        public FixedTimeProvider Clock { get; } = new(Now);
        public RecordingContentStore Content { get; }
        public CountingProtectedStore Protected { get; }
        public CountingArtifactStore Artifacts { get; }
        public IServiceProvider Services => _scope.ServiceProvider;''')
s=s.replace('''            services.AddPortia();
            _provider = services.BuildServiceProvider''','''            var kv = new PersistenceKvClient(new InMemoryKvClient());
            Content = new RecordingContentStore(new FitzKvImmutableContentStore(kv));
            Protected = new CountingProtectedStore(new AesProtectedResponseContentStore(Content,
                new ProtectedResponseKeyRing("test-key-v1", new Dictionary<string, byte[]> { ["test-key-v1"] = Enumerable.Repeat((byte)5, 32).ToArray() })));
            _store = new LocalArtifactContentStore(new ArtifactContentStoreOptions(_root, new byte[32],
                ArtifactContentLimits.MaxContentLength), Clock);
            Artifacts = new CountingArtifactStore(_store, Clock);
            services.AddSingleton<TimeProvider>(Clock);
            services.AddSingleton<IImmutableContentStore>(Content);
            services.AddSingleton<IProtectedResponseContentStore>(Protected);
            services.AddSingleton<IArtifactContentStore>(Artifacts);
            services.AddSingleton<IProcessRecordStore>(new FitzKvProcessRecordStore(kv));
            services.AddSingleton(ArtifactDownloadProcess.Definition());
            services.AddSingleton<ProcessCatalog>(provider => new ProcessCatalog(provider.GetServices<ProcessDefinition>()));
            services.AddScoped<ProcessDriver>();
            services.AddScoped<ReceiverAppend>();
            services.AddScoped<ArtifactDownloadSourceVerifier>();
            services.AddScoped<ArtifactDownloadCancellationProofs>();
            services.AddScoped<ArtifactDownloadIssueProofs>();
            services.AddScoped<AdvisorHandoffReader>();
            services.AddScoped<ISourceFactResolver>(provider => new EventStoreSourceFactResolver(provider.GetRequiredService<IDomainEventReader>()));
            services.AddPortia()
                .AddRequestHandler<AuthorizeArtifactHandlingDownloadUseHandler>()
                .AddRequestHandler<AuthorizeAdvisorArtifactDownloadUseHandler>()
                .AddRequestHandler<IssueProtectedArtifactDownloadGrantHandler>()
                .AddRequestHandler<CancelProtectedArtifactDownloadGrantHandler>()
                .AddRequestHandler<SettleArtifactHandlingDownloadUseHandler>()
                .AddRequestHandler<SettleAdvisorArtifactDownloadUseHandler>()
                .AddRequestHandler<SettleArtifactDownloadAvailabilityUseHandler>()
                .AddRequestAuthorizer<ArtifactDownloadReceiverAuthorizer>();
            _provider = services.BuildServiceProvider''')
s=s.replace('''            _store = new LocalArtifactContentStore(new ArtifactContentStoreOptions(_root, new byte[32],
                ArtifactContentLimits.MaxContentLength), Clock);
            Access =''','''            Access =''')
s=s.replace('''        public IssueArtifactDownloadHandler Handler(EvidenceArtifactDownloadAccess? access = null) => new(access ?? Access,
                new EvidenceArtifactMetadataRead(Reader, Events), _store, Executor, Clock);''','''        public IssueArtifactDownloadHandler Handler(EvidenceArtifactDownloadAccess? access = null) => new(access ?? Access,
            new EvidenceDownloadAdmission(Reader, Content, new AdvisorHandoffReader(Reader, Content), new EvidenceArtifactMetadataRead(Reader, Events)),
            new NativeOperationExecutor(Reader, Executor, Content), Content, Protected, Clock);

        public ArtifactDownloadResultReader ResultReader(EvidenceArtifactDownloadAccess? access = null) => new(Reader,
            access ?? Access, new EvidenceArtifactMetadataRead(Reader, Events), Content, Protected);

        public IssueProtectedArtifactDownloadGrantHandler GrantHandler(IAggregateExecutor? executor = null) => new(Reader,
            new ReceiverAppend(executor ?? Executor), Services.GetRequiredService<ArtifactDownloadSourceVerifier>(),
            Services.GetRequiredService<ArtifactDownloadIssueProofs>(), Artifacts, Content, Protected, Clock);

        public async Task<ProcessRecord> RecordAsync(IssueArtifactDownload request)
        {
            var artifact = await Reader.HydrateAsync(new EvidenceArtifact(TenantId, request.ArtifactId));
            var admitted = Assert.Single(artifact.DownloadFacts.OfType<EvidenceArtifactDownloadRequested>().Where(fact => fact.Operation.LogicalId == request.CommandId));
            var intent = await Content.ReadJsonAsync<EvidenceDownloadIntent>(TenantId.ToString(), admitted.Intent);
            var selected = await Content.ReadSelectionAsync<SourceUseRequirement>(TenantId.ToString(), intent.RequiredSourceUses);
            var source = NativeFactReference.Of(artifact.Stream, admitted);
            return await Services.GetRequiredService<IProcessRecordStore>().CreateIfAbsentAsync(ProcessRecord.Start(
                ProcessKey.ForRoot(ArtifactDownloadProcess.Name, request.CommandId, source), source, intent.Header.Episode, admitted.Intent,
                selected.Select(row => row.SourceOwner.ToString()).Append(artifact.Stream.ToString())
                    .Append(new ArtifactDownloadGrant(TenantId, request.CommandId).Stream.ToString()), Clock.GetUtcNow()));
        }

        public async Task<ProcessRecord> DriveAsync(IssueArtifactDownload request)
        {
            var record = await RecordAsync(request);
            return await Services.GetRequiredService<ProcessDriver>().RunAsync(record.Key, "download-test", new RequestDispatchContext(RequestActor.System));
        }

        public async Task<IRequest<ReceiverOutcome>?> StepAsync(ProcessRecord record, string stage, string receiver, string? target)
        {
            var id = EffectIdentity.CommandId(record.Source.EventId, $"{ArtifactDownloadProcess.Name}:{receiver}", target ?? "-", record.Episode);
            return await ArtifactDownloadProcess.Definition().CreateReceiver(new ProcessStep(record, stage, receiver, target, id), Services, CancellationToken.None);
        }

        public async Task<(ProcessRecord Record, IssueProtectedArtifactDownloadGrant Command)> AcquireAsync(IssueArtifactDownload request)
        {
            var record = await RecordAsync(request);
            foreach (var target in record.Targets)
            {
                foreach (var receiver in ArtifactDownloadProcess.Definition().Stages[0].Receivers)
                {
                    var command = await StepAsync(record, "acquire", receiver, target);
                    if (command is null)
                        continue;
                    var applied = await Services.GetRequiredService<IRequestBus>().SendAsync(command, new RequestDispatchContext(RequestActor.System));
                    Assert.True(applied.IsSuccess, applied.Error?.Message);
                    var fact = applied.Value switch
                    {
                        ReceiverOutcome.Applied added => added.Fact,
                        ReceiverOutcome.Replayed replay => replay.Fact,
                        _ => throw new InvalidOperationException("The test expected an acquired source use."),
                    };
                    record = record with { Facts = new Dictionary<string, NativeFactReference>(record.Facts, StringComparer.Ordinal)
                        { [ProcessRecord.FactKey(receiver, target)] = fact } };
                }
            }
            record = await Services.GetRequiredService<IProcessRecordStore>().ReplaceAsync(record with { StageIndex = 1 }, record.Version);
            var targetGrant = new ArtifactDownloadGrant(TenantId, request.CommandId).Stream.ToString();
            return (record, Assert.IsType<IssueProtectedArtifactDownloadGrant>(await StepAsync(record, "issue", nameof(IssueProtectedArtifactDownloadGrant), targetGrant)));
        }

        public async Task<IssueArtifactDownload> AdvisorRequestAsync(Uuid artifactId, AdvisorRecordVersion selected)
        {
            var program = Uuid.CreateVersion4();
            var id = Uuid.CreateVersion4();
            var handoff = new AdvisorHandoff(TenantId, program, id);
            var actor = ActorReference.ForMember(RbacIds.Member(TenantId, UserId), "Advisor manager");
            var manifest = await Content.WriteJsonAsync(TenantId.ToString(), Uuid.CreateVersion4(), "AdvisorHandoffCreated.RecordVersionsManifest.v1",
                (IReadOnlyList<AdvisorRecordVersion>)new[] { selected });
            var (response, result) = await NativeContent.FreezeUnitAsync(Content, TenantId);
            var frozen = await FirstResponses.FreezeAsync(Content, TenantId.ToString(), response);
            Assert.True(handoff.Create(RootOperation.Provenance(id, nameof(CreateAdvisorHandoff), handoff.Stream, actor, null,
                new string('a', 64), Clock.GetUtcNow()), manifest, "Advisor review", DateOnly.FromDateTime(Now.UtcDateTime), actor,
                Clock.GetUtcNow(), null, frozen, result).IsSuccess);
            await Writer.SaveAsync(handoff, new RequestDispatchContext(RequestActor.System));
            Assert.True(handoff.MarkReady(RootOperation.Provenance(Uuid.CreateVersion4(), nameof(MarkAdvisorHandoffReady), handoff.Stream,
                actor, handoff.Revision, new string('b', 64), Clock.GetUtcNow()), actor, Clock.GetUtcNow(), frozen, result).IsSuccess);
            await Writer.SaveAsync(handoff, new RequestDispatchContext(RequestActor.System));
            return new IssueArtifactDownload(Uuid.CreateVersion4(), TenantId, artifactId, "Advisor review", 2)
                { ProgramId = program, AdvisorHandoffId = id, SelectedSource = selected };
        }''')
s=s.replace('''    sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
    {
        public override DateTimeOffset GetUtcNow() => utcNow;
    }''','''    sealed class FixedTimeProvider(DateTimeOffset utcNow) : TimeProvider
    {
        public DateTimeOffset UtcNow { get; set; } = utcNow;
        public override DateTimeOffset GetUtcNow() => UtcNow;
    }''')
p.write_text(s)
