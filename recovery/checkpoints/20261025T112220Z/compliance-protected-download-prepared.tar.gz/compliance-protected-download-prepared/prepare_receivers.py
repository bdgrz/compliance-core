from prep_common import *
core='src/Compliance.Core/Features/Evidence/'
header='''using System.Globalization;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

'''
put(core+'ArtifactDownloadUsePins.cs',header+'''/// <summary>Source identity stays content-bound while reservation facts advance the physical stream.</summary>
static class ArtifactDownloadUsePins
{
    public static bool Policy(EvidenceHandlingPolicy owner, SourceUseRequirement requirement) =>
        requirement.SourceOwner == owner.Stream && requirement.ResourceRevision == (ulong)owner.Revision &&
        (owner.ContentFact is null ? requirement.ResourceRevision == 0 :
            NativeFactReference.Of(owner.Stream, owner.ContentFact) == requirement.ContentEvent);

    public static bool Handoff(AdvisorHandoff owner, SourceUseRequirement requirement)
    {
        var selected = owner.Facts.LastOrDefault(fact => fact is AdvisorHandoffCreated or AdvisorHandoffSelectionRevised);
        return owner.IsCreated && owner.Status == AdvisorHandoff.ReadyForReview && selected is not null &&
            requirement.SourceOwner == owner.Stream && NativeFactReference.Of(owner.Stream, selected) == requirement.ContentEvent;
    }

    public static async ValueTask<Result<SourceUseSource>> VerifyAsync(Func<Task<SourceUseSource>> verify)
    {
        try
        {
            return Result<SourceUseSource>.Success(await verify().ConfigureAwait(false));
        }
        catch (ImmutableContentUnavailableException)
        {
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict, "The exact download source content is not available yet.", true));
        }
        catch (SourceFactVerificationException)
        {
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict, "The native download source proof cannot be verified."));
        }
        catch (ImmutableContentIntegrityException)
        {
            return Result<SourceUseSource>.Failure(new RequestError(RequestErrorKind.Conflict, "The exact download source content cannot be verified."));
        }
    }
}
''')
put(core+'AuthorizeArtifactHandlingDownloadUseHandler.cs',header+'''/// <summary>Holds the exact applied classification, or the explicit immutable default version.</summary>
public sealed class AuthorizeArtifactHandlingDownloadUseHandler(IAggregateReader reader, IAggregateExecutor executor,
    IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier, TimeProvider clock)
    : AuthorizeSourceUseHandler<EvidenceHandlingPolicy, AuthorizeArtifactHandlingDownloadUse>(reader, executor, content, clock)
{
    protected override EvidenceHandlingPolicy Open(AuthorizeArtifactHandlingDownloadUse request, Uuid selectedCommandId) =>
        new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), request.ArtifactId, selectedCommandId);

    protected override ValueTask<Result<SourceUseSource>> VerifyAsync(AuthorizeArtifactHandlingDownloadUse request, CancellationToken ct) =>
        ArtifactDownloadUsePins.VerifyAsync(async () =>
        {
            var source = await verifier.AuthorizationAsync(request.Source, request.Intent, request.Target, request.OperationId,
                request.Generation, request.ArtifactId, nameof(AuthorizeArtifactHandlingDownloadUse), request.CommandId, ct).ConfigureAwait(false);
            var facts = await verifier.PinnedAsync(source.Requirement, ct).ConfigureAwait(false);
            if (request.ExpectedRevision is not null || facts.PolicyVersion != request.PolicyVersion || facts.Kind != "handling")
                throw new ImmutableContentIntegrityException("The download use names another exact policy version.");
            return source;
        });

    protected override async ValueTask<Result> VerifyPinnedAsync(EvidenceHandlingPolicy owner, SourceUseRequirement requirement, CancellationToken ct)
    {
        var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
        return IsPinned(owner, requirement) && (owner.Current is not { } current ||
            current.Source.ContentSha256 == facts.ContentSha256 && current.ContentLength == facts.ContentLength &&
            current.HandlingClass == facts.HandlingClass && current.PolicyVersion == facts.PolicyVersion)
            ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict, "The exact handling classification changed before acquisition."));
    }

    protected override bool IsPinned(EvidenceHandlingPolicy owner, SourceUseRequirement requirement) => ArtifactDownloadUsePins.Policy(owner, requirement);
    protected override Func<EvidenceHandlingPolicy, OperationProvenance, ImmutableContentRef, long, Result> GrantOperation() =>
        (EvidenceHandlingPolicy owner, OperationProvenance operation, ImmutableContentRef intent, long generation) => owner.GrantDownloadUse(operation, intent, generation);
    protected override ValueTask<Result<ReceiverOutcome>> RefuseAsync(AuthorizeArtifactHandlingDownloadUse request,
        SourceUseSource source, string reason, IExecutionContext context, CancellationToken ct) =>
        ValueTask.FromResult(ReceiverAppend.Rejected("The frozen handling source cannot grant this download use."));
}
''')
put(core+'AuthorizeAdvisorArtifactDownloadUseHandler.cs',header+'''/// <summary>Holds only an actually selected ready handoff source; ordinary members create no optional use.</summary>
public sealed class AuthorizeAdvisorArtifactDownloadUseHandler(IAggregateReader reader, IAggregateExecutor executor,
    IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier, AdvisorHandoffReader handoffs, TimeProvider clock)
    : AuthorizeSourceUseHandler<AdvisorHandoff, AuthorizeAdvisorArtifactDownloadUse>(reader, executor, content, clock)
{
    protected override AdvisorHandoff Open(AuthorizeAdvisorArtifactDownloadUse request, Uuid selectedCommandId) =>
        new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), Uuid.Empty, request.HandoffId, selectedCommandId);

    protected override ValueTask<Result<SourceUseSource>> VerifyAsync(AuthorizeAdvisorArtifactDownloadUse request, CancellationToken ct) =>
        ArtifactDownloadUsePins.VerifyAsync(async () =>
        {
            var source = await verifier.AuthorizationAsync(request.Source, request.Intent, request.Target, request.OperationId,
                request.Generation, request.ArtifactId, nameof(AuthorizeAdvisorArtifactDownloadUse), request.CommandId, ct).ConfigureAwait(false);
            var facts = await verifier.PinnedAsync(source.Requirement, ct).ConfigureAwait(false);
            if (request.ExpectedRevision is not null || facts.HandoffId != request.HandoffId || facts.SelectedSource != request.SelectedSource || facts.Kind != "handoff")
                throw new ImmutableContentIntegrityException("The use names another optional selected source.");
            return source;
        });

    protected override async ValueTask<Result> VerifyPinnedAsync(AdvisorHandoff owner, SourceUseRequirement requirement, CancellationToken ct)
    {
        var facts = await verifier.PinnedAsync(requirement, ct).ConfigureAwait(false);
        var snapshot = await handoffs.ReadAsync(owner, Uuid.Parse(owner.Stream.Realm, CultureInfo.InvariantCulture), ct).ConfigureAwait(false);
        return IsPinned(owner, requirement) && owner.ProgramId == facts.ProgramId && owner.SelectionManifest == facts.Selection &&
            facts.SelectedSource is { } selected && snapshot.Selection.Contains(selected) && facts.ValidUntil is { } until && clock.GetUtcNow() < until
            ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict, "The selected handoff source changed or expired before acquisition."));
    }

    protected override bool IsPinned(AdvisorHandoff owner, SourceUseRequirement requirement) => ArtifactDownloadUsePins.Handoff(owner, requirement);
    protected override Func<AdvisorHandoff, OperationProvenance, ImmutableContentRef, long, Result> GrantOperation() =>
        (AdvisorHandoff owner, OperationProvenance operation, ImmutableContentRef intent, long generation) => owner.GrantArtifactDownloadUse(operation, intent, generation);
    protected override ValueTask<Result<ReceiverOutcome>> RefuseAsync(AuthorizeAdvisorArtifactDownloadUse request,
        SourceUseSource source, string reason, IExecutionContext context, CancellationToken ct) =>
        ValueTask.FromResult(ReceiverAppend.Rejected("The frozen handoff source cannot grant this download use."));
}
''')
for name,owner,openexpr,method in [
 ('SettleAdvisorArtifactDownloadUse','AdvisorHandoff','new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), Uuid.Empty, Uuid.Parse(request.Target.Resource, CultureInfo.InvariantCulture), selectedCommandId)','SettleArtifactDownloadUse'),
 ('SettleArtifactHandlingDownloadUse','EvidenceHandlingPolicy','new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), request.ArtifactId, selectedCommandId)','SettleDownloadUse'),
 ('SettleArtifactDownloadAvailabilityUse','EvidenceArtifact','new(Uuid.Parse(request.Target.Realm, CultureInfo.InvariantCulture), request.ArtifactId, selectedCommandId)','SettleDownloadAvailability')]:
 put(core+name+'Handler.cs',header+f'''/// <summary>Releases this exact source only after its native grant or receiving cancellation fence.</summary>
public sealed class {name}Handler(IAggregateReader reader, IAggregateExecutor executor,
    IImmutableContentStore content, ArtifactDownloadSourceVerifier verifier, TimeProvider clock)
    : SettleSourceUseHandler<{owner}, {name}>(reader, executor, content, clock)
{{
    protected override {owner} Open({name} request, Uuid selectedCommandId) => {openexpr};
    protected override ValueTask<Result<SourceUseSource>> VerifyAsync({name} request, CancellationToken ct) =>
        ArtifactDownloadUsePins.VerifyAsync(() => verifier.SettlementAsync(request.Source, request.Intent, request.Target,
            request.OperationId, request.Generation, request.ArtifactId, nameof({name}), request.CommandId, ct));
    protected override Func<{owner}, OperationProvenance, ImmutableContentRef, long, Result> SettleOperation() =>
        ({owner} owner, OperationProvenance operation, ImmutableContentRef intent, long generation) => owner.{method}(operation, intent, generation);
}}
''')
