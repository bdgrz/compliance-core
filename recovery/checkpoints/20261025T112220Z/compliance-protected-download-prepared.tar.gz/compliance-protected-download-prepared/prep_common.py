from pathlib import Path
root=Path('/tmp/compliance-protected-download-prepared')
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def put(rel,s):
 p=root/'work'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 q=repo/rel;b=root/'base'/rel
 if q.exists() and not b.exists():b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(q.read_bytes())
 p.write_text(s)
def copy(rel):
 p=root/'work'/rel
 if not p.exists():put(rel,(repo/rel).read_text())
 return p
