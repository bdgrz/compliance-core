from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,re
p=Path('/tmp/compliance-import-source-prepared');base=p/'base';work=p/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
src=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')]
red={'test/Compliance.Tests/Features/Applications/ApplicationImportSourceNativeBoundaryTests.cs','test/Compliance.Tests/Features/Applications/ApplicationImportAcceptPreparationReplayTests.cs'}
arts={}
for name,selected in [('implementation.patch',src),('tests.patch',tests),('green-after-red.patch',[r for r in paths if r not in red]),('full.patch',paths)]:
 text=''
 for r in selected:
  b=base/r;f=work/r;text+=''.join(difflib.unified_diff(b.read_text().splitlines(True) if b.exists() else [],f.read_text().splitlines(True),fromfile='a/'+r if b.exists() else '/dev/null',tofile='b/'+r))
 f=p/name;f.write_text(text);arts[name]={'path':str(f),'sha256':sha(f)}
for name in ['behavioral-red.patch']:
 arts[name]={'path':str(p/name),'sha256':sha(p/name)}
checks=[]
for label,sequence in [('full',['full.patch']),('split',['tests.patch','implementation.patch']),('staged',['behavioral-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/label;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest)
 for patch in sequence:
  result=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,capture_output=True,text=True)
  assert result.returncode==0,result.stdout+result.stderr
 assert all(sha(dest/r)==sha(work/r) for r in paths),label
 checks.append({'sequence':sequence,'exact':True})
rows=[{'path':r,'before':sha(base/r),'after':sha(work/r),'mainMatchesBase':sha(repo/r)==sha(base/r)} for r in paths]
(p/'owned-paths.txt').write_text('\n'.join(paths)+'\n')
(p/'hashes.json').write_text(json.dumps(rows,indent=2)+'\n')
report={'status':'FROZEN source layer; Batch stage2 remains active','paths':rows,'artifacts':arts,'reconstruction':checks,
'prerequisites':['Current merged NativeOwnerHistory/source-fact proof foundation/generic native Prepare expected failure recovery','Production ISourceFactResolver and existing ApplicationImport registrations'],
'scope':'Compact ApplicationImportSource with one active and one selected historical batch slot; full transient source native/payload/physical prefix and publication order; installed hydration/finalized append gate; whole source claim/settle/fence/read and actual import/cancellation/query producers migrated. Source published claims require exact admitted plan and terminal publication plus verified complete rows. Current source-aware Accept/Correlate/Freeze preparations and content freezes run inside native Prepare with exact batch-cut certificates.',
'wire':'Source identity derivation, public request/result/route contracts, actual occupied event tags/versions, receipt semantics and target hold/effect protocol remain. Additive DI decorator and required IDomainEventReader/ISourceFactResolver constructor dependencies recorded in source and fixtures. No shared Program/JSON changes. Empty cancellation selections now each carry their real declared schema/order rather than sharing a mislabeled descriptor.',
'protocol':'Selected batch hydration preserves settled-before-admission fences and historical accepted effects without lifetime slots/published/facts maps. Full native history checks duplicate logical/batch grants/settlements, exclusive active claim, disposition and exact first-owner lineage. Publication history never follows the source latest pointer. Import reactors verify actual committed typed triggers at real physical offsets. Commit effect verification reads each exact hydrated target physical prefix including audits, matches actual stored event payload+full metadata, and never compares aggregate version as a physical offset. Missing content is pending/transient; corrupt content permanent.',
'qualification':'Normal existing source fact schemas are preserved and exact child lineage is required. No migration/dualread/bare lookup/legacy alias/permit invention. Parent owns central receiver-preparation recovery follow-on: source Claim/Release/Execute still perform trusted immutable verifier reads before their existing accepted receiver resolution; owning NativeOperation producer recovery is fixed here but does not claim every receiver preflight recovery fixed.',
'remaining':'ApplicationImportBatch itself is not bounded: repeated same-row corrections and renewed omission proposals append to retained _facts. This source layer does not claim Batch complete. Separate /tmp/compliance-import-batch-prepared contains genuine existing-API repeated-correlation RED for central execution; full compact Batch/history/producer/read migration follows immediately and will remove the temporary preparation-cut dependency on its existing Facts.',
'runtime':'No local .NET/build/test/Jev/broker/Git/GitHub operations. Root queued standalone OLD-API RED2:48 real canceled-before-admission source fences and equal Accept winner after losing frozen plan write becomes unavailable. Root additionally queued separate Batch repeated-correlation RED1. No green/runtime claim from static gates.',
'validation':'Full effective syntax93/explicit ctor15 and five targettyped Host constructor checks;78 original acceptance names/assert counts preserved; full/split/oldAPI-red-staged exact final hash reconstruction. New tests include middle payload/metadata substitution2, selected earlier fence plus other current active holder, publication missing/corrupt bytes2, forged same-native-identity source reaction. Parent owns central strict/focused/full/HTTP/Jev.',
'filters':['FullyQualifiedName~Features.Applications.ApplicationImport|FullyQualifiedName~DeclaredApplicationImportHoldTests|FullyQualifiedName~ApplicationPublicationCutTests'],
'sharedDeltas':['PersistenceServiceCollectionExtensions: add Applications import + ApplicationImportSourceAggregateReader decorator after existing decorators, preserving concurrent root wrappers.']}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'source':len(src),'tests':len(tests),'drift':[row['path'] for row in rows if not row['mainMatchesBase']],'artifacts':arts,'reconstruction':checks},indent=2))
