from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,sys
root=Path('/tmp/compliance-audit-population-native-prepared');work=root/'work';base=root/'base';release=root/'releases/001'
if release.exists():raise SystemExit('Release 001 exists; never rewrite immutable artifacts.')
release.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=[]
for p in sorted(work.rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(work));before=base/rel
 if before.exists() and before.read_bytes()==p.read_bytes():continue
 kind='production' if rel.startswith('src/') else ('tests' if rel.startswith('test/') else 'docs')
 changed.append({'path':rel,'beforeSha256':sha(before.read_bytes()) if before.exists() else None,'afterSha256':sha(p.read_bytes()),'kind':kind})
red={str(p.relative_to(root/'capacity-red')):p.read_bytes() for p in (root/'capacity-red').rglob('*.cs')}
seven={k:v for k,v in red.items() if not k.endswith('AuditPopulationCapacityTests.cs')}
def patch(entries,qualified=None):
 out=''
 for e in entries:
  rel=e['path'];old=qualified.get(rel) if qualified is not None and rel in qualified else ((base/rel).read_bytes() if (base/rel).exists() else None);new=(work/rel).read_bytes()
  if old==new:continue
  out+=''.join(difflib.unified_diff(old.decode().splitlines(True) if old is not None else [],new.decode().splitlines(True),fromfile='a/'+rel if old is not None else '/dev/null',tofile='b/'+rel))
 return out
spec=[('full.patch',changed,None),('implementation.patch',[e for e in changed if e['kind']!='tests'],None),('tests.patch',[e for e in changed if e['kind']=='tests'],None),('tests-from-qualified-red.patch',[e for e in changed if e['kind']=='tests'],red),('tests-from-qualified-seven.patch',[e for e in changed if e['kind']=='tests'],seven)]
for name,entries,q in spec:(release/name).write_text(patch(entries,q))
for e in changed:
 rel=e['path'];dst=release/'files'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(work/rel,dst)
 if (base/rel).exists():
  dst=release/'baseline'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/rel,dst)
 if rel in red:e['qualifiedRedBeforeSha256']=sha(red[rel])
(release/'production-files.txt').write_text(''.join(e['path']+'\n' for e in changed if e['kind']=='production'))
manifest={'release':1,'base':str(release/'baseline'),'work':str(release/'files'),'baselineDirectory':str(release/'baseline'),'afterDirectory':str(release/'files'),'sourceAuthority':'Exact before/after SHA256. Shared DI/JSON/Persistence and connected TypeII/Auditor hunks must preserve all unrelated current root layers/lifetimes.','runtimeExecutedByAgent':False,'files':changed,'filters':['FullyQualifiedName~AuditPopulation','FullyQualifiedName~SampleSelectionCommandHandlerTests|FullyQualifiedName~AuditorRequestTests|FullyQualifiedName~ObservationPeriodReadHandlerTests|FullyQualifiedName~TypeIIPeriodCommandHandlerTests'],'rootReportedQualification':{'nativeSeven':'All6 real public-handler exact Unit retries genuinely fail stale revision or append classification, plus24definition owner-retention failure. Initial RequestContext namespace CS1503 excluded; actual qualified test uses fully qualified SDK type. Archived recovery/audit-population-qualified-red.','capacityOne':'Genuine denial at definition59 from actual complete-state48KiB event payload bound during valid70-definition campaign. Does not reach explicitMaximumVersions64 cap. Archived recovery/person-client-audit-capacity-qualified-red.','oldAPIRedPatchSha256':sha((root/'old-api-red.patch').read_bytes()),'oldAPICapacityRedPatchSha256':sha((root/'old-api-capacity-red.patch').read_bytes())},'pendingSourceQualifiedFollowup':['DefineAuditPopulation','GenerateAuditPopulation','GenerateAuditPopulationExport'],'qualificationLimits':['No compiler,format,unit,HTTP,Jev,Git or deployment execution by this agent.','Six selected commands have native original Unit protocol; three adapted existing producers remain explicitly unqualified, not complete by signature/identity alone.','Manual source fields and upstream legacy fixture declarations are not external source authenticity. Actual predecessor and retained canonical TypeII close tuples/bodies are verified.','Existing16MiB complete-body/authored-command admission applies; no new history count cap or truncation. Explicit old inline versions retain original replay count checks.'],'patches':{name:sha((release/name).read_bytes()) for name,_,_ in spec}}
(release/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
results=[]
for scenario,patches,q in [('full',['full.patch'],None),('split',['implementation.patch','tests.patch'],None),('qualified-red',['implementation.patch','tests-from-qualified-red.patch'],red),('qualified-seven',['implementation.patch','tests-from-qualified-seven.patch'],seven)]:
 target=release/'reconstruction'/scenario;shutil.copytree(base,target)
 if q:
  for rel,b in q.items():
   p=target/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for name in patches:
  ran=subprocess.run(['patch','-p1','--batch','--forward','--input',str(release/name)],cwd=target,capture_output=True,text=True)
  if ran.returncode:raise SystemExit(f'{scenario} failed {name}: {ran.stdout}{ran.stderr}')
 mismatch=[e['path'] for e in changed if not (target/e['path']).exists() or sha((target/e['path']).read_bytes())!=e['afterSha256']]
 if mismatch:raise SystemExit(f'{scenario}: mismatch {mismatch}')
 results.append({'scenario':scenario,'filesVerified':len(changed),'matchedEveryAfterHash':True})
(release/'reconstruction-proof.json').write_text(json.dumps(results,indent=2)+'\n')
sys.path.insert(0,'/tmp/compliance-identity-recovery-native-prepared/static-parser')
from tree_sitter import Parser,Language
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));parse=[]
for e in changed:
 if not e['path'].endswith('.cs'):continue
 p=work/e['path'];t=parser.parse(p.read_bytes());b=base/e['path'];before_error=parser.parse(b.read_bytes()).root_node.has_error if b.exists() else False
 parse.append({'path':e['path'],'treeSitterHasError':t.root_node.has_error,'baselineTreeSitterHasError':before_error,'note':'Syntax inspection only; no C# type,analyzer or runtime claim.'})
(release/'static-syntax-inspection.json').write_text(json.dumps(parse,indent=2)+'\n')
print(json.dumps({'files':len(changed),'productionFiles':sum(e['kind']=='production' for e in changed),'testFiles':sum(e['kind']=='tests' for e in changed),'docsFiles':sum(e['kind']=='docs' for e in changed),'manifestSha256':sha((release/'manifest.json').read_bytes()),'patches':manifest['patches'],'reconstruction':results,'newSyntaxErrors':[e['path'] for e in parse if e['treeSitterHasError'] and not e['baselineTreeSitterHasError']]},indent=2))
