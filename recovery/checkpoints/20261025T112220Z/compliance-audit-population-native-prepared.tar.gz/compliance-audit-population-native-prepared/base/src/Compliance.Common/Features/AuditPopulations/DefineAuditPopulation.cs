using Bdgrz.Compliance.Features.Programs;
using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPopulations;

/// <summary>Defines a population against one exact frozen Type II period close.</summary>
[Discriminator("bdgrz.audit-populations.define-audit-population", 2)]
public sealed record DefineAuditPopulation(
    Uuid TenantId,
    Uuid ProgramId,
    Uuid DefinitionId,
    Uuid PeriodId,
    Uuid PeriodCloseId,
    AuditPopulationDefinitionContent Definition) : IRequest, IProgramScopedRequest, IClientManagementMutationRequest, ICallable;
