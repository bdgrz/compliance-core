using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Evidence;

/// <summary>Native personal approval of an exact preparation and observed available derivative.</summary>
[Discriminator("bdgrz.evidence.redaction.approved", 2)]
public sealed record EvidenceRedactionApprovedV2(Uuid TenantId, Uuid RedactionId, long ExpectedRevision,
    EvidenceRedactionApprovalFact Approval, OperationProvenance Operation, ImmutableContentRef SourceProofs,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult) : DomainEvent, INativeOperationFact;
