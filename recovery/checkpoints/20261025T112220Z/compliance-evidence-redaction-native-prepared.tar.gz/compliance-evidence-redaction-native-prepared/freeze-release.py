from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,sys
root=Path('/tmp/compliance-evidence-redaction-native-prepared');work=root/'work';base=root/'base';release=root/'releases/001'
if release.exists():raise SystemExit('Release 001 exists; never rewrite immutable artifacts.')
release.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=[]
for p in sorted(work.rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(work));before=base/rel
 if before.exists() and before.read_bytes()==p.read_bytes():continue
 kind='production' if rel.startswith('src/') else ('tests' if rel.startswith('test/') else 'docs')
 changed.append({'path':rel,'beforeSha256':sha(before.read_bytes()) if before.exists() else None,'afterSha256':sha(p.read_bytes()),'kind':kind})
red={str(p.relative_to(root/'red')):p.read_bytes() for p in (root/'red').rglob('*.cs')}
def patch(entries,qualified=False):
 out=''
 for e in entries:
  rel=e['path'];old=red.get(rel) if qualified and rel in red else ((base/rel).read_bytes() if (base/rel).exists() else None);new=(work/rel).read_bytes()
  if old==new:continue
  out+=''.join(difflib.unified_diff(old.decode().splitlines(True) if old is not None else [],new.decode().splitlines(True),fromfile='a/'+rel if old is not None else '/dev/null',tofile='b/'+rel))
 return out
for name,entries,q in [('full.patch',changed,False),('implementation.patch',[e for e in changed if e['kind']!='tests'],False),('tests.patch',[e for e in changed if e['kind']=='tests'],False),('tests-from-qualified-red.patch',[e for e in changed if e['kind']=='tests'],True)]:
 (release/name).write_text(patch(entries,q))
for e in changed:
 rel=e['path'];dst=release/'files'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(work/rel,dst)
 if (base/rel).exists():
  dst=release/'baseline'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/rel,dst)
 if rel in red:e['qualifiedRedBeforeSha256']=sha(red[rel])
(release/'production-files.txt').write_text(''.join(e['path']+'\n' for e in changed if e['kind']=='production'))
manifest={'release':1,'base':str(release/'baseline'),'work':str(release/'files'),'baselineDirectory':str(release/'baseline'),'afterDirectory':str(release/'files'),'sourceAuthority':'Exact before and after SHA256 bytes. Main source not modified by this agent. Shared DI/JSON/Persistence/Program hunks are narrow; preserve all unrelated root layers and reader lifetimes.','runtimeExecutedByAgent':False,'files':changed,'filters':['FullyQualifiedName~EvidenceRedaction&Category!=WebIntegration','FullyQualifiedName~EvidenceRedactionNativeHttpTests'],'rootReportedQualification':{'oldAPI4':'All four genuine failures with actual 100-preparation,24-owner-bound,original preparation and original approval targets; no compile/setup errors. Archived by root before production application.','redPatchSha256':sha((root/'old-api-red.patch').read_bytes())},'qualificationLimits':['All compilation,format,unit,HTTP,Jev,Git,merge and deployment gates remain root-owned.','Source facts are actual retained canonical metadata; synthetic inspector fixture does not prove byte transformation or malware scanner.','Existing 16MiB immutable body admission remains; no new count cap,truncation,segmented or unlimited response promise.','Occupied v1 retains original tags and unqualified replay; no old receipt is upgraded.'],'patches':{n:sha((release/n).read_bytes()) for n in ['full.patch','implementation.patch','tests.patch','tests-from-qualified-red.patch']}}
(release/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
results=[]
for scenario,patches,q in [('full',['full.patch'],False),('split',['implementation.patch','tests.patch'],False),('qualified-red',['implementation.patch','tests-from-qualified-red.patch'],True)]:
 target=release/'reconstruction'/scenario;shutil.copytree(base,target)
 if q:
  for rel,b in red.items():
   p=target/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 for name in patches:
  ran=subprocess.run(['patch','-p1','--batch','--forward','--input',str(release/name)],cwd=target,capture_output=True,text=True)
  if ran.returncode:raise SystemExit(f'{scenario} failed {name}: {ran.stdout}{ran.stderr}')
 mismatch=[e['path'] for e in changed if not (target/e['path']).exists() or sha((target/e['path']).read_bytes())!=e['afterSha256']]
 if mismatch:raise SystemExit(f'{scenario}: mismatch {mismatch}')
 results.append({'scenario':scenario,'filesVerified':len(changed),'matchedEveryAfterHash':True})
(release/'reconstruction-proof.json').write_text(json.dumps(results,indent=2)+'\n')
sys.path.insert(0,'/tmp/compliance-identity-recovery-native-prepared/static-parser')
from tree_sitter import Parser,Language
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()));parse=[]
for e in changed:
 if not e['path'].endswith('.cs'):continue
 p=work/e['path'];t=parser.parse(p.read_bytes());b=base/e['path'];before_error=parser.parse(b.read_bytes()).root_node.has_error if b.exists() else False
 parse.append({'path':e['path'],'treeSitterHasError':t.root_node.has_error,'baselineTreeSitterHasError':before_error,'note':'Syntax inspection only; no C# type,analyzer or runtime claim.'})
(release/'static-syntax-inspection.json').write_text(json.dumps(parse,indent=2)+'\n')
print(json.dumps({'files':len(changed),'productionFiles':sum(e['kind']=='production' for e in changed),'testFiles':sum(e['kind']=='tests' for e in changed),'docsFiles':sum(e['kind']=='docs' for e in changed),'manifestSha256':sha((release/'manifest.json').read_bytes()),'patches':manifest['patches'],'reconstruction':results,'newSyntaxErrors':[e['path'] for e in parse if e['treeSitterHasError'] and not e['baselineTreeSitterHasError']]},indent=2))
