# EvidenceRedaction native release 001

Immutable release: `/tmp/compliance-evidence-redaction-native-prepared/releases/001`.

Manifest SHA256: `72abc503e85174477bff20e11da842db0f1a69c34c76b42204bffed6f6c5cb7f`.

The manifest names exact physical before and after directories (`baseline` and `files`) and every changed file's before/after SHA256. New files have no before bytes. `full.patch`, `implementation.patch` plus `tests.patch`, and `implementation.patch` plus `tests-from-qualified-red.patch` reconstruct all30 after hashes, independently verified by package-local `patch` only. `reconstruction-proof.json` records those checks. Shared Program, JSON context, service registration and persistence hunks are narrow and must union with any later root changes; preserve every unrelated current reader wrapper and lifetime.

## Root-qualified old-API baseline

The immutable `/tmp/compliance-evidence-redaction-native-prepared/old-api-red.patch` SHA256 is `835ed59928a3a38d752617fc05e49b011b838e03ae698fb1221d8aec747d8810`. The root reported all four tests genuine failures with actual100-preparation/24-bounded-owner/original-preparation/original-approval targets and no compile/setup errors. Exact current source, tests, qualification and log were archived centrally at `recovery/evidence-initial-read-qualified-red` before production application. The old RED filter is `FullyQualifiedName~GivenNativeHistoryBoundary`. The `red` directory is immutable; the GREEN fixture adds typed required CommandIds and native source/result assertions.

## Implementation and source authority

- Required typed `CommandId`, `IIdentifiedRequest`, request version2 and PUT preparation/approval paths. Immediate result remains original complete `EvidenceRedactionView`200. Approval remains personal HTTP only. Current membership, fixed core permissions, historical Attest wall and both current artifact read permissions precede native original-result replay. Canonical actor and authored intent changes conflict; display changes retain original presentation.
- Compact owner: current preparation, current approval, one selected receipt or occupied legacy fact and constant-size exact payload/saved-metadata replay commitments. Complete historical rows live in a transient external snapshot. No history count cap, pruning, expiry, truncation or writer alias.
- Full production history validation uses installed `NativeOwnerHistory`, verifies all actual logical/physical facts and unique identities, source locators and exact payload+savedmetadata cut before both default and executor hydration. Native preparation/approval appended only at the exact finalized target selection/cut. Independent historical result/notice does not become current decision state.
- Actual scoped native source records provide registration event ids, payload hashes and resource offsets. Source proof builders use explicit observed `ResourceOffset`, never native-version-minus-one. Retained clean-inspection/quarantine-release availability is reverified. Approval proves the exact v1 or v2 preparation record and exact independently recorded+approved waiver source cut. Owners consume bounded waiver primitive values; live waiver eligibility/current permissions remain orchestration checks, including expiry at synchronous append after original response freezing.
- Existing inline occupied v1 facts and tags are unchanged. Production history reader checks their exact lineage/integrity and marks them unqualified legacy. Old retry ids cannot become native receipts; fresh typed native ids may follow a valid legacy prefix after actual current source/authority checks. No source hold, trusted cutover, privileged callback or cross-owner future atomicity is invented.
- Existing generic immutable body maximum16MiB remains. A prospective complete original response exceeding the installed `FitzKvImmutableContentStore.MaximumContentBytes` is deterministic Validation before append. Full history is never count-capped or truncated. No segmented/unlimited transport or deployment qualification is claimed.

## Fixtures and intentional assertion changes

Six test files include actual composed artifact registrations, inspection metadata, canonical tenant members, fixed roles, artifact grants, permission authorizers and source resolver. The native proof fault wrappers alter only immutable read/write behavior or clock; the equal-winner case commits a real public native command. Missing source manifest yields transient Conflict; corrupt source manifest yields permanent Conflict; requested cancellation propagates; expiry crossed while freezing original response cannot append approval. Two WebIntegration tests use real developer UserIdentity registration and developer-session cookies attached to already existing canonical members; no authentication/permission callback bypass is installed.

The old `ShouldPreserveBoundedHistoryAndAllowExactRetryGivenHistoryCapacity` method name is preserved, but its arbitrary100 denial expectation is intentionally superseded by101 actual native preparations, complete production history and original retry view. Legacy compatibility is exercised with immutable actual v1 fact shapes fed into the production v1/v2 history reader, never a copied test-only legacy writer.

The prior `ShouldReturnCurrentApprovalWithoutAppendGivenExactPreparationRetry` assertion contradicted the selected original-result contract. It is replaced by `ShouldReturnOriginalPreparationWithoutAppendGivenLaterApprovalAndExactPreparationRetry`, asserting the original preparation response while the real current owner keeps its later approval. Other existing behavioral names and source/permission assertions are preserved, with retained collections read through production full history.

## Gates and limits

This agent ran no .NET, Git, Jev, broker, delivery or deployment. Syntax inspection finds no new grammar errors versus baseline; shared Program/preprocessor and large JSON-context parser limitations remain present in baseline. It is not a compile or analyzer result.

Root gates: whitespace, strict Release build, focused `FullyQualifiedName~EvidenceRedaction&Category!=WebIntegration`, full backend unit suite, actual `FullyQualifiedName~EvidenceRedactionNativeHttpTests`, current-head source review and direct per-production-file Jev using `production-files.txt`. Scanner/provider/byte-transformation/disclosure qualification is outside this metadata lineage layer. Recorded source cuts are bounded observed-prefix proofs, not source holds or future atomicity guarantees.
