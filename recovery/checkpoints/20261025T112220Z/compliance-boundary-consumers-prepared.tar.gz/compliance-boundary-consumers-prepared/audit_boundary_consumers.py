from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,re,json,hashlib
r=Path('/tmp/compliance-boundary-consumers-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 pending=[n]
 while pending:
  node=pending.pop();yield node;pending.extend(reversed(node.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
def signature(t,n):
 ps=[x for x in n.children if x.type=='parameter'];return (sum('=' not in tx(t,x) for x in ps),len(ps))
def definitions(t):
 known={}
 for n in walk(parser.parse(t).root_node):
  if n.type not in {'class_declaration','record_declaration','struct_declaration'}:continue
  name=n.child_by_field_name('name');pl=next((x for x in n.children if x.type=='parameter_list'),None)
  if name is None:continue
  nm=tx(t,name)
  if pl:known.setdefault(nm,[]).append(signature(t,pl))
  body=n.child_by_field_name('body')
  for ch in body.children if body else []:
   if ch.type=='constructor_declaration':
    pl=next((x for x in ch.children if x.type=='parameter_list'),None)
    if pl:known.setdefault(nm,[]).append(signature(t,pl))
 return known
sources={}
for root in [repo,Path('/tmp/compliance-s32-commitment-prepared/after'),Path('/tmp/compliance-commitment-consumers-prepared/after'),Path('/tmp/compliance-s32-boundary-prepared/after'),r/'after']:
 for directory in ['src','test']:
  for f in (root/directory).rglob('*.cs'):
   if not {'bin','obj'}.intersection(f.parts):sources[str(f.relative_to(root))]=f
known={}
for p,f in sources.items():
 if p.startswith('src/') or '/Testing/' in p:
  raw=f.read_bytes()
  if re.search(rb'\b(?:class|record|struct)\s+(?:Boundary\w*|FitzBoundary\w*|SystemBoundary|WorkQueueReader|ScopeSnapshotFreezer|VerifyProgramScopeSnapshotHandler|ProfessionalAdvisoryReadAccess|EventSourcedServiceEngagementAcceptanceEvidenceReader|AuthorizeEngagementPracticeCommitmentsHandler|FitzApplicationBoundaryReferenceDirectory|AssignResponsibilityHandler|RevokeResponsibilityHandler)\b',raw):known.update(definitions(raw))
errors=[];syntax=[];checked=0;localResolved=0
selected={n for n in known if n.startswith(('Boundary','FitzBoundary'))}|{'SystemBoundary','WorkQueueReader','ScopeSnapshotFreezer','VerifyProgramScopeSnapshotHandler','ProfessionalAdvisoryReadAccess','EventSourcedServiceEngagementAcceptanceEvidenceReader','AuthorizeEngagementPracticeCommitmentsHandler','FitzApplicationBoundaryReferenceDirectory','AssignResponsibilityHandler','RevokeResponsibilityHandler'}
for p,f in sources.items():
 t=f.read_bytes()
 if not any(name.encode() in t for name in selected) and not f.is_relative_to(r/'after'):continue
 tree=parser.parse(t);local=definitions(t)
 if f.is_relative_to(r/'after') and tree.root_node.has_error:syntax.append(p)
 for n in walk(tree.root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((x for x in n.children if x.type=='argument_list'),None)
  if typ is None or args is None:continue
  name=tx(t,typ).split('.')[-1]
  if name not in selected or name not in known:continue
  count=sum(x.type=='argument' for x in args.children);checked+=1;expected=local.get(name,known[name])
  if name in local and p.startswith('test/'):localResolved+=1
  if not any(a<=count<=z for a,z in expected):errors.append({'path':p,'line':t[:n.start_byte].count(b'\n')+1,'type':name,'arguments':count,'expected':expected})
base={};after={}
for root,result in [(r/'before',base),(r/'after',after)]:
 for f in (root/'test').rglob('*.cs'):
  result[str(f.relative_to(root))]=re.findall(r'\b(?:public|internal)\s+(?:async\s+)?(?:void|Task(?:<[^>]+>)?|ValueTask(?:<[^>]+>)?)\s+(Should\w+)\s*\(',f.read_text())
removed=[{'path':p,'name':name} for p,names in base.items() for name in names if name not in after.get(p,[])]
new=[{'path':p,'name':name} for p,names in after.items() for name in names if name not in base.get(p,[])]
originalGate=[]
for f in (r/'after').rglob('*'):
 if f.is_file() and (repo/f.relative_to(r/'after')).exists() and not (r/'before'/f.relative_to(r/'after')).is_file():originalGate.append(str(f.relative_to(r/'after')))
audit={'qualification':'Static C# syntax, merged-overlay explicit constructor arity and acceptance name preservation only. No compiler, type resolution, runtime, HTTP or RED/GREEN proof.','filesParsed':len(list((r/'after').rglob('*.cs'))),'syntaxErrors':syntax,'explicitConstructorsCheckedAcrossEffectiveTree':checked,'sameFileTypeResolutions':localResolved,'constructorErrors':errors,'existingAcceptanceNames':sum(map(len,base.values())),'removedAcceptanceNames':removed,'newAcceptanceNames':new,'existingRepoPathMissingOriginalBaseline':originalGate}
(r/'audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps(audit,indent=2))
