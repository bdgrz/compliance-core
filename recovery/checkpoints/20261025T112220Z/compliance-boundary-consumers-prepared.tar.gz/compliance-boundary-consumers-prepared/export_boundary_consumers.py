from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,tempfile,re
r=Path('/tmp/compliance-boundary-consumers-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
shared={'src/Compliance.Core/ComplianceCoreJsonContext.cs':'shared-json.patch','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs':'shared-di.patch'}
behaviorTests={'test/Compliance.Tests/Features/Boundaries/BoundaryConsumerAuthorityTests.cs','test/Compliance.Tests/Features/AccessControl/EngagementAcceptanceSourceAvailabilityTests.cs'}
files={};baselineMissing=[];assertionDrops=[]
for a in sorted((r/'after').rglob('*.cs')):
 p=str(a.relative_to(r/'after'));b=r/'before'/p;old=b.read_bytes() if b.exists() else None;new=a.read_bytes()
 if old==new:continue
 if (repo/p).exists() and old is None:baselineMissing.append(p)
 group=shared.get(p,'tests.patch' if p in behaviorTests else 'migrated-tests.patch' if p.startswith('test/') else 'implementation.patch')
 files[p]={'old':old,'new':new,'phase':group}
 if old is not None and p.startswith('test/'):
  bc=len(re.findall(rb'Assert\.',old));ac=len(re.findall(rb'Assert\.',new))
  if ac<bc:assertionDrops.append({'path':p,'before':bc,'after':ac})
assert not baselineMissing,baselineMissing
assert not assertionDrops,assertionDrops
red={p:v['new'] for p,v in files.items()}
# Compile-compatible native implementation retaining selected historical consumer bugs for parent behavioral RED.
p='src/Compliance.Core/Features/Boundaries/GetBoundaryHandler.cs';s=red[p].decode();s=s.replace('catch (ImmutableContentIntegrityException failure)\n        {\n            return Result<BoundaryView>.Failure(BoundaryReadFailure.Of(failure));\n        }','catch (ImmutableContentIntegrityException)\n        {\n            throw;\n        }',1);red[p]=s.encode()
p='src/Compliance.Core/Features/Boundaries/BoundaryImpactService.cs';s=red[p].decode();a=s.index('            var source = await sources.ReadAsync(');b=s.index('            var changes = Compare(',a);s=s[:a]+'            _ = await sources.ReadAsync(request.TenantId, request.BoundaryId, ct).ConfigureAwait(false);\n            var boundary = discovered;\n\n'+s[b:];red[p]=s.encode()
p='src/Compliance.Core/Features/Work/BoundaryDecisionWork.cs';red[p]=red[p].replace(b'aggregate.DraftAuthorMemberId, aggregate.DraftChangedAt!.Value, aggregate.LatestReviewOutcome,',b'draft.AuthorMemberId, draft.ChangedAt, decision?.Outcome,')
p='src/Compliance.Core/Features/AccessControl/AuthorizeEngagementPracticeCommitmentsHandler.cs';red[p]=red[p].replace(b'catch (ImmutableContentIntegrityException exception) when (exception is not ImmutableContentUnavailableException)',b'catch (ImmutableContentIntegrityException exception)')
redRoot=r/'red';redRoot.mkdir(exist_ok=True)
for p,v in files.items():
 if v['phase']=='implementation.patch':
  dest=redRoot/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(red[p])
def diff(p,old,new):
 return ''.join(difflib.unified_diff((old or b'').decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+p if old is not None else '/dev/null',tofile='b/'+p))
groups={n:[] for n in ['implementation.patch','implementation-red.patch','consumer-boundaries.patch','tests.patch','migrated-tests.patch','tests-full.patch','shared-json.patch','shared-di.patch']}
manifest=[]
for p,v in files.items():
 groups[v['phase']].append(diff(p,v['old'],v['new']))
 if v['phase']=='implementation.patch':
  groups['implementation-red.patch'].append(diff(p,v['old'],red[p]))
  if red[p]!=v['new']:groups['consumer-boundaries.patch'].append(diff(p,red[p],v['new']))
 if v['phase'] in {'tests.patch','migrated-tests.patch'}:groups['tests-full.patch'].append(diff(p,v['old'],v['new']))
 manifest.append({'path':p,'phase':v['phase'],'beforeSha256':sha(v['old']) if v['old'] is not None else None,'afterSha256':sha(v['new']),'redSha256':sha(red[p]) if v['phase']=='implementation.patch' else None})
for n,parts in groups.items():(r/n).write_text(''.join(parts))
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(r/'existing-file-baseline-audit.json').write_text(json.dumps({'changedFiles':len(files),'existingFiles':sum(v['old'] is not None for v in files.values()),'newFiles':[p for p,v in files.items() if v['old'] is None],'existingRepositoryPathsMissingOriginal':baselineMissing,'assertionCountDrops':assertionDrops},indent=2)+'\n')
# Frozen prerequisite owner byte hashes must still match their published manifests.
prerequisites={}
for label,directory in [('boundary-owner','/tmp/compliance-s32-boundary-prepared'),('commitment-owner','/tmp/compliance-s32-commitment-prepared'),('commitment-consumers','/tmp/compliance-commitment-consumers-prepared')]:
 d=Path(directory);manifestPath=d/'manifest.json';entries=json.loads(manifestPath.read_text());bad=[]
 for e in entries:
  f=d/'after'/e['path'];expected=e.get('afterSha256')
  if expected is not None and (not f.exists() or sha(f.read_bytes())!=expected):bad.append(e['path'])
 assert not bad,(label,bad)
 prerequisites[label]={'root':directory,'handoffSha256':sha((d/'handoff.json').read_bytes()),'manifestSha256':sha(manifestPath.read_bytes()),'afterPathsVerified':len(entries)}
# Reconstruct staged and final groups using the system patch utility, in isolated temporary trees.
reconstruction={}
for mode,order in [('final',['implementation.patch','tests-full.patch','shared-json.patch','shared-di.patch']),('red-to-green',['implementation-red.patch','migrated-tests.patch','shared-json.patch','shared-di.patch','tests.patch','consumer-boundaries.patch'])]:
 root=Path(tempfile.mkdtemp(prefix='boundary-reconstruct-',dir=r))
 try:
  for p,v in files.items():
   if v['old'] is not None:
    dest=root/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(v['old'])
  for name in order:
   result=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/name)],cwd=root,capture_output=True,text=True)
   assert result.returncode==0,(name,result.stdout,result.stderr)
  mismatch=[p for p,v in files.items() if not (root/p).exists() or (root/p).read_bytes()!=v['new']]
  assert not mismatch,(mode,mismatch)
  reconstruction[mode]={'patchOrder':order,'filesExact':len(files)}
 finally:shutil.rmtree(root)
(r/'reconstruction.json').write_text(json.dumps(reconstruction,indent=2)+'\n')
(r/'prerequisites.json').write_text(json.dumps(prerequisites,indent=2)+'\n')
handoff={'root':str(r),'status':'Frozen offline; parent compiler/runtime/RED/GREEN/Jev/Git review gates pending.','prerequisites':prerequisites,'changedFiles':len(files),'implementationFiles':sum(v['phase']=='implementation.patch' for v in files.values()),'testFiles':sum(v['phase'] in {'tests.patch','migrated-tests.patch'} for v in files.values()),'sharedFiles':2,'stagedOrder':reconstruction['red-to-green']['patchOrder'],'allGreenAlternative':reconstruction['final']['patchOrder'],'expectedRedCases':5,'newBehaviorCases':6,'behaviorFilter':'FullyQualifiedName~BoundaryConsumerAuthorityTests|FullyQualifiedName~EngagementAcceptanceSourceAvailabilityTests','focusedFilter':'FullyQualifiedName~Boundar|FullyQualifiedName~ScopeSnapshotTests|FullyQualifiedName~Responsibilities|FullyQualifiedName~WorkQueueTests|FullyQualifiedName~WorkSourceCompositionTests|FullyQualifiedName~AssignedDecisionAuthorityTests|FullyQualifiedName~ApplicationChangePreviewTests|FullyQualifiedName~ApplicationBoundaryReferenceDirectoryTests|FullyQualifiedName~EngagementAcceptanceSourceAvailabilityTests|FullyQualifiedName~ScopeResponsibilityIndependenceTests|FullyQualifiedName~WaiverManagementIndependenceTests|FullyQualifiedName~AdvisoryReadinessNoteIndependenceTests|FullyQualifiedName~ProgramSetupWorkReadConsistencyTests|FullyQualifiedName~ProgramResourceScopeResolverTests|FullyQualifiedName~ProjectionFreshnessTests','patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in groups},'existingAcceptanceNames':264,'sourceUsePairs':'local-review-items.md','staticAudit':'audit.json','exactReconstruction':'reconstruction.json','originalBaselineGate':'existing-file-baseline-audit.json','notes':['Shared DI and JSON deltas layer after frozen native Commitment; merge hunks into newer parent changes. Do not overwrite whole shared files.','Owner57 is frozen separately: apply owner native implementation/migrations/shared owner wiring before this package.','No main edits, Git/worktree/GitHub changes, .NET, brokers, Jev or runtime claims were made.','No new GitHub issues were created.']}
(r/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps({'changedFiles':len(files),'patches':handoff['patches'],'reconstruction':reconstruction},indent=2))
