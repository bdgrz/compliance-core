using System.Globalization;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Boundaries;

static class BoundaryDirectorySchema
{
    public static readonly KvDirectoryIndex<BoundaryDirectoryIdentity> VersionsByBoundary = new("by_boundary", 1,
        static value => [value.Header.BoundaryId.ToString(), value.EffectiveFrom!.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)]);
    public static readonly KvDirectory<BoundaryDirectoryIdentity, Uuid> Versions = new("boundary_version_identities",
        ComplianceCoreJsonContext.Default.BoundaryDirectoryIdentity, static value => value.VersionId!.Value,
        static id => [id.ToString()], [VersionsByBoundary]);
    public static readonly KvDirectoryIndex<BoundaryDirectoryIdentity> DecisionsByBoundary = new("by_boundary", 1,
        static value => [value.Header.BoundaryId.ToString(), value.DecidedAt!.Value.UtcTicks.ToString("D20", CultureInfo.InvariantCulture),
            value.DecisionId!.Value.ToString()]);
    public static readonly KvDirectory<BoundaryDirectoryIdentity, Uuid> Decisions = new("boundary_decision_identities",
        ComplianceCoreJsonContext.Default.BoundaryDirectoryIdentity, static value => value.DecisionId!.Value,
        static id => [id.ToString()], [DecisionsByBoundary]);
    public static readonly KvDirectoryIndex<BoundaryDirectoryIdentity> ByProgram = new("by_program", 1,
        static value => [value.Header.ProgramId.ToString(), value.Header.BoundaryId.ToString()]);
    public static readonly KvDirectory<BoundaryDirectoryIdentity, Uuid> Directory = new("boundary_current_identities",
        ComplianceCoreJsonContext.Default.BoundaryDirectoryIdentity, static value => value.Header.BoundaryId,
        static id => [id.ToString()], [ByProgram]);
}
