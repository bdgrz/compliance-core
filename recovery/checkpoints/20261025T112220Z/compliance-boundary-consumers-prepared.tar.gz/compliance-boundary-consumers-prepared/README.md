Boundary consumers are frozen offline at this directory. Parent owns integration, compiler/format checks, runtime RED/GREEN, direct Jev review, GitHub, and merge. No main checkout edits, dotnet commands, brokers, Git/worktree/GitHub mutation, Jev calls, or issue creation were performed here.

Scope: native Boundary current/history/query composition, compact BoundaryDirectoryV3 identities, verified impact authority, responsibility scope reads, snapshots, professional access/acceptance joins, Work source/directory, ApplicationBoundaryReferencesV3, DI/JSON, and existing test/E2E source fixtures. Metadata-only existence/program/first-approval readers intentionally keep the compact SystemBoundary owner. The frozen owner package defines the aggregate/facts/commands; this package does not alter it.

Prerequisites are exactly the frozen Commitment owner54 + consumer41, then frozen Boundary owner57 at /tmp/compliance-s32-boundary-prepared. Their published manifests were rehashed in prerequisites.json. The descriptor-aware parent HTTP bridge remains the parent prerequisite for Broker E2E; no broker tests were run here. Preserve newer Policy, Control, Template, Type II and parent shared-file work by applying the shared deltas, never copying whole shared files.

Parent behavioral staging:

1. Apply Boundary owner's native implementation/migrated tests/shared wiring and preserve its old-API RED evidence separately.
2. Apply implementation-red.patch, migrated-tests.patch, shared-json.patch, shared-di.patch. This is a compile-compatible native preparation retaining five selected consumer behavior failures; it is not a claimed original main source snapshot.
3. Apply tests.patch and run the handoff behaviorFilter with Category!=BrokerIntegration. The six theory-expanded cases should produce five behavioral REDs: missing and corrupt current-source result classification, forged impact body, forged work author, and unavailable pinned-source retry. The corrupt pinned-source rejection is the positive control. Parent must verify actual results.
4. Apply consumer-boundaries.patch, rerun those cases, then the focused and full backend suites. Parent owns all runtime claims.

Alternatively, the all-final package is implementation.patch + tests-full.patch + shared-json.patch + shared-di.patch. reconstruction.json proves that both sequences reconstruct the same 64 files byte-for-byte from saved nonnull originals for all 60 existing files. Four intentional new files are listed in existing-file-baseline-audit.json.

Static audit: 85 prepared C# candidates parse without errors, 26 RED-stage source candidates parse without errors, and 478 relevant explicit constructors across the effective repository plus frozen overlays pass the arity audit (including same-file nested reader types). All 264 existing acceptance names remain; no existing test file lost Assert calls. These checks do not replace compilation, type resolution, unit tests, or runtime HTTP proof.

Preserved checks include 201 approved versions across directory pages, actual malformed sequence/draft payload rollback, approved waiver evidence, exact current/history lag, source tenant/program ownership, native responsibility OCC, suspension during waiver hydration, assignment lifetime/revocation, API scope, and existing acceptance names. Positive fixtures publish real BoundaryRules/BoundarySeeds immutable native bodies. Malformed rollback inputs remain malformed and are frozen without writing a rejected authority sequence.

Current native draft contracts are intentionally unchanged from owner57: Review/Approve/Revise/Discard gate explicit DraftVersionId + DraftRevision. ProposeSuccessor gates owner.Revision and derives its draft ID from the original command ID. Native sequence and physical tail remain separate. Shared Assign/Revoke handlers are the owner57 versions layered after Commitment and continue routing Control, Commitment and Boundary to their respective native operations.

A Boundary history page composes its identities from one verified native source cut per page. Current directory rows reject stale authority; version/decision rows select retained native history. Boundary impact uses source content after discovery gates, and work uses source author/time/outcome after discovery validation. The receiver keeps unavailable pinned/grant content transient while corrupt pinned content remains a terminal rejection.

See handoff.json for patch hashes, test filters and order; manifest.json for every before/final/RED source hash; audit.json for static details; local-review-items.md for source-use boundaries. Parent should run formatting after integration. No runtime GREEN or Jev pass is claimed.
