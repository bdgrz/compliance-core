# Three bounded native history compactions

Frozen offline preparation for AccessPrincipalClassification, CriteriaTextOverlay and TrainingRequirement. Actual root runtime and review gates remain pending.

Apply behavioral-red.patch first and run red-filter.txt against the old code; then apply after-red.patch. Alternatively full.patch exactly reconstructs all27 paths from base/. implementation.patch and tests.patch are separate review artifacts. Partitions are recorded per path in manifest.json. NativeOwnerHistory.cs is the shared prerequisite for parent RiskMethod/Governance/Treatment work; do not install divergent copies.

The three owners retain latest native source/ref, scalar current revision/identity and selected NativeAcceptance. They no longer retain every prior fact/version. Exact immutable history composition verifies the hydrated physical/native cut, audit positions, canonical source stream, event identity/logical version, source body/schema/digest and original actor/time. Missing source bytes/tail remain transient; contradictory/corrupt content is permanent. Later commits cannot change a captured read cut. All four root handlers prepare/freeze inside NativeOperation.Prepare, preserving equal-winner acceptance recovery.

The original native durable facts, discriminators, content schemas, result envelopes, typed200 HTTP commands and public query contracts are unchanged. New producers explicitly write FirstOwner. Existing nullable native FirstOwner normalization matches AcceptedOperationBinding; no legacy full-State migration or dual-reader is introduced. No body clock substitutes for broker receipt cut. Criteria historical source capture keeps the merged receipt prefix/current usage policy, exact original narrative and original digest preimages; null RecordedThrough path is unchanged.

No new DI/JSON/Program registration is needed. Existing IDomainEventReader is added to current-history consumer constructors. Detailed arities and direct callsite audits are in static-checks.json; shared-deltas.json records root integration details. Existing test names and their assertions are retained, including training version-history assertions now using verified history reads.

No source outside this /tmp package was changed. No builds/tests, Git, new worktrees, Jev calls, issues or deployment operations were run. Modern syntax, source constructor/token/import audits and exact patch reconstruction are preparation evidence only. Parent owns actual RED/GREEN, strict analyzer/build/format, focused/full/HTTP, direct per-file Jev and integration.
