Boundary contract clarification

ReviewBoundary, ApproveBoundary, ReviseBoundaryDraft, and DiscardBoundaryDraft retain the existing public exact DraftVersionId plus DraftRevision meaning of ExpectedRevision. The accepted remaining-command-identities catalog labels this counter ResourceRevision; that label does not silently turn existing draft gates into the aggregate's lifecycle count. Root confirmed this selection during preparation. ProposeBoundarySuccessor gains ExpectedRevision against the owner lifecycle Revision, alongside ExpectedApprovedVersionId. NativeSequence and physical append OCC are separate counters.

Creation accepts the required authored BoundaryId, preserving the existing arbitrary typed UUID identity because SystemBoundary has no existing deterministic IdFor algorithm. Its first draft is exactly UUIDv5(BoundaryId, "draft-1"). A successor retains existing UUIDv5(CommandId, "draft"). Durable native seed fixtures must select those same identities. Pure legacy content folds may retain historical IDs without claiming native admission.

The existing HTTP revision entrypoint remains supported with the authored command ID added to /boundaries/{boundary_id}/drafts/{draft_version_id}/revisions/{command_id}. Other selected typed PUT paths follow the accepted remaining-command-identities catalog. Review and approval remain personal HTTP only. Existing MCP registration selection is preserved. Unit commands retain plain IRequest/Result and frozen immediate 200 UnitResult metadata; actual HTTP status qualification depends on the parent's shared descriptor-aware transport completion.

Current native authority contains only header and immutable current-authority references. Complete draft/version/decision history and prior responsibility scopes live in verified immutable change content and transient source-backed read folds. No .Current history shim, live waiver aggregate input, synthetic lifetime cap, or projection-as-authority is introduced.

No selected SystemBoundary source-use acquire/settle pair exists in the accepted source-admission/target-owner-extension catalogs. This slice does not invent receiver purposes or claim a new cross-owner atomic admission guarantee. Existing source/reference/impact proof semantics remain intact.

No persisted-v1 data migration or live deployment qualification is claimed. Legacy actor/content acceptance tests exercise the immutable business payload codec/read fold; they do not imply that removed v1 aggregate-envelope persistence was migrated.
