from pathlib import Path
import re,json
import prepare as p
C='src/Compliance.Common/Features/Boundaries/';K='src/Compliance.Core/Features/Boundaries/'
EVENTS=['BoundaryDraftCreated','BoundaryDraftRevised','BoundaryReviewed','BoundaryApproved','BoundaryDraftDiscarded','BoundarySuccessorProposed']
def source(path):return p.original(path)
def put(path,text,phase='implementation'):p.put(path,text,phase)
def new(path,text,phase='implementation'):put(path,text.strip()+'\n',phase)
test_path='test/Compliance.Tests/Features/Boundaries/PersonalBoundaryDecisionTransportTests.cs'
red=source(test_path)
red=red.replace('        readonly Uuid _review = Uuid.CreateVersion4();', '        readonly Uuid _review = Uuid.CreateVersion4();\n        readonly Uuid _approval = Uuid.CreateVersion4();')
red=red.replace('action == "review" ? _review : Uuid.CreateVersion4()', 'action == "review" ? _review : _approval')
red=red.replace('    sealed class Fixture : IAsyncDisposable', '''    [Theory]
    [InlineData("review")]
    [InlineData("approval")]
    public async Task ShouldReturnOriginalDecisionGivenExactPersonalHttpRetry(string action)
    {
        // Arrange
        await using var fixture = await Fixture.CreateAsync(action);
        var first = await fixture.DecideAsync(action, "http");
        Assert.True(first.IsSuccess, first.Error?.Message);
        var accepted = await fixture.ReadAsync();

        // Act
        var retry = await fixture.DecideAsync(action, "http");
        var retained = await fixture.ReadAsync();

        // Assert
        Assert.True(retry.IsSuccess, retry.Error?.Message);
        Assert.Equal(accepted.CommittedStreamPosition, retained.CommittedStreamPosition);
    }

    sealed class Fixture : IAsyncDisposable''')
put(test_path,red,'tests')

# Preserve the old immutable full business payload shape, while native roots retain compact source identities only.
for name in EVENTS:
 old=source(C+name+'.cs');m=re.search(r'public sealed record '+name+r'\((.*?)\)\s*:\s*DomainEvent',old,re.S);assert m
 old=old[:m.start()]+f'public sealed record {name}Content('+m.group(1)+') : IBoundaryMutationContent'+old[m.end():]
 old=re.sub(r'\[Discriminator\([^\n]+\)\]\n','',old);put(C+name+'Content.cs',old)
new(C+'IBoundaryMutationContent.cs','''using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.Responsibilities;

namespace Bdgrz.Compliance.Features.Boundaries;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "$boundary_change")]
'''+''.join(f'[JsonDerivedType(typeof({n}Content), "{n}")]\n' for n in EVENTS)+'''[JsonDerivedType(typeof(ResponsibilityAssigned), "ResponsibilityAssigned")]
[JsonDerivedType(typeof(ResponsibilityRevoked), "ResponsibilityRevoked")]
public interface IBoundaryMutationContent { }''')
new(C+'BoundaryAuthorityHeader.cs','''using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Boundaries;

public sealed record BoundaryAuthorityHeader(Uuid TenantId, Uuid ProgramId, Uuid BoundaryId,
    long Revision, bool IsCreated, bool IsVisible, Uuid DraftVersionId, long DraftRevision,
    Uuid DraftAuthorMemberId, bool DraftEverReviewed, Uuid AcceptedReviewDecisionId,
    string? LatestReviewOutcome, Uuid LatestApprovedVersionId, Uuid FirstApprovedVersionId,
    DateOnly? LatestApprovedEffectiveFrom, DateTimeOffset? DraftChangedAt, ImmutableContentRef Content);''')
new(C+'BoundaryDecisionConstraint.cs','''using Bdgrz.Compliance.Features.Responsibilities;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Boundaries;

public sealed record BoundaryDecisionConstraint(Uuid MemberId, ResponsibilityType Type, DateTimeOffset At, Uuid? WaiverId);''')
new(C+'BoundaryAuthorityContent.cs','''using Bdgrz.Compliance.Features.Responsibilities;

namespace Bdgrz.Compliance.Features.Boundaries;

public sealed record BoundaryAuthorityContent(BoundaryAuthorityHeader Header,
    IReadOnlyList<ResponsibilityAssignmentView> Assignments, IReadOnlyList<BoundaryDecisionConstraint> DecisionConstraints);''')
new(C+'BoundaryMutationContent.cs','''using Bdgrz.Compliance.Features.AccessControl;

namespace Bdgrz.Compliance.Features.Boundaries;

public sealed record BoundaryMutationContent(IReadOnlyList<IBoundaryMutationContent> Changes,
    IReadOnlyList<SeparationOfDutiesWaiverProof>? Waivers = null, IBoundaryMutationContent? Receipt = null);''')
new(C+'IBoundaryFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Boundaries;

public interface IBoundaryFact : INativeOperationFact
{
    Uuid TenantId { get; }
    BoundaryAuthorityHeader Header { get; }
    ImmutableContentRef Change { get; }
    ImmutableContentRef Authority { get; }
    ImmutableContentRef? OperationResult { get; }
    long NativeSequence { get; }
    int ChangeCount { get; }
}''')
heads={
'BoundaryDraftCreated':'Uuid TenantId, Uuid BoundaryId, Uuid ProgramId, Uuid DraftVersionId, ImmutableContentRef Content, Uuid AuthorMemberId, string AuthorDisplay, DateTimeOffset ChangedAt',
'BoundaryDraftRevised':'Uuid TenantId, Uuid BoundaryId, Uuid DraftVersionId, long Revision, ImmutableContentRef Content, Uuid AuthorMemberId, string AuthorDisplay, DateTimeOffset ChangedAt',
'BoundarySuccessorProposed':'Uuid TenantId, Uuid BoundaryId, Uuid DraftVersionId, Uuid PredecessorVersionId, ImmutableContentRef Content, Uuid AuthorMemberId, string AuthorDisplay, DateTimeOffset ChangedAt',
'BoundaryReviewed':'Uuid TenantId, Uuid BoundaryId, Uuid DraftVersionId, long Revision, Uuid DecisionId, string Outcome, Uuid ActorMemberId, string ActorDisplay, DateTimeOffset DecidedAt, Uuid? SeparationOfDutiesWaiverId = null',
'BoundaryApproved':'Uuid TenantId, Uuid BoundaryId, Uuid DraftVersionId, long Revision, Uuid ApprovalDecisionId, Uuid AcceptedReviewDecisionId, Uuid ActorMemberId, string ActorDisplay, DateOnly EffectiveFrom, DateTimeOffset DecidedAt, Uuid? SeparationOfDutiesWaiverId = null',
'BoundaryDraftDiscarded':'Uuid TenantId, Uuid BoundaryId, Uuid DraftVersionId, long Revision, Uuid ActorMemberId, string ActorDisplay, DateTimeOffset DiscardedAt'}
for name,head in heads.items():
 disc=re.search(r'\[Discriminator\((.*?)\)\]',source(C+name+'.cs')).group(1);disc=re.sub(r', 1$',', 2',disc)
 text='''using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Boundaries;

'''+f'[Discriminator({disc})]\npublic sealed record {name}({head}) : DomainEvent, IBoundaryFact\n'+'''{
    public OperationProvenance Operation { get; init; } = default!;
    public ImmutableContentRef? FirstResponse { get; init; }
    public ImmutableContentRef? OperationResult { get; init; }
    public BoundaryAuthorityHeader Header { get; init; } = default!;
    public ImmutableContentRef Change { get; init; } = default!;
    public ImmutableContentRef Authority { get; init; } = default!;
    public long NativeSequence { get; init; }
    public int ChangeCount { get; init; }
'''
 if name in ['BoundaryReviewed','BoundaryApproved','BoundaryDraftDiscarded']:
  text+='''    [JsonPropertyName("actor")]
    public ActorReference? StoredActor { get; init; }
    [JsonIgnore]
    public ActorReference Actor => StoredActor ?? ActorReference.ForMember(ActorMemberId, ActorDisplay);
'''
 text+='}\n';put(C+name+'.cs',text)
for name in ['ResponsibilityAssigned','ResponsibilityRevoked']:
 path='src/Compliance.Common/Features/Responsibilities/'+name+'.cs';text='using Bdgrz.Compliance.Features.Boundaries;\n'+source(path)
 text=text.replace('ICommitmentFact, ICommitmentMutationContent','ICommitmentFact, ICommitmentMutationContent, IBoundaryFact, IBoundaryMutationContent')
 point='    [JsonPropertyName("actor")]';text=text.replace(point,'''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public BoundaryAuthorityHeader? BoundaryHeader { get; init; }
    BoundaryAuthorityHeader IBoundaryFact.Header => BoundaryHeader!;

'''+point);put(path,text)
# Stable typed operation identities; preserve existing draft gates, and add owner lifecycle gate only for successor.
for name in ['CreateBoundary','ProposeBoundarySuccessor','ReviseBoundaryDraft','ReviewBoundary','ApproveBoundary','DiscardBoundaryDraft']:
 text=source(C+name+'.cs');field='BoundaryId' if name=='CreateBoundary' else 'CommandId'
 text=text.replace(f'record {name}(Uuid TenantId',f'record {name}(Uuid {field}, Uuid TenantId')
 if name=='ProposeBoundarySuccessor':text=text.replace('Uuid ExpectedApprovedVersionId, BoundaryContent Content)', 'Uuid ExpectedApprovedVersionId, BoundaryContent Content, long ExpectedRevision)')
 text=text.replace('IClientManagementMutationRequest, ICallable;',f'IClientManagementMutationRequest, IIdentifiedRequest, ICallable\n{{\n    Uuid IIdentifiedRequest.RequestId => {field};\n}}')
 put(C+name+'.cs',text)
# Exact typed native receipt creation retains scalar facts and actor snapshots.
factory="""using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Responsibilities;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Boundaries;

public static class BoundaryFactFactory
{
    public static DomainEvent Create(string kind, BoundaryAuthorityHeader header, long sequence, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result,
        BoundaryMutationContent mutation) => kind switch
    {
"""
commands=['CreateBoundary','ReviseBoundaryDraft','ReviewBoundary','ApproveBoundary','DiscardBoundaryDraft','ProposeBoundarySuccessor']
for name,kind in zip(EVENTS,commands):factory+=f'        nameof({kind}) => {name}(header, sequence, operation, change, authority, first, result, mutation),\n'
for name in ['ResponsibilityAssigned','ResponsibilityRevoked']:factory+=f'        nameof({name.replace("ResponsibilityAssigned","AssignResponsibility").replace("ResponsibilityRevoked","RevokeResponsibility")}) => {name}(header, sequence, operation, change, authority, first, result, mutation),\n'
factory+='        _ => throw new InvalidOperationException("The boundary command kind is not selected."),\n    };\n    static T Selected<T>(BoundaryMutationContent mutation) where T : class, IBoundaryMutationContent =>\n        (mutation.Changes.Count == 0 ? mutation.Receipt as T : mutation.Changes.OfType<T>().SingleOrDefault())\n        ?? throw new InvalidOperationException("The boundary command has another exact prepared content kind.");\n'
for name,head in heads.items():
 fields=[re.search(r'(\w+)(?: = .*)?$',item.strip()).group(1) for item in head.split(',')]
 args=', '.join('header.Content' if field=='Content' else 'data.'+field for field in fields)
 factory+=f'    static {name} {name}(BoundaryAuthorityHeader header, long sequence, OperationProvenance operation,\n        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result, BoundaryMutationContent mutation)\n    {{\n        var data = Selected<{name}Content>(mutation);\n        return new({args})\n        {{\n            Operation = operation, Header = header, Change = change, Authority = authority, NativeSequence = sequence,\n            ChangeCount = mutation.Changes.Count, FirstResponse = first, OperationResult = result,'
 if name in ['BoundaryReviewed','BoundaryApproved','BoundaryDraftDiscarded']:factory+=' StoredActor = data.StoredActor,'
 factory+='\n        };\n    }\n'
for name in ['ResponsibilityAssigned','ResponsibilityRevoked']:
 factory+=f'    static {name} {name}(BoundaryAuthorityHeader header, long sequence, OperationProvenance operation,\n        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result, BoundaryMutationContent mutation)\n    {{\n        var data = Selected<{name}>(mutation);\n        return data with {{ Operation = operation, BoundaryHeader = header, Change = change, Authority = authority, NativeSequence = sequence,\n            ChangeCount = mutation.Changes.Count, FirstResponse = first, OperationResult = result }};\n    }}\n'
factory+='}\n';put(K+'BoundaryFactFactory.cs',factory)

# Pure transient preparation/read fold. The compact Aggregate below never retains these histories.
rules=source(K+'SystemBoundary.cs').replace('public sealed class SystemBoundary : Aggregate','public sealed class BoundaryRules')
rules=rules.replace('    readonly Uuid _tenantId;','''    readonly Dictionary<Type, Action<IBoundaryMutationContent>> _reducers = [];
    readonly List<IBoundaryMutationContent> _pendingChanges = [];
    readonly List<IBoundaryMutationContent> _appliedChanges = [];
    readonly Dictionary<Uuid, SeparationOfDutiesWaiverProof> _waivers = [];
    public Uuid Id { get; }
    public Uuid TenantId => _tenantId;
    public ulong SourcePhysicalPosition { get; internal set; }
    public IReadOnlyList<IBoundaryMutationContent> PendingChanges => _pendingChanges.AsReadOnly();
    internal IReadOnlyList<IBoundaryMutationContent> AppliedChanges => _appliedChanges.AsReadOnly();
    public void ClearPendingChanges() => _pendingChanges.Clear();
    void On<T>(Action<T> reduce) where T : IBoundaryMutationContent => _reducers.Add(typeof(T), value => reduce((T)value));
    void RaiseEvent<T>(T value) where T : IBoundaryMutationContent
    {
        Apply(value);
        _pendingChanges.Add(value);
    }
    public void Apply(IBoundaryMutationContent value)
    {
        if (!_reducers.TryGetValue(value.GetType(), out var reduce))
            throw new InvalidOperationException("The boundary change has another content kind.");
        FoldRead(value);
        reduce(value);
        _appliedChanges.Add(value);
    }
    readonly Uuid _tenantId;''',1)
rules=rules.replace('public SystemBoundary(Uuid tenantId, Uuid boundaryId)\n        : base(boundaryId, new EventStreamAddress(tenantId.ToString(), "boundaries", boundaryId.ToString()))','public BoundaryRules(Uuid tenantId, Uuid boundaryId)')
rules=rules.replace('        _tenantId = tenantId;', '        Id = boundaryId;\n        _tenantId = tenantId;',1)
for name in EVENTS:rules=re.sub(r'\b'+name+r'\b',name+'Content',rules)
rules=rules.replace('SeparationOfDutiesWaiver?', 'SeparationOfDutiesWaiverProof?').replace('IReadOnlyList<SeparationOfDutiesWaiver>', 'IReadOnlyList<SeparationOfDutiesWaiverProof>')
rules=rules.replace('string authorDisplay, DateTimeOffset changedAt)\n    {\n        if (!_created)', 'string authorDisplay, DateTimeOffset changedAt, Uuid commandId = default)\n    {\n        if (!_created)')
rules=rules.replace('        RaiseEvent(new BoundarySuccessorProposedContent(', '        if (commandId != Uuid.Empty)\n            _successorCommands[draftVersionId] = commandId;\n        RaiseEvent(new BoundarySuccessorProposedContent(')
rules=rules.replace('    bool IsCurrentResponsibilityScope(', '    public bool IsCurrentResponsibilityScope(')
rules=rules.replace('ResponsibilityDecisionGuard.Validate(', 'ResponsibilityDecisionGuard.ValidateAuthorized(').replace('return set.Assign(', 'return set.AssignAuthorized(')
rules=rules.replace('!separationOfDutiesWaiver.Allows(reviewWaiverScope, reviewerMemberId, decidedAt)', '!BoundaryWaiverProof.Allows(separationOfDutiesWaiver, _tenantId, reviewWaiverScope, reviewerMemberId, decidedAt)').replace('!separationOfDutiesWaiver.Allows(approvalWaiverScope, approverMemberId, decidedAt)', '!BoundaryWaiverProof.Allows(separationOfDutiesWaiver, _tenantId, approvalWaiverScope, approverMemberId, decidedAt)')
rules=rules.replace('    static string? Validate(', '    internal static string? Validate(')
# Existing responsibility guard/set have proof overloads after the Control cutover.
rules=rules.replace('separationOfDutiesWaiver?.Id','separationOfDutiesWaiver?.WaiverId')
# Freeze only proofs supplied through validated preparation; never a live waiver aggregate.
rules=rules.replace('        RaiseEvent(reviewed);','        Remember(separationOfDutiesWaiver);\n        RaiseEvent(reviewed);').replace('        RaiseEvent(approved);','        Remember(separationOfDutiesWaiver);\n        RaiseEvent(approved);')
rules=rules.replace('        return set.Assign(assignmentId', '        foreach (var waiver in waivers)\n            Remember(waiver);\n        return set.Assign(assignmentId')
rules=rules.replace('using Bdgrz.Compliance.Features.Responsibilities;', 'using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Proofs;\nusing Bdgrz.Compliance.Features.Responsibilities;')
# Extra pure history/read methods are a physically separate template for review.
rules=rules.rsplit('}',1)[0]+(p.OUT/'templates/BoundaryRulesRead.cs.txt').read_text()+'}\n'
put(K+'BoundaryRules.cs',rules)
for template in (p.OUT/'templates').glob('*.cs.txt'):
 if template.name=='BoundaryRulesRead.cs.txt':continue
 dest=('test/Compliance.Tests/Features/Boundaries/' if template.name=='BoundaryNativeAuthorityTests.cs.txt' else 'test/Compliance.Tests/Testing/' if template.name in ['BoundarySeeds.cs.txt','BoundarySourceFixture.cs.txt'] else C if template.name.startswith('COMMON_') else K)+template.name.removeprefix('COMMON_').removesuffix('.txt')
 put(dest,template.read_text())
# Control and Commitment native branches are unchanged; Boundary completes the last legacy writer branch.
for name in ['AssignResponsibilityHandler','RevokeResponsibilityHandler']:
 path='src/Compliance.Core/Features/Responsibilities/'+name+'.cs'
 assign=name.startswith('Assign')
 text="""using Bdgrz.Compliance.Features.Boundaries;
using Bdgrz.Compliance.Features.Commitments;
using Bdgrz.Compliance.Features.Controls;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Responsibilities;

"""
 if assign:
  text+='public sealed class AssignResponsibilityHandler(ITenantMembershipDirectoryReader memberships,\n    IResponsibilityScopeValidator scopeValidator, ControlOperations controls, CommitmentOperations commitments, BoundaryOperations boundaries)\n    : IRequestHandler<AssignResponsibility>\n{\n    public ValueTask<Result> HandleAsync(IRequestContext<AssignResponsibility> context, CancellationToken ct) => context.Request.RecordType switch\n    {\n        SeparationOfDutiesRecordTypes.Control => controls.AssignResponsibilityAsync(context, memberships, scopeValidator, ct),\n        SeparationOfDutiesRecordTypes.Commitment => commitments.AssignResponsibilityAsync(context, memberships, scopeValidator, ct),\n        SeparationOfDutiesRecordTypes.Boundary => boundaries.AssignResponsibilityAsync(context, memberships, scopeValidator, ct),\n        _ => ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Validation, "The responsibility record type is not supported."))),\n    };\n}\n'
 else:
  text+='public sealed class RevokeResponsibilityHandler(IResponsibilityScopeValidator scopeValidator,\n    ControlOperations controls, CommitmentOperations commitments, BoundaryOperations boundaries) : IRequestHandler<RevokeResponsibility>\n{\n    public ValueTask<Result> HandleAsync(IRequestContext<RevokeResponsibility> context, CancellationToken ct) => context.Request.RecordType switch\n    {\n        SeparationOfDutiesRecordTypes.Control => controls.RevokeResponsibilityAsync(context, scopeValidator, ct),\n        SeparationOfDutiesRecordTypes.Commitment => commitments.RevokeResponsibilityAsync(context, scopeValidator, ct),\n        SeparationOfDutiesRecordTypes.Boundary => boundaries.RevokeResponsibilityAsync(context, scopeValidator, ct),\n        _ => ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Validation, "The responsibility record type is not supported."))),\n    };\n}\n'
 put(path,text)

p.emit()
# Preserve original business acceptance methods on the exact pure preparation fold.
path='test/Compliance.Tests/Features/Boundaries/SystemBoundaryTests.cs';text=source(path)
text='using Bdgrz.Compliance.Tests.Testing;\n'+text
text=text.replace('new SystemBoundary(', 'new BoundaryRules(')
text=re.sub(r'new AggregateScenario<SystemBoundary>\((\w+)\)\.PendingEvents',r'\1.PendingChanges',text)
for name in EVENTS:text=re.sub(r'\b'+name+r'\b',name+'Content',text)
a=text.index('        new AggregateScenario<SystemBoundary>(boundary).Given(');b=text.index('\n\n',a)
text=text[:a]+'''        // Legacy immutable content is read into the transient business fold only.
        boundary.Apply(new BoundaryDraftCreatedContent(TenantId, BoundaryId, ProgramId,
            VersionId, legacy, AuthorId, "Author", Now));
        boundary.Apply(new BoundaryReviewedContent(TenantId, BoundaryId, VersionId, 1,
            decisionId, "accept", reviewer, "Reviewer", "Reviewed", Now));
        boundary.ClearPendingChanges();'''+text[b:]
text=text.replace('static SeparationOfDutiesWaiver CreateWaiver(', 'static SeparationOfDutiesWaiverProof CreateWaiver(').replace('        return waiver;', '        return ControlTestWaivers.Proof(waiver);')
text=text.replace('valid.Id, decision.SeparationOfDutiesWaiverId', 'valid.WaiverId, decision.SeparationOfDutiesWaiverId').replace('waiver.Id, approval.SeparationOfDutiesWaiverId', 'waiver.WaiverId, approval.SeparationOfDutiesWaiverId')
put(path,text,'migrated-tests')
path='test/Compliance.Tests/Features/Boundaries/BoundaryActorSnapshotTests.cs';text=source(path)
for name in ['BoundaryReviewed','BoundaryDraftDiscarded']:text=re.sub(r'\b'+name+r'\b',name+'Content',text)
put(path,text,'migrated-tests')
# Handler transport fixture now seeds the same native source it queries.
path=test_path;text=red
text=text.replace('        readonly Uuid _version = Uuid.CreateVersion4();','        readonly Uuid _version;')
text=text.replace('        Fixture()\n        {','        Fixture()\n        {\n            _version = Uuid.CreateVersion5(_boundary, "draft-1");')
text=text.replace('new SystemBoundary(', 'new BoundaryRules(').replace('Task<SystemBoundary> ReadAsync()', 'Task<BoundaryRules> ReadAsync()')
text=text.replace('.CommittedStreamPosition', '.SourcePhysicalPosition')
text=text.replace('new ReviewBoundary(_tenant,', 'new ReviewBoundary(_review, _tenant,').replace('new ApproveBoundary(_tenant,', 'new ApproveBoundary(_approval, _tenant,')
text=text.replace('new CheckpointIdentity("BoundaryDirectoryV2",', 'new CheckpointIdentity(FitzBoundaryDirectory.ProjectorName,')
# ImpactDigest is immutable approval content rather than duplicated native root data.
text=text.replace('                Assert.Equal(_digest, approval.ImpactDigest);','''                var change = await BoundaryFactContent.ReadChangeAsync(_provider.GetRequiredService<Bdgrz.Compliance.Features.Content.IImmutableContentStore>(), approval);
                Assert.Equal(_digest, Assert.IsType<BoundaryApprovedContent>(Assert.Single(change.Changes)).ImpactDigest);''')
put(path,text,'migrated-tests')
p.emit()

path='src/Compliance.Core/ComplianceCoreJsonContext.cs';text=source(path)
json_types=['BoundaryAuthorityHeader','BoundaryAuthorityContent','BoundaryDecisionConstraint','BoundaryMutationContent','IBoundaryMutationContent']+[name+'Content' for name in EVENTS]
point='[JsonSerializable(typeof(BoundaryContent))]';assert point in text
text=text.replace(point,point+'\n'+''.join('[JsonSerializable(typeof('+name+'))]\n' for name in json_types).rstrip())
put(path,text,'shared-json-contracts')
path='src/Compliance.App/Program.cs';text=source(path)
text=text.replace('app.MapPortiaPost<CreateBoundary, BoundaryRegistration>', 'app.MapPortiaPut<CreateBoundary, BoundaryRegistration>')
text=text.replace('"/api/v1/tenants/{tenant_id}/programs/{program_id}/boundaries")','"/api/v1/tenants/{tenant_id}/programs/{program_id}/boundaries/{boundary_id}")',1)
text=text.replace('"/api/v1/tenants/{tenant_id}/boundaries/{boundary_id}/drafts/{draft_version_id}")','"/api/v1/tenants/{tenant_id}/boundaries/{boundary_id}/drafts/{draft_version_id}/revisions/{command_id}")',1)
for name,suffix in [('DiscardBoundaryDraft','discards'),('ReviewBoundary','reviews'),('ApproveBoundary','approvals')]:
 text=text.replace('app.MapPortiaPost<'+name+'>','app.MapPortiaPut<'+name+'>')
 text=text.replace('/drafts/{draft_version_id}/'+suffix+'")','/drafts/{draft_version_id}/'+suffix+'/{command_id}")',1)
text=text.replace('app.MapPortiaPost<ProposeBoundarySuccessor, BoundaryRegistration>', 'app.MapPortiaPut<ProposeBoundarySuccessor, BoundaryRegistration>')
text=text.replace('/boundaries/{boundary_id}/successors")','/boundaries/{boundary_id}/successors/{command_id}")',1)
put(path,text,'shared-program-routes')
p.emit()
