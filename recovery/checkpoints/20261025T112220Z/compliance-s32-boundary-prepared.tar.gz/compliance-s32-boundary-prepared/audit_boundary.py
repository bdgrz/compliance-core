from pathlib import Path
import tree_sitter,tree_sitter_c_sharp,json,hashlib,subprocess,tempfile
out=Path('/tmp/compliance-s32-boundary-prepared');root=Path('/Users/jrepanich/Code/bdgrz/compliance-core');after=out/'after';parser=tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()));known={};errors=[];syntax=[];grammar=[];calls=0

def walk(n):
 yield n
 for c in n.children:yield from walk(c)
for p in after.rglob('*.cs'):
 t=p.read_bytes()
 for n in walk(parser.parse(t).root_node):
  if n.type in ['class_declaration','record_declaration','constructor_declaration']:
   name=n.child_by_field_name('name');pars=next((c for c in n.children if c.type=='parameter_list'),None)
   if name and pars:
    ps=[c for c in pars.children if c.type=='parameter'];known.setdefault(name.text.decode(),[]).append((sum(b'=' not in c.text for c in ps),len(ps)))
  if n.type=='ERROR':
   row={'path':str(p.relative_to(after)),'line':n.start_point.row+1,'text':n.text.decode()[:140]}
   if n.text==b',' or p.name in ['ComplianceCoreJsonContext.cs','Program.cs']:grammar.append(row)
   else:syntax.append(row)
for p in after.rglob('*.cs'):
 for n in walk(parser.parse(p.read_bytes()).root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((c for c in n.children if c.type=='argument_list'),None)
  if not typ or not args or typ.text.decode().split('.')[-1] not in known:continue
  name=typ.text.decode().split('.')[-1];num=sum(c.type=='argument' for c in args.children);calls+=1
  if not any(lo<=num<=hi for lo,hi in known[name]):errors.append({'path':p.name,'line':n.start_point.row+1,'type':name,'args':num,'expected':known[name]})
def names(p):
 return [n.child_by_field_name('name').text.decode() for n in walk(parser.parse(p.read_bytes()).root_node) if n.type=='method_declaration' and n.child_by_field_name('name').text.startswith(b'Should')]
acceptance=[];removed=[]
for name in ['SystemBoundaryTests','BoundaryActorSnapshotTests','PersonalBoundaryDecisionTransportTests']:
 rel=Path('test/Compliance.Tests/Features/Boundaries')/(name+'.cs');old=names(out/'before'/rel);new=names(after/rel);removed.extend(sorted(set(old)-set(new)));acceptance.append({'path':str(rel),'original':len(old),'prepared':len(new)})
manifest=json.loads((out/'manifest.json').read_text());validation=Path(tempfile.mkdtemp(prefix='compliance-boundary-staged-verify-')).resolve()
for row in manifest:
 baseline=out/'before'/row['path']
 if baseline.exists():
  dest=validation/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(baseline.read_bytes())
checks=[]
for name in ['tests.patch','implementation.patch','migrated-tests.patch','shared-json-contracts.patch','shared-program-routes.patch']:
 result=subprocess.run(['git','apply','--unsafe-paths','--directory='+str(validation),str(out/name)],cwd=root,capture_output=True,text=True);checks.append({'patch':name,'exit':result.returncode,'error':result.stderr});assert result.returncode==0,result.stderr
mismatch=[row['path'] for row in manifest if (validation/row['path']).read_bytes()!=(after/row['path']).read_bytes()]
report={'files':len(manifest),'syntaxErrors':syntax,'knownParserGrammarFlags':grammar,'explicitConstructorCalls':calls,'constructorArityErrors':errors,'originalAcceptanceNamesRemoved':removed,'acceptance':acceptance,'nativeMethods':names(after/'test/Compliance.Tests/Features/Boundaries/BoundaryNativeAuthorityTests.cs'),'patchApplyChecks':checks,'reconstructedByteMismatches':mismatch,'validationDirectory':str(validation),'qualification':'Static offline preparation only; no dotnet/runtime or Jev claims.'}
(out/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='knownParserGrammarFlags'},indent=2));assert not syntax and not errors and not removed and not mismatch
