using Cntryl.Fitz;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

sealed class FitzCommitmentDraftDirectory(IKvClient client)
    : FitzKvProjectionStore(client, "kv://bdgrz/commitment-draft-directory/projection",
            "CommitmentDraftDirectory"),
        ICommitmentDraftDirectoryReader, ICommitmentDraftDirectoryProjection
{
    public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId,
        CancellationToken ct = default) =>
        base.LoadCheckpointAsync(new CheckpointIdentity("CommitmentDraftDirectory",
            EventStreamPattern.ForPattern(tenantId.ToString(), "commitment-drafts")), ct);

    public async ValueTask ApplyAsync(DomainEvent domainEvent, CancellationToken ct = default)
    {
        switch (domainEvent)
        {
            case CommitmentDraftCreated created:
                await CommitmentDraftDirectorySchema.Drafts.InsertAsync(Transaction,
                        new CommitmentDraftView(created.TenantId, created.ProgramId,
                            created.DraftId, created.ServiceId, created.Kind, created.Identifier,
                            1, "draft", "unverified", "unresolved", "unresolved",
                            created.Statement, created.Context, created.SourceReference,
                            created.ActorMemberId, created.ActorDisplay, created.ChangedAt)
                        {
                            LastChangedBy = created.Actor,
                            ProviderId = created.ProviderId,
                        }, ct)
                    .ConfigureAwait(false);
                await CommitmentDraftDirectorySchema.Revisions.InsertAsync(Transaction,
                        new CommitmentDraftRevisionView(created.TenantId, created.ProgramId,
                            created.DraftId, created.ServiceId, created.Kind, created.Identifier,
                            1, created.Statement, created.Context, created.SourceReference,
                            created.ActorMemberId, created.ActorDisplay, created.ChangedAt)
                        {
                            Actor = created.Actor,
                            ProviderId = created.ProviderId,
                        }, ct)
                    .ConfigureAwait(false);
                break;
            case CommitmentDraftRevised revised:
                var current = await CommitmentDraftDirectorySchema.Drafts.GetAsync(Transaction,
                    revised.DraftId, ct).ConfigureAwait(false);
                if (current is null || current.TenantId != revised.TenantId ||
                    current.ProgramId != revised.ProgramId ||
                    current.Revision + 1 != revised.Revision)
                    throw new InvalidOperationException(
                        "A commitment draft revision cannot project before its predecessor.");
                await CommitmentDraftDirectorySchema.Drafts.ReplaceAsync(Transaction, current,
                    current with
                    {
                        Revision = revised.Revision,
                        Statement = revised.Statement,
                        Context = revised.Context,
                        SourceReference = revised.SourceReference,
                        LastChangedByMemberId = revised.ActorMemberId,
                        LastChangedByDisplay = revised.ActorDisplay,
                        LastChangedBy = revised.Actor,
                        LastChangedAt = revised.ChangedAt,
                        Status = "draft",
                        SourceResolution = "unverified",
                        OwnerResolution = "unresolved",
                        ApplicabilityResolution = "unresolved",
                    }, ct).ConfigureAwait(false);
                await CommitmentDraftDirectorySchema.Revisions.InsertAsync(Transaction,
                    new CommitmentDraftRevisionView(revised.TenantId, revised.ProgramId,
                        revised.DraftId, current.ServiceId, current.Kind, current.Identifier,
                        revised.Revision, revised.Statement, revised.Context,
                        revised.SourceReference, revised.ActorMemberId,
                        revised.ActorDisplay, revised.ChangedAt)
                    {
                        Actor = revised.Actor,
                        ProviderId = current.ProviderId,
                    }, ct).ConfigureAwait(false);
                break;
            case CommitmentReviewed reviewed:
                await ApplyReviewedAsync(reviewed, ct).ConfigureAwait(false);
                break;
            case CommitmentApproved approved:
                await ApplyApprovedAsync(approved, ct).ConfigureAwait(false);
                break;
        }
    }

    async ValueTask ApplyReviewedAsync(CommitmentReviewed reviewed, CancellationToken ct)
    {
        var current = await CommitmentDraftDirectorySchema.Drafts.GetAsync(Transaction,
            reviewed.DraftId, ct).ConfigureAwait(false);
        if (current is null || current.TenantId != reviewed.TenantId ||
            current.ProgramId != reviewed.ProgramId || current.Revision != reviewed.Revision)
            throw new InvalidOperationException(
                "A commitment review cannot project before its reviewed revision.");
        var decision = new CommitmentDecisionView(reviewed.TenantId, reviewed.ProgramId,
            reviewed.DraftId, reviewed.DecisionId, reviewed.Revision, reviewed.Outcome,
            reviewed.OwnerReference, reviewed.Applicability, reviewed.Interpretation,
            reviewed.InterpretationNote, reviewed.Rationale, reviewed.Version,
            reviewed.EffectiveFrom, reviewed.ImpactDigest, reviewed.ActorMemberId,
            reviewed.ActorDisplay, reviewed.DecidedAt, reviewed.SeparationOfDutiesWaiverId,
            "review", null, reviewed.SourceVerification, reviewed.SourceVerifiedReference,
            reviewed.SourceEvidence)
        {
            Actor = reviewed.Actor,
        };
        await CommitmentDraftDirectorySchema.Decisions.InsertAsync(Transaction, decision, ct)
            .ConfigureAwait(false);
        var legacyEffective = reviewed.Version is not null && reviewed.EffectiveFrom is not null;
        if (legacyEffective)
            await CommitmentDraftDirectorySchema.Versions.InsertAsync(Transaction,
                new CommitmentVersionView(current.TenantId, current.ProgramId, current.DraftId,
                    current.ServiceId, current.Kind, current.Identifier, reviewed.Version!.Value,
                    current.Revision, current.Statement, current.Context,
                    current.SourceReference, reviewed.OwnerReference!, reviewed.Applicability!,
                    reviewed.Interpretation!, reviewed.InterpretationNote,
                    CommitmentDraft.PerformedBy(current.Kind),
                    CommitmentDraft.IsInternallyPerformed(current.Kind),
                    reviewed.EffectiveFrom!.Value, decision)
                {
                    ProviderId = current.ProviderId,
                }, ct).ConfigureAwait(false);
        var accepted = StringComparer.Ordinal.Equals(reviewed.Outcome, "accept");
        await CommitmentDraftDirectorySchema.Drafts.ReplaceAsync(Transaction, current,
            accepted
                ? current with
                {
                    Status = legacyEffective ? "effective" : "reviewed",
                    SourceResolution = reviewed.SourceVerification ?? current.SourceResolution,
                    OwnerResolution = "verified",
                    ApplicabilityResolution = reviewed.Applicability!,
                }
                : current with { Status = "changes_requested" }, ct).ConfigureAwait(false);
    }

    async ValueTask ApplyApprovedAsync(CommitmentApproved approved, CancellationToken ct)
    {
        var current = await CommitmentDraftDirectorySchema.Drafts.GetAsync(Transaction,
            approved.DraftId, ct).ConfigureAwait(false);
        var review = await CommitmentDraftDirectorySchema.Decisions.GetAsync(Transaction,
            approved.AcceptedReviewDecisionId, ct).ConfigureAwait(false);
        if (current is null || current.TenantId != approved.TenantId ||
            current.ProgramId != approved.ProgramId || current.Revision != approved.Revision ||
            review is null || review.DraftId != approved.DraftId ||
            review.Revision != approved.Revision)
            throw new InvalidOperationException(
                "A commitment approval cannot project before its accepted review.");
        var decision = new CommitmentDecisionView(approved.TenantId, approved.ProgramId,
            approved.DraftId, approved.DecisionId, approved.Revision, "approve", null, null,
            null, null, approved.Rationale, approved.Version, approved.EffectiveFrom,
            approved.ImpactDigest, approved.ActorMemberId, approved.ActorDisplay,
            approved.DecidedAt, approved.SeparationOfDutiesWaiverId, "approval",
            approved.AcceptedReviewDecisionId)
        {
            Actor = approved.Actor,
        };
        await CommitmentDraftDirectorySchema.Decisions.InsertAsync(Transaction, decision, ct)
            .ConfigureAwait(false);
        await CommitmentDraftDirectorySchema.Versions.InsertAsync(Transaction,
            new CommitmentVersionView(current.TenantId, current.ProgramId, current.DraftId,
                current.ServiceId, current.Kind, current.Identifier, approved.Version,
                current.Revision, current.Statement, current.Context, current.SourceReference,
                review.OwnerReference!, review.Applicability!, review.Interpretation!,
                review.InterpretationNote, CommitmentDraft.PerformedBy(current.Kind),
                CommitmentDraft.IsInternallyPerformed(current.Kind), approved.EffectiveFrom,
                review, review.SourceVerification ?? "unverified", review.SourceEvidence,
                decision)
            {
                ProviderId = current.ProviderId,
            }, ct).ConfigureAwait(false);
        await CommitmentDraftDirectorySchema.Drafts.ReplaceAsync(Transaction, current,
            current with { Status = "effective" }, ct).ConfigureAwait(false);
    }

    public async ValueTask<CommitmentVersionView?> GetVersionAsync(Uuid tenantId, Uuid draftId,
        long version, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        return await CommitmentDraftDirectorySchema.Versions.GetAsync(tx,
            CommitmentDraftDirectorySchema.RevisionKey(draftId, version), ct).ConfigureAwait(false);
    }

    public async ValueTask<Page<CommitmentVersionView>> ListVersionsAsync(Uuid tenantId,
        Uuid draftId, int limit, string? cursor, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        return await CommitmentDraftDirectorySchema.Versions.QueryAsync(tx,
            CommitmentDraftDirectorySchema.ByDraftVersion.Query()
                .WithPrefix(draftId.ToString()).Take(Math.Clamp(limit, 1, 200))
                .After(cursor), ct).ConfigureAwait(false);
    }

    public async ValueTask<Page<CommitmentDecisionView>> ListDecisionsAsync(Uuid tenantId,
        Uuid draftId, int limit, string? cursor, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        return await CommitmentDraftDirectorySchema.Decisions.QueryAsync(tx,
            CommitmentDraftDirectorySchema.ByDraftDecision.Query()
                .WithPrefix(draftId.ToString()).Take(Math.Clamp(limit, 1, 200))
                .After(cursor), ct).ConfigureAwait(false);
    }

    public async ValueTask<CommitmentDecisionView?> GetDecisionAsync(Uuid tenantId,
        Uuid decisionId, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        return await CommitmentDraftDirectorySchema.Decisions.GetAsync(tx, decisionId, ct)
            .ConfigureAwait(false);
    }

    public async ValueTask<CommitmentDraftView?> GetAsync(Uuid tenantId, Uuid draftId,
        CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        return await CommitmentDraftDirectorySchema.Drafts.GetAsync(tx, draftId, ct)
            .ConfigureAwait(false);
    }

    public async ValueTask<Page<CommitmentDraftView>> ListProgramAsync(Uuid tenantId,
        Uuid programId, int limit, string? cursor, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        return await CommitmentDraftDirectorySchema.Drafts.QueryAsync(tx,
            CommitmentDraftDirectorySchema.ByProgramKindIdentifier.Query()
                .WithPrefix(programId.ToString()).Take(Math.Clamp(limit, 1, 200))
                .After(cursor), ct).ConfigureAwait(false);
    }

    public async ValueTask<CommitmentDraftRevisionView?> GetRevisionAsync(Uuid tenantId,
        Uuid draftId, long revision, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        return await CommitmentDraftDirectorySchema.Revisions.GetAsync(tx,
                CommitmentDraftDirectorySchema.RevisionKey(draftId, revision), ct)
            .ConfigureAwait(false);
    }
}
