# Commitment native consumer cutover

All changes are offline. Main, Git, GitHub and .NET were untouched. Parent owns compiler, actual RED/GREEN, source review/Jev and integration.

Apply owner54 first (old API RED tests are in that owning artifact). For consumer-specific RED, apply this `implementation-red.patch`, `migrated-tests.patch` and symbolic shared DI/JSON additions. The resulting native code intentionally omits only bounded immutable dependency classification and RecordedThrough guards. Apply `consumer-behavior.tests.patch` / `tests.patch` next, then run all 9 new cases: four content failures and two frozen receipt failures should be RED; large complete content and two cursor-scope rows should pass. Apply `consumer-boundaries.patch` for GREEN. Alternatively the all-GREEN source/test patches are `implementation.patch` and `tests-full.patch`.

Discovery/current/revision/version/decision directories retain scoped cursor and checkpoint behavior, now storing compact identities. List uses captured/confirmed checkpoint around current native composition. All queries remain public producers; no bare identifier/global lookup or missing unblocked handler is deferred. Source-use/current approval authority remains in native owners/readers. Metadata-only commitment existence stays a compact owner read.

Nine baseline source acceptance cases retain native version/evidence/retirement/provider-CSOC semantics plus forged-history refusals. Snapshot publisher capture is preserved. Late frozen receipt approvals/retirements reject transiently; effective-on remains the engagement date. Missing immutable content is transient, corrupt body/schema/scope is permanent, and no partial list page succeeds.

Broker E2E calls were migrated mechanically to selected typed PUT create, draft-revision, review and approval routes; they were not run. Parent's plain Unit first-response bridge must be present for their selected HTTP200 assertions. Original legacy one-step accepted-review projection scenario now tests pure immutable business-content folding. It does not claim an allowed fresh native writer or automatic persisted-v1 migration.

Shared production deltas are only two registrations + one JsonSerializable. Owner54 supplies native public heads/Program additions (all ApiUser). See manifest.json, audit.json, baseline-fixture-handoff.json, existing-file-baseline-audit.json and reconstruction-audit.json for exact evidence.
