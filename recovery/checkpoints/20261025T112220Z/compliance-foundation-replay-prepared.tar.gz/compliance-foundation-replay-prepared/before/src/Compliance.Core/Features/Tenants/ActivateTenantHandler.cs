using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

public sealed class ActivateTenantHandler(IAggregateExecutor executor, IAggregateReader reader,
    ITenantMembershipDirectoryReader memberships, IPermissionAuthorizer permissions)
    : IRequestHandler<ActivateTenant>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<ActivateTenant> context, CancellationToken ct)
    {
        var tenantId = context.Request.TenantId;
        var userId = context.Request.FirstAdministratorUserId;
        var tenant = await reader.HydrateAsync(new Tenant(tenantId), ct).ConfigureAwait(false);
        // A losing concurrent slug claim is terminal. A successful reaction lets the
        // tenant activation reactor checkpoint instead of retrying a rejected registration.
        if (tenant.IsRegistrationRejected)
            return Result.Success;
        // A later administrator invitation, such as operator recovery of a tenant without an
        // active administrator, needs no activation and must not exhaust the reactor's budget.
        if (tenant.HasCompletedActivation)
            return Result.Success;

        var memberId = RbacIds.Member(tenantId, userId);
        var member = await reader.HydrateAsync(new Member(tenantId, userId), ct).ConfigureAwait(false);
        var assignment = await reader.HydrateAsync(new TeamMember(tenantId,
            BuiltInRbac.AdministratorsTeamId(tenantId), memberId), ct).ConfigureAwait(false);
        if (member.IsRegistered && member.Affiliation != "client_personnel")
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The first administrator must be client personnel."));
        if (!member.IsRegistered || !assignment.IsAssigned ||
            assignment.MembershipEpisodeId != member.MembershipEpisodeId ||
            !await memberships.IsMemberAsync(tenantId.ToString(), userId, ct).ConfigureAwait(false) ||
            !await permissions.IsAllowedAsync(tenantId, userId, memberId,
                RbacPermissions.TenantAccess, ct)
                .ConfigureAwait(false) ||
            !await permissions.IsAllowedAsync(tenantId, userId, memberId,
                RbacPermissions.TenantRbacManage, ct)
                .ConfigureAwait(false) ||
            !await permissions.IsAllowedAsync(tenantId, userId, memberId,
                RbacPermissions.ProgramManage, ct)
                .ConfigureAwait(false))
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The first administrator is still being provisioned.", isTransient: true));

        return await executor.ExecuteAsync(new Tenant(tenantId),
            tenant => AggregateOutcome.CommitOnSuccess(tenant.Activate(context.Request.FirstAdministratorUserId,
                context.Request.FirstAdministratorEmail)),
            context, ct).ConfigureAwait(false);
    }
}
