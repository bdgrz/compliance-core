# Foundation replay patch sets

All preparation is outside the checkout. No builds/tests were started here, no index/branch/PR/GitHub writes were made, and no new issues were created. Parent owns integration, strict compilation, behavioral RED/GREEN, full tests and direct current-file Jev review. `manifest.json` records baseline/proposed hashes and group boundaries. `before/`, `after/` and `validation/` are plain file snapshots, not Git worktrees.

## Consumed by parent

- `grant-access`: complete original issuance receipt before mutable membership/role/source selection; exact original Issue after revocation returns original success without restoring authority or changing the original membership episode. Current caller RBAC authorization remains required. RED filter is **GrantAccessReplayTests**, plus AccessGrantTests. The prior README's AccessGrantReplayTests spelling was wrong.
- `freeze-revision`: stores the original authored ExpectedRevision on the immutable snapshot and checks all original freeze retry/reconciliation branches. Parent also added a direct owner clock RED and removed RecordedAt from SameSnapshot intent equality. Parent's extra clock correction is authoritative; do not reapply the consumed owner patch over it.

The freeze CommandId/native admission migration is still a separate catalog task; this consumed patch fixes the confirmed original-revision defect only.

## Next integration-ready groups

Each group contains `tests.patch`, `implementation.patch`, `migrated-tests.patch`, and a route-only parent-owned `shared-deltas.patch` where required.

For each group:

1. Apply tests.patch and run its RED filter against the old API. These are behavioral tests; they do not require the new command constructors.
2. Apply implementation.patch and migrated-tests.patch together. Where the same test file needs a constructor migration, the migration patch starts from the RED-stage file, not from the original file.
3. Parent applies/reproduces shared-deltas.patch in Program.cs, then runs strict build, focused tests, contract/export checks and full units, and reviews the final production files through Jev.

All 15 staged patch applications (five groups times three phases) were applied successfully to isolated plain-file copies and reproduced every proposed SHA; see applicability.json. No compiler or test execution is claimed by that check.

### Ratification

RED filter: `FullyQualifiedName~ShouldReturnOriginalRatificationGivenImmediateExactHandlerRetry`.

The new RED seeds real signed professional authority and a first ratification through existing fixtures, publishes the next draft, ratifies it through the actual handler, then retries the same context. Current code rejects it because the accepted sequence already advanced.

The implementation adds required CommandId and owner ExpectedRevision, retains the complete original authored request/actor/result already carried by the ratification receipt, and resolves that receipt after current professional authorization but before mutable rule and sequence reads. Actor display refreshes preserve the original recorded display. Changed original owner revision conflicts before checking new-operation sequence consistency. Existing signed duty expiry/revocation/continuity tests stay intact.

Focused GREEN: `ProfessionalDutyGovernanceCompositionTests|IndependenceRuleRatificationCatalogTests|CurrentRatifiedIndependenceRulesReaderTests` (use actual class inventory for the final family filter). Shared route becomes the catalog-selected identified PUT.

### Risk drafts

RED filter: `FullyQualifiedName~ShouldConflictGivenCreateRetryWithChangedOriginalActor`.

Creation now requires the authored RiskId. As parent confirmed from the selected catalog and commitment precedent, it must equal the existing UUIDv5 IdFor(tenant, program, normalized identifier). Mismatches are rejected; the supplied ID is never silently replaced, and identifier uniqueness retains its current atomic owner boundary. New typed creations retain full original authored digest and actor, return original revision-one registration after later edits, and resolve before mutable program validation.

Revision requires CommandId and retains only that selected revision receipt during owner hydration; no lifetime revision receipt dictionary is added. Exact original retry after later edits returns Unit without changing the current draft. Actor, content and original revision changes conflict. New tests cover round-trip hydration, normalized-ID mismatch, creation actor/intent and selected revision binding. Existing legacy direct seed methods remain available for historical fixtures, while production handlers use the typed paths.

Focused GREEN: `RiskDraftTests|RiskDraftCreationIdentityTests|RiskDraftRevisionIdentityTests` plus risk draft/API consumers. Shared creation route becomes selected PUT `.../risks/{risk_id}`. Existing revise MCP/internal command gains required CommandId; the catalog does not select a replacement HTTP edit route, so this patch does not invent one.

### Risk evaluation

RED filter: `FullyQualifiedName~ShouldConflictGivenAssessmentRetryWithChangedOriginalAuthoredBinding` (three rationale/actor/original-revision cases).

Assessment, treatment choice and personal acceptance gain required typed CommandId. Assessment and acceptance business facts freeze the full original authored digest, actor and expected owner revision; treatment keeps one selected receipt during hydration. Reuse of one selected owner command ID for another command kind conflicts. Replays return original views/Unit and do not restore later treatment or reassessment state. Acceptance rechecks current specific acceptance authority before returning any cached result.

RiskEvaluation no longer calls a live SeparationOfDutiesWaiver owner. The existing exact immutable proof resolver validates the source approval; the receiving owner compares immutable scope, beneficiary/actor, target/version/revision, source locator and validity time, and retains that proof on the accepted fact. Existing owner and handler waiver/SoD coverage is migrated rather than removed. Production DI already registers the resolver; the test-only work fixture now registers the same resolver over its real in-memory source facts.

Focused GREEN: `RiskEvaluationTests|RiskAssessmentIdentityTests|RiskTreatmentIdentityTests|RiskAcceptanceIdentityTests|RiskGovernanceHandlerTests|RiskAcceptanceWork` plus provider/baseline consumers. Shared identified PUTs are selected for assessment and acceptance; treatment's existing MCP/internal selection gains required CommandId without inventing another HTTP route.

### Evidence support

RED filter: `FullyQualifiedName~ShouldReturnOriginalSupportGivenAcceptedRetryAfterTargetRevisionAdvances`.

The RED creates a real available artifact and control, accepts support, advances the control, then retries the original support. Current code rejects it before reading the accepted assertion.

CommandId becomes the immutable assertion identity and ExpectedRevision is owner-local (initial zero). The accepted fact retains its full original authored digest, actor and original revision, and its existing complete content returns the original EvidenceSupportView. The handler requires current personal HTTP/artifact disclosure authorization, then resolves original receipt before current artifact availability and exact-target selection. Fresh requests still perform all source/period/current-target fences. Existing source, scope, period, personal transport and attribution tests remain. Shared route becomes selected PUT `.../supports/{command_id}`.

Focused GREEN: `EvidenceSupportTests|LinkEvidenceSupportHandlerTests|AdvisorRecordVersionResolverTests|EvidenceGovernanceTypeIBaselineSourceContributorTests`.

### Tenant activation (additional bounded group)

RED filter: `FullyQualifiedName~ShouldRejectChangedOriginalBootstrapGivenSameActivationIdentityAfterSuccess`.

The RED first activates a genuinely seeded creator/admin tenant, then reuses the same execution identity with another administrator. Its fixture-only constructor adapter supports the old and new DTO shapes, so no contract scaffold is needed. The old handler's completed shortcut returns success; the selected native operation must conflict without another fact. Existing completed/rejected receiver no-ops remain deliberate for distinct operations.

ActivateTenant gains the selected required CommandId and identified dispatch. New native TenantActivatedV2 freezes original authored administrator/email, actor, owner, command kind, episode and Unit response; V1 remains readable. The actual handler resolves the selected owner acceptance before mutable bootstrap/membership/permission reads. Fresh operations retain the existing trusted system, creator/invited email, current member affiliation, membership episode, admin team and all three permission fences. The two bootstrap reactors derive their command identity from the exact committed source event plus tenant/administrator target. Directory hydration/projection consumes both fact versions and preserves suspended/offboarding status.

Shared delta is JSON registration only: `TenantActivatedV2` in ComplianceCoreJsonContext. There is no new HTTP route or production DI requirement. The focused GREEN family includes `ActivateTenantReadinessTests|ActivateTenantIdentityTests|TenantActivationEffectsTests|TenantSelfServiceActivationReactorTests|TenantInvitationReactorTests|TenantDirectory` and native operation/contract checks. The existing legacy owner activation helper stays for trusted fixture/history construction. No source main files were edited and no compiler/test execution is claimed during this preparation.

## Qualification boundaries and remaining local work

New receipt metadata is omitted when absent on older facts, preserving legacy canonical shapes. New typed retries against historical facts without a provable original binding fail closed instead of guessing intent. Existing history/query facts are not removed. Persisted-data compatibility still needs explicit qualification before any rollout; local unit/patch checks are not deployment evidence.

#1042 still limits bare-operation status/result lookup and cross-route global dedupe, not these owner writes. There is no external blocker for these patch groups. The earlier speculative arbitrary-RiskId blocker is removed: the selected-ID validation above preserves the existing documented deterministic identity.

The broader freeze admission remains queued as separate independent work. Do not describe these bounded patch sets as completion of every remaining owner/protocol catalog entry.
