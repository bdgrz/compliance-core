from pathlib import Path
import hashlib,json,difflib,shutil,re
ROOT=Path('/Users/jrepanich/Code/bdgrz/compliance-core');OUT=Path('/tmp/compliance-foundation-replay-prepared')
BEFORE=OUT/'before';AFTER=OUT/'after'
if AFTER.exists():shutil.rmtree(AFTER)
prior=json.loads((OUT/'manifest.json').read_text()) if (OUT/'manifest.json').exists() else []
prior_by_path={row['path']:row for row in prior}
changed={}
def original(path):
 if path in prior_by_path and prior_by_path[path]['beforeSha256'] is None:return None
 if (BEFORE/path).exists():return (BEFORE/path).read_text()
 return (ROOT/path).read_text() if (ROOT/path).exists() else None
def put(path,text,group,phase='implementation'):
 old=original(path)
 if path not in changed:
  changed[path]={'before':old,'group':group,'phase':phase}
  if old is not None:
   p=BEFORE/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(old)
 p=AFTER/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
def edit(path,fn,group,phase='implementation'):
 s=(AFTER/path).read_text() if (AFTER/path).exists() else original(path)
 put(path,fn(s),group,phase)
core='src/Compliance.Core/Features/'
common='src/Compliance.Common/Features/'
tests='test/Compliance.Tests/Features/'
# GrantId is already the immutable creation identity; the issued fact holds the complete original terms.
p=core+'AccessControl/AccessGrant.cs'
def grant_owner(s):
 old='''        if (_terms is not null)
            return _isRevoked
                ? Result.Failure(new RequestError(RequestErrorKind.Conflict,
                    "A revoked access grant cannot be reissued."))
                : _terms == terms && _membershipEpisodeId == membershipEpisodeId
                ? Result.Success
                : Result.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The access grant already has different terms."));'''
 new='''        if (ReplayIssue(new AccessGrantProposal(terms.Principal, terms.RoleId, terms.Scope,
                terms.Source, terms.EffectiveFrom, terms.EffectiveUntil), terms.GrantedBy) is { } retry)
            return retry;'''
 assert old in s;s=s.replace(old,new)
 at=s.index('    public Result Revoke(')
 s=s[:at]+'''    /// <summary>
    /// Resolves the immutable creation receipt without consulting current grant, member, role or source state.
    /// A successful replay never reissues a revoked grant or rebinds its original membership episode.
    /// </summary>
    public Result? ReplayIssue(AccessGrantProposal? proposal, ActorReference actor)
    {
        if (_terms is not { } original)
            return null;
        var authored = new AccessGrantProposal(original.Principal, original.RoleId, original.Scope,
            original.Source, original.EffectiveFrom, original.EffectiveUntil);
        return proposal == authored && actor.Kind == original.GrantedBy.Kind && actor.Id == original.GrantedBy.Id
            ? Result.Success
            : Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The grant identity already accepted another proposal or original actor."));
    }

'''+s[at:]
 return s
edit(p,grant_owner,'grant-access')
put(core+'AccessControl/GrantAccessHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AccessControl;

public sealed class GrantAccessHandler(IAggregateExecutor executor,
    IAccessGrantProposalValidator validator, IMemberAccessEligibility memberAccess, IAggregateReader reader)
    : IRequestHandler<GrantAccess>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<GrantAccess> context, CancellationToken ct)
    {
        var request = context.Request;
        if (request.TenantId == Uuid.Empty || request.GrantId == Uuid.Empty)
            return Result.Failure(new RequestError(RequestErrorKind.Validation,
                "An access grant requires its tenant and immutable grant identity."));
        var actor = AccessGrantActor.From(context, request.TenantId);
        var original = await ReplayAsync().ConfigureAwait(false);
        if (original is { } retry)
            return retry;
        var proposal = request.Proposal;
        if (proposal is null || proposal.Principal is null)
            return await FailureAsync(await validator.ValidateAsync(request.TenantId, proposal!, ct)
                .ConfigureAwait(false)).ConfigureAwait(false);

        Uuid? membershipEpisodeId = null;
        if (proposal.Principal.Kind == AccessGrantPrincipalKind.Member)
        {
            membershipEpisodeId = await memberAccess.GetMembershipEpisodeIdAsync(request.TenantId,
                proposal.Principal.Id, ct).ConfigureAwait(false);
            if (membershipEpisodeId is null)
                return await FailureAsync(Result.Failure(new RequestError(RequestErrorKind.NotFound,
                    "The access grant member was not found in this organization."))).ConfigureAwait(false);
        }
        var validation = await validator.ValidateAsync(request.TenantId, proposal, ct).ConfigureAwait(false);
        if (!validation.IsSuccess)
            return await FailureAsync(validation).ConfigureAwait(false);
        if (proposal.Principal.Kind == AccessGrantPrincipalKind.Member)
        {
            var currentEpisodeId = await memberAccess.GetMembershipEpisodeIdAsync(request.TenantId,
                proposal.Principal.Id, ct).ConfigureAwait(false);
            if (currentEpisodeId != membershipEpisodeId)
                return await FailureAsync(Result.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The member's tenant authority changed while the grant was being prepared."))).ConfigureAwait(false);
            if (membershipEpisodeId == Uuid.Empty)
                membershipEpisodeId = null;
        }
        var terms = new AccessGrantTerms(proposal.Principal, proposal.RoleId, proposal.Scope,
            proposal.Source, actor, proposal.EffectiveFrom, proposal.EffectiveUntil);
        try
        {
            var committed = await executor.ExecuteAsync(new AccessGrant(request.TenantId, request.GrantId),
                grant => AggregateOutcome.CommitOnSuccess(grant.Issue(terms, membershipEpisodeId)), context, ct)
                .ConfigureAwait(false);
            return committed.IsSuccess ? committed : await FailureAsync(committed).ConfigureAwait(false);
        }
        catch (EventStreamConcurrencyException)
        {
            var resolved = await ReplayAsync().ConfigureAwait(false);
            if (resolved is { } accepted)
                return accepted;
            throw;
        }

        async ValueTask<Result?> ReplayAsync()
        {
            var grant = await reader.HydrateAsync(new AccessGrant(request.TenantId, request.GrantId), ct)
                .ConfigureAwait(false);
            return grant.ReplayIssue(request.Proposal, actor);
        }
        async ValueTask<Result> FailureAsync(Result failure) =>
            await ReplayAsync().ConfigureAwait(false) ?? failure;
    }
}
''','grant-access')
# Current constructor consumers migrate only after RED; no current acceptance scenario is removed.
edit(tests+'AccessControl/GrantAccessHandlerTests.cs',lambda s:s.replace(
 'new ValidProposalValidator(), new TestMemberAccessEligibility(episodeId, episodeId));',
 'new ValidProposalValidator(), new TestMemberAccessEligibility(episodeId, episodeId), provider.GetRequiredService<IAggregateReader>());').replace(
 'new ValidProposalValidator(), new TestMemberAccessEligibility(firstEpisodeId, secondEpisodeId));',
 'new ValidProposalValidator(), new TestMemberAccessEligibility(firstEpisodeId, secondEpisodeId), provider.GetRequiredService<IAggregateReader>());'),
 'grant-access','migrated-tests')
# The existing old rejection assertion changes to the selected original-result semantics, while preserving no resurrection.
p=tests+'AccessControl/AccessGrantTests.cs'
def grant_tests(s):
 start=s.index('    public void ShouldRejectReissueGivenPreviouslyRevokedGrantId()')
 end=s.index('    [Fact]',start)
 body=s[start:end].replace('ShouldRejectReissueGivenPreviouslyRevokedGrantId','ShouldReplayOriginalCreationWithoutRestoringAuthorityGivenPreviouslyRevokedGrantId')
 body=body.replace('''        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error.Kind);''',
 '''        Assert.True(result.IsSuccess);
        Assert.True(scenario.Aggregate.IsRevoked);''')
 return s[:start]+body+s[end:]
edit(p,grant_tests,'grant-access','tests')
put(tests+'AccessControl/GrantAccessReplayTests.cs','''using System.Security.Claims;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.AccessControl;

public sealed class GrantAccessReplayTests
{
    [Fact]
    public async Task ShouldReplayWithoutReselectingRetiredMemberOrRoleGivenOriginalAcceptedGrant()
    {
        // Arrange
        await using var fixture = new Fixture();
        var request = fixture.Request();
        var handler = fixture.Handler();
        Assert.True((await handler.HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        fixture.Members.Available = false;
        fixture.Validator.Available = false;

        // Act
        var result = await handler.HandleAsync(fixture.Context(request), CancellationToken.None);
        var grant = await fixture.Reader.HydrateAsync(new AccessGrant(request.TenantId, request.GrantId));

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(1UL, grant.CommittedStreamPosition);
        Assert.False(grant.IsRevoked);
    }

    [Fact]
    public async Task ShouldKeepRevocationAndOriginalEpisodeGivenRetryAfterAuthorityRetirement()
    {
        // Arrange
        await using var fixture = new Fixture();
        var request = fixture.Request();
        var handler = fixture.Handler();
        Assert.True((await handler.HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var grant = await fixture.Reader.HydrateAsync(new AccessGrant(request.TenantId, request.GrantId));
        Assert.True(grant.Revoke(ActorReference.ForMember(Uuid.CreateVersion4(), "Administrator"), DateTimeOffset.UtcNow).IsSuccess);
        await fixture.Writer.SaveAsync(grant, fixture.Context(request));
        fixture.Members.Available = false;

        // Act
        var result = await handler.HandleAsync(fixture.Context(request), CancellationToken.None);
        var current = await fixture.Reader.HydrateAsync(new AccessGrant(request.TenantId, request.GrantId));

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.True(current.IsRevoked);
        Assert.Equal(fixture.Members.Episode, current.MembershipEpisodeId);
        Assert.Equal(2UL, current.CommittedStreamPosition);
    }

    sealed class Fixture : IAsyncDisposable
    {
        readonly ServiceProvider _provider;
        readonly AsyncServiceScope _scope;
        readonly Uuid _tenant = Uuid.CreateVersion4();
        readonly ClaimsPrincipal _actor = new(new ClaimsIdentity(
            [new Claim("iss", "bdgrz"), new Claim("sub", Uuid.CreateVersion4().ToString())], "BdgrzSession"));
        public MemberEligibility Members { get; } = new();
        public ProposalValidator Validator { get; } = new();
        public IAggregateReader Reader { get; }
        public IAggregateWriter Writer { get; }
        public Fixture()
        {
            var services = new ServiceCollection();
            services.AddSingleton<IEventStore>(new InMemoryEventStore());
            services.AddSingleton<IMemberAccessEligibility>(Members);
            services.AddSingleton<IAccessGrantProposalValidator>(Validator);
            services.AddPortia();
            _provider = services.BuildServiceProvider();
            _scope = _provider.CreateAsyncScope();
            Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();
            Writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
        }
        public GrantAccessHandler Handler() => ActivatorUtilities.CreateInstance<GrantAccessHandler>(_scope.ServiceProvider);
        public Cntryl.Portia.RequestContext<GrantAccess> Context(GrantAccess request) => new(request, _actor);
        public GrantAccess Request() => new(_tenant, Uuid.CreateVersion4(), new(
            new(AccessGrantPrincipalKind.Member, Uuid.CreateVersion4()), Uuid.CreateVersion4(),
            new(AccessGrantScopeKind.Program, Uuid.CreateVersion4()), new("manual", "review"),
            DateTimeOffset.UtcNow.AddDays(-1), null));
        public async ValueTask DisposeAsync()
        {
            await _scope.DisposeAsync();
            await _provider.DisposeAsync();
        }
    }
    sealed class MemberEligibility : IMemberAccessEligibility
    {
        public bool Available { get; set; } = true;
        public Uuid Episode { get; } = Uuid.CreateVersion4();
        public ValueTask<bool> IsEligibleAsync(Uuid tenantId, Uuid userId, CancellationToken ct = default) => ValueTask.FromResult(Available);
        public ValueTask<Uuid?> GetMembershipEpisodeIdAsync(Uuid tenantId, Uuid memberId, CancellationToken ct = default) =>
            ValueTask.FromResult<Uuid?>(Available ? Episode : null);
    }
    sealed class ProposalValidator : IAccessGrantProposalValidator
    {
        public bool Available { get; set; } = true;
        public ValueTask<Result> ValidateAsync(Uuid tenantId, AccessGrantProposal proposal, CancellationToken ct = default) =>
            ValueTask.FromResult(Available ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Validation, "Current role unavailable.")));
    }
}
''','grant-access','tests')
# Freeze binds its original authored revision on the immutable snapshot; legacy unknown binding fails closed.
edit(common+'Operations/TypeIIPeriodCloseSnapshotView.cs',lambda s:s.replace('''    DateTimeOffset RecordedAt);''','''    DateTimeOffset RecordedAt)
{
    /// <summary>The authored period revision accepted by an original close freeze; absent on historical unbound snapshots.</summary>
    public long? OriginalExpectedRevision { get; init; }
}
'''),'freeze-revision')
edit(core+'Operations/TypeIIPeriod.cs',lambda s:s.replace(
 'return SameSnapshot(prior, content, actorMemberId, actorRole, frozenAt) ? null :',
 'return prior.OriginalExpectedRevision == expectedRevision &&\n                   SameSnapshot(prior, content, actorMemberId, actorRole, frozenAt) ? null :').replace(
 'frozenAt, null, null, [], []);','frozenAt, null, null, [], []) with { OriginalExpectedRevision = expectedRevision };'),
 'freeze-revision')
p=core+'Operations/FreezeTypeIIPeriodCloseHandler.cs'
def freeze_handler(s):
 s=s.replace('MatchesFrozenSnapshot(existing, content, memberId, role)',
             'MatchesFrozenSnapshot(existing, content, memberId, role, request.ExpectedRevision)')
 s=s.replace('MatchesFrozenSnapshot(snapshot, content, memberId, role)',
             'MatchesFrozenSnapshot(snapshot, content, memberId, role, request.ExpectedRevision)')
 s=s.replace('TypeIIPeriodCloseSnapshotContent content, Uuid memberId, string role) =>',
             'TypeIIPeriodCloseSnapshotContent content, Uuid memberId, string role, long expectedRevision) =>')
 s=s.replace('snapshot.CloseSnapshotId == content.CloseSnapshotId && snapshot.Version == 1 &&',
             'snapshot.CloseSnapshotId == content.CloseSnapshotId && snapshot.OriginalExpectedRevision == expectedRevision &&\n        snapshot.Version == 1 &&')
 return s
edit(p,freeze_handler,'freeze-revision')
p=tests+'Operations/TypeIIPeriodCommandHandlerTests.cs'
def freeze_red(s):
 start=s.index('    [Fact]\n    public async Task ShouldReplayFreezeWithoutAppendingGivenCloseFreezeRetryAfterClockAdvances()')
 end=s.index('    [Fact]',start+11)
 method=s[start:end]
 method=method.replace('ShouldReplayFreezeWithoutAppendingGivenCloseFreezeRetryAfterClockAdvances',
                       'ShouldConflictWithoutAppendingGivenFreezeRetryWithChangedOriginalRevision')
 method=method.replace('handler.HandleAsync(context, CancellationToken.None);\n        var period',
 '''handler.HandleAsync(fixture.Context(request with { ExpectedRevision = request.ExpectedRevision + 1 }), CancellationToken.None);
        var period''')
 method=method.replace('Assert.True(retry.IsSuccess, retry.Error?.Message);','Assert.Equal(RequestErrorKind.Conflict, retry.Error?.Kind);')
 return s[:end]+method+s[end:]
edit(p,freeze_red,'freeze-revision','tests')
# Ratification already retains its complete immutable authored decision. Use a typed command identity and resolve it
# after current professional authorization but before mutable draft/ratification validation.
edit(common+'AccessControl/RatifyIndependenceRuleVersion.cs',lambda s:s.replace(
 'record RatifyIndependenceRuleVersion(Uuid RatificationId,', 'record RatifyIndependenceRuleVersion(Uuid CommandId, Uuid RatificationId,').replace(
 'string SourceReference) :', 'string SourceReference, long ExpectedRevision) :'), 'ratification')
p=core+'AccessControl/IndependenceRuleRatificationCatalog.cs'
def ratify_owner(s):
 s=s.replace('new RatifyIndependenceRuleVersion(ratificationId, ruleVersion,\n            observedRuleCatalogSequence, expectedRatificationSequence, ruleContentDigest, sourceReference)',
 'new RatifyIndependenceRuleVersion(requestId, ratificationId, ruleVersion,\n            observedRuleCatalogSequence, expectedRatificationSequence, ruleContentDigest, sourceReference, expectedRatificationSequence)')
 s=s.replace('new RatifyIndependenceRuleVersion(item.RatificationId, item.RuleVersion,\n            item.ObservedRuleCatalogSequence, ev.ExpectedSequence, item.RuleContentDigest, item.SourceReference)',
 'new RatifyIndependenceRuleVersion(ev.RequestId, item.RatificationId, item.RuleVersion,\n            item.ObservedRuleCatalogSequence, ev.ExpectedSequence, item.RuleContentDigest, item.SourceReference, ev.ExpectedSequence)')
 pos=s.index('    Result<IndependenceRuleRatificationView>? Retry(')
 s=s[:pos]+'''    /// <summary>Resolves a complete original authored ratification without reselecting the mutable draft.</summary>
    public Result<IndependenceRuleRatificationView>? Replay(RatifyIndependenceRuleVersion request, ActorReference actor) =>
        Retry(request.CommandId, request, actor);

'''+s[pos:]
 s=s.replace('previous.Intent == Intent(request) && previous.Actor == actor',
 'previous.Intent == Intent(request) && previous.Actor.Kind == actor.Kind && previous.Actor.Id == actor.Id')
 return s
edit(p,ratify_owner,'ratification')
p=core+'AccessControl/RatifyIndependenceRuleVersionHandler.cs'
def ratify_handler(s):
 s=s.replace('''        var request = context.Request;
''','''        var request = context.Request;
        if (request.CommandId == Uuid.Empty || request.ExpectedRevision < 0 ||
            request.ExpectedRevision != request.ExpectedRatificationSequence)
            return Refuse(RequestErrorKind.Validation,
                "Ratification requires its command identity and exact authored catalog revision.");
''',1)
 marker='''        var rules = await reader.HydrateAsync(new IndependenceRuleCatalog(), ct).ConfigureAwait(false);'''
 s=s.replace(marker,'''        var actor = ActorReference.ForFirmStaff(userId, UserIdentityClaims.BdgrzDisplay(context.Actor, userId));
        var ratifications = await reader.HydrateAsync(new IndependenceRuleRatificationCatalog(), ct)
            .ConfigureAwait(false);
        if (ratifications.Replay(request, actor) is { } original)
            return original;

'''+marker)
 dup='''        var actor = ActorReference.ForFirmStaff(userId, UserIdentityClaims.BdgrzDisplay(context.Actor, userId));
        var ratifications = await reader.HydrateAsync(new IndependenceRuleRatificationCatalog(), ct)
            .ConfigureAwait(false);
'''
 first=s.index(dup);second=s.index(dup,first+len(dup));s=s[:second]+s[second:].replace(dup,'',1)
 s=s.replace('catalog.Ratify(context.RequestId, request.RatificationId,','catalog.Ratify(request.CommandId, request.RatificationId,')
 return s
edit(p,ratify_handler,'ratification')
p=tests+'AccessControl/ProfessionalDutyGovernanceCompositionTests.cs'
def ratify_tests(s):
 # These two calls author catalog revision zero, which is also their selected owner revision.
 s=s.replace('new RatifyIndependenceRuleVersion(Uuid.CreateVersion4(),','new RatifyIndependenceRuleVersion(Uuid.CreateVersion4(), Uuid.CreateVersion4(),')
 s=s.replace('"Synthetic ratification source")','"Synthetic ratification source", 0)').replace('"Synthetic ratification evidence")','"Synthetic ratification evidence", 0)')
 return s
edit(p,ratify_tests,'ratification','migrated-tests')
# Preserve the existing normalized identifier uniqueness boundary while correcting actor attribution on create.
# Revisions have a typed CommandId and retain only the selected revision receipt during hydration.
edit(common+'Risks/ReviseRiskDraft.cs',lambda s:s.replace('record ReviseRiskDraft(Uuid TenantId,',
 'record ReviseRiskDraft(Uuid CommandId, Uuid TenantId,'),'risk-draft')
edit(common+'Risks/RiskDraftRevised.cs',lambda s:s.replace('''{
    [JsonPropertyName("actor")]''','''{
    public Uuid? CommandId { get; init; }
    public long? OriginalExpectedRevision { get; init; }
    public string? AuthoredIntentSha256 { get; init; }

    [JsonPropertyName("actor")]'''),'risk-draft')
p=core+'Risks/RiskDraft.cs'
def draft(s):
 s=s.replace('using System.Text.Json;', 'using System.Text.Json;\nusing Bdgrz.Compliance.Features.Kernel;')
 s=s.replace('    RiskDraftContent? _initialContent;', '''    RiskDraftContent? _initialContent;
    Uuid _createActorMemberId;
    readonly Uuid _selectedCommandId;
    RiskDraftRevised? _selectedRevision;''')
 s=s.replace('public RiskDraft(Uuid tenantId, Uuid riskId)', 'public RiskDraft(Uuid tenantId, Uuid riskId, Uuid selectedCommandId = default)')
 s=s.replace('''        _tenantId = tenantId;''','''        _tenantId = tenantId;
        _selectedCommandId = selectedCommandId;''',1)
 s=s.replace('''            _initialContent = ev.Content;''','''            _initialContent = ev.Content;
            _createActorMemberId = ev.ActorMemberId;''')
 s=s.replace('''        On<RiskDraftRevised>(ev => _revision = ev.Revision);''','''        On<RiskDraftRevised>(ev =>
        {
            _revision = ev.Revision;
            if (_selectedCommandId != Uuid.Empty && ev.CommandId == _selectedCommandId)
            {
                if (_selectedRevision is not null)
                    throw new InvalidOperationException("A revision command is accepted once on its risk owner.");
                _selectedRevision = ev;
            }
        });''')
 s=s.replace('''ProgramId == programId && _createRequestId == createRequestId &&''',
 '''ProgramId == programId && _createRequestId == createRequestId && _createActorMemberId == actorMemberId &&''')
 pos=s.index('    public CommandFailure? Revise(Uuid programId,')
 s=s[:pos]+'''    /// <summary>Resolves the selected authored revision before current owner revision validation.</summary>
    public CommandFailure? Revise(ReviseRiskDraft request, Uuid actorMemberId, string actorDisplay,
        DateTimeOffset changedAt)
    {
        if (request.CommandId == Uuid.Empty || request.CommandId != _selectedCommandId ||
            request.TenantId != _tenantId || request.RiskId != Id)
            return CommandFailure.InvalidContent("A revision requires its selected typed command identity and exact owner.");
        var digest = AuthoredIntentDigest.Compute(request);
        if (_selectedRevision is { } original)
            return original.ActorMemberId == actorMemberId && original.ProgramId == request.ProgramId &&
                   original.OriginalExpectedRevision == request.ExpectedRevision && original.AuthoredIntentSha256 == digest
                ? null : CommandFailure.StateConflict("The revision identity already accepted another actor or authored intent.");
        var before = _revision;
        var failure = Revise(request.ProgramId, request.ExpectedRevision,
            new(request.Title, request.Scenario, request.PotentialEffect, request.SourceNote), actorMemberId, actorDisplay,
            changedAt, request.CommandId, digest);
        if (failure is null && _revision != before + 1)
            throw new InvalidOperationException("A new risk revision must append exactly one decision.");
        return failure;
    }

'''+s[pos:]
 s=s.replace('''        Uuid actorMemberId, string actorDisplay, DateTimeOffset changedAt)
    {
        if (!_created''',
 '''        Uuid actorMemberId, string actorDisplay, DateTimeOffset changedAt, Uuid? commandId = null,
        string? authoredIntentSha256 = null)
    {
        if (!_created''',1)
 s=s.replace('''RiskDraftRevised revised = new(_tenantId, programId, Id, _revision + 1,
            Clean(content), actorMemberId, actorDisplay, changedAt)
        {
            StoredActor''',
 '''RiskDraftRevised revised = new(_tenantId, programId, Id, _revision + 1,
            Clean(content), actorMemberId, actorDisplay, changedAt)
        {
            CommandId = commandId,
            OriginalExpectedRevision = commandId is null ? null : expectedRevision,
            AuthoredIntentSha256 = authoredIntentSha256,
            StoredActor''')
 return s
edit(p,draft,'risk-draft')
p=core+'Risks/ReviseRiskDraftHandler.cs'
def revise_handler(s):
 s=s.replace('''        var request = context.Request;''','''        var request = context.Request;
        if (request.CommandId == Uuid.Empty)
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Validation,
                "A risk revision requires its typed command identity.")));''')
 start=s.index('        RiskDraftContent content =')
 end=s.index('        return executor.ExecuteAsync',start)
 s=s[:start]+s[end:]
 s=s.replace('new RiskDraft(request.TenantId, request.RiskId)', 'new RiskDraft(request.TenantId, request.RiskId, request.CommandId)')
 s=s.replace('''risk.Revise(request.ProgramId,
                request.ExpectedRevision, content,''','''risk.Revise(request,''')
 return s
edit(p,revise_handler,'risk-draft')
# Add an API-compatible behavioral RED case for original create actor binding.
p=tests+'Risks/RiskDraftTests.cs'
def draft_actor_red(s):
 at=s.index('    [Fact]')
 method='''    [Fact]
    public void ShouldConflictGivenCreateRetryWithChangedOriginalActor()
    {
        // Arrange
        var requestId = Uuid.CreateVersion4();
        var risk = new RiskDraft(TenantId, RiskDraft.IdFor(TenantId, ProgramId, "R-01"));
        Assert.True(risk.Create(ProgramId, requestId, "R-01", Content(), ActorId, "Original author", Now).IsSuccess);

        // Act
        var result = risk.Create(ProgramId, requestId, "R-01", Content(), Uuid.CreateVersion4(), "Different author", Now);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.Equal(1, risk.Revision);
    }

'''
 return s[:at]+method+s[at:]
edit(p,draft_actor_red,'risk-draft','tests')
# The assessment business history retains complete facts, including the exact original authored request binding.
edit(common+'Risks/RecordRiskAssessment.cs',lambda s:s.replace('record RecordRiskAssessment(Uuid TenantId,',
 'record RecordRiskAssessment(Uuid CommandId, Uuid TenantId,'),'risk-evaluation')
edit(common+'Risks/RiskAssessmentRecorded.cs',lambda s:s.replace('long Revision, RiskAssessmentView Assessment) : DomainEvent;',
 '''long Revision, RiskAssessmentView Assessment) : DomainEvent
{
    public long? OriginalExpectedRevision { get; init; }
    public string? AuthoredIntentSha256 { get; init; }
}'''),'risk-evaluation')
p=core+'Risks/RiskEvaluation.cs'
def assessment_owner(s):
 s=s.replace('using Bdgrz.Compliance.Features.Versioning;', 'using Bdgrz.Compliance.Features.Versioning;\nusing Bdgrz.Compliance.Features.Kernel;')
 s=s.replace('readonly List<RiskAssessmentView> _assessments', 'readonly List<RiskAssessmentRecorded> _assessments')
 s=s.replace('_assessments.Add(ev.Assessment);','_assessments.Add(ev);')
 s=s.replace('_assessments.LastOrDefault(assessment => assessment.Phase == phase);',
 '_assessments.LastOrDefault(fact => fact.Assessment.Phase == phase)?.Assessment;')
 s=s.replace('_assessments.Find(assessment => assessment.AssessmentId == assessmentId);',
 '_assessments.Find(fact => fact.Assessment.AssessmentId == assessmentId)?.Assessment;')
 s=s.replace('[.. _assessments], Treatment,', '[.. _assessments.Select(static fact => fact.Assessment)], Treatment,')
 start=s.index('        if (FindAssessment(assessmentId) is { } existing)')
 end=s.index('        var scope = CheckScope',start)
 s=s[:start]+'''        if (assessmentId == Uuid.Empty)
            return CommandFailure.InvalidContent("An assessment requires its authored command identity.");
        var authored = new RecordRiskAssessment(assessmentId, _tenantId, programId, Id, expectedRevision,
            method.Version, phase, likelihood, impact, rationale);
        if (ReplayAssessment(authored, assessorMemberId) is { } retry)
            return retry.IsSuccess ? null : CommandFailure.StateConflict(retry.Error!.Message!);
'''+s[end:]
 old='''                ActorReference.ForMember(assessorMemberId, assessorDisplay), assessedAt)));'''
 new='''                ActorReference.ForMember(assessorMemberId, assessorDisplay), assessedAt))
        {
            OriginalExpectedRevision = expectedRevision,
            AuthoredIntentSha256 = AuthoredIntentDigest.Compute(authored),
        });'''
 assert old in s;s=s.replace(old,new,1)
 pos=s.index('    public CommandFailure? RecordAssessment(')
 s=s[:pos]+'''    /// <summary>Returns the immutable original assessment before any mutable risk/method/treatment lookup.</summary>
    public Result<RiskAssessmentView>? ReplayAssessment(RecordRiskAssessment request, Uuid assessorMemberId)
    {
        var original = _assessments.Find(fact => fact.Assessment.AssessmentId == request.CommandId);
        if (original is null)
            return null;
        return request.TenantId == _tenantId && request.RiskId == Id && request.ProgramId == original.ProgramId &&
               original.OriginalExpectedRevision == request.ExpectedRevision &&
               original.AuthoredIntentSha256 == AuthoredIntentDigest.Compute(request) &&
               original.Assessment.Assessor.Kind == "member" && original.Assessment.Assessor.Id == assessorMemberId.ToString()
            ? Result<RiskAssessmentView>.Success(original.Assessment)
            : Result<RiskAssessmentView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The assessment identity already accepted another actor or authored request."));
    }

'''+s[pos:]
 return s
edit(p,assessment_owner,'risk-evaluation')
p=core+'Risks/RecordRiskAssessmentHandler.cs'
def assessment_handler(s):
 s=s.replace('''        var request = context.Request;''','''        var request = context.Request;
        if (request.CommandId == Uuid.Empty)
            return Result<RiskAssessmentView>.Failure(new RequestError(RequestErrorKind.Validation,
                "An assessment requires its typed command identity."));
        var actor = RiskActor.From(context.Actor, request.TenantId);
        var snapshot = await reader.HydrateAsync(new RiskEvaluation(request.TenantId, request.RiskId), ct)
            .ConfigureAwait(false);
        if (snapshot.ReplayAssessment(request, actor.MemberId) is { } original)
            return original;''',1)
 # Remove the later duplicate actor declaration.
 marker='        var actor = RiskActor.From(context.Actor, request.TenantId);'
 first=s.index(marker);second=s.index(marker,first+len(marker));s=s[:second]+s[second:].replace(marker+'\n','',1)
 s=s.replace('request.ExpectedRevision, context.RequestId, method, request.Phase,',
             'request.ExpectedRevision, request.CommandId, method, request.Phase,')
 s=s.replace('evaluation.FindAssessment(context.RequestId)!','evaluation.FindAssessment(request.CommandId)!')
 return s
edit(p,assessment_handler,'risk-evaluation')
edit(tests+'Risks/RiskGovernanceHandlerTests.cs',lambda s:s.replace('public RecordRiskAssessment Residual(long revision) => new(TenantId,',
 'public RecordRiskAssessment Residual(long revision) => new(Uuid.CreateVersion4(), TenantId,'),'risk-evaluation','migrated-tests')
p=tests+'Risks/RiskEvaluationTests.cs'
def assessment_red(s):
 pos=s.index('    [Fact]')
 method='''    [Theory]
    [InlineData("rationale")]
    [InlineData("actor")]
    [InlineData("revision")]
    public void ShouldConflictGivenAssessmentRetryWithChangedOriginalAuthoredBinding(string change)
    {
        // Arrange
        var evaluation = new RiskEvaluation(TenantId, Uuid.CreateVersion4());
        var method = Method(12);
        var id = Uuid.CreateVersion4();
        var actor = Uuid.CreateVersion4();
        Assert.Null(evaluation.RecordAssessment(ProgramId, 0, id, method, "inherent", 2, 2,
            "Original assessment", actor, "Assessor", Now));

        // Act
        var result = evaluation.RecordAssessment(ProgramId, change == "revision" ? 1 : 0, id, method,
            "inherent", 2, 2, change == "rationale" ? "Changed assessment" : "Original assessment",
            change == "actor" ? Uuid.CreateVersion4() : actor, "Assessor", Now.AddMinutes(1));

        // Assert
        Assert.Equal(CommandFailureCode.StateConflict, result?.Code);
        Assert.Equal(1, evaluation.Revision);
    }

'''
 return s[:pos]+method+s[pos:]
edit(p,assessment_red,'risk-evaluation','tests')
put(tests+'Risks/RiskDraftRevisionIdentityTests.cs','''using Bdgrz.Compliance.Features.Risks;
using Bdgrz.Compliance.Features.Versioning;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Risks;

public sealed class RiskDraftRevisionIdentityTests
{
    [Theory]
    [InlineData("actor")]
    [InlineData("revision")]
    [InlineData("content")]
    public void ShouldKeepOriginalRevisionBindingGivenLaterRevisionAndDurableReplay(string change)
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var id = RiskDraft.IdFor(tenant, program, "R-01");
        var command = Uuid.CreateVersion4();
        var actor = Uuid.CreateVersion4();
        var now = DateTimeOffset.UtcNow;
        var owner = new RiskDraft(tenant, id, command);
        Assert.True(owner.Create(program, Uuid.CreateVersion4(), "R-01", new("Title", "Scenario", "Effect", null), actor, "Author", now).IsSuccess);
        var request = new ReviseRiskDraft(command, tenant, program, id, 1, "Revised title", "Scenario", "Effect");
        Assert.Null(owner.Revise(request, actor, "Author", now));
        Assert.Null(owner.Revise(program, 2, new("Later title", "Later scenario", "Effect", null), actor, "Author", now));
        var facts = new AggregateScenario<RiskDraft>(owner).PendingEvents.ToArray();
        var hydrated = new AggregateScenario<RiskDraft>(new(tenant, id, command)).Given(facts);

        // Act
        var original = hydrated.Aggregate.Revise(request, actor, "Updated display", now.AddDays(1));
        var changed = hydrated.Aggregate.Revise(request with
        {
            ExpectedRevision = change == "revision" ? 2 : request.ExpectedRevision,
            Title = change == "content" ? "Changed original intent" : request.Title,
        }, change == "actor" ? Uuid.CreateVersion4() : actor, "Author", now.AddDays(1));

        // Assert
        Assert.Null(original);
        Assert.Equal(CommandFailureCode.StateConflict, changed?.Code);
        Assert.Equal(3, hydrated.Aggregate.Revision);
        Assert.Empty(hydrated.PendingEvents);
    }
}
''','risk-draft','migrated-tests')
put(tests+'Risks/RiskAssessmentIdentityTests.cs','''using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Risks;

public sealed class RiskAssessmentIdentityTests
{
    [Fact]
    public void ShouldReturnOriginalViewWithoutReselectingMethodGivenLaterAssessmentAndDurableReplay()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var risk = Uuid.CreateVersion4();
        var actor = Uuid.CreateVersion4();
        var now = DateTimeOffset.UtcNow;
        var methodOwner = new RiskMethod(tenant, program);
        Assert.Null(methodOwner.Publish(program, 0, RiskMethodTests.Scale(), RiskMethodTests.Scale(), 12,
            Bdgrz.Compliance.Features.AccessControl.ActorReference.ForMember(actor, "Author"), now));
        var method = methodOwner.GetVersion(1)!;
        var request = new RecordRiskAssessment(Uuid.CreateVersion4(), tenant, program, risk, 0, method.Version,
            "inherent", 2, 2, "Original rationale");
        var evaluation = new RiskEvaluation(tenant, risk);
        Assert.Null(evaluation.RecordAssessment(program, 0, request.CommandId, method, request.Phase,
            request.Likelihood, request.Impact, request.Rationale, actor, "Original display", now));
        Assert.Null(evaluation.RecordAssessment(program, 1, Uuid.CreateVersion4(), method, "target", 1, 1,
            "Later assessment", actor, "Later display", now.AddMinutes(1)));
        var facts = new AggregateScenario<RiskEvaluation>(evaluation).PendingEvents.ToArray();
        var replay = new AggregateScenario<RiskEvaluation>(new(tenant, risk)).Given(facts);

        // Act
        var result = replay.Aggregate.ReplayAssessment(request, actor);

        // Assert
        Assert.NotNull(result);
        Assert.True(result.Value.IsSuccess);
        Assert.Equal("Original rationale", result.Value.Value.Rationale);
        Assert.Equal("Original display", result.Value.Value.Assessor.Display);
        Assert.Equal(now, result.Value.Value.AssessedAt);
        Assert.Equal(2, replay.Aggregate.Revision);
        Assert.Empty(replay.PendingEvents);
    }
}
''','risk-evaluation','migrated-tests')
# Emit bounded independent groups; parent can integrate ready groups while remaining candidates are prepared.
ready={'grant-access','freeze-revision'}
manifest=[]
for path,row in sorted(changed.items()):
 old=row['before'];new=(AFTER/path).read_text();group=row['group'];phase=row['phase']
 if old==new:continue
 folder=OUT/group;folder.mkdir(parents=True,exist_ok=True)
 patch='diff --git a/'+path+' b/'+path+'\n'
 if old is None:patch+='new file mode 100644\n'
 patch+=''.join(difflib.unified_diff((old or '').splitlines(True),new.splitlines(True),
    fromfile='/dev/null' if old is None else 'a/'+path,tofile='b/'+path))
 row['patch']=patch
 manifest.append({'path':path,'group':group,'phase':phase,'status':'integration-ready' if group in ready else 'preparing',
  'beforeSha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,
  'afterSha256':hashlib.sha256(new.encode()).hexdigest(),'action':'add' if old is None else 'modify'})
for group in sorted({r['group'] for r in changed.values()}):
 for phase in ['tests','implementation','migrated-tests']:
  text=''.join(r.get('patch','') for r in changed.values() if r['group']==group and r['phase']==phase)
  (OUT/group/(phase+'.patch')).write_text(text)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'integrationReady':sorted(ready),'groups':sorted({r['group'] for r in manifest}),'files':len(manifest)},indent=2))
# Evidence support creation uses the selected authored CommandId rather than a mutable relationship-derived ID.
edit(common+'Evidence/LinkEvidenceSupport.cs',lambda s:s.replace('record LinkEvidenceSupport(Uuid TenantId,',
 'record LinkEvidenceSupport(Uuid CommandId, Uuid TenantId,').replace('string Purpose, string SufficiencyRationale)',
 'string Purpose, string SufficiencyRationale, long ExpectedRevision)'), 'evidence-support')
edit(common+'Evidence/EvidenceSupportLinked.cs',lambda s:s.replace('using Cntryl.Portia;',
 'using System.Text.Json.Serialization;\nusing Cntryl.Portia;').replace('''    public Uuid ProgramId''','''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public long? OriginalExpectedRevision { get; init; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? AuthoredIntentSha256 { get; init; }
    public Uuid ProgramId'''), 'evidence-support')
p=core+'Evidence/EvidenceSupport.cs'
def support_owner(s):
 s=s.replace('using System.Globalization;\n','')
 s=s.replace('using Bdgrz.Compliance.Features.AccessControl;',
 'using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Kernel;')
 start=s.index('    /// <summary>Derives a stable relationship identity')
 end=s.index('    public CommandFailure? Link(',start)
 s=s[:start]+'''    /// <summary>The authored command identity is the immutable support assertion identity.</summary>
    public static Uuid IdFor(LinkEvidenceSupport request)
    {
        ArgumentNullException.ThrowIfNull(request);
        return request.CommandId;
    }

    /// <summary>Replays the accepted assertion before selecting mutable artifact or target facts.</summary>
    public Result<EvidenceSupportView>? Replay(LinkEvidenceSupport request, ActorReference actor)
    {
        if (Current is not { } original)
            return null;
        return request.CommandId == Id && request.TenantId == _tenantId && request.ProgramId == _programId &&
               original.OriginalExpectedRevision == request.ExpectedRevision &&
               original.AuthoredIntentSha256 == AuthoredIntentDigest.Compute(request) &&
               actor.Kind == "member" && actor.Id == original.ActorMemberId!.Value.ToString()
            ? Result<EvidenceSupportView>.Success(View()!)
            : Result<EvidenceSupportView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The support identity already accepted another actor or authored intent."));
    }

    /// <summary>The frozen original assertion view, including its original source, actor display and time.</summary>
    public EvidenceSupportView? View() => Current is not { } value ? null : new(value.TenantId, value.ProgramId,
        value.SubjectId, value.ArtifactId, value.ArtifactRevision, value.ArtifactContentSha256!,
        value.SupportedRecordType!, value.SupportedRecordId, value.SupportedRecordRevision,
        value.PeriodStart, value.PeriodEnd, value.Purpose!, value.SufficiencyRationale!,
        value.ActorMemberId!.Value, value.ActorDisplay!, value.OccurredAt);

'''+s[end:]
 s=s.replace('''        ArgumentNullException.ThrowIfNull(actor);
''','''        ArgumentNullException.ThrowIfNull(actor);
        if (Replay(request, actor) is { } original)
            return original.IsSuccess ? null : CommandFailure.StateConflict(original.Error!.Message!);
''',1)
 s=s.replace('''            Id != IdFor(request) || request.ArtifactId == Uuid.Empty ||''',
 '''            Id != IdFor(request) || request.ExpectedRevision != 0 || request.ArtifactId == Uuid.Empty ||''')
 start=s.index('        if (Current is { } existing)')
 end=s.index('        RaiseEvent(',start)
 s=s[:start]+s[end:]
 s=s.replace('''            ProgramId = _programId,''','''            OriginalExpectedRevision = request.ExpectedRevision,
            AuthoredIntentSha256 = AuthoredIntentDigest.Compute(request),
            ProgramId = _programId,''',1)
 # The old SameRelationship helper is no longer the request identity binding.
 start=s.index('    static bool SameRelationship(')
 end=s.index('    static string NormalizeType(',start)
 s=s[:start]+s[end:]
 return s
edit(p,support_owner,'evidence-support')
p=core+'Evidence/LinkEvidenceSupportHandler.cs'
def support_handler(s):
 s=s.replace('IAggregateExecutor executor, TimeProvider clock)', 'IAggregateExecutor executor, TimeProvider clock, IAggregateReader reader)')
 s=s.replace('''        if (request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty ||''',
 '''        if (request.CommandId == Uuid.Empty || request.ExpectedRevision < 0 ||
            request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty ||''')
 target='''        var captured = await metadata.GetCapturedAsync'''
 pos=s.index(target)
 s=s[:pos]+'''        var original = await reader.HydrateAsync(new EvidenceSupport(request.TenantId, request.ProgramId,
            request.CommandId), ct).ConfigureAwait(false);
        if (original.Replay(request, actor) is { } retry)
            return retry;
'''+s[pos:]
 return s
edit(p,support_handler,'evidence-support')
# Rewrite explicit constructor calls without interpreting nested arguments or string literals as separators.
def add_args(s,token,prefix,suffix):
 cursor=0
 while True:
  at=s.find(token,cursor)
  if at<0:break
  begin=at+len(token);depth=1;i=begin;quoted=False;escape=False
  while depth:
   c=s[i]
   if quoted:
    if escape:escape=False
    elif c=='\\':escape=True
    elif c=='"':quoted=False
   elif c=='"':quoted=True
   elif c=='(':depth+=1
   elif c==')':depth-=1
   i+=1
  body=s[begin:i-1]
  value=prefix+body+suffix
  s=s[:begin]+value+s[i-1:];cursor=begin+len(value)+1
 return s
for p in [tests+'Evidence/EvidenceSupportTests.cs',tests+'AdvisorCollaboration/AdvisorRecordVersionResolverTests.cs']:
 edit(p,lambda s:add_args(s,'new LinkEvidenceSupport(', 'Uuid.CreateVersion4(), ', ', 0'),
      'evidence-support','migrated-tests')
p=tests+'Evidence/LinkEvidenceSupportHandlerTests.cs'
# Preserve the original behavioral RED as a before-API-migration intermediate snapshot.
s=original(p)
pos=s.index('    sealed class Fixture')
red='''    [Fact]
    public async Task ShouldReturnOriginalSupportGivenAcceptedRetryAfterTargetRevisionAdvances()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifact = await fixture.SeedArtifactAsync(EvidenceInspectionOutcome.Clean);
        var controlId = await fixture.SeedControlAsync();
        var request = fixture.Request(artifact, controlId, 1);
        var first = await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None);
        Assert.True(first.IsSuccess, first.Error?.Message);
        var control = await fixture.Reader.HydrateAsync(new ControlDraft(fixture.TenantId, controlId));
        Assert.Null(control.Revise(fixture.ProgramId, 1,
            new("Updated review", "New owner instruction", "Review access", "Quarterly review", ["Approval record"]),
            RbacIds.Member(fixture.TenantId, fixture.UserId), "Evidence lead", Now));
        await fixture.Writer.SaveAsync(control, fixture.Context(request));

        // Act
        var result = await fixture.Handler().HandleAsync(fixture.Context(request), CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(first.Value, result.Value);
        var owner = await fixture.Reader.HydrateAsync(new EvidenceSupport(fixture.TenantId,
            fixture.ProgramId, EvidenceSupport.IdFor(request)));
        Assert.Equal(1UL, owner.CommittedStreamPosition);
    }

'''
put(p,s[:pos]+red+s[pos:],'evidence-support','migrated-tests')
changed[p]['red']=(AFTER/p).read_text()
def support_tests(s):
 s=s.replace('new(TenantId, ProgramId, artifactId, "control", controlId, revision,',
 'new(Uuid.CreateVersion4(), TenantId, ProgramId, artifactId, "control", controlId, revision,')
 s=s.replace('"The artifact demonstrates the approved control design.");',
 '"The artifact demonstrates the approved control design.", 0);')
 s=s.replace('_scope.ServiceProvider.GetRequiredService<IAggregateExecutor>(), TimeProvider.System);',
 '_scope.ServiceProvider.GetRequiredService<IAggregateExecutor>(), TimeProvider.System, Reader);')
 return s
edit(p,support_tests,'evidence-support','migrated-tests')
edit(core+'Evidence/EvidenceSupport.cs',lambda s:s.replace('''        var recordType = NormalizeType(request.SupportedRecordType);
        var purpose''','''        if (request.ExpectedRevision != Revision)
            return CommandFailure.ForVersion(VersionedRecordRules.StaleRevision("evidence support", Revision));
        var recordType = NormalizeType(request.SupportedRecordType);
        var purpose''',1).replace('Id != IdFor(request) || request.ExpectedRevision != 0 ||','Id != IdFor(request) ||'), 'evidence-support')
# Ignore absent new receipt metadata when serializing older facts, preserving their historical canonical shape.
for p in [common+'Risks/RiskDraftRevised.cs',common+'Risks/RiskAssessmentRecorded.cs']:
 def optional_metadata(s):
  if 'using System.Text.Json.Serialization;' not in s:s='using System.Text.Json.Serialization;\n'+s
  for prop in ['public Uuid? CommandId','public long? OriginalExpectedRevision','public string? AuthoredIntentSha256']:
   s=s.replace('    '+prop,'    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]\n    '+prop)
  return s
 edit(p,optional_metadata,changed[p]['group'])
# Give ratification a behavioral RED before changing the record constructor.
p=tests+'AccessControl/ProfessionalDutyGovernanceCompositionTests.cs'
s=original(p);pos=s.index('    static async Task<SeededRuleSource> SeedRatifiedRulesAsync')
red='''    [Fact]
    public async Task ShouldReturnOriginalRatificationGivenImmediateExactHandlerRetry()
    {
        // Arrange
        var at = DateTimeOffset.FromUnixTimeSeconds(DateTimeOffset.UtcNow.ToUnixTimeSeconds()).AddMinutes(-1);
        await using var provider = Compose();
        await using var scope = provider.CreateAsyncScope();
        var seeded = await SeedRatifiedRulesAsync(scope.ServiceProvider, at, at.AddMinutes(59));
        var rules = new IndependenceRuleContent(12,
            [new IndependenceServiceRuleContent("readiness", "conditionally_compatible", "impairing")],
            "Second version for retry proof");
        Assert.True((await seeded.Executor.ExecuteAsync(new IndependenceRuleCatalog(), current =>
            AggregateOutcome.CommitOnSuccess(current.ReviseRules(Uuid.CreateVersion4(), 1, rules,
                seeded.OperatorActor, at)), new RequestDispatchContext(RequestActor.System), CancellationToken.None)).IsSuccess);
        var request = new RatifyIndependenceRuleVersion(Uuid.CreateVersion4(), 2, 2, 1,
            IndependenceSourceDigest.RuleContent(rules), "Original retry decision");
        var context = new Cntryl.Portia.RequestContext<RatifyIndependenceRuleVersion>(request,
            new RequestDispatchContext(Actor, new HttpInvocation("PUT", "/synthetic/ratify", null, "ratify-retry")));
        var handler = ActivatorUtilities.CreateInstance<RatifyIndependenceRuleVersionHandler>(scope.ServiceProvider);
        var first = await handler.HandleAsync(context, CancellationToken.None);
        Assert.True(first.IsSuccess, first.Error?.Message);

        // Act
        var retry = await handler.HandleAsync(context, CancellationToken.None);

        // Assert
        Assert.True(retry.IsSuccess, retry.Error?.Message);
        Assert.Equal(first.Value, retry.Value);
        var current = await scope.ServiceProvider.GetRequiredService<IAggregateReader>()
            .HydrateAsync(new IndependenceRuleRatificationCatalog());
        Assert.Equal(2, current.Sequence);
    }

'''
put(p,s[:pos]+red+s[pos:],'ratification','migrated-tests')
changed[p]['red']=(AFTER/p).read_text()
edit(p,lambda s:ratify_tests(s).replace('"Original retry decision")','"Original retry decision", 1)'),
 'ratification','migrated-tests')
# Authored creation identity preserves the documented normalized identifier boundary; mismatches are rejected,
# never silently replaced. New typed creations retain their full original authored digest as well as actor.
edit(common+'Risks/CreateRiskDraft.cs',lambda s:s.replace('record CreateRiskDraft(Uuid TenantId,',
 'record CreateRiskDraft(Uuid RiskId, Uuid TenantId,'),'risk-draft')
edit(common+'Risks/RiskDraftCreated.cs',lambda s:s.replace('''{
    [JsonPropertyName("actor")]''','''{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? AuthoredIntentSha256 { get; init; }

    [JsonPropertyName("actor")]'''),'risk-draft')
p=core+'Risks/RiskDraft.cs'
def typed_create(s):
 s=s.replace('    Uuid _createActorMemberId;', '    Uuid _createActorMemberId;\n    string? _createAuthoredIntentSha256;')
 s=s.replace('''            _createActorMemberId = ev.ActorMemberId;''',
 '''            _createActorMemberId = ev.ActorMemberId;
            _createAuthoredIntentSha256 = ev.AuthoredIntentSha256;''')
 pos=s.index('    public Result<RiskRegistration> Create(Uuid programId,')
 s=s[:pos]+'''    /// <summary>Resolves a typed immutable creation before selecting the current program or draft state.</summary>
    public Result<RiskRegistration>? ReplayCreate(CreateRiskDraft request, Uuid actorMemberId)
    {
        if (!_created)
            return null;
        return request.RiskId == Id && request.TenantId == _tenantId && request.ProgramId == ProgramId &&
               _createRequestId == request.RiskId && _createActorMemberId == actorMemberId &&
               _createAuthoredIntentSha256 == AuthoredIntentDigest.Compute(request)
            ? Result<RiskRegistration>.Success(new(Id, _identifier!, 1))
            : Result<RiskRegistration>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The risk identity already retains another original creation or a historical unbound creation."));
    }

    public Result<RiskRegistration> Create(CreateRiskDraft request, Uuid actorMemberId, string actorDisplay,
        DateTimeOffset changedAt)
    {
        if (request.RiskId == Uuid.Empty || request.RiskId != Id || request.TenantId != _tenantId ||
            Id != IdFor(_tenantId, request.ProgramId, request.Identifier))
            return Result<RiskRegistration>.Failure(new RequestError(RequestErrorKind.Validation,
                "The authored risk id must match the documented normalized identifier identity."));
        if (ReplayCreate(request, actorMemberId) is { } original)
            return original;
        return Create(request.ProgramId, request.RiskId, request.Identifier,
            new(request.Title, request.Scenario, request.PotentialEffect, request.SourceNote), actorMemberId,
            actorDisplay, changedAt, AuthoredIntentDigest.Compute(request));
    }

'''+s[pos:]
 s=s.replace('''        DateTimeOffset changedAt)
    {
        var normalized = NormalizeIdentifier(identifier);''',
 '''        DateTimeOffset changedAt, string? authoredIntentSha256 = null)
    {
        var normalized = NormalizeIdentifier(identifier);''',1)
 s=s.replace('''            StoredActor = ActorReference.ForMember(actorMemberId, actorDisplay),
        };''',
 '''            AuthoredIntentSha256 = authoredIntentSha256,
            StoredActor = ActorReference.ForMember(actorMemberId, actorDisplay),
        };''',1)
 return s
edit(p,typed_create,'risk-draft')
put(core+'Risks/CreateRiskDraftHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

public sealed class CreateRiskDraftHandler(IAggregateExecutor executor, IAggregateReader reader, TimeProvider clock)
    : IRequestHandler<CreateRiskDraft, RiskRegistration>
{
    public async ValueTask<Result<RiskRegistration>> HandleAsync(IRequestContext<CreateRiskDraft> context, CancellationToken ct)
    {
        var request = context.Request;
        var identifier = RiskDraft.NormalizeIdentifier(request.Identifier);
        if (request.RiskId == Uuid.Empty || identifier.Length is < 1 or > 80 ||
            request.RiskId != RiskDraft.IdFor(request.TenantId, request.ProgramId, identifier))
            return Result<RiskRegistration>.Failure(new RequestError(RequestErrorKind.Validation,
                "An authored risk id must equal the documented UUIDv5 identity of its tenant, program and normalized identifier."));
        var user = UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var subject)
            ? subject : throw new InvalidOperationException("ProgramManagementAuthorizer must reject this actor.");
        var actor = RbacIds.Member(request.TenantId, user);
        var current = await reader.HydrateAsync(new RiskDraft(request.TenantId, request.RiskId), ct).ConfigureAwait(false);
        if (current.ReplayCreate(request, actor) is { } original)
            return original;
        var program = await reader.HydrateAsync(new ComplianceProgram(request.TenantId, request.ProgramId), ct)
            .ConfigureAwait(false);
        if (!program.IsCreated)
            return Result<RiskRegistration>.Failure(new RequestError(RequestErrorKind.NotFound, "The program was not found."));
        return await executor.ExecuteAsync(new RiskDraft(request.TenantId, request.RiskId),
            risk => AggregateOutcome.CommitOnSuccess(risk.Create(request, actor,
                UserIdentityClaims.BdgrzDisplay(context.Actor, user), clock.GetUtcNow())), context, ct).ConfigureAwait(false);
    }
}
''','risk-draft')
edit(core+'Risks/CreateRiskDraftHandler.cs',lambda s:s.replace('if (request.RiskId == Uuid.Empty || identifier.Length',
 'if (request.RiskId == Uuid.Empty || request.TenantId == Uuid.Empty || request.ProgramId == Uuid.Empty || identifier.Length'), 'risk-draft')
put(tests+'Risks/RiskDraftCreationIdentityTests.cs','''using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Risks;

public sealed class RiskDraftCreationIdentityTests
{
    [Fact]
    public void ShouldRetainOriginalRegistrationGivenTypedCreationRetryAfterRevision()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var id = RiskDraft.IdFor(tenant, program, "R-01");
        var actor = Uuid.CreateVersion4();
        var now = DateTimeOffset.UtcNow;
        var request = new CreateRiskDraft(id, tenant, program, "r-01", "Original title", "Scenario", "Effect");
        var risk = new RiskDraft(tenant, id);
        Assert.True(risk.Create(request, actor, "Author", now).IsSuccess);
        Assert.Null(risk.Revise(program, 1, new("Later title", "Later scenario", "Effect", null), actor, "Editor", now));
        var facts = new AggregateScenario<RiskDraft>(risk).PendingEvents.ToArray();
        var reloaded = new AggregateScenario<RiskDraft>(new(tenant, id)).Given(facts);

        // Act
        var original = reloaded.Aggregate.Create(request, actor, "Updated profile", now.AddDays(1));
        var changedActor = reloaded.Aggregate.Create(request, Uuid.CreateVersion4(), "Other author", now);
        var changedIntent = reloaded.Aggregate.Create(request with { Title = "Different creation" }, actor, "Author", now);

        // Assert
        Assert.True(original.IsSuccess, original.Error?.Message);
        Assert.Equal(new RiskRegistration(id, "R-01", 1), original.Value);
        Assert.Equal(RequestErrorKind.Conflict, changedActor.Error?.Kind);
        Assert.Equal(RequestErrorKind.Conflict, changedIntent.Error?.Kind);
        Assert.Equal(2, reloaded.Aggregate.Revision);
        Assert.Empty(reloaded.PendingEvents);
    }

    [Fact]
    public void ShouldRejectWithoutAppendGivenAuthoredIdentityDiffersFromNormalizedIdentifierIdentity()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var wrong = Uuid.CreateVersion4();
        var risk = new RiskDraft(tenant, wrong);
        var request = new CreateRiskDraft(wrong, tenant, program, "R-01", "Title", "Scenario", "Effect");

        // Act
        var result = risk.Create(request, Uuid.CreateVersion4(), "Author", DateTimeOffset.UtcNow);

        // Assert
        Assert.Equal(RequestErrorKind.Validation, result.Error?.Kind);
        Assert.Equal(0, risk.Revision);
        Assert.Empty(new AggregateScenario<RiskDraft>(risk).PendingEvents);
    }
}
''','risk-draft','migrated-tests')
for name in ['ChooseRiskTreatment','AcceptRisk']:
 edit(common+'Risks/'+name+'.cs',lambda s,n=name:s.replace('record '+n+'(Uuid TenantId,',
  'record '+n+'(Uuid CommandId, Uuid TenantId,'),'risk-evaluation')
for name in ['RiskTreatmentChosen','RiskAccepted']:
 def evaluation_metadata(s,n=name):
  s='using System.Text.Json.Serialization;\n'+s
  tail='RiskTreatmentView Treatment) : DomainEvent;' if n=='RiskTreatmentChosen' else 'RiskAcceptanceView Acceptance) : DomainEvent;'
  replacement=tail.replace(' : DomainEvent;',' : DomainEvent\n{\n')
  if n=='RiskTreatmentChosen':replacement+='    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]\n    public Uuid? CommandId { get; init; }\n'
  replacement+='''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public long? OriginalExpectedRevision { get; init; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? AuthoredIntentSha256 { get; init; }
}'''
  assert tail in s;return s.replace(tail,replacement)
 edit(common+'Risks/'+name+'.cs',evaluation_metadata,'risk-evaluation')
p=core+'Risks/RiskEvaluation.cs'
def evaluation_more(s):
 s=s.replace('''    ActorReference? _lastChangedBy;''','''    readonly Uuid _selectedLogicalId;
    DomainEvent? _selectedFact;
    ActorReference? _lastChangedBy;''')
 s=s.replace('public RiskEvaluation(Uuid tenantId, Uuid riskId)',
             'public RiskEvaluation(Uuid tenantId, Uuid riskId, Uuid selectedLogicalId = default)')
 s=s.replace('''        _tenantId = tenantId;''','''        _tenantId = tenantId;
        _selectedLogicalId = selectedLogicalId;''',1)
 s=s.replace('''            _assessments.Add(ev);''','''            Observe(ev.Assessment.AssessmentId, ev);
            _assessments.Add(ev);''')
 s=s.replace('''            Treatment = ev.Treatment;''','''            Observe(ev.CommandId, ev);
            Treatment = ev.Treatment;''')
 s=s.replace('''            _acceptances.Add(ev.Acceptance);''','''            Observe(ev.Acceptance.AcceptanceId, ev);
            _acceptances.Add(ev.Acceptance);''')
 marker='''        var original = _assessments.Find(fact => fact.Assessment.AssessmentId == request.CommandId);'''
 s=s.replace(marker,'''        if (_selectedFact is not null && _selectedFact is not RiskAssessmentRecorded)
            return Result<RiskAssessmentView>.Failure(IdentityConflict());
'''+marker)
 pos=s.index('    public CommandFailure? ChooseTreatment(Uuid programId,')
 s=s[:pos]+'''    public Result? ReplayTreatment(ChooseRiskTreatment request, Uuid memberId)
    {
        if (_selectedFact is null)
            return null;
        return _selectedFact is RiskTreatmentChosen original && request.TenantId == _tenantId &&
               request.RiskId == Id && request.ProgramId == original.ProgramId &&
               original.OriginalExpectedRevision == request.ExpectedRevision &&
               original.AuthoredIntentSha256 == AuthoredIntentDigest.Compute(request) &&
               original.Treatment.ChosenBy.Kind == "member" && original.Treatment.ChosenBy.Id == memberId.ToString()
            ? Result.Success : Result.Failure(IdentityConflict());
    }

    public CommandFailure? ChooseTreatment(ChooseRiskTreatment request, Uuid memberId, string display, DateTimeOffset at)
    {
        if (request.CommandId == Uuid.Empty || request.CommandId != _selectedLogicalId ||
            request.TenantId != _tenantId || request.RiskId != Id)
            return CommandFailure.InvalidContent("Treatment requires its selected command identity and exact owner.");
        if (ReplayTreatment(request, memberId) is { } original)
            return original.IsSuccess ? null : CommandFailure.StateConflict(original.Error!.Message!);
        return ChooseTreatment(request.ProgramId, request.ExpectedRevision, request.Kind, request.Rationale,
            memberId, display, at, request.CommandId, AuthoredIntentDigest.Compute(request));
    }

'''+s[pos:]
 s=s.replace('''        string rationale, Uuid actorMemberId, string actorDisplay, DateTimeOffset chosenAt)
    {''',
 '''        string rationale, Uuid actorMemberId, string actorDisplay, DateTimeOffset chosenAt,
        Uuid? commandId = null, string? authoredIntentSha256 = null)
    {''',1)
 old='''                ActorReference.ForMember(actorMemberId, actorDisplay), chosenAt)));'''
 new='''                ActorReference.ForMember(actorMemberId, actorDisplay), chosenAt))
        {
            CommandId = commandId,
            OriginalExpectedRevision = commandId is null ? null : expectedRevision,
            AuthoredIntentSha256 = authoredIntentSha256,
        });'''
 assert old in s;s=s.replace(old,new,1)
 pos=s.index('    public CommandFailure? Accept(')
 s=s[:pos]+'''    public Result<RiskAcceptanceView>? ReplayAcceptance(AcceptRisk request, Uuid memberId)
    {
        if (_selectedFact is not null && _selectedFact is not RiskAccepted)
            return Result<RiskAcceptanceView>.Failure(IdentityConflict());
        if (!_acceptanceFacts.TryGetValue(request.CommandId, out var original))
            return null;
        return request.TenantId == _tenantId && request.RiskId == Id && request.ProgramId == original.ProgramId &&
               original.OriginalExpectedRevision == request.ExpectedRevision &&
               original.AuthoredIntentSha256 == AuthoredIntentDigest.Compute(request) &&
               original.Acceptance.ApproverMemberId == memberId
            ? Result<RiskAcceptanceView>.Success(original.Acceptance)
            : Result<RiskAcceptanceView>.Failure(IdentityConflict());
    }

'''+s[pos:]
 start=s.index('        if (FindAcceptance(acceptanceId) is { } existing)')
 end=s.index('        var scope = CheckScope',start)
 s=s[:start]+'''        if (acceptanceId == Uuid.Empty)
            return CommandFailure.InvalidContent("Acceptance requires its authored command identity.");
        var authored = new AcceptRisk(acceptanceId, _tenantId, programId, Id, expectedRevision,
            residualAssessmentId, authority, expiresAt, rationale, waiver?.Id);
        if (ReplayAcceptance(authored, approverMemberId) is { } original)
            return original.IsSuccess ? null : CommandFailure.StateConflict(original.Error!.Message!);
'''+s[end:]
 s=s.replace('''                SeparationOfDutiesWaiverId = waiver?.Id,
            }));''',
 '''                SeparationOfDutiesWaiverId = waiver?.Id,
            })
        {
            OriginalExpectedRevision = expectedRevision,
            AuthoredIntentSha256 = AuthoredIntentDigest.Compute(authored),
        });''',1)
 pos=s.index('    public RiskEvaluationView ToView()')
 s=s[:pos]+'''    void Observe(Uuid? logicalId, DomainEvent fact)
    {
        if (_selectedLogicalId == Uuid.Empty || logicalId != _selectedLogicalId)
            return;
        if (_selectedFact is not null)
            throw new InvalidOperationException("One logical evaluation operation is accepted once on its owner.");
        _selectedFact = fact;
    }

    static RequestError IdentityConflict() => new(RequestErrorKind.Conflict,
        "This evaluation command identity already accepted another actor, command or authored intent.");

'''+s[pos:]
 return s
edit(p,evaluation_more,'risk-evaluation')
edit(core+'Risks/RecordRiskAssessmentHandler.cs',lambda s:s.replace(
 'new RiskEvaluation(request.TenantId, request.RiskId)',
 'new RiskEvaluation(request.TenantId, request.RiskId, request.CommandId)'), 'risk-evaluation')
p=core+'Risks/ChooseRiskTreatmentHandler.cs'
def treatment_handler(s):
 s=s.replace('''        var request = context.Request;''','''        var request = context.Request;
        if (request.CommandId == Uuid.Empty)
            return Result.Failure(new RequestError(RequestErrorKind.Validation, "A treatment requires its command identity."));
        var actor = RiskActor.From(context.Actor, request.TenantId);
        var current = await reader.HydrateAsync(new RiskEvaluation(request.TenantId, request.RiskId, request.CommandId), ct)
            .ConfigureAwait(false);
        if (current.ReplayTreatment(request, actor.MemberId) is { } original)
            return original;''',1)
 duplicate='        var actor = RiskActor.From(context.Actor, request.TenantId);'
 first=s.index(duplicate);second=s.index(duplicate,first+len(duplicate));s=s[:second]+s[second:].replace(duplicate+'\n','',1)
 s=s.replace('new RiskEvaluation(request.TenantId, request.RiskId)', 'new RiskEvaluation(request.TenantId, request.RiskId, request.CommandId)')
 s=s.replace('''evaluation.ChooseTreatment(
                request.ProgramId, request.ExpectedRevision, request.Kind, request.Rationale,''',
 '''evaluation.ChooseTreatment(request,''')
 return s
edit(p,treatment_handler,'risk-evaluation')
p=core+'Risks/AcceptRiskHandler.cs'
def acceptance_handler(s):
 insert='''        var request = context.Request;'''
 s=s.replace(insert,insert+'''
        if (request.CommandId == Uuid.Empty)
            return Result<RiskAcceptanceView>.Failure(new RequestError(RequestErrorKind.Validation,
                "Risk acceptance requires its command identity."));
        var actor = RiskActor.From(context.Actor, request.TenantId);
        var permission = RbacPermissions.RiskAcceptanceFor(request.ApproverAuthority);
        var held = permission is not null && await permissions.IsAllowedAsync(request.TenantId,
            actor.UserId, actor.MemberId, request.ProgramId, permission, ct).ConfigureAwait(false);
        if (!held)
            return Result<RiskAcceptanceView>.Failure(new RequestError(RequestErrorKind.Forbidden,
                "The current actor does not hold the requested risk acceptance authority."));
        var replay = await reader.HydrateAsync(new RiskEvaluation(request.TenantId, request.RiskId, request.CommandId), ct)
            .ConfigureAwait(false);
        if (replay.ReplayAcceptance(request, actor.MemberId) is { } original)
            return original;''',1)
 block='''        var actor = RiskActor.From(context.Actor, request.TenantId);
        var permission = RbacPermissions.RiskAcceptanceFor(request.ApproverAuthority);
        var held = permission is not null && await permissions.IsAllowedAsync(request.TenantId,
            actor.UserId, actor.MemberId, request.ProgramId, permission, ct).ConfigureAwait(false);'''
 first=s.index(block);second=s.index(block,first+len(block));s=s[:second]+s[second:].replace(block+'\n','',1)
 s=s.replace('new RiskEvaluation(request.TenantId, request.RiskId)', 'new RiskEvaluation(request.TenantId, request.RiskId, request.CommandId)')
 s=s.replace('''context.RequestId, request.ResidualAssessmentId, method,''','''request.CommandId, request.ResidualAssessmentId, method,''')
 s=s.replace('evaluation.FindAcceptance(context.RequestId)!','evaluation.FindAcceptance(request.CommandId)!')
 return s
edit(p,acceptance_handler,'risk-evaluation')
for p in [tests+'Risks/RiskGovernanceHandlerTests.cs',tests+'Work/RiskAcceptanceWorkAuthorityTests.cs']:
 edit(p,lambda s:s.replace('public AcceptRisk Accept(Uuid residualId, Uuid? waiverId) => new(TenantId,',
  'public AcceptRisk Accept(Uuid residualId, Uuid? waiverId) => new(Uuid.CreateVersion4(), TenantId,').replace(
  'public AcceptRisk Accept(Pending pending, bool executive) => new(Operations.TenantId,',
  'public AcceptRisk Accept(Pending pending, bool executive) => new(Uuid.CreateVersion4(), Operations.TenantId,'),
 'risk-evaluation','migrated-tests')
edit(tests+'Work/RiskAcceptanceWorkCompositionTests.cs',lambda s:s.replace('new AcceptRisk(tenant,',
 'new AcceptRisk(Uuid.CreateVersion4(), tenant,'), 'risk-evaluation','migrated-tests')
put(tests+'Risks/RiskTreatmentIdentityTests.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Risks;
using Bdgrz.Compliance.Features.Versioning;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Risks;

public sealed class RiskTreatmentIdentityTests
{
    [Fact]
    public void ShouldReplayWithoutRestoringOldTreatmentGivenLaterChoice()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var risk = Uuid.CreateVersion4();
        var command = Uuid.CreateVersion4();
        var actor = Uuid.CreateVersion4();
        var now = DateTimeOffset.UtcNow;
        var method = new RiskMethod(tenant, program);
        Assert.Null(method.Publish(program, 0, RiskMethodTests.Scale(), RiskMethodTests.Scale(), 12,
            ActorReference.ForMember(actor, "Author"), now));
        var owner = new RiskEvaluation(tenant, risk, command);
        Assert.Null(owner.RecordAssessment(program, 0, Uuid.CreateVersion4(), method.Current!, "inherent", 2, 2,
            "Initial assessment", actor, "Assessor", now));
        var request = new ChooseRiskTreatment(command, tenant, program, risk, 1, "accept", "Original choice");
        Assert.Null(owner.ChooseTreatment(request, actor, "Original display", now));
        Assert.Null(owner.ChooseTreatment(program, 2, "mitigate", "Later choice", actor, "Author", now));
        var facts = new AggregateScenario<RiskEvaluation>(owner).PendingEvents.ToArray();
        var hydrated = new AggregateScenario<RiskEvaluation>(new(tenant, risk, command)).Given(facts);

        // Act
        var original = hydrated.Aggregate.ChooseTreatment(request, actor, "Updated display", now.AddDays(1));
        var changed = hydrated.Aggregate.ChooseTreatment(request with { ExpectedRevision = 2 }, actor, "Author", now);

        // Assert
        Assert.Null(original);
        Assert.Equal(CommandFailureCode.StateConflict, changed?.Code);
        Assert.Equal("mitigate", hydrated.Aggregate.Treatment!.Kind);
        Assert.Equal(3, hydrated.Aggregate.Revision);
        Assert.Empty(hydrated.PendingEvents);
    }

    [Fact]
    public void ShouldRejectAnotherCommandKindGivenAlreadyAcceptedEvaluationIdentity()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var risk = Uuid.CreateVersion4();
        var command = Uuid.CreateVersion4();
        var actor = Uuid.CreateVersion4();
        var now = DateTimeOffset.UtcNow;
        var method = new RiskMethod(tenant, program);
        Assert.Null(method.Publish(program, 0, RiskMethodTests.Scale(), RiskMethodTests.Scale(), 12,
            ActorReference.ForMember(actor, "Author"), now));
        var owner = new RiskEvaluation(tenant, risk, command);
        Assert.Null(owner.RecordAssessment(program, 0, command, method.Current!, "inherent", 2, 2,
            "Initial assessment", actor, "Assessor", now));

        // Act
        var result = owner.ChooseTreatment(new ChooseRiskTreatment(command, tenant, program, risk, 1,
            "accept", "Another command"), actor, "Author", now);

        // Assert
        Assert.Equal(CommandFailureCode.StateConflict, result?.Code);
        Assert.Equal(1, owner.Revision);
        Assert.Null(owner.Treatment);
    }
}
''','risk-evaluation','migrated-tests')
put(tests+'Risks/RiskAcceptanceIdentityTests.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Risks;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Risks;

public sealed class RiskAcceptanceIdentityTests
{
    [Theory]
    [InlineData("rationale")]
    [InlineData("expiry")]
    [InlineData("actor")]
    [InlineData("revision")]
    [InlineData("waiver")]
    public void ShouldBindAllOriginalAcceptanceFieldsGivenLaterResidualAssessment(string change)
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var risk = Uuid.CreateVersion4();
        var command = Uuid.CreateVersion4();
        var assessor = Uuid.CreateVersion4();
        var approver = Uuid.CreateVersion4();
        var residual = Uuid.CreateVersion4();
        var now = DateTimeOffset.UtcNow;
        var expires = now.AddMonths(6);
        var method = new RiskMethod(tenant, program);
        Assert.Null(method.Publish(program, 0, RiskMethodTests.Scale(), RiskMethodTests.Scale(), 12,
            ActorReference.ForMember(approver, "Author"), now));
        var owner = new RiskEvaluation(tenant, risk, command);
        Assert.Null(owner.RecordAssessment(program, 0, Uuid.CreateVersion4(), method.Current!, "inherent", 2, 2,
            "Inherent", assessor, "Assessor", now));
        Assert.Null(owner.ChooseTreatment(program, 1, "accept", "Accept within tolerance", assessor, "Author", now));
        Assert.Null(owner.RecordAssessment(program, 2, residual, method.Current!, "residual", 2, 2,
            "Residual", assessor, "Assessor", now));
        var request = new AcceptRisk(command, tenant, program, risk, 3, residual, "compliance_lead", expires, "Original acceptance");
        Assert.Null(owner.Accept(program, 3, command, residual, method.Current!, "compliance_lead", true,
            expires, request.Rationale, approver, "Original approver", now));
        Assert.Null(owner.RecordAssessment(program, 4, Uuid.CreateVersion4(), method.Current!, "residual", 1, 1,
            "Later residual", assessor, "Assessor", now));
        var facts = new AggregateScenario<RiskEvaluation>(owner).PendingEvents.ToArray();
        var hydrated = new AggregateScenario<RiskEvaluation>(new(tenant, risk, command)).Given(facts);

        // Act
        var original = hydrated.Aggregate.ReplayAcceptance(request, approver);
        var changed = hydrated.Aggregate.ReplayAcceptance(request with
        {
            Rationale = change == "rationale" ? "Changed acceptance" : request.Rationale,
            ExpiresAt = change == "expiry" ? expires.AddDays(1) : expires,
            ExpectedRevision = change == "revision" ? 4 : request.ExpectedRevision,
            SeparationOfDutiesWaiverId = change == "waiver" ? Uuid.CreateVersion4() : null,
        }, change == "actor" ? Uuid.CreateVersion4() : approver);
        var result = Assert.IsType<Result<RiskAcceptanceView>>(original);
        var conflict = Assert.IsType<Result<RiskAcceptanceView>>(changed);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(residual, result.Value.ResidualAssessmentId);
        Assert.Equal("Original approver", result.Value.Approver.Display);
        Assert.Equal(RequestErrorKind.Conflict, conflict.Error?.Kind);
        Assert.Equal(5, hydrated.Aggregate.Revision);
        Assert.Empty(hydrated.PendingEvents);
    }
}
''','risk-evaluation','migrated-tests')
# A cached acceptance can never bypass the actor's current specific acceptance authority.
p=tests+'Work/RiskAcceptanceWorkAuthorityTests.cs'
def current_authority(s):
 pos=s.index('    [Theory]')
 method='''    [Fact]
    public async Task ShouldDenyOriginalAcceptanceReplayGivenCurrentAcceptanceGrantRevoked()
    {
        // Arrange
        await using var fixture = await Fixture.CreateAsync(false);
        var user = fixture.Operations.ApproverUserId;
        var member = fixture.Operations.ApproverMemberId;
        fixture.Permissions.Managers.Add(member);
        fixture.Permissions.Acceptors.Add((member, RbacPermissions.RiskAcceptComplianceLead));
        var pending = await fixture.SeedAsync(false);
        var request = fixture.Accept(pending, false);
        Assert.True((await fixture.AcceptHttpAsync(request, user)).IsSuccess);
        fixture.Permissions.Acceptors.Remove((member, RbacPermissions.RiskAcceptComplianceLead));

        // Act
        var result = await fixture.AcceptHttpAsync(request, user, RequestErrorKind.Forbidden);

        // Assert
        Assert.Equal(RequestErrorKind.Forbidden, result.Error?.Kind);
        var evaluation = await ProgramManagementServices.HydrateAsync(fixture.Provider,
            new RiskEvaluation(fixture.Operations.TenantId, pending.RiskId));
        Assert.Equal(4, evaluation.Revision);
    }

'''
 return s[:pos]+method+s[pos:]
edit(p,current_authority,'risk-evaluation','migrated-tests')
# Complete the source-backed RiskEvaluation foreign-owner gap using the already selected immutable waiver proof.
p=core+'Risks/RiskEvaluation.cs'
def risk_waiver(s):
 s=s.replace('SeparationOfDutiesWaiver? waiver = null)', 'SeparationOfDutiesWaiverProof? waiver = null)')
 s=s.replace('rationale, waiver?.Id);', 'rationale, waiver?.WaiverId);')
 old='''        if (waiver is not null && (waiver.TenantId != _tenantId || !waiver.Allows(
                new SeparationOfDutiesWaiverScope(SeparationOfDutiesRecordTypes.Risk, Id,
                    residualAssessmentId, expectedRevision, SeparationOfDutiesActions.Approve),
                approverMemberId, acceptedAt)))'''
 new='''        if (waiver is not null && (waiver.ToScope() != new SeparationOfDutiesWaiverProofScope(_tenantId,
                waiver.WaiverId, approverMemberId, approverMemberId, SeparationOfDutiesActions.Approve,
                SeparationOfDutiesRecordTypes.Risk, Id, residualAssessmentId, expectedRevision) ||
                acceptedAt < waiver.ValidFrom || acceptedAt >= waiver.ValidUntil ||
                waiver.ApprovalFact.Source != new EventStreamAddress(_tenantId.ToString(),
                    "separation-of-duties-waivers", waiver.WaiverId.ToString()) ||
                waiver.ApprovalFact.EventId == Uuid.Empty || waiver.ApprovalFact.ResourcePosition != 1 ||
                waiver.ApprovalFact.AggregateVersion != 2))'''
 assert old in s;s=s.replace(old,new)
 s=s.replace('SeparationOfDutiesWaiverId = waiver?.Id,','SeparationOfDutiesWaiverId = waiver?.WaiverId,')
 s=s.replace('''            AuthoredIntentSha256 = AuthoredIntentDigest.Compute(authored),
        });
        return null;
    }

    void Observe''',
 '''            AuthoredIntentSha256 = AuthoredIntentDigest.Compute(authored),
            WaiverProof = waiver,
        });
        return null;
    }

    void Observe''',1)
 return s
edit(p,risk_waiver,'risk-evaluation')
edit(common+'Risks/RiskAccepted.cs',lambda s:s.replace('using Cntryl.Portia;',
 'using Bdgrz.Compliance.Features.AccessControl;\nusing Cntryl.Portia;').replace('''    public string? AuthoredIntentSha256 { get; init; }
}''',
 '''    public string? AuthoredIntentSha256 { get; init; }
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public SeparationOfDutiesWaiverProof? WaiverProof { get; init; }
}'''),'risk-evaluation')
p=core+'Risks/AcceptRiskHandler.cs'
def risk_waiver_handler(s):
 s=s.replace('using Bdgrz.Compliance.Features.AccessControl;', 'using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Independence;')
 s=s.replace('IAccessGrantPermissionAuthorizer permissions, RiskGovernanceReader governanceReader, TimeProvider clock)',
 'IAccessGrantPermissionAuthorizer permissions, RiskGovernanceReader governanceReader, TimeProvider clock,\n    ISeparationOfDutiesWaiverProofResolver waivers)')
 old='''        SeparationOfDutiesWaiver? waiver = null;
        if (request.SeparationOfDutiesWaiverId is { } waiverId)
            waiver = await reader.HydrateAsync(new SeparationOfDutiesWaiver(request.TenantId,
                waiverId), ct).ConfigureAwait(false);'''
 new='''        SeparationOfDutiesWaiverProof? waiver = null;
        if (request.SeparationOfDutiesWaiverId is { } waiverId)
        {
            var scope = new SeparationOfDutiesWaiverProofScope(request.TenantId, waiverId,
                actor.MemberId, actor.MemberId, SeparationOfDutiesActions.Approve, SeparationOfDutiesRecordTypes.Risk,
                request.RiskId, request.ResidualAssessmentId, request.ExpectedRevision);
            var proof = await waivers.ResolveAsync(scope, clock.GetUtcNow(), ct).ConfigureAwait(false);
            if (!proof.IsSuccess)
                return Result<RiskAcceptanceView>.Failure(proof.Error!);
            waiver = proof.Value;
        }'''
 assert old in s;s=s.replace(old,new)
 return s
edit(p,risk_waiver_handler,'risk-evaluation')
p=tests+'Risks/RiskEvaluationTests.cs'
def risk_waiver_tests(s):
 s=s.replace('Now, ApproverId, otherScope);','Now, ApproverId, Proof(otherScope));')
 s=s.replace('Now,\n            ApproverId, waiver);','Now,\n            ApproverId, Proof(waiver));')
 pos=s.index('    static RiskMethodVersionView Method(')
 helper='''    static SeparationOfDutiesWaiverProof Proof(SeparationOfDutiesWaiver waiver)
    {
        var scope = waiver.Scope!;
        return new(waiver.TenantId, waiver.Id, waiver.BeneficiaryMemberId, waiver.BeneficiaryMemberId,
            scope.Action, scope.RecordType, scope.RecordId, scope.VersionId, scope.Revision,
            new Bdgrz.Compliance.Features.Proofs.SourceFactLocator(waiver.Stream, Uuid.CreateVersion4(), 1, 10001,
                1000001, 2, new string('a', 64)), waiver.ApprovedAt!.Value, waiver.ExpiresAt);
    }

'''
 return s[:pos]+helper+s[pos:]
# Keep the pre-implementation RED shape for the assessment regression, then migrate waiver fixtures after source apply.
changed[p]['red']=(AFTER/p).read_text()
edit(p,risk_waiver_tests,'risk-evaluation','migrated-tests')
p=tests+'Work/RiskAcceptanceWorkAuthorityTests.cs'
def waiver_services(s):
 s=s.replace('using Bdgrz.Compliance.Features.AccessControl;',
 'using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Independence;\nusing Bdgrz.Compliance.Features.SourceFacts;')
 s=s.replace('''                services.AddSingleton<IDomainEventReader>((IDomainEventReader)events);''',
 '''                services.AddSingleton<IDomainEventReader>((IDomainEventReader)events);
                services.AddSingleton<ISourceFactResolver>(new EventStoreSourceFactResolver((IDomainEventReader)events));
                services.AddScoped<ISeparationOfDutiesWaiverProofResolver, SeparationOfDutiesWaiverProofResolver>();''')
 return s
edit(p,waiver_services,'risk-evaluation','migrated-tests')
edit(core+'AccessControl/RatifyIndependenceRuleVersionHandler.cs',lambda s:s.replace(
 '''if (request.CommandId == Uuid.Empty || request.ExpectedRevision < 0 ||
            request.ExpectedRevision != request.ExpectedRatificationSequence)''',
 '''if (request.CommandId == Uuid.Empty || request.ExpectedRevision < 0)''').replace(
 '''        if (ratifications.Replay(request, actor) is { } original)
            return original;
''',
 '''        if (ratifications.Replay(request, actor) is { } original)
            return original;
        if (request.ExpectedRevision != request.ExpectedRatificationSequence)
            return Refuse(RequestErrorKind.Validation,
                "A new ratification must author the current owner revision and ratification sequence consistently.");
'''), 'ratification')
# Verify nullable replay values without relying on nullable flow through a boxed assertion.
edit(tests+'Risks/RiskAssessmentIdentityTests.cs',lambda s:s.replace(
 '''        Assert.NotNull(result);
        Assert.True(result.Value.IsSuccess);
        Assert.Equal("Original rationale", result.Value.Value.Rationale);
        Assert.Equal("Original display", result.Value.Value.Assessor.Display);
        Assert.Equal(now, result.Value.Value.AssessedAt);''',
 '''        var original = Assert.IsType<Result<RiskAssessmentView>>(result);
        Assert.True(original.IsSuccess);
        Assert.Equal("Original rationale", original.Value.Rationale);
        Assert.Equal("Original display", original.Value.Assessor.Display);
        Assert.Equal(now, original.Value.AssessedAt);'''), 'risk-evaluation','migrated-tests')
edit(tests+'AccessControl/ProfessionalDutyGovernanceCompositionTests.cs',lambda s:s.replace(
 '''        Assert.Equal(first.Value, retry.Value);
        var current =''',
 '''        Assert.Equal(first.Value, retry.Value);
        var changed = await handler.HandleAsync(new Cntryl.Portia.RequestContext<RatifyIndependenceRuleVersion>(
            request with { ExpectedRevision = request.ExpectedRevision + 1 }, context), CancellationToken.None);
        Assert.Equal(RequestErrorKind.Conflict, changed.Error?.Kind);
        var current ='''), 'ratification','migrated-tests')
edit(common+'Risks/CreateRiskDraft.cs',lambda s:s.replace('[Discriminator(',
 '''/// <summary>Creates the risk under its authored UUIDv5 tenant/program/normalized-identifier identity; mismatches are rejected.</summary>
[Discriminator(''',1),'risk-draft')
# Final staging: the consumed grant/freeze artifacts remain immutable; other candidates use staged RED/migration diffs.
ready={'grant-access','freeze-revision','ratification','risk-draft','risk-evaluation','evidence-support'}
manifest=[]
def patch_for(path,old,new):
 if old==new:return ''
 head='diff --git a/'+path+' b/'+path+'\n'
 if old is None:head+='new file mode 100644\n'
 return head+''.join(difflib.unified_diff((old or '').splitlines(True),(new or '').splitlines(True),
  fromfile='/dev/null' if old is None else 'a/'+path,tofile='/dev/null' if new is None else 'b/'+path))
parts={}
for path,row in sorted(changed.items()):
 old=row['before'];new=(AFTER/path).read_text();group=row['group'];phase=row['phase']
 if old==new:continue
 folder=OUT/group;folder.mkdir(parents=True,exist_ok=True)
 if 'red' in row:
  parts.setdefault((group,'tests'),[]).append(patch_for(path,old,row['red']))
  parts.setdefault((group,'migrated-tests'),[]).append(patch_for(path,row['red'],new))
 else:parts.setdefault((group,phase),[]).append(patch_for(path,old,new))
 manifest.append({'path':path,'group':group,'phase':phase,'hasBehavioralRedStage':'red' in row or phase=='tests',
  'status':'consumed-by-parent' if group in {'grant-access','freeze-revision'} else 'integration-ready',
  'beforeSha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,
  'afterSha256':hashlib.sha256(new.encode()).hexdigest(),'action':'add' if old is None else 'modify'})
for group in ready:
 for phase in ['tests','implementation','migrated-tests']:
  (OUT/group/(phase+'.patch')).write_text(''.join(parts.get((group,phase),[])))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'newfiles.json').write_text(json.dumps([row for row in manifest if row['action']=='add'],indent=2)+'\n')
print(json.dumps({'integrationReady':sorted(ready-{'grant-access','freeze-revision'}),
                 'consumed':['grant-access','freeze-revision'],'files':len(manifest)},indent=2))
# Fully selected internal activation identity, using native V2 fact while retaining old V1 history.
edit(common+'Tenants/ActivateTenant.cs',lambda s:s.replace('record ActivateTenant(Uuid TenantId,',
 'record ActivateTenant(Uuid CommandId, Uuid TenantId,').replace('string? FirstAdministratorEmail = null) : IRequest;',
 '''string? FirstAdministratorEmail = null) : IRequest, IIdentifiedRequest
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}'''), 'tenant-activation')
put(common+'Tenants/TenantActivatedV2.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>A native activation decision bound to the exact authored administrator, email and command identity.</summary>
[Discriminator("bdgrz.tenant.activated", 2)]
public sealed record TenantActivatedV2(Uuid TenantId, Uuid FirstAdministratorUserId, string? FirstAdministratorEmail,
    OperationProvenance Operation, ImmutableContentRef? FirstResponse) : DomainEvent, INativeOperationFact;
''','tenant-activation')
p=core+'Tenants/Tenant.cs'
def tenant_activation(s):
 s=s.replace('''        On<TenantActivated>(_ => _activated = true);''','''        On<TenantActivated>(_ => _activated = true);
        On<TenantActivatedV2>(Apply);''')
 pos=s.index('    public Result Activate(Uuid firstAdministratorUserId,')
 s=s[:pos]+'''    /// <summary>A bootstrap reaction for an already completed/rejected registration needs no state transition.</summary>
    public static RequestError ActivationNotNeeded { get; } = new(RequestErrorKind.Conflict,
        "The tenant registration no longer needs an activation decision.", false);

    public Result PrepareActivation(Uuid userId, string? email)
    {
        if (IsRegistrationRejected || HasCompletedActivation)
            return Result.Failure(ActivationNotNeeded);
        return ValidateActivation(userId, email);
    }

    public Result Activate(OperationProvenance operation, ImmutableContentRef response, Uuid userId, string? email)
    {
        var prepared = PrepareActivation(userId, email);
        if (!prepared.IsSuccess)
            return prepared;
        if (!ValidActivationOperation(operation) || response is null)
            return Failure(RequestErrorKind.Validation, "Activation requires its exact native bootstrap operation.");
        RaiseEvent(new TenantActivatedV2(Id, userId, email, operation, response));
        return Result.Success;
    }

    bool ValidActivationOperation(OperationProvenance operation) => operation.Owner == Stream &&
        operation.AffectedOwner == Stream && operation.ExpectedRevisionOwner == Stream &&
        operation.LogicalId != Uuid.Empty && operation.RootOperationId == operation.LogicalId &&
        operation.CommandKind == "ActivateTenant" && operation.Episode == "activation" &&
        operation.OriginalExpectedRevision is null && operation.Actor is { Kind: "system_process", Id: "system" };

    void Apply(TenantActivatedV2 ev)
    {
        if (ev.TenantId != Id || ev.FirstResponse is null || !ValidActivationOperation(ev.Operation) ||
            !PrepareActivation(ev.FirstAdministratorUserId, ev.FirstAdministratorEmail).IsSuccess)
            throw new InvalidOperationException("A native tenant activation must follow its exact eligible bootstrap.");
        Accept(ev, ev.Operation.LogicalId, ev.Operation);
        _activated = true;
    }

'''+s[pos:]
 # Preserve legacy direct seed semantics while factoring their own local preconditions for the native path.
 start=s.index('    public Result Activate(Uuid firstAdministratorUserId,')
 end=s.index('    /// <summary>',start)
 old=s[start:end]
 body=old[old.index('        if (_offboarding)'):old.index('        if (_activated)')]
 replacement='''    public Result Activate(Uuid firstAdministratorUserId, string? firstAdministratorEmail)
    {
        var valid = ValidateActivation(firstAdministratorUserId, firstAdministratorEmail);
        if (!valid.IsSuccess)
            return valid;
        if (_activated)
            return Result.Success;
        RaiseEvent(new TenantActivated(Id, firstAdministratorUserId));
        return Result.Success;
    }

    Result ValidateActivation(Uuid firstAdministratorUserId, string? firstAdministratorEmail)
    {
'''+body+'''        return Result.Success;
    }

'''
 return s[:start]+replacement+s[end:]
edit(p,tenant_activation,'tenant-activation')
put(core+'Tenants/ActivateTenantHandler.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

public sealed class ActivateTenantHandler(NativeOperationExecutor operations, IImmutableContentStore content,
    TimeProvider clock, IAggregateReader reader, ITenantMembershipDirectoryReader memberships, IPermissionAuthorizer permissions)
    : IRequestHandler<ActivateTenant>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<ActivateTenant> context, CancellationToken ct)
    {
        var request = context.Request;
        if (!RequestActor.IsSystem(context.Actor))
            return Result.Failure(new RequestError(RequestErrorKind.Forbidden,
                "Only tenant bootstrap reactions may activate a tenant."));
        if (request.CommandId == Uuid.Empty || request.TenantId == Uuid.Empty || request.FirstAdministratorUserId == Uuid.Empty)
            return Result.Failure(new RequestError(RequestErrorKind.Validation,
                "Activation requires its command, tenant and administrator identities."));
        var owner = new Tenant(request.TenantId);
        var operation = OwnerProvenance.For(owner, request.CommandId, "ActivateTenant",
            ActorReference.ForSystemProcess("system", "system"), "activation", null,
            AuthoredIntentDigest.Compute(request), clock.GetUtcNow());
        var accepted = await operations.ExecuteAsync(new NativeOperation<Tenant>(AcceptedOperationBinding.Of(operation),
            () => new Tenant(request.TenantId, request.CommandId), tenant => tenant.Acceptance,
            async (tenant, token) =>
            {
                var prepared = tenant.PrepareActivation(request.FirstAdministratorUserId, request.FirstAdministratorEmail);
                if (!prepared.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(prepared.Error!);
                var user = request.FirstAdministratorUserId;
                var memberId = RbacIds.Member(request.TenantId, user);
                var member = await reader.HydrateAsync(new Member(request.TenantId, user), token).ConfigureAwait(false);
                var assignment = await reader.HydrateAsync(new TeamMember(request.TenantId,
                    BuiltInRbac.AdministratorsTeamId(request.TenantId), memberId), token).ConfigureAwait(false);
                if (member.IsRegistered && member.Affiliation != "client_personnel")
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The first administrator must be client personnel."));
                if (!member.IsRegistered || !assignment.IsAssigned || assignment.MembershipEpisodeId != member.MembershipEpisodeId ||
                    !await memberships.IsMemberAsync(request.TenantId.ToString(), user, token).ConfigureAwait(false) ||
                    !await permissions.IsAllowedAsync(request.TenantId, user, memberId, RbacPermissions.TenantAccess, token).ConfigureAwait(false) ||
                    !await permissions.IsAllowedAsync(request.TenantId, user, memberId, RbacPermissions.TenantRbacManage, token).ConfigureAwait(false) ||
                    !await permissions.IsAllowedAsync(request.TenantId, user, memberId, RbacPermissions.ProgramManage, token).ConfigureAwait(false))
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The first administrator is still being provisioned.", true));
                return Result<FirstResponseDescriptor>.Success(await UnitResponses.FreezeAsync(content, "bdgrz", token)
                    .ConfigureAwait(false));
            }, (Tenant tenant, ImmutableContentRef response) => tenant.Activate(operation, response,
                request.FirstAdministratorUserId, request.FirstAdministratorEmail)), context, ct).ConfigureAwait(false);
        return UnitResponses.ToResult(accepted, Tenant.ActivationNotNeeded);
    }
}
''','tenant-activation')
put(core+'Tenants/TenantActivationEffects.cs','''using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Tenants;

/// <summary>One stable activation identity for one exact committed bootstrap source and target administrator.</summary>
static class TenantActivationEffects
{
    public static ActivateTenant Activate(Uuid sourceEventId, Uuid tenantId, Uuid userId, string? email = null) =>
        new(EffectIdentity.CommandId(sourceEventId, "tenant:activate", $"{tenantId}:{userId}", null), tenantId, userId, email);
}
''','tenant-activation')
edit(core+'Tenants/TenantSelfServiceActivationReactor.cs',lambda s:s.replace('new ActivateTenant(assignment.TenantId, tenant.OwnerUserId)',
 'TenantActivationEffects.Activate(assignment.Metadata.EventId, assignment.TenantId, tenant.OwnerUserId)'), 'tenant-activation')
edit(core+'Tenants/TenantInvitationReactor.cs',lambda s:s.replace('new ActivateTenant(accepted.TenantId, accepted.UserId, accepted.EmailAddress)',
 'TenantActivationEffects.Activate(accepted.Metadata.EventId, accepted.TenantId, accepted.UserId, accepted.EmailAddress)'), 'tenant-activation')
edit(core+'Tenants/TenantDirectoryProjector.cs',lambda s:s.replace('IProjectorHandler<TenantActivated>,',
 'IProjectorHandler<TenantActivated>,\n      IProjectorHandler<TenantActivatedV2>,').replace('''    public ValueTask HandleAsync(TenantSlugChanged ev,''',
 '''    public ValueTask HandleAsync(TenantActivatedV2 ev, IProjectorContext context, CancellationToken ct) =>
        projection.ApplyAsync(ev, ct);

    public ValueTask HandleAsync(TenantSlugChanged ev,'''), 'tenant-activation')
edit(core+'Tenants/FitzTenantDirectoryReader.cs',lambda s:s.replace('TenantActivated ev => ev.TenantId,',
 'TenantActivated ev => ev.TenantId,\n                TenantActivatedV2 ev => ev.TenantId,'), 'tenant-activation')
edit(core+'Tenants/TenantDirectoryStatus.cs',lambda s:s.replace('domainEvent is TenantActivated &&',
 'domainEvent is (TenantActivated or TenantActivatedV2) &&').replace(
 'TenantSlugConfirmed or TenantReactivated or TenantActivated =>',
 'TenantSlugConfirmed or TenantReactivated or TenantActivated or TenantActivatedV2 =>'), 'tenant-activation')
p=tests+'Tenants/ActivateTenantReadinessTests.cs'
def activation_fixture(s):
 s=s.replace('new ActivateTenant(', 'new ActivateTenant(Uuid.CreateVersion4(), ')
 s=s.replace('''        services.AddPortia()''','''        services.AddSingleton(TimeProvider.System);
        services.AddSingleton<Bdgrz.Compliance.Features.Content.IImmutableContentStore>(
            new Bdgrz.Compliance.Features.Content.FitzKvImmutableContentStore(new Cntryl.Fitz.Testing.InMemoryKvClient()));
        services.AddScoped<Bdgrz.Compliance.Features.NativeOperations.NativeOperationExecutor>();
        services.AddPortia()''')
 return s
edit(p,activation_fixture,'tenant-activation','migrated-tests')
put(tests+'Tenants/ActivateTenantIdentityTests.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Tenants;

public sealed class ActivateTenantIdentityTests
{
    [Fact]
    public async Task ShouldRejectChangedOriginalBootstrapGivenSameActivationIdentityAfterSuccess()
    {
        // Arrange
        await using var fixture = new Fixture();
        await fixture.SeedAsync();
        var id = Uuid.CreateVersion4();
        var first = Command(id, fixture.TenantId, fixture.UserId);
        var handler = fixture.Handler();
        Assert.True((await handler.HandleAsync(fixture.Context(first, id), CancellationToken.None)).IsSuccess);

        // Act
        var result = await handler.HandleAsync(fixture.Context(Command(id, fixture.TenantId, Uuid.CreateVersion4()), id),
            CancellationToken.None);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        var current = await fixture.Reader.HydrateAsync(new Tenant(fixture.TenantId));
        Assert.True(current.IsActive);
        Assert.Equal(3UL, current.CommittedStreamPosition);
    }

    // This adapter lets the behavioral RED run before the typed CommandId constructor exists. The old shape
    // uses the same explicit execution identity; the new shape additionally carries that same id in the command.
    static ActivateTenant Command(Uuid commandId, Uuid tenantId, Uuid userId)
    {
        var constructor = typeof(ActivateTenant).GetConstructors().Single();
        var arguments = constructor.GetParameters().Select(parameter => Value(parameter.Name!)).ToArray();
        return (ActivateTenant)constructor.Invoke(arguments);

        object? Value(string name) => name switch
        {
            "CommandId" => commandId,
            "TenantId" => tenantId,
            "FirstAdministratorUserId" => userId,
            "FirstAdministratorEmail" => null,
            _ => throw new InvalidOperationException("Unexpected activation constructor parameter."),
        };
    }

    sealed class Fixture : IAsyncDisposable
    {
        readonly ServiceProvider _provider;
        readonly AsyncServiceScope _scope;
        readonly IAggregateWriter _writer;
        public Uuid TenantId { get; } = Uuid.CreateVersion4();
        public Uuid UserId { get; } = Uuid.CreateVersion4();
        public IAggregateReader Reader { get; }

        public Fixture()
        {
            var services = new ServiceCollection();
            services.AddSingleton<IEventStore>(new InMemoryEventStore());
            services.AddSingleton(TimeProvider.System);
            services.AddSingleton<IImmutableContentStore>(new FitzKvImmutableContentStore(new InMemoryKvClient()));
            services.AddSingleton<ITenantMembershipDirectoryReader>(new Members());
            services.AddSingleton<IPermissionAuthorizer>(new Permissions());
            services.AddScoped<NativeOperationExecutor>();
            services.AddPortia();
            _provider = services.BuildServiceProvider();
            _scope = _provider.CreateAsyncScope();
            Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();
            _writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
        }
        public ActivateTenantHandler Handler() => ActivatorUtilities.CreateInstance<ActivateTenantHandler>(_scope.ServiceProvider);
        public Cntryl.Portia.RequestContext<ActivateTenant> Context(ActivateTenant request, Uuid id) =>
            new(request, new RequestDispatchContext(RequestActor.System, metadata: new RequestMetadata(id, id)));
        public async Task SeedAsync()
        {
            var context = new RequestDispatchContext(RequestActor.System);
            var tenant = new Tenant(TenantId);
            Assert.True(tenant.Register(UserId, "Company", "company", creatorIsAdministrator: true).IsSuccess);
            Assert.True(tenant.ConfirmSlug("company").IsSuccess);
            await _writer.SaveAsync(tenant, context);
            var member = new Member(TenantId, UserId);
            Assert.True(member.Register().IsSuccess);
            await _writer.SaveAsync(member, context);
            var assignment = new TeamMember(TenantId, BuiltInRbac.AdministratorsTeamId(TenantId), RbacIds.Member(TenantId, UserId));
            Assert.True(assignment.Assign(member.MembershipEpisodeId).IsSuccess);
            await _writer.SaveAsync(assignment, context);
        }
        public async ValueTask DisposeAsync()
        {
            await _scope.DisposeAsync();
            await _provider.DisposeAsync();
        }
    }
    sealed class Members : ITenantMembershipDirectoryReader
    {
        public ValueTask<TenantMembershipView?> GetAsync(string tenantId, Uuid userId, CancellationToken ct = default) =>
            ValueTask.FromResult<TenantMembershipView?>(new(userId, Uuid.Parse(tenantId, null), "client_personnel"));
        public ValueTask<bool> IsMemberAsync(string tenantId, Uuid userId, CancellationToken ct = default) => ValueTask.FromResult(true);
        public ValueTask<Page<TenantMembershipView>> ListAsync(Uuid tenantId, int limit, string? cursor, CancellationToken ct = default) =>
            ValueTask.FromResult(new Page<TenantMembershipView>([], null));
    }
    sealed class Permissions : IPermissionAuthorizer
    {
        public ValueTask<bool> IsAllowedAsync(Uuid tenantId, Uuid userId, Uuid memberId, string permission, CancellationToken ct = default) =>
            ValueTask.FromResult(true);
    }
}
''','tenant-activation','tests')
# Final emit includes the selected optional activation group. Reuse the same phase-splitting logic.
ready.add('tenant-activation')
manifest=[];parts={}
for path,row in sorted(changed.items()):
 old=row['before'];new=(AFTER/path).read_text();group=row['group'];phase=row['phase']
 if old==new:continue
 (OUT/group).mkdir(parents=True,exist_ok=True)
 if 'red' in row:
  parts.setdefault((group,'tests'),[]).append(patch_for(path,old,row['red']))
  parts.setdefault((group,'migrated-tests'),[]).append(patch_for(path,row['red'],new))
 else:parts.setdefault((group,phase),[]).append(patch_for(path,old,new))
 manifest.append({'path':path,'group':group,'phase':phase,'hasBehavioralRedStage':'red' in row or phase=='tests',
  'status':'consumed-by-parent' if group in {'grant-access','freeze-revision'} else 'integration-ready',
  'beforeSha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,
  'afterSha256':hashlib.sha256(new.encode()).hexdigest(),'action':'add' if old is None else 'modify'})
for group in ready:
 for phase in ['tests','implementation','migrated-tests']:
  (OUT/group/(phase+'.patch')).write_text(''.join(parts.get((group,phase),[])))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'newfiles.json').write_text(json.dumps([row for row in manifest if row['action']=='add'],indent=2)+'\n')
print(json.dumps({'readyGroups':sorted(ready),'files':len(manifest)},indent=2))
put(tests+'Tenants/TenantActivationEffectsTests.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.Tenants;

public sealed class TenantActivationEffectsTests
{
    [Fact]
    public void ShouldKeepOneActivationIdentityGivenTheSameCommittedSourceAndTarget()
    {
        // Arrange
        var source = Uuid.CreateVersion4();
        var tenant = Uuid.CreateVersion4();
        var user = Uuid.CreateVersion4();

        // Act
        var first = TenantActivationEffects.Activate(source, tenant, user);
        var replay = TenantActivationEffects.Activate(source, tenant, user);
        var otherSource = TenantActivationEffects.Activate(Uuid.CreateVersion4(), tenant, user);
        var otherTarget = TenantActivationEffects.Activate(source, tenant, Uuid.CreateVersion4());

        // Assert
        Assert.NotEqual(Uuid.Empty, first.CommandId);
        Assert.Equal(first, replay);
        Assert.NotEqual(first.CommandId, otherSource.CommandId);
        Assert.NotEqual(first.CommandId, otherTarget.CommandId);
    }
}
''','tenant-activation','migrated-tests')
# Re-emit only the additive activation group; all previously handed-off group bytes remain unchanged.
group='tenant-activation';gparts={'tests':[],'implementation':[],'migrated-tests':[]}
manifest=[row for row in manifest if row['group']!=group]
for path,row in sorted(changed.items()):
 if row['group']!=group:continue
 old=row['before'];new=(AFTER/path).read_text();phase=row['phase']
 if old==new:continue
 gparts[phase].append(patch_for(path,old,new))
 manifest.append({'path':path,'group':group,'phase':phase,'hasBehavioralRedStage':phase=='tests',
  'status':'integration-ready','beforeSha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,
  'afterSha256':hashlib.sha256(new.encode()).hexdigest(),'action':'add' if old is None else 'modify'})
for phase,parts in gparts.items():(OUT/group/(phase+'.patch')).write_text(''.join(parts))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'newfiles.json').write_text(json.dumps([row for row in manifest if row['action']=='add'],indent=2)+'\n')

# Add the advisor current-source DTO reconstruction omitted from the initial migration.
path='src/Compliance.Core/Features/AdvisorCollaboration/AdvisorRecordVersionResolver.cs'
s=original(path)
s=s.replace('new LinkEvidenceSupport(tenantId, programId, link.ArtifactId,',
 'new LinkEvidenceSupport(selected.EvidenceSupportId!.Value, tenantId, programId, link.ArtifactId,')
s=s.replace('link.PeriodStart, link.PeriodEnd, link.Purpose!, link.SufficiencyRationale!);',
 'link.PeriodStart, link.PeriodEnd, link.Purpose!, link.SufficiencyRationale!, 0);')
put(path,s,'evidence-support','implementation')
group='evidence-support';gparts={'tests':[],'implementation':[],'migrated-tests':[]}
manifest=[row for row in manifest if row['group']!=group]
for path,row in sorted(changed.items()):
 if row['group']!=group:continue
 old=row['before'];new=(AFTER/path).read_text();phase=row['phase']
 if old==new:continue
 if 'red' in row:
  gparts['tests'].append(patch_for(path,old,row['red']))
  gparts['migrated-tests'].append(patch_for(path,row['red'],new))
 else:gparts[phase].append(patch_for(path,old,new))
 manifest.append({'path':path,'group':group,'phase':phase,'hasBehavioralRedStage':'red' in row or phase=='tests',
  'status':'integration-ready','beforeSha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,
  'afterSha256':hashlib.sha256(new.encode()).hexdigest(),'action':'add' if old is None else 'modify'})
for phase,parts in gparts.items():(OUT/group/(phase+'.patch')).write_text(''.join(parts))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'newfiles.json').write_text(json.dumps([row for row in manifest if row['action']=='add'],indent=2)+'\n')
