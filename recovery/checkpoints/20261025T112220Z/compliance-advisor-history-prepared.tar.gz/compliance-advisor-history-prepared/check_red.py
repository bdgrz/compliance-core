from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-advisor-history-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()));errors=[]
paths=['test/Compliance.Tests/Features/AdvisorCollaboration/AdvisorNativeBoundaryTests.cs','test/Compliance.Tests/Features/AdvisorCollaboration/AdvisorPreparationRaceTests.cs']
for p in paths:
 assert not(repo/p).exists(),p
 text=(r/'work'/p).read_bytes();root=parser.parse(text).root_node;nodes=[root]
 while nodes:
  n=nodes.pop();nodes.extend(n.children)
  if n.type=='ERROR' or n.is_missing:errors.append({'path':p,'line':text[:n.start_byte].count(b'\n')+1,'source':text[n.start_byte:n.end_byte].decode()})
assert not errors,errors
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
t=Path(tempfile.mkdtemp(prefix='advisor-red-reconstruct-',dir=r))
try:
 x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/'behavioral-red.patch')],cwd=t,capture_output=True,text=True);assert x.returncode==0,(x.stdout,x.stderr)
 assert all((t/p).read_bytes()==(r/'work'/p).read_bytes() for p in paths)
finally:shutil.rmtree(t)
(r/'red-handoff.json').write_text(json.dumps({'status':'Existing-API RED4 only; implementation untouched, parent qualifies actual failures.','root':str(r),'filter':'FullyQualifiedName~AdvisorNativeBoundaryTests|FullyQualifiedName~AdvisorPreparationRaceTests','patches':{p:{'sha256':sha(r/p),'bytes':(r/p).stat().st_size} for p in ['behavioral-boundary-red.patch','behavioral-preparation-race-red.patch','behavioral-red.patch']},'paths':paths,'syntaxErrors':errors,'exactReconstructionFiles':2,'knownCtorChecks':['AdvisorHandoff(3 required + selected optional)','AdvisorFeedbackThread(4 required + selected optional)','RecordAdvisorFeedback(9 fields)','RespondToAdvisorFeedback(7 fields)','AdvisorUnitOperation(3 services)','RespondToAdvisorFeedbackHandler(3 services)','NativeOperationExecutor(3 services + optional transport)','AdvisorHost(all3 parameters optional)'],'noRuntimeClaim':True},indent=2)+'\n')
print(sha(r/'red-handoff.json'))
