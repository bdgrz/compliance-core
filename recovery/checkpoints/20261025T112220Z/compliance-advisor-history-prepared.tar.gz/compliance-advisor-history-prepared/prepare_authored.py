from pathlib import Path
import re
r=Path('/tmp/compliance-advisor-history-prepared');w=r/'work';b=r/'base';common='src/Compliance.Common/Features/AdvisorCollaboration/';core='src/Compliance.Core/Features/AdvisorCollaboration/'
replace={
'AdvisorHandoffCreated':('string Purpose','ImmutableContentRef Authored'),
'AdvisorHandoffSelectionRevised':('string ChangeReason','ImmutableContentRef Authored'),
'AdvisorHandoffClosed':('string Rationale','ImmutableContentRef Authored'),
'AdvisorHandoffRevoked':('string Rationale','ImmutableContentRef Authored'),
'AdvisorFeedbackCorrected':('string CorrectedBody, string CorrectionReason','ImmutableContentRef Authored'),
'AdvisorFeedbackResponded':('string Response','ImmutableContentRef Authored')}
for n,(old,new) in replace.items():
 p=w/(common+n+'.cs');s=(b/(common+n+'.cs')).read_text();assert old in s,n;s=s.replace(old,new).replace(', 1)]',', 2)]');p.write_text(s)
p=w/(common+'AdvisorFeedbackRecorded.cs');s=(b/(common+'AdvisorFeedbackRecorded.cs')).read_text().replace('string Kind, string Body,','string Kind,').replace(', 1)]',', 2)]');p.write_text(s)
# Complete canonical typed authored content. No new authority envelope or actor/schema contract is invented.
s='''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AdvisorCollaboration;

/// <summary>Complete canonical authored values referenced by advisor native business facts.</summary>
static class AdvisorAuthored
{
    public static string Schema<T>() => typeof(T).Name + ".AuthoredContent.v1";

    public static Task<ImmutableContentRef> WriteAsync<T>(IImmutableContentStore content, Uuid tenantId,
        T request, CancellationToken ct) where T : notnull =>
        AdvisorContent.WriteAsync(content, tenantId, Schema<T>(), request, ct);

    static async Task<T> ReadAsync<T>(IImmutableContentStore content, Uuid tenantId, ImmutableContentRef reference,
        OperationProvenance operation, CancellationToken ct) where T : notnull
    {
        if (reference.Schema != Schema<T>() || operation.CommandKind != typeof(T).Name)
            throw Invalid("The advisor authored content has another command schema.");
        var request = await AdvisorContent.ReadAsync<T>(content, tenantId, reference, ct).ConfigureAwait(false);
        if (AuthoredIntentDigest.Compute(request) != operation.AuthoredIntentSha256)
            throw Invalid("The advisor authored content differs from its exact native intent.");
        return request;
    }
READERS
    static bool Text(string? value) => !string.IsNullOrWhiteSpace(value) && value.Trim() == value;
    static ImmutableContentIntegrityException Invalid(string message) => new(message);
}
'''
rows=[
('AdvisorHandoffCreated','CreateAdvisorHandoff','value.HandoffId == request.HandoffId && value.ExpiresOn == request.ExpiresOn && value.ComparedToHandoffId == request.ComparedToHandoffId && value.Operation.LogicalId == request.HandoffId && value.Operation.OriginalExpectedRevision is null && Text(request.Purpose) && AdvisorHandoffRules.ValidSelection(request.RecordVersions)'),
('AdvisorHandoffSelectionRevised','ReviseAdvisorHandoffSelection','value.HandoffId == request.HandoffId && value.Operation.LogicalId == request.CommandId && value.Operation.OriginalExpectedRevision == (ulong)request.ExpectedRevision && value.Revision == request.ExpectedRevision + 1 && Text(request.ChangeReason) && AdvisorHandoffRules.ValidSelection(request.RecordVersions)'),
('AdvisorHandoffClosed','CloseAdvisorHandoff','value.HandoffId == request.HandoffId && value.Operation.LogicalId == request.CommandId && value.Operation.OriginalExpectedRevision == (ulong)request.ExpectedRevision && value.Revision == request.ExpectedRevision + 1 && Text(request.Rationale)'),
('AdvisorHandoffRevoked','RevokeAdvisorHandoff','value.HandoffId == request.HandoffId && value.Operation.LogicalId == request.CommandId && value.Operation.OriginalExpectedRevision == (ulong)request.ExpectedRevision && value.Revision == request.ExpectedRevision + 1 && Text(request.Rationale)'),
('AdvisorFeedbackCorrected','CorrectAdvisorFeedback','value.HandoffId == request.HandoffId && value.FeedbackId == request.FeedbackId && value.CorrectionId == request.CorrectionId && value.Operation.LogicalId == request.CorrectionId && value.Operation.OriginalExpectedRevision == (ulong)request.ExpectedRevision && Text(request.CorrectedBody) && Text(request.CorrectionReason)'),
('AdvisorFeedbackResponded','RespondToAdvisorFeedback','value.HandoffId == request.HandoffId && value.FeedbackId == request.FeedbackId && value.Operation.LogicalId == request.CommandId && value.Operation.OriginalExpectedRevision == (ulong)request.ExpectedRevision && Text(request.Response)')]
readers=[]
for fact,req,cond in rows:
 readers.append('''    public static async Task<REQ> ReadAsync(IImmutableContentStore content, FACT value,
        CancellationToken ct)
    {
        var request = await ReadAsync<REQ>(content, value.TenantId, value.Authored, value.Operation, ct).ConfigureAwait(false);
        if (!(value.TenantId == request.TenantId && value.ProgramId == request.ProgramId && COND))
            throw Invalid("The advisor authored command has another native tuple or original terms.");
        return request;
    }
'''.replace('REQ',req).replace('FACT',fact).replace('COND',cond))
s=s.replace('READERS','\n'.join(readers));(w/(core+'AdvisorAuthored.cs')).write_text(s)
