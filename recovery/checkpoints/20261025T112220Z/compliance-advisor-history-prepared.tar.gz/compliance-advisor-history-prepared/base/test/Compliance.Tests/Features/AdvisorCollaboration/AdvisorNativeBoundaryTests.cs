using System.Collections;
using System.Reflection;
using System.Text.Json;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.AdvisorCollaboration;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.AdvisorCollaboration;

public sealed class AdvisorNativeBoundaryTests
{
    [Fact]
    public void ShouldRetainOnlyCurrentAuthorityGivenManyFeedbackAdmissionsAndResponses()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var handoffId = Uuid.CreateVersion4();
        var member = Uuid.CreateVersion4();
        var actor = ActorReference.ForMember(member, "Advisor");
        var handoff = new AdvisorHandoff(tenant, program, handoffId);
        Assert.True(handoff.Create(NativeFacts.Root(handoff, handoffId, nameof(CreateAdvisorHandoff), null, member),
            NativeFacts.Ref(), "Review exact selected records.", DateOnly.FromDateTime(NativeFacts.Now.UtcDateTime).AddDays(1),
            actor, NativeFacts.Now, null, NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
        Assert.True(handoff.MarkReady(NativeFacts.Root(handoff, Uuid.CreateVersion4(), nameof(MarkAdvisorHandoffReadyForReview), 1, member),
            actor, NativeFacts.Now, NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
        var feedbackId = Uuid.CreateVersion4();
        var thread = new AdvisorFeedbackThread(tenant, program, handoffId, feedbackId);
        var authored = new RecordAdvisorFeedback(tenant, program, handoffId, feedbackId, Uuid.CreateVersion4(),
            Uuid.CreateVersion4(), "comment", "Original exact contribution.", handoff.Revision);
        Assert.True(thread.Materialize(NativeFacts.Root(thread, Uuid.CreateVersion4(), nameof(MaterializeAdvisorFeedback), 0, member),
            authored, actor, NativeFacts.Now, NativeFacts.Ref()).IsSuccess);

        // Act
        for (var index = 0; index < 105; index++)
        {
            Assert.True(handoff.AdmitFeedback(NativeFacts.Root(handoff, Uuid.CreateVersion4(), nameof(RecordAdvisorFeedback),
                handoff.Revision, member), NativeFacts.Ref(), DateOnly.FromDateTime(NativeFacts.Now.UtcDateTime), NativeFacts.Ref()).IsSuccess);
            Assert.True(thread.Respond(NativeFacts.Root(thread, Uuid.CreateVersion4(), nameof(RespondToAdvisorFeedback),
                thread.Revision, member), "Client response " + index, actor, NativeFacts.Now, NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
        }
        var retained = new Aggregate[] { handoff, thread }.SelectMany(owner => owner.GetType()
            .GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(owner) is ICollection { Count: > 2 })).ToArray();

        // Assert
        Assert.Equal(107, handoff.Revision);
        Assert.Equal(106, thread.Revision);
        Assert.Empty(retained);
    }

    [Fact]
    public void ShouldBoundNativeCorrectionGivenLargeValidCompleteText()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var handoff = Uuid.CreateVersion4();
        var feedback = Uuid.CreateVersion4();
        var member = Uuid.CreateVersion4();
        var actor = ActorReference.ForMember(member, "Advisor");
        var thread = new AdvisorFeedbackThread(tenant, program, handoff, feedback);
        var authored = new RecordAdvisorFeedback(tenant, program, handoff, feedback, Uuid.CreateVersion4(),
            Uuid.CreateVersion4(), "comment", "Original contribution.", 2);
        Assert.True(thread.Materialize(NativeFacts.Root(thread, Uuid.CreateVersion4(), nameof(MaterializeAdvisorFeedback), 0, member),
            authored, actor, NativeFacts.Now, NativeFacts.Ref()).IsSuccess);
        var text = new string('界', 8000);
        var correction = Uuid.CreateVersion4();

        // Act
        var result = thread.Correct(NativeFacts.Root(thread, correction, nameof(CorrectAdvisorFeedback), 1, member),
            correction, text, text, actor, NativeFacts.Now, NativeFacts.Ref(), NativeFacts.Ref());
        var fact = Assert.Single(new AggregateScenario<AdvisorFeedbackThread>(thread).PendingEvents.OfType<AdvisorFeedbackCorrected>());
        var bytes = JsonSerializer.SerializeToUtf8Bytes(fact, ComplianceCoreJsonContext.Default.AdvisorFeedbackCorrected);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.True(bytes.Length <= 48 * 1024, $"The complete valid correction produced a {bytes.Length}-byte native payload.");
    }
}
