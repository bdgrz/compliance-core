# Advisor history/content package (54 paths)

FROZEN preparation in `/tmp/compliance-advisor-history-prepared`. Parent owns integration, all .NET/format/runtime/HTTP/Jev checks, PR and merge. No runtime or Jev command was run by this preparation agent.

`manifest.json` records all exact before/after hashes and staged reconstruction evidence. `baselines.json` preserves exact original captures. Every changed path that existed in the repository at freeze has a nonnull original before hash; all those bytes matched current main. The handoff is layered after the already merged AdvisorUnit3 prefix and NativeOwnerHistory small3; it does not reapply the prefix.

## Apply

- Clean current main after AdvisorUnit3: `full-from-clean.patch`.
- If the two current-API RED patches remain installed: `full-after-red.patch`.
- Narrow composition: `implementation.patch` (40 source/document paths), `shared.patch` (two scoped-reader/wrapper registration hunks), then `tests-from-clean.patch` or `tests-after-red.patch` (12 test/helper paths).
- `behavioral-boundary-red.patch` and `behavioral-admission-race-red.patch` are the stable current-API RED4 parent already qualified. Their exact originals remain `old-api-boundary-red.cs` and `old-api-admission-race-red.cs`. The captured boundary test in `base/` is that exact temporary RED, explicitly absent from the clean stage. All four reconstruction orders account for that distinction.
- Historical `behavioral-red.patch`, `behavioral-preparation-race-red.patch` and the initial `red-handoff.json` include the old three-argument Unit helper API. They are preserved historical evidence; do not apply them to the already merged prefix.

## Behavior and compatibility

The owners retain bounded current authority, scalar counts/revision/generation, an exact native replay commitment and explicitly selected acceptance. Complete histories live in verified transient readers/snapshots. A distinct outer `AdvisorAggregateReader` finalizes both explicit and executor-internal hydration after the existing Calendar, SourceUse and Mapping layers; every wrapper receives a fresh opaque key, preserving custom registrations and preventing self-resolution.

Complete canonical authored requests replace seven native inline payloads at discriminator version 2: handoff create/revise/close/revoke, feedback recorded/corrected/responded. Recorded reuses the actual accepted `ChildAdmissionIntent` and original canonical feedback body. No text cap/truncation is added. The existing 100-item current-selection policy remains. Public routes, required IDs, current personal authorization, native Unit200 and admission202 response bytes remain their existing contracts.

Materialization locates and verifies the exact accepted parent native source without a latest selection/status/body gate, including after closure/revocation. The original actor and admission time remain separate from the later receiver accepted time. Corrections/responses after resolution remain permitted by the existing thread policy. Scope-qualified thread/work/projection keys from #1112 are unchanged.

All preparation runs inside native async preparation, including authored content and the admission202 intent/response. A local precise preparation cut also prevents a different coherent prefix at the same metadata version/physical tail from being used by the real executor. Current authorization still precedes replay; accepted public retries do not read historical authored text.

Retained version-1 event streams/SDK snapshots are not implicitly migrated or dual-read by this package. See `LOCAL-QUALIFICATIONS.md` for exact data/source-use qualification, including the absence of an Advisor purpose/fact pair in the actual SourceUse protocol. No permit, release, cross-owner hold or trusted callback is invented.

## Constructors/wiring

- `AdvisorHandoffReader`: adds `IDomainEventReader` (reader, content, events).
- New scoped `AdvisorFeedbackReader`: aggregate reader, domain events, content.
- Handoff/feedback projection stores: add immutable content store.
- Close/Revoke handlers: add content. Correct/Respond: explicit thread reader + content in place of aggregate reader. Resolve uses the explicit thread reader.
- Record handler: drops unused aggregate reader (operations, handoffs, content, clock).
- Materialize handler: adds handoff reader (aggregate reader, executor, handoffs, content, clock).
- Unit helper retains its merged two-service constructor; the full-family delta only adds preparation-cut binding.
- No new persisted JSON roots or routes are needed; existing concrete command/native-event roots cover all immutable authored DTOs.

## Evidence and parent gates

Parent reported a strict successful build followed by all four intended existing-API RED failures in `/tmp/compliance-next-families-red.log`: retained lifetime fields, a 97,775-byte valid correction, and two real admission write-failure/cancellation races. The narrow Unit race prefix was previously RED-qualified, GREEN and merged by parent.

Static checks here: 53 changed C# files parse; 309 explicit constructor calls across the effective main+delta tree have correct arities; token ordering, duplicate usings and proof namespaces pass. All 210 captured acceptance names remain and assertion counts do not drop. Four isolated clean/partitioned/RED reconstruction orders exactly reproduce every changed file while preserving unrelated baseline bytes.

New runtime gates include default and real executor malformed-history fences, accepted retry on malformed later history, same-metadata intermediate substitution/truncation, response replay with historical content unavailable/current personal auth, a real executor with a distinct coherent prefix, complete large authored text for every compact payload family, resolution-followed-by-write semantics, and transactional projection row/checkpoint rollback on substituted actual immutable authored bytes. Existing outside advisory/readiness/authorization seed fixtures now write real canonical content and exact selected cuts. All original projection acceptance names and real scope/replay assertions remain.

Suggested focused filter: `FullyQualifiedName~Advisor|FullyQualifiedName~AdvisoryReadinessNote|FullyQualifiedName~ProfessionalAdvisory`. Parent must run focused/full units with its non-broker filter, existing production-host HTTP cases and direct per-file Jev review before merging.
