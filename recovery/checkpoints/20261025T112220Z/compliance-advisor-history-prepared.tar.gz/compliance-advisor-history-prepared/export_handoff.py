from pathlib import Path
import difflib,hashlib,json,re,shutil,subprocess,tempfile
r=Path('/tmp/compliance-advisor-history-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
boundary='test/Compliance.Tests/Features/AdvisorCollaboration/AdvisorNativeBoundaryTests.cs'
admission='test/Compliance.Tests/Features/AdvisorCollaboration/AdvisorAdmissionPreparationRaceTests.cs'
red={boundary:(r/'old-api-boundary-red.cs').read_bytes(),admission:(r/'old-api-admission-race-red.cs').read_bytes()}
shared={'src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs'}
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=sorted(str(p.relative_to(r/'work')) for p in (r/'work').rglob('*') if p.is_file() and (not (r/'base'/p.relative_to(r/'work')).exists() or p.read_bytes()!=(r/'base'/p.relative_to(r/'work')).read_bytes()))
metadata={item['path']:item for item in json.loads((r/'baselines.json').read_text())}
# The boundary RED was captured while the parent had its temporary qualified test installed. Keep that original
# exactly, but the clean stage intentionally starts with no new RED file. Both wire paths are exported explicitly.
metadata[boundary]['baselineSource']=str(r/'old-api-boundary-red.cs')+' (exact root-qualified temporary RED; absent from clean repository base)'
metadata[boundary]['cleanBaselineAbsent']=True
(r/'baselines.json').write_text(json.dumps(list(metadata.values()),indent=2)+'\n')

def before(p,mode):
 if mode=='after-red' and p in red:return red[p]
 if p==boundary:return None
 b=r/'base'/p
 return b.read_bytes() if b.exists() else None

def patch(selected,mode):
 out=[]
 for p in selected:
  old=before(p,mode);new=(r/'work'/p).read_bytes()
  if old==new:continue
  out.append(f'diff --git a/{p} b/{p}\n')
  out.extend(difflib.unified_diff((old or b'').decode().splitlines(True),new.decode().splitlines(True),fromfile=f'a/{p}' if old is not None else '/dev/null',tofile=f'b/{p}',n=3))
 return ''.join(out)
impl=[p for p in paths if not p.startswith('test/') and p not in shared]
shr=[p for p in paths if p in shared]
tests=[p for p in paths if p.startswith('test/')]
exports={'implementation.patch':(impl,'clean'),'shared.patch':(shr,'clean'),'tests-from-clean.patch':(tests,'clean'),'tests-after-red.patch':(tests,'after-red'),'full-from-clean.patch':(paths,'clean'),'full-after-red.patch':(paths,'after-red')}
for name,(selected,mode) in exports.items():(r/name).write_text(patch(selected,mode))
rows=[];missing=[];drift=[]
for p in paths:
 b=r/'base'/p;w=r/'work'/p;main=repo/p
 original=b.read_bytes() if b.exists() else None
 if main.exists() and original is None:missing.append(p)
 if main.exists() and original is not None and main.read_bytes()!=original:drift.append(p)
 rows.append({'path':p,'baselineSource':metadata.get(p,{}).get('baselineSource'),'beforeSha256':sha(original) if original is not None else None,'cleanBeforeSha256':sha(before(p,'clean')) if before(p,'clean') is not None else None,'afterRedBeforeSha256':sha(before(p,'after-red')) if before(p,'after-red') is not None else None,'afterSha256':sha(w.read_bytes()),'currentRepositoryExists':main.exists(),'partition':'shared' if p in shared else 'tests' if p.startswith('test/') else 'implementation','originalAcceptanceNames':re.findall(r'\b(Should\w+)\s*\(',original.decode()) if original is not None and p.startswith('test/') else []})
assert not missing,missing
assert not drift,drift
reconstruction=[]
for label,stages,hasred in [('clean-full',['full-from-clean.patch'],False),('clean-partitions',['implementation.patch','shared.patch','tests-from-clean.patch'],False),('red-full',['behavioral-boundary-red.patch','behavioral-admission-race-red.patch','full-after-red.patch'],True),('red-partitions',['behavioral-boundary-red.patch','behavioral-admission-race-red.patch','implementation.patch','shared.patch','tests-after-red.patch'],True)]:
 with tempfile.TemporaryDirectory(prefix='reconstruct-',dir=r) as tmp:
  target=Path(tmp);shutil.copytree(r/'base',target,dirs_exist_ok=True)
  (target/boundary).unlink(missing_ok=True)
  for stage in stages:
   result=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/stage)],cwd=target,text=True,capture_output=True)
   assert result.returncode==0,(label,stage,result.stdout,result.stderr)
  mismatch=[p for p in paths if (target/p).read_bytes()!=(r/'work'/p).read_bytes()]
  assert not mismatch,(label,mismatch)
  unchanged=[str(p.relative_to(r/'base')) for p in (r/'base').rglob('*') if p.is_file() and str(p.relative_to(r/'base')) not in paths and p.read_bytes()!=(target/p.relative_to(r/'base')).read_bytes()]
  assert not unchanged,(label,unchanged)
  reconstruction.append({'stage':label,'patches':stages,'allChangedPathsExact':True,'unrelatedBasePathsPreserved':True})
allnames=0;removed=[];assertdrops=[]
for p in (r/'base/test').rglob('*.cs'):
 rel=p.relative_to(r/'base');w=r/'work'/rel
 if not w.exists():continue
 old=p.read_text();new=w.read_text();names=re.findall(r'\b(Should\w+)\s*\(',old);allnames+=len(names)
 removed.extend({'path':str(rel),'name':name} for name in names if not re.search(r'\b'+name+r'\s*\(',new))
 if new.count('Assert.')<old.count('Assert.'):assertdrops.append(str(rel))
assert not removed and not assertdrops,(removed,assertdrops)
manifest={'status':'FROZEN','scope':'AdvisorHandoff and AdvisorFeedbackThread native immutable authored content, bounded runtime state, verified external history/read/projection/preparation cut','baseline':'Current main owning sources and fresh shared files; AdvisorUnit3 prefix already included; captured boundary RED is an explicit intermediate and absent clean baseline.','prerequisites':['Merged NativeOwnerHistory small3','Merged Calendar/SourceUse/Mapping reader finalizers and opaque-key safety decorator','Frozen/merged AdvisorUnit3 asynchronous preparation prefix'],'changedPaths':len(paths),'implementationPaths':len(impl),'sharedPaths':len(shr),'testPaths':len(tests),'existingOriginalBaselinePaths':sum(x['beforeSha256'] is not None for x in rows),'newCleanPaths':sum(x['cleanBeforeSha256'] is None for x in rows),'gates':{'existingRepositoryPathsMissingNonNullOriginalBefore':missing,'currentRepositoryOriginalBaselineDrift':drift,'allCapturedAcceptanceNamesPreserved':allnames,'removedAcceptanceNames':removed,'assertionCountDrops':assertdrops},'files':rows,'patches':{name:{'sha256':sha((r/name).read_bytes()),'paths':len(selected),'baselineMode':mode} for name,(selected,mode) in exports.items()},'reconstruction':reconstruction,'runtimeQualification':'No runtime, build, formatter, broker or Jev commands run by preparation agent. Parent reported current-API RED4 strict build succeeded and all four failed as intended in /tmp/compliance-next-families-red.log; Unit prefix RED2 previously qualified and GREEN/merged by parent. Parent owns all focused/full runtime and direct per-file Jev qualification.','oldApiRed':{'boundaryPatch':'behavioral-boundary-red.patch','boundarySha256':sha((r/'behavioral-boundary-red.patch').read_bytes()),'admissionPatch':'behavioral-admission-race-red.patch','admissionSha256':sha((r/'behavioral-admission-race-red.patch').read_bytes()),'filter':'FullyQualifiedName~AdvisorNativeBoundaryTests|FullyQualifiedName~AdvisorAdmissionPreparationRaceTests','parentReportedLog':'/tmp/compliance-next-families-red.log','parentLogSha256':sha(Path('/tmp/compliance-next-families-red.log').read_bytes()) if Path('/tmp/compliance-next-families-red.log').exists() else None},'staticAudit':'static-audit.json','qualifications':'LOCAL-QUALIFICATIONS.md'}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['changedPaths','implementationPaths','sharedPaths','testPaths','existingOriginalBaselinePaths','newCleanPaths','gates']},indent=2))
