from pathlib import Path
import re
r=Path('/tmp/compliance-advisor-history-prepared');w=r/'work';b=r/'base';c='src/Compliance.Core/Features/AdvisorCollaboration/'
# No lifetime history remains in either command owner. Native raw validation is finalized separately.
for name in ['AdvisorHandoff','AdvisorFeedbackThread']:
 s=(b/(c+name+'.cs')).read_text()
 if name=='AdvisorHandoff':
  s=s.replace('    readonly List<AdvisorFeedbackAdmitted> _admitted = [];\n','').replace('    readonly HashSet<Uuid> _admittedIds = [];\n','').replace('    readonly List<DomainEvent> _facts = [];\n','')
  s=s.replace('    long _generation;','    long _generation;\n    long _admissionCount;')
  s=re.sub(r'    /// <summary>The purpose stated at creation.</summary>\n    public string\? Purpose => _createdFact\?\.Purpose;\n\n','',s)
  a=s.index('    /// <summary>The feedback admitted so far');z=s.index('    /// <summary>True while the handoff can still change',a);s=s[:a]+'''    /// <summary>The count of accepted admissions, independent of selection generation.</summary>
    public long AdmissionCount => _admissionCount;
    public Uuid TenantId => _tenantId;
    internal AdvisorHandoffCreated? CreatedFact => _createdFact;

'''+s[z:]
  s=s.replace('ImmutableContentRef manifest, string purpose,','ImmutableContentRef manifest, ImmutableContentRef authored,').replace('manifest, purpose, expiresOn,','manifest, authored, expiresOn,')
  s=s.replace('ImmutableContentRef manifest, string changeReason,','ImmutableContentRef manifest, ImmutableContentRef authored,').replace('            changeReason, revisedBy,','            authored, revisedBy,')
  s=s.replace('OperationProvenance operation, string rationale,','OperationProvenance operation, ImmutableContentRef authored,').replace('_revision + 1, rationale,','_revision + 1, authored,')
  s=s.replace('''        if (_admittedIds.Contains(operation.LogicalId))
            return Conflict("The feedback identifier already has different content.");
''','')
  s=s.replace(' || !_admittedIds.Add(ev.Operation.LogicalId)','')
  s=s.replace('        _admitted.Add(ev);','        _admissionCount++;')
 else:
  for text in ['    readonly List<AdvisorFeedbackCorrected> _corrections = [];\n','    readonly List<AdvisorFeedbackResponded> _responses = [];\n','    readonly List<DomainEvent> _facts = [];\n']:s=s.replace(text,'')
  a=s.index('    /// <summary>The corrections in order;');z=s.index('    /// <summary>The resolution fact',a);s=s[:a]+s[z:]
  a=s.index('    /// <summary>The fact with this event id.');z=s.index('    /// <summary>Checks that the thread can be materialized.',a);s=s[:a]+'''    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;

'''+s[z:]
  s=s.replace('authored.Kind, authored.Body.Trim(), author,','authored.Kind, author,')
  s=s.replace('Uuid correctionId, string correctedBody,\n        string correctionReason,','Uuid correctionId, ImmutableContentRef authored,')
  s=s.replace('            correctedBody, correctionReason, correctedBy,','            authored, correctedBy,')
  s=s.replace('OperationProvenance operation, string response,','OperationProvenance operation, ImmutableContentRef authored,').replace('_feedbackId, response,','_feedbackId, authored,')
  s=s.replace('        _corrections.Add(ev);\n','').replace('        _responses.Add(ev);\n','')
 s=s.replace('        _facts.Add(ev);\n','').replace('        _facts.Add(fact);\n','')
 # All append paths require the exact selected finalized native cut. A genuinely empty owner proves its own absence.
 s=s.replace('    readonly Uuid _tenantId;','    readonly Uuid _tenantId;\n    readonly AdvisorReplayCut _cut = new();')
 s=s.replace('    /// <summary>Acceptance of the logical operation', '    internal AdvisorReplayCut ReplayCut => _cut;\n\n    /// <summary>Acceptance of the logical operation',1)
 # Place one guard immediately before the first RaiseEvent/branch in each business method, not reducers.
 methods=['Create','ReviseSelection','MarkReady','Close','Revoke','AdmitFeedback'] if name=='AdvisorHandoff' else ['Materialize','Correct','Respond','Resolve']
 for method in methods:
  a=s.index('    public Result '+method+'(');z=s.index('\n    }',a);part=s[a:z]
  at=part.index('        RaiseEvent(')
  part=part[:at]+'''        var append = _cut.Require(this, Acceptance, operation);
        if (!append.IsSuccess)
            return append;
'''+part[at:];s=s[:a]+part+s[z:]
 pos=s.index('    void Apply(');s=s[:pos]+'''    protected override void Apply(DomainEvent ev)
    {
        _cut.Observe(ev);
        base.Apply(ev);
    }

'''+s[pos:]
 (w/(c+name+'.cs')).write_text(s)
# Byte framing copies the qualified immutable metadata terms from Mapping; it adds no new protocol fact.
s=Path('/tmp/compliance-mapping-native-prepared/work/src/Compliance.Core/Features/ControlMappings/MappingLineReplayDigest.cs').read_text().replace('namespace Bdgrz.Compliance.Features.ControlMappings;','namespace Bdgrz.Compliance.Features.AdvisorCollaboration;').replace('MappingLineReplayDigest','AdvisorReplayDigest');(w/(c+'AdvisorReplayDigest.cs')).write_text(s)
(w/(c+'AdvisorReplayCut.cs')).write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AdvisorCollaboration;

/// <summary>Bounded proof of the actual hydrated native prefix, selected before an append.</summary>
sealed class AdvisorReplayCut
{
    bool _verified;
    ulong _version;
    ulong _position;
    public string Digest { get; private set; } = AdvisorReplayDigest.Empty;
    public void Observe(DomainEvent ev)
    {
        Digest = AdvisorReplayDigest.Append(Digest, ev);
        _verified = false;
    }
    public void Confirm(Aggregate owner, string digest)
    {
        if (Digest != digest)
            throw new ImmutableContentIntegrityException("The advisor native history differs from the actual hydrated payload/metadata prefix.");
        (_verified, _version, _position) = (true, owner.Version, owner.CommittedStreamPosition);
    }
    public Result Require(Aggregate owner, NativeAcceptance acceptance, OperationProvenance operation)
    {
        if (owner.Version == 0 && owner.CommittedStreamPosition == 0 && Digest == AdvisorReplayDigest.Empty)
            return Result.Success;
        if (!_verified || _version != owner.Version || _position != owner.CommittedStreamPosition ||
            acceptance.SelectedLogicalId != operation.LogicalId || acceptance.SelectedFact is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "An advisor append requires the exact selected finalized native owner cut.", true));
        return Result.Success;
    }
}
''')
