from pathlib import Path
r=Path('/tmp/compliance-advisor-history-prepared');w=r/'work';b=r/'base';c='src/Compliance.Core/Features/AdvisorCollaboration/'
# All complete authored values are prepared inside the already-frozen asynchronous Unit/native boundary.
for name in ['CreateAdvisorHandoff','ReviseAdvisorHandoffSelection']:
 p=w/(c+name+'Handler.cs');s=(b/(c+name+'Handler.cs')).read_text()
 s=s.replace('        ImmutableContentRef? manifest = null;', '        ImmutableContentRef? manifest = null;\n        ImmutableContentRef? authored = null;')
 needle='                    AdvisorContent.'+('CreatedSelectionSchema' if name.startswith('Create') else 'RevisedSelectionSchema')+', request.RecordVersions, token).ConfigureAwait(false);'
 assert needle in s
 s=s.replace(needle,needle+'\n                authored = await AdvisorAuthored.WriteAsync(content, request.TenantId, canonical, token).ConfigureAwait(false);')
 s=s.replace('manifest!, canonical.Purpose','manifest!, authored!').replace('manifest!, canonical.ChangeReason','manifest!, authored!')
 p.write_text(s)
for name in ['CloseAdvisorHandoff','RevokeAdvisorHandoff']:
 p=w/(c+name+'Handler.cs');s=(b/(c+name+'Handler.cs')).read_text()
 s='using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Proofs;\n'+s
 s=s.replace('AdvisorUnitOperation operation, TimeProvider clock','AdvisorUnitOperation operation, IImmutableContentStore content, TimeProvider clock')
 s=s.replace('        return operation.ExecuteAsync<AdvisorHandoff>', '        ImmutableContentRef? authored = null;\n        return operation.ExecuteAsync<AdvisorHandoff>')
 s=s.replace('            handoff => handoff.Acceptance, null,','''            handoff => handoff.Acceptance,
            async (_, token) =>
            {
                authored = await AdvisorAuthored.WriteAsync(content, request.TenantId, canonical, token).ConfigureAwait(false);
                return Result.Success;
            },''')
 s=s.replace('provenance, canonical.Rationale,','provenance, authored!,')
 p.write_text(s)
for name in ['CorrectAdvisorFeedback','RespondToAdvisorFeedback','ResolveAdvisorFeedback']:
 p=w/(c+name+'Handler.cs');s=(b/(c+name+'Handler.cs')).read_text().replace('IAggregateReader reader,','AdvisorFeedbackReader threads,')
 s=s.replace('AdvisorFeedbackLookup.RequireMaterializedAsync(reader,', 'AdvisorFeedbackLookup.RequireMaterializedAsync(threads,')
 if name!='ResolveAdvisorFeedback':
  s='using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Proofs;\n'+s
  s=s.replace('    TimeProvider clock)', '    IImmutableContentStore content, TimeProvider clock)')
  s=s.replace('        return operation.ExecuteAsync<AdvisorFeedbackThread>', '        ImmutableContentRef? authored = null;\n        return operation.ExecuteAsync<AdvisorFeedbackThread>')
  a=s.index('            (thread, token) => AdvisorFeedbackLookup.');z=s.index('            thread => thread.PrepareWrite',a)
  s=s[:a]+'''            async (thread, token) =>
            {
                var materialized = await AdvisorFeedbackLookup.RequireMaterializedAsync(threads, thread, request.TenantId,
                    request.ProgramId, request.HandoffId, request.FeedbackId, token).ConfigureAwait(false);
                if (!materialized.IsSuccess)
                    return materialized;
                authored = await AdvisorAuthored.WriteAsync(content, request.TenantId, canonical, token).ConfigureAwait(false);
                return Result.Success;
            },
'''+s[z:]
  s=s.replace('request.CorrectionId, canonical.CorrectedBody,\n                canonical.CorrectionReason, actor','request.CorrectionId, authored!, actor').replace('provenance, canonical.Response,','provenance, authored!,')
 p.write_text(s)
p=w/(c+'AdvisorFeedbackLookup.cs');s=(b/(c+'AdvisorFeedbackLookup.cs')).read_text().replace('IAggregateReader reader,','AdvisorFeedbackReader threads,')
a=s.index('        var handoff = await reader.HydrateAsync');z=s.index('            ? Result.Failure',a)
s=s[:a]+'''        var admitted = await threads.HasAdmissionAsync(tenantId, programId, handoffId, feedbackId, ct).ConfigureAwait(false);
        return admitted
'''+s[z:];p.write_text(s)
# The 202 admission path has its own asynchronous native preparation, never the Unit helper.
p=w/(c+'RecordAdvisorFeedbackHandler.cs');s=(b/(c+'RecordAdvisorFeedbackHandler.cs')).read_text().replace('NativeOperationExecutor operations, IAggregateReader reader,\n    AdvisorHandoffReader handoffs','NativeOperationExecutor operations, AdvisorHandoffReader handoffs')
a=s.index('        var snapshot = await reader.HydrateAsync');z=s.index('        var binding =',a)
s=s[:a]+'''        var owner = new AdvisorHandoff(request.TenantId, request.ProgramId, request.HandoffId).Stream;
        var provenance = AdvisorContent.Provenance(request.FeedbackId, CommandKind, owner, actor,
            (ulong)request.ExpectedHandoffRevision, AuthoredIntentDigest.Compute(canonical), now);
'''+s[z:]
a=s.index('        ImmutableContentRef? intent = null;');z=s.index('    static Result<OperationAcceptedResponse> Failure',a)
s=s[:a]+'''        ImmutableContentRef? intent = null;
        var outcome = await operations.ExecuteAsync(new NativeOperation<AdvisorHandoff>(binding,
            () => new AdvisorHandoff(request.TenantId, request.ProgramId, request.HandoffId, request.FeedbackId),
            handoff => handoff.Acceptance,
            async (handoff, token) =>
            {
                if (!AdvisorHandoffRules.InProgram(handoff, request.ProgramId))
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound,
                        "The advisor handoff was not found in the requested program."));
                var prepared = handoff.PrepareAdmit(request.ExpectedHandoffRevision, today);
                if (!prepared.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(prepared.Error!);
                if (!AdvisorHandoffRules.FeedbackKinds.Contains(request.Kind) || !sourceVersion.HasValidIdentity)
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Validation,
                        "Feedback must target a selected exact version and include a supported kind, body, and author."));
                var current = await handoffs.ReadAsync(handoff, request.TenantId, token).ConfigureAwait(false);
                if (!current.Selection.Contains(sourceVersion))
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Validation,
                        "Feedback must target a selected exact version and include a supported kind, body, and author."));
                var authored = await AdvisorContent.WriteAsync(content, request.TenantId,
                    AdvisorContent.FeedbackAuthoredSchema, canonical, token).ConfigureAwait(false);
                intent = await AdvisorContent.WriteAsync(content, request.TenantId,
                    ChildAdmissionIntent.Schema, new ChildAdmissionIntent(AdvisorContent.Header(provenance, now),
                        request.HandoffId, (ulong)handoff.Generation, AdmittedChildKind.AdvisorFeedback,
                        request.FeedbackId, authored,
                        await AdvisorContent.EmptyProofsAsync(content, request.TenantId, request.FeedbackId, token)
                            .ConfigureAwait(false), (ulong)request.ExpectedHandoffRevision + 1), token).ConfigureAwait(false);
                return Result<FirstResponseDescriptor>.Success(await AdvisorContent.AcceptedResponseAsync(content,
                    request.TenantId, request.FeedbackId, RegisterFirmStaffHandler.StatusUrlTemplate, now, token)
                    .ConfigureAwait(false));
            },
            (AdvisorHandoff handoff, ImmutableContentRef acknowledgment) =>
                handoff.AdmitFeedback(provenance, intent!, today, acknowledgment)), context, ct).ConfigureAwait(false);
        return await AdvisorContent.AcknowledgmentAsync(content, request.TenantId, outcome, ct).ConfigureAwait(false);
    }

'''+s[z:];p.write_text(s)
