from pathlib import Path
r=Path('/tmp/compliance-advisor-history-prepared');w=r/'work';b=r/'base';c='src/Compliance.Core/Features/AdvisorCollaboration/'
p=w/(c+'FitzAdvisorHandoffDirectory.cs');s=(b/(c+'FitzAdvisorHandoffDirectory.cs')).read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s
s=s.replace('    readonly IKvClient _directoryClient;', '    readonly IKvClient _directoryClient;\n    readonly IImmutableContentStore _content;').replace('public FitzAdvisorHandoffDirectory(IKvClient client)', 'public FitzAdvisorHandoffDirectory(IKvClient client, IImmutableContentStore content)')
s=s.replace('''        : base(client, "kv://bdgrz/advisor-handoff-directory/projection-v1", ProjectorName) =>
        _directoryClient = client;''','''        : base(client, "kv://bdgrz/advisor-handoff-directory/projection-v1", ProjectorName)
    {
        _directoryClient = client;
        _content = content;
    }''')
s=s.replace('''                await ApplyCreatedAsync(created, selection ?? throw InvalidEvent(), ct).ConfigureAwait(false);''','''                var creation = await AdvisorAuthored.ReadAsync(_content, created, ct).ConfigureAwait(false);
                await ApplyCreatedAsync(created, creation, selection ?? throw InvalidEvent(), ct).ConfigureAwait(false);''')
s=s.replace('''            case AdvisorHandoffSelectionRevised revised:
                if''','''            case AdvisorHandoffSelectionRevised revised:
                var revision = await AdvisorAuthored.ReadAsync(_content, revised, ct).ConfigureAwait(false);
                if''').replace('!ValidSelection(selection) ||\n                    string.IsNullOrWhiteSpace(revised.ChangeReason)', '!ValidSelection(selection) || !selection!.SequenceEqual(revision.RecordVersions) ||\n                    string.IsNullOrWhiteSpace(revision.ChangeReason)').replace('revised.ChangeReason.Trim() != revised.ChangeReason','revision.ChangeReason.Trim() != revision.ChangeReason')
s=s.replace('''            case AdvisorHandoffClosed closed:
                if''','''            case AdvisorHandoffClosed closed:
                var closure = await AdvisorAuthored.ReadAsync(_content, closed, ct).ConfigureAwait(false);
                if''').replace('closed.Rationale','closure.Rationale')
s=s.replace('''            case AdvisorHandoffRevoked revoked:
                if''','''            case AdvisorHandoffRevoked revoked:
                var revocation = await AdvisorAuthored.ReadAsync(_content, revoked, ct).ConfigureAwait(false);
                if''').replace('revoked.Rationale','revocation.Rationale')
s=s.replace('async ValueTask ApplyCreatedAsync(AdvisorHandoffCreated ev, IReadOnlyList<AdvisorRecordVersion> selection,','async ValueTask ApplyCreatedAsync(AdvisorHandoffCreated ev, CreateAdvisorHandoff authored,\n        IReadOnlyList<AdvisorRecordVersion> selection,')
s=s.replace('ev.Purpose','authored.Purpose').replace('''            !ValidSelection(selection) ||
            (ev.ComparedToHandoffId''','''            !ValidSelection(selection) || !selection.SequenceEqual(authored.RecordVersions) ||
            (ev.ComparedToHandoffId''')
p.write_text(s)
p=w/(c+'FitzAdvisorFeedbackWorkItemDirectory.cs');s=(b/(c+'FitzAdvisorFeedbackWorkItemDirectory.cs')).read_text();s='using Bdgrz.Compliance.Features.Content;\n'+s;s=s.replace('(IKvClient client)', '(IKvClient client, IImmutableContentStore content)',1)
s=s.replace('''    async ValueTask RecordAsync(AdvisorFeedbackRecorded ev, CancellationToken ct)
    {
        var source''','''    async ValueTask RecordAsync(AdvisorFeedbackRecorded ev, CancellationToken ct)
    {
        var contribution = await AdvisorFeedbackReader.ReadRecordedAsync(content, ev, ct).ConfigureAwait(false);
        var source''').replace('ev.Body','contribution.Body')
s=s.replace('''    async ValueTask CorrectAsync(AdvisorFeedbackCorrected ev, CancellationToken ct)
    {
        if''','''    async ValueTask CorrectAsync(AdvisorFeedbackCorrected ev, CancellationToken ct)
    {
        var authored = await AdvisorAuthored.ReadAsync(content, ev, ct).ConfigureAwait(false);
        if''').replace('ev.CorrectedBody','authored.CorrectedBody').replace('ev.CorrectionReason','authored.CorrectionReason')
s=s.replace('''    async ValueTask RespondAsync(AdvisorFeedbackResponded ev, CancellationToken ct)
    {
        if''','''    async ValueTask RespondAsync(AdvisorFeedbackResponded ev, CancellationToken ct)
    {
        var authored = await AdvisorAuthored.ReadAsync(content, ev, ct).ConfigureAwait(false);
        if''').replace('ev.Response','authored.Response')
p.write_text(s)
