from pathlib import Path
import json,hashlib
r=Path('.');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
files=['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','docs/product/aggregate-boundary-ledger.md']
meta=json.loads((r/'baselines.json').read_text())
for name in files:
 before=(repo/name).read_text();after=before
 if 'PersistenceServiceCollection' in name:
  after='using Bdgrz.Compliance.Features.AdvisorCollaboration;\n'+after
  anchor='''        Decorate<IRequestBus>(services, (_, inner) => new PersistenceValidationRequestBus(inner));'''
  assert after.count(anchor)==1
  after=after.replace(anchor,'''        Decorate<IAggregateReader>(services, (provider, inner) =>
            new AdvisorAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));
'''+anchor)
 elif 'ComplianceServiceCollection' in name:
  anchor='        services.AddScoped<AdvisorHandoffReader>();'
  assert after.count(anchor)==1
  after=after.replace(anchor,anchor+'\n        services.AddScoped<AdvisorFeedbackReader>();')
 elif name.endswith('.md'):
  old=next(x for x in after.splitlines() if x.startswith('| `AdvisorHandoff` |'))
  new='| `AdvisorHandoff` | `handoffId, new EventStreamAddress(tenantId.ToString(), "advisor-handoffs", handoffId.ToString())` | Current selection reference, lifecycle/generation/revision and admission count; exact-cut selected native acceptance. Admission serializes with closure/revocation; complete admitted history is verified by the external reader. | bounded native frames reference complete canonical authored bytes and selection; complete transient raw validation preserves duplicate fences for explicit reads, executor hydration and retry; current selection policy remains 100 | [source](../../src/Compliance.Core/Features/AdvisorCollaboration/AdvisorHandoff.cs) |\n| `AdvisorFeedbackThread` | `AggregateIdentity.Create(OwnerType, tenantId, programId, handoffId, feedbackId)` in `advisor-feedback` | Original compact admitted contribution, current resolution/revision and selected native acceptance; authored corrections/responses and full history compose outside the owner. | complete original body uses the actual immutable admission intent; corrections/responses reference canonical authored bytes; no lifetime history collections or authored-text cap | [source](../../src/Compliance.Core/Features/AdvisorCollaboration/AdvisorFeedbackThread.cs) |'
  assert '| `AdvisorFeedbackThread` |' not in after
  after=after.replace(old,new)
 for d,content in [('base',before),('work',after)]:
  p=r/d/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
 for item in meta:
  if item['path']==name:
   item['baselineSource']=str(repo/name)+' (fresh read after root #1120 integration; unrelated current work preserved)'
   item['beforeSha256']=hashlib.sha256(before.encode()).hexdigest()
(r/'baselines.json').write_text(json.dumps(meta,indent=2)+'\n')
