from pathlib import Path
r=Path('work/src/Compliance.Core/Features/AdvisorCollaboration')
p=r/'MaterializeAdvisorFeedbackHandler.cs';s=p.read_text();needle='''    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<MaterializeAdvisorFeedback> context,
        CancellationToken ct)
    {'''; repl='''    public ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<MaterializeAdvisorFeedback> context,
        CancellationToken ct) => AdvisorFailures.ClassifyAsync(() => HandleCoreAsync(context, ct), ct);

    async ValueTask<Result<ReceiverOutcome>> HandleCoreAsync(IRequestContext<MaterializeAdvisorFeedback> context,
        CancellationToken ct)
    {''';assert needle in s;s=s.replace(needle,repl)
s=s.replace('''        catch (ImmutableContentUnavailableException exception)
        {
            return''','''        catch (ImmutableContentUnavailableException exception)
        {
            ct.ThrowIfCancellationRequested();
            return''').replace('''        catch (ImmutableContentIntegrityException exception)
        {
            return''','''        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return''')
s=s.replace('''admitted.Operation.LogicalId != command.FeedbackId || admitted.Operation.RootOperationId != command.OperationId)''','''admitted.Operation.LogicalId != command.FeedbackId || admitted.Operation.RootOperationId != command.OperationId ||
            intent.Header != AdvisorContent.Header(admitted.Operation, admitted.Operation.AcceptedAt) ||
            intent.ParentGeneration != (ulong)admitted.Generation || intent.ParentAdmissionRevision != (ulong)admitted.Revision)''')
needle='''        var binding = AcceptedOperationBinding.Of(provenance);''';s=s.replace(needle,'''        _ = await AdvisorFeedbackReader.ReadRecordedAsync(content, new AdvisorFeedbackRecorded(tenant,
            authored.ProgramId, command.HandoffId, command.FeedbackId, authored.RecordId, authored.RecordVersionId,
            authored.Kind, intent.Header.OriginalActor, intent.Header.AcceptedAt, provenance, command.Intent, null, null)
            { SelectedSource = authored.SelectedSource }, ct).ConfigureAwait(false);
        var binding = AcceptedOperationBinding.Of(provenance);''')
p.write_text(s)
p=r/'AdvisorHandoff.cs';s=p.read_text().replace('Advance(ev, ', 'Advance(').replace('void Advance(DomainEvent fact, DateTimeOffset occurredAt)', 'void Advance(DateTimeOffset occurredAt)');p.write_text(s)
p=r/'AdvisorFeedbackThread.cs';s=p.read_text().replace('Advance(ev);','Advance();').replace('void Advance(DomainEvent fact)', 'void Advance()');p.write_text(s)
p=Path('work/test/Compliance.Tests/Features/AdvisorCollaboration/AdvisorFeedbackScopedIdentityTests.cs');s=p.read_text().replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;')
s=s.replace('new FitzAdvisorFeedbackWorkItemDirectory(source.Kv)','new FitzAdvisorFeedbackWorkItemDirectory(source.Kv, source.Content)')
s=s.replace('''        var operation = OwnerProvenance.For(first, Uuid.CreateVersion4(), "ResolveAdvisorFeedback", manager, "initial", 1,''','''        var commandId = Uuid.CreateVersion4();
        first = await source.Reader.HydrateAsync(new AdvisorFeedbackThread(tenant, firstProgram, firstHandoff, shared, commandId));
        _ = await AdvisorNativeHistory.ReadAsync(first, source.Events, CancellationToken.None);
        var operation = OwnerProvenance.For(first, commandId, "ResolveAdvisorFeedback", manager, "initial", 1,''')
s=s.replace('author, "initial", 1, new string(\'a\', 64), Now)', 'author, "initial", 1, AuthoredIntentDigest.Compute(authored), Now)').replace('new ChildAdmissionIntent(header, handoff, 0,','new ChildAdmissionIntent(header, handoff, 1,')
p.write_text(s)
