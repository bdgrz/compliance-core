# Scoped audit-package read producers

Prepared offline from current main S29 source. No main edits, builds, tests, Git writes, or GitHub writes performed.

For actual runtime RED evidence, apply `http-red-tests.patch` alone. Its production-host fixture seeds real native packages and uses only existing baseline APIs. Run `AuditPackageReadHttpTests` with WebIntegration enabled: the baseline has no GET producer, while the canonical path already accepts PUT. Then apply `tests-after-http-red.patch`, `implementation.patch`, and `shared.patch`, format/compile, and rerun `AuditPackageReadHandlerTests` plus `AuditPackageReadHttpTests`. For direct application, `tests.patch` supplies both complete test files from baseline.

The new directory is created-only discovery with a stable program/creation/ID keyset index. It projects no lifecycle status. Each list page composes current package views from existing native owner/content readers and returns a caught-up source checkpoint fence before and after composition. Unknown/foreign owner reads are NotFound; missing content is transient Conflict; corrupt content is permanent Conflict. List failures return no partial page. The query limit is bounded to 1–200; cursor validation uses the installed KvDirectory route/query binding.

Shared deltas are exactly two files: Core DI adds directory aliases, consistency, both handlers, and the per-tenant projector; App maps scoped GET collection and canonical `{package_id}` detail path. Detail binding uses the supported existing `OnBind(HttpContext)` API and the existing route UUID parser, with explicit route metadata. No duplicate `{audit_package_id}` path is added. Existing Core JSON metadata already includes all three view/page types, so no JSON registration change is required. No MCP exposure is added. Parent should regenerate aggregate-command-coverage.json from final source.

Regressions exercise actual native fixture storage and actual KvDirectory pages: full scope and no cross-scope content access; positive exact read; missing/corrupt content classifications; current lifecycle versus stale identity row; creation-order pagination despite later update; tenant/program cursor rejection; invalid bounds/cursor; projection lag; no partial page; source append and projector advancement races; replay/conflicting identity projection; production HTTP binding, scoped permission, and OpenAPI canonical path metadata.

Only syntax parsing and exact patch reconstruction were performed here. Parent owns runtime RED/GREEN, analyzers, full suite and direct Jev review.
