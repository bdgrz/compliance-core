from pathlib import Path
import difflib
import hashlib
import json
import re
import tree_sitter
import tree_sitter_c_sharp

OUT = Path('/tmp/compliance-control-consumers-prepared')
ROOT = Path('/Users/jrepanich/Code/bdgrz/compliance-core')
parser = tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()))
changed = {}


def baseline(path):
    prepared = OUT / 'after' / path
    return (prepared if prepared.exists() else ROOT / path).read_text()


def put(path, text, phase='body', red=None):
    changed[path] = dict(before=baseline(path) if (OUT / 'after' / path).exists() or (ROOT / path).exists() else None,
                         after=text, phase=phase, red=red)
    target = OUT / 'seam-after' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)


def diff(path, before, after):
    text = f'diff --git a/{path} b/{path}\n'
    if before is None:
        text += 'new file mode 100644\n'
    return text + ''.join(difflib.unified_diff((before or '').splitlines(True), after.splitlines(True),
        fromfile='/dev/null' if before is None else 'a/' + path, tofile='b/' + path))


test_path = 'test/Compliance.Tests/Features/Examinations/ControlTypeIBaselineSourceContributorTests.cs'
test = baseline(test_path)
regression = '''    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ShouldReturnClassifiedSourceFailureGivenUnreadableNativeControlContent(bool unavailable)
    {
        // Arrange
        var control = ApprovedControl("AC-UNREADABLE", new DateOnly(2026, 9, 1));
        await using var source = await NativeSource.CreateAsync(control);
        var before = await source.Controls.ReadAsync(TenantId, ProgramId, control.Id);
        var contributor = Contributor(new Directory([control]), source, source.WithReadFailure(unavailable));

        // Act
        var result = await contributor.ReadAsync(Engagement(new DateOnly(2026, 9, 30)), CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error.Kind);
        Assert.Equal(unavailable, result.Error.IsTransient);
        var retained = await source.Controls.ReadAsync(TenantId, ProgramId, control.Id);
        Assert.Equal(before.Owner.CommittedStreamPosition, retained.Owner.CommittedStreamPosition);
    }

'''
marker = '    [Fact]\n    public async Task ShouldBindControlVersionEffectiveOnTypeIDateGivenApprovedSuccessor()'
assert test.count(marker) == 1
test = test.replace(marker, regression + marker)
test = test.replace('IControlDraftDirectoryReader directory, NativeSource source)',
                    'IControlDraftDirectoryReader directory, NativeSource source, ControlReader? controls = null)')
test = test.replace('return new(directory, source.Controls, new ControlDraftListReadConsistency(directory, source.Events));',
                    'return new(directory, controls ?? source.Controls, new ControlDraftListReadConsistency(directory, source.Events));')
marker = '        public static async Task<NativeSource> CreateAsync(ControlRules control)'
test = test.replace(marker, '''        public ControlReader WithReadFailure(bool unavailable) =>
            new(_reader, Events, new FailingReads(_content, unavailable));

''' + marker)
marker = '    sealed class NativeSource : IAsyncDisposable'
test = test.replace(marker, '''    sealed class FailingReads(IImmutableContentStore inner, bool unavailable) : IImmutableContentStore
    {
        public Task<Bdgrz.Compliance.Features.Proofs.ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId,
            string schema, string mediaType, ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);

        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm,
            Bdgrz.Compliance.Features.Proofs.ImmutableContentRef reference, CancellationToken ct = default) =>
            Task.FromException<ReadOnlyMemory<byte>>(unavailable
                ? new ImmutableContentUnavailableException("The selected content is not visible yet.")
                : new ImmutableContentIntegrityException("The selected content does not verify."));
    }

''' + marker)
put(test_path, test, 'tests')

# A bounded content-family classifier shared by the direct consumer entrypoints. Native/projector
# writes continue to propagate all unrelated faults and cancellation normally.
helper_path = 'src/Compliance.Core/Features/Controls/ControlSourceFailures.cs'
put(helper_path, '''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Controls;

/// <summary>Classifies expected native content-read failures at the consumer result boundary.</summary>
static class ControlSourceFailures
{
    public static async ValueTask<Result<T>> ClassifyAsync<T>(Func<ValueTask<Result<T>>> read)
    {
        try
        {
            return await read().ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            return Result<T>.Failure(ControlReadFailure.Of(error));
        }
    }

    public static async ValueTask<Result> ClassifyAsync(Func<ValueTask<Result>> read)
    {
        try
        {
            return await read().ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            return Result.Failure(ControlReadFailure.Of(error));
        }
    }
}
''')


def descendants(node):
    yield node
    for child in node.children:
        yield from descendants(child)


def wrap(path, method_name, longest=False):
    source = baseline(path)
    data = source.encode()
    methods = []
    for node in descendants(parser.parse(data).root_node):
        if node.type != 'method_declaration':
            continue
        name = node.child_by_field_name('name')
        if data[name.start_byte:name.end_byte].decode() != method_name:
            continue
        parameters = next(child for child in node.children if child.type == 'parameter_list')
        methods.append((node, name, parameters))
    assert methods, (path, method_name)
    if longest:
        methods = [max(methods, key=lambda item: len(item[2].children))]
    assert len(methods) == 1, (path, method_name, len(methods))
    node, name, parameters = methods[0]
    body = node.child_by_field_name('body')
    if body is None:
        body = next(child for child in node.children if child.type == 'arrow_expression_clause')
    head = data[node.start_byte:body.start_byte].decode()
    assert 'ValueTask<Result' in head, head
    core_name = method_name.removesuffix('Async') + 'CoreAsync'
    assert core_name not in source, (path, core_name)
    arguments = []
    for parameter in parameters.children:
        if parameter.type != 'parameter':
            continue
        parameter_name = parameter.child_by_field_name('name')
        arguments.append(data[parameter_name.start_byte:parameter_name.end_byte].decode())
    public_head = re.sub(r'\basync\s+', '', head).rstrip()
    wrapper = public_head + ' =>\n        ControlSourceFailures.ClassifyAsync(() => ' + core_name + '(' + ', '.join(arguments) + '));'
    original = data[node.start_byte:node.end_byte].decode()
    core = original[:name.start_byte-node.start_byte] + core_name + original[name.end_byte-node.start_byte:]
    core = re.sub(r'^(?:public|internal|protected|private)\s+', '', core)
    replacement = wrapper + '\n\n    ' + core
    text = data[:node.start_byte].decode() + replacement + data[node.end_byte:].decode()
    put(path, text)


features = 'src/Compliance.Core/Features/'
targets = [
    ('AdvisorCollaboration/AdvisorRecordVersionResolver.cs', 'RequireCurrentAsync'),
    ('AdvisorCollaboration/AdvisorSharedSourceReader.cs', 'GetAsync'),
    ('Commitments/CommitmentImpactService.cs', 'PreviewAsync'),
    ('ControlMappings/ListCriteriaCoverageHandler.cs', 'HandleAsync'),
    ('Controls/ControlResponsibilityScopeValidator.cs', 'ValidateAsync'),
    ('Controls/ControlImpactService.cs', 'PreviewAsync'),
    ('Evaluations/RaiseEvaluationDeviationFindingHandler.cs', 'HandleAsync'),
    ('Evidence/OpenEvidenceRequestHandler.cs', 'HandleAsync'),
    ('Evidence/EvidenceSupportTargetSource.cs', 'RequireExactAsync'),
    ('Examinations/ControlTypeIBaselineSourceContributor.cs', 'ReadAsync'),
    ('Providers/ProviderChangeImpactService.cs', 'PreviewAsync'),
    ('Readiness/RunReadinessAssessmentHandler.cs', 'HandleAsync'),
    ('Operations/ProposeTypeIIOperatingPlanHandler.cs', 'HandleAsync'),
    ('Operations/StartTypeIIObservationPeriodHandler.cs', 'HandleAsync'),
    ('Work/WorkSource.cs', 'LoadAsync'),
    ('Work/ControlDecisionWork.cs', 'LoadAsync'),
    ('Work/FitzControlOperatingPlanWorkItemDirectory.cs', 'LoadProgramAsync'),
    ('Work/FitzControlOccurrenceWorkItemDirectory.cs', 'LoadProgramAsync'),
]
for name in [
    'ListControlOccurrences', 'GetControlOperatingPlan', 'ReviewControlOccurrence', 'GetControlOccurrence',
    'OpenControlOccurrence', 'ApproveControlOperatingPlan', 'ListControlOperatingBlockers',
    'ProposeControlOperatingPlan', 'PreviewControlOperatingPlan', 'AttestControlOccurrence', 'CorrectControlAttestation']:
    targets.append(('Operations/' + name + 'Handler.cs', 'HandleAsync'))
for name in ['StartControlEvaluation', 'GetControlEvaluation', 'DefineControlEvaluationPlan',
             'GetControlEvaluationPlanVersion', 'ListControlEvaluationPlanVersions', 'ListControlEvaluations']:
    targets.append(('Evaluations/' + name + 'Handler.cs', 'HandleAsync'))
for path, method in targets:
    wrap(features + path, method, longest=method == 'LoadProgramAsync')

path = 'test/Compliance.Tests/Features/AccessControl/AttestManagementWriteWallTests.cs'
text = baseline(path)
assert '"ControlDraftDirectoryV2"' in text
put(path, text.replace('"ControlDraftDirectoryV2"', 'FitzControlDraftDirectoryV2.ProjectorName'))

phases = {'tests': [], 'body': []}
manifest = []
for path, row in sorted(changed.items()):
    phases[row['phase']].append(diff(path, row['before'], row['after']))
    manifest.append(dict(path=path, phase=row['phase'],
        beforeSha256=hashlib.sha256(row['before'].encode()).hexdigest() if row['before'] is not None else None,
        afterSha256=hashlib.sha256(row['after'].encode()).hexdigest()))
(OUT / 'late-seam.tests.patch').write_text(''.join(phases['tests']))
(OUT / 'late-seam.patch').write_text(''.join(phases['body']))
(OUT / 'late-seam-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(files=len(manifest), wrappers=len(targets),
    testsSha256=hashlib.sha256((OUT/'late-seam.tests.patch').read_bytes()).hexdigest(),
    bodySha256=hashlib.sha256((OUT/'late-seam.patch').read_bytes()).hexdigest()), indent=2))
