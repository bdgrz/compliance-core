# Native Control consumer migration

Prepared outside the checkout. No main/worktree/index/branch/commit/PR/GitHub changes and no .NET build/test process was started. Parent owns integration, actual behavioral RED/GREEN, strict compilation, focused/full units, contract qualification and direct current-file Jev review.

## Split and exact APIs

`integrate_s30` owns compact ControlDraft, immutable change/fact/authority contracts, native producers (including the Control branches of shared responsibility handlers), read/history/proof services, Controls projectors/directories, all Features/Controls tests and ControlSeeds. This artifact owns existing remaining consumer sources, their tests, Applications event consumers and Controls impact consumers.

Agreed concrete API: `ControlReader(IAggregateReader, IDomainEventReader, IImmutableContentStore)`, `ReadAsync(tenant,program,control,ct)` plus exact tenant/control discovery overload, returning source-backed `ControlReadSnapshot`; `RulesAsync` overloads return a transient rule fold for test preparation. Scope mismatch hides visibility. All production consumer reads use that service. No old aggregate `.Current` or whole-history property compatibility shim was added. Snapshot composition exposes immutable version/approval/retirement history, exact current responsibilities and pending review metadata outside command state.

Native fact interfaces and headers are read from the owner's prepared declarations. `Header.Revision` is post-operation logical content revision, independent of NativeSequence; successor/withdrawal publish their content change atomically. Applications indexes thaw exact immutable content through `ControlFactContent.ReadDraftAsync`; reference/work updates skip `ChangeCount==0` roots. Indexes remain discovery inputs and never become command authority.

## Preserved behavior

- Current readers retain tenant/program/control identity and exact revision/version checks, current caller/disclosure authorization, source-use fences that already exist, and current-target validation.
- Readiness retains original approval and retirement decision times for exact historical-as-of selection and half-open version intervals. Baseline reads retain canonical hashes and directory checkpoint fencing.
- Operations/evaluations use native control current versions and effective windows. Work retains pending target/review round, original author/reviewer exclusions, current responsibility assignments, current permission checks, tenant scope and projection checkpoint fences.
- Impact previews retain every registered owning-context contribution and stable source-derived content. Public contributor contracts now accept read snapshots rather than a foreign live owner.
- Existing valid seed IDs derive from documented ControlDraft.IdFor. Production create uniqueness is preserved. Projection-only malformed fixtures intentionally retain authored wrong scope/order/IDs and freeze a complete native envelope without saving through the owner.
- Shared test helpers publish real native operations via ControlSeeds. The Type I baseline tests now use a real event store, content store and native reader; no aggregate-reader owner stub stands in for source proof.

## Applying

`manifest.json` records every baseline/proposed SHA. Foundation evidence-support constructor/replay changes are composed into affected before snapshots and must integrate first. `bounded-current-read/implementation-and-migrations.patch` is the first 11-file review cluster; it is a subset of the main group patches, so do not apply it twice.

The nine group `implementation.patch` files partition the complete changed paths. Consumer constructor/seed changes are migration tests, not independent RED proofs. Apply only together with the owner's native contract/body patches once its owner behavioral RED is recorded. `shared-test-fixtures/implementation.patch` is a separate ProgramManagementServices native overload/reader registration delta; coordinate its use with the owner's Controls tests. `shared-di-deltas.patch` adds the sole extra consumer-required production registration, ControlReader; parent owns reproducing it in shared wiring. No new route, JSON contract or receiver registration is invented by this consumer artifact. The owner's new fact/mutation JSON registrations remain its separate wiring obligation.

## Static evidence and remaining gates

`syntax-audit.json` compares real C# syntax trees before/after. The grammar reports a few already-valid new C# forms in the baseline; no additional syntax diagnostics were introduced. `acceptance-preservation.json` proves all 339 existing Fact/Theory method names in changed tests remain. `applicability.json` records all nine patch groups applied cleanly to isolated plain snapshots and every after SHA reproduced. These checks do not prove compilation, runtime behavior, broker safety or deployment readiness.

The owner's reader/fact/factory/ControlSeeds APIs are physically saved and the exact ControlOperations/shared responsibility constructor agreement is applied. Both explicit MemberAssignmentLag constructors and their minimal real native dependencies are migrated; ProgramManagementServices registers both ControlReader and ControlOperations. The owner's remaining body/test completion and actual strict compilation remain parent integration gates. `local-contract-dependencies.json` records the separate selected Control source-use pair gap reported by the owner; it does not block these existing read migrations, and ISourceUseOwner alone must not be described as acquisition support. No new issue was opened.
