from pathlib import Path
import collections
import hashlib
import json
import re
import shutil
import subprocess
import tree_sitter
import tree_sitter_c_sharp

OUT = Path('/tmp/compliance-control-consumers-prepared')
ROOT = Path('/Users/jrepanich/Code/bdgrz/compliance-core')
rows = json.loads((OUT / 'manifest.json').read_text())
parser = tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()))


def inspect(text):
    data = text.encode()
    root = parser.parse(data).root_node
    errors = []
    tests = []

    def walk(node):
        if node.type == 'ERROR' or node.is_missing:
            errors.append((node.type, data[node.start_byte:node.end_byte].decode(), node.start_point.row + 1))
        if node.type == 'method_declaration':
            name = node.child_by_field_name('name')
            attrs = [data[child.start_byte:child.end_byte].decode()
                     for child in node.children if child.type == 'attribute_list']
            if any('Fact' in attr or 'Theory' in attr for attr in attrs):
                tests.append(data[name.start_byte:name.end_byte].decode())
        for child in node.children:
            walk(child)

    walk(root)
    return errors, tests


syntax_rows = []
test_rows = []
for row in rows:
    before = (OUT / 'before' / row['path']).read_text() if row['beforeSha256'] else ''
    after = (OUT / 'after' / row['path']).read_text()
    old_errors, old_tests = inspect(before)
    new_errors, new_tests = inspect(after)
    old = collections.Counter((kind, text.replace('ControlDraft,', 'ControlReadSnapshot,'))
                              for kind, text, _ in old_errors)
    added = []
    for kind, text, line in new_errors:
        if old[(kind, text)]:
            old[(kind, text)] -= 1
        else:
            added.append(dict(line=line, kind=kind, code=text[:250]))
    syntax_rows.append(dict(path=row['path'], baselineParserErrors=len(old_errors),
                            proposedParserErrors=len(new_errors), newParserErrors=added))
    if row['path'].startswith('test/'):
        removed = sorted((collections.Counter(old_tests) - collections.Counter(new_tests)).elements())
        test_rows.append(dict(path=row['path'], beforeCount=len(old_tests), afterCount=len(new_tests), removed=removed))

syntax = dict(method='Tree-sitter C# before/after syntax comparison. The grammar flags some existing new-language forms; identical baseline diagnostics are accounted for. No compiler or runtime claim.',
              files=len(rows), newErrors=[row for row in syntax_rows if row['newParserErrors']], rows=syntax_rows)
(OUT / 'syntax-audit.json').write_text(json.dumps(syntax, indent=2) + '\n')
(OUT / 'acceptance-preservation.json').write_text(json.dumps(dict(
    method='Exact existing Fact/Theory method-name and count comparison; not test execution.',
    methodsBefore=sum(row['beforeCount'] for row in test_rows),
    methodsAfter=sum(row['afterCount'] for row in test_rows),
    removed=[row for row in test_rows if row['removed']], rows=test_rows), indent=2) + '\n')

validation = OUT / 'validation'
if validation.exists():
    shutil.rmtree(validation)
validation.mkdir()
for row in rows:
    if row['beforeSha256'] is not None:
        target = validation / row['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(OUT / 'before' / row['path'], target)

applied = []
for group in sorted({row['group'] for row in rows}):
    patch = OUT / group / 'implementation.patch'
    result = subprocess.run(['git', 'apply', '--unsafe-paths', '--directory=' + str(validation.resolve()), str(patch)],
                            cwd=ROOT, capture_output=True, text=True)
    applied.append(dict(group=group, exit=result.returncode, error=result.stderr,
                        patchSha256=hashlib.sha256(patch.read_bytes()).hexdigest()))
    assert result.returncode == 0, result.stderr
for row in rows:
    assert hashlib.sha256((validation / row['path']).read_bytes()).hexdigest() == row['afterSha256'], row['path']
(OUT / 'applicability.json').write_text(json.dumps(dict(
    method='Plain-file isolated snapshot patch application only; no Git worktree, index or main mutation.',
    files=len(rows), allProposedHashesReproduced=True, groups=applied), indent=2) + '\n')

print(json.dumps(dict(files=len(rows), newSyntaxErrors=sum(len(row['newParserErrors']) for row in syntax_rows),
                      existingAcceptanceMethods=sum(row['beforeCount'] for row in test_rows),
                      removedAcceptanceMethods=sum(len(row['removed']) for row in test_rows),
                      patchGroups=len(applied), allProposedHashesReproduced=True), indent=2))
