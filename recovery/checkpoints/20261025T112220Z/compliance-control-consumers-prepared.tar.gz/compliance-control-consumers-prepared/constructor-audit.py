from pathlib import Path
import tree_sitter,tree_sitter_c_sharp,json
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core');out=Path('/tmp/compliance-control-consumers-prepared');owner=Path('/tmp/compliance-control-owners-prepared/work');rows=json.loads((out/'manifest.json').read_text());parser=tree_sitter.Parser(tree_sitter.Language(tree_sitter_c_sharp.language()));known={}
def descend(n):
 yield n
 for c in n.children:yield from descend(c)
def signature(t,param):
 ps=[c for c in param.children if c.type=='parameter']
 return (sum(b'=' not in t[p.start_byte:p.end_byte] for p in ps),len(ps))
for row in rows:
 if not row['path'].startswith('src/'):continue
 t=(out/'after'/row['path']).read_bytes()
 for n in descend(parser.parse(t).root_node):
  if n.type=='class_declaration' and n.child_by_field_name('name'):
   name=t[n.child_by_field_name('name').start_byte:n.child_by_field_name('name').end_byte].decode();param=next((c for c in n.children if c.type=='parameter_list'),None)
   if param:known.setdefault(name,[]).append(signature(t,param))
for name in ['ReviseControlDraft','ProposeControlSuccessor','ProposeControlRetirement','DiscardControlDraft','DesignateControlOwnerPerson','WithdrawControlProposal','RetireControl','AssignResponsibility','RevokeResponsibility']:
 paths=list(owner.glob('src/Compliance.Common/Features/*/'+name+'.cs'))
 assert len(paths)==1,(name,paths)
 t=paths[0].read_bytes()
 for n in descend(parser.parse(t).root_node):
  if n.type=='record_declaration':
   param=next(c for c in n.children if c.type=='parameter_list');known[name]=[signature(t,param)];break
# Shared producers are authored concurrently; these exact signatures were agreed by the owning agent.
known['AssignResponsibilityHandler']=[(6,6)]
known['RevokeResponsibilityHandler']=[(4,4)]
known['ControlOperations']=[(5,6)]
errors=[];checked=0
for f in (root/'test/Compliance.Tests').rglob('*.cs'):
 if '/Features/Controls/' in str(f):continue
 rel=str(f.relative_to(root));p=out/'after'/rel;t=(p if p.exists() else f).read_bytes()
 for n in descend(parser.parse(t).root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((c for c in n.children if c.type=='argument_list'),None)
  if typ is None or args is None:continue
  name=t[typ.start_byte:typ.end_byte].decode().split('.')[-1]
  if name not in known:continue
  count=sum(c.type=='argument' for c in args.children);checked+=1
  if not any(low<=count<=high for low,high in known[name]):errors.append(dict(path=rel,line=n.start_point.row+1,type=name,arguments=count,accepted=known[name]))
report={'method':'Static C# explicit-constructor arity check against prepared declarations plus the exact agreed shared producer signatures; overload resolution/type semantics and implicit new remain compiler gates. Owner Controls tests excluded by split.','checked':checked,'errors':errors,'signatures':known}
(out/'constructor-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('Checked',checked,'mismatches',len(errors));print(json.dumps(errors,indent=2))
