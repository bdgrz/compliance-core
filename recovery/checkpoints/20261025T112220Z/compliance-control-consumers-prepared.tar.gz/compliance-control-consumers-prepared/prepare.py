from pathlib import Path
import difflib
import hashlib
import json
import re

ROOT = Path('/Users/jrepanich/Code/bdgrz/compliance-core')
OUT = Path('/tmp/compliance-control-consumers-prepared')
FOUNDATIONS = Path('/tmp/compliance-foundation-replay-prepared')
changes = {}


def original(path):
    saved = OUT / 'before' / path
    if saved.exists():
        return saved.read_text()
    text = (ROOT / path).read_text()
    prior = FOUNDATIONS / 'after' / path
    if prior.exists():
        manifest = json.loads((FOUNDATIONS / 'manifest.json').read_text())
        row = next(row for row in manifest if row['path'] == path)
        current = hashlib.sha256(text.encode()).hexdigest()
        if current == row['beforeSha256']:
            text = prior.read_text()
        elif current != row['afterSha256']:
            raise AssertionError(f'Foundation baseline drift: {path}')
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_text(text)
    return text


def edit(relative, group, action):
    path = relative if relative.startswith(('src/', 'test/')) else 'src/Compliance.Core/Features/' + relative
    before = original(path)
    after = action(before)
    assert before != after, f'No change: {path}'
    changes[path] = dict(group=group, before=before, after=after)


def replace(text, before, after, count=None):
    found = text.count(before)
    assert found and (count is None or found == count), (before, found, count)
    return text.replace(before, after)


def hydrate(text, reader, tenant, program, control):
    pattern = rf'{reader}\.HydrateAsync\(\s*new ControlDraft\(\s*{re.escape(tenant)},\s*{re.escape(control)}\),\s*ct\)'
    result, found = re.subn(pattern, f'controlSources.ReadAsync({tenant}, {program}, {control}, ct)', text)
    assert found, (reader, tenant, program, control)
    return result


def direct(text, reader, tenant, program, control, preserve_reader=True):
    text = hydrate(text, reader, tenant, program, control)
    if preserve_reader:
        text = replace(text, f'IAggregateReader {reader},', f'IAggregateReader {reader}, ControlReader controlSources,', 1)
    else:
        text = replace(text, f'IAggregateReader {reader}', 'ControlReader controlSources', 1)
    return text


for file in ['AdvisorCollaboration/AdvisorRecordVersionResolver.cs', 'AdvisorCollaboration/AdvisorSharedSourceReader.cs']:
    edit(file, 'current-reads', lambda text: direct(text, 'aggregates', 'tenantId', 'programId', 'selected.RecordId'))

edit('Commitments/CommitmentImpactService.cs', 'current-reads',
     lambda text: direct(text, 'reader', 'request.TenantId', 'request.ProgramId', 'item.ControlId', False))
edit('ControlMappings/ListCriteriaCoverageHandler.cs', 'current-reads',
     lambda text: direct(text, 'reader', 'request.TenantId', 'request.ProgramId', 'controlId'))
edit('Evaluations/RaiseEvaluationDeviationFindingHandler.cs', 'current-reads',
     lambda text: direct(text, 'reader', 'request.TenantId', 'request.ProgramId', 'request.ControlId'))
edit('Evidence/OpenEvidenceRequestHandler.cs', 'current-reads',
     lambda text: direct(text, 'reader', 'request.TenantId', 'request.ProgramId', 'controlId'))
edit('Evidence/EvidenceSupportTargetSource.cs', 'current-reads',
     lambda text: direct(text, 'reader', 'request.TenantId', 'request.ProgramId', 'request.SupportedRecordId'))
edit('Examinations/ControlTypeIBaselineSourceContributor.cs', 'historical-reads',
     lambda text: direct(text, 'reader', 'engagement.TenantId', 'engagement.ProgramId', 'item.ControlId', False)
     .replace('ControlDraft control,', 'ControlReadSnapshot control,'))
edit('Providers/ProviderChangeImpactService.cs', 'current-reads',
     lambda text: direct(text, 'reader', 'tenantId', 'programId', 'item.ControlId')
     .replace('ReferencesAffectedSystem(ControlDraft control,', 'ReferencesAffectedSystem(ControlReadSnapshot control,'))
edit('Readiness/RunReadinessAssessmentHandler.cs', 'historical-reads',
     lambda text: direct(text, 'reader', 'tenant', 'request.ProgramId', 'controlId'))
edit('Readiness/ReadinessControlSelection.cs', 'historical-reads',
     lambda text: replace(text, 'EffectiveVersionAt(ControlDraft control,', 'EffectiveVersionAt(ControlReadSnapshot control,', 1))
edit('Controls/ControlResponsibilityScopeValidator.cs', 'current-reads',
     lambda text: replace(text, 'IAggregateReader reader', 'ControlReader controlSources', 1)
     .replace('reader.HydrateAsync(new ControlDraft(tenantId, scope.RecordId), ct)',
              'controlSources.ReadAsync(tenantId, scope.RecordId, ct)'))

impact_files = ['IControlImpactContributor', 'ControlImpactRelationships', 'ApplicabilityControlImpactContributor',
                'ResponsibilityControlImpactContributor', 'MappingControlImpactContributor',
                'RiskTreatmentControlImpactContributor', 'ReadinessControlImpactContributor',
                'EvidenceControlImpactContributor', 'WorkControlImpactContributor']
for name in impact_files:
    edit('Controls/' + name + '.cs', 'impact',
         lambda text: text.replace('IImpactContributor<ControlDraft,', 'IImpactContributor<ControlReadSnapshot,')
         .replace('ControlDraft subject', 'ControlReadSnapshot subject'))
edit('Controls/ControlImpactService.cs', 'impact',
     lambda text: direct(text, 'reader', 'request.TenantId', 'request.ProgramId', 'request.ControlId', False))



# All operations/evaluation callers now consume the explicit native reader. The aggregate reader
# remains only where the same handler reads another owner or saves its own routed workflow.
def add_reader(text, name='reader'):
    declaration = 'IAggregateReader ' + name
    assert declaration in text
    used = len(re.findall(r'\b' + name + r'\b', text)) > 1
    return replace(text, declaration,
                   declaration + ', ControlReader controlSources' if used else 'ControlReader controlSources', 1)


def operating_source(text):
    text = replace(text, 'IAggregateReader reader', 'ControlReader controlSources', 2)
    text = text.replace('ValueTask<ControlDraft?>', 'ValueTask<ControlReadSnapshot?>')
    text = hydrate(text, 'reader', 'tenantId', 'programId', 'controlId')
    return replace(text, 'LoadControlAsync(reader,', 'LoadControlAsync(controlSources,', 1)


edit('Operations/ControlOperationsSource.cs', 'operations', operating_source)
edit('Operations/OperatingAuthority.cs', 'operations',
     lambda text: replace(text, 'VersionWindows(ControlDraft? control)', 'VersionWindows(ControlReadSnapshot? control)', 1))

for file, helper in [('Operations/OperatingPlanChecks.cs', 'CheckAsync'),
                     ('Operations/OccurrenceAttestation.cs', 'PrepareAsync')]:
    edit(file, 'operations', lambda text: replace(text, 'IAggregateReader reader', 'ControlReader controlSources', 1)
         .replace('ControlOperationsSource.LoadControlAsync(reader,',
                  'ControlOperationsSource.LoadControlAsync(controlSources,'))

# Direct users of the shared control source.
for file in [
    'Operations/ListControlOccurrencesHandler.cs', 'Operations/GetControlOperatingPlanHandler.cs',
    'Operations/ReviewControlOccurrenceHandler.cs', 'Operations/GetControlOccurrenceHandler.cs',
    'Operations/OpenControlOccurrenceHandler.cs', 'Operations/ApproveControlOperatingPlanHandler.cs',
    'Operations/ListControlOperatingBlockersHandler.cs',
    'Evaluations/StartControlEvaluationHandler.cs', 'Evaluations/GetControlEvaluationHandler.cs',
    'Evaluations/DefineControlEvaluationPlanHandler.cs', 'Evaluations/GetControlEvaluationPlanVersionHandler.cs',
    'Evaluations/ListControlEvaluationPlanVersionsHandler.cs', 'Evaluations/ListControlEvaluationsHandler.cs']:
    edit(file, 'operations', lambda text: add_reader(replace(text,
         'ControlOperationsSource.LoadControlAsync(reader,',
         'ControlOperationsSource.LoadControlAsync(controlSources,'))
         .replace('ControlDraft control,', 'ControlReadSnapshot control,'))

for file, helper in [
    ('Operations/ProposeControlOperatingPlanHandler.cs', 'OperatingPlanChecks.CheckAsync'),
    ('Operations/PreviewControlOperatingPlanHandler.cs', 'OperatingPlanChecks.CheckAsync'),
    ('Operations/AttestControlOccurrenceHandler.cs', 'OccurrenceAttestation.PrepareAsync'),
    ('Operations/CorrectControlAttestationHandler.cs', 'OccurrenceAttestation.PrepareAsync')]:
    edit(file, 'operations', lambda text, helper=helper: add_reader(replace(text,
         helper + '(reader,', helper + '(controlSources,', 1)))


def plan_validator(text):
    text = hydrate(text, 'reader', 'tenantId', 'programId', 'source.RecordId')
    text = replace(text, 'IAggregateReader reader, FindingReader findings, ControlOperationsReader operating,',
                   'IAggregateReader reader, ControlReader controlSources, FindingReader findings, ControlOperationsReader operating,', 1)
    text = replace(text, 'ControlPlansMatchAsync(IAggregateReader reader,',
                   'ControlPlansMatchAsync(ControlReader controlSources,', 1)
    return replace(text, 'ControlPlansMatchAsync(reader,', 'ControlPlansMatchAsync(controlSources,', 1)


edit('Operations/TypeIIPlanSourceValidator.cs', 'historical-reads', plan_validator)
for file in ['Operations/ProposeTypeIIOperatingPlanHandler.cs', 'Operations/StartTypeIIObservationPeriodHandler.cs']:
    edit(file, 'historical-reads', lambda text: add_reader(replace(text,
         'TypeIIPlanSourceValidator.ValidateAsync(reader,',
         'TypeIIPlanSourceValidator.ValidateAsync(reader, controlSources,', 1)))


def decision_work(text):
    text = replace(text, 'IAggregateReader reader', 'ControlReader controlSources', 1)
    text = hydrate(text, 'reader', 'tenantId', 'programId', 'summary.ControlId')
    return replace(text, 'ControlDraft control,', 'ControlReadSnapshot control,', 1)


edit('Work/ControlDecisionWork.cs', 'work', decision_work)
edit('Work/FitzControlDecisionWorkItemDirectory.cs', 'work',
     lambda text: replace(text, 'IAggregateReader sourceReader', 'ControlReader controlSources', 1)
     .replace('sourceReader.HydrateAsync(new ControlDraft(tenantId, controlId), ct)',
              'controlSources.ReadAsync(tenantId, controlId, ct)'))

for file in ['Work/FitzControlOperatingPlanWorkItemDirectory.cs', 'Work/FitzControlOccurrenceWorkItemDirectory.cs']:
    edit(file, 'work', lambda text: replace(text, 'IAggregateReader sourceReader', 'ControlReader controlSources', 1)
         .replace('ControlOperationsSource.LoadControlAsync(sourceReader,',
                  'ControlOperationsSource.LoadControlAsync(controlSources,'))

edit('Work/WorkSource.cs', 'work', lambda text: replace(text,
     'IAggregateReader reader, FindingReader? findings,',
     'IAggregateReader reader, ControlReader controlSources, FindingReader? findings,', 1)
     .replace('.ReadPlannedAsync(reader,', '.ReadPlannedAsync(controlSources,')
     .replace('ControlOperationsSource.LoadControlAsync(reader,', 'ControlOperationsSource.LoadControlAsync(controlSources,'))
edit('Work/WorkQueueReader.cs', 'work', lambda text: replace(text,
     'WorkQueueReader(IAggregateReader reader, OperatingAuthority authority,',
     'WorkQueueReader(IAggregateReader reader, ControlReader controlSources, OperatingAuthority authority,', 1)
     .replace('WorkSource.LoadAsync(reader,', 'WorkSource.LoadAsync(reader, controlSources,')
     .replace('ControlDecisionWork.LoadAsync(reader,', 'ControlDecisionWork.LoadAsync(controlSources,'))



# Projection indexes remain non-authoritative: read canonical frozen content for each committed
# native root, and ignore roots whose accepted decision has no view/reference change.
def draft_projector(text):
    text = replace(text, 'IProjectorHandler<ControlDraftDiscarded>',
                   'IProjectorHandler<ControlDraftDiscarded>, IProjectorHandler<ControlSuccessorProposed>,\n      IProjectorHandler<ControlProposalWithdrawn>', 1)
    return text.replace('\n}', '\n    public ValueTask HandleAsync(ControlSuccessorProposed ev, IProjectorContext context,\n'
                        '        CancellationToken ct) => projection.ApplyAsync(ev, ct);\n\n'
                        '    public ValueTask HandleAsync(ControlProposalWithdrawn ev, IProjectorContext context,\n'
                        '        CancellationToken ct) => projection.ApplyAsync(ev, ct);\n}\n', 1)


edit('Applications/ApplicationControlDraftReferenceProjector.cs', 'projections', draft_projector)


def draft_directory(text):
    text = 'using Bdgrz.Compliance.Features.Content;\n' + text
    text = replace(text, 'FitzApplicationControlDraftReferenceDirectory(IKvClient client)',
                   'FitzApplicationControlDraftReferenceDirectory(IKvClient client, IImmutableContentStore content)', 1)
    text = replace(text, '        switch (domainEvent)',
                   '        if (domainEvent is IControlFact { ChangeCount: 0 })\n            return;\n        switch (domainEvent)', 1)
    text = replace(text, '            case ControlDraftCreated created:\n',
                   '            case ControlDraftCreated created:\n'
                   '                var initialContent = await ControlFactContent.ReadDraftAsync(content, created, ct)\n'
                   '                    .ConfigureAwait(false);\n', 1)
    text = text.replace('ReferenceIds(created.Content)', 'ReferenceIds(initialContent)')
    text = text.replace('initial, created.Content, ct)', 'initial, initialContent, ct)')
    start = text.index('            case ControlDraftRevised revised:')
    end = text.index('            case ControlDraftDiscarded discarded:', start)
    text = text[:start] + """            case ControlDraftRevised revised:
                await ReviseAsync(revised.TenantId, revised.ProgramId, revised.ControlId,
                    revised.Header.Revision, revised, ct).ConfigureAwait(false);
                break;
            case ControlSuccessorProposed proposed:
                await ReviseAsync(proposed.TenantId, proposed.ProgramId, proposed.ControlId,
                    proposed.Header.Revision, proposed, ct).ConfigureAwait(false);
                break;
            case ControlProposalWithdrawn withdrawn:
                await ReviseAsync(withdrawn.TenantId, withdrawn.ProgramId, withdrawn.ControlId,
                    withdrawn.Header.Revision, withdrawn, ct).ConfigureAwait(false);
                break;
""" + text[end:]
    marker = '    static Uuid[] ReferenceIds(ControlDraftContent content) =>'
    helper = """    async ValueTask ReviseAsync(Uuid tenantId, Uuid programId, Uuid controlId,
        long revision, IControlFact fact, CancellationToken ct)
    {
        var revising = await RequireStateAsync(controlId, ct).ConfigureAwait(false);
        if (revising.TenantId != tenantId || revising.ProgramId != programId ||
            revising.Revision + 1 != revision)
            throw new InvalidOperationException("A control draft reference revision is out of order.");
        var revisedContent = await ControlFactContent.ReadDraftAsync(content, fact, ct).ConfigureAwait(false);
        await DeleteReferencesAsync(controlId, revising.EntryIds, ct).ConfigureAwait(false);
        var next = revising with { Revision = revision, EntryIds = ReferenceIds(revisedContent) };
        await ApplicationControlDraftReferenceSchema.States.ReplaceAsync(Transaction,
            revising, next, ct).ConfigureAwait(false);
        await InsertAsync(tenantId, next, revisedContent, ct).ConfigureAwait(false);
    }

"""
    return replace(text, marker, helper + marker, 1)


edit('Applications/FitzApplicationControlDraftReferenceDirectory.cs', 'projections', draft_directory)


def version_directory(text):
    text = 'using Bdgrz.Compliance.Features.Content;\n' + text
    text = replace(text, 'FitzApplicationControlVersionReferenceDirectory(IKvClient client)',
                   'FitzApplicationControlVersionReferenceDirectory(IKvClient client, IImmutableContentStore content)', 1)
    text = replace(text, '        switch (domainEvent)',
                   '        if (domainEvent is IControlFact { ChangeCount: 0 })\n            return;\n        switch (domainEvent)', 1)
    return replace(text, '        var references = (approved.Content.Applicability ?? []).Where(IsIndexed).ToArray();',
                   '        var approvedContent = await ControlFactContent.ReadDraftAsync(content, approved, ct)\n'
                   '            .ConfigureAwait(false);\n'
                   '        var references = (approvedContent.Applicability ?? []).Where(IsIndexed).ToArray();', 1)


edit('Applications/FitzApplicationControlVersionReferenceDirectory.cs', 'projections', version_directory)
# Work views are reconstructed from the exact native stream; an acceptance-only root cannot
# replace the previously projected decision round or manufacture a new work revision.
path='src/Compliance.Core/Features/Work/FitzControlDecisionWorkItemDirectory.cs'
row=changes[path]
row['after']=replace(row['after'], '        var (tenantId, controlId) = ScopeFor(domainEvent);',
                     '        if (domainEvent is IControlFact { ChangeCount: 0 })\n            return;\n'
                     '        var (tenantId, controlId) = ScopeFor(domainEvent);', 1)



# Test preparation reuses a transient rule fold and commits actual native facts through ControlSeeds.
# No production aggregate compatibility overload is introduced.
def test_import(text, namespace):
    using = 'using ' + namespace + ';\n'
    return text if using in text else using + text


def test_rules(text):
    text = re.sub(r'\bnew ControlDraft\(', 'new ControlRules(', text)
    text = text.replace('Func<ControlDraft,', 'Func<ControlRules,')
    text = text.replace('Task<ControlDraft>', 'Task<ControlRules>')
    text = text.replace('ControlDraft control,', 'ControlRules control,')
    text = text.replace('ControlDraft control)', 'ControlRules control)')
    text = text.replace('ControlDraft ApprovedControl', 'ControlRules ApprovedControl')
    text = text.replace('IEnumerable<ControlDraft>', 'IEnumerable<ControlRules>')
    text = text.replace('params ControlDraft[] controls', 'params ControlRules[] controls')
    return test_import(text, 'Bdgrz.Compliance.Tests.Testing')


# Freeze all existing non-owner test baselines before mechanical migrations, including staged
# foundation constructor changes. Remaining raw aggregate writes are audited below and migrated
# explicitly before any group is marked integration-ready.
for file in sorted((ROOT / 'test/Compliance.Tests').rglob('*.cs')):
    if '/Features/Controls/' in str(file):
        continue
    relative = str(file.relative_to(ROOT))
    baseline = original(relative) if re.search(r'\bControlDraft\b', file.read_text()) else None
    if baseline and re.search(r'new ControlDraft\(|Func<ControlDraft,|Task<ControlDraft>|ControlDraft control', baseline):
        edit(relative, 'consumer-tests', test_rules)


def shared_test_services(text):
    text = test_import(text, 'Bdgrz.Compliance.Features.Content')
    text = test_import(text, 'Bdgrz.Compliance.Features.Controls')
    marker='        services?.Invoke(collection);'
    text=replace(text, marker, '        collection.AddScoped<ControlReader>();\n' + marker, 1)
    marker='    public static ClaimsPrincipal Actor(Uuid userId) =>'
    overloads="""    public static async Task SeedAsync(IServiceProvider provider, ControlRules selected,
        Func<ControlRules, Result> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var rules = await services.GetRequiredService<ControlReader>()
            .RulesAsync(selected.TenantId, selected.Id, CancellationToken.None);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await ControlSeeds.AppendAsync(reader, services.GetRequiredService<IAggregateWriter>(),
            services.GetRequiredService<IImmutableContentStore>(), rules, CancellationToken.None);
    }

    public static async Task SeedAsync<TOut>(IServiceProvider provider, ControlRules selected,
        Func<ControlRules, Result<TOut>> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var rules = await services.GetRequiredService<ControlReader>()
            .RulesAsync(selected.TenantId, selected.Id, CancellationToken.None);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await ControlSeeds.AppendAsync(reader, services.GetRequiredService<IAggregateWriter>(),
            services.GetRequiredService<IImmutableContentStore>(), rules, CancellationToken.None);
    }

    public static async Task<ControlRules> HydrateAsync(IServiceProvider provider, ControlRules selected)
    {
        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<ControlReader>()
            .RulesAsync(selected.TenantId, selected.Id, CancellationToken.None);
    }

"""
    return replace(text, marker, overloads + marker, 1)


edit('test/Compliance.Tests/Testing/ProgramManagementServices.cs', 'shared-test-fixtures', shared_test_services)



def amend(relative, action, group='consumer-tests'):
    path=relative if relative.startswith(('src/','test/')) else 'test/Compliance.Tests/' + relative
    if path not in changes:
        changes[path]=dict(group=group,before=original(path),after=original(path))
    before=changes[path]['after'];after=action(before)
    assert before!=after, ('No amendment',path)
    changes[path]['after']=after


def evidence_fixture(text):
    text=test_import(text,'Bdgrz.Compliance.Features.Content')
    text=test_import(text,'Cntryl.Fitz.Testing')
    text=replace(text,'        public IDomainEventReader Events { get; }',
                 '        public IDomainEventReader Events { get; }\n'
                 '        public IImmutableContentStore Content { get; } = new FitzKvImmutableContentStore(new InMemoryKvClient());\n'
                 '        public ControlReader Controls => new(Reader, Events, Content);',1)
    text=text.replace('fixture.Reader.HydrateAsync(new ControlRules(fixture.TenantId, controlId))',
                      'fixture.Controls.RulesAsync(fixture.TenantId, fixture.ProgramId, controlId)')
    text=text.replace('await fixture.Writer.SaveAsync(control, fixture.Context(request));',
                      'await ControlSeeds.AppendAsync(fixture.Reader, fixture.Writer, fixture.Content, control, CancellationToken.None);')
    text=text.replace('await Writer.SaveAsync(control, new RequestDispatchContext(RequestActor.System));',
                      'await ControlSeeds.WriteAsync(Writer, Content, control, CancellationToken.None);')
    return text.replace('new EvidenceSupportTargetSource(Reader,', 'new EvidenceSupportTargetSource(Reader, Controls,')


amend('Features/Evidence/LinkEvidenceSupportHandlerTests.cs',evidence_fixture)


def advisor_fixture(text):
    text=replace(text,'        public ReadinessReader Readiness { get; }',
                 '        public ReadinessReader Readiness { get; }\n'
                 '        public IImmutableContentStore Content => _scope.ServiceProvider.GetRequiredService<IImmutableContentStore>();\n'
                 '        public ControlReader Controls => new(Reader, Events, Content);',1)
    text=text.replace('new AdvisorSharedSourceReader(fixture.Reader, fixture.Resolver(),',
                      'new AdvisorSharedSourceReader(fixture.Reader, fixture.Controls, fixture.Resolver(),')
    text=text.replace('null) => new(Reader, Metadata,', 'null) => new(Reader, Controls, Metadata,')
    text=text.replace('new EvidenceSupportTargetSource(Reader,', 'new EvidenceSupportTargetSource(Reader, Controls,')
    return text.replace('await Writer.SaveAsync(control, SystemDispatch);',
                        'await ControlSeeds.AppendAsync(Reader, Writer, Content, control, CancellationToken.None);')


amend('Features/AdvisorCollaboration/AdvisorRecordVersionResolverTests.cs',advisor_fixture)
amend('Features/Readiness/ReadinessAssessmentHandlerTests.cs',lambda text: text.replace(
    'GetRequiredService<IAggregateReader>()\n            .HydrateAsync(new ControlRules(fixture.TenantId, fixture.ControlId), CancellationToken.None)',
    'GetRequiredService<ControlReader>()\n            .ReadAsync(fixture.TenantId, fixture.ProgramId, fixture.ControlId, CancellationToken.None)'))

for file in ['Features/Operations/ProposeTypeIIOperatingPlanHandlerTests.cs',
             'Features/Operations/StartTypeIIObservationPeriodHandlerTests.cs']:
    amend(file,lambda text: text.replace('await Writer.SaveAsync(control, new RequestDispatchContext(RequestActor.System));',
          'await ControlSeeds.WriteAsync(Writer, '+
          ('scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()' if 'public FindingReader Findings' in text else 'Host.Content')+
          ', control, CancellationToken.None);'))
amend('Features/Operations/ProposeTypeIIOperatingPlanHandlerTests.cs',lambda text: text.replace(
    'new ProposeTypeIIOperatingPlanHandler(Executor, Reader, Findings,',
    'new ProposeTypeIIOperatingPlanHandler(Executor, Reader, new ControlReader(Reader, events, scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()), Findings,'))
amend('Testing/TypeIIRangeHost.cs',lambda text: test_import(text,'Bdgrz.Compliance.Features.Controls').replace(
    'Services.GetRequiredService<NativeOperationExecutor>(), Reader,',
    'Services.GetRequiredService<NativeOperationExecutor>(), Reader, new ControlReader(Reader, Events, Content),',1))
amend('E2E/ControlOperationE2ETests.cs',lambda text: replace(text,
    '    internal static async Task SeedAsync<TAggregate>',
    '    internal static Task SeedAsync(WebApplicationFactory<Program> factory, ControlRules rules,\n'
    '        Func<ControlRules, Result> operation) => ProgramManagementServices.SeedAsync(factory.Services, rules, operation);\n\n'
    '    internal static async Task SeedAsync<TAggregate>',1))



# Mechanical direct-constructor migrations use the very same scoped native reader/content store
# as the native seed facts; no empty reader replaces a source of authority.
def argument_end(text, start):
    depth=0;quoted=False;escape=False
    for i in range(start,len(text)):
        c=text[i]
        if quoted:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c=='"':quoted=False
            continue
        if c=='"':quoted=True
        elif c in '([{':depth+=1
        elif c in ')]}':
            if depth==0:return i
            depth-=1
        elif c==',' and depth==0:return i
    raise AssertionError('Unterminated constructor argument')


def rewrite_call_argument(text, name, position, replacement, insert=False):
    starts=[m.end() for m in re.finditer(re.escape(name)+r'\s*\(',text)]
    for start in reversed(starts):
        for _ in range(position):start=argument_end(text,start)+1
        end=argument_end(text,start)
        old=text[start:end];new=replacement(old.strip(),text[:start])
        text=text[:start]+(old+', '+new if insert else re.match(r'\s*',old).group()+new)+text[end:]
    return text


def service_reader(old,prefix):
    if '.GetRequiredService<IAggregateReader>()' in old:
        return old.replace('GetRequiredService<IAggregateReader>()','GetRequiredService<ControlReader>()')
    if old=='sourceReader':
        provider='sourceScope.ServiceProvider' if 'var sourceScope =' in prefix else 'scope.ServiceProvider'
    elif old=='reader':
        provider='services' if 'var services = scope.ServiceProvider' in prefix else 'scope.ServiceProvider'
    else:raise AssertionError(('Unknown scoped reader',old))
    return provider+'.GetRequiredService<ControlReader>()'


for file in sorted((ROOT/'test/Compliance.Tests').rglob('*.cs')):
    if '/Features/Controls/' in str(file):continue
    relative=str(file.relative_to(ROOT));text=changes.get(relative,{}).get('after') or file.read_text()
    if 'new WorkQueueReader(' in text:
        amend(relative,lambda text: test_import(rewrite_call_argument(text,'new WorkQueueReader',0,service_reader,True),
              'Bdgrz.Compliance.Features.Controls'))
    for name in ['FitzControlDecisionWorkItemDirectory','FitzControlOperatingPlanWorkItemDirectory',
                 'FitzControlOccurrenceWorkItemDirectory']:
        if 'new '+name+'(' in text:
            amend(relative,lambda text,name=name: test_import(rewrite_call_argument(text,'new '+name,1,service_reader),
                  'Bdgrz.Compliance.Features.Controls'))
    if 'WorkSource.LoadAsync(' in text:
        amend(relative,lambda text: test_import(rewrite_call_argument(text,'WorkSource.LoadAsync',0,service_reader,True),
              'Bdgrz.Compliance.Features.Controls'))

# Required authored identities are constructor data for all existing selected mutation DTOs.
identified=['ReviseControlDraft','ProposeControlSuccessor','ProposeControlRetirement','DiscardControlDraft',
            'DesignateControlOwnerPerson','WithdrawControlProposal','RetireControl','AssignResponsibility',
            'RevokeResponsibility']
for file in sorted((ROOT/'test/Compliance.Tests').rglob('*.cs')):
    if '/Features/Controls/' in str(file):continue
    relative=str(file.relative_to(ROOT));text=changes.get(relative,{}).get('after') or file.read_text()
    selected=[name for name in identified if 'new '+name+'(' in text]
    if selected:
        def ids(text):
            for name in selected:text=text.replace('new '+name+'(', 'new '+name+'(Uuid.CreateVersion4(), ')
            return text
        amend(relative,ids)


def examination_fixture(text):
    for namespace in ['Bdgrz.Compliance.Features.Content','Cntryl.Fitz.Testing','Microsoft.Extensions.DependencyInjection']:
        text=test_import(text,namespace)
    text=replace(text,'        var predecessor = Assert.IsType<ControlVersionView>(control.ApprovedVersion);',
                 '        await using var source = await NativeSource.CreateAsync(control);\n'
                 '        var predecessor = Assert.IsType<ControlVersionView>(control.ApprovedVersion);',1)
    text=replace(text,'var contributor = Contributor(directory, new ControlReader(control),\n            new InMemoryEventStore());',
                 'var contributor = Contributor(directory, source);',2)
    text=replace(text,'        ApproveSuccessor(control, new DateOnly(2026, 10, 15));',
                 '        ApproveSuccessor(control, new DateOnly(2026, 10, 15));\n'
                 '        await source.AppendAsync(control);',1)
    text=replace(text,'        var contributor = Contributor(new Directory([future]), new ControlReader(future),\n            new InMemoryEventStore());',
                 '        await using var source = await NativeSource.CreateAsync(future);\n'
                 '        var contributor = Contributor(new Directory([future]), source);',1)
    text=replace(text,'        var directory = new AdvancingDirectory(View(control));',
                 '        await using var source = await NativeSource.CreateAsync(control);\n'
                 '        var directory = new AdvancingDirectory(View(control));',1)
    text=replace(text,'        var wrongProgramView = View(control) with { ProgramId = Uuid.CreateVersion4() };',
                 '        await using var source = await NativeSource.CreateAsync(control);\n'
                 '        var wrongProgramView = View(control) with { ProgramId = Uuid.CreateVersion4() };',1)
    text=replace(text,'var contributor = Contributor(new Directory([wrongProgramView]), new ControlReader(control),\n            new InMemoryEventStore());',
                 'var contributor = Contributor(new Directory([wrongProgramView]), source);',1)
    text=replace(text,'        IControlDraftDirectoryReader directory, IAggregateReader reader, IDomainEventReader events) =>\n        new(directory, reader, new ControlDraftListReadConsistency(directory, events));',
                 '        IControlDraftDirectoryReader directory, NativeSource source)\n'
                 '    {\n'
                 '        if (directory is Directory stable) stable.CurrentCheckpoint = () => source.Checkpoint;\n'
                 '        if (directory is AdvancingDirectory advancing) advancing.InitialCheckpoint = source.Checkpoint;\n'
                 '        return new(directory, source.Controls, new ControlDraftListReadConsistency(directory, source.Events));\n'
                 '    }',1)
    text=replace(text,'        ControlDraftView[] _views;',
                 '        ControlDraftView[] _views;\n'
                 '        public Func<ProjectionCheckpoint> CurrentCheckpoint { get; set; } = () => ProjectionCheckpoint.Start;',1)
    text=replace(text,'CancellationToken ct = default) => ValueTask.FromResult(ProjectionCheckpoint.Start);',
                 'CancellationToken ct = default) => ValueTask.FromResult(CurrentCheckpoint());',1)
    text=replace(text,'        int _loads;',
                 '        int _loads;\n'
                 '        public ProjectionCheckpoint InitialCheckpoint { get; set; } = ProjectionCheckpoint.Start;',1)
    text=replace(text,'            ? ProjectionCheckpoint.Start\n            : new ProjectionCheckpoint(new EventCursor("advanced")));',
                 '            ? InitialCheckpoint\n            : new ProjectionCheckpoint(new EventCursor("advanced")));',1)
    start=text.index('    sealed class ControlReader(')
    text=text[:start]+'''    sealed class NativeSource : IAsyncDisposable
    {
        readonly ServiceProvider _provider;
        readonly AsyncServiceScope _scope;
        readonly IAggregateReader _reader;
        readonly IAggregateWriter _writer;
        readonly IImmutableContentStore _content;
        public IDomainEventReader Events { get; }
        public ControlReader Controls { get; }
        public ProjectionCheckpoint Checkpoint { get; private set; } = ProjectionCheckpoint.Start;

        NativeSource()
        {
            var services = new ServiceCollection();
            var events = new InMemoryEventStore();
            services.AddSingleton<IEventStore>(events);
            services.AddSingleton<IDomainEventReader>(events);
            services.AddSingleton<IImmutableContentStore>(new FitzKvImmutableContentStore(new InMemoryKvClient()));
            services.AddPortia();
            _provider = services.BuildServiceProvider();
            _scope = _provider.CreateAsyncScope();
            _reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();
            _writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
            _content = _scope.ServiceProvider.GetRequiredService<IImmutableContentStore>();
            Events = events;
            Controls = new(_reader, events, _content);
        }

        public static async Task<NativeSource> CreateAsync(ControlRules control)
        {
            var source = new NativeSource();
            await source.AppendAsync(control);
            return source;
        }

        public async Task AppendAsync(ControlRules control)
        {
            await ControlSeeds.AppendAsync(_reader, _writer, _content, control, CancellationToken.None);
            var cursor = EventCursor.Start;
            await foreach (var record in Events.ReadAsync(EventStreamPattern.ForPattern(
                               TenantId.ToString(), "controls"), cursor, CancellationToken.None))
                cursor = record.NextCursor;
            Checkpoint = new(cursor);
        }

        public async ValueTask DisposeAsync()
        {
            await _scope.DisposeAsync();
            await _provider.DisposeAsync();
        }
    }
}
'''
    return text


amend('Features/Examinations/ControlTypeIBaselineSourceContributorTests.cs',examination_fixture)


# Valid native creation fixtures preserve the documented normalized-identifier uniqueness boundary.
for file,old,new in [
 ('Features/AdvisorCollaboration/AdvisorRecordVersionResolverTests.cs',
  'var controlId = Uuid.CreateVersion4();', 'var controlId = ControlDraft.IdFor(TenantId, ProgramId, "AC-01");'),
 ('Features/AdvisorCollaboration/AdvisorRecordVersionResolverTests.cs',
  'new ControlRules(TenantId, Uuid.CreateVersion4())', 'new ControlRules(TenantId, ControlDraft.IdFor(TenantId, ProgramId, "AC-02"))'),
 ('Features/AccessControl/AttestManagementWriteWallTests.cs',
  'var controlId = Uuid.CreateVersion4();', 'var controlId = ControlDraft.IdFor(Tenant, Program, "AC-1");'),
 ('Features/Operations/ProposeTypeIIOperatingPlanHandlerTests.cs',
  'public Uuid ControlId { get; } = Uuid.CreateVersion4();', 'public Uuid ControlId => ControlDraft.IdFor(TenantId, ProgramId, "AC-T1-01");'),
 ('Features/Operations/StartTypeIIObservationPeriodHandlerTests.cs',
  'public Uuid ControlId { get; } = Uuid.CreateVersion4();', 'public Uuid ControlId => ControlDraft.IdFor(TenantId, ProgramId, "AC-T2-01");'),
 ('Features/Work/ControlDecisionWorkTests.cs',
  'var controlId = Uuid.CreateVersion4();', 'var controlId = ControlDraft.IdFor(fixture.TenantId, fixture.ProgramId, "AC-WORK");'),
 ('Features/Work/ReviewerWorkAuthorityTests.cs',
  'var controlId = Uuid.CreateVersion4();', 'var controlId = ControlDraft.IdFor(Operations.TenantId, Operations.ProgramId, "AC-GUEST");')]:
    amend(file,lambda text,old=old,new=new:replace(text,old,new,1))
amend('Features/Work/FitzControlDecisionWorkItemDirectoryTests.cs',lambda text:
     text.replace('var controlId = Uuid.CreateVersion4();',
                  'var controlId = ControlDraft.IdFor(fixture.TenantId, fixture.ProgramId, "AC-PROJ");',1)
     .replace('var controlId = Uuid.CreateVersion4();',
                  'var controlId = ControlDraft.IdFor(fixture.TenantId, fixture.ProgramId, "AC-FALLBACK");',1))

# Existing personal HTTP acceptance tests now author the required command identity explicitly.
amend('E2E/TenantInvitationE2ETests.cs',lambda text: test_import(text,'Bdgrz.Compliance.Features.Content')
     .replace('new { expected_revision = 1, content = JourneyContentRequest(changedContent) }',
              'new { command_id = Uuid.CreateVersion4(), expected_revision = 1, content = JourneyContentRequest(changedContent) }')
     .replace('Assert.Equivalent(changedContent, revision.Content, strict: true);',
              'await using var contentScope = factory.Services.CreateAsyncScope();\n'
              '            var frozenContent = await ControlFactContent.ReadDraftAsync(\n'
              '                contentScope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), revision, CancellationToken.None);\n'
              '            Assert.Equivalent(changedContent, frozenContent, strict: true);'))
amend('E2E/DraftActorSnapshotE2ETests.cs',lambda text:replace(text,
     '                    content = ControlContent("Monthly access review"),',
     '                    command_id = Uuid.CreateVersion4(),\n'
     '                    content = ControlContent("Monthly access review"),',1))


# Explicit malformed-fact fixtures keep their supplied metadata and content while receiving the
# required native immutable envelope. These facts are never saved through a production owner.
projection_helper='''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Controls;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

sealed class ControlProjectionFacts
{
    readonly Dictionary<(Uuid Tenant, Uuid Control), ControlRules> _rules = [];
    readonly Dictionary<(Uuid Tenant, Uuid Control), long> _sequences = [];
    public IImmutableContentStore Content { get; } = new FitzKvImmutableContentStore(new InMemoryKvClient());
'''
metadata={
 'ControlDraftCreated':('CreateRequestId','ChangedAt','CreateControlDraft'),
 'ControlDraftRevised':('Uuid.CreateVersion4()','ChangedAt','ReviseControlDraft'),
 'ControlDraftDiscarded':('Uuid.CreateVersion4()','DiscardedAt','DiscardControlDraft'),
 'ControlReviewed':('DecisionId','DecidedAt','ReviewControl'),
 'ControlApproved':('ApprovalDecisionId','DecidedAt','ApproveControl'),
 'ControlSuccessorProposed':('VersionId','ChangedAt','ProposeControlSuccessor'),
 'ControlRetirementProposed':('RetirementId','ChangedAt','ProposeControlRetirement'),
 'ControlRetired':('DecisionId','DecidedAt','RetireControl'),
 'ControlProposalWithdrawn':('DecisionId','WithdrawnAt','WithdrawControlProposal'),
}
for name,(identity,time,command) in metadata.items():
    identity=identity if identity.startswith('Uuid.') else 'change.'+identity
    display='change.Actor.Display' if name=='ControlProposalWithdrawn' else 'change.ActorDisplay'
    projection_helper+=f'''    public Task<{name}> FreezeAsync({name}Content change) =>
        FreezeAsync<{name}>(change, change.TenantId, change.ProgramId, change.ControlId,
            {identity}, change.ActorMemberId, {display}, change.{time}, "{command}");

'''
projection_helper+='''    async Task<TFact> FreezeAsync<TFact>(IControlMutationContent change, Uuid tenantId, Uuid programId,
        Uuid controlId, Uuid identity, Uuid actorId, string display, DateTimeOffset at, string commandKind)
        where TFact : DomainEvent
    {
        var key = (tenantId, controlId);
        if (!_rules.TryGetValue(key, out var rules))
        {
            rules = new(tenantId, controlId);
            _rules.Add(key, rules);
            if (change is not ControlDraftCreatedContent)
            {
                // Isolated forged approval/revision fixtures need a complete immutable envelope,
                // without changing the supplied event fields whose rejection the projection tests.
                var content = change switch
                {
                    ControlDraftRevisedContent revised => revised.Content,
                    ControlApprovedContent approved => approved.Content,
                    _ => new ControlDraftContent("Control", "Objective", "Description", "Narrative", ["Record"]),
                };
                rules.Apply(new ControlDraftCreatedContent(tenantId, programId, controlId,
                    Uuid.CreateVersion4(), "AC-01", content, actorId, display, at));
            }
        }
        var changes = new List<IControlMutationContent>();
        if (change is ControlApprovedContent approval)
        {
            // The isolated version-index fixture supplies the approved body directly.
            // Freeze that exact body; do not replace it with the fixture's earlier draft.
            var approvedDraft = new ControlDraftRevisedContent(tenantId, programId, controlId,
                approval.Revision, approval.Content, actorId, display, at);
            rules.Apply(approvedDraft);
            changes.Add(approvedDraft);
        }
        rules.Apply(change);
        changes.Add(change);
        if (change is ControlSuccessorProposedContent successor)
        {
            var revised = new ControlDraftRevisedContent(tenantId, programId, controlId, successor.Revision,
                rules.CurrentContent!, actorId, display, at);
            rules.Apply(revised);
            changes.Add(revised);
        }
        else if (change is ControlProposalWithdrawnContent withdrawn)
        {
            var revised = new ControlDraftRevisedContent(tenantId, programId, controlId, withdrawn.Revision + 1,
                rules.ApprovedVersion!.Content, actorId, display, at);
            rules.Apply(revised);
            changes.Add(revised);
        }
        var owner = new ControlDraft(tenantId, controlId);
        var operation = OwnerProvenance.For(owner, identity, commandKind,
            ActorReference.ForMember(actorId, display), "projection-fixture", null,
            AuthoredIntentDigest.Compute(change), at);
        var sequence = _sequences.GetValueOrDefault(key) + 1;
        _sequences[key] = sequence;
        return (TFact)await ControlSeeds.FreezeAsync(Content, rules, changes, operation, sequence,
            CancellationToken.None);
    }
}
'''
helper_path='test/Compliance.Tests/Testing/ControlProjectionFacts.cs'
changes[helper_path]=dict(group='projection-tests',before='',after=projection_helper,isNew=True)


def matching_end(text,start,opening='(',closing=')'):
    depth=0;quoted=False;escape=False
    for i in range(start,len(text)):
        c=text[i]
        if quoted:
            if escape:escape=False
            elif c=='\\':escape=True
            elif c=='"':quoted=False
            continue
        if c=='"':quoted=True
        elif c==opening:depth+=1
        elif c==closing:
            depth-=1
            if depth==0:return i+1
    raise AssertionError('Unbalanced fixture construction')


def native_fact_constructors(text):
    for name in metadata:
        matches=list(re.finditer(r'new '+name+r'\s*\(',text))
        for match in reversed(matches):
            end=matching_end(text,text.index('(',match.start()))
            suffix=end
            while suffix<len(text) and text[suffix].isspace():suffix+=1
            if suffix<len(text) and text[suffix]=='{':end=matching_end(text,suffix,'{','}')
            expression=text[match.start():end].replace('new '+name+'(', 'new '+name+'Content(',1)
            text=text[:match.start()]+'await _controlFacts.FreezeAsync('+expression+')'+text[end:]
    return text


fact_files=['Features/Applications/ApplicationControlDraftReferenceDirectoryTests.cs',
            'Features/Applications/ApplicationControlVersionReferenceDirectoryTests.cs',
            'Features/Applications/ApplicationChangePreviewTests.cs',
            'Features/Boundaries/ControlBoundaryImpactContributorTests.cs']
for file in fact_files:
    def transform(text):
        text=test_import(text,'Bdgrz.Compliance.Tests.Testing')
        text=re.sub(r'(public sealed class \w+\s*\n\{)',r'\1\n    readonly ControlProjectionFacts _controlFacts = new();',text,count=1)
        return native_fact_constructors(text)
    amend(file,transform,'projection-tests')

# All directory instances which can consume frozen facts share that fixture's content store.
for file in sorted((ROOT/'test/Compliance.Tests').rglob('*.cs')):
    if '/Features/Controls/' in str(file):continue
    relative=str(file.relative_to(ROOT));text=changes.get(relative,{}).get('after') or file.read_text()
    if 'new FitzApplicationControlDraftReferenceDirectory(' not in text and 'new FitzApplicationControlVersionReferenceDirectory(' not in text:
        continue
    use_field=relative.removeprefix('test/Compliance.Tests/') in fact_files
    def stores(text):
        text=test_import(text,'Bdgrz.Compliance.Tests.Testing')
        for name in ['FitzApplicationControlDraftReferenceDirectory','FitzApplicationControlVersionReferenceDirectory']:
            def content(old,prefix):
                if use_field and not('CreateSystemInstanceBoundaryScenarioAsync(' in prefix and
                    prefix.rfind('CreateSystemInstanceBoundaryScenarioAsync(')>prefix.rfind('[Fact]')):
                    return '_controlFacts.Content'
                return 'new ControlProjectionFacts().Content'
            text=rewrite_call_argument(text,'new '+name,0,content,True)
        return text
    amend(relative,stores,'projection-tests')

# Existing compact helper methods become asynchronous native fact factories.
def version_test_fact_helpers(text):
    text=replace(text,'    static ControlDraftCreated Created(', '    Task<ControlDraftCreated> Created(',1)
    text=replace(text,'ControlDraftContent content) => new(tenantId, programId, controlId,',
                 'ControlDraftContent content) => _controlFacts.FreezeAsync(new ControlDraftCreatedContent(tenantId, programId, controlId,',1)
    text=replace(text,'        DateTimeOffset.UtcNow);\n\n    static ControlApproved Approved(',
                 '        DateTimeOffset.UtcNow));\n\n    Task<ControlApproved> Approved(',1)
    text=replace(text,'Uuid? predecessorVersionId = null) => new(tenantId, programId, controlId, versionId,',
                 'Uuid? predecessorVersionId = null) => _controlFacts.FreezeAsync(new ControlApprovedContent(tenantId, programId, controlId, versionId,',1)
    text=replace(text,'        predecessorVersionId);', '        predecessorVersionId));',1)
    for name in ['Created','Approved']:
        # The declaration line is the sole occurrence preceded by Task<T>.
        text=re.sub(r'(?<!> )\b'+name+r'\(', 'await '+name+'(',text)
    return text


amend('Features/Applications/ApplicationControlVersionReferenceDirectoryTests.cs',version_test_fact_helpers)

def management_control_projection(text):
    start=text.index('        await using (var batch = await projection.BeginAsync(new ProjectionBatchContext(')
    end=text.index('        await AttestAssignmentHistoryFixture.SeedAsync',start)
    text=text[:start]+'''        var events = scope.ServiceProvider.GetRequiredService<IDomainEventReader>();
        var cursor = EventCursor.Start;
        await using (var batch = await projection.BeginAsync(new ProjectionBatchContext(
                         new CheckpointIdentity("ControlDraftDirectoryV2", EventStreamPattern.ForPattern(
                             Tenant.ToString(), "controls")), ProjectionCheckpoint.Start)))
        {
            await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(
                               Tenant.ToString(), "controls", controlId.ToString()), cursor, CancellationToken.None))
            {
                await projection.ApplyAsync(record.Event);
                cursor = record.NextCursor;
            }
            await batch.CommitAsync(new ProjectionCheckpoint(cursor));
        }
''' + text[end:]
    return text


amend('Features/AccessControl/AttestManagementWriteWallTests.cs',management_control_projection)

def responsibility_lag_fixture(text):
    for namespace in ['Bdgrz.Compliance.Features.Content','Bdgrz.Compliance.Features.Controls',
                      'Bdgrz.Compliance.Features.NativeOperations','Cntryl.Fitz.Testing']:
        text=test_import(text,namespace)
    registration='''        services.AddSingleton<IEventStore>(new InMemoryEventStore());
        services.AddSingleton<IDomainEventReader>(provider =>
            (IDomainEventReader)provider.GetRequiredService<IEventStore>());
        services.AddSingleton<IImmutableContentStore>(new FitzKvImmutableContentStore(new InMemoryKvClient()));
        services.AddSingleton(TimeProvider.System);
        services.AddScoped<NativeOperationExecutor>();
        services.AddScoped<ControlReader>();
        services.AddScoped<ControlOperations>();'''
    text=replace(text,'        services.AddSingleton<IEventStore>(new InMemoryEventStore());',registration,2)
    text,count=re.subn(r'new AllowScope\(\),\s*TimeProvider.System\);',
        'new AllowScope(), scopeServices.ServiceProvider.GetRequiredService<ControlOperations>(), TimeProvider.System);',text)
    assert count==2,count
    return text


amend('Features/Responsibilities/MemberAssignmentLagTests.cs',responsibility_lag_fixture)
amend('Testing/ProgramManagementServices.cs',lambda text:replace(text,
     '        collection.AddScoped<ControlReader>();',
     '        collection.AddScoped<ControlReader>();\n        collection.AddScoped<ControlOperations>();',1))

def emit():
    manifest = []
    for path, row in sorted(changes.items()):
        destination = OUT / 'after' / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(row['after'])
        manifest.append(dict(path=path, group=row['group'], action='add' if row.get('isNew') else 'modify',
                             beforeSha256=None if row.get('isNew') else hashlib.sha256(row['before'].encode()).hexdigest(),
                             afterSha256=hashlib.sha256(row['after'].encode()).hexdigest()))
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    for group in sorted({row['group'] for row in changes.values()}):
        lines = []
        for path, row in sorted(changes.items()):
            if row['group'] != group:
                continue
            lines.append(f'diff --git a/{path} b/{path}\n')
            if row.get('isNew'):lines.append('new file mode 100644\n')
            lines.extend(difflib.unified_diff(row['before'].splitlines(True), row['after'].splitlines(True),
                                            fromfile='/dev/null' if row.get('isNew') else 'a/' + path, tofile='b/' + path))
        destination = OUT / group
        destination.mkdir(exist_ok=True)
        (destination / 'implementation.patch').write_text(''.join(lines))


if __name__ == '__main__':
    emit()
    print(f'Prepared {len(changes)} files')
