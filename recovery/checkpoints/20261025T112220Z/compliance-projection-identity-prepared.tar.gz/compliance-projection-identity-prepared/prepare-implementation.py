from pathlib import Path
root=Path('/tmp/compliance-projection-identity-prepared/work')
def edit(name, replacements):
    p=root/name
    value=p.read_text()
    for old,new in replacements:
        if old not in value: raise Exception(f'No match {name}: {old!r}')
        value=value.replace(old,new)
    p.write_text(value)
edit('src/Compliance.Core/Features/Commitments/CommitmentDraftDirectorySchema.cs',[
('KvDirectory<CommitmentDirectoryIdentity, Uuid> Decisions','KvDirectory<CommitmentDirectoryIdentity, string> Decisions'),
('static value => value.DecisionId!.Value,\n        static id => [id.ToString()], [ByDraftDecision]);','static value => DecisionKey(value.Header.DraftId, value.DecisionId!.Value),\n        static key => [key], [ByDraftDecision]);\n    public static string DecisionKey(Uuid draftId, Uuid decisionId) => $"{draftId}:{decisionId}";')])
edit('src/Compliance.Core/Features/Commitments/FitzCommitmentDraftDirectory.cs',[
('Decisions.GetAsync(Transaction, approved.AcceptedReviewDecisionId, ct)','Decisions.GetAsync(Transaction,\n                CommitmentDraftDirectorySchema.DecisionKey(header.DraftId, approved.AcceptedReviewDecisionId), ct)'),
('GetDecisionAsync(Uuid tenantId, Uuid decisionId, CancellationToken ct = default)','GetDecisionAsync(Uuid tenantId, Uuid draftId, Uuid decisionId, CancellationToken ct = default)'),
('Decisions.GetAsync(tx, decisionId, ct)','Decisions.GetAsync(tx,\n                CommitmentDraftDirectorySchema.DecisionKey(draftId, decisionId), ct)'),
('SourceAsync(tenantId, row.Header.DraftId, row, ct).ConfigureAwait(false)).FindDecision(decisionId)','SourceAsync(tenantId, draftId, row, ct).ConfigureAwait(false)).FindDecision(decisionId)')])
edit('src/Compliance.Core/Features/Commitments/ICommitmentDraftDirectoryReader.cs',[
('GetDecisionAsync(Uuid tenantId, Uuid decisionId,','GetDecisionAsync(Uuid tenantId, Uuid draftId, Uuid decisionId,')])
for path in ['test/Compliance.Tests/Features/Operations/OperationsFixture.cs','test/Compliance.Tests/Features/Examinations/CommitmentTypeIBaselineSourceContributorTests.cs']:
    edit(path,[('ValueTask<CommitmentDecisionView?> GetDecisionAsync(Uuid tenantId,\n            Uuid decisionId,','ValueTask<CommitmentDecisionView?> GetDecisionAsync(Uuid tenantId,\n            Uuid draftId, Uuid decisionId,')])
edit('src/Compliance.Core/Features/Work/ControlOperatingPlanWorkItemDirectorySchema.cs',[
('KvDirectory<ControlOperatingPlanApprovalWorkState, Uuid> Plans','KvDirectory<ControlOperatingPlanApprovalWorkState, string> Plans'),
('static work => work.PlanVersionId,\n        static planVersionId => [planVersionId.ToString()], [ByProgram]);','static work => PlanKey(work.ProgramId, work.ControlId, work.PlanVersionId),\n        static key => [key], [ByProgram]);\n\n    public static string PlanKey(Uuid programId, Uuid controlId, Uuid planVersionId) =>\n        $"{programId}\\n{controlId}\\n{planVersionId}";')])
edit('src/Compliance.Core/Features/Work/FitzControlOperatingPlanWorkItemDirectory.cs',[
('Transaction, plan.PlanVersionId, ct)','Transaction, ControlOperatingPlanWorkItemDirectorySchema.PlanKey(\n                plan.ProgramId, plan.ControlId, plan.PlanVersionId), ct)'),
('            approved.PlanVersionId, ct)','            ControlOperatingPlanWorkItemDirectorySchema.PlanKey(approved.ProgramId, approved.ControlId,\n                approved.PlanVersionId), ct)')])
edit('src/Compliance.Core/Features/Work/WorkSource.cs',[
('mapping.ControlId, proposal.MappingId, mapping.CriterionIdentifier,','ControlCriterionMapping.IdentityOf(tenantId, programId, mapping.ControlId, mapping.EditionId, mapping.CriterionIdentifier),\n                    mapping.ControlId, proposal.MappingId, mapping.CriterionIdentifier,'),
('proposal.DecisionId, decision.CriterionIdentifier,','CriterionApplicability.IdentityOf(tenantId, programId, decision.EditionId, decision.CriterionIdentifier),\n                    proposal.DecisionId, decision.CriterionIdentifier,'),
('WorkCandidate.IdFor(planVersionId, ControlOperatingPlanApproval),','ControlOperatingPlanApprovalWorkItemId(tenantId, programId, controlId, planVersionId),'),
('    public static WorkCandidate ControlEvaluationReviewCandidate','    public static Uuid ControlOperatingPlanApprovalWorkItemId(Uuid tenantId, Uuid programId, Uuid controlId, Uuid planVersionId) =>\n        WorkCandidate.IdFor(Uuid.CreateVersion5(\n            Bdgrz.Compliance.Features.Operations.ControlOccurrenceIdentity.PlanLineOf(tenantId, programId, controlId),\n            $"operating-plan-approval\\n{planVersionId}"), ControlOperatingPlanApproval);\n\n    public static WorkCandidate ControlEvaluationReviewCandidate'),
('Uuid programId, Uuid controlId, Uuid mappingId, string criterionIdentifier,','Uuid programId, Uuid lineId, Uuid controlId, Uuid mappingId, string criterionIdentifier,'),
('new(ControlCriterionMappingReviewWorkItemId(mappingId, versionNumber),','new(ControlCriterionMappingReviewWorkItemId(lineId, mappingId, versionNumber),'),
('ControlCriterionMappingReviewWorkItemId(Uuid mappingId, int versionNumber)','ControlCriterionMappingReviewWorkItemId(Uuid lineId, Uuid mappingId, int versionNumber)'),
('Uuid.CreateVersion5(mappingId,\n            $"control-criterion-mapping-review\\n{versionNumber}")','Uuid.CreateVersion5(lineId,\n            $"control-criterion-mapping-review\\n{mappingId}\\n{versionNumber}")'),
('Uuid programId, Uuid decisionId, string criterionIdentifier,','Uuid programId, Uuid lineId, Uuid decisionId, string criterionIdentifier,'),
('new(CriterionApplicabilityReviewWorkItemId(decisionId, versionNumber),','new(CriterionApplicabilityReviewWorkItemId(lineId, decisionId, versionNumber),'),
('CriterionApplicabilityReviewWorkItemId(Uuid decisionId, int versionNumber)','CriterionApplicabilityReviewWorkItemId(Uuid lineId, Uuid decisionId, int versionNumber)'),
('Uuid.CreateVersion5(decisionId,\n            $"criterion-applicability-review\\n{versionNumber}")','Uuid.CreateVersion5(lineId,\n            $"criterion-applicability-review\\n{decisionId}\\n{versionNumber}")')])
edit('src/Compliance.Core/Features/Work/FitzControlMappingWorkItemDirectory.cs',[
('proposed.ProgramId, proposed.ControlId, proposed.MappingId,','proposed.ProgramId, scope.LineId, proposed.ControlId, proposed.MappingId,'),
('RemoveWorkItemAsync(reviewed.TenantId, reviewed.ProgramId, reviewed.MappingId,','RemoveWorkItemAsync(reviewed.TenantId, reviewed.ProgramId, scope.LineId, reviewed.MappingId,'),
('RemoveWorkItemAsync(Uuid tenantId, Uuid programId, Uuid mappingId,','RemoveWorkItemAsync(Uuid tenantId, Uuid programId, Uuid lineId, Uuid mappingId,'),
('WorkItemIdFor(mappingId, versionNumber)','WorkItemIdFor(lineId, mappingId, versionNumber)'),
('WorkItemIdFor(Uuid mappingId, int versionNumber)','WorkItemIdFor(Uuid lineId, Uuid mappingId, int versionNumber)'),
('ControlCriterionMappingReviewWorkItemId(mappingId, versionNumber)','ControlCriterionMappingReviewWorkItemId(lineId, mappingId, versionNumber)')])
edit('src/Compliance.Core/Features/Work/FitzCriterionApplicabilityWorkItemDirectory.cs',[
('proposed.ProgramId, proposed.DecisionId, proposed.CriterionIdentifier,','proposed.ProgramId, scope.LineId, proposed.DecisionId, proposed.CriterionIdentifier,'),
('reviewed.DecisionId, reviewed.VersionNumber, required: true','scope.LineId, reviewed.DecisionId, reviewed.VersionNumber, required: true'),
('withdrawn.DecisionId, withdrawn.VersionNumber, required: false','scope.LineId, withdrawn.DecisionId, withdrawn.VersionNumber, required: false'),
('RemoveWorkItemAsync(Uuid tenantId, Uuid programId, Uuid decisionId,','RemoveWorkItemAsync(Uuid tenantId, Uuid programId, Uuid lineId, Uuid decisionId,'),
('WorkItemIdFor(decisionId, versionNumber)','WorkItemIdFor(lineId, decisionId, versionNumber)'),
('WorkItemIdFor(Uuid decisionId, int versionNumber)','WorkItemIdFor(Uuid lineId, Uuid decisionId, int versionNumber)'),
('CriterionApplicabilityReviewWorkItemId(decisionId, versionNumber)','CriterionApplicabilityReviewWorkItemId(lineId, decisionId, versionNumber)')])
edit('test/Compliance.Tests/Features/Work/FitzControlOperatingPlanWorkItemDirectoryTests.cs',[
('WorkCandidate.IdFor(plan.PlanVersionId,\n            WorkSource.ControlOperatingPlanApproval)','WorkSource.ControlOperatingPlanApprovalWorkItemId(fixture.TenantId, fixture.ProgramId,\n            fixture.ControlId, plan.PlanVersionId)')])
edit('test/Compliance.Tests/Features/Work/FitzControlMappingWorkItemDirectoryTests.cs',[
('WorkCandidate.IdFor(Uuid.CreateVersion5(mappingId,\n            "control-criterion-mapping-review\\n1"), WorkSource.ControlCriterionMappingReview)','WorkSource.ControlCriterionMappingReviewWorkItemId(ControlCriterionMapping.IdentityOf(tenantId, programId,\n            controlId, editionId, "AC-2.4"), mappingId, 1)')])
edit('test/Compliance.Tests/Features/Work/FitzCriterionApplicabilityWorkItemDirectoryTests.cs',[
('WorkCandidate.IdFor(Uuid.CreateVersion5(decisionId,\n            "criterion-applicability-review\\n1"), WorkSource.CriterionApplicabilityReview)','WorkSource.CriterionApplicabilityReviewWorkItemId(CriterionApplicability.IdentityOf(tenantId, programId,\n            editionId, "AC-2.4"), decisionId, 1)')])
edit('test/Compliance.Tests/Features/Work/WorkQueueReadConsistencyTests.cs',[
('var (mappingId, proposedAt) = await SeedControlMappingProposalAsync(fixture);','var (mappingId, proposedAt, editionId) = await SeedControlMappingProposalAsync(fixture);'),
('fixture.ProgramId, fixture.ControlId, mappingId, "AC-2.4", fixture.OwnerMemberId, 1,','fixture.ProgramId, ControlCriterionMapping.IdentityOf(fixture.TenantId, fixture.ProgramId, fixture.ControlId,\n                editionId, "AC-2.4"), fixture.ControlId, mappingId, "AC-2.4", fixture.OwnerMemberId, 1,'),
('Task<(Uuid MappingId, DateTimeOffset ProposedAt)>','Task<(Uuid MappingId, DateTimeOffset ProposedAt, Uuid EditionId)>'),
('return (mappingId, proposedAt);','return (mappingId, proposedAt, editionId);')])
print('Prepared owner-scoped directory and work identity implementation and signature migrations.')
