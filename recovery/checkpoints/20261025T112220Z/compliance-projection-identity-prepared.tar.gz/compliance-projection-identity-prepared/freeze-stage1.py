from pathlib import Path
import json,hashlib,difflib,shutil,subprocess,datetime
p=Path('/tmp/compliance-projection-identity-prepared')
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=sorted(str(f.relative_to(p/'work')) for f in (p/'work').rglob('*.cs'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
def text(path): return path.read_text() if path.exists() else ''
def diff(before,after,names):
 out=[]
 for name in names:
  a,b=before/name,after/name
  out.extend(difflib.unified_diff(text(a).splitlines(keepends=True),text(b).splitlines(keepends=True),fromfile='a/'+name if a.exists() else '/dev/null',tofile='b/'+name if b.exists() else '/dev/null'))
 return ''.join(out)
source=[n for n in paths if n.startswith('src/')]
tests=[n for n in paths if n.startswith('test/')]
(p/'implementation.patch').write_text(diff(p/'base',p/'work',source))
(p/'tests.patch').write_text(diff(p/'base',p/'work',tests))
(p/'full.patch').write_text(diff(p/'base',p/'work',paths))
empty=p/'empty';empty.mkdir(exist_ok=True)
redpaths=sorted(str(f.relative_to(p/'red')) for f in (p/'red').rglob('*.cs'))
(p/'behavioral-red.patch').write_text(diff(empty,p/'red',redpaths))
redbase=p/'red-base'
if redbase.exists(): shutil.rmtree(redbase)
shutil.copytree(p/'base',redbase)
for name in redpaths:
 (redbase/name).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p/'red'/name,redbase/name)
(p/'after-red.patch').write_text(diff(redbase,p/'work',paths))
checks=[]
for patch,base in [('full.patch',p/'base'),('behavioral-red.patch',empty),('after-red.patch',redbase)]:
 dst=p/('verify-'+patch.removesuffix('.patch'))
 if dst.exists(): shutil.rmtree(dst)
 shutil.copytree(base,dst)
 result=subprocess.run(['patch','--batch','-p1'],cwd=dst,input=(p/patch).read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 expected=p/'red' if patch=='behavioral-red.patch' else p/'work'
 compare=redpaths if patch=='behavioral-red.patch' else paths
 mismatch=[name for name in compare if sha(dst/name)!=sha(expected/name)]
 checks.append({'patch':patch,'exit_code':result.returncode,'mismatches':mismatch})
 if result.returncode or mismatch: raise Exception(result.stdout.decode()+str(mismatch))
manifest=[{'path':name,'before_sha256':sha(p/'base'/name),'after_sha256':sha(p/'work'/name),'current_main_matches_before':sha(repo/name)==sha(p/'base'/name)} for name in paths]
(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
filter='FullyQualifiedName~CommitmentOwnerScopedIdentityTests|FullyQualifiedName~OwnerScopedProjectionIdentityTests'
(p/'red-filter.txt').write_text(filter+'\n')
(p/'target-filter.txt').write_text(filter+'|FullyQualifiedName~CommitmentNativeDirectoryReadTests|FullyQualifiedName~FitzControlOperatingPlanWorkItemDirectoryTests|FullyQualifiedName~FitzControlMappingWorkItemDirectoryTests|FullyQualifiedName~FitzCriterionApplicabilityWorkItemDirectoryTests|FullyQualifiedName~WorkQueueReadConsistencyTests|FullyQualifiedName~ControlMappingWorkTests\n')
handoff={'status':'offline_prepared_not_compiled_or_executed','scope':'stage1_commitment_decisions_and_operating_plan_mapping_applicability_work_identity','changed_paths':len(paths),'production_paths':len(source),'test_paths':len(tests),'behavioral_red_test_rows':13,'apply_order':['behavioral-red.patch on unchanged baseline, run red-filter.txt; expected failures demonstrate collisions and stale generation trust','after-red.patch directly on baseline+behavioral-red to migrate tests and apply implementation','or revert behavioral-red then apply implementation.patch+tests.patch / full.patch'],'patches':{name:sha(p/name) for name in ['behavioral-red.patch','after-red.patch','implementation.patch','tests.patch','full.patch']},'reconstruction_checks':checks,'main_drift':[row['path'] for row in manifest if not row['current_main_matches_before']],'shared_wiring_deltas':[],'qualification_gaps':['New projection generations intentionally do not trust old flat-key rows/checkpoints. Catch-up/replay gates remain authoritative.','Changed work-item identity does not migrate historical assignment/delegation/escalation streams or old saved URLs. No alias migration is invented; persisted histories need explicit qualification before rollout.','Mapping/applicability local-ID action lookups retain explicit ambiguity refusal in authoritative locators. No new routes or global mutation uniqueness guarantee.'],'next_separate_layer':['Advisor feedback work/schema thread-scope collision','Member responsibility assignment index exact-scope collision']}
(p/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'production':len(source),'tests':len(tests),'reconstruction':checks,'main_drift':handoff['main_drift']},indent=2))
