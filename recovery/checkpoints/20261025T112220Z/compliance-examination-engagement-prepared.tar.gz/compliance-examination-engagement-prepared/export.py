from pathlib import Path
import json,difflib,hashlib,subprocess,tempfile,shutil
r=Path('/tmp/compliance-examination-engagement-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
changed=sorted(str(f.relative_to(r/'work')) for f in (r/'work').rglob('*') if f.is_file() and (not (r/'base'/f.relative_to(r/'work')).exists() or f.read_bytes()!=(r/'base'/f.relative_to(r/'work')).read_bytes()))
def original(p):return (r/'base'/p).read_bytes() if (r/'base'/p).exists() else b''
def patch(paths,before=None):
 out=''
 for p in paths:
  b=(before or {}).get(p,original(p));a=(r/'work'/p).read_bytes()
  out+=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+p if b else'/dev/null',tofile='b/'+p))
 return out
source=[p for p in changed if p.startswith('src/')];tests=[p for p in changed if p.startswith('test/')]
for name,paths in [('full.patch',changed),('implementation.patch',source),('tests.patch',tests)]: (r/name).write_text(patch(paths))
with tempfile.TemporaryDirectory(prefix='examination-red-baseline-') as d:
 d=Path(d)
 for p in changed:
  if original(p):(d/p).parent.mkdir(parents=True,exist_ok=True);(d/p).write_bytes(original(p))
 run=subprocess.run(['patch','--batch','-p1','-d',str(d),'-i',str(r/'behavioral-red.patch')],capture_output=True,text=True)
 if run.returncode:raise SystemExit((run.stdout,run.stderr))
 before={p:(d/p).read_bytes() if (d/p).exists() else b'' for p in changed}
 (r/'after-red.patch').write_text(patch(changed,before))
rows=[]
for p in changed:
 b=original(p);a=(r/'work'/p).read_bytes()
 rows.append({'path':p,'before':sha(b) if b else None,'after':sha(a),'kind':'source' if p.startswith('src/') else'test','currentMainMatchesBefore':(repo/p).read_bytes()==b if (repo/p).exists() else not b})
(r/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
checks=[]
for name,sequence in [('full',['full.patch']),('partitioned',['tests.patch','implementation.patch']),('red-then-green',['behavioral-red.patch','after-red.patch'])]:
 with tempfile.TemporaryDirectory(prefix='examination-reconstruct-') as d:
  d=Path(d)
  for p in changed:
   if original(p):(d/p).parent.mkdir(parents=True,exist_ok=True);(d/p).write_bytes(original(p))
  for artifact in sequence:
   run=subprocess.run(['patch','--batch','-p1','-d',str(d),'-i',str(r/artifact)],capture_output=True,text=True)
   if run.returncode:raise SystemExit((name,artifact,run.stdout,run.stderr))
  bad=[p for p in changed if not (d/p).exists() or (d/p).read_bytes()!=(r/'work'/p).read_bytes()]
  if bad:raise SystemExit((name,bad))
  checks.append({'sequence':name,'exactFiles':len(changed),'passed':True})
(r/'reconstruction.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'changed':len(changed),'source':len(source),'tests':len(tests),'driftedBaseline':[x['path'] for x in rows if not x['currentMainMatchesBefore']],'patchHashes':{n:sha((r/n).read_bytes()) for n in ['behavioral-red.patch','implementation.patch','tests.patch','after-red.patch','full.patch']},'reconstruction':checks},indent=2))
