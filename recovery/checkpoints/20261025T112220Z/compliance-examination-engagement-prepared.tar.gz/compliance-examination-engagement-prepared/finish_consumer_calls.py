from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,shutil
r=Path('/tmp/compliance-examination-engagement-prepared');w=r/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
for f in (w/'test').rglob('*.cs'):
 t=f.read_bytes();edits=[]
 for n in walk(parser.parse(t).root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((c for c in n.children if c.type=='argument_list'),None)
  if not typ or not args:continue
  name=t[typ.start_byte:typ.end_byte].decode();num=sum(c.type=='argument' for c in args.children)
  if name in {'RecordManagementAssertionHandler','RecordManagementExaminationReviewHandler'} and num==6:
   edits.append((args.end_byte-1,', fixture.Examinations'))
  elif name=='GetTypeIBaselineHandler' and f.name=='SnapshotSourcePublicationTests.cs' and num==3:
   aa=[c for c in args.children if c.type=='argument'];edits.append((aa[2].start_byte,'fixture.Examinations, '))
 for pos,text in sorted(edits,reverse=True):t=t[:pos]+text.encode()+t[pos:]
 f.write_bytes(t)
p=w/'test/Compliance.Tests/Features/SystemDescription/SystemDescriptionDraftCommandHandlerTests.cs';s=p.read_text().replace('new(Reader, Periods, new SystemDescriptionSnapshotSources(PeriodEvents, PeriodContent));','new(Reader, Periods, new SystemDescriptionSnapshotSources(PeriodEvents, PeriodContent), Examinations);');p.write_text(s)
p=w/'test/Compliance.Tests/Features/Examinations/RecordManagementAssertionHandlerTests.cs';s=p.read_text().replace('new(Executor, Reader, Packages, Periods, Clock, Descriptions);','new(Executor, Reader, Packages, Periods, Clock, Descriptions, Examinations);');p.write_text(s)
p=w/'test/Compliance.Tests/Testing/TypeIIRangeHost.cs';s=p.read_text().replace('clock, new SystemDescriptionReader(Reader, Events, Content));','clock, new SystemDescriptionReader(Reader, Events, Content), new ExaminationEngagementReader(Reader, Events, Content));');p.write_text(s)
rel='test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.cs'
if not (r/'base'/rel).exists():
 for d in ['base','work']:
  p=r/d/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,p)
p=w/rel;s=p.read_text().replace('        public IDomainEventReader Events => Host.Events;','        public IDomainEventReader Events => Host.Events;\n        public ExaminationEngagementReader Examinations => new(Reader, Events, Host.Content);');p.write_text(s)
