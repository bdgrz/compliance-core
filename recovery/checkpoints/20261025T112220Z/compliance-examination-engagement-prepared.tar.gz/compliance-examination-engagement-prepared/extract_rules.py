from pathlib import Path
import re
r=Path('/tmp/compliance-examination-engagement-prepared/work/src/Compliance.Core/Features/Examinations');s=(r/'ExaminationEngagement.cs').read_text()
s=s.replace('public sealed class ExaminationEngagement : Aggregate','public sealed class ExaminationEngagementRules').replace('    public NativeAcceptance ReplayAcceptance { get; }\n    OperationProvenance? _pendingOperation;','    readonly List<ExaminationEngagementRuleChange> _changes = [];\n    public IReadOnlyList<ExaminationEngagementRuleChange> PendingChanges => _changes;\n    public Uuid Id { get; }')
s=s.replace('    const int MaximumEventBytes = 48 * 1024;\n','').replace('using System.Text.Json;\n','')
a=s.index('    public ExaminationEngagement(');b=s.index('\n    public CommandFailure? Create',a)
s=s[:a]+'''    public ExaminationEngagementRules(Uuid tenantId, Uuid programId, Uuid engagementId)
    {
        (_tenantId, _programId, Id) = (tenantId, programId, engagementId);
    }

    internal void Replay(ExaminationEngagementRuleChange change)
    {
        switch (change)
        {
            case ExaminationEngagementRuleOpened opened: Apply(opened); break;
            case ExaminationEngagementRuleRevised revised: Apply(revised); break;
            case ExaminationEngagementRuleFrozen frozen: Apply(frozen); break;
            case ExaminationEngagementRuleAmended amended: Apply(amended); break;
            default: throw new InvalidOperationException("The engagement rules change kind is invalid.");
        }
        _changes.Add(change);
    }

    void RaiseEvent(ExaminationEngagementRuleChange change) => Replay(change);
''' + s[b:]
s=s.replace('        OperationProvenance? operation = null)','        OperationProvenance? operation = null)')
s=s.replace('        if (AuthoredCommandReplay.TryReplay(ReplayAcceptance, operation, out var replayFailure))\n            return replayFailure;\n        _pendingOperation = operation;\n','')
s=s.replace(' { Operation = _pendingOperation }','').replace('        AuthoredCommandReplay.Observe(this, ReplayAcceptance, ev, ev.Operation);\n','')
for old,new in [('ExaminationEngagementOpened','ExaminationEngagementRuleOpened'),('ExaminationEngagementRevised','ExaminationEngagementRuleRevised'),('TypeIBaselineFrozen','ExaminationEngagementRuleFrozen'),('TypeIBaselineAmended','ExaminationEngagementRuleAmended')]:s=s.replace(old,new)
s=re.sub(r'        if \(!Fits\((?:opened|revised|ev)\)\)\n            return CommandFailure.InvalidContent\(\n                "[^\n]*"\);\n','',s)
s=re.sub(r'    static bool Fits<T>\(T value\) => JsonSerializer.SerializeToUtf8Bytes\(value,\n        value!\.GetType\(\), ComplianceCoreJsonContext.Default\).Length <= MaximumEventBytes;\n\n','',s)
# The former depth cap only bounded the inline lifetime lineage. New owner history is external.
s=s.replace('    const int MaximumAmendmentDepth = 8;\n','')
s=s.replace('        if (_baseline.AmendmentDepth >= MaximumAmendmentDepth)\n            return CommandFailure.StateConflict(\n                "The Type I baseline amendment lineage reached its supported limit.");\n','')
(r/'ExaminationEngagementRules.cs').write_text(s)
base='''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>Transient complete validation input; never persisted or retained by an Aggregate.</summary>
public abstract record ExaminationEngagementRuleChange(Uuid TenantId, ExaminationEngagementView Engagement,
    DateTimeOffset OccurredAt);
'''
(r/'ExaminationEngagementRuleChange.cs').write_text(base)
for suffix,baseline in [('Opened',False),('Revised',False),('Frozen',True),('Amended',True)]:
 body='''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>One complete transient rules change, outside native command authority.</summary>
public sealed record ExaminationEngagementRuleSUFFIX(Uuid TenantId, ExaminationEngagementView Engagement,
    BASELINEDateTimeOffset OccurredAt) : ExaminationEngagementRuleChange(TenantId, Engagement, OccurredAt);
'''.replace('SUFFIX',suffix).replace('BASELINE','TypeIBaselineView Baseline, ' if baseline else'')
 (r/f'ExaminationEngagementRule{suffix}.cs').write_text(body)
