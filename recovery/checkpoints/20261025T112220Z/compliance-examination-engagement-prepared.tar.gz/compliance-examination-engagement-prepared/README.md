# Examination engagement compact native cutover

One complete offline owning slice, including four handlers, native+immutable history/read composition, baseline lineage, directory, actual source/proof consumers, fixtures, scoped read binding and HTTP tests. Root owns all runtime/Jev/integration/Git. See QUALIFICATIONS.md for explicit persistence/current-source boundaries.

Owner `ExaminationEngagement` retains only scalar Header, initial/current/current-baseline/explicit-selected immutable refs, one selected NativeAcceptance, latest fact and bounded full-prefix replay commitment. Complete terms, sources, canonical manifests and baseline history are outside Aggregate in immutable content and explicit Rules/History/Snapshot. Every unselected root and baseline identity is verified at exact hydrated native+physical cut, with rolling payload/metadata equality and executor reader decoration. Preparation is source-cut bound through append; equal winning acceptance is resolved by the installed central executor.

Four incompatible occupied inlinev1 facts become nativev2 under the same names/tags. Complete `ExaminationEngagementState` immutable body preserves exact source byte publication descriptors and logical digests. Existing validation is extracted to non-Aggregate Rules, maintaining source identity/coverage/actor/rationale/changed-record/impact checks. Source consumers read exact native current/historical versions; no legacy dual path. Existing Package36 APIs/fixture migrations are prerequisite and preserved.

Public Reader API is `(IAggregateReader, IDomainEventReader, IImmutableContentStore)`:
- `ReadAsync(tenant,program,examination,ct)` returns explicit Snapshot Owner/View/Baseline/History/Rules.
- `ReadBaselineAsync(tenant,program,examination,baseline,ct)` returns exact verified historical baseline or null.
- Scoped query locator uses directory only for identity discovery; native/body authority and final source/checkpoint fences are mandatory.

Constructor deltas: native Operations4; Create handler3(operations,reader,readiness), Revise2(operations,reader), Freeze/Amend3(operations,directory,previews); Directory2(client,content); GetEngagement1(nativeReader); Preview3(nativeReader,directory,previews); GetBaseline3required(directory,events,nativeReader)+optionalcontent4; PackageSourceBuilder first argument now native examinationReader; TypeII Propose/Start final examinationReader; SystemDescriptionSourceResolver fourth examinationReader; Assertion/ManagementReview final examinationReader. TypeIICloseReconciliation constructor unchanged, uses its existing reader/events/content to compose examination authority. Shared root DI/JSON/safety/Program deltas are narrow additions; retain concurrent root overlays.

Test fixture writing is explicit `ExaminationSeeds.WriteAsync(reader,writer,events,content,rules,ct)` with fresh selected/raw-verified hydration per native append, actual typed DTO intent hashes, real immutable state/Unit/descriptor/result refs, exact original member/clock/revision and FirstOwner. `ExaminationScenario` supplies real stored native proof for projections/scoped query tests and deliberately altered valid immutable body faults; no opaque authority refs replace malformed/rollback assertions. Original acceptance names/assert counts are retained. HTTP tests prove native200{}, original result after laterdefer/revision, canonical scoped Get, current permission before replay, and forbidden guest/firm-staff writes.

Patches:
- `behavioral-red.patch` is the exact root-qualified old-API RED2; leave its SHA unchanged.
- `after-red.patch` advances from that exact RED to the complete implementation/tests/shared wiring.
- Or `implementation.patch` + `tests.patch`, or `full.patch`, from captured exact baselines.
- Three reconstruction sequences must match manifest hashes. Shared files may drift; compose additive DI/context/wrapper/read-binder deltas rather than overwrite.

Recommended root focus: Examinations engagement/baseline/directory/preview/management sources, AuditPackages, SystemDescription source proof, TypeII propose/start/close/archive. New HTTP class is `ExaminationEngagementNativeHttpTests`. Do not run unrelated source contributor snapshot copies: unchanged baseline files are not exported. Root's current Evaluation fixture/contributor changes are deliberately excluded.

Queued next task after this frozen handoff: WorkDigestDispatch + WeeklyWorkDigest actual source/lifetime inventory and coherent migration; no digest edits yet.
