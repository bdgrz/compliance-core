from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json,re
r=Path('/tmp/compliance-examination-engagement-prepared/work');p=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
errors=[]
for f in (r/'test').rglob('*.cs'):
 t=f.read_bytes();tree=p.parse(t)
 for method in walk(tree.root_node):
  if method.type!='method_declaration':continue
  types={}
  for n in walk(method):
   if n.type!='variable_declarator':continue
   nm=n.child_by_field_name('name');v=tx(t,n)
   if nm and re.search(r'=\s*new ExaminationEngagementRules\(',v):types[tx(t,nm)]='rules'
   elif nm and re.search(r'=\s*await [\w.]*Examinations\.ReadAsync\(',v):types[tx(t,nm)]='snapshot'
  for n in walk(method):
   if n.type!='member_access_expression':continue
   expr=n.child_by_field_name('expression');name=n.child_by_field_name('name')
   if not expr or not name:continue
   var=tx(t,expr);member=tx(t,name);kind=types.get(var)
   bad=kind=='rules' and member in {'Stream','Version','Acceptance','ReplayAcceptance','CommittedStreamPosition'} or kind=='snapshot' and member in {'Current','Revision','Stream','Version','Create','Revise','FreezeBaseline','AmendBaseline','BaselineHistory'}
   if bad:errors.append({'path':str(f.relative_to(r)),'line':t[:n.start_byte].count(b'\n')+1,'variable':var,'kind':kind,'member':member})
  for var,kind in types.items():
   if re.search(r'\.SaveAsync\('+re.escape(var)+r'\s*,',tx(t,method)):errors.append({'path':str(f.relative_to(r)),'method':tx(t,method.child_by_field_name('name')),'invalidDirectSave':var,'kind':kind})
(r.parent/'member-audit.json').write_text(json.dumps(errors,indent=2)+'\n');print(json.dumps(errors,indent=2))
