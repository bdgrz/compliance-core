from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,re
r=Path('/tmp/compliance-examination-engagement-prepared/work');parser=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
def txt(t,n):return t[n.start_byte:n.end_byte].decode()
for f in (r/'test').rglob('*.cs'):
 if f.name in {'ExaminationSeeds.cs','ExaminationEngagementTests.cs','TypeIBaselineScopedIdentityTests.cs','FitzExaminationEngagementDirectoryTests.cs','ExaminationEngagementNativeBoundaryTests.cs'}:continue
 t=f.read_bytes();tree=parser.parse(t);edits=[];byMethod={};seedVars={}
 for n in walk(tree.root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type')
  if not typ or txt(t,typ) not in {'ExaminationEngagement','ExaminationEngagementAggregate'}:continue
  # Locate the immediate Hydrate invocation, if any.
  ancestor=n.parent;hydr=None
  while ancestor and ancestor.type not in {'method_declaration','constructor_declaration','variable_declarator','expression_statement'}:
   if ancestor.type=='invocation_expression' and 'HydrateAsync' in txt(t,ancestor).split('(')[0]:hydr=ancestor;break
   ancestor=ancestor.parent
  method=n.parent
  while method and method.type!='method_declaration':method=method.parent
  if hydr:
   args=next(c for c in n.children if c.type=='argument_list');aa=[txt(t,a) for a in args.children if a.type=='argument']
   ha=next(c for c in hydr.children if c.type=='argument_list');ht=[txt(t,a) for a in ha.children if a.type=='argument'];ct=', '+ht[1] if len(ht)>1 else''
   callhead=txt(t,hydr).split('HydrateAsync')[0];readerexpr=callhead.rstrip('.')
   fixture=readerexpr.rsplit('.',1)[0] if '.' in readerexpr else''
   newhead=fixture+'.Examinations' if fixture else'Examinations'
   edits.append((hydr.start_byte,hydr.end_byte,newhead+'.ReadAsync('+', '.join(aa[:3])+ct+')'))
   vd=hydr.parent
   while vd and vd.type not in {'variable_declarator','method_declaration'}:vd=vd.parent
   if vd and vd.type=='variable_declarator' and method:
    name=vd.child_by_field_name('name');byMethod.setdefault((method.start_byte,method.end_byte),set()).add(txt(t,name))
  else:
   edits.append((typ.start_byte,typ.end_byte,'ExaminationEngagementRules'))
   vd=n.parent
   while vd and vd.type not in {'variable_declarator','method_declaration'}:vd=vd.parent
   if vd and vd.type=='variable_declarator' and method:seedVars.setdefault((method.start_byte,method.end_byte),set()).add(txt(t,vd.child_by_field_name('name')))
 # Add member edits in exact methods only, avoiding identically named non-engagement variables in other tests.
 for (a,b),variables in byMethod.items():
  body=t[a:b].decode()
  for var in variables:
   for old,new in [('Current','View'),('Revision','Owner.Revision'),('CommittedStreamPosition','Owner.CommittedStreamPosition'),('BaselineHistory','Rules.BaselineHistory'),('Create','Rules.Create'),('Stream','Owner.Stream')]:
    for m in re.finditer(r'\b'+re.escape(var)+r'\.'+old+r'\b',body):edits.append((a+m.start(),a+m.end(),var+'.'+new))
 for a,b,s in sorted(edits,reverse=True):t=t[:a]+s.encode()+t[b:]
 f.write_bytes(t)
 # Save calls are handled with the actual existing fixture ports, preserving other owners.
 s=f.read_text()
 if not seedVars:continue
 filename=f.name
 if filename=='PreviewTypeIBaselineHandlerTests.cs':ports='AggregateReader, AggregateWriter, Events, Content'
 elif filename in {'ProposeTypeIIOperatingPlanHandlerTests.cs'}:ports='Reader, Writer, Events, Content'
 elif filename=='StartTypeIIObservationPeriodHandlerTests.cs':ports='Reader, Writer, Host.Events, Host.Content'
 elif filename.startswith('TypeIIPeriodCommandHandlerTests'):ports='fixture.Reader, fixture.Writer, fixture.Events, fixture.Host.Content'
 elif filename.startswith('SystemDescriptionDraftCommandHandlerTests'):ports='Reader, Writer, PeriodEvents, PeriodContent'
 elif filename=='SnapshotSourcePublicationTests.cs':ports='Reader, Writer, PeriodEvents, Content'
 elif filename=='ExaminationEngagementCommandHandlerTests.cs':ports='Reader, Writer, Events, Content'
 elif filename=='TypeIBaselineCommandHandlerTests.cs':ports='Reader, Writer, Events, Content'
 elif filename=='RecordManagementExaminationReviewHandlerTests.cs':ports='fixture.Reader, fixture.Writer, fixture.PeriodEvents, fixture.ContentStore'
 else:ports='Reader, Writer, PeriodEvents, ContentStore'
 names=set().union(*seedVars.values())
 for var in names:
  # Arguments contain the standard existing system dispatch context; source code paths here have no custom callback.
  pattern=r'await\s+(?:[\w.]+\.)?SaveAsync\('+re.escape(var)+r',\s*new RequestDispatchContext\(RequestActor.System\)\s*\)'
  s,n=re.subn(pattern,'await ExaminationSeeds.WriteAsync('+ports+', '+var+')',s)
 if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
 f.write_text(s)
