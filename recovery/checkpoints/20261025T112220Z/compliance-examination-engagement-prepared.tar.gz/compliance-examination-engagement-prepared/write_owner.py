from pathlib import Path
r=Path('/tmp/compliance-examination-engagement-prepared/work');c=r/'src/Compliance.Common/Features/Examinations';core=r/'src/Compliance.Core/Features/Examinations'
for name,tag in [('ExaminationEngagementOpened','examination-engagement-opened'),('ExaminationEngagementRevised','examination-engagement-revised'),('TypeIBaselineFrozen','type-i-baseline-frozen'),('TypeIBaselineAmended','type-i-baseline-amended')]:
 (c/(name+'.cs')).write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>One exact attributed native engagement transition; complete business bytes stay immutable.</summary>
[Discriminator("bdgrz.examinations.TAG", 2)]
public sealed record NAME(Uuid TenantId, Uuid SubjectId, Uuid ProgramId, long Revision,
    string EngagementType, Uuid BoundaryId, Uuid? BaselineId, long BaselineRevision, ImmutableContentRef Change,
    DateTimeOffset OccurredAt, OperationProvenance Operation, ImmutableContentRef? FirstResponse,
    ImmutableContentRef? OperationResult, Uuid ActorMemberId) : DomainEvent, IExaminationEngagementFact;
'''.replace('TAG',tag).replace('NAME',name))
(c/'IExaminationEngagementFact.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>The exact bounded native identity shared by the four engagement transition kinds.</summary>
public interface IExaminationEngagementFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid SubjectId { get; }
    Uuid ProgramId { get; }
    long Revision { get; }
    string EngagementType { get; }
    Uuid BoundaryId { get; }
    Uuid? BaselineId { get; }
    long BaselineRevision { get; }
    ImmutableContentRef Change { get; }
    DateTimeOffset OccurredAt { get; }
    ImmutableContentRef? OperationResult { get; }
    Uuid ActorMemberId { get; }
}
''')
(core/'ExaminationEngagementHeader.cs').write_text('''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>Current scalar engagement authority; terms, contacts, sources and history remain immutable content.</summary>
public sealed record ExaminationEngagementHeader(Uuid ProgramId, string EngagementType, Uuid BoundaryId,
    string Status, long Revision, Uuid? BaselineId, long BaselineRevision);
''')
(core/'ExaminationEngagementState.cs').write_text('''namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>One complete immutable business snapshot; no lifetime history is embedded.</summary>
public sealed record ExaminationEngagementState(ExaminationEngagementView Engagement, TypeIBaselineView? Baseline)
{
    public const string Schema = "examination-engagement-state.v1";
}
''')
(core/'ExaminationEngagement.cs').write_text('''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Examinations;

/// <summary>Bounded engagement authority. No complete terms, source lists or baseline history are retained.</summary>
public sealed class ExaminationEngagement : Aggregate
{
    public const string Area = "examinations";
    readonly Uuid _tenant;
    readonly Uuid _program;
    readonly Uuid _selectedBaseline;
    ImmutableContentRef? _selectedBaselineContent;
    public ExaminationEngagement(Uuid tenant, Uuid program, Uuid examination, Uuid selectedCommandId = default,
        string? selectedCommandKind = null, Uuid selectedBaselineId = default)
        : base(examination, new EventStreamAddress(tenant.ToString(), Area, examination.ToString()))
    {
        (_tenant, _program, _selectedBaseline) = (tenant, program, selectedBaselineId);
        Acceptance = new NativeAcceptance(selectedCommandId, selectedCommandKind);
        On<ExaminationEngagementOpened>(ApplyFact);
        On<ExaminationEngagementRevised>(ApplyFact);
        On<TypeIBaselineFrozen>(ApplyFact);
        On<TypeIBaselineAmended>(ApplyFact);
    }
    public Uuid TenantId => _tenant;
    public Uuid ProgramId => Header?.ProgramId ?? _program;
    public long Revision => Header?.Revision ?? 0;
    public ExaminationEngagementHeader? Header { get; private set; }
    public NativeAcceptance Acceptance { get; }
    public ImmutableContentRef? CurrentContent { get; private set; }
    public ImmutableContentRef? InitialContent { get; private set; }
    public ImmutableContentRef? BaselineContent { get; private set; }
    public ImmutableContentRef? SelectedBaselineContent => _selectedBaseline == Header?.BaselineId
        ? BaselineContent : _selectedBaselineContent;
    public Uuid SelectedBaselineId => _selectedBaseline;
    public DomainEvent? Latest { get; private set; }
    internal ExaminationEngagementReplayCut ReplayCut { get; } = new();

    public Result PrepareCreate(Uuid program) => Header is not null
        ? Fail(RequestErrorKind.Conflict, "The examination engagement already exists.")
        : _tenant == Uuid.Empty || program == Uuid.Empty || Id == Uuid.Empty
            ? Fail(RequestErrorKind.Validation, "An examination requires exact tenant/program/engagement identities.")
            : Result.Success;
    public Result PrepareWrite(Uuid program, long expected, bool requireFrozen)
    {
        if (Header is null || Header.ProgramId != program)
            return Fail(RequestErrorKind.NotFound, "The examination engagement was not found.");
        if (expected != Revision)
            return Fail(RequestErrorKind.Conflict, "The examination engagement revision is stale.");
        if ((Header.BaselineId is not null) != requireFrozen)
            return Fail(RequestErrorKind.Conflict, requireFrozen ? "A frozen Type I baseline is required."
                : "A frozen engagement can change only through an attributable baseline amendment.");
        return Result.Success;
    }

    internal Result Accept(OperationProvenance operation, ExaminationEngagementState state,
        ImmutableContentRef change, ImmutableContentRef response, ImmutableContentRef result)
    {
        var view = state.Engagement;
        var creating = operation.CommandKind == nameof(CreateExaminationEngagement);
        var frozen = operation.CommandKind == nameof(AmendTypeIBaseline);
        var guard = creating ? PrepareCreate(view.ProgramId) : PrepareWrite(view.ProgramId,
            checked((long)operation.OriginalExpectedRevision!.Value), frozen);
        if (!guard.IsSuccess)
            return guard;
        if (!OwnRoot(operation, operation.CommandKind, creating ? null : (ulong)Revision) ||
            view.TenantId != _tenant || view.ExaminationEngagementId != Id || view.Revision != Revision + 1 ||
            view.ActorMemberId != Member(operation) || view.UpdatedAt != operation.AcceptedAt ||
            Header is { } header && (view.EngagementType != header.EngagementType || view.BoundaryId != header.BoundaryId))
            return Fail(RequestErrorKind.Conflict, "The prepared engagement differs from its exact root/actor/revision authority.");
        if (ReplayCut.Require(this, Acceptance, operation) is { IsSuccess: false } missing)
            return missing;
        DomainEvent fact = operation.CommandKind switch
        {
            nameof(CreateExaminationEngagement) => new ExaminationEngagementOpened(_tenant, Id, view.ProgramId,
                view.Revision, view.EngagementType, view.BoundaryId, null, 0, change, operation.AcceptedAt,
                operation, response, result, view.ActorMemberId),
            nameof(ReviseExaminationEngagement) => new ExaminationEngagementRevised(_tenant, Id, view.ProgramId,
                view.Revision, view.EngagementType, view.BoundaryId, null, 0, change, operation.AcceptedAt,
                operation, response, result, view.ActorMemberId),
            nameof(FreezeTypeIBaseline) => new TypeIBaselineFrozen(_tenant, Id, view.ProgramId, view.Revision,
                view.EngagementType, view.BoundaryId, state.Baseline!.TypeIBaselineId, state.Baseline.Revision,
                change, operation.AcceptedAt, operation, response, result, view.ActorMemberId),
            nameof(AmendTypeIBaseline) => new TypeIBaselineAmended(_tenant, Id, view.ProgramId, view.Revision,
                view.EngagementType, view.BoundaryId, state.Baseline!.TypeIBaselineId, state.Baseline.Revision,
                change, operation.AcceptedAt, operation, response, result, view.ActorMemberId),
            _ => throw new InvalidOperationException("The examination root kind is unsupported.")
        };
        RaiseEvent(fact);
        return Result.Success;
    }

    internal bool OwnRoot(OperationProvenance operation, string kind, ulong? expected) =>
        NativeOwnerHistory.IsOwnRoot(this, operation, kind, expected) && Member(operation) != Uuid.Empty;
    internal static Uuid Member(OperationProvenance operation) => operation.Actor.Kind == "member" &&
        Uuid.TryParse(operation.Actor.Id, CultureInfo.InvariantCulture, out var member) ? member : Uuid.Empty;
    internal static string Kind(DomainEvent fact) => fact switch
    {
        ExaminationEngagementOpened => nameof(CreateExaminationEngagement),
        ExaminationEngagementRevised => nameof(ReviseExaminationEngagement),
        TypeIBaselineFrozen => nameof(FreezeTypeIBaseline),
        TypeIBaselineAmended => nameof(AmendTypeIBaseline),
        _ => throw new ImmutableContentIntegrityException("The native engagement fact kind is unsupported.")
    };
    void ApplyFact(DomainEvent domainEvent)
    {
        var fact = (IExaminationEngagementFact)domainEvent;
        if (fact.TenantId != _tenant || fact.SubjectId != Id || fact.ProgramId == Uuid.Empty ||
            fact.Revision != Revision + 1 || fact.Change.Schema != ExaminationEngagementState.Schema ||
            fact.OccurredAt != fact.Operation.AcceptedAt || fact.ActorMemberId != Member(fact.Operation) ||
            fact.FirstResponse is null || fact.OperationResult is null ||
            !OwnRoot(fact.Operation, Kind(domainEvent), Revision == 0 ? null : (ulong)Revision))
            throw Invalid("The native engagement fact differs from its exact scope/root/actor/revision.");
        var baseline = domainEvent is TypeIBaselineFrozen or TypeIBaselineAmended;
        if (Header is null)
        {
            if (domainEvent is not ExaminationEngagementOpened || fact.Operation.LogicalId != Id || baseline ||
                fact.BaselineId is not null || fact.BaselineRevision != 0 || fact.BoundaryId == Uuid.Empty ||
                fact.EngagementType != "type_i")
                throw Invalid("An engagement must be created once with exact initial authority.");
            InitialContent = fact.Change;
        }
        else
        {
            if (domainEvent is ExaminationEngagementOpened || Header.ProgramId != fact.ProgramId ||
                Header.EngagementType != fact.EngagementType || Header.BoundaryId != fact.BoundaryId ||
                domainEvent is ExaminationEngagementRevised && (Header.BaselineId is not null || baseline ||
                    fact.BaselineId is not null || fact.BaselineRevision != 0) ||
                domainEvent is TypeIBaselineFrozen && (Header.BaselineId is not null || fact.BaselineRevision != 1) ||
                domainEvent is TypeIBaselineAmended && (Header.BaselineId is null ||
                    fact.BaselineRevision != Header.BaselineRevision + 1))
                throw Invalid("The native engagement lifecycle or baseline lineage is invalid.");
        }
        if (baseline && (fact.BaselineId is not { } id || id == Uuid.Empty || fact.Operation.LogicalId != id))
            throw Invalid("A baseline root must retain its exact accepted baseline identity.");
        Header = new ExaminationEngagementHeader(fact.ProgramId, fact.EngagementType, fact.BoundaryId,
            baseline ? "baseline_frozen" : "draft", fact.Revision, fact.BaselineId, fact.BaselineRevision);
        CurrentContent = fact.Change;
        if (baseline)
        {
            BaselineContent = fact.Change;
            if (fact.BaselineId == _selectedBaseline)
                _selectedBaselineContent = fact.Change;
        }
        Latest = domainEvent;
        Acceptance.Observe(domainEvent);
        ReplayCut.Observe(domainEvent);
    }
    static ImmutableContentIntegrityException Invalid(string message) => new(message);
    static Result Fail(RequestErrorKind kind, string message) => Result.Failure(new RequestError(kind, message));
}
''')
# Reuse the already-frozen exact hydrated prefix mechanism, with independent domain/type names.
pkg=Path('/tmp/compliance-audit-package-history-prepared/work/src/Compliance.Core/Features/AuditPackages')
for src,dst in [('AuditPackageReplayDigest','ExaminationEngagementReplayDigest'),('AuditPackageReplayCut','ExaminationEngagementReplayCut'),('AuditPackagePreparedCut','ExaminationEngagementPreparedCut')]:
 s=(pkg/(src+'.cs')).read_text().replace('Bdgrz.Compliance.Features.AuditPackages','Bdgrz.Compliance.Features.Examinations').replace('AuditPackageManifest','ExaminationEngagement').replace('AuditPackage','ExaminationEngagement').replace('audit-package','examination-engagement').replace('package source','engagement source')
 (core/(dst+'.cs')).write_text(s)
