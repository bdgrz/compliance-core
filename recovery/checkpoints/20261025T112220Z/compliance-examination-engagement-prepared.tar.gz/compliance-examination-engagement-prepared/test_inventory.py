from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-examination-engagement-prepared/work');p=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
for f in (r/'test').rglob('*.cs'):
 t=f.read_bytes();hits=[]
 for n in walk(p.parse(t).root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');txt=t[n.start_byte:n.end_byte].decode()
  if typ and t[typ.start_byte:typ.end_byte].decode() in {'ExaminationEngagement','ExaminationEngagementAggregate'}:
   hits.append((t[:n.start_byte].count(b'\n')+1,txt.replace('\n',' ')))
 if hits:print(str(f.relative_to(r)),hits)
