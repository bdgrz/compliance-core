from pathlib import Path
r=Path('/tmp/compliance-examination-engagement-prepared/work')
def edit(rel,fn):
 p=r/rel;s=p.read_text();p.write_text(fn(s))
def imports(s):
 for u in ['Bdgrz.Compliance.Features.Content','Bdgrz.Compliance.Features.NativeOperations','Bdgrz.Compliance.Tests.Testing','Cntryl.Fitz.Testing']:
  if 'using '+u+';' not in s:s='using '+u+';\n'+s
 return s
for name in ['ExaminationEngagementCommandHandlerTests','TypeIBaselineCommandHandlerTests','PreviewTypeIBaselineHandlerTests']:
 rel=f'test/Compliance.Tests/Features/Examinations/{name}.cs'
 def fn(s):
  s=imports(s)
  if 'public InMemoryEventStore Events' not in s:
   marker='        public IAggregateReader '+('AggregateReader' if name=='PreviewTypeIBaselineHandlerTests' else'Reader')+' { get; }'
   s=s.replace(marker,'        public InMemoryEventStore Events { get; } = new();\n        public IImmutableContentStore Content { get; } = new FitzKvImmutableContentStore(new InMemoryKvClient());\n'+marker)
   s=s.replace('services.AddSingleton<IEventStore>(new InMemoryEventStore());','services.AddSingleton<IEventStore>(Events);')
  reader='AggregateReader' if name=='PreviewTypeIBaselineHandlerTests' else'Reader'
  marker=f'        public IAggregateReader {reader} {{ get; }}'
  props=f'        public ExaminationEngagementReader Examinations => new({reader}, Events, Content);\n'
  if name!='PreviewTypeIBaselineHandlerTests':props+='        public ExaminationEngagementOperations Operations => new(new NativeOperationExecutor(Reader, Executor, Content),\n            Examinations, Content, Clock);\n'
  s=s.replace(marker,props+marker)
  s=s.replace('services.AddPortia();','services.AddPortia();\n            ExaminationSeeds.Configure(services, Events);')
  s=s.replace('new FitzExaminationEngagementDirectory(new InMemoryKvClient())','new FitzExaminationEngagementDirectory(new InMemoryKvClient(), Content)')
  s=s.replace('new(Reader, Executor, new ReadinessReader(Reader, Content, Events), Clock)','new(Operations, Reader, new ReadinessReader(Reader, Content, Events))').replace('new(Reader, Executor, Clock)','new(Operations, Reader)')
  s=s.replace('new PreviewTypeIBaselineHandler(AggregateReader, Directory, SourceReader)','new PreviewTypeIBaselineHandler(Examinations, Directory, SourceReader)')
  s=s.replace('new FreezeTypeIBaselineHandler(Reader, Executor, Directory, SourceReader,\n                Clock)','new FreezeTypeIBaselineHandler(Operations, Directory, SourceReader)').replace('new AmendTypeIBaselineHandler(Reader, Executor, Directory, SourceReader,\n                Clock)','new AmendTypeIBaselineHandler(Operations, Directory, SourceReader)')
  return s
 edit(rel,fn)
# Shared fixtures with existing event/content ports.
for rel,events,content,reader in [
 ('test/Compliance.Tests/Features/AuditPackages/CreateAuditPackageHandlerTests.cs','PeriodEvents','ContentStore','Reader'),
 ('test/Compliance.Tests/Features/AuditPackages/AmendAuditPackageHandlerTests.cs','PeriodEvents','ContentStore','Reader'),
 ('test/Compliance.Tests/Features/AuditPackages/SnapshotSourcePublicationTests.cs','PeriodEvents','Content','Reader'),
 ('test/Compliance.Tests/Features/Examinations/RecordManagementAssertionHandlerTests.cs','PeriodEvents','ContentStore','Reader'),
 ('test/Compliance.Tests/Features/SystemDescription/SystemDescriptionDraftCommandHandlerTests.cs','PeriodEvents','PeriodContent','Reader')]:
 def fn(s):
  marker=f'        public IAggregateReader {reader} {{ get; }}';s=s.replace(marker,f'        public ExaminationEngagementReader Examinations => new({reader}, {events}, {content});\n'+marker)
  if 'ExaminationSeeds.Configure' not in s:s=s.replace('services.AddPortia();',f'services.AddPortia();\n            ExaminationSeeds.Configure(services, {events});')
  return imports(s)
 edit(rel,fn)
rel='test/Compliance.Tests/Features/Operations/ProposeTypeIIOperatingPlanHandlerTests.cs'
def fn(s):
 s=s.replace('        public IAggregateReader Reader { get; }','        public InMemoryEventStore Events { get; } = new();\n        public IImmutableContentStore Content => scope.ServiceProvider.GetRequiredService<IImmutableContentStore>();\n        public ExaminationEngagementReader Examinations => new(Reader, Events, Content);\n        public IAggregateReader Reader { get; }').replace('var events = new InMemoryEventStore();','var events = Events;').replace('services.AddPortia();','services.AddPortia();\n            ExaminationSeeds.Configure(services, Events);')
 s=s.replace('new SystemDescriptionReader(Reader, events, scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()));','new SystemDescriptionReader(Reader, events, scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()), Examinations);')
 return imports(s)
edit(rel,fn)
rel='test/Compliance.Tests/Features/Operations/StartTypeIIObservationPeriodHandlerTests.cs';edit(rel,lambda s:s.replace('        public IAggregateReader Reader => Host.Reader;','        public ExaminationEngagementReader Examinations => new(Reader, Host.Events, Host.Content);\n        public IAggregateReader Reader => Host.Reader;'))
# Current source-builder calls now require the explicit verified examination reader.
for p in (r/'test').rglob('*.cs'):
 s=p.read_text().replace('new AuditPackageSourceBuilder(fixture.Reader,','new AuditPackageSourceBuilder(fixture.Examinations,').replace('new AuditPackageSourceBuilder(Reader,','new AuditPackageSourceBuilder(Examinations,')
 p.write_text(s)
# Correct missing proof namespace in the new fixture utility.
p=r/'test/Compliance.Tests/Testing/ExaminationSeeds.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.NativeOperations;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;');p.write_text(s)
