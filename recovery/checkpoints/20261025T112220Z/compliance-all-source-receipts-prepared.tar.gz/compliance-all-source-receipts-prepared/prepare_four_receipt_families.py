from pathlib import Path
root=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features/Examinations')
p=root/'ControlCriterionMappingTypeIBaselineSourceContributor.cs';s=p.read_text()
s=s.replace('using System.Security.Cryptography;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.SourceFacts;\nusing System.Security.Cryptography;')
a='''    public async ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(
        ExaminationEngagementView engagement, TypeIBaselineSourceReadContext context,
        CancellationToken ct)
    {'''
b='''    public async ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(
        ExaminationEngagementView engagement, TypeIBaselineSourceReadContext context,
        CancellationToken ct)
    {
        try
        {
            return await ReadCoreAsync(engagement, context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result<TypeIBaselineSourceContribution>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact mapping broker receipt source cannot be verified: " + exception.Message,
                isTransient: exception is ImmutableContentUnavailableException));
        }
    }

    async ValueTask<Result<TypeIBaselineSourceContribution>> ReadCoreAsync(
        ExaminationEngagementView engagement, TypeIBaselineSourceReadContext context, CancellationToken ct)
    {'''
assert a in s;s=s.replace(a,b)
s=s.replace('''        var editionSources = context.PreviouslyCapturedSources''','''        var receiptCut = context.RecordedThrough is null ? null : context.RequireReceipts(engagement.TenantId);
        var editionSources = context.PreviouslyCapturedSources''',1)
s=s.replace('''            var capturedVersions = new List<ControlCriterionMappingVersionView>();''','''            var receiptStream = receiptCut is null ? null : await receiptCut.ReadAsync(new ControlCriterionMapping(
                engagement.TenantId, engagement.ProgramId, mapping.ControlId, mapping.EditionId,
                mapping.CriterionIdentifier).Stream, ct).ConfigureAwait(false);
            var capturedVersions = new List<ControlCriterionMappingVersionView>();''')
s=s.replace('''                if (version.ProposedAt > through)
                    continue;
                if (!TryAsOfVersion(mapping, index, through, out var asOfVersion))''','''                if (receiptStream is null ? version.ProposedAt > through : !ProposalIncluded(receiptStream, version))
                    continue;
                if (!TryAsOfVersion(mapping, index, through, out var asOfVersion, receiptStream))''')
s=s.replace('''        DateTimeOffset through, out ControlCriterionMappingVersionView asOf)
    {''','''        DateTimeOffset through, out ControlCriterionMappingVersionView asOf, RecordedSourceReceiptStream? receipts = null)
    {''')
s=s.replace('''var reviewed = version.ReviewedAt is { } reviewedAt && reviewedAt <= through;''','''var reviewed = receipts is null ? version.ReviewedAt is { } reviewedAt && reviewedAt <= through
            : ReviewIncluded(receipts, version);''')
s=s.replace('''var retired = accepted && version.RetiredAt is { } retiredAt && retiredAt <= through;''','''var retired = accepted && (receipts is null ? version.RetiredAt is { } retiredAt && retiredAt <= through
            : version.RetiredAt is not null && receipts.Includes(fact => fact is ControlCriterionMappingRetired retiredFact &&
                retiredFact.MappingId == version.MappingId && retiredFact.VersionNumber == version.VersionNumber));''')
s=s.replace('''                if (candidate.ReviewedAt is { } candidateReviewedAt &&
                    candidateReviewedAt <= through &&
                    candidate.Status is ("accepted" or "superseded" or "retired"))''','''                if ((receipts is null ? candidate.ReviewedAt is { } candidateReviewedAt && candidateReviewedAt <= through
                        : ReviewIncluded(receipts, candidate)) &&
                    candidate.Status is ("accepted" or "superseded" or "retired"))''')
s=s.replace('''    static string Digest(ControlCriterionMappingView mapping,''','''    static bool ProposalIncluded(RecordedSourceReceiptStream receipts, ControlCriterionMappingVersionView version) =>
        receipts.Includes(fact => fact is ControlCriterionMappingProposed proposed &&
            proposed.MappingId == version.MappingId && proposed.VersionNumber == version.VersionNumber &&
            proposed.ControlVersionId == version.ControlVersionId);

    static bool ReviewIncluded(RecordedSourceReceiptStream receipts, ControlCriterionMappingVersionView version) =>
        version.ReviewDecisionId is { } decision && receipts.Includes(fact => fact is ControlCriterionMappingReviewed reviewed &&
            reviewed.MappingId == version.MappingId && reviewed.VersionNumber == version.VersionNumber && reviewed.DecisionId == decision);

    static string Digest(ControlCriterionMappingView mapping,''')
p.write_text(s)
print('Prepared mapping receipt-bound proposal/review/retirement/successor selection; nullcut retained.')
