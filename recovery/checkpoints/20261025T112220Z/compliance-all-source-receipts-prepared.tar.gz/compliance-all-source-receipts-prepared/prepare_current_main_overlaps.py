from pathlib import Path
import shutil,re
R=Path('/tmp/compliance-all-source-receipts-prepared');M=Path('/Users/jrepanich/Code/bdgrz/compliance-core');D=R/'current-main-overlaps'
paths=['src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs','src/Compliance.Core/Features/Operations/TypeIIPeriodCloseMaterialReader.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.NativeOwners.cs','test/Compliance.Tests/Features/Operations/ObservationPeriodReadHandlerTests.cs']
for rel in paths:
 for folder in ['base','work']:
  p=D/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(M/rel,p)
p=D/'work'/paths[0];s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
for n in ['ReadDraftHistoryAsync','ReadEvaluationHistoryAsync','ReadMethodHistoryAsync','ReadGovernanceHistoryAsync']:
 s=re.sub(r'\b'+n+r'\(',n+'(context, ',s)
 s=re.sub(r'(\b'+n+r'\()context,\s+(?=Uuid\s)',r'\1TypeIBaselineSourceReadContext context, ',s)
s=s.replace('priorRecordedAt is { } prior && metadata.OccurredOn < prior','context.RecordedThrough is null && priorRecordedAt is { } prior && metadata.OccurredOn < prior')
s=s.replace('occurredAt <= through && metadata.OccurredOn <= through','context.RecordedThrough is null ? occurredAt <= through && metadata.OccurredOn <= through :\n                await context.IncludesAsync(record.Stream, record.Event, ct).ConfigureAwait(false)')
s=s.replace('content, through, ct)','content, through, context, ct)')
s=s.replace('IImmutableContentStore content, DateTimeOffset through, CancellationToken ct)','IImmutableContentStore content, DateTimeOffset through, TypeIBaselineSourceReadContext context, CancellationToken ct)')
s=s.replace('native.Operation.AcceptedAt <= through && metadata.OccurredOn <= through','context.RecordedThrough is null ? native.Operation.AcceptedAt <= through && metadata.OccurredOn <= through :\n                    await context.IncludesAsync(stream, fact, ct).ConfigureAwait(false)')
p.write_text(s)
p=D/'work'/paths[1];s=p.read_text();s=s.replace('IImmutableContentStore content)','IImmutableContentStore content, RecordedSourceReceiptCutFactory receiptCuts)',1)
# Exact ScanAsync receipt implementation is independent of the queued SD consumer migration.
future=(R/'work'/paths[1]).read_text();a=future.index('    async Task<IReadOnlyList<TypeIIPeriodCloseNativeSource>> ScanAsync(');b=future.index('    static bool ReferencesClose',a)
a0=s.index('    async Task<IReadOnlyList<TypeIIPeriodCloseNativeSource>> ScanAsync(');b0=s.index('    static bool ReferencesClose',a0);s=s[:a0]+future[a:b]+s[b0:];p.write_text(s)
for rel in paths[2:]:
 p=D/'work'/rel;s=p.read_text()
 if 'using Bdgrz.Compliance.Features.SourceFacts;' not in s:s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
 if 'NativeOwners' in rel:
  if 'using Microsoft.Extensions.DependencyInjection;' not in s:s='using Microsoft.Extensions.DependencyInjection;\n'+s
  s=s.replace('new TypeIIPeriodCloseMaterialReader(fixture.Events, fixture.Host.Content)','new TypeIIPeriodCloseMaterialReader(fixture.Events, fixture.Host.Content,\n                new RecordedSourceReceiptCutFactory(fixture.Events, fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>()))')
 else:
  s=s.replace('public InMemoryEventStore Events { get; } = new();','public InMemoryEventStore Events { get; } = new();\n        public ReceiptTrackingEventStore Receipts { get; }')
  s=s.replace('''            services.AddSingleton<IEventStore>(Events);''','''            Receipts = new ReceiptTrackingEventStore(Events, new ReceiptClock());
            services.AddSingleton<IEventStore>(Receipts);''')
  s=s.replace('new TypeIIPeriodCloseMaterialReader(Events, Content)','new TypeIIPeriodCloseMaterialReader(Events, Content, new RecordedSourceReceiptCutFactory(Events, Receipts))')
  s=s.replace('''        public async ValueTask DisposeAsync()
        {''','''        sealed class ReceiptClock : TimeProvider
        {
            public override DateTimeOffset GetUtcNow() => Now;
        }
        public async ValueTask DisposeAsync()
        {''')
 p.write_text(s)
