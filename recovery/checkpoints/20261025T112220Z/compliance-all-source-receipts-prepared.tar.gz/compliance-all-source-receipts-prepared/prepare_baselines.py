from pathlib import Path
import shutil,json,hashlib
P=Path('/tmp/compliance-all-source-receipts-prepared');R=Path('/Users/jrepanich/Code/bdgrz/compliance-core');SD=Path('/tmp/compliance-system-description-prepared/work');RC=Path('/tmp/compliance-native-receipts-prepared/work');RISK=Path('/tmp/compliance-risk-native-prepared/work')
source=[p for p in (R/'src/Compliance.Core/Features/Examinations').glob('*.cs') if ('TypeIBaselineSourceContributor' in p.name or p.name in ['CommitmentTypeIBaselineSourceReader.cs','TypeIBaselineSourceReadContext.cs','TypeIBaselinePreviewReader.cs','PublishedTypeIBaselinePreviewReader.cs'])]
paths={str(p.relative_to(R)) for p in source};paths|={'src/Compliance.Core/Features/Evaluations/ControlEvaluationReader.cs','src/Compliance.Core/Features/Operations/TypeIIPeriodCloseMaterialReader.cs'}
rows=[]
for rel in sorted(paths):
 # Risk native owner is actively prepared: snapshot its latest source where complete, do not edit sibling artifact.
 roots=[SD,RISK,R] if 'RiskTypeIBaselineSourceContributor.cs' in rel else [SD,R]
 source=next(root/rel for root in roots if (root/rel).exists())
 for folder in ['base','work']:
  p=P/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,p)
 rows.append({'path':rel,'baselineSource':str(source),'beforeSha256':hashlib.sha256(source.read_bytes()).hexdigest()})
(P/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows),'source baselines captured')
