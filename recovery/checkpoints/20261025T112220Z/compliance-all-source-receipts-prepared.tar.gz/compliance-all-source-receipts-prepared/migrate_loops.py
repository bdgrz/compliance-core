from pathlib import Path
import re
R=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features')
def read(n):return (R/'Examinations'/n).read_text()
def save(n,s):
 if 'using Bdgrz.Compliance.Features.SourceFacts;' not in s:s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
 (R/'Examinations'/n).write_text(s)
def plumb(s,names):
 # Add context to selected method invocations/declarations as first argument. multiline generic methods are intentionally matched by exact name+paren.
 for name in names:
  s=re.sub(r'\b'+name+r'\(',name+'(context, ',s)
  # definitions begin returntype Name(context, type...)
  s=re.sub(r'(\b'+name+r'\()context, (?=(?:Uuid|EventStreamAddress|ExaminationEngagementView|List<|DateTimeOffset))',r'\1TypeIBaselineSourceReadContext context, ',s)
 return s
n='BoundaryTypeIBaselineSourceContributor.cs';s=read(n).replace('Boundary.Area','SystemBoundary.Area');save(n,s)
n='WorkforceTypeIBaselineSourceContributor.cs';s=read(n).replace('PopulationSnapshot.Area','"population-snapshots"');save(n,s)
n='AccessExpectationsTypeIBaselineSourceContributor.cs';s=plumb(read(n),['ReadHistoryAsync','ReadLineAsync','ReadPopulationExceptionAsync'])
s=s.replace('priorRecordedAt is { } earlierRecord && metadata.OccurredOn < earlierRecord','context.RecordedThrough is null && priorRecordedAt is { } earlierRecord && metadata.OccurredOn < earlierRecord')
s=s.replace('occurredAt <= through && metadata.OccurredOn <= through','context.RecordedThrough is null ? occurredAt <= through && metadata.OccurredOn <= through :\n                        await context.IncludesAsync(record.Stream, record.Event, ct).ConfigureAwait(false)')
s=s.replace('exception.ApprovedAt <= through && metadata.OccurredOn <= through','context.RecordedThrough is null ? exception.ApprovedAt <= through && metadata.OccurredOn <= through :\n                await context.IncludesAsync(record.Stream, record.Event, ct).ConfigureAwait(false)')
save(n,s)
n='ProviderTypeIBaselineSourceContributor.cs';s=plumb(read(n),['ReadProviderHistoryAsync','ReadAssuranceHistoryAsync'])
# actual provider method name differs? ReadProviderHistoryAsync below expected signatures asserted later
s=s.replace('priorAt.TryGetValue(record.Stream, out var prior) && metadata.OccurredOn < prior','context.RecordedThrough is null && priorAt.TryGetValue(record.Stream, out var prior) && metadata.OccurredOn < prior')
s=s.replace('occurred.TryGetValue(stream, out var prior) && metadata.OccurredOn < prior','context.RecordedThrough is null && occurred.TryGetValue(stream, out var prior) && metadata.OccurredOn < prior')
for old in ['recordedAt <= through && metadata.OccurredOn <= through','fact.RecordedAt <= through && metadata.OccurredOn <= through']:
 s=s.replace(old,'context.RecordedThrough is null ? '+old+' :\n                await context.IncludesAsync(record.Stream, record.Event, ct).ConfigureAwait(false)')
save(n,s)
n='FindingTypeIBaselineSourceContributor.cs';s=read(n)
s=s.replace('if (!InsideCutoff(fact, through))','if (!(context.RecordedThrough is null ? InsideCutoff(fact, through) :\n                    await context.IncludesAsync(finding.Stream, fact, ct).ConfigureAwait(false)))')
s=s.replace('if (!InsideCutoff(admitted, through))','if (!(context.RecordedThrough is null ? InsideCutoff(admitted, through) :\n                    await context.IncludesAsync(finding.Stream, admitted, ct).ConfigureAwait(false)))')
s=s.replace('''                foreach (var fact in ActionFacts(action).Where(fact => InsideCutoff(fact, through)))
                    history.Add(Capture(fact));''','''                foreach (var fact in ActionFacts(action))
                    if (context.RecordedThrough is null ? InsideCutoff(fact, through) :
                        await context.IncludesAsync(action.Stream, fact, ct).ConfigureAwait(false))
                        history.Add(Capture(fact));''')
save(n,s)
