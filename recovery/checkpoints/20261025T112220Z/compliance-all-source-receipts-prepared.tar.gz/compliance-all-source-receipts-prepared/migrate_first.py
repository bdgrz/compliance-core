from pathlib import Path
R=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features')
def edit(rel,fn):
 p=R/rel;s=p.read_text();p.write_text(fn(s))
def imp(s):return 'using Bdgrz.Compliance.Features.SourceFacts;\n'+s if 'using Bdgrz.Compliance.Features.SourceFacts;' not in s else s
edit('Examinations/TypeIBaselineSourceReadContext.cs',lambda s:s.replace('RequireReceipts(Uuid.Parse(stream.Realm,System.Globalization.CultureInfo.InvariantCulture)).IncludesAsync(stream,fact,ct)', 'RequireReceipts(ReceiptCut?.TenantId ?? Uuid.Empty).IncludesAsync(stream,fact,ct)'))
# Simple exact approval gates retain effective/current selections and typed source validation.
edit('Examinations/ControlTypeIBaselineSourceContributor.cs',lambda s:imp(s).replace('if (context.RecordedThrough is { } cutoff && version.ApprovedAt > cutoff)', '''if (context.RecordedThrough is not null && !(await context.RequireReceipts(engagement.TenantId)
                        .ReadAsync(new EventStreamAddress(engagement.TenantId.ToString(), ControlDraft.Area, control.Id.ToString()), ct)
                        .ConfigureAwait(false)).Includes(fact => fact is ControlApproved approved && approved.ChangeCount > 0 &&
                            approved.VersionId == version.VersionId && approved.ApprovalDecisionId == version.ApprovalDecisionId))'''))
edit('Examinations/BoundaryTypeIBaselineSourceContributor.cs',lambda s:imp(s).replace('if (context.RecordedThrough is { } cutoff && version.ChangedAt > cutoff)', '''if (context.RecordedThrough is not null && !(await context.RequireReceipts(engagement.TenantId)
                        .ReadAsync(new EventStreamAddress(engagement.TenantId.ToString(), Boundary.Area, version.BoundaryId.ToString()), ct)
                        .ConfigureAwait(false)).Includes(fact => fact is BoundaryApproved approved && approved.ChangeCount > 0 &&
                            approved.DraftVersionId == version.VersionId && approved.Revision == version.Revision))'''))
# Workforce uses actual freeze marker; source full row verification stays below unchanged.
def workforce(s):
 s=imp(s).replace('''    public async ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(
        ExaminationEngagementView engagement, CancellationToken ct)
    {''','''    public ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(
        ExaminationEngagementView engagement, CancellationToken ct) =>
        ReadAsync(engagement, new TypeIBaselineSourceReadContext(Uuid.Empty, []), ct);

    public async ValueTask<Result<TypeIBaselineSourceContribution>> ReadAsync(
        ExaminationEngagementView engagement, TypeIBaselineSourceReadContext context, CancellationToken ct)
    {''')
 s=s.replace('if (item.FrozenAt <= through)','''if (item.FrozenAt <= through && (context.RecordedThrough is null ||
                    (await context.RequireReceipts(engagement.TenantId).ReadAsync(new EventStreamAddress(
                        engagement.TenantId.ToString(), PopulationSnapshot.Area, item.SnapshotId.ToString()), ct)
                        .ConfigureAwait(false)).Includes(fact => fact is PopulationSnapshotFrozen frozen &&
                            frozen.SnapshotId == item.SnapshotId && frozen.ContentSha256 == item.ContentSha256)))''')
 return s
edit('Examinations/WorkforceTypeIBaselineSourceContributor.cs',workforce)
# ReviewedSystem preserves actual source fact in private read composition, never source digest DTO.
def reviewed(s):
 s=imp(s).replace('history.Add(state);','history.Add(state with { Source = record });')
 s=s.replace('var declarations = new List<SystemInstanceDeclared>();','var declarations = new List<SystemInstanceDeclared>();\n        DomainEventRecord? declarationSource = null;')
 s=s.replace('''                declarations.Add(candidate);''','''            {
                declarations.Add(candidate);
                declarationSource = record;
            }''')
 s=s.replace('declaration.ApplicationRevision)]);','declaration.ApplicationRevision) { Source = declarationSource }]);')
 s=s.replace('long? LegacyApplicationRevision = null);','long? LegacyApplicationRevision = null)\n    {\n        public DomainEventRecord? Source { get; init; }\n    }')
 old='''            var systemVersion = history.Value.Where(state =>
                    state.ChangeKind != "retired" && state.ChangedAt <= through)'''
 if old not in s:
  # variable is selectedSystemVersion etc
  import re
  m=re.search(r'            var (\w+) = history.Value.Where\(state =>\n                    state.ChangeKind != "retired" && state.ChangedAt <= through\)',s)
  assert m,m
  old=m.group(0)
  prefix='''            var eligibleHistory = new List<ReviewedSystemState>();
            foreach (var state in history.Value)
                if (context.RecordedThrough is null ? state.ChangedAt <= through :
                    state.Source is { } source && await context.IncludesAsync(source.Stream, source.Event, ct).ConfigureAwait(false))
                    eligibleHistory.Add(state);
'''
  s=s.replace(old,prefix+old.replace('history.Value.Where(state =>','eligibleHistory.Where(state =>').replace(' && state.ChangedAt <= through',''))
 else:
  raise RuntimeError('unexpected var')
 s=s.replace('retirement.ChangedAt > through && retirement.EffectiveAt > effectiveThrough','!eligibleHistory.Contains(retirement) && retirement.EffectiveAt > effectiveThrough')
 # retroactive source emitted late must fail closed for a close, rather than leak post-cut retirement
 anchor='''            if (retirement is null || !eligibleHistory.Contains(retirement) && retirement.EffectiveAt > effectiveThrough)'''
 s=s.replace(anchor,'''            if (context.RecordedThrough is not null && retirement is not null &&
                !eligibleHistory.Contains(retirement) && retirement.EffectiveAt <= effectiveThrough)
                return SourceConflict();
'''+anchor)
 s=s.replace('else if (retirement.ChangedAt > through)','else if (!eligibleHistory.Contains(retirement))')
 return s
edit('Examinations/ReviewedSystemTypeIBaselineSourceContributor.cs',reviewed)
