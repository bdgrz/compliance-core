from pathlib import Path
R=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features')
def edit(rel,fn):
 p=R/rel;p.write_text(fn(p.read_text()))
def policy(s):
 s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
 anchor='''                var eligibleVersions = versions.Where(version => version.ApprovedAt <= through &&'''
 s=s.replace(anchor,'''                var receiptStream = context.RecordedThrough is null ? null :
                    await context.RequireReceipts(engagement.TenantId).ReadAsync(new EventStreamAddress(
                        engagement.TenantId.ToString(), Policy.Area, policy.Id.ToString()), ct).ConfigureAwait(false);
                bool DecisionRecorded(PolicyDecisionView decision) => receiptStream is null ? decision.DecidedAt <= through :
                    DecisionIncluded(receiptStream, decision.DecisionId);
                bool VersionRecorded(PolicyVersionView version) => receiptStream is null ? version.ApprovedAt <= through :
                    DecisionIncluded(receiptStream, version.ApprovalDecisionId);
                var eligibleVersions = versions.Where(version => VersionRecorded(version) &&''')
 # limit first ReadCore region before static ReferencesAsOf
 a,b=s.split('    internal static IReadOnlyList<TypeIBaselineSourceReference> ReferencesAsOf',1)
 a=a.replace('decision.DecidedAt <= through','DecisionRecorded(decision)')
 # replacement also replaced localfunc condition; restore exact
 a=a.replace('receiptStream is null ? DecisionRecorded(decision) :','receiptStream is null ? decision.DecidedAt <= through :')
 a=a.replace('versions.Any(version => version.ApprovedAt <= through)','versions.Any(VersionRecorded)')
 s=a+'    internal static IReadOnlyList<TypeIBaselineSourceReference> ReferencesAsOf'+b
 # overload optional selector preserves existing internal callers until migrated by peer.
 s=s.replace('PolicyReadSnapshot policy, DateOnly periodStart, DateTimeOffset through, out bool valid)','PolicyReadSnapshot policy, DateOnly periodStart, DateTimeOffset through, out bool valid, RecordedSourceReceiptStream? receipts = null)')
 a,b=s.split('    internal static IReadOnlyList<TypeIBaselineSourceReference> ReferencesAsOf',1)
 b=b.replace('version.ApprovedAt <= through &&','(receipts is null ? version.ApprovedAt <= through : DecisionIncluded(receipts, version.ApprovalDecisionId)) &&',1)
 # onlyReferences region beforevalidationhelper
 c,d=b.split('    static bool IsValidHistory',1)
 c=c.replace('decision.DecidedAt <= through','(receipts is null ? decision.DecidedAt <= through : DecisionIncluded(receipts, decision.DecisionId))')
 b=c+'''    internal static bool DecisionIncluded(RecordedSourceReceiptStream receipts, Uuid decisionId) =>
        receipts.Includes(fact => fact switch
        {
            PolicyReviewed review => review.DecisionId == decisionId,
            PolicyApproved approval => approval.DecisionId == decisionId,
            PolicyRetired retirement => retirement.DecisionId == decisionId,
            PolicyPeriodicReviewConfirmed periodic => periodic.DecisionId == decisionId,
            _ => false,
        });

    static bool IsValidHistory'''+d
 return a+'    internal static IReadOnlyList<TypeIBaselineSourceReference> ReferencesAsOf'+b
edit('Examinations/PolicyTypeIBaselineSourceContributor.cs',policy)
def evalreader(s):
 s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
 s=s.replace('Uuid tenantId, Uuid programId, DateTimeOffset? through, CancellationToken ct = default)','Uuid tenantId, Uuid programId, DateTimeOffset? through, CancellationToken ct = default, RecordedSourceReceiptCut? receiptCut = null)')
 s=s.replace('''            if (through is { } limit && record.Event.Metadata.OccurredOn > limit)
                continue;''','''            if (receiptCut is not null)
            {
                if (receiptCut.TenantId != tenantId || receiptCut.RecordedThrough != through)
                    throw new ImmutableContentIntegrityException("The evaluation receipt selection has another exact scope or cutoff.");
                if (!await receiptCut.IncludesAsync(record, ct).ConfigureAwait(false))
                    continue;
            }
            else if (through is { } limit && record.Event.Metadata.OccurredOn > limit)
                continue;''')
 return s
edit('Evaluations/ControlEvaluationReader.cs',evalreader)
def evalcontributor(s):
 s=s.replace('''        var firstRead = await evaluations.ReadStatesAsync(engagement.TenantId, engagement.ProgramId, through, ct)''','''        var receiptCut = context.RecordedThrough is null ? null : context.RequireReceipts(engagement.TenantId);
        var firstRead = await evaluations.ReadStatesAsync(engagement.TenantId, engagement.ProgramId, through, ct, receiptCut)''')
 s=s.replace('evaluations.ReadStatesAsync(engagement.TenantId, engagement.ProgramId, through, ct)','evaluations.ReadStatesAsync(engagement.TenantId, engagement.ProgramId, through, ct, receiptCut)')
 s=s.replace('!IsValid(state, through)','!IsValid(state, context.RecordedThrough is null ? through : DateTimeOffset.MaxValue)')
 return s
edit('Examinations/ControlEvaluationTypeIBaselineSourceContributor.cs',evalcontributor)
