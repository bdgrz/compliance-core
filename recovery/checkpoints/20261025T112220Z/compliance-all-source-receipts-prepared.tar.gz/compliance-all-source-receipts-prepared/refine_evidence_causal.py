exec(open('/tmp/compliance-all-source-receipts-prepared/prepare_tests.py').read().split('for rel in [')[0])
p=D/'work/src/Compliance.Core/Features/Examinations/EvidenceGovernanceTypeIBaselineSourceContributor.cs';s=p.read_text();s=s.replace('''                artifactGroup.Key, through, ct).ConfigureAwait(false);''','''                artifactGroup.Key, through, artifact.Value.AsOfRevision, ct).ConfigureAwait(false);''')
s=s.replace('''    async ValueTask<Result<RetentionAsOf>> ReadRetentionAsOfAsync(TypeIBaselineSourceReadContext context, Uuid tenantId, Uuid artifactId,
        DateTimeOffset through, CancellationToken ct)''','''    async ValueTask<Result<RetentionAsOf>> ReadRetentionAsOfAsync(TypeIBaselineSourceReadContext context, Uuid tenantId, Uuid artifactId,
        DateTimeOffset through, long artifactRevision, CancellationToken ct)''')
s=s.replace('''        var selectedHolds = new List<ArtifactLegalHoldView>();''','''        if (context.RecordedThrough is not null && basis is not null && basis.SourcePosition > (ulong)artifactRevision)
            return InvalidHistory<RetentionAsOf>();
        var selectedHolds = new List<ArtifactLegalHoldView>();''')
s=s.replace('''            selectedHolds.Add(owner.Release is { } release &&
                !await context.IncludesAsync(owner.Stream, release, ct).ConfigureAwait(false) ?
                hold with { ReleaseReason = null, ReleasedBy = null, ReleasedAt = null } : hold);''','''            if (owner.Placement.SourcePosition > (ulong)artifactRevision)
                return InvalidHistory<RetentionAsOf>();
            var released = owner.Release is { } release &&
                await context.IncludesAsync(owner.Stream, release, ct).ConfigureAwait(false);
            if (released && owner.Release!.SourcePosition > (ulong)artifactRevision)
                return InvalidHistory<RetentionAsOf>();
            selectedHolds.Add(released ? hold : hold with { ReleaseReason = null, ReleasedBy = null, ReleasedAt = null });''')
p.write_text(s)
p=capture('test/Compliance.Tests/Features/Examinations/EvidenceGovernanceTypeIBaselineSourceContributorTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
s=s.replace('bool includeFutureHandlingPolicy = false)','bool includeFutureHandlingPolicy = false, bool lateArtifactReceipt = false)')
s=s.replace('''        return new FixtureState(contributor, new TypeIBaselineSourceReadContext(MemberId,
            [effectiveControlVersion]));''','''        var context = new TypeIBaselineSourceReadContext(MemberId, [effectiveControlVersion]);
        if (lateArtifactReceipt)
        {
            var cutoff = AfterTypeIDate.AddDays(3);
            var receipts = new ScriptedNativeEventReceipts();
            await foreach (var record in store.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString()), EventCursor.Start, CancellationToken.None))
                receipts.Record(record, record.Event is EvidenceArtifactDownloadIssued ? cutoff.AddMilliseconds(1) : cutoff.AddMilliseconds(-1));
            context = context with { RecordedThrough = cutoff,
                ReceiptCut = new RecordedSourceReceiptCutFactory(store, receipts).Create(TenantId, cutoff) };
        }
        return new FixtureState(contributor, context);''')
if 'using Bdgrz.Compliance.Tests.Testing;' not in s:s='using Bdgrz.Compliance.Tests.Testing;\n'+s
anchor='    static async Task<FixtureState> Fixture('
s=s.replace(anchor,'''    [Fact]
    public async Task ShouldRefuseHandlingPolicyGivenReferencedArtifactHeadCommitsAfterReceiptCut()
    {
        // Arrange
        var fixture = await Fixture(includeLaterLink: false, includeFutureHandlingPolicy: true, lateArtifactReceipt: true);

        // Act
        var result = await fixture.Contributor.ReadAsync(Engagement(), fixture.Context, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error.Kind);
        Assert.False(result.Error.IsTransient);
    }

'''+anchor)
p.write_text(s)
