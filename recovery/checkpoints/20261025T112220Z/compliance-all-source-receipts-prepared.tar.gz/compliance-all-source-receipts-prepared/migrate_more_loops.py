exec(open('/tmp/compliance-all-source-receipts-prepared/migrate_loops.py').read().split("n='BoundaryTypeIBaseline")[0])
n='AccessReviewCampaignsTypeIBaselineSourceContributor.cs';s=plumb(read(n),['ReadHistoryAsync','ReadHistoryCoreAsync','ReplayItemAsync'])
s=re.sub(r'(\w+Async\()context,\s+(?=(?:Uuid|EventStreamAddress)\s)',r'\1TypeIBaselineSourceReadContext context, ',s)
s=s.replace('priorRecordedAt is { } earlierRecord && metadata.OccurredOn < earlierRecord','context.RecordedThrough is null && priorRecordedAt is { } earlierRecord && metadata.OccurredOn < earlierRecord')
# compute once per event after its full native identity check; exact per-resource selector also validates causal prefix.
s=s.replace('''            switch (domainEvent)
            {''','''            var receiptIncluded = context.RecordedThrough is null ? (bool?)null :
                await context.IncludesAsync(record.Stream, domainEvent, ct).ConfigureAwait(false);
            switch (domainEvent)
            {''',1)
s=s.replace('''                priorRecordedAt = metadata.OccurredOn;
                expectedVersion++;''','''                var receiptIncluded = context.RecordedThrough is null ? (bool?)null :
                    await context.IncludesAsync(record.Stream, domainEvent, ct).ConfigureAwait(false);
                priorRecordedAt = metadata.OccurredOn;
                expectedVersion++;''',1)
# Only Include calls terminate through); or through); multiline; changed method def handled separately.
s=s.replace('                        through);','                        through, receiptIncluded);').replace('), through);','), through, receiptIncluded);').replace('stream, payload, through);','stream, payload, through, receiptIncluded);')
s=s.replace('EventStreamAddress stream, JsonElement payload, DateTimeOffset through)','EventStreamAddress stream, JsonElement payload, DateTimeOffset through, bool? receiptIncluded)')
s=s.replace('if (at <= through && metadata.OccurredOn <= through)','if (receiptIncluded ?? (at <= through && metadata.OccurredOn <= through))')
s=s.replace('''        catch (ImmutableContentIntegrityException)
        {
            return InvalidHistory();
        }''','''        catch (ImmutableContentUnavailableException)
        {
            return Result<AccessReviewCampaignHistory>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact access review source receipt or content is not available yet.", true));
        }
        catch (ImmutableContentIntegrityException)
        {
            return InvalidHistory();
        }''',1)
save(n,s)
# Risk methods all operate through existing exact source reads; nullable cut uses shared verified receipt authority.
n='RiskTypeIBaselineSourceContributor.cs';s=read(n)
methods=['ReadDraftHistoryAsync','ReadEvaluationHistoryAsync','ReadMethodologyHistoryAsync','ReadGovernanceHistoryAsync']
# discover actual names from signatures manually whitelist via known call patterns below
names=re.findall(r'async ValueTask<[^\n]+>\s+(\w+)\(',s)
print('riskmethods',names)
# Methods carrying through receive context; ReadDirectory/readonly date semantic functions remain unchanged.
for name in names:
 pat=re.search(r'\b'+name+r'\([^\{]+\)\s*\{',s)
 if pat and 'DateTimeOffset through' in pat.group(0) and name!='CaptureAsync':methods.append(name)
methods=list(dict.fromkeys(methods))
s=plumb(s,methods)
s=re.sub(r'(\w+Async\()context,\s+(?=(?:Uuid|EventStreamAddress|ExaminationEngagementView)\s)',r'\1TypeIBaselineSourceReadContext context, ',s)
s=s.replace('priorRecordedAt is { } prior && metadata.OccurredOn < prior','context.RecordedThrough is null && priorRecordedAt is { } prior && metadata.OccurredOn < prior')
for old in ['version.ChangedAt <= through && metadata.OccurredOn <= through','occurredAt <= through && metadata.OccurredOn <= through']:
 s=s.replace(old,'context.RecordedThrough is null ? '+old+' :\n                    await context.IncludesAsync(record.Stream, record.Event, ct).ConfigureAwait(false)')
s=s.replace('content, through, ct)','content, through, context, ct)')
s=s.replace('IImmutableContentStore content, DateTimeOffset through, CancellationToken ct)','IImmutableContentStore content, DateTimeOffset through, TypeIBaselineSourceReadContext context, CancellationToken ct)')
s=s.replace('native.Operation.AcceptedAt <= through && metadata.OccurredOn <= through','context.RecordedThrough is null ? native.Operation.AcceptedAt <= through && metadata.OccurredOn <= through :\n                    await context.IncludesAsync(stream, fact, ct).ConfigureAwait(false)')
save(n,s)
