from pathlib import Path
P=Path('/tmp/compliance-all-source-receipts-prepared/work');S='src/Compliance.Core/Features/SourceFacts/';E='src/Compliance.Core/Features/Examinations/'
def put(rel,s):p=P/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(S+'RecordedSourceReceiptCutFactory.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceFacts;

/// <summary>Creates one immutable request-relative broker receipt selection shared by all closing source families.</summary>
public sealed class RecordedSourceReceiptCutFactory(IDomainEventReader events,INativeEventReceiptReader receipts)
{
    public RecordedSourceReceiptCut Create(Uuid tenant,DateTimeOffset through) => new(tenant,through,events,receipts);
}
''')
put(S+'RecordedSourceReceiptCut.cs','''using System.Collections.Concurrent;
using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceFacts;

/// <summary>Verified inclusive broker-millisecond prefix selection; payload occurrence/preparation time never supplies receipt authority.</summary>
public sealed class RecordedSourceReceiptCut(Uuid tenant,DateTimeOffset through,IDomainEventReader events,INativeEventReceiptReader receipts)
{
    readonly ConcurrentDictionary<EventStreamAddress,Lazy<Task<RecordedSourceReceiptStream>>> _streams = new();
    public Uuid TenantId { get; } = tenant;
    public DateTimeOffset RecordedThrough { get; } = through;
    public Task<RecordedSourceReceiptStream> ReadAsync(EventStreamAddress stream,CancellationToken ct = default)
    {
        if (stream.Realm != TenantId.ToString())
            throw new ImmutableContentIntegrityException("The receipt selection belongs to another exact tenant scope.");
        return _streams.GetOrAdd(stream,key => new(() => CaptureAsync(key,ct))).Value;
    }
    public async ValueTask<bool> IncludesAsync(DomainEventRecord source,CancellationToken ct = default) =>
        (await ReadAsync(source.Stream,ct).ConfigureAwait(false)).Includes(source.Event);
    public async ValueTask<bool> IncludesAsync(EventStreamAddress stream,DomainEvent source,CancellationToken ct = default) =>
        (await ReadAsync(stream,ct).ConfigureAwait(false)).Includes(source);
    async Task<RecordedSourceReceiptStream> CaptureAsync(EventStreamAddress stream,CancellationToken ct)
    {
        var all = new List<DomainEventRecord>();var included = new HashSet<Uuid>();var excluded = false;var position = 0UL;
        var ids = new HashSet<Uuid>();
        await foreach (var record in events.ReadAsync(stream,0,ct).ConfigureAwait(false))
        {
            if (record.Stream != stream || record.ResourceOffset != position++)
                throw new ImmutableContentIntegrityException("The receipt source stream has a foreign record or physical gap.");
            var metadata = record.Event.Metadata;
            if (metadata.IsAudit) continue;
            if (metadata.EventId == Uuid.Empty || metadata.AggregateVersion == 0 || !ids.Add(metadata.EventId))
                throw new ImmutableContentIntegrityException("The receipt source stream lacks unique committed native identity.");
            var at = await receipts.RecordedAtAsync(record,ct).ConfigureAwait(false);
            all.Add(record);
            if (at > RecordedThrough) { excluded = true;continue; }
            if (excluded)
                throw new ImmutableContentIntegrityException("The broker receipt cutoff does not select a complete causal prefix of its source stream.");
            included.Add(metadata.EventId);
        }
        return new(stream,all.AsReadOnly(),included);
    }
}
''')
put(S+'RecordedSourceReceiptStream.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SourceFacts;

/// <summary>One exact captured native stream and its verified receipt prefix, independent of mutable source presentation.</summary>
public sealed class RecordedSourceReceiptStream(EventStreamAddress stream,IReadOnlyList<DomainEventRecord> records,IReadOnlySet<Uuid> included)
{
    public EventStreamAddress Stream { get; } = stream;
    public IReadOnlyList<DomainEventRecord> Records { get; } = records;
    public IEnumerable<DomainEventRecord> Included => Records.Where(record => included.Contains(record.Event.Metadata.EventId));
    public bool Includes(DomainEvent source)
    {
        var metadata = source.Metadata;
        var actual = Records.SingleOrDefault(record => record.Event.Metadata.EventId == metadata.EventId);
        if (actual is null)
            throw new ImmutableContentUnavailableException("The selected source is absent from the captured native receipt stream.");
        if (actual.Event.GetType() != source.GetType() || actual.Event.Metadata != metadata ||
            ContentDigest.Sha256(actual.Event,actual.Event.GetType()) != ContentDigest.Sha256(source,source.GetType()))
            throw new ImmutableContentIntegrityException("The selected source differs from its exact captured native tuple and payload.");
        return included.Contains(metadata.EventId);
    }
    public bool Includes(NativeFactReference source)
    {
        if (source.Stream != Stream)
            throw new ImmutableContentIntegrityException("The selected source proof belongs to another exact stream.");
        var actual = Records.SingleOrDefault(record => record.Event.Metadata.EventId == source.EventId);
        if (actual is null)
            throw new ImmutableContentUnavailableException("The selected native source proof is absent from the captured receipt stream.");
        if (actual.Event.Metadata.AggregateVersion != source.AggregateVersion)
            throw new ImmutableContentIntegrityException("The selected source proof has another native version.");
        return included.Contains(source.EventId);
    }
    public bool Includes(Func<DomainEvent,bool> selected)
    {
        var found = Records.Where(record => selected(record.Event)).ToArray();
        if (found.Length != 1)
            throw new ImmutableContentIntegrityException("The selected source component has no unique exact native fact.");
        return included.Contains(found[0].Event.Metadata.EventId);
    }
}
''')
p=P/E/'TypeIBaselineSourceReadContext.cs';s=p.read_text().replace('using Cntryl.Portia;','using Cntryl.Portia;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.SourceFacts;');at=s.rfind('}');s=s[:at]+'''    public RecordedSourceReceiptCut? ReceiptCut { get; init; }
    public RecordedSourceReceiptCut RequireReceipts(Uuid tenant)
    {
        if (RecordedThrough is not { } through || ReceiptCut is not { } cut || cut.TenantId != tenant || cut.RecordedThrough != through)
            throw new ImmutableContentUnavailableException("The exact closing source broker receipt selection is not configured.");
        return cut;
    }
    public ValueTask<bool> IncludesAsync(EventStreamAddress stream,DomainEvent fact,CancellationToken ct) => RecordedThrough is null
        ? ValueTask.FromResult(true) : RequireReceipts(Uuid.Parse(stream.Realm,System.Globalization.CultureInfo.InvariantCulture)).IncludesAsync(stream,fact,ct);
'''+s[at:];p.write_text(s)
p=P/E/'TypeIBaselinePreviewReader.cs';s=p.read_text().replace('using Cntryl.Portia;','using Cntryl.Portia;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.SourceFacts;')
s=s.replace('    readonly Dictionary<string, ITypeIBaselineSourceContributor> _contributors;','    readonly Dictionary<string, ITypeIBaselineSourceContributor> _contributors;\n    readonly RecordedSourceReceiptCutFactory? _receiptCuts;')
s=s.replace('IEnumerable<ITypeIBaselineSourceContributor> contributors)','IEnumerable<ITypeIBaselineSourceContributor> contributors,RecordedSourceReceiptCutFactory? receiptCuts = null)',1).replace('        var required = TypeIBaselineSourceFamilies.Required','        _receiptCuts = receiptCuts;\n        var required = TypeIBaselineSourceFamilies.Required',1)
s=s.replace('        foreach (var family in TypeIBaselineSourceFamilies.Required)','        var receiptCut = recordedThrough is { } through ? _receiptCuts?.Create(engagement.TenantId,through) : null;\n        foreach (var family in TypeIBaselineSourceFamilies.Required)',1)
s=s.replace('{ RecordedThrough = recordedThrough };','{ RecordedThrough = recordedThrough,ReceiptCut = receiptCut };')
s=s.replace('            var result = await contributor.ReadAsync(engagement, context, ct)\n                .ConfigureAwait(false);','''            Result<TypeIBaselineSourceContribution> result;
            try { result = await contributor.ReadAsync(engagement,context,ct).ConfigureAwait(false); }
            catch (ImmutableContentIntegrityException exception)
            { return Result<TypeIBaselinePreview>.Failure(new RequestError(RequestErrorKind.Conflict,"The exact closing source receipt cannot be verified.",exception is ImmutableContentUnavailableException)); }''')
p.write_text(s)
