exec(open('/tmp/compliance-all-source-receipts-prepared/prepare_tests.py').read().split('for rel in [')[0])
p=capture('test/Compliance.Tests/Features/Examinations/WorkforceTypeIBaselineSourceContributorTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\nusing Bdgrz.Compliance.Tests.Testing;\n'+s
s=s.replace('''        public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId,
            CancellationToken ct = default) => ValueTask.FromResult(ProjectionCheckpoint.Start);''','''        public ProjectionCheckpoint Checkpoint { get; init; } = ProjectionCheckpoint.Start;
        public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId,
            CancellationToken ct = default) => ValueTask.FromResult(Checkpoint);''',1)
anchor='    static WorkforceTypeIBaselineSourceContributor Contributor('
s=s.replace(anchor,'''    [Fact]
    public async Task ShouldSelectEarlierIntactRosterGivenLaterFreezeCommitsAfterReceiptCut()
    {
        // Arrange
        var engagement = Engagement();
        var earlier = Snapshot(engagement.TenantId, new DateTimeOffset(2026, 9, 29, 12, 0, 0, TimeSpan.Zero));
        var later = Snapshot(engagement.TenantId, new DateTimeOffset(2026, 9, 30, 12, 0, 0, TimeSpan.Zero));
        var events = new InMemoryEventStore();
        var receipts = new ScriptedNativeEventReceipts();
        var through = Now;
        foreach (var pair in new[] { earlier, later })
        {
            var fact = DomainEventSeed.Attach(pair.Source.FrozenFact!, pair.Source.Id, 1);
            await events.AppendAsync(pair.Source.Stream, 0, [fact]);
            await foreach (var record in events.ReadAsync(pair.Source.Stream, 0, CancellationToken.None))
                receipts.Record(record, pair.Source.Id == later.Source.Id ? through.AddMilliseconds(1) : through.AddMilliseconds(-1));
        }
        var cursor = EventCursor.Start;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(engagement.TenantId.ToString(), "population-snapshots"), cursor, CancellationToken.None))
            cursor = record.NextCursor;
        var directory = new SnapshotDirectory(earlier.Summary, later.Summary) { Checkpoint = new(cursor) };
        var contributor = Contributor(directory, new SnapshotAggregateReader(earlier.Source, later.Source), events);
        var context = new TypeIBaselineSourceReadContext(Uuid.Empty, []) { RecordedThrough = through,
            ReceiptCut = new RecordedSourceReceiptCutFactory(events, receipts).Create(engagement.TenantId, through) };

        // Act
        var result = await contributor.ReadAsync(engagement, context, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(earlier.Source.Id, Assert.Single(result.Value.Sources).VersionId);
        Assert.Empty(result.Value.Blockers);
    }

'''+anchor)
p.write_text(s)
p=capture('test/Compliance.Tests/Features/Examinations/TechnologyComponentTypeIBaselineSourceContributorTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
s=s.replace('Uuid? componentId = null, bool includeReviewedSystemSource = false)','Uuid? componentId = null, bool includeReviewedSystemSource = false,\n        DateTimeOffset? recordedThrough = null, IReadOnlyList<DateTimeOffset>? committedTimes = null)')
s=s.replace('''        return new FixtureState(contributor,
            new TypeIBaselineSourceReadContext(Uuid.CreateVersion4(), priorSources.AsReadOnly()));''','''        var context = new TypeIBaselineSourceReadContext(Uuid.CreateVersion4(), priorSources.AsReadOnly());
        if (recordedThrough is { } through)
        {
            var receipts = new ScriptedNativeEventReceipts();
            await foreach (var record in events.ReadAsync(stream, 0, CancellationToken.None))
                receipts.Record(record, committedTimes![checked((int)record.ResourceOffset)]);
            context = context with { RecordedThrough = through,
                ReceiptCut = new RecordedSourceReceiptCutFactory(events, receipts).Create(TenantId, through) };
        }
        return new FixtureState(contributor, context);''')
anchor='    static async Task<FixtureState> Fixture('
s=s.replace(anchor,'''    [Fact]
    public async Task ShouldKeepOriginalComponentGivenBackdatedRevisionCommitsAfterReceiptCut()
    {
        // Arrange
        var cutoff = DayOne.AddDays(20);
        var first = Revision(1, "Original VPC", DayOne);
        var next = Revision(2, "Backdated VPC", DayOne.AddDays(1));
        var fixture = await Fixture([first, next], recordedThrough: cutoff,
            committedTimes: [cutoff.AddMilliseconds(-1), cutoff.AddMilliseconds(1)]);
        var original = await Fixture([first]);

        // Act
        var result = await fixture.Contributor.ReadAsync(Engagement(), fixture.Context, CancellationToken.None);
        var expected = await original.Contributor.ReadAsync(Engagement(), original.Context, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.True(expected.IsSuccess, expected.Error?.Message);
        Assert.Equal(1, Assert.Single(result.Value.Sources).Revision);
        Assert.Equal(Assert.Single(expected.Value.Sources).ContentSha256, Assert.Single(result.Value.Sources).ContentSha256);
    }

'''+anchor)
p.write_text(s)
