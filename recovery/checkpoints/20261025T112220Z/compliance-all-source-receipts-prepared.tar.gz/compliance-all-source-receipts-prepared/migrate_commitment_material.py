from pathlib import Path
R=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features')
p=R/'Examinations/CommitmentTypeIBaselineSourceReader.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
s=s.replace('''            if (context.RecordedThrough is { } cutoff &&
                (view.Approval?.DecidedAt ?? view.Decision.DecidedAt) > cutoff)''','''            var receiptStream = context.RecordedThrough is null ? null :
                await context.RequireReceipts(engagement.TenantId).ReadAsync(new EventStreamAddress(
                    engagement.TenantId.ToString(), CommitmentDraft.Area, draftId.ToString()), ct).ConfigureAwait(false);
            if (receiptStream is not null && !receiptStream.Includes(fact => fact is CommitmentApproved approved &&
                    approved.ChangeCount > 0 && approved.Version == view.Version && approved.Revision == view.Revision))''')
s=s.replace('''            if (context.RecordedThrough is { } retirementCutoff && retirement.OccurredAt > retirementCutoff &&
                retirement.EffectiveOn <= engagement.PeriodStart)''','''            var retirementRecorded = receiptStream is null ? retirement.OccurredAt <= through :
                receiptStream.Includes(fact => fact is CommitmentRetired retired && retired.ChangeCount > 0 &&
                    retired.Revision == retirement.Revision);
            if (receiptStream is not null && !retirementRecorded && retirement.EffectiveOn <= engagement.PeriodStart)''')
s=s.replace('if (retirement.OccurredAt <= through || retirement.EffectiveOn <= engagement.PeriodStart)','if (retirementRecorded || retirement.EffectiveOn <= engagement.PeriodStart)')
s=s.replace('else if (retirement.OccurredAt > through)','else if (!retirementRecorded)')
p.write_text(s)
p=R/'Operations/TypeIIPeriodCloseMaterialReader.cs';s=p.read_text()
s=s.replace('IImmutableContentStore content, SystemDescriptionReader descriptions)','IImmutableContentStore content, SystemDescriptionReader descriptions, RecordedSourceReceiptCutFactory receiptCuts)')
s=s.replace('''        var result = new List<TypeIIPeriodCloseNativeSource>();
        foreach (var area in Areas)''','''        var result = new List<TypeIIPeriodCloseNativeSource>();
        var receiptCut = receiptCuts.Create(period.TenantId, through);
        foreach (var area in Areas)''')
old='''                var at = native.Payload.TryGetProperty("occurred_at", out var occurred) ? occurred.GetDateTimeOffset() :
                    record.Event is INativeOperationFact fact ? fact.Operation.AcceptedAt :
                    throw new ImmutableContentIntegrityException("The material source has no exact receipt timestamp.");
                if (at > through)
                    throw new ImmutableContentUnavailableException("Examination material advanced after the close amendment receipt cut.");'''
new='''                if (!await receiptCut.IncludesAsync(record, ct).ConfigureAwait(false))
                    throw new ImmutableContentUnavailableException("Examination material advanced after the close amendment receipt cut.");'''
assert old in s;s=s.replace(old,new)
# actual receipt source evidence must be recorded, selector exposes exact verified timestamps to avoid second raw call
# add stream accessor in separate framework change below; proof capture sets same verified broker ms.
s=s.replace('''                result.Add(native);''','''                var receiptStream = await receiptCut.ReadAsync(record.Stream, ct).ConfigureAwait(false);
                result.Add(native with { RecordedAt = receiptStream.RecordedAt(record.Event) });''')
p.write_text(s)
