from pathlib import Path
import json,shutil,hashlib
D=Path('/tmp/compliance-all-source-receipts-prepared');M=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def capture(rel,source=None):
 p=D/'base'/rel;w=D/'work'/rel
 if not p.exists():
  src=Path(source) if source else M/rel
  p.parent.mkdir(parents=True,exist_ok=True);w.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(src,p);shutil.copyfile(src,w)
 return w
for rel in ['test/Compliance.Tests/Features/Examinations/AccessExpectationsTypeIBaselineSourceContributorTests.cs','test/Compliance.Tests/Features/Examinations/PolicyTypeIBaselineSourceContributorTests.cs','test/Compliance.Tests/Features/Examinations/CommitmentTypeIBaselineSourceContributorTests.cs']:
 capture(rel)
p=D/'work/test/Compliance.Tests/Testing/ScriptedNativeEventReceipts.cs';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

/// <summary>Explicit authenticated-receipt fixture; its clock is supplied independently of occurrence/preparation payloads.</summary>
sealed class ScriptedNativeEventReceipts : INativeEventReceiptReader
{
    readonly Dictionary<(EventStreamAddress, ulong), (DomainEvent Fact, string Sha, DateTimeOffset At)> _values = [];
    public int Reads { get; private set; }
    public void Record(DomainEventRecord source, DateTimeOffset committedAt)
    {
        var at = DateTimeOffset.FromUnixTimeMilliseconds(committedAt.ToUnixTimeMilliseconds());
        _values[(source.Stream, source.ResourceOffset)] = (source.Event,
            ContentDigest.Sha256(source.Event, source.Event.GetType()), at);
    }
    public ValueTask<DateTimeOffset> RecordedAtAsync(DomainEventRecord source, CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        Reads++;
        if (!_values.TryGetValue((source.Stream, source.ResourceOffset), out var actual))
            throw new ImmutableContentUnavailableException("The scripted broker receipt is absent.");
        if (source.Event.GetType() != actual.Fact.GetType() || source.Event.Metadata != actual.Fact.Metadata ||
            ContentDigest.Sha256(source.Event, source.Event.GetType()) != actual.Sha)
            throw new ImmutableContentIntegrityException("The source differs from the scripted committed tuple.");
        return ValueTask.FromResult(actual.At);
    }
}
''')
# Existing receipt-cut cases now name explicit committed source times, never infer receipt from payload dates.
p=D/'work/test/Compliance.Tests/Features/Examinations/PolicyTypeIBaselineSourceContributorTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
anchor='''            await source.SeedAsync(policy);
            var directory = new Directory(policy, source);'''
# this anchor only nestedscenario (other spacing differs)
s=s.replace(anchor,'''            await source.SeedAsync(policy);
            if (context.RecordedThrough is { } through)
            {
                var receipts = new ScriptedNativeEventReceipts();
                var stream = new EventStreamAddress(TenantId.ToString(), Policy.Area, policy.Id.ToString());
                await foreach (var record in source.Events.ReadAsync(stream, 0, ct))
                    receipts.Record(record, record.Event.Metadata.AggregateVersion >= 4 ?
                        new DateTimeOffset(2027, 3, 15, 12, 3, 0, TimeSpan.Zero) : ApprovalAt);
                context = context with { ReceiptCut = new RecordedSourceReceiptCutFactory(source.Events, receipts).Create(TenantId, through) };
            }
            var directory = new Directory(policy, source);''')
p.write_text(s)
p=D/'work/test/Compliance.Tests/Features/Examinations/CommitmentTypeIBaselineSourceContributorTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
s=s.replace('var context = fixture.Context with { RecordedThrough = DayOne.AddDays(1) };','var context = await ReceiptContextAsync(fixture, DayOne.AddDays(1));')
s=s.replace('var context = fixture.Context with { RecordedThrough = DayOne.AddDays(9) };','var context = await ReceiptContextAsync(fixture, DayOne.AddDays(9));')
anchor='    static async Task<FixtureState> Fixture('
s=s.replace(anchor,'''    static async Task<TypeIBaselineSourceReadContext> ReceiptContextAsync(FixtureState fixture, DateTimeOffset through)
    {
        var receipts = new ScriptedNativeEventReceipts();
        var stream = new EventStreamAddress(TenantId.ToString(), CommitmentDraft.Area, fixture.DraftId.ToString());
        await foreach (var record in fixture.Source.Events.ReadAsync(stream, 0, CancellationToken.None))
            receipts.Record(record, record.Event is CommitmentRetired ? DayOne.AddDays(10) : DayOne.AddDays(2));
        return fixture.Context with { RecordedThrough = through,
            ReceiptCut = new RecordedSourceReceiptCutFactory(fixture.Source.Events, receipts).Create(TenantId, through) };
    }

'''+anchor)
# inspect exact FixtureState property name below, handle actualname Source likely
p.write_text(s)
# Access expectation: retain all originalcases; add exact append clocks, optional metadata descent to setup.
p=D/'work/test/Compliance.Tests/Features/Examinations/AccessExpectationsTypeIBaselineSourceContributorTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
s=s.replace('bool approvedAfterTypeIDate = false, bool secondLine = false)','bool approvedAfterTypeIDate = false, bool secondLine = false,\n        DateTimeOffset? committedAt = null, bool descendingOccurrence = false)')
s=s.replace('''        var attached = facts.ToArray();''','''        if (descendingOccurrence && facts.Count > 1)
            facts[1].AttachMetadata(facts[1].Metadata with { OccurredOn = facts[0].Metadata.OccurredOn.AddDays(-1) });
        var attached = facts.ToArray();''')
s=s.replace('''        return new FixtureState(contributor, Context());''','''        var context = Context();
        if (committedAt is { } at)
        {
            var receipts = new ScriptedNativeEventReceipts();
            await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString()), EventCursor.Start, CancellationToken.None))
                receipts.Record(record, at);
            context = context with { RecordedThrough = TypeIThrough,
                ReceiptCut = new RecordedSourceReceiptCutFactory(events, receipts).Create(TenantId, TypeIThrough) };
        }
        return new FixtureState(contributor, context);''')
anchor='    static AccessExpectationView View('
s=s.replace(anchor,'''    [Fact]
    public async Task ShouldExcludeBackdatedExpectationGivenAppendCommitsAfterFrozenReceiptCut()
    {
        // Arrange
        var fixture = await Fixture(includeApproval: false, committedAt: AfterTypeIDate);

        // Act
        var result = await fixture.Contributor.ReadAsync(Engagement(), fixture.Context, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Empty(result.Value.Sources);
    }

    [Fact]
    public async Task ShouldAcceptValidExpectationHistoryGivenOccurrenceMetadataDescendsBeforeReceiptCut()
    {
        // Arrange
        var fixture = await Fixture(includeApproval: true, committedAt: TypeIThrough.AddSeconds(-1), descendingOccurrence: true);

        // Act
        var result = await fixture.Contributor.ReadAsync(Engagement(), fixture.Context, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(4, Assert.Single(result.Value.Sources).Revision);
    }

'''+anchor)
p.write_text(s)
