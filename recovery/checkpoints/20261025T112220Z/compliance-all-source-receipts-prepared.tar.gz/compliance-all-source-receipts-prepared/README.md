# All source-family receipt selection

Frozen offline: 46 changed paths, 20 owning contributor files / 21 families. See handoff.json, manifest.json, artifacts.json, static-checks.json, method-audit.json and reconstruction-checks.json.

The shared selector authenticates complete resource-stream native tuples and bytes using the parent receipt15 port, caches one request-relative prefix per resource, and selects inclusive broker-reported epoch milliseconds. Same-ms values tie; no sub-ms physical ordering or new watermark protocol is claimed. A source after the cut followed by one inside the cut fails closed. Native import publication requires complete frozen target effects; access-review publication requires the exact admitted batch plus complete selected holds/provisional decisions; participant results require their exact root admission; provider and artifact dependencies cannot reference later excluded native heads.

The examination date still controls effective-date rules. Current restricted visibility, request authority, current licensing intersection, source checkpoints, original logical digest preimages and publisher bytes remain in place. RecordedThrough-null reads preserve the existing Type I behavior and perform no receipt lookups. Forty-two canonical digest/serialization helper methods compare unchanged. Missing verified receipt/content stays transient; corruption, wrong scope and causal-cut disagreement fail permanently.

## Current main integration

Parent receipt15 is a prerequisite. Current main has not yet integrated queued native Risk and SystemDescription. Use implementation-core.patch + tests-core.patch + current-main-overlaps.patch + shared.patch. The four-path current-main variant supplies faithful receipt guards for the current Risk contributor and current MaterialReader/two manual test fixtures.

For red first, apply red-scaffold.patch and behavioral-red.patch. The scaffold adds only receipt/context infrastructure; old feature selection still ignores it. Run behavioral-red-filter.txt. Its eight missing-behavior rows should fail, while the one valid legacy-Incident-prefix row should pass (actual execution belongs to root). Then apply green-after-red-implementation.patch, green-after-red-tests.patch, current-main-overlaps.patch and shared.patch. These deltas omit already-installed scaffold/test paths; no reverse patch is required. Run focused-filter.txt and the full unit suite centrally after format and strict build.

## Queued owner overlays

implementation.patch + tests.patch + shared.patch reconstruct the complete queued-native version directly. They require native Risk and SystemDescription APIs. Extracted overlap-risk-native.patch and overlap-system-description-native.patch preserve the same correction when those queued owner patches are later integrated. The native SD MaterialReader constructor gains receipt factory as fourth argument; the current-main MaterialReader gains it as third. The later SD integration must preserve this receipt seam. Do not apply both variants to the same baseline.

TypeIIPeriodCloseHistory follow-on is included in both core and full implementation, and separately extracted as overlap-receipt15-history.patch. It addresses the parent-reported legacy Incident group.Last bypass using the shared per-resource prefix selector, with controlled receipt prefix/non-prefix cases and sealed exact receipt assertions.

shared.patch adds only RecordedSourceReceiptCutFactory registration, on a refreshed actual-main DI snapshot preserving parent's fixed workload store registration constants. No JSON roots/public wire DTOs/routes are added.

## Evidence and limits

Modern syntax parse: 49 C# files; 26 relevant explicit constructor calls; zero static errors. All 89 captured original acceptance method names and per-file assertion counts remain; 25 new methods include theory rows. Primary46, current-main variant4, red11 and red-to-green-core42 reconstruct exact hashes. Static checks are not compilation or runtime evidence. Child performed no builds, tests, Jev, git operations, main edits, issue creation, or broker operations. Root owns runtime and exact-file review.

The separate Incident native compaction WIP remains saved and unqualified; this correction does not mark it complete. Frozen SD101 and receipt15 artifacts were not modified.
