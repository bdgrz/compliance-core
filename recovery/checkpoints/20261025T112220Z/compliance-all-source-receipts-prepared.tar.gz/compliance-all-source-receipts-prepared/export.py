from pathlib import Path
import difflib,hashlib,json,shutil,subprocess
R=Path('/tmp/compliance-all-source-receipts-prepared')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def changed(root):
 return sorted(str(p.relative_to(root/'work')) for p in (root/'work').rglob('*') if p.is_file() and (not(root/'base'/p.relative_to(root/'work')).exists() or p.read_bytes()!=(root/'base'/p.relative_to(root/'work')).read_bytes()))
def export(root,filename,paths):
 chunks=[]
 for rel in paths:
  b=root/'base'/rel;w=root/'work'/rel
  before=b.read_text().splitlines(keepends=True) if b.exists() else []
  after=w.read_text().splitlines(keepends=True) if w.exists() else []
  chunks+=difflib.unified_diff(before,after,fromfile='a/'+rel if b.exists() else '/dev/null',tofile='b/'+rel if w.exists() else '/dev/null')
 path=R/filename;path.write_text(''.join(chunks));return {'path':str(path),'sha256':sha(path),'paths':paths}
paths=changed(R);shared=['src/Compliance.Core/ComplianceServiceCollectionExtensions.cs'];risk=['src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs'];sd=['src/Compliance.Core/Features/Operations/TypeIIPeriodCloseMaterialReader.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.NativeOwners.cs','test/Compliance.Tests/Features/Operations/ObservationPeriodReadHandlerTests.cs'];history=['src/Compliance.Core/Features/Operations/TypeIIPeriodCloseHistory.cs']
src=[p for p in paths if p.startswith('src/') and p not in shared];tests=[p for p in paths if p.startswith('test/')]
scaffold=['src/Compliance.Core/Features/Examinations/TypeIBaselineSourceReadContext.cs']+sorted(p for p in src if '/SourceFacts/RecordedSourceReceipt' in p)
redclasses=['AccessExpectations','TechnologyComponent','Workforce','Control','EvidenceGovernance'];redpaths=[p for p in tests if any('/'+name+'TypeIBaselineSourceContributorTests.cs' in p for name in redclasses)]+['test/Compliance.Tests/Testing/ScriptedNativeEventReceipts.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCloseHistoryReceiptTests.cs']
artifacts={}
for name,selected in [('implementation.patch',src),('tests.patch',tests),('shared.patch',shared),('implementation-core.patch',[p for p in src if p not in risk+sd]),('tests-core.patch',[p for p in tests if p not in sd]),('red-scaffold.patch',scaffold),('behavioral-red.patch',redpaths),('green-after-red-implementation.patch',[p for p in src if p not in risk+sd+scaffold]),('green-after-red-tests.patch',[p for p in tests if p not in sd+redpaths]),('overlap-risk-native.patch',risk),('overlap-system-description-native.patch',sd),('overlap-receipt15-history.patch',history)]:artifacts[name]=export(R,name,selected)
V=R/'current-main-overlaps';vp=changed(V);artifacts['current-main-overlaps.patch']=export(V,'current-main-overlaps.patch',vp)
manifest=[]
origins={x['path']:x['baselineSource'] for x in json.loads((R/'baselines.json').read_text())}
for rel in paths:
 manifest.append({'path':rel,'beforeSha256':sha(R/'base'/rel),'afterSha256':sha(R/'work'/rel),'baselineSource':origins.get(rel,'captured exact original / existing shared package base'),'layer':'shared' if rel in shared else 'queued-risk' if rel in risk else 'queued-system-description' if rel in sd else 'receipt15-history' if rel in history else 'core'})
(R/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(R/'current-main-overlaps/manifest.json').write_text(json.dumps([{'path':rel,'beforeSha256':sha(V/'base'/rel),'afterSha256':sha(V/'work'/rel),'baselineSource':'current main snapshot, no native queued owner prerequisite'} for rel in vp],indent=2)+'\n')
# Exact reconstruction of complete primary and current-main variants from original bytes.
results=[]
for label,root,patches,selected in [('primary',R,['implementation.patch','tests.patch','shared.patch'],paths),('current-main-overlaps',V,['current-main-overlaps.patch'],vp),('red-scaffold-and-tests',R,['red-scaffold.patch','behavioral-red.patch'],list(dict.fromkeys(scaffold+redpaths))),('core-red-to-green',R,['red-scaffold.patch','behavioral-red.patch','green-after-red-implementation.patch','green-after-red-tests.patch','shared.patch'],[p for p in paths if p not in risk+sd])]:
 out=R/'reconstruction'/label
 if out.exists():shutil.rmtree(out)
 out.mkdir(parents=True)
 for rel in selected:
  b=root/'base'/rel
  if b.exists():dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b,dest)
 for patch in patches:
  run=subprocess.run(['patch','-p1','-E','--batch','-i',str(R/patch)],cwd=out,capture_output=True,text=True)
  if run.returncode:raise RuntimeError(label+' '+run.stdout+run.stderr)
 for rel in selected:
  if sha(out/rel)!=sha(root/'work'/rel):raise RuntimeError('hash mismatch '+label+' '+rel)
 results.append({'layer':label,'pathCount':len(selected),'exactReconstruction':True})
(R/'reconstruction-checks.json').write_text(json.dumps(results,indent=2)+'\n')
(R/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n');print(json.dumps({'changedPaths':len(paths),'source':len(src),'tests':len(tests),'shared':len(shared),'artifacts':{k:v['sha256'] for k,v in artifacts.items()},'reconstruction':results},indent=2))
