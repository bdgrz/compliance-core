from pathlib import Path
p=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features/Examinations/PolicyCommunicationTypeIBaselineSourceContributor.cs');s=p.read_text()
s=s.replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.SourceFacts;')
s=s.replace('''        var fence = await consistency.CaptureAsync''','''        var receiptCut = context.RecordedThrough is null ? null : context.RequireReceipts(engagement.TenantId);
        var fence = await consistency.CaptureAsync''',1)
s=s.replace('engagement.ProgramId, through, ct).ConfigureAwait(false);','engagement.ProgramId, through, ct, context).ConfigureAwait(false);')
s=s.replace('''                PolicyReadSnapshot? policy = null;''','''                var campaignStream = new PolicyDistributionCampaign(engagement.TenantId, item.CampaignId).Stream;
                var campaignReceipts = receiptCut is null ? null : await receiptCut.ReadAsync(campaignStream, ct).ConfigureAwait(false);
                if (campaignReceipts is not null)
                {
                    var nativeLaunch = campaignReceipts.Records.Select(record => record.Event).OfType<PolicyCampaignLaunched>().SingleOrDefault()
                        ?? throw new ImmutableContentUnavailableException("The listed campaign has no exact native launch fact.");
                    if (!campaignReceipts.Includes(nativeLaunch))
                        continue;
                }
                PolicyReadSnapshot? policy = null;''')
s=s.replace('''                            out var validHistory);''','''                            out var validHistory, receiptCut is null ? null : await receiptCut.ReadAsync(
                                new Policy(engagement.TenantId, policy.Id).Stream, ct).ConfigureAwait(false));''')
s=s.replace('''                var launch = history.Value.Launch;
                if (launch.LaunchedAt > effectiveThrough)''','''                var launch = history.Value.Launch;
                if (campaignReceipts is not null && (!campaignReceipts.Includes(launch) ||
                    !campaignReceipts.Includes(history.Value.Frozen)))
                {
                    blockers.Add($"Campaign {item.SubjectIdentifier} had no complete frozen audience at the recorded cutoff.");
                    continue;
                }
                if (launch.LaunchedAt > effectiveThrough)''')
a='''                    var acknowledgements = history.Value.Acknowledgements.Where(item =>
                            item.AcknowledgedAt <= through)
                        .ToArray();
                    var completions = history.Value.Completions.Where(item =>
                            item.CompletedOn <= engagement.PeriodStart && item.RecordedAt <= through)
                        .ToArray();
                    var waivers = history.Value.Waivers.Where(item => item.ApprovedAt <= through)
                        .ToArray();
                    var amendments = history.Value.Amendments.Where(item =>
                            item.Fact.AmendedAt <= through && item.Fact.ObservedOn <= engagement.PeriodStart)
                        .ToArray();
                    var closure = history.Value.Closure is { } closed && closed.ClosedAt <= through
                        ? closed
                        : null;'''
b='''                    var acknowledgements = await RecordedResultsAsync(history.Value.Acknowledgements, receiptCut,
                        item => PolicyCampaignParticipant.StreamOf(engagement.TenantId, item.CampaignId, item.PersonId),
                        item => item.AcknowledgedAt <= through, ct).ConfigureAwait(false);
                    var completions = await RecordedResultsAsync(history.Value.Completions.Where(item =>
                            item.CompletedOn <= engagement.PeriodStart).ToArray(), receiptCut,
                        item => PolicyCampaignParticipant.StreamOf(engagement.TenantId, item.CampaignId, item.PersonId),
                        item => item.RecordedAt <= through, ct).ConfigureAwait(false);
                    var waivers = await RecordedResultsAsync(history.Value.Waivers, receiptCut,
                        item => PolicyCampaignParticipant.StreamOf(engagement.TenantId, item.CampaignId, item.PersonId),
                        item => item.ApprovedAt <= through, ct).ConfigureAwait(false);
                    var amendments = history.Value.Amendments.Where(item =>
                            item.Fact.ObservedOn <= engagement.PeriodStart && (campaignReceipts is null
                                ? item.Fact.AmendedAt <= through : campaignReceipts.Includes(item.Fact)))
                        .ToArray();
                    var closure = history.Value.Closure is { } closed && (campaignReceipts is null
                        ? closed.ClosedAt <= through : campaignReceipts.Includes(closed)) ? closed : null;'''
assert a in s;s=s.replace(a,b)
s=s.replace('''                    InvalidOperationException or NotSupportedException)
                {''','''                    InvalidOperationException or NotSupportedException && exception is not ImmutableContentIntegrityException)
                {''')
s=s.replace('''    static bool ValidSummary(CampaignSummaryView? summary,''','''    static async Task<T[]> RecordedResultsAsync<T>(IReadOnlyList<T> facts, RecordedSourceReceiptCut? cut,
        Func<T, EventStreamAddress> sourceStream, Func<T, bool> legacyIncluded, CancellationToken ct) where T : DomainEvent
    {
        var selected = new List<T>();
        foreach (var fact in facts)
            if (cut is null ? legacyIncluded(fact) : await cut.IncludesAsync(sourceStream(fact), fact, ct).ConfigureAwait(false))
                selected.Add(fact);
        return selected.ToArray();
    }

    static bool ValidSummary(CampaignSummaryView? summary,''')
s=s.replace('''new CampaignHistory(launch, state.Teams, 1,''','''new CampaignHistory(launch, frozen, state.Teams, 1,''')
s=s.replace('''DateTimeOffset through, CancellationToken ct)
    {
        var byRequirement''','''DateTimeOffset through, CancellationToken ct, TypeIBaselineSourceReadContext? context = null)
    {
        var receiptCut = context?.RecordedThrough is null ? null : context.RequireReceipts(tenantId);
        var byRequirement''')
s=s.replace('''                if (version.ChangedAt <= through)
                    asOf = version;''','''                if (receiptCut is null ? version.ChangedAt <= through : await receiptCut.IncludesAsync(
                        new TrainingRequirement(tenantId, requirementId).Stream, fact, ct).ConfigureAwait(false))
                    asOf = version;''')
s=s.replace('''sealed record CampaignHistory(PolicyCampaignLaunched Launch, IReadOnlyList<string> Teams,''','''sealed record CampaignHistory(PolicyCampaignLaunched Launch, PolicyCampaignAudienceFrozen Frozen, IReadOnlyList<string> Teams,''')
p.write_text(s)
print('Prepared campaign-root, participant-result, training-version and policy-source receipt gates; nullcut retained.')
