exec(open('/tmp/compliance-all-source-receipts-prepared/prepare_tests.py').read().split('for rel in [')[0])
rel='src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';p=capture(rel,'/tmp/compliance-native-receipts-prepared/work/'+rel);s=p.read_text();s=s.replace('services.TryAddScoped<INativeEventReceiptReader,FitzNativeEventReceiptReader>();','services.TryAddScoped<INativeEventReceiptReader,FitzNativeEventReceiptReader>();\n        services.AddScoped<RecordedSourceReceiptCutFactory>();');p.write_text(s)
for rel in ['test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.NativeOwners.cs','test/Compliance.Tests/Features/Operations/ObservationPeriodReadHandlerTests.cs']:
 p=capture(rel,'/tmp/compliance-system-description-prepared/work/'+rel);s=p.read_text()
 if 'using Bdgrz.Compliance.Features.SourceFacts;' not in s:s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
 if 'NativeOwners' in rel:
  if 'using Microsoft.Extensions.DependencyInjection;' not in s:s='using Microsoft.Extensions.DependencyInjection;\n'+s
  s=s.replace('new SystemDescriptionReader(fixture.Reader, fixture.Events, fixture.Host.Content))','new SystemDescriptionReader(fixture.Reader, fixture.Events, fixture.Host.Content),\n                new RecordedSourceReceiptCutFactory(fixture.Events, fixture.Host.Services.GetRequiredService<INativeEventReceiptReader>()))')
 else:
  s=s.replace('public InMemoryEventStore Events { get; } = new();','public InMemoryEventStore Events { get; } = new();\n        public ReceiptTrackingEventStore Receipts { get; }')
  s=s.replace('''            services.AddSingleton<IEventStore>(Events);''','''            Receipts = new ReceiptTrackingEventStore(Events, new ReceiptClock());
            services.AddSingleton<IEventStore>(Receipts);''')
  s=s.replace('new SystemDescriptionReader(Reader, Events, Content))','new SystemDescriptionReader(Reader, Events, Content),\n                new RecordedSourceReceiptCutFactory(Events, Receipts))')
  s=s.replace('''        public async ValueTask DisposeAsync()
        {''','''        sealed class ReceiptClock : TimeProvider
        {
            public override DateTimeOffset GetUtcNow() => Now;
        }
        public async ValueTask DisposeAsync()
        {''')
 p.write_text(s)
