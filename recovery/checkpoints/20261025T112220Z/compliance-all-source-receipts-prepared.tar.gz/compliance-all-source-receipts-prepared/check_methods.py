from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json,re
R=Path('/tmp/compliance-all-source-receipts-prepared');p=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 q=[n]
 while q:
  n=q.pop();yield n;q.extend(n.children)
def txt(b,n):return b[n.start_byte:n.end_byte].decode()
def methods(f):
 b=f.read_bytes();t=p.parse(b);result={}
 for n in walk(t.root_node):
  if n.type!='method_declaration':continue
  name=n.child_by_field_name('name');pl=n.child_by_field_name('parameters')
  if name is None or pl is None:continue
  result[(txt(b,name),txt(b,pl))]=txt(b,n)
 return result
canonical=[];changedCanonical=[];ctNotLast=[];missingContext=[]
for f in (R/'work').rglob('*.cs'):
 b=f.read_bytes();tree=p.parse(b);base=R/'base'/f.relative_to(R/'work');before=methods(base) if base.exists() else {}
 for n in walk(tree.root_node):
  if n.type!='method_declaration':continue
  name=n.child_by_field_name('name');pl=n.child_by_field_name('parameters')
  if name is None or pl is None:continue
  name=txt(b,name);pars=[x for x in pl.named_children if x.type=='parameter'];sig=txt(b,pl)
  for i,arg in enumerate(pars):
   if 'CancellationToken ' in txt(b,arg) and i!=len(pars)-1:ctNotLast.append({'path':str(f.relative_to(R/'work')),'method':name,'signature':sig})
  if '/src/' in str(f) and re.search(r'\bcontext\b',txt(b,n)) and 'context' not in sig and not re.search(r'\bvar context\b',txt(b,n)):
   missingContext.append({'path':str(f.relative_to(R/'work')),'method':name})
  if name in {'Digest','RevisionDigest','RetirementDigest','VersionDigest','SelectionDigest','EditionDigest','WriteCanonical','Write','VersionReference','RetirementReference','RevisionVersionId','RetirementVersionId'} and (name,sig) in before:
   entry={'path':str(f.relative_to(R/'work')),'method':name};canonical.append(entry)
   if re.sub(r'\s+','',txt(b,n))!=re.sub(r'\s+','',before[(name,sig)]):changedCanonical.append(entry)
report={'staticOnly':True,'canonicalSourceHelpersCompared':len(canonical),'canonicalSourceHelpersChanged':changedCanonical,'cancellationTokensNotLast':ctNotLast,'methodsWithUnboundContextIdentifier':missingContext}
(R/'method-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
