exec(open('/tmp/compliance-all-source-receipts-prepared/migrate_loops.py').read().split("n='BoundaryTypeIBaseline")[0])
n='EvidenceGovernanceTypeIBaselineSourceContributor.cs';s=plumb(read(n),['ReadArtifactAsOfAsync','ReadHandlingPolicyAsOfAsync','ReadRetentionAsOfAsync','ReadRelatedGovernanceAsync'])
s=re.sub(r'(\w+Async\()context,\s+(?=(?:Uuid|EventStreamAddress|ExaminationEngagementView)\s)',r'\1TypeIBaselineSourceReadContext context, ',s)
s=s.replace('''            if (link.ProgramId != engagement.ProgramId || link.OccurredAt > through ||
                record.Event!.Metadata!.OccurredOn > through ||''','''            if (link.ProgramId != engagement.ProgramId ||
                (context.RecordedThrough is null ? link.OccurredAt > through || record.Event!.Metadata!.OccurredOn > through :
                    !await context.IncludesAsync(record.Stream, record.Event!, ct).ConfigureAwait(false)) ||''')
s=s.replace('''                    link.ArtifactRevision < artifact.Value.Events.Count(item =>
                        item.OccurredOn < link.OccurredAt) ||
                    link.ArtifactRevision > artifact.Value.Events.Count(item =>
                        item.OccurredOn <= link.OccurredAt)))''','''                    (context.RecordedThrough is null ?
                        link.ArtifactRevision < artifact.Value.Events.Count(item => item.OccurredOn < link.OccurredAt) ||
                        link.ArtifactRevision > artifact.Value.Events.Count(item => item.OccurredOn <= link.OccurredAt) :
                        link.ArtifactRevision < 1 || link.ArtifactRevision > artifact.Value.AsOfRevision)))''')
s=s.replace('''metadata.OccurredOn == default || priorOccurredAt is { } prior &&
                metadata.OccurredOn < prior''','''metadata.OccurredOn == default || context.RecordedThrough is null && priorOccurredAt is { } prior &&
                metadata.OccurredOn < prior''')
s=s.replace('''if (metadata.OccurredOn <= through)''','''if (context.RecordedThrough is null ? metadata.OccurredOn <= through :
                await context.IncludesAsync(item.Stream, item.Event!, ct).ConfigureAwait(false))''')
s=s.replace('''        var asOf = states.LastOrDefault(state => state.AssignedAt <= through);''','''        EvidenceHandlingPolicyView? asOf = null;
        for (var index = 0; index < states.Count; index++)
            if (context.RecordedThrough is null ? states[index].AssignedAt <= through :
                await context.IncludesAsync(read.Value[index].Stream, read.Value[index].Event, ct).ConfigureAwait(false))
                asOf = states[index];''')
old='''        var basis = retention.Basis is { RecordedAt: var recordedAt } value && recordedAt <= through
            ? value
            : null;
        var holds = retention.Holds.Where(hold => hold.PlacedAt <= through)
            .Select(hold => hold.ReleasedAt is { } releasedAt && releasedAt > through
                ? hold with { ReleaseReason = null, ReleasedBy = null, ReleasedAt = null }
                : hold)
            .OrderBy(static hold => hold.HoldId.ToString(), StringComparer.Ordinal).ToArray();'''
new='''        var basis = retention.Basis;
        if (basis is not null && !(context.RecordedThrough is null ? basis.RecordedAt <= through :
                await context.IncludesAsync(new ArtifactRetentionBasis(basis.Source).Stream, basis, ct).ConfigureAwait(false)))
            basis = null;
        var selectedHolds = new List<ArtifactLegalHoldView>();
        foreach (var hold in retention.Holds)
        {
            if (context.RecordedThrough is null)
            {
                if (hold.PlacedAt <= through)
                    selectedHolds.Add(hold.ReleasedAt is { } releasedAt && releasedAt > through ?
                        hold with { ReleaseReason = null, ReleasedBy = null, ReleasedAt = null } : hold);
                continue;
            }
            var owner = await aggregates.HydrateAsync(new ArtifactLegalHold(tenantId, hold.HoldId), ct).ConfigureAwait(false);
            if (owner.Placement is null || owner.Source != retention.Source || owner.View != hold)
                return InvalidHistory<RetentionAsOf>();
            if (!await context.IncludesAsync(owner.Stream, owner.Placement, ct).ConfigureAwait(false))
                continue;
            selectedHolds.Add(owner.Release is { } release &&
                !await context.IncludesAsync(owner.Stream, release, ct).ConfigureAwait(false) ?
                hold with { ReleaseReason = null, ReleasedBy = null, ReleasedAt = null } : hold);
        }
        var holds = selectedHolds.OrderBy(static hold => hold.HoldId.ToString(), StringComparer.Ordinal).ToArray();'''
assert old in s;s=s.replace(old,new)
s=s.replace('occurred.TryGetValue(aggregateId, out var prior) && metadata.OccurredOn < prior','context.RecordedThrough is null && occurred.TryGetValue(aggregateId, out var prior) && metadata.OccurredOn < prior')
s=s.replace('if (businessAt > through || metadata.OccurredOn > through)','if (context.RecordedThrough is null ? businessAt > through || metadata.OccurredOn > through :\n                    !await context.IncludesAsync(record.Stream, record.Event, ct).ConfigureAwait(false))')
save(n,s)
