exec(open('/tmp/compliance-all-source-receipts-prepared/prepare_tests.py').read().split('for rel in [')[0])
p=D/'work/src/Compliance.Core/Features/Examinations/ControlTypeIBaselineSourceContributor.cs';s=p.read_text()
anchor='''                var version = control.EffectiveVersion(engagement.PeriodStart);'''
s=s.replace(anchor,'''                var receiptStream = context.RecordedThrough is null ? null :
                    await context.RequireReceipts(engagement.TenantId).ReadAsync(new EventStreamAddress(
                        engagement.TenantId.ToString(), ControlDraft.Area, control.Id.ToString()), ct).ConfigureAwait(false);
                if (receiptStream is not null && control.ReadRetirementHistory().Any(retirement =>
                        retirement.EffectiveUntil <= engagement.PeriodStart && !receiptStream.Includes(retirement)))
                    return Result<TypeIBaselineSourceContribution>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "An effective control retirement changed after the frozen close receipt cutoff.", true));
'''+anchor)
s=s.replace('''                if (context.RecordedThrough is not null && !(await context.RequireReceipts(engagement.TenantId)
                        .ReadAsync(new EventStreamAddress(engagement.TenantId.ToString(), ControlDraft.Area, control.Id.ToString()), ct)
                        .ConfigureAwait(false)).Includes(fact => fact is ControlApproved approved && approved.ChangeCount > 0 &&
                            approved.VersionId == version.VersionId && approved.ApprovalDecisionId == version.ApprovalDecisionId))''','''                if (receiptStream is not null && !receiptStream.Includes(fact => fact is ControlApproved approved && approved.ChangeCount > 0 &&
                            approved.VersionId == version.VersionId && approved.ApprovalDecisionId == version.ApprovalDecisionId))''')
p.write_text(s)
p=capture('test/Compliance.Tests/Features/Examinations/ControlTypeIBaselineSourceContributorTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
anchor='    static ControlTypeIBaselineSourceContributor Contributor('
s=s.replace(anchor,'''    [Fact]
    public async Task ShouldRefuseMissingEffectiveControlGivenRetroactiveRetirementCommitsAfterReceiptCut()
    {
        // Arrange
        var control = ApprovedControl("AC-RECEIPT", new DateOnly(2026, 9, 1));
        var cutoff = Now.AddDays(3);
        Assert.Null(control.ProposeRetirement(ProgramId, control.ApprovedVersion!.VersionId, new DateOnly(2026, 9, 15),
            "Replaced by an automated control.", AuthorId, "Author", Now.AddHours(1)));
        var review = Uuid.CreateVersion4();
        Assert.Null(control.Review(ProgramId, control.Revision, review, "accept", "Retirement justified.", ReviewerId, "Reviewer", Now.AddHours(2)));
        Assert.Null(control.Retire(ProgramId, control.Revision, Uuid.CreateVersion4(), review, "impact-digest",
            "Retire at the approved date.", ApproverId, "Approver", Now.AddHours(3)));
        await using var source = await NativeSource.CreateAsync(control);
        var stream = new EventStreamAddress(TenantId.ToString(), ControlDraft.Area, control.Id.ToString());
        var receipts = new ScriptedNativeEventReceipts();
        await foreach (var record in source.Events.ReadAsync(stream, 0, CancellationToken.None))
            receipts.Record(record, record.Event is ControlRetired ? cutoff.AddMilliseconds(1) : cutoff.AddMilliseconds(-1));
        var context = new TypeIBaselineSourceReadContext(Uuid.Empty, []) { RecordedThrough = cutoff,
            ReceiptCut = new RecordedSourceReceiptCutFactory(source.Events, receipts).Create(TenantId, cutoff) };
        var contributor = Contributor(new Directory([control]), source);

        // Act
        var result = await contributor.ReadAsync(Engagement(new DateOnly(2026, 9, 30)), context, CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, result.Error.Kind);
        Assert.True(result.Error.IsTransient);
    }

'''+anchor)
p.write_text(s)
