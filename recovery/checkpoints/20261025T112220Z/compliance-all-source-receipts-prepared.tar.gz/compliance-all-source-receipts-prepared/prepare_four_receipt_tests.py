from pathlib import Path
root=Path('/tmp/compliance-all-source-receipts-prepared/work/test/Compliance.Tests/Features/Examinations')
def change(family,test,replacements):
 p=root/(family+'TypeIBaselineSourceContributorTests.cs');s=p.read_text()
 s='using Bdgrz.Compliance.Features.SourceFacts;\n'+s
 s=s.replace('    [Fact]',test+'\n    [Fact]',1)
 for a,b in replacements:
  assert a in s,(family,a);s=s.replace(a,b)
 p.write_text(s)
change('ControlCriterionMapping','''    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldUseBrokerReceiptPrefixGivenMappingPayloadTimesDisagree(bool lateBrokerReceipt)
    {
        // Arrange
        var fixture = await Fixture(includeFutureSuccessor: true, successorBeforePeriod: lateBrokerReceipt,
            capturedControlVersionId: lateBrokerReceipt ? ControlVersionId : FutureControlVersionId);
        var cutoff = new DateTimeOffset(2026, 1, 31, 23, 59, 59, TimeSpan.Zero);
        var receipts = new ScriptedNativeEventReceipts();
        await foreach (var record in fixture.Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString(),
            ControlCriterionMapping.Area), EventCursor.Start, CancellationToken.None))
        {
            var successor = record.Event is ControlCriterionMappingProposed { VersionNumber: 2 } or
                ControlCriterionMappingReviewed { VersionNumber: 2 };
            receipts.Record(record, lateBrokerReceipt && successor ? cutoff.AddMilliseconds(1) : cutoff);
        }
        var context = fixture.Context with
        {
            RecordedThrough = cutoff,
            ReceiptCut = new RecordedSourceReceiptCut(TenantId, cutoff, fixture.Events, receipts),
        };

        // Act
        var result = await fixture.Contributor.ReadAsync(Engagement(), context, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(lateBrokerReceipt ? 1 : 2, Assert.Single(result.Value.Sources).Revision);
        Assert.True(receipts.Reads > 0);
    }
''',[
 ('return new FixtureState(mappingId, contributor, context);','return new FixtureState(mappingId, contributor, context, events);'),
 ('TypeIBaselineSourceReadContext Context);','TypeIBaselineSourceReadContext Context, InMemoryEventStore Events);')])
change('Application','''    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldUseBrokerReceiptPrefixGivenApplicationPayloadTimesDisagree(bool lateBrokerReceipt)
    {
        // Arrange
        var cutoff = new DateTimeOffset(2026, 6, 30, 23, 59, 59, TimeSpan.Zero);
        var fixture = Fixture([Revision(1, "Payroll", DayOne), Revision(2, "Payroll successor",
            lateBrokerReceipt ? DayOne.AddDays(1) : cutoff.AddDays(1))]);
        await fixture.Events.AppendAsync(fixture.Source.Stream, 0, NativeFacts.Raised(fixture.Source));
        var receipts = new ScriptedNativeEventReceipts();
        await foreach (var record in fixture.Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString(),
            DeclaredApplication.Area), EventCursor.Start, CancellationToken.None))
            receipts.Record(record, lateBrokerReceipt && record.Event is ApplicationRevised ? cutoff.AddMilliseconds(1) : cutoff);
        var context = fixture.Context with
        {
            RecordedThrough = cutoff,
            ReceiptCut = new RecordedSourceReceiptCut(TenantId, cutoff, fixture.Events, receipts),
        };

        // Act
        var result = await fixture.Contributor.ReadAsync(Engagement(new DateOnly(2026, 6, 30)), context, CancellationToken.None);
        var legacy = await fixture.Contributor.ReadAsync(Engagement(new DateOnly(2026, 6, 30)),
            fixture.Context with { ReceiptCut = context.ReceiptCut }, CancellationToken.None);
        var receiptReads = receipts.Reads;
        var legacyWithoutPort = await fixture.Contributor.ReadAsync(Engagement(new DateOnly(2026, 6, 30)),
            fixture.Context, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(lateBrokerReceipt ? 1 : 2, Assert.Single(result.Value.Sources).Revision);
        Assert.True(receipts.Reads > 0);
        Assert.Equal(legacyWithoutPort.Value.Sources, legacy.Value.Sources);
        Assert.Equal(receiptReads, receipts.Reads);
    }
''',[
 ('return new FixtureState(contributor, context);','return new FixtureState(contributor, context, events, source);'),
 ('TypeIBaselineSourceReadContext Context);','TypeIBaselineSourceReadContext Context, InMemoryEventStore Events, DeclaredApplication Source);')])
change('PolicyCommunication','''    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldUseParticipantReceiptPrefixGivenAcknowledgementPayloadTimeDisagrees(bool lateBrokerReceipt)
    {
        // Arrange
        await using var fixture = await PolicyCampaign();
        var cutoff = new DateTimeOffset(2027, 3, 31, 23, 59, 59, TimeSpan.Zero);
        var before = await fixture.Contributor.ReadAsync(Engagement(), fixture.Context, CancellationToken.None);
        Assert.True((await fixture.AcknowledgeAsync(Bob, lateBrokerReceipt ? LaunchAt.AddDays(20) : cutoff.AddDays(1))).IsSuccess);
        var receipts = new ScriptedNativeEventReceipts();
        await foreach (var record in fixture.Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString()),
            EventCursor.Start, CancellationToken.None))
            receipts.Record(record, lateBrokerReceipt && record.Event is PolicyAcknowledgementRecorded { PersonId: var person } && person == Bob
                ? cutoff.AddMilliseconds(1) : cutoff);
        var context = fixture.Context with
        {
            RecordedThrough = cutoff,
            ReceiptCut = new RecordedSourceReceiptCut(TenantId, cutoff, fixture.Events, receipts),
        };

        // Act
        var result = await fixture.Contributor.ReadAsync(Engagement(), context, CancellationToken.None);

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        var selected = Assert.Single(result.Value.Sources, source => source.Kind == "policy_communication");
        var opening = Assert.Single(before.Value.Sources, source => source.Kind == "policy_communication");
        if (lateBrokerReceipt)
            Assert.Equal(opening.ContentSha256, selected.ContentSha256);
        else
            Assert.NotEqual(opening.ContentSha256, selected.ContentSha256);
        Assert.Equal(lateBrokerReceipt ? opening.Revision : opening.Revision + 1, selected.Revision);
        Assert.True(receipts.Reads > 0);
    }
''',[
 ('readonly InMemoryEventStore _events = new();','readonly InMemoryEventStore _events = new();\n        public InMemoryEventStore Events => _events;')])
print('Prepared receipt-vs-payload behavioral theories for Application, Mapping and Communication (six rows).')
