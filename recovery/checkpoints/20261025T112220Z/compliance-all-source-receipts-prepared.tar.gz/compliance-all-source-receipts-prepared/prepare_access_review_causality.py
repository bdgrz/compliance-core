from pathlib import Path
p=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features/Examinations/AccessReviewCampaignsTypeIBaselineSourceContributor.cs');s=p.read_text()
s=s.replace('using Bdgrz.Compliance.Features.SourceFacts;','using Bdgrz.Compliance.Features.SourceFacts;\nusing Bdgrz.Compliance.Features.NativeOperations;')
s=s.replace('''                        state.Decisions.Add(pending.Decision);''','''                        if (receiptIncluded == true)
                            await RequireBulkPublicationAsync(context, tenantId, campaignId, settledDecision, pending, ct).ConfigureAwait(false);
                        state.Decisions.Add(pending.Decision);''')
s=s.replace('''                                decisions.Revision)))''','''                                decisions.Revision, NativeFactReference.Of(AccessReviewEffects.ItemStream(tenantId, campaignId, itemId), decisions))))''')
s=s.replace('''sealed record PendingDecision(AccessDecisionView Decision, long Revision);''','''sealed record PendingDecision(AccessDecisionView Decision, long Revision, NativeFactReference Source);''')
needle='''    async ValueTask<(string? Kind, DateTimeOffset At, JsonElement Payload)> ApplyItemFactAsync'''
helper='''    async Task RequireBulkPublicationAsync(TypeIBaselineSourceReadContext context, Uuid tenant, Uuid campaignId,
        AccessReviewItemDecisionSettled settled, PendingDecision pending, CancellationToken ct)
    {
        var cut = context.RequireReceipts(tenant);
        var operationId = settled.Operation.RootOperationId;
        var itemOwner = AccessReviewEffects.ItemStream(tenant, campaignId, settled.ItemId);
        var campaign = await reader.HydrateAsync(new AccessReviewCampaign(tenant, campaignId), ct).ConfigureAwait(false);
        var admitted = campaign.AdmittedFor(operationId)
            ?? throw new ImmutableContentUnavailableException("The settled bulk decision admission is not visible.");
        var admission = NativeFactReference.Of(campaign.Stream, admitted);
        var verifier = new AccessReviewBulkVerifier(reader, content, new AccessReviewManifests(content));
        var verified = await verifier.VerifyAsync(tenant, campaignId, admission, settled.Intent, operationId, ct).ConfigureAwait(false);
        if (verified.Error is { } error)
            throw error.IsTransient ? new ImmutableContentUnavailableException(error.Message)
                : new ImmutableContentIntegrityException(error.Message);
        var intent = verified.Intent!;
        var batch = await reader.HydrateAsync(new AccessReviewDecisionBatch(tenant, campaignId, operationId), ct).ConfigureAwait(false);
        var published = batch.Published ?? throw new ImmutableContentUnavailableException("The settled bulk decision has no visible publication.");
        if (settled.TenantId != tenant || settled.CampaignId != campaignId || settled.Owner != itemOwner ||
            settled.Operation.Owner != itemOwner || settled.Operation.FirstOwner != campaign.Stream ||
            settled.Operation.CausationEventId != admission.EventId || pending.Source.Stream != itemOwner ||
            published.Owner != batch.Stream || published.Operation.Owner != batch.Stream ||
            published.Operation.RootOperationId != operationId || published.Operation.CausationEventId != admission.EventId ||
            published.Generation != AccessReviewEffects.Generation || published.Intent != settled.Intent ||
            batch.Accepted is not { } accepted || accepted.Intent != settled.Intent || published.SourceProofs is null)
            throw new ImmutableContentIntegrityException("The settled bulk decision differs from its exact admitted publication root or owner.");
        if (!(await cut.ReadAsync(campaign.Stream, ct).ConfigureAwait(false)).Includes(admitted))
            throw new ImmutableContentIntegrityException("The settlement receipt cutoff excludes its required campaign admission.");
        var batchReceipts = await cut.ReadAsync(batch.Stream, ct).ConfigureAwait(false);
        if (!batchReceipts.Includes(accepted) || !batchReceipts.Includes(published))
            throw new ImmutableContentIntegrityException("The settlement receipt cutoff excludes its required complete batch publication.");
        var items = await content.ReadJsonAsync<IReadOnlyList<BulkAccessDecisionItemIntent>>(tenant.ToString(), intent.Items.Content, ct)
            .ConfigureAwait(false);
        var proofs = await AccessReviewContent.ReadAsync<IReadOnlyList<BulkItemDecisionProof>>(content, tenant,
            published.SourceProofs, ct).ConfigureAwait(false);
        if (items.Count == 0 || items.Count != intent.Items.Count || intent.Items.ItemsSha256 != intent.Items.Content.Sha256 ||
            proofs.Count != items.Count || items.Select(item => item.ItemId).Distinct().Count() != items.Count ||
            proofs.Select(proof => proof.ItemId).Distinct().Count() != proofs.Count ||
            items.Count(item => item.ItemId == settled.ItemId) != 1)
            throw new ImmutableContentIntegrityException("The published proof set does not cover the exact complete frozen selection.");
        foreach (var selected in items)
        {
            var target = AccessReviewEffects.ItemStream(tenant, campaignId, selected.ItemId);
            var proof = proofs.SingleOrDefault(proof => proof.ItemId == selected.ItemId)
                ?? throw new ImmutableContentIntegrityException("The published proof set omits a selected item.");
            if (selected.ItemOwner != target || proof.Hold.Stream != target || proof.Decision.Stream != target)
                throw new ImmutableContentIntegrityException("A selected bulk proof belongs to another item owner.");
            var source = await cut.ReadAsync(target, ct).ConfigureAwait(false);
            if (!source.Includes(proof.Hold) || !source.Includes(proof.Decision))
                throw new ImmutableContentIntegrityException("The settlement receipt cutoff excludes a selected item's required hold or provisional decision.");
            var held = source.Records.Single(record => record.Event.Metadata.EventId == proof.Hold.EventId).Event;
            var applied = source.Records.Single(record => record.Event.Metadata.EventId == proof.Decision.EventId).Event;
            if (held is not AccessReviewItemDecisionAuthorized hold || hold.Owner != target || hold.TenantId != tenant ||
                hold.CampaignId != campaignId || hold.ItemId != selected.ItemId || hold.Revision != (long)selected.ExpectedItemRevision ||
                hold.Generation != AccessReviewEffects.Generation || hold.Intent != settled.Intent ||
                hold.Operation.Owner != target || hold.Operation.RootOperationId != operationId || hold.Operation.CausationEventId != admission.EventId ||
                applied is not AccessDecisionsRecorded decision || decision.TenantId != tenant || decision.CampaignId != campaignId ||
                decision.ItemId != selected.ItemId || decision.Revision != (long)selected.ExpectedItemRevision + 1 ||
                !decision.PublicationRequired || decision.DecisionBatchId != operationId || decision.Intent != settled.Intent ||
                decision.Operation.Owner != target || decision.Operation.RootOperationId != operationId || decision.Operation.CausationEventId != admission.EventId ||
                selected.ItemId == settled.ItemId && proof.Decision != pending.Source)
                throw new ImmutableContentIntegrityException("The publication proof differs from its exact selected hold or provisional native decision.");
        }
    }

'''
assert needle in s;s=s.replace(needle,helper+needle);p.write_text(s)
print('Saved complete bulk-publication/admission/selected-proof receipt causal closure guard.')
