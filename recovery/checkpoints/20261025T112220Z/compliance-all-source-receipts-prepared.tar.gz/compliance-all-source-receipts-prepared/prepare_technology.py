from pathlib import Path
P=Path('/tmp/compliance-all-source-receipts-prepared/work/src/Compliance.Core/Features/Examinations')
for name,key in [('InformationAsset','assetId'),('TechnologyComponent','componentId'),('DataFlow','flowId')]:
 p=P/(name+'TypeIBaselineSourceContributor.cs');s=p.read_text()
 if name!='DataFlow':
  needle='            var version = history.Value.LastOrDefault(revision => revision.ChangedAt <= through);';assert needle in s,name
  s=s.replace(needle,'''            var eligibleHistory = history.Value;
            if (context.RecordedThrough is not null)
            {
                var receipts = await context.RequireReceipts(engagement.TenantId).ReadAsync(new(engagement.TenantId.ToString(),
                    TechnologyInventoryStreams.Area,'''+key+'''.ToString()),ct).ConfigureAwait(false);
                eligibleHistory = history.Value.Where(revision => receipts.Includes(revision)).ToArray();
            }
            else
                eligibleHistory = history.Value.Where(revision => revision.ChangedAt <= through).ToArray();
            var version = eligibleHistory.LastOrDefault();''')
 else:
  needle='''            var throughRevision = history.Value.Where(revision => revision.ChangedAt <= through)
                .ToArray();''';assert needle in s
  s=s.replace(needle,'''            var eligibleHistory = history.Value;
            if (context.RecordedThrough is not null)
            {
                var receipts = await context.RequireReceipts(engagement.TenantId).ReadAsync(new(engagement.TenantId.ToString(),
                    TechnologyInventoryStreams.Area,flowId.ToString()),ct).ConfigureAwait(false);
                eligibleHistory = history.Value.Where(revision => receipts.Includes(revision)).ToArray();
            }
            else
                eligibleHistory = history.Value.Where(revision => revision.ChangedAt <= through).ToArray();
            var throughRevision = eligibleHistory.ToArray();''')
  s=s.replace('history.Value.Any(revision => revision.ChangedAt > through &&','history.Value.Any(revision => !eligibleHistory.Contains(revision) &&')
 p.write_text(s)
