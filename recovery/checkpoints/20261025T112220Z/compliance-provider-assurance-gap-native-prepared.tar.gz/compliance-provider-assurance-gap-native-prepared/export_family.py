from pathlib import Path
import json,hashlib,difflib,re,subprocess,shutil
r=Path('/tmp/compliance-provider-assurance-gap-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
h=lambda b:hashlib.sha256(b).hexdigest()
meta={v['path']:v for v in json.loads((r/'baselines.json').read_text())}
shared={'src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs'}
red={
 'test/Compliance.Tests/Features/Providers/ProviderGapNativeBoundaryTests.cs':r/'qualified-old-api-ProviderGapNativeBoundaryTests.cs',
 'test/Compliance.Tests/Features/Providers/ProviderGapPreparationRaceTests.cs':r/'old-api-ProviderGapPreparationRaceTests.cs',
 'test/Compliance.Tests/Features/Providers/ProviderGapCapturedProofTests.cs':r/'old-api-ProviderGapCapturedProofTests.cs',
 'test/Compliance.Tests/Features/Providers/ProviderGapReceiverPreparationTests.cs':r/'old-api-ProviderGapReceiverPreparationTests.cs',
}
rows=[];clean={};afterred={};after={}
for f in sorted((r/'work').rglob('*')):
 if not f.is_file():continue
 p=str(f.relative_to(r/'work'));b=r/'base'/p
 if b.exists() and f.read_bytes()==b.read_bytes():continue
 old=b.read_bytes() if b.exists() else None;v=meta.get(p,{})
 if (repo/p).exists() and old is None:raise RuntimeError('Existing repository path missing original before '+p)
 if old is not None and h(old)!=v['beforeSha256']:raise RuntimeError('Original baseline hash mismatch '+p)
 c=None if v.get('cleanBaselineAbsent') else old
 ar=red[p].read_bytes() if p in red else old
 clean[p]=c;afterred[p]=ar;after[p]=f.read_bytes()
 oldnames=re.findall(r'\b(Should\w+)\s*\(',old.decode()) if old and p.startswith('test/') else []
 newnames=re.findall(r'\b(Should\w+)\s*\(',f.read_text()) if p.startswith('test/') else []
 if any(n not in newnames for n in oldnames):raise RuntimeError('Acceptance name removed '+p)
 group='shared' if p in shared else 'tests' if p.startswith('test/') else 'implementation'
 rows.append({'path':p,'group':group,'originalBeforeSha256':h(old) if old is not None else None,'cleanBeforeSha256':h(c) if c is not None else None,'afterRedBeforeSha256':h(ar) if ar is not None else None,'afterSha256':h(after[p]),'baselineSource':v.get('baselineSource','new path; absent from current main at freeze'),'cleanBaselineAbsent':bool(v.get('cleanBaselineAbsent')),'originalAcceptanceNames':oldnames,'afterAcceptanceNames':newnames})
def patch(before,paths):
 out=[]
 for p in paths:
  old=before[p];new=after[p]
  out.append(f'diff --git a/{p} b/{p}\n')
  if old is None:out.append('new file mode 100644\n')
  out.extend(difflib.unified_diff(old.decode().splitlines(True) if old is not None else [],new.decode().splitlines(True),fromfile='a/'+p if old is not None else '/dev/null',tofile='b/'+p,n=3))
 return ''.join(out)
paths=[v['path'] for v in rows];groups={g:[v['path'] for v in rows if v['group']==g] for g in ['implementation','shared','tests']}
patches={
 'implementation.patch':patch(clean,groups['implementation']),
 'shared.patch':patch(clean,groups['shared']),
 'tests.clean.patch':patch(clean,groups['tests']),
 'tests.after-red.patch':patch(afterred,groups['tests']),
 'full.clean.patch':patch(clean,paths),
 'full.after-red.patch':patch(afterred,paths),
}
for name,data in patches.items():(r/name).write_text(data)
reconstructed=[]
for stage,before,names in [('full-clean',clean,['full.clean.patch']),('full-after-red',afterred,['full.after-red.patch']),('partition-clean',clean,['implementation.patch','shared.patch','tests.clean.patch']),('partition-after-red',afterred,['implementation.patch','shared.patch','tests.after-red.patch'])]:
 target=r/'reconstruction'/stage
 if target.exists():shutil.rmtree(target)
 target.mkdir(parents=True)
 for p,data in before.items():
  if data is not None:(target/p).parent.mkdir(parents=True,exist_ok=True);(target/p).write_bytes(data)
 for name in names:
  done=subprocess.run(['patch','--batch','--silent','-p1','-i',str(r/name)],cwd=target,capture_output=True,text=True)
  if done.returncode:raise RuntimeError(stage+' '+name+' '+done.stdout+done.stderr)
 for p,data in after.items():
  if (target/p).read_bytes()!=data:raise RuntimeError('Reconstruction mismatch '+stage+' '+p)
 reconstructed.append({'stage':stage,'patches':names,'exactPaths':len(paths),'result':'all bytes equal work/after SHA256'})
(r/'manifest.json').write_text(json.dumps({'status':'FROZEN','qualification':'Offline preparation only; parent owns actual runtime/strict analyzers/HTTP/full/Jev/delivery.','paths':rows},indent=2)+'\n')
(r/'reconstruction.json').write_text(json.dumps(reconstructed,indent=2)+'\n')
(r/'patch-sha256.json').write_text(json.dumps({name:h((r/name).read_bytes()) for name in patches},indent=2)+'\n')
print(json.dumps({'paths':len(rows),'groups':{g:len(ps) for g,ps in groups.items()},'newPaths':sum(v['originalBeforeSha256'] is None for v in rows),'originalAcceptanceNames':sum(len(v['originalAcceptanceNames']) for v in rows),'manifestSha256':h((r/'manifest.json').read_bytes()),'reconstruction':reconstructed},indent=2))
