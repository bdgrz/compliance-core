from pathlib import Path
r=Path('/tmp/compliance-provider-assurance-gap-native-prepared/work/src/Compliance.Core/Features/Providers')
p=r/'LinkProviderCoverageGapRiskAcceptanceHandler.cs';s=p.read_text();a=s.index('        var prior = await reader.HydrateAsync');b=s.index('        var accepted = await operations.ExecuteAsync',a)
s=s[:a]+'''        ImmutableContentRef? intent = null;
        ProviderGapPreparedCut? preparedCut = null;
''' +s[b:]
a=s.index('            owner =>\n            {',s.index('var accepted = await operations.ExecuteAsync'));b=s.index('            context, ct).ConfigureAwait(false);',a)
s=s[:a]+'''            async (owner, token) =>
            {
                preparedCut = ProviderGapPreparedCut.Capture(owner);
                var frozen = await FreezeAsync(request, owner, provenance, now, token).ConfigureAwait(false);
                if (!frozen.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(frozen.Error!);
                intent = frozen.Value.Intent;
                return Result<FirstResponseDescriptor>.Success(frozen.Value.Response);
            },
            (ProviderAssuranceGap owner, ImmutableContentRef acknowledgment) =>
            {
                var guarded = owner.PrepareAdmitLink(request.ExpectedGapRevision, request.RiskId, request.AcceptanceId);
                if (!guarded.IsSuccess)
                    return guarded;
                return preparedCut is null || !preparedCut.Matches(owner) ? ProviderGapPreparedCut.Changed()
                    : owner.AdmitLink(provenance, request.ExpectedGapRevision, request.RiskId, request.AcceptanceId,
                        intent!, acknowledgment);
            }),
''' +s[b:]
s=s.replace('new(request.TenantId, request.ProviderId, request.GapId, request.CommandId);','new(request.TenantId, request.ProviderId, request.GapId, request.CommandId,\n            selectedPair: ProviderAssuranceGap.PairEpisode(request.RiskId, request.AcceptanceId));')
for exc in ['ImmutableContentIntegrityException exception','ImmutableContentIntegrityException failure','SourceFactVerificationException exception']:
 s=s.replace(f'catch ({exc})\n        {{',f'catch ({exc})\n        {{\n            ct.ThrowIfCancellationRequested();')
p.write_text(s)
# Existing preparation bodies move intact into NativeOperationExecutor async Prepare.
for name in ['RecordProviderCoverageGapHandler','CloseProviderCoverageGapHandler']:
 p=r/(name+'.cs');s=p.read_text();s=s.replace('(NativeOperationExecutor operations, IAggregateReader reader,\n    AssuranceReferences references', '(NativeOperationExecutor operations, AssuranceReferences references')
 s=s.replace('        var prior = await reader.HydrateAsync(Owner(request), ct).ConfigureAwait(false);\n','').replace('        FirstResponseDescriptor? response = null;\n','')
 a=s.index('        if (prior.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');body_start=s.index('        {\n',a)+len('        {\n');body_end=s.index('\n        }\n        var accepted = await operations.ExecuteAsync',body_start)
 body=s[body_start:body_end].replace('prior.','owner.').replace(', ct)',', token)').replace(' ct).ConfigureAwait', ' token).ConfigureAwait')
 body=body.replace('Result<ProviderCoverageGapRegistration>.Failure','Result<FirstResponseDescriptor>.Failure')
 body=body.replace('return Fail(RequestErrorKind.NotFound, "The provider coverage gap was not found.");','return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The provider coverage gap was not found."));')
 body=body.replace('response = ProviderAssuranceContent.Completed(', 'return Result<FirstResponseDescriptor>.Success(ProviderAssuranceContent.Completed(')
 body=body.replace('ProviderAssuranceContent.GapRegistrationSchema);', 'ProviderAssuranceContent.GapRegistrationSchema));')
 # Catch block ct checks reference the async preparation token.
 body=body.replace('catch (ImmutableContentIntegrityException exception)\n            {','catch (ImmutableContentIntegrityException exception)\n            {\n                token.ThrowIfCancellationRequested();')
 s=s[:a]+'        ProviderGapPreparedCut? preparedCut = null;\n'+s[body_end+len('\n        }\n'):]
 a=s.index('            owner =>\n            {',s.index('var accepted = await operations.ExecuteAsync'));b=s.index('        return await ProviderAssuranceContent.ReadFirstResponseAsync',a)
 oldapply=s[a:b]
 # Replace both Prepare and Apply explicitly, keeping public business checks first on the fresh append owner.
 if name.startswith('Record'):
  apply='''                var guarded = owner.PrepareRecord();
                if (!guarded.IsSuccess)
                    return guarded;
                return preparedCut is null || !preparedCut.Matches(owner) ? ProviderGapPreparedCut.Changed()
                    : owner.Record(provenance, providerRevision, contentRef!, actor, now, frozen, resultRef!);'''
 else:
  apply='''                var guarded = owner.PrepareClose(request.ExpectedRevision, recorded!, normalized);
                if (!guarded.IsSuccess)
                    return guarded;
                return preparedCut is null || !preparedCut.Matches(owner) ? ProviderGapPreparedCut.Changed()
                    : owner.Close(provenance, request.ExpectedRevision, recorded!, normalized, contentRef!, actor, now,
                        frozen, resultRef!);'''
 replacement='''            async (owner, token) =>
            {
                preparedCut = ProviderGapPreparedCut.Capture(owner);
'''+''.join('    '+line+'\n' for line in body.splitlines())+'''            },
            (ProviderAssuranceGap owner, ImmutableContentRef frozen) =>
            {
'''+apply+'''
            }), context, ct).ConfigureAwait(false);
'''
 s=s[:a]+replacement+s[b:];p.write_text(s)
