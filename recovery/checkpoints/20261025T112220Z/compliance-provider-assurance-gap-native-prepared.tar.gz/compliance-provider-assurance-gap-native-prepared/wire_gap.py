from pathlib import Path
r=Path('/tmp/compliance-provider-assurance-gap-native-prepared/work')
p=r/'src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';s=p.read_text();assert s.count('services.AddScoped<ProviderSource>();')==1;s=s.replace('services.AddScoped<ProviderSource>();','services.AddScoped<ProviderSource>();\n        services.AddScoped<ProviderGapReader>();');p.write_text(s)
p=r/'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.Providers;\n'+s;anchor='        Decorate<IRequestBus>(services, (_, inner) => new PersistenceValidationRequestBus(inner));';assert s.count(anchor)==1;s=s.replace(anchor,'        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new ProviderGapAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n'+anchor);p.write_text(s)
p=r/'test/Compliance.Tests/Features/Providers/ProviderGapNativeBoundaryTests.cs';s=p.read_text();s=s.replace('using Bdgrz.Compliance.Tests.Testing;','using Bdgrz.Compliance.Tests.Testing;\nusing Microsoft.Extensions.DependencyInjection;');s=s.replace('var gap = await host.GapAsync(registration.GapId);','await using var scope = host.Services.CreateAsyncScope();\n        var gap = await scope.ServiceProvider.GetRequiredService<ProviderGapReader>()\n            .ReadAsync(host.Tenant, host.ProviderId, registration.GapId);');s=s.replace('var retained = gap.GetType().GetFields','var retained = gap.Owner.GetType().GetFields').replace('field.GetValue(gap) is ICollection','field.GetValue(gap.Owner) is ICollection');p.write_text(s)
source=Path('/tmp/compliance-policy-campaign-native-prepared/work/test/Compliance.Tests/Testing/VerifiedPolicyCampaignServices.cs').read_text();source=source.replace('Features.PolicyDistribution','Features.Providers').replace('VerifiedPolicyCampaignServices','VerifiedProviderGapServices').replace('AddVerifiedPolicyCampaignReader','AddVerifiedProviderGapReader').replace('PolicyCampaignAggregateReader','ProviderGapAggregateReader').replace('campaign','provider gap')
(r/'test/Compliance.Tests/Testing/VerifiedProviderGapServices.cs').write_text(source)
# Migrate only the gap source fixture to genuine persisted/native history; preserve other owning families.
p=r/'test/Compliance.Tests/Features/Examinations/ProviderTypeIBaselineSourceContributorTests.cs';s=p.read_text();a=s.index('        Assert.True(gap.Record(');b=s.index('\n\n        await AppendAsync',a)
s=s[:a]+'''        var gapAt = assuranceRecordedAt.AddHours(2);
        var gapRequest = new RecordProviderCoverageGap(gapId, TenantId, ProviderId, gapContent);
        var gapBody = await ProviderAssuranceContent.WriteAsync(content, TenantId, ProviderAssuranceContent.GapRecordedSchema,
            gapContent, CancellationToken.None);
        var gapResult = await ProviderAssuranceContent.WriteAsync(content, TenantId, ProviderAssuranceContent.GapRegistrationSchema,
            new ProviderCoverageGapRegistration(gapId, 1), CancellationToken.None);
        var gapResponse = await FirstResponses.FreezeAsync(content, TenantId.ToString(),
            ProviderAssuranceContent.Completed(gapResult, ProviderAssuranceContent.GapRegistrationSchema));
        Assert.True(gap.Record(gap.Provenance(gapId, nameof(RecordProviderCoverageGap), actor, "initial", null,
                AuthoredIntentDigest.Compute(gapRequest), gapAt), 1, gapBody, actor, gapAt, gapResponse, gapResult).IsSuccess);''' +s[b:]
s=s.replace('        collection.AddPortia();','        collection.AddPortia();\n        collection.AddVerifiedProviderGapReader();').replace('aggregate is Provider\n', 'aggregate is Provider or ProviderAssuranceGap\n').replace('Hydrates providers from the real store and every other owner from the fixed instances.', 'Hydrates providers and gaps from their verified real stores; the other owner fixtures retain their fixed instances.')
p.write_text(s)
