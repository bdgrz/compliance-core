using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Providers;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Risks;
using Bdgrz.Compliance.Features.SourceFacts;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Providers;

public sealed class ProviderGapPreparationRaceTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldReplayOriginalAcceptanceOrRequestedCancellationGivenWinnerBeforeLinkIntentWriteFailure(bool cancel)
    {
        // Arrange
        await using var host = await ProviderAssuranceHost.CreateAsync();
        var gap = await host.RecordGapAsync();
        var source = await host.AcceptRiskAsync();
        var request = new LinkProviderCoverageGapRiskAcceptance(Uuid.CreateVersion4(), host.Tenant,
            ProviderAssuranceHost.ProgramId, host.ProviderId, gap.GapId, 1, source.RiskId, source.AcceptanceId);
        var context = new Cntryl.Portia.RequestContext<LinkProviderCoverageGapRiskAcceptance>(request,
            new RequestDispatchContext(ProgramManagementServices.Actor(host.User),
                new HttpInvocation("PUT", "/synthetic/provider-gap", "/synthetic/provider-gap", "synthetic")));
        await using var scope = host.Services.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var healthy = Handler(services, host.Content);
        using var cancellation = new CancellationTokenSource();
        var winner = Result<OperationAcceptedResponse>.Failure(new RequestError(RequestErrorKind.Conflict, "No winner yet."));
        var fault = new FaultStore(host.Content, async () =>
        {
            winner = await healthy.HandleAsync(context, CancellationToken.None);
            Assert.True(winner.IsSuccess, winner.Error?.Message);
            if (cancel)
                cancellation.Cancel();
        });
        var losing = Handler(services, fault);
        var actual = Result<OperationAcceptedResponse>.Failure(new RequestError(RequestErrorKind.Conflict, "Not executed yet."));

        // Act
        var failure = await Record.ExceptionAsync(async () => actual = await losing.HandleAsync(context, cancellation.Token));
        var facts = await host.FactsAsync(ProviderAssuranceStreams.Gap(host.Tenant, host.ProviderId, gap.GapId));

        // Assert
        Assert.True(winner.IsSuccess);
        var admitted = Assert.Single(facts.OfType<ProviderCoverageGapRiskAcceptanceAdmitted>());
        Assert.Equal(request.CommandId, admitted.Operation.LogicalId);
        Assert.Equal(2, admitted.Revision);
        if (cancel)
            Assert.Equal(cancellation.Token, Assert.IsAssignableFrom<OperationCanceledException>(failure).CancellationToken);
        else
        {
            Assert.Null(failure);
            Assert.True(actual.IsSuccess, actual.Error?.Message);
            Assert.Equal(winner.Value, actual.Value);
        }
        Assert.Equal(2, facts.Count);
    }

    static LinkProviderCoverageGapRiskAcceptanceHandler Handler(IServiceProvider services, IImmutableContentStore content) =>
        new(new NativeOperationExecutor(services.GetRequiredService<IAggregateReader>(),
                services.GetRequiredService<IAggregateExecutor>(), content), services.GetRequiredService<IAggregateReader>(),
            services.GetRequiredService<AssuranceReferences>(), services.GetRequiredService<ProviderReadConsistency>(),
            services.GetRequiredService<ISourceFactResolver>(), content, services.GetRequiredService<TimeProvider>(),
            services.GetRequiredService<RiskEvaluationReader>());

    sealed class FaultStore(IImmutableContentStore inner, Func<Task> commitWinner) : IImmutableContentStore
    {
        bool _failed;
        public async Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default)
        {
            if (!_failed && schema == ProviderRiskLinkIntent.Schema)
            {
                _failed = true;
                await commitWinner();
                throw new ImmutableContentUnavailableException("The losing actual risk-link intent write failed.");
            }
            return await inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        }
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default) =>
            inner.ReadVerifiedAsync(realm, reference, ct);
    }
}
