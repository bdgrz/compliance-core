from pathlib import Path
p=Path('/tmp/compliance-provider-assurance-gap-native-prepared/work/src/Compliance.Core/Features/Providers/MaterializeProviderRiskAcceptanceLinkHandler.cs');s=p.read_text().replace('using Bdgrz.Compliance.Features.SourceUse;','using Bdgrz.Compliance.Features.SourceUse;\nusing Bdgrz.Compliance.Features.SourceFacts;\nusing Bdgrz.Compliance.Features.Risks;')
s=s.replace('IImmutableContentStore content, TimeProvider clock)', 'IImmutableContentStore content, TimeProvider clock, ProviderGapReader history, ISourceFactResolver resolver)')
s=s.replace('''    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(
        IRequestContext<MaterializeProviderRiskAcceptanceLink> context, CancellationToken ct)
''','''    public ValueTask<Result<ReceiverOutcome>> HandleAsync(
        IRequestContext<MaterializeProviderRiskAcceptanceLink> context, CancellationToken ct) =>
        ProviderGapFailures.ClassifyAsync(() => HandleCoreAsync(context, ct), ct);

    async ValueTask<Result<ReceiverOutcome>> HandleCoreAsync(
        IRequestContext<MaterializeProviderRiskAcceptanceLink> context, CancellationToken ct)
''')
a=s.index('        ProviderRiskLinkIntent intent;');b=s.index('        for (var attempt = 1; ; attempt++)',a)
s=s[:a]+'''        var gap = await history.ReadFromSourceAsync(request.Source, request.GapId, request.LinkId, ct).ConfigureAwait(false);
        if (gap.AdmissionOf(request.LinkId) is not { } admitted)
            return gap.Facts.Any(value => value.Metadata.EventId == request.Source.EventId)
                ? SourceUseReceiverSupport.Permanent("The source admits another link operation.")
                : SourceUseReceiverSupport.Transient("The admitted link is not visible yet.");
        if (request.Source.Stream != gap.Stream || admitted.Metadata.EventId != request.Source.EventId ||
            admitted.Metadata.AggregateVersion != request.Source.AggregateVersion || admitted.Intent != request.Intent ||
            admitted.Revision != request.Generation)
            return SourceUseReceiverSupport.Permanent("The source is not the admission of this link.");
        var operation = admitted.Operation;
        var header = new DurableIntentHeader(operation.RootOperationId, gap.Stream, gap.Stream, gap.Stream,
            operation.Actor, operation.Episode, operation.OriginalExpectedRevision, operation.AuthoredIntentSha256,
            operation.AcceptedAt);
        // Preserve this receiver's actual existing child binding, including its original optional FirstOwner semantics.
        var provenance = new ProviderRiskAcceptance(tenantId, request.LinkId).Provenance(request.CommandId,
            nameof(MaterializeProviderRiskAcceptanceLink), request.Source.EventId, header, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var preparation = await NativeReceiverPreparation.PrepareAsync<ProviderRiskAcceptance, Prepared>(reader,
            () => new ProviderRiskAcceptance(tenantId, request.LinkId, request.CommandId), owner => Decide(owner, binding),
            (_, token) => PrepareAsync(tenantId, gap, admitted, request, header, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var prepared = preparation.Value.Value!;
''' +s[b:]
s=s.replace('''fresh.Materialize(provenance, intent.GapId, intent.ProviderId, admitted.Revision,
                        acceptance, request.Intent, result)''','''fresh.Materialize(provenance, request.GapId, gap.ProviderId, admitted.Revision,
                        prepared.Acceptance, request.Intent, prepared.Result)''')
pos=s.index('    static Result<ReceiverOutcome>? Decide')
s=s[:pos]+'''    async ValueTask<Result<Prepared>> PrepareAsync(Uuid tenantId, ProviderGapSnapshot gap,
        ProviderCoverageGapRiskAcceptanceAdmitted admitted, MaterializeProviderRiskAcceptanceLink request,
        DurableIntentHeader header, CancellationToken ct)
    {
        ProviderRiskLinkIntent intent;
        try
        {
            intent = await ProviderAssuranceContent.ReadAsync<ProviderRiskLinkIntent>(content, tenantId, request.Intent, ct)
                .ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return Result<Prepared>.Failure(SourceUseReceiverSupport.Permanent(
                $"The frozen link cannot be verified: {exception.Message}").Error!);
        }
        if (intent.Header != header || intent.LinkId != request.LinkId || intent.GapId != request.GapId ||
            intent.ProviderId != gap.ProviderId || intent.GapAdmissionRevision != (ulong)admitted.Revision ||
            intent.ProviderRevision != (ulong)gap.Recorded!.ProviderRevision || intent.LinkedAt != header.AcceptedAt ||
            intent.ProgramId == Uuid.Empty || intent.RiskId == Uuid.Empty || intent.AcceptanceId == Uuid.Empty ||
            header.OriginalExpectedRevision is not { } original || original > long.MaxValue ||
            ProviderAssuranceGap.PairEpisode(intent.RiskId, intent.AcceptanceId) != header.Episode ||
            AuthoredIntentDigest.Compute(new LinkProviderCoverageGapRiskAcceptance(request.LinkId, tenantId,
                intent.ProgramId, gap.ProviderId, request.GapId, (long)original, intent.RiskId, intent.AcceptanceId)) !=
                header.AuthoredIntentSha256 || intent.AcceptanceProof is null ||
            intent.AcceptanceProof.Source != new RiskEvaluation(tenantId, intent.RiskId).Stream)
            return Result<Prepared>.Failure(SourceUseReceiverSupport.Permanent(
                "The frozen link differs from its exact native admission and original authored terms.").Error!);
        var recorded = await ProviderAssuranceContent.ReadAsync<ProviderCoverageGapContent>(content, tenantId,
            gap.Recorded.ContentContent, ct).ConfigureAwait(false);
        if (recorded.ServiceId != intent.ServiceId)
            return Result<Prepared>.Failure(SourceUseReceiverSupport.Permanent(
                "The frozen link names another exact recorded provider service.").Error!);
        VerifiedSourceProof<RiskAccepted> proof;
        try
        {
            proof = await resolver.VerifyAsync(intent.AcceptanceProof, ct).ConfigureAwait(false);
        }
        catch (SourceFactVerificationException exception)
        {
            ct.ThrowIfCancellationRequested();
            return Result<Prepared>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The captured risk acceptance proof cannot be verified: " + exception.Message,
                exception is SourceFactUnavailableException));
        }
        var fact = proof.Facts;
        if (fact.TenantId != tenantId || fact.ProgramId != intent.ProgramId || fact.RiskId != intent.RiskId ||
            fact.Header.LatestAcceptanceId != intent.AcceptanceId)
            return Result<Prepared>.Failure(SourceUseReceiverSupport.Permanent(
                "The captured source is another exact risk acceptance.").Error!);
        var accepted = await RiskEvaluationContent.ReadAcceptanceAsync(content, fact, ct).ConfigureAwait(false);
        if (accepted.AcceptanceId != intent.AcceptanceId || accepted.ExpiresAt != intent.AcceptanceExpiresAt ||
            accepted.AcceptedAt > intent.LinkedAt || intent.AcceptanceExpiresAt <= intent.LinkedAt)
            return Result<Prepared>.Failure(SourceUseReceiverSupport.Permanent(
                "The captured acceptance was not active at the original link admission instant.").Error!);
        var view = new ProviderCoverageGapRiskAcceptanceView(intent.ProgramId, intent.RiskId, intent.AcceptanceId,
            intent.AcceptanceExpiresAt, header.OriginalActor, intent.LinkedAt) { Revision = admitted.Revision };
        var acceptance = await ProviderAssuranceContent.WriteAsync(content, tenantId, ProviderAssuranceContent.LinkSchema,
            view, ct, Uuid.CreateVersion5(request.CommandId, ProviderAssuranceContent.LinkSchema)).ConfigureAwait(false);
        var result = await ProviderAssuranceContent.WriteAsync(content, tenantId, ProviderAssuranceContent.GapRegistrationSchema,
            new ProviderCoverageGapRegistration(request.GapId, admitted.Revision), ct,
            Uuid.CreateVersion5(request.CommandId, ProviderAssuranceContent.GapRegistrationSchema)).ConfigureAwait(false);
        return Result<Prepared>.Success(new Prepared(acceptance, result));
    }

''' +s[pos:]
s=s.replace('    sealed record Decision(Result<ReceiverOutcome> Outcome);','''    sealed record Prepared(ImmutableContentRef Acceptance, ImmutableContentRef Result);

    sealed record Decision(Result<ReceiverOutcome> Outcome);''')
p.write_text(s)
