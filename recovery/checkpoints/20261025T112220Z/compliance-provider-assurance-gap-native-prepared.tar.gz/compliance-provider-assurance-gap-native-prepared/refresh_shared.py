from pathlib import Path
import json,hashlib
r=Path('/tmp/compliance-provider-assurance-gap-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');meta=json.loads((r/'baselines.json').read_text())
ps=['src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','docs/product/aggregate-boundary-ledger.md']
for p in ps:
 data=(repo/p).read_bytes()
 for tree in ['base','work']:(r/tree/p).write_bytes(data)
 row=next(v for v in meta if v['path']==p);row['beforeSha256']=hashlib.sha256(data).hexdigest();row['baselineSource']=str(repo/p)+' (current parent Policy244-focus/59HTTP green source; parent composes subsequent narrow wiring)'
p=r/'work'/ps[0];s=p.read_text();assert s.count('services.AddScoped<ProviderSource>();')==1;s=s.replace('services.AddScoped<ProviderSource>();','services.AddScoped<ProviderSource>();\n        services.AddScoped<ProviderGapReader>();');p.write_text(s)
p=r/'work'/ps[1];s=p.read_text();s='using Bdgrz.Compliance.Features.Providers;\n'+s;anchor='        Decorate<IRequestBus>(services, (_, inner) => new PersistenceValidationRequestBus(inner));';assert s.count(anchor)==1;s=s.replace(anchor,'        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new ProviderGapAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n'+anchor);p.write_text(s)
p=r/'work'/ps[2];s=p.read_text();lines=s.splitlines(True)
for i,line in enumerate(lines):
 if line.startswith('| `ProviderAssuranceGap` |'):
  cells=line.rstrip('\n').split(' | ');cells[-1]='Independent per-gap stream; current record/closure/revision and explicit selected pair/admission/acceptance at a verified exact native cut. Full transient replay preserves all historical pair/logical uniqueness; complete admissions are composed by ProviderGapReader outside the command owner. |';lines[i]=' | '.join(cells)+'\n'
 if line.startswith('| `ProviderAssuranceReport`, `ProviderAssuranceReview`, `ProviderAssuranceGap`, `ProviderRiskAcceptance` |'):
  cells=line.rstrip('\n').split(' | ');cells[-2]='state per owner only; gap retains bounded current/selected authority, complete verified native admissions outside the owner, no history cap; exact RiskAccepted proof and original historical materialization retained';lines[i]=' | '.join(cells)+'\n'
p.write_text(''.join(lines));(r/'baselines.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps({p:hashlib.sha256((r/'base'/p).read_bytes()).hexdigest() for p in ps},indent=2))
