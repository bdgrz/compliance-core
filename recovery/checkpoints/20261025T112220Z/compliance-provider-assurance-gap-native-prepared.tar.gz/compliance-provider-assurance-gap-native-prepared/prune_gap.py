from pathlib import Path
r=Path('/tmp/compliance-provider-assurance-gap-native-prepared/work/src/Compliance.Core/Features/Providers')
p=r/'ProviderAssuranceGap.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.AccessControl;','using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Content;')
s=s.replace('''    readonly HashSet<string> _admittedPairs = new(StringComparer.Ordinal);
    readonly Dictionary<Uuid, ProviderCoverageGapRiskAcceptanceAdmitted> _admissions = [];''','''    readonly ProviderGapReplayCut _cut = new();''')
s=s.replace('Uuid gapId, Uuid selectedLogicalId = default)', 'Uuid gapId, Uuid selectedLogicalId = default,\n        Uuid selectedAdmissionId = default, string? selectedPair = null)')
s=s.replace('        Acceptance = new NativeAcceptance(selectedLogicalId);','''        Acceptance = new NativeAcceptance(selectedLogicalId);
        SelectedAdmissionId = selectedAdmissionId;
        SelectedPair = selectedPair;''')
for name in ['recorded','closed','admitted']:
 s=s.replace(f'            Acceptance.Observe({name});',f'''            if ({name}.Operation is null)
                throw new ImmutableContentIntegrityException("The native provider gap fact lacks operation provenance.");
            if (Acceptance.SelectedFact is not null && Acceptance.SelectedLogicalId == {name}.Operation.LogicalId)
                throw new ImmutableContentIntegrityException("The selected native provider gap operation occurs more than once.");
            Acceptance.Observe({name});''')
s=s.replace('''                admitted.Revision != _revision + 1 || admitted.Operation.Owner != Stream ||
                !_admittedPairs.Add(admitted.Operation.Episode) ||
                !_admissions.TryAdd(admitted.Operation.LogicalId, admitted))''','''                admitted.Revision != _revision + 1 || admitted.Operation.Owner != Stream)''')
s=s.replace('            _revision = admitted.Revision;','''            _revision = admitted.Revision;
            if (admitted.Operation.LogicalId == SelectedAdmissionId)
                SelectedAdmission = admitted;''')
s=s.replace('new InvalidOperationException(', 'new ImmutableContentIntegrityException(')
a=s.index('    /// <summary>The admission of one link')
b=s.index('    /// <summary>The wire form',a)
s=s[:a]+'''    internal ProviderGapReplayCut ReplayCut => _cut;
    internal Uuid TenantId => _tenantId;
    internal Uuid SelectedAdmissionId { get; }
    internal ProviderCoverageGapRiskAcceptanceAdmitted? SelectedAdmission { get; set; }
    internal string? SelectedPair { get; }
    internal bool SelectedPairSeen { get; set; }

''' +s[b:]
s=s.replace('''        return _admittedPairs.Contains(PairEpisode(riskId, acceptanceId))
            ? Result.Failure''','''        if (SelectedPair != PairEpisode(riskId, acceptanceId))
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "A link admission requires its exact selected pair at the finalized native gap cut.", true));
        return SelectedPairSeen
            ? Result.Failure''')
# Insert cut gate immediately before every single-fact append; fresh empty owner can prove local absence.
for marker in ['        RaiseEvent(new ProviderCoverageGapRecorded(', '        RaiseEvent(new ProviderCoverageGapClosed(', '        var revision = _revision + 1;']:
 assert s.count(marker)==1,marker
 s=s.replace(marker,'''        var append = _cut.Require(this, Acceptance, operation);
        if (!append.IsSuccess)
            return append;
'''+marker)
pos=s.index('    /// <summary>The provenance of an operation')
s=s[:pos]+'''    protected override void Apply(DomainEvent ev)
    {
        _cut.Observe(ev);
        base.Apply(ev);
    }

''' +s[pos:]
p.write_text(s)
frozen=Path('/tmp/compliance-policy-campaign-native-prepared/work/src/Compliance.Core/Features/PolicyDistribution')
for old,new in [('PolicyCampaignReplayDigest','ProviderGapReplayDigest'),('PolicyCampaignReplayCut','ProviderGapReplayCut')]:
 text=(frozen/(old+'.cs')).read_text().replace('Bdgrz.Compliance.Features.PolicyDistribution','Bdgrz.Compliance.Features.Providers').replace('PolicyCampaignReplayDigest','ProviderGapReplayDigest').replace('PolicyCampaignReplayCut','ProviderGapReplayCut').replace('policy campaign','provider gap')
 (r/(new+'.cs')).write_text(text)
