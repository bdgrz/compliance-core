using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Providers;

/// <summary>
///     The open provider coverage gap was closed once, against a newer or different source. The complete
///     <see cref="ProviderCoverageGapClosureContent" /> is immutable content. A closure never erases an already
///     admitted risk link.
/// </summary>
[Discriminator("bdgrz.provider.coverage_gap.closed", 1)]
public sealed record ProviderCoverageGapClosed(Uuid TenantId, Uuid GapId, Uuid ProviderId, Uuid RequestId,
    long Revision, ImmutableContentRef ContentContent, ActorReference Actor, DateTimeOffset ClosedAt,
    OperationProvenance Operation, ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult)
    : DomainEvent, INativeOperationFact;
