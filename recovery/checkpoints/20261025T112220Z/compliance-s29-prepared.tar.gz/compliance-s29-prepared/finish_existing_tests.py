from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work');folder='test/Compliance.Tests/Features/AuditPackages/'
p=root/(folder+'AuditPackageTests.cs');s=p.read_text().replace('using AuditPackageAggregate = Bdgrz.Compliance.Features.AuditPackages.AuditPackage;','using AuditPackageAggregate = Bdgrz.Compliance.Features.AuditPackages.AuditPackageRules;')
s='''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Hosting.Persistence;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz.Testing;
using Microsoft.Extensions.DependencyInjection;
'''+s
s=s.replace('public void ShouldReplayCompletePackageHistoryGivenEvents()','public async Task ShouldReplayCompletePackageHistoryGivenEvents()')
old='''        var replay = new AggregateScenario<AuditPackageAggregate>(
            new AuditPackageAggregate(TenantId, ProgramId, PackageId)).Given(
                new AggregateScenario<AuditPackageAggregate>(package).PendingEvents.ToArray());
        var packageState = package.Current!;
        var replayedState = replay.Aggregate.Current!;'''
new='''        var services = new ServiceCollection();
        services.AddSingleton<IEventStore>(new InMemoryEventStore());
        services.AddPortia();
        await using var provider = services.BuildServiceProvider();
        await using var scope = provider.CreateAsyncScope();
        var content = new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient()));
        var writer = scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
        var reader = scope.ServiceProvider.GetRequiredService<IAggregateReader>();
        await PackageSeeds.WriteAsync(writer, content, package.Current!);
        var replay = await new AuditPackageReader(reader, content).ReadAsync(TenantId, ProgramId, PackageId,
            CancellationToken.None);
        var packageState = package.Current!;
        var replayedState = replay.View!;'''
assert old in s;s=s.replace(old,new)
p.write_text(s)
# Materialization is an explicit internal receiver stage, not an inline public command side effect.
p=root/(folder+'AuditPackageCommandHandlerTests.cs');s=p.read_text()
s=s.replace('''        var saved = await fixture.ReadPackageAsync(packageId);

        // Assert
        Assert.True(approved.IsSuccess''','''        await fixture.MaterializeDeliveriesAsync(packageId);
        var saved = await fixture.ReadPackageAsync(packageId);

        // Assert
        Assert.True(approved.IsSuccess''',1)
s=s.replace('''        public async Task<Uuid> SeedDraftPackageAsync()''','''        public async Task MaterializeDeliveriesAsync(Uuid packageId)
        {
            var owner = (await Packages.ReadAsync(TenantId, ProgramId, packageId, CancellationToken.None)).Owner;
            foreach (var fact in owner.Facts.OfType<AuditPackageDeliveryAdmitted>())
            {
                var command = new MaterializeRecordedAuditPackageDelivery(
                    Uuid.CreateVersion5(fact.Metadata.EventId, "test-materialize"),
                    NativeFactReference.Of(owner.Stream, fact), new AuditPackageDelivery(TenantId, packageId,
                        fact.PackageVersion, fact.Operation.LogicalId).Stream, fact.Operation.LogicalId,
                    fact.PackageVersion, null, fact.Intent, packageId, fact.Operation.LogicalId, fact.PackageVersion);
                var handler = new MaterializeRecordedAuditPackageDeliveryHandler(
                    new AuditPackageSourceVerifier(Reader, ContentStore), Reader,
                    new Bdgrz.Compliance.Features.Processes.ReceiverAppend(Executor), _clock);
                var result = await handler.HandleAsync(new Cntryl.Portia.RequestContext<MaterializeRecordedAuditPackageDelivery>(
                    command, new RequestDispatchContext(RequestActor.System)), CancellationToken.None);
                Assert.True(result.IsSuccess, result.Error?.Message);
            }
        }

        public async Task<Uuid> SeedDraftPackageAsync()''')
p.write_text(s)
# Source byte storage is a distinct prerequisite from the built ZIP, exposed for the native worker regressions.
p=root/(folder+'AmendAuditPackageHandlerTests.cs');s=p.read_text()
s=s.replace('''        public async Task<TypeIBaselineView> SeedBaselineAsync()''','''        public async Task SeedSourceBytesAsync()
        {
            await ArtifactStore.StoreIfAbsentAsync(TenantId, new MemoryStream(SourceBytes1));
            await ArtifactStore.StoreIfAbsentAsync(TenantId, new MemoryStream(SourceBytes2));
        }

        public async Task<TypeIBaselineView> SeedBaselineAsync()''')
p.write_text(s)
# Read projection metadata supports existing pure validation rules; it never stores worker failure/progress facts.
p=root/'src/Compliance.Core/Features/AuditPackages/AuditPackageReader.cs';s=p.read_text()
s=s.replace('ArchiveSha256 = change.Output.ArchiveSha256, ArchiveBytes = change.Output.ArchiveBytes };','''ArchiveSha256 = change.Output.ArchiveSha256, ArchiveBytes = change.Output.ArchiveBytes,
                        ResultFingerprint = Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(
                            System.Text.Json.JsonSerializer.SerializeToUtf8Bytes(change.Output,
                                ComplianceCoreJsonContext.Default.AuditPackageBuildOutput))) };''')
s=s.replace('''                    versions[index] = versions[index] with {
                        DisclosureApprovals = [.. versions[index].DisclosureApprovals, approval] };''','''                    if (versions[index].DisclosureApprovals.All(item => item.DisclosureApprovalId != approval.DisclosureApprovalId))
                        versions[index] = versions[index] with { Status = "disclosure_approved",
                            DisclosureApprovals = [.. versions[index].DisclosureApprovals, approval] };''')
s=s.replace('''                    versions[index] = versions[index] with { Status = validation.Status == "blocked" ? "validation_blocked" : "validated",
                        Validations = [.. versions[index].Validations, validation] };''','''                    if (versions[index].Validations.All(item => item.AuditPackageValidationId != validation.AuditPackageValidationId))
                        versions[index] = versions[index] with { Status = validation.Status == "blocked" ? "validation_blocked" : "validated",
                            Validations = [.. versions[index].Validations, validation] };''')
s=s.replace('''                    var overrides = validations[validationIndex].Overrides.Append(change.Override).ToArray();''','''                    if (validations[validationIndex].Overrides.Any(item => item.FindingId == change.Override.FindingId))
                        break;
                    var overrides = validations[validationIndex].Overrides.Append(change.Override).ToArray();''')
p.write_text(s)
