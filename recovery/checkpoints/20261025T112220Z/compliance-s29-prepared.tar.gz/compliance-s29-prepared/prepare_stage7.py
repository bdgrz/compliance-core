from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
def write(path,text):
 p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text.strip()+'\n')
core='src/Compliance.Core/Features/AuditPackages/'
write(core+'AuditPackageBuildProcess.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Technical ordered build stages; retries and failures never become manifest business facts.</summary>
public static class AuditPackageBuildProcess
{
    public const string Name = nameof(AuditPackageBuildProcess);
    public static ProcessDefinition Definition() => new(Name, [nameof(AuditPackageBuildRequestedV2)], true,
        [new ProcessStageDefinition("start", [nameof(StartAuditPackageBuild)], PerTarget: false),
            new ProcessStageDefinition("record", [nameof(RecordAuditPackageBuildResultV2)], PerTarget: false)], [],
        CreateAsync);

    static async ValueTask<IRequest<ReceiverOutcome>?> CreateAsync(ProcessStep step, IServiceProvider services,
        CancellationToken ct)
    {
        var tenant = Uuid.Parse(step.Record.Key.Realm, CultureInfo.InvariantCulture);
        var content = services.GetRequiredService<IImmutableContentStore>();
        var intent = await PackageContent.ReadAsync<PackageBuildIntent>(content, tenant, step.Record.Intent, ct)
            .ConfigureAwait(false);
        var target = new AuditPackageManifest(tenant, intent.PackageId).Stream;
        if (step.Receiver == nameof(StartAuditPackageBuild))
            return new StartAuditPackageBuild(step.CommandId, step.Record.Source, target,
                step.Record.Key.RootOperationId, intent.PackageVersion, null, step.Record.Intent,
                intent.PackageId, intent.BuildId, intent.PackageVersion);
        if (step.Receiver != nameof(RecordAuditPackageBuildResultV2))
            return null;
        var checkpoint = await services.GetRequiredService<IAuditPackageBuildOutputs>().ReadAsync(tenant,
            intent.BuildId, ct).ConfigureAwait(false);
        if (checkpoint is null)
            throw new SourceFactVerificationException("The successful build checkpoint is not visible yet.");
        if (checkpoint.Source != step.Record.Source || checkpoint.Intent != step.Record.Intent)
            throw new ImmutableContentIntegrityException("The build checkpoint belongs to another admitted source.");
        var output = await PackageContent.ReadAsync<AuditPackageBuildOutput>(content, tenant,
            checkpoint.VerifiedOutput, ct).ConfigureAwait(false);
        return new RecordAuditPackageBuildResultV2(step.CommandId, step.Record.Source, target,
            step.Record.Key.RootOperationId, intent.PackageVersion, null, step.Record.Intent,
            intent.PackageId, intent.BuildId, output);
    }
}
''')
write(core+'AuditPackageDeliveryRecordingProcess.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Processes;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Independent historical delivery materialization with no external send or abort stage.</summary>
public static class AuditPackageDeliveryRecordingProcess
{
    public const string Name = nameof(AuditPackageDeliveryRecordingProcess);
    public static ProcessDefinition Definition() => new(Name, [nameof(AuditPackageDeliveryAdmitted)], false,
        [new ProcessStageDefinition("materialize", [nameof(MaterializeRecordedAuditPackageDelivery)], PerTarget: false)],
        [], CreateAsync);

    static async ValueTask<IRequest<ReceiverOutcome>?> CreateAsync(ProcessStep step, IServiceProvider services,
        CancellationToken ct)
    {
        if (step.Receiver != nameof(MaterializeRecordedAuditPackageDelivery))
            return null;
        var tenant = Uuid.Parse(step.Record.Key.Realm, CultureInfo.InvariantCulture);
        var intent = await PackageContent.ReadAsync<PackageDeliveryRecordingIntent>(
            services.GetRequiredService<IImmutableContentStore>(), tenant, step.Record.Intent, ct).ConfigureAwait(false);
        return new MaterializeRecordedAuditPackageDelivery(step.CommandId, step.Record.Source,
            new AuditPackageDelivery(tenant, intent.PackageId, intent.PackageVersion, intent.DeliveryId).Stream,
            step.Record.Key.RootOperationId, intent.PackageVersion, null, step.Record.Intent,
            intent.PackageId, intent.DeliveryId, intent.PackageVersion);
    }
}
''')
for cls,trigger,process,field in [('AuditPackageBuildProcessReactor','AuditPackageBuildRequestedV2','AuditPackageBuildProcess','Change'),('AuditPackageDeliveryAdmissionReactor','AuditPackageDeliveryAdmitted','AuditPackageDeliveryRecordingProcess','Intent')]:
 write(core+cls+'.cs',f'''using Bdgrz.Compliance.Features.Processes;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Durably starts the accepted package process before the source checkpoint can advance.</summary>
sealed partial class {cls}(IProjectionCheckpointStore checkpoints, ProcessRootReaction process)
    : Reactor(checkpoints, EventStreamPattern.ForTenant(AuditPackageManifest.Area), WorkloadName),
        IReactorHandler<{trigger}>
{{
    public const string WorkloadName = "{cls.removesuffix('Reactor')}V1";
    public async ValueTask HandleAsync(IReactorContext<{trigger}> context, CancellationToken ct) =>
        _ = await process.StartAsync({process}.Name, context, context.Trigger.{field}, [],
            $"reactor:{{WorkloadName}}", ct).ConfigureAwait(false);
}}
''')
