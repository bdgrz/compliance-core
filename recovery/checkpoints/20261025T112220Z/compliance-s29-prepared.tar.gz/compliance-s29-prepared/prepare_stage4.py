from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
def write(path,text):
 p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text.strip()+'\n')
core='src/Compliance.Core/Features/AuditPackages/'
imports='''using System.Globalization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Versioning;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;
'''
write(core+'PackageChanges.cs',imports+'''
/// <summary>Event-specific deltas and pure rule error adaptation; no full parent snapshots are persisted.</summary>
static class PackageChanges
{
    public static Result<PreparedPackageDelta> Failure(CommandFailure failure) =>
        Result<PreparedPackageDelta>.Failure(failure.ToRequestError());
    public static Result<PreparedPackageDelta> Invalid(string message) =>
        Result<PreparedPackageDelta>.Failure(new RequestError(RequestErrorKind.Validation, message));
    public static Result<PreparedPackageDelta> Conflict(string message) =>
        Result<PreparedPackageDelta>.Failure(new RequestError(RequestErrorKind.Conflict, message));
    public static Uuid Member(OperationProvenance operation) =>
        Uuid.Parse(operation.Actor.Id, CultureInfo.InvariantCulture);
    public static AuditPackageContent Content(AuditPackageView view, AuditPackageVersionView version) =>
        new(view.ExaminationId, view.PackageKind, version.SourceSnapshotKind, version.SourceSnapshotId,
            version.SourceSnapshotSha256, view.Name, version.SelectedContent, version.SourcePeriodId);
    public static AuditPackageManifestVersionContent Version(AuditPackageView view,
        OperationProvenance operation)
    {
        var version = view.Versions[^1];
        return new AuditPackageManifestVersionContent(view.ProgramId, Content(view, version), version.Manifest,
            version.AmendsVersion, version.AmendmentReason, operation.Actor, operation.AcceptedAt);
    }
}
''')
write(core+'CreateAuditPackageHandler.cs',imports+'''
/// <summary>Creates a native manifest only from its exact frozen examination source.</summary>
public sealed class CreateAuditPackageHandler(AuditPackageRootOperation operations,
    AuditPackageSourceBuilder sources, IImmutableContentStore content) : IRequestHandler<CreateAuditPackage>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<CreateAuditPackage> context, CancellationToken ct)
    {
        var request = context.Request;
        var outcome = await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PackageId,
            request.PackageId, nameof(CreateAuditPackage), null, _ => 1,
            owner => owner.PrepareCreate(request.ProgramId), async (_, operation, token) =>
            {
                var resolved = await sources.ResolveAsync(request.TenantId, request.ProgramId, request.Content, token)
                    .ConfigureAwait(false);
                if (!resolved.IsSuccess)
                    return Result<PreparedPackageDelta>.Failure(resolved.Error!);
                var rules = new AuditPackageRules(request.TenantId, request.ProgramId, request.PackageId);
                if (rules.Create(resolved.Value!, PackageChanges.Member(operation), operation.Actor.Display,
                        operation.AcceptedAt) is { } failure)
                    return PackageChanges.Failure(failure);
                return Result<PreparedPackageDelta>.Success(await PackageContent.DeltaAsync(content, request.TenantId,
                    "AuditPackageCreated.change.v1", PackageChanges.Version(rules.Current!, operation), token)
                    .ConfigureAwait(false));
            }, (owner, operation, delta, response, result) =>
                owner.Create(request.ProgramId, operation, delta.Content, response, result), false, ct).ConfigureAwait(false);
        return AuditPackageRootOperation.Unit(outcome);
    }
}
''')
write(core+'AmendAuditPackageHandler.cs',imports+'''
/// <summary>Admits one complete next-version manifest; exact retries bypass later source changes.</summary>
public sealed class AmendAuditPackageHandler(AuditPackageRootOperation operations, AuditPackageSourceBuilder sources,
    IImmutableContentStore content) : IRequestHandler<AmendAuditPackage>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<AmendAuditPackage> context, CancellationToken ct)
    {
        var request = context.Request;
        var outcome = await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PackageId,
            request.CommandId, nameof(AmendAuditPackage), request.ExpectedRevision, owner => owner.CurrentVersion + 1,
            owner => owner.PrepareWrite(request.ProgramId, request.ExpectedRevision, owner.CurrentVersion,
                allowFrozen: true), async (snapshot, operation, token) =>
            {
                var view = snapshot.View!;
                var prior = view.Versions[^1];
                if ((request.Content is null) == (request.IncludedRecordIds is null))
                    return PackageChanges.Invalid("An amendment requires exactly one complete or retained selection.");
                AuditPackageContent selected;
                if (request.Content is { } complete)
                {
                    if (complete.ExaminationId != view.ExaminationId || complete.PackageKind != view.PackageKind ||
                        complete.Name != view.Name || complete.SourcePeriodId != prior.SourcePeriodId ||
                        complete.SourceSnapshotKind != prior.SourceSnapshotKind)
                        return PackageChanges.Conflict("An amendment must preserve package identity and source kind/period.");
                    selected = complete;
                }
                else
                {
                    var ids = request.IncludedRecordIds!;
                    if (ids.Count == 0 || ids.Any(id => id == Uuid.Empty) || ids.Distinct().Count() != ids.Count)
                        return PackageChanges.Invalid("An amendment requires unique nonempty selected identities.");
                    var retained = prior.SelectedContent.Where(item => ids.Contains(item.SourceRecordId)).ToArray();
                    if (retained.Select(item => item.SourceRecordId).Distinct().Count() != ids.Count)
                        return PackageChanges.Conflict("An amendment may retain only records in its exact prior selection.");
                    selected = PackageChanges.Content(view, prior) with { SelectedContent = retained };
                }
                var resolved = await sources.ResolveAsync(request.TenantId, request.ProgramId, selected, token)
                    .ConfigureAwait(false);
                if (!resolved.IsSuccess)
                    return Result<PreparedPackageDelta>.Failure(resolved.Error!);
                var rules = new AuditPackageRules(request.TenantId, request.ProgramId, request.PackageId, view);
                if (rules.Amend(request.ExpectedRevision, request.AmendmentReason, resolved.Value!.SourceSnapshotId,
                        resolved.Value.SourceSnapshotSha256, resolved.Value.SelectedContent, PackageChanges.Member(operation),
                        operation.Actor.Display, operation.AcceptedAt) is { } failure)
                    return PackageChanges.Failure(failure);
                return Result<PreparedPackageDelta>.Success(await PackageContent.DeltaAsync(content, request.TenantId,
                    "AuditPackageAmended.change.v1", PackageChanges.Version(rules.Current!, operation), token)
                    .ConfigureAwait(false));
            }, (owner, operation, delta, response, result) => owner.Amend(request.ProgramId,
                request.ExpectedRevision, operation, delta.Content, response, result), false, ct).ConfigureAwait(false);
        return AuditPackageRootOperation.Unit(outcome);
    }
}
''')
write(core+'RequestAuditPackageBuildHandler.cs',imports+'''
/// <summary>Freezes exact selected bytes and an authored manifest revision before queueing one logical build.</summary>
public sealed class RequestAuditPackageBuildHandler(AuditPackageRootOperation operations, IImmutableContentStore content)
    : IRequestHandler<RequestAuditPackageBuild, OperationAcceptedResponse>
{
    public async ValueTask<Result<OperationAcceptedResponse>> HandleAsync(
        IRequestContext<RequestAuditPackageBuild> context, CancellationToken ct)
    {
        var request = context.Request;
        if (string.IsNullOrWhiteSpace(request.BuildKey) || request.PackageVersion is < 1 or > int.MaxValue)
            return Result<OperationAcceptedResponse>.Failure(new RequestError(RequestErrorKind.Validation,
                "A build requires a stable key and exact manifest version."));
        var buildId = AuditPackageCommandIdentity.Build(request.PackageId, request.PackageVersion, request.BuildKey);
        var outcome = await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PackageId,
            buildId, nameof(RequestAuditPackageBuild), request.ExpectedManifestRevision, _ => request.PackageVersion,
            owner => owner.PrepareWrite(request.ProgramId, request.ExpectedManifestRevision, request.PackageVersion),
            async (snapshot, operation, token) =>
            {
                var view = snapshot.View!;
                if (view.ExaminationId != request.ExaminationId || view.PackageKind != request.PackageKind)
                    return PackageChanges.Conflict("The build must identify the package's exact examination and kind.");
                var rules = new AuditPackageRules(request.TenantId, request.ProgramId, request.PackageId, view);
                if (rules.RequestBuild(request.ExpectedManifestRevision, request.BuildKey, PackageChanges.Member(operation),
                        operation.Actor.Display, operation.AcceptedAt) is { } failure)
                    return PackageChanges.Failure(failure);
                var version = view.Versions[^1];
                var manifest = await PackageContent.WriteAsync(content, request.TenantId, "audit-package-manifest.v1",
                    version.Manifest, token).ConfigureAwait(false);
                var selected = version.Manifest.Entries.OrderBy(entry => entry.RelativePath, StringComparer.Ordinal)
                    .Select(entry => entry.Source).ToArray();
                var selection = await PackageContent.WriteAsync<IReadOnlyList<AuditPackageSelectionEntry>>(content,
                    request.TenantId, "audit-package-selection-entry.v1", selected, token).ConfigureAwait(false);
                var intent = new PackageBuildIntent(PackageContent.Header(operation), request.PackageId,
                    view.ExaminationId, view.PackageKind, request.PackageVersion, buildId, request.BuildKey.Trim(),
                    version.Manifest.AuditPackageManifestId, version.Manifest.ManifestSha256, manifest,
                    new ImmutableSelectionManifest(selection, "audit-package-selection-entry.v1", selected.Length,
                        SelectionOrder.CanonicalKey, selection.Sha256));
                return Result<PreparedPackageDelta>.Success(await PackageContent.DeltaAsync(content, request.TenantId,
                    PackageBuildIntent.Schema, intent, token).ConfigureAwait(false));
            }, (owner, operation, delta, response, _) => owner.AdmitBuild(request.ProgramId,
                request.ExpectedManifestRevision, request.PackageVersion, operation, delta.Content, response), true, ct)
            .ConfigureAwait(false);
        return await operations.AcknowledgmentAsync(request.TenantId, outcome, ct).ConfigureAwait(false);
    }
}
''')
write(core+'ValidateAuditPackageHandler.cs',imports+'''
/// <summary>Validates the exact source selection and actual stored archive; proof absence never passes validation.</summary>
public sealed class ValidateAuditPackageHandler(AuditPackageRootOperation operations, AuditPackageSourceBuilder sources,
    IArtifactContentStore artifacts, IImmutableContentStore content) : IRequestHandler<ValidateAuditPackage>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<ValidateAuditPackage> context, CancellationToken ct)
    {
        var request = context.Request;
        var outcome = await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PackageId,
            request.CommandId, nameof(ValidateAuditPackage), request.ExpectedRevision, _ => request.PackageVersion,
            owner => owner.PrepareWrite(request.ProgramId, request.ExpectedRevision, request.PackageVersion),
            async (snapshot, operation, token) =>
            {
                var view = snapshot.View!;
                var version = view.Versions[^1];
                var resolved = await sources.ResolveAsync(request.TenantId, request.ProgramId,
                    PackageChanges.Content(view, version), token).ConfigureAwait(false);
                var failureCode = resolved.IsSuccess ? null : "frozen_source_mismatch";
                if (failureCode is null)
                    failureCode = version.BuildAttempts.LastOrDefault(attempt => attempt.Status == "built") is { } build
                        ? await AuditPackageArchiveVerifier.FailureCodeAsync(artifacts, request.TenantId, build,
                            version.Manifest, token).ConfigureAwait(false) : "archive_content_unavailable";
                AuditPackageValidationFinding[] findings = failureCode is null ? [] :
                    [new AuditPackageValidationFinding(Uuid.CreateVersion5(request.PackageId,
                        $"{request.PackageVersion}\\n{request.ValidationKey}\\n{failureCode}"), failureCode, "error", true,
                        false, "The exact frozen source or actual archive did not verify: " + failureCode)];
                var rules = new AuditPackageRules(request.TenantId, request.ProgramId, request.PackageId, view);
                if (rules.RecordValidation(request.ExpectedRevision, checked((int)request.PackageVersion),
                        request.ValidationKey, findings, PackageChanges.Member(operation), operation.Actor.Display,
                        operation.AcceptedAt) is { } failure)
                    return PackageChanges.Failure(failure);
                var validation = rules.Current!.Versions[^1].Validations.Last(item =>
                    item.ValidationKey == request.ValidationKey.Trim());
                return Result<PreparedPackageDelta>.Success(await PackageContent.DeltaAsync(content, request.TenantId,
                    "AuditPackageValidated.change.v1", validation, token).ConfigureAwait(false));
            }, (owner, operation, delta, response, result) => owner.RecordValidation(request.ProgramId,
                request.ExpectedRevision, request.PackageVersion, operation, delta.Content, response, result), false, ct)
            .ConfigureAwait(false);
        return AuditPackageRootOperation.Unit(outcome);
    }
}
''')
write(core+'ApproveAuditPackageDisclosureHandler.cs',imports+'''
/// <summary>Records an attributable exact-recipient approval against the manifest's authored revision.</summary>
public sealed class ApproveAuditPackageDisclosureHandler(AuditPackageRootOperation operations,
    IImmutableContentStore content) : IRequestHandler<ApproveAuditPackageDisclosure>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<ApproveAuditPackageDisclosure> context, CancellationToken ct)
    {
        var request = context.Request;
        var outcome = await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PackageId,
            request.CommandId, nameof(ApproveAuditPackageDisclosure), request.ExpectedRevision, _ => request.PackageVersion,
            owner => owner.PrepareWrite(request.ProgramId, request.ExpectedRevision, request.PackageVersion),
            async (snapshot, operation, token) =>
            {
                var rules = new AuditPackageRules(request.TenantId, request.ProgramId, request.PackageId, snapshot.View);
                if (rules.ApproveDisclosure(request.ExpectedRevision, checked((int)request.PackageVersion),
                        request.Recipient, request.Purpose, request.Rationale, PackageChanges.Member(operation),
                        operation.Actor.Display, operation.AcceptedAt) is { } failure)
                    return PackageChanges.Failure(failure);
                var approval = rules.Current!.Versions[^1].DisclosureApprovals.Last(item =>
                    item.Recipient == request.Recipient.Trim() && item.Purpose == request.Purpose.Trim());
                return Result<PreparedPackageDelta>.Success(await PackageContent.DeltaAsync(content, request.TenantId,
                    "AuditPackageDisclosureApproved.change.v1", approval, token).ConfigureAwait(false));
            }, (owner, operation, delta, response, result) => owner.ApproveDisclosure(request.ProgramId,
                request.ExpectedRevision, request.PackageVersion, operation, delta.Content, response, result), false, ct)
            .ConfigureAwait(false);
        return AuditPackageRootOperation.Unit(outcome);
    }
}
''')
write(core+'ApproveAuditPackageValidationOverrideHandler.cs',imports+'''
/// <summary>Records an independent rationale-backed override of one exact overridable blocking finding.</summary>
public sealed class ApproveAuditPackageValidationOverrideHandler(AuditPackageRootOperation operations,
    IImmutableContentStore content) : IRequestHandler<ApproveAuditPackageValidationOverride>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<ApproveAuditPackageValidationOverride> context,
        CancellationToken ct)
    {
        var request = context.Request;
        var outcome = await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PackageId,
            request.CommandId, nameof(ApproveAuditPackageValidationOverride), request.ExpectedRevision,
            _ => request.PackageVersion,
            owner => owner.PrepareWrite(request.ProgramId, request.ExpectedRevision, request.PackageVersion),
            async (snapshot, operation, token) =>
            {
                if (!Uuid.TryParse(request.ValidationIssue, CultureInfo.InvariantCulture, out var finding) ||
                    finding == Uuid.Empty)
                    return PackageChanges.Invalid("An override must identify one exact validation finding.");
                var rules = new AuditPackageRules(request.TenantId, request.ProgramId, request.PackageId, snapshot.View);
                if (rules.ApproveValidationOverride(request.ExpectedRevision, checked((int)request.PackageVersion),
                        finding, request.Rationale, PackageChanges.Member(operation), operation.Actor.Display,
                        operation.AcceptedAt) is { } failure)
                    return PackageChanges.Failure(failure);
                var validation = rules.Current!.Versions[^1].Validations[^1];
                var change = new AuditPackageValidationOverrideChange(validation.AuditPackageValidationId,
                    validation.Overrides.Single(item => item.FindingId == finding));
                return Result<PreparedPackageDelta>.Success(await PackageContent.DeltaAsync(content, request.TenantId,
                    "AuditPackageValidationOverrideApproved.change.v1", change, token).ConfigureAwait(false));
            }, (owner, operation, delta, response, result) => owner.ApproveOverride(request.ProgramId,
                request.ExpectedRevision, request.PackageVersion, operation, delta.Content, response, result), false, ct)
            .ConfigureAwait(false);
        return AuditPackageRootOperation.Unit(outcome);
    }
}
''')
