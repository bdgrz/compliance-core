from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
def write(path,text):
 p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text.strip()+'\n')
common='src/Compliance.Common/Features/AuditPackages/'
for name in ['Created','Amended','BuildRequested','Built','Validated','ValidationOverrideApproved','DisclosureApproved']:
 cls='AuditPackage'+name+'V2'
 write(common+cls+'.cs',f'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>One accepted manifest delta; complete business content remains immutable and verified.</summary>
[Discriminator("bdgrz.auditpackages.audit-package-{''.join(('-'+c.lower()) if c.isupper() else c for c in name).lstrip('-')}", 2)]
public sealed record {cls}(Uuid TenantId, Uuid SubjectId, Uuid ProgramId, long Revision,
    long PackageVersion, ImmutableContentRef Change, DateTimeOffset OccurredAt, OperationProvenance Operation,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult) : DomainEvent, INativeOperationFact;
''')
write(common+'AuditPackageDeliveryAdmitted.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Freezes an exact personal external-handoff attestation before independent historical materialization.</summary>
[Discriminator("bdgrz.audit-package-manifest.delivery-admitted", 1)]
public sealed record AuditPackageDeliveryAdmitted(Uuid TenantId, Uuid SubjectId, Uuid ProgramId,
    long Revision, long PackageVersion, ImmutableContentRef Intent, DateTimeOffset OccurredAt,
    OperationProvenance Operation, ImmutableContentRef? FirstResponse) : DomainEvent, INativeOperationFact;
''')
write(common+'AuditPackageDeliveredV2.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>The independently materialized historical handoff; no external transmission is performed.</summary>
[Discriminator("bdgrz.auditpackages.audit-package-delivered", 2)]
public sealed record AuditPackageDeliveredV2(Uuid TenantId, Uuid SubjectId, Uuid ProgramId, Uuid PackageId,
    long PackageVersion, Uuid DeliveryId, ImmutableContentRef Change, NativeFactReference Admission,
    DateTimeOffset OccurredAt, OperationProvenance Operation) : DomainEvent, INativeOperationFact
{
    public ImmutableContentRef? FirstResponse => null;
}
''')
write(common+'PackageBuildIntent.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Complete build inputs frozen before queueing; BuildId identifies business intent, never a worker attempt.</summary>
public sealed record PackageBuildIntent(DurableIntentHeader Header, Uuid PackageId, Uuid ExaminationId,
    string PackageKind, long PackageVersion, Uuid BuildId, string BuildKey, Uuid ManifestId,
    string ManifestSha256, ImmutableContentRef Manifest, ImmutableSelectionManifest Selection)
{
    public const string Schema = "package-build-intent.v1";
}
''')
write(common+'PackageDeliveryRecordingIntent.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>One personal handoff, pinned to its exact archive, disclosure and complete validation proofs.</summary>
public sealed record PackageDeliveryRecordingIntent(DurableIntentHeader Header, Uuid DeliveryId, Uuid PackageId,
    long PackageVersion, Uuid ManifestId, string ManifestSha256, Uuid ArchiveArtifactId, string ArchiveSha256,
    string Recipient, string DeliveryReference, DateTimeOffset DeliveredAt, DateTimeOffset RecordedAt,
    Uuid RecorderMemberId, NativeFactReference DisclosureApproval, ImmutableSelectionManifest ValidationProofs)
{
    public const string Schema = "package-delivery-recording-intent.v1";
}
''')
write(common+'IAuditPackageReceiver.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Marks typed internal effects whose handlers independently verify the exact committed source.</summary>
public interface IAuditPackageReceiver : IRequestBase;
''')
for cls,extra in [('StartAuditPackageBuild','Uuid PackageId, Uuid BuildId, long ManifestVersion'),('MaterializeRecordedAuditPackageDelivery','Uuid PackageId, Uuid DeliveryId, long ManifestVersion')]:
 write(common+cls+'.cs',f'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Internal source-scoped effect; the target verifies the committed source and frozen intent.</summary>
[Discriminator("bdgrz.audit-packages.{''.join(('-'+c.lower()) if c.isupper() else c for c in cls).lstrip('-')}", 1)]
public sealed record {cls}(Uuid CommandId, NativeFactReference Source, EventStreamAddress Target,
    Uuid OperationId, long Generation, long? ExpectedRevision, ImmutableContentRef Intent, {extra})
    : IRequest<ReceiverOutcome>, IAuditPackageReceiver, IIdentifiedRequest
{{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}}
''')
write(common+'IAuditPackageManifestFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>The compact owner envelope shared by the closed set of manifest facts.</summary>
public interface IAuditPackageManifestFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid SubjectId { get; }
    Uuid ProgramId { get; }
    long Revision { get; }
    long PackageVersion { get; }
    ImmutableContentRef Change { get; }
    DateTimeOffset OccurredAt { get; }
}
''')
for name in ['Created','Amended','BuildRequested','Built','Validated','ValidationOverrideApproved','DisclosureApproved']:
 p=root/(common+'AuditPackage'+name+'V2.cs'); p.write_text(p.read_text().replace(': DomainEvent, INativeOperationFact;',': DomainEvent, IAuditPackageManifestFact;'))
p=root/(common+'AuditPackageDeliveryAdmitted.cs'); p.write_text(p.read_text().replace(': DomainEvent, INativeOperationFact;', ''': DomainEvent, IAuditPackageManifestFact
{
    public ImmutableContentRef Change => Intent;
}'''))
write('src/Compliance.Core/Features/AuditPackages/AuditPackageManifest.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>
/// Owns package identity, immutable manifest version references, local approvals, and build/delivery admissions.
/// Command state contains no selections, archive bytes, delivery children, worker attempts or full read snapshots.
/// </summary>
public sealed class AuditPackageManifest : Aggregate
{
    public const string Area = "audit-packages";
    readonly Uuid _tenantId;
    readonly List<DomainEvent> _facts = [];
    readonly Dictionary<long, ImmutableContentRef> _versions = [];
    readonly HashSet<long> _frozenVersions = [];
    Uuid _programId;
    long _revision;
    long _currentVersion;

    public AuditPackageManifest(Uuid tenantId, Uuid packageId, Uuid selectedLogicalId = default,
        string? selectedCommandKind = null)
        : base(packageId, new EventStreamAddress(tenantId.ToString(), Area, packageId.ToString()))
    {
        _tenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedLogicalId, selectedCommandKind);
        On<AuditPackageCreatedV2>(Apply);
        On<AuditPackageAmendedV2>(Apply);
        On<AuditPackageBuildRequestedV2>(Apply);
        On<AuditPackageBuiltV2>(Apply);
        On<AuditPackageValidatedV2>(Apply);
        On<AuditPackageValidationOverrideApprovedV2>(Apply);
        On<AuditPackageDisclosureApprovedV2>(Apply);
        On<AuditPackageDeliveryAdmitted>(Apply);
    }

    public NativeAcceptance Acceptance { get; }
    public bool IsCreated => _revision > 0;
    public long Revision => _revision;
    public long CurrentVersion => _currentVersion;
    public Uuid ProgramId => _programId;
    public IReadOnlyList<DomainEvent> Facts => _facts;
    public ImmutableContentRef? VersionContent(long version) => _versions.GetValueOrDefault(version);
    public bool IsFrozen(long version) => _frozenVersions.Contains(version);
    public DomainEvent? FactById(Uuid eventId) => _facts.FirstOrDefault(fact => fact.Metadata?.EventId == eventId);

    public Result PrepareCreate(Uuid programId) => IsCreated
        ? Fail(RequestErrorKind.Conflict, "The audit package identity already exists.")
        : programId == Uuid.Empty || _tenantId == Uuid.Empty || Id == Uuid.Empty
            ? Fail(RequestErrorKind.Validation, "A package requires tenant, program and package identities.")
            : Result.Success;

    public Result PrepareWrite(Uuid programId, long expectedRevision, long packageVersion,
        bool allowFrozen = false, bool allowHistorical = false)
    {
        if (!IsCreated || programId != _programId)
            return Fail(RequestErrorKind.NotFound, "The audit package was not found in this program.");
        if (expectedRevision != _revision)
            return Fail(RequestErrorKind.Conflict, "The audit package manifest revision is stale.");
        if (!_versions.ContainsKey(packageVersion) || !allowHistorical && packageVersion != _currentVersion)
            return Fail(RequestErrorKind.Conflict, "The command must name the exact current manifest version.");
        if (!allowFrozen && IsFrozen(packageVersion))
            return Fail(RequestErrorKind.Conflict, "A delivery-admitted version is immutable; amend to create another version.");
        return Result.Success;
    }

    public Result Create(Uuid programId, OperationProvenance operation, ImmutableContentRef change,
        ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        var prepared = PrepareCreate(programId);
        if (!prepared.IsSuccess)
            return prepared;
        if (operation.LogicalId != Id || operation.RootOperationId != Id || !Owns(operation, 1))
            return Fail(RequestErrorKind.Validation, "Creation must be the package's own root operation.");
        RaiseEvent(new AuditPackageCreatedV2(_tenantId, Id, programId, 1, 1, change,
            operation.AcceptedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    public Result Amend(Uuid programId, long expectedRevision, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        var prepared = PrepareWrite(programId, expectedRevision, _currentVersion, allowFrozen: true);
        if (!prepared.IsSuccess)
            return prepared;
        if (!Owns(operation, _currentVersion + 1))
            return Fail(RequestErrorKind.Validation, "An amendment must name its new manifest version.");
        RaiseEvent(new AuditPackageAmendedV2(_tenantId, Id, programId, _revision + 1, _currentVersion + 1,
            change, operation.AcceptedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    public Result AdmitBuild(Uuid programId, long expectedRevision, long version, OperationProvenance operation,
        ImmutableContentRef intent, ImmutableContentRef firstResponse)
    {
        var prepared = PrepareWrite(programId, expectedRevision, version);
        if (!prepared.IsSuccess)
            return prepared;
        if (!Owns(operation, version))
            return Fail(RequestErrorKind.Validation, "The build must be bound to this exact manifest version.");
        RaiseEvent(new AuditPackageBuildRequestedV2(_tenantId, Id, programId, _revision + 1, version,
            intent, operation.AcceptedAt, operation, firstResponse, null));
        return Result.Success;
    }

    public Result RecordBuilt(Uuid programId, long expectedRevision, long version, OperationProvenance operation,
        NativeFactReference request, ImmutableContentRef verifiedOutput)
    {
        var prepared = PrepareWrite(programId, expectedRevision, version, allowHistorical: true);
        if (!prepared.IsSuccess)
            return prepared;
        if (!Owns(operation, version) || request.Stream != Stream ||
            FactById(request.EventId) is not AuditPackageBuildRequestedV2 admitted ||
            admitted.Metadata.AggregateVersion != request.AggregateVersion || admitted.PackageVersion != version ||
            admitted.Operation.RootOperationId != operation.RootOperationId || operation.CausationEventId != request.EventId)
            return Fail(RequestErrorKind.Conflict, "The successful archive must follow its exact admitted build.");
        RaiseEvent(new AuditPackageBuiltV2(_tenantId, Id, programId, _revision + 1, version,
            verifiedOutput, operation.AcceptedAt, operation, null, null));
        return Result.Success;
    }

    public Result RecordValidation(Uuid programId, long expectedRevision, long version, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef firstResponse, ImmutableContentRef operationResult) =>
        AcceptDecision(programId, expectedRevision, version, operation, () =>
            new AuditPackageValidatedV2(_tenantId, Id, programId, _revision + 1, version, change,
                operation.AcceptedAt, operation, firstResponse, operationResult));

    public Result ApproveOverride(Uuid programId, long expectedRevision, long version, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef firstResponse, ImmutableContentRef operationResult) =>
        AcceptDecision(programId, expectedRevision, version, operation, () =>
            new AuditPackageValidationOverrideApprovedV2(_tenantId, Id, programId, _revision + 1, version, change,
                operation.AcceptedAt, operation, firstResponse, operationResult));

    public Result ApproveDisclosure(Uuid programId, long expectedRevision, long version, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef firstResponse, ImmutableContentRef operationResult) =>
        AcceptDecision(programId, expectedRevision, version, operation, () =>
            new AuditPackageDisclosureApprovedV2(_tenantId, Id, programId, _revision + 1, version, change,
                operation.AcceptedAt, operation, firstResponse, operationResult));

    public Result AdmitDelivery(Uuid programId, long expectedRevision, long version, OperationProvenance operation,
        ImmutableContentRef intent, NativeFactReference build, NativeFactReference disclosure,
        IReadOnlyList<NativeFactReference> validations, ImmutableContentRef firstResponse)
    {
        var prepared = PrepareWrite(programId, expectedRevision, version, allowFrozen: true);
        if (!prepared.IsSuccess)
            return prepared;
        if (!Owns(operation, version) || !Contains<AuditPackageBuiltV2>(build, version) ||
            !Contains<AuditPackageDisclosureApprovedV2>(disclosure, version) || validations.Count == 0 ||
            validations.Any(proof => !Contains<AuditPackageValidatedV2>(proof, version) &&
                                    !Contains<AuditPackageValidationOverrideApprovedV2>(proof, version)))
            return Fail(RequestErrorKind.Conflict, "Delivery requires this version's exact built archive and approval proofs.");
        var latest = _facts.OfType<AuditPackageValidatedV2>().LastOrDefault(fact => fact.PackageVersion == version);
        if (latest is null || validations.All(proof => proof.EventId != latest.Metadata.EventId))
            return Fail(RequestErrorKind.Conflict, "Delivery must pin the latest applicable validation.");
        RaiseEvent(new AuditPackageDeliveryAdmitted(_tenantId, Id, programId, _revision + 1, version, intent,
            operation.AcceptedAt, operation, firstResponse));
        return Result.Success;
    }

    Result AcceptDecision(Uuid programId, long expectedRevision, long version, OperationProvenance operation,
        Func<DomainEvent> fact)
    {
        var prepared = PrepareWrite(programId, expectedRevision, version);
        if (!prepared.IsSuccess)
            return prepared;
        if (!Owns(operation, version))
            return Fail(RequestErrorKind.Validation, "The decision must name its exact manifest owner and version.");
        RaiseEvent(fact());
        return Result.Success;
    }

    bool Contains<T>(NativeFactReference proof, long version) where T : DomainEvent, IAuditPackageManifestFact =>
        proof.Stream == Stream && FactById(proof.EventId) is T fact && fact.PackageVersion == version &&
        fact.Metadata.AggregateVersion == proof.AggregateVersion;

    bool Owns(OperationProvenance operation, long version) => operation.LogicalId != Uuid.Empty &&
        operation.RootOperationId != Uuid.Empty && operation.Owner == Stream && operation.AffectedOwner == Stream &&
        operation.ExpectedRevisionOwner == Stream && operation.Episode == version.ToString(CultureInfo.InvariantCulture);

    void Apply(DomainEvent domainEvent)
    {
        var fact = (IAuditPackageManifestFact)domainEvent;
        if (fact.TenantId != _tenantId || fact.SubjectId != Id || fact.Revision != _revision + 1 ||
            fact.Change is null || !Owns(fact.Operation, fact.PackageVersion))
            throw new InvalidOperationException("A manifest fact must advance its exact owner at the next local revision.");
        if (domainEvent is AuditPackageCreatedV2)
        {
            if (IsCreated || fact.PackageVersion != 1 || fact.ProgramId == Uuid.Empty || fact.Operation.LogicalId != Id)
                throw new InvalidOperationException("A manifest is created once in its authoritative program.");
            _programId = fact.ProgramId;
            _currentVersion = 1;
            _versions.Add(1, fact.Change);
        }
        else
        {
            if (!IsCreated || fact.ProgramId != _programId)
                throw new InvalidOperationException("A manifest fact cannot change its program binding.");
            if (domainEvent is AuditPackageAmendedV2)
            {
                if (fact.PackageVersion != _currentVersion + 1)
                    throw new InvalidOperationException("An amendment must create the next manifest version.");
                _currentVersion = fact.PackageVersion;
                _versions.Add(_currentVersion, fact.Change);
            }
            else if (!_versions.ContainsKey(fact.PackageVersion))
                throw new InvalidOperationException("A fact cannot refer to an uncreated manifest version.");
            if (domainEvent is AuditPackageDeliveryAdmitted)
                _frozenVersions.Add(fact.PackageVersion);
            else if (domainEvent is not AuditPackageAmendedV2 && IsFrozen(fact.PackageVersion))
                throw new InvalidOperationException("A delivery-admitted version cannot be changed.");
        }
        Acceptance.Observe(domainEvent);
        _revision = fact.Revision;
        _facts.Add(domainEvent);
    }

    static Result Fail(RequestErrorKind kind, string message) => Result.Failure(new RequestError(kind, message));
}
''')
write('src/Compliance.Core/Features/AuditPackages/AuditPackageDelivery.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>One immutable personal handoff, materialized from its manifest admission on its own owner.</summary>
public sealed class AuditPackageDelivery : Aggregate
{
    public const string Area = "audit-package-deliveries";
    readonly Uuid _tenantId;
    readonly Uuid _packageId;
    readonly long _version;
    readonly Uuid _deliveryId;
    AuditPackageDeliveredV2? _delivered;

    public AuditPackageDelivery(Uuid tenantId, Uuid packageId, long manifestVersion, Uuid deliveryId,
        Uuid selectedLogicalId = default)
        : base(IdentityOf(tenantId, packageId, manifestVersion, deliveryId),
            new EventStreamAddress(tenantId.ToString(), Area,
                IdentityOf(tenantId, packageId, manifestVersion, deliveryId).ToString()))
    {
        (_tenantId, _packageId, _version, _deliveryId) = (tenantId, packageId, manifestVersion, deliveryId);
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<AuditPackageDeliveredV2>(fact =>
        {
            if (_delivered is not null || fact.TenantId != _tenantId || fact.SubjectId != Id ||
                fact.PackageId != _packageId || fact.PackageVersion != _version || fact.DeliveryId != _deliveryId ||
                fact.Operation.Owner != Stream || fact.Operation.RootOperationId != _deliveryId)
                throw new InvalidOperationException("A handoff is materialized once on its exact independent owner.");
            Acceptance.Observe(fact);
            _delivered = fact;
        });
    }

    public static Uuid IdentityOf(Uuid tenantId, Uuid packageId, long version, Uuid deliveryId) =>
        AggregateIdentity.Create(nameof(AuditPackageDelivery), tenantId, packageId,
            Uuid.CreateVersion5(packageId, version.ToString(CultureInfo.InvariantCulture)), deliveryId);
    public NativeAcceptance Acceptance { get; }
    public bool IsMaterialized => _delivered is not null;
    public AuditPackageDeliveredV2? Delivered => _delivered;
    public long Revision => _delivered is null ? 0 : 1;

    public Result Materialize(Uuid programId, OperationProvenance operation, PackageDeliveryRecordingIntent intent,
        ImmutableContentRef frozen, NativeFactReference admission)
    {
        if (_delivered is not null)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict, "This handoff already exists."));
        var manifest = new AuditPackageManifest(_tenantId, _packageId).Stream;
        if (programId == Uuid.Empty || intent.PackageId != _packageId || intent.PackageVersion != _version ||
            intent.DeliveryId != _deliveryId || intent.Header.RootOperationId != _deliveryId ||
            intent.Header.FirstOwner != manifest || intent.Header.AffectedOwner != manifest ||
            intent.Header.ExpectedRevisionOwner != manifest || admission.Stream != manifest ||
            admission.EventId == Uuid.Empty || admission.AggregateVersion == 0 ||
            operation.Owner != Stream || operation.RootOperationId != _deliveryId ||
            operation.CausationEventId != admission.EventId || operation.Actor != intent.Header.OriginalActor)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The handoff differs from its exact admitted historical attestation."));
        RaiseEvent(new AuditPackageDeliveredV2(_tenantId, Id, programId, _packageId, _version, _deliveryId,
            frozen, admission, intent.RecordedAt, operation));
        return Result.Success;
    }
}
''')
write('src/Compliance.Core/Features/AuditPackages/AuditPackageArchiveBuilder.cs','''using System.IO.Compression;
using System.Security.Cryptography;
using Bdgrz.Compliance.Features.Artifacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Builds exact pinned source bytes into a deterministic ZIP, then verifies the stored result before use.</summary>
public sealed class AuditPackageArchiveBuilder(IArtifactContentStore artifacts)
{
    static readonly DateTimeOffset ZipEpoch = new(1980, 1, 1, 0, 0, 0, TimeSpan.Zero);

    public async ValueTask<Result<AuditPackageBuildOutput>> BuildAsync(Uuid tenantId,
        AuditPackageManifestView manifest, CancellationToken ct)
    {
        if (tenantId == Uuid.Empty || manifest.TenantId != tenantId || manifest.Entries.Count == 0 ||
            manifest.Entries.Select(entry => entry.RelativePath).Distinct(StringComparer.Ordinal).Count() !=
            manifest.Entries.Count || manifest.Entries.Any(entry => !SafePath(entry.RelativePath) ||
                entry.Source.ByteLength < 0 || !Sha256(entry.Source.ContentSha256)))
            return Failure("The archive manifest contains invalid, duplicate or foreign content.", false);
        var temporary = Path.GetTempFileName();
        try
        {
            await using (var output = new FileStream(temporary, FileMode.Truncate, FileAccess.ReadWrite,
                             FileShare.None, 81920, FileOptions.Asynchronous))
            {
                using var archive = new ZipArchive(output, ZipArchiveMode.Create, leaveOpen: true);
                foreach (var item in manifest.Entries.OrderBy(entry => entry.RelativePath, StringComparer.Ordinal))
                {
                    ct.ThrowIfCancellationRequested();
                    await using var source = await artifacts.OpenVerifiedAsync(new ArtifactContentReference(tenantId,
                        item.Source.ContentSha256, item.Source.ByteLength), ct).ConfigureAwait(false);
                    if (source is null)
                        return Failure("An exact selected source is not available in verified tenant storage.", true);
                    var entry = archive.CreateEntry(item.RelativePath, CompressionLevel.NoCompression);
                    entry.LastWriteTime = ZipEpoch;
                    await using var target = entry.Open();
                    using var digest = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                    var buffer = new byte[81920];
                    long copied = 0;
                    int read;
                    while ((read = await source.ReadAsync(buffer, ct).ConfigureAwait(false)) != 0)
                    {
                        copied = checked(copied + read);
                        if (copied > item.Source.ByteLength)
                            return Failure("A selected source exceeds its exact admitted length.", false);
                        digest.AppendData(buffer.AsSpan(0, read));
                        await target.WriteAsync(buffer.AsMemory(0, read), ct).ConfigureAwait(false);
                    }
                    if (copied != item.Source.ByteLength ||
                        Convert.ToHexStringLower(digest.GetHashAndReset()) != item.Source.ContentSha256)
                        return Failure("A selected source differs from its exact admitted bytes.", false);
                }
            }
            await using var completed = new FileStream(temporary, FileMode.Open, FileAccess.Read,
                FileShare.Read, 81920, FileOptions.Asynchronous);
            var stored = await artifacts.StoreIfAbsentAsync(tenantId, completed, ct).ConfigureAwait(false);
            var reference = stored.Content;
            var archiveId = Uuid.CreateVersion5(tenantId, "audit-package-archive:" + reference.Sha256);
            var build = new AuditPackageBuildAttemptView(Uuid.Empty, string.Empty, "built", manifest.Entries.Count,
                manifest.Entries.Count, ZipEpoch, ZipEpoch, null, string.Empty, ZipEpoch, null, null,
                archiveId, reference.Sha256, reference.Length);
            var failure = await AuditPackageArchiveVerifier.FailureCodeAsync(artifacts, tenantId, build,
                manifest, ct).ConfigureAwait(false);
            return failure is null
                ? Result<AuditPackageBuildOutput>.Success(new AuditPackageBuildOutput(
                    manifest.AuditPackageManifestId, manifest.ManifestSha256, manifest.Entries, archiveId,
                    reference.Sha256, reference.Length, null))
                : Failure("The completed archive does not verify against its exact manifest: " + failure,
                    failure == "archive_content_unavailable");
        }
        finally
        {
            File.Delete(temporary);
        }
    }

    static bool SafePath(string path) => !string.IsNullOrWhiteSpace(path) && path.Length <= 1024 &&
        !path.StartsWith('/') && !path.Contains('\\\\') &&
        path.Split('/').All(segment => segment.Length > 0 && segment is not "." and not "..");
    static bool Sha256(string value) => value.Length == 64 && value.All(character =>
        character is >= '0' and <= '9' or >= 'a' and <= 'f');
    static Result<AuditPackageBuildOutput> Failure(string message, bool transient) =>
        Result<AuditPackageBuildOutput>.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
write('src/Compliance.Core/Features/AuditPackages/AuditPackageBuildOutputRecord.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Technical successful-output checkpoint; failures, attempts and leases remain in the process record.</summary>
public sealed record AuditPackageBuildOutputRecord(Uuid TenantId, Uuid BuildId, NativeFactReference Source,
    ImmutableContentRef Intent, ImmutableContentRef VerifiedOutput);
''')
write('src/Compliance.Core/Features/AuditPackages/IAuditPackageBuildOutputs.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Immutable technical successful-output ledger, scoped to tenant and logical build.</summary>
public interface IAuditPackageBuildOutputs
{
    Task<AuditPackageBuildOutputRecord?> ReadAsync(Uuid tenantId, Uuid buildId, CancellationToken ct);
    Task<AuditPackageBuildOutputRecord> PublishIfAbsentAsync(AuditPackageBuildOutputRecord output, CancellationToken ct);
}
''')
write('src/Compliance.Core/Features/AuditPackages/FitzKvAuditPackageBuildOutputs.cs','''using System.Globalization;
using System.Text;
using System.Text.Json;
using Bdgrz.Compliance.Features.Processes;
using Cntryl.Fitz;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Durable insert-if-absent checkpoint before the successful result receiver can be dispatched.</summary>
sealed class FitzKvAuditPackageBuildOutputs(IKvClient client) : IAuditPackageBuildOutputs
{
    public async Task<AuditPackageBuildOutputRecord?> ReadAsync(Uuid tenantId, Uuid buildId, CancellationToken ct)
    {
        await using var tx = await client.BeginAsync(Route(tenantId, buildId), KvMode.ReadOnly, ct).ConfigureAwait(false);
        var found = await tx.GetAsync(Key(buildId), ct).ConfigureAwait(false);
        return found.Found ? Parse(found.Value!.Value.Span) : null;
    }

    public async Task<AuditPackageBuildOutputRecord> PublishIfAbsentAsync(AuditPackageBuildOutputRecord output,
        CancellationToken ct)
    {
        for (var attempt = 1; ; attempt++)
        {
            try
            {
                await using var tx = await client.BeginAsync(Route(output.TenantId, output.BuildId), KvMode.ReadWrite,
                    ct).ConfigureAwait(false);
                var found = await tx.GetAsync(Key(output.BuildId), ct).ConfigureAwait(false);
                if (found.Found)
                {
                    var existing = Parse(found.Value!.Value.Span);
                    await tx.RollbackAsync(ct).ConfigureAwait(false);
                    if (existing != output)
                        throw new InvalidOperationException("A logical build cannot publish a different source or archive.");
                    return existing;
                }
                await tx.InsertAsync(Key(output.BuildId), JsonSerializer.SerializeToUtf8Bytes(output,
                    ComplianceCoreJsonContext.Default.AuditPackageBuildOutputRecord), ct).ConfigureAwait(false);
                await tx.CommitAsync(KvDurability.Sync, ct).ConfigureAwait(false);
                return output;
            }
            catch (KvException exception) when (attempt < 4 && FitzKvProcessRecordStore.IsIsolationConflict(exception))
            {
                // Retry the route-lock transaction; no checkpoint was published.
            }
        }
    }

    static string Route(Uuid tenantId, Uuid buildId) =>
        $"kv://bdgrz/audit-package-build-outputs/{tenantId}/{buildId.ToString("N", CultureInfo.InvariantCulture)[..2]}";
    static byte[] Key(Uuid buildId) => Encoding.UTF8.GetBytes("b/" + buildId);
    static AuditPackageBuildOutputRecord Parse(ReadOnlySpan<byte> bytes) => JsonSerializer.Deserialize(bytes,
        ComplianceCoreJsonContext.Default.AuditPackageBuildOutputRecord)
        ?? throw new InvalidOperationException("A successful build checkpoint cannot be empty.");
}
''')
