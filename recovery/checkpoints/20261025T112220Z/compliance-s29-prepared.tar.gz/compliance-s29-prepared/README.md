# Prepared S29 native owner cutover

Apply `tests.patch`, then `implementation.patch`, then the parent-owned changes listed in `shared-wiring-deltas.json`. Patches reconstruct all expected file hashes in `manifest.json` using ordinary `patch -E -p1`; no Git index changes were used.

This is a coordinated cutover, with no shipped legacy aggregate or dual read. Package tests retain all original acceptance names; new tests cover actual source bytes/ZIP verification, typed source proof matching, missing versus corrupt content, successful output retry, immediate delivery freeze, historical materialization after an amendment, and exact root/receiver replay.

Validation so far is C# syntax and exact patch reconstruction only. No .NET build/test has run for this patch. Parent owns central validation and shared Program/JSON/DI. `work/` is the authoritative final preparation; Python scripts record intermediate preparation and must not be rerun.

Follow-on implementation remains open: real baseline contributors must publish their exact canonical source bytes to tenant artifact storage. The native archive builder correctly waits on missing bytes. Do not mark S29 complete merely because the owner cutover passes tests.
