from pathlib import Path
r=Path('/tmp/compliance-s29-prepared/work/src/Compliance.Core/Features/AuditPackages')
p=r/'FitzKvAuditPackageBuildOutputs.cs';s=p.read_text().replace('audit-package-build-outputs/{tenantId}/{buildId','audit-package-build-outputs/{tenantId}-{buildId');p.write_text(s)
p=r/'AuditPackageSourceVerifier.cs';s=p.read_text()
s=s.replace('''        var intent = await PackageContent.ReadAsync<PackageBuildIntent>(content, tenant, reference, ct)
            .ConfigureAwait(false);
        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, packageId), ct).ConfigureAwait(false);
        if (source.Stream != owner.Stream || owner.FactById(source.EventId) is not AuditPackageBuildRequestedV2 admitted)
            return BuildFailure("The exact admitted build is not visible yet.", true);''','''        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, packageId), ct).ConfigureAwait(false);
        if (source.Stream != owner.Stream)
            return BuildFailure("The build proof belongs to another manifest owner.");
        if (owner.FactById(source.EventId) is not AuditPackageBuildRequestedV2 admitted)
            return BuildFailure("The exact admitted build is not visible yet.", true);
        if (admitted.Change != reference)
            return BuildFailure("The build intent differs from its exact source admission.");
        var intent = await PackageContent.ReadAsync<PackageBuildIntent>(content, tenant, reference, ct)
            .ConfigureAwait(false);''')
s=s.replace('''        var intent = await PackageContent.ReadAsync<PackageDeliveryRecordingIntent>(content, tenant, reference, ct)
            .ConfigureAwait(false);
        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, packageId), ct).ConfigureAwait(false);
        if (source.Stream != owner.Stream || owner.FactById(source.EventId) is not AuditPackageDeliveryAdmitted admitted)
            return DeliveryFailure("The exact delivery admission is not visible yet.", true);''','''        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, packageId), ct).ConfigureAwait(false);
        if (source.Stream != owner.Stream)
            return DeliveryFailure("The handoff proof belongs to another manifest owner.");
        if (owner.FactById(source.EventId) is not AuditPackageDeliveryAdmitted admitted)
            return DeliveryFailure("The exact delivery admission is not visible yet.", true);
        if (admitted.Intent != reference)
            return DeliveryFailure("The handoff intent differs from its exact source admission.");
        var intent = await PackageContent.ReadAsync<PackageDeliveryRecordingIntent>(content, tenant, reference, ct)
            .ConfigureAwait(false);''')
s=s.replace('''        return Result<PackageDeliveryRecordingIntent>.Success(intent);''','''        var exactBuild = false;
        foreach (var builtFact in owner.Facts.OfType<AuditPackageBuiltV2>().Where(fact =>
                     fact.PackageVersion == version && fact.Revision < admitted.Revision))
        {
            var built = await PackageContent.ReadAsync<AuditPackageBuiltChange>(content, tenant, builtFact.Change, ct)
                .ConfigureAwait(false);
            exactBuild |= built.Output.ManifestId == intent.ManifestId && built.Output.ManifestSha256 == intent.ManifestSha256 &&
                built.Output.ArchiveArtifactId == intent.ArchiveArtifactId && built.Output.ArchiveSha256 == intent.ArchiveSha256 &&
                built.Output.ArchiveBytes is > 0 && built.Output.FailureCode is null;
        }
        if (!exactBuild)
            return DeliveryFailure("The historical handoff does not match an earlier exact successful archive proof.");
        return Result<PackageDeliveryRecordingIntent>.Success(intent);''')
p.write_text(s)
p=Path('/tmp/compliance-s29-prepared/work/src/Compliance.Common/Features/AuditPackages/AuditPackageDeliveryAdmitted.cs');s=p.read_text().replace('public ImmutableContentRef Change => Intent;','ImmutableContentRef IAuditPackageManifestFact.Change => Intent;');p.write_text(s)
p=Path('/tmp/compliance-s29-prepared/work/src/Compliance.Common/Features/AuditPackages/AuditPackageCommandIdentity.cs');s=p.read_text().replace('key.Trim()', '(key?.Trim() ?? string.Empty)').replace('recipient.Trim()', '(recipient?.Trim() ?? string.Empty)').replace('reference.Trim()', '(reference?.Trim() ?? string.Empty)');p.write_text(s)
