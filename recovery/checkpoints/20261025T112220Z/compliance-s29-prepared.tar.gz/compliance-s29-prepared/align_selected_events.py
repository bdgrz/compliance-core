from pathlib import Path
import re
roots=[Path('.'),Path('/tmp/compliance-s29-prepared/work')]
# Preserve parent-owned compiler corrections before changing owning result call sites.
for rel in ['test/Compliance.Tests/Features/AuditPackages/AuditPackageNativeDeliveryTests.cs','test/Compliance.Tests/Features/AuditPackages/AuditPackageTests.cs','test/Compliance.Tests/Testing/PackageSeeds.cs']:
 (roots[1]/rel).write_text((roots[0]/rel).read_text())

def args_end(s,lp):
 depth=1;i=lp+1;quote=None;esc=False
 while i<len(s):
  c=s[i]
  if quote:
   if esc:esc=False
   elif c=='\\':esc=True
   elif c==quote:quote=None
  elif c in '\"\'':quote=c
  elif c=='(':depth+=1
  elif c==')':
   depth-=1
   if depth==0:return i
  i+=1
 raise RuntimeError('unclosed')

for root in roots:
 common=root/'src/Compliance.Common/Features/AuditPackages';core=root/'src/Compliance.Core/Features/AuditPackages'
 for name in ['Created','Amended','BuildRequested','Built','Validated','ValidationOverrideApproved','DisclosureApproved']:
  p=common/('AuditPackage'+name+'.cs');s=p.read_text().replace(', 2)]',', 1)]')
  s=s.replace('ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult)',
              'ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult, Uuid? ActorMemberId)')
  p.write_text(s)
 p=common/'IAuditPackageManifestFact.cs';s=p.read_text().replace('    Uuid ProgramId { get; }','    Uuid ProgramId { get; }\n    Uuid? ActorMemberId { get; }\n    ImmutableContentRef? OperationResult { get; }');p.write_text(s)
 (common/'AuditPackageDeliveryAdmitted.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Freezes an exact personal external-handoff attestation before independent historical materialization.</summary>
[Discriminator("bdgrz.audit-package-manifest.audit-package-delivery-admitted", 1)]
public sealed record AuditPackageDeliveryAdmitted(EventStreamAddress Owner, long Revision, long Generation,
    ImmutableContentRef Intent, ImmutableContentRef? SourceProofs, OperationProvenance Operation,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult, Uuid TenantId, Uuid SubjectId,
    Uuid ProgramId, long PackageVersion, DateTimeOffset OccurredAt, Uuid? ActorMemberId)
    : DomainEvent, IAuditPackageManifestFact
{
    ImmutableContentRef IAuditPackageManifestFact.Change => Intent;
}
''')
 (common/'AuditPackageDelivered.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>The independently materialized historical handoff with its immutable original terminal result.</summary>
[Discriminator("bdgrz.auditpackages.audit-package-delivered", 1)]
public sealed record AuditPackageDelivered(Uuid TenantId, Uuid SubjectId, long Revision, Uuid? ActorMemberId,
    ImmutableContentRef Change, DateTimeOffset OccurredAt, OperationProvenance Operation,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult, Uuid ProgramId, Uuid PackageId,
    long PackageVersion, Uuid DeliveryId, NativeFactReference Admission) : DomainEvent, INativeOperationFact;
''')
 p=core/'AuditPackageManifest.cs';s=p.read_text()
 for name in ['Created','Amended','BuildRequested','Built','Validated','ValidationOverrideApproved','DisclosureApproved']:
  marker='new AuditPackage'+name+'(';pos=0
  while True:
   st=s.find(marker,pos)
   if st<0:break
   end=args_end(s,st+len(marker)-1);s=s[:end]+', Member(operation)'+s[end:];pos=end+len(', Member(operation)')+1
 oldstart=s.index('new AuditPackageDeliveryAdmitted(');oldend=args_end(s,oldstart+len('new AuditPackageDeliveryAdmitted(')-1)
 s=s[:oldstart]+'''new AuditPackageDeliveryAdmitted(Stream, _revision + 1, version, intent, null, operation,
            firstResponse, null, _tenantId, Id, programId, version, operation.AcceptedAt, Member(operation))'''+s[oldend+1:]
 s=s.replace('NativeFactReference request, ImmutableContentRef verifiedOutput)', 'NativeFactReference request, ImmutableContentRef verifiedOutput, ImmutableContentRef operationResult)')
 # The built terminal result is the original typed Unit result, not the successful-output read view.
 s=s.replace('verifiedOutput, operation.AcceptedAt, operation, null, null, Member(operation))',
             'verifiedOutput, operation.AcceptedAt, operation, null, operationResult, Member(operation))')
 s=s.replace('''    bool Root(OperationProvenance operation''','''    static Uuid? Member(OperationProvenance operation) => operation.Actor.Kind == "member" &&
        Uuid.TryParse(operation.Actor.Id, CultureInfo.InvariantCulture, out var member) ? member : null;

    bool Root(OperationProvenance operation''')
 s=s.replace('''            fact.Change is null || !Owns''','''            fact.Change is null || fact.ActorMemberId != Member(fact.Operation) || !Owns''')
 s=s.replace('''        var kind = domainEvent switch''','''        if (domainEvent is AuditPackageDeliveryAdmitted delivery &&
            (delivery.Owner != Stream || delivery.Generation != delivery.PackageVersion))
            throw new InvalidOperationException("A delivery admission must name its exact owner and manifest generation.");
        if (fact.OperationResult is null && domainEvent is not (AuditPackageBuildRequested or AuditPackageDeliveryAdmitted))
            throw new InvalidOperationException("A terminal native package fact must retain its original typed result.");
        var kind = domainEvent switch''')
 p.write_text(s)
 p=core/'PackageContent.cs';s=p.read_text();end=s.rfind('\n}')
 s=s[:end]+'''

    public static async Task<ImmutableContentRef> FreezeUnitResultAsync(IImmutableContentStore content, Uuid tenant,
        CancellationToken ct)
    {
        var value = await WriteAsync(content, tenant, UnitResult.Schema, new UnitResult(), ct).ConfigureAwait(false);
        return await WriteAsync(content, tenant, "mutation-result-content.v1",
            new MutationResultContent(UnitResult.Schema, new StandardResponseBody(value)), ct).ConfigureAwait(false);
    }
'''+s[end:];p.write_text(s)
 p=core/'AuditPackageDelivery.cs';s=p.read_text()
 s=s.replace('ImmutableContentRef frozen, NativeFactReference admission)', 'ImmutableContentRef frozen, NativeFactReference admission, ImmutableContentRef operationResult)')
 s=s.replace('''fact.PackageId != _packageId || fact.PackageVersion''','''fact.Revision != 1 || fact.OperationResult is null || fact.FirstResponse is not null ||
                fact.PackageId != _packageId || fact.PackageVersion''')
 st=s.index('new AuditPackageDelivered(');end=args_end(s,st+len('new AuditPackageDelivered(')-1)
 s=s[:st]+'''new AuditPackageDelivered(_tenantId, Id, 1, intent.RecorderMemberId, frozen,
            intent.RecordedAt, operation, null, operationResult, programId, _packageId, _version, _deliveryId,
            admission)'''+s[end+1:];p.write_text(s)
 p=core/'RecordAuditPackageBuildResultHandler.cs';s=p.read_text()
 s=s.replace('''            return await append.ApplyAsync(''','''            var terminalResult = await PackageContent.FreezeUnitResultAsync(content, tenant, ct).ConfigureAwait(false);
            return await append.ApplyAsync(''',1)
 s=s.replace('command.Generation, operation, command.Source, change)', 'command.Generation, operation, command.Source, change, terminalResult)');p.write_text(s)
 p=core/'MaterializeRecordedAuditPackageDeliveryHandler.cs';s=p.read_text()
 s=s.replace('IAggregateReader reader, ReceiverAppend append, TimeProvider clock)',
             'IAggregateReader reader, ReceiverAppend append, IImmutableContentStore content, TimeProvider clock)')
 s=s.replace('''            return await append.ApplyAsync(''','''            var terminalResult = await PackageContent.FreezeUnitResultAsync(content, tenant, ct).ConfigureAwait(false);
            return await append.ApplyAsync(''',1)
 s=s.replace('''                    command.Source), context''','''                    command.Source, terminalResult), context''');p.write_text(s)
 # Seed data also carries real MutationResultContent envelopes on every terminal fact.
 p=root/'test/Compliance.Tests/Testing/PackageSeeds.cs';s=p.read_text()
 s=s.replace('''        var response = await FirstResponses.FreezeAsync''','''        var unitResult = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
            "mutation-result-content.v1", new MutationResultContent(UnitResult.Schema, new StandardResponseBody(unit)), ct);
        var response = await FirstResponses.FreezeAsync''',1)
 s=s.replace(', response, unit)',', response, unitResult)')
 s=s.replace('source, successful)', 'source, successful, unitResult)')
 s=s.replace('intent, admission.Intent, source)', 'intent, admission.Intent, source, unitResult)')
 p.write_text(s)
 # Owning handler tests explicitly supply the content store needed to freeze terminal results.
 for rel in ['test/Compliance.Tests/Features/AuditPackages/AuditPackageCommandHandlerTests.cs',
             'test/Compliance.Tests/Features/AuditPackages/AuditPackageNativeDeliveryTests.cs']:
  p=root/rel;s=p.read_text()
  s=s.replace('new Bdgrz.Compliance.Features.Processes.ReceiverAppend(Executor), _clock)', 'new Bdgrz.Compliance.Features.Processes.ReceiverAppend(Executor), ContentStore, _clock)')
  s=s.replace('new ReceiverAppend(fixture.Executor), TimeProvider.System)', 'new ReceiverAppend(fixture.Executor), fixture.ContentStore, TimeProvider.System)')
  p.write_text(s)
print('selected event fields/discriminators and immutable Unit terminal results saved in main + preparation')
