from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work');core=root/'src/Compliance.Core/Features/AuditPackages'
p=core/'AuditPackageManifest.cs';s=p.read_text()
s=s.replace('''        RaiseEvent(new AuditPackageBuilt(_tenantId''','''        if (_facts.OfType<AuditPackageBuilt>().Any(fact => fact.Operation.RootOperationId == operation.RootOperationId))
            return Fail(RequestErrorKind.Conflict, "This logical build already has a successful native result.");
        RaiseEvent(new AuditPackageBuilt(_tenantId''')
s=s.replace('''        RaiseEvent(fact());''','''        var accepted = fact();
        var kind = accepted switch { AuditPackageValidated => nameof(ValidateAuditPackage),
            AuditPackageValidationOverrideApproved => nameof(ApproveAuditPackageValidationOverride),
            AuditPackageDisclosureApproved => nameof(ApproveAuditPackageDisclosure),
            _ => throw new InvalidOperationException("The decision fact kind is unsupported."), };
        if (!Root(operation, kind, expectedRevision))
            return Fail(RequestErrorKind.Validation, "The decision differs from its exact authored command kind.");
        RaiseEvent(accepted);''')
p.write_text(s)
for file in ['AuditPackageBuildProcess.cs','AuditPackageDeliveryRecordingProcess.cs']:
 p=core/file;s=p.read_text().replace('PerTarget: false','PerTarget: true')
 if file=='AuditPackageBuildProcess.cs':
  s=s.replace('''        var target = new AuditPackageManifest(tenant, intent.PackageId).Stream;''','''        var target = new AuditPackageManifest(tenant, intent.PackageId).Stream;
        if (step.Target != target.ToString())
            throw new ImmutableContentIntegrityException("The build process target differs from its canonical owner.");''')
 else:
  s=s.replace('''        return new MaterializeRecordedAuditPackageDelivery(step.CommandId''','''        var target = new AuditPackageDelivery(tenant, intent.PackageId, intent.PackageVersion, intent.DeliveryId).Stream;
        if (step.Target != target.ToString())
            throw new ImmutableContentIntegrityException("The delivery process target differs from its canonical child.");
        return new MaterializeRecordedAuditPackageDelivery(step.CommandId''')
 p.write_text(s)
for file in ['AuditPackageBuildProcessReactor.cs','AuditPackageDeliveryAdmissionReactor.cs']:
 p=core/file;s=p.read_text()
 if file=='AuditPackageBuildProcessReactor.cs':s=s.replace('context.Trigger.Change, [],','context.Trigger.Change, [context.Source.Stream.ToString()],')
 else:s=s.replace('context.Trigger.Intent, [],','''context.Trigger.Intent,
            [new AuditPackageDelivery(context.Trigger.TenantId, context.Trigger.SubjectId, context.Trigger.PackageVersion,
                context.Trigger.Operation.LogicalId).Stream.ToString()],''')
 p.write_text(s)
for file,command,process,anchor in [
 ('StartAuditPackageBuildHandler.cs','StartAuditPackageBuild','AuditPackageBuildProcess','''            var existing = await outputs.ReadAsync'''),
 ('RecordAuditPackageBuildResultHandler.cs','RecordAuditPackageBuildResult','AuditPackageBuildProcess','''            var operation = SourceUseReceiverSupport.Child'''),
 ('MaterializeRecordedAuditPackageDeliveryHandler.cs','MaterializeRecordedAuditPackageDelivery','AuditPackageDeliveryRecordingProcess','''            var parent = await reader.HydrateAsync''')]:
 p=core/file;s=p.read_text();s='using Bdgrz.Compliance.Features.Kernel;\n'+s
 header='verified.Value!.Header' if command=='MaterializeRecordedAuditPackageDelivery' else 'verified.Value!.Intent.Header'
 check=f'''            if (command.CommandId != EffectIdentity.CommandId(command.Source.EventId,
                    $"{{{process}.Name}}:{{nameof({command})}}", command.Target.ToString(), {header}.Episode))
                return ReceiverAppend.Invalid("The receiver command id differs from its exact source effect key.");
'''
 assert anchor in s;s=s.replace(anchor,check+anchor);p.write_text(s)
# Typed receiver tests/factories use the same canonical effect key as the actual process driver.
for p in (root/'test').rglob('*.cs'):
 s=p.read_text()
 if p.name=='RecordAuditPackageBuildResultHandlerTests.cs':
  s='using Bdgrz.Compliance.Features.Kernel;\n'+s
  s=s.replace('Uuid.CreateVersion5(admitted.Metadata.EventId, "start")','EffectIdentity.CommandId(admitted.Metadata.EventId, $"{AuditPackageBuildProcess.Name}:{nameof(StartAuditPackageBuild)}", owner.Stream.ToString(), admitted.Operation.Episode)')
  s=s.replace('Uuid.CreateVersion5(start.Source.EventId, "record")','EffectIdentity.CommandId(start.Source.EventId, $"{AuditPackageBuildProcess.Name}:{nameof(RecordAuditPackageBuildResult)}", start.Target.ToString(), "1")')
 if p.name in ['AuditPackageCommandHandlerTests.cs','AuditPackageNativeDeliveryTests.cs']:
  s='using Bdgrz.Compliance.Features.Kernel;\n'+s
  if p.name=='AuditPackageCommandHandlerTests.cs':
   s=s.replace('Uuid.CreateVersion5(fact.Metadata.EventId, "test-materialize")','EffectIdentity.CommandId(fact.Metadata.EventId, $"{AuditPackageDeliveryRecordingProcess.Name}:{nameof(MaterializeRecordedAuditPackageDelivery)}", new AuditPackageDelivery(TenantId, packageId, fact.PackageVersion, fact.Operation.LogicalId).Stream.ToString(), fact.Operation.Episode)')
   s=s.replace('using Bdgrz.Compliance.Features.NativeOperations;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Processes;')
  else:s=s.replace('Uuid.CreateVersion5(admitted.Metadata.EventId, "materialize")','EffectIdentity.CommandId(admitted.Metadata.EventId, $"{AuditPackageDeliveryRecordingProcess.Name}:{nameof(MaterializeRecordedAuditPackageDelivery)}", new AuditPackageDelivery(fixture.TenantId, packageId, 1, admitted.Operation.LogicalId).Stream.ToString(), admitted.Operation.Episode)')
 p.write_text(s)
