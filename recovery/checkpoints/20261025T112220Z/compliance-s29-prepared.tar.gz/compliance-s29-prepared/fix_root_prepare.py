from pathlib import Path

def fix(p):
 s=p.read_text();start=s.index('            FirstResponseDescriptor? response = null;');end=s.index('        }\n        catch (ImmutableContentUnavailableException',start)
 replacement='''            ImmutableContentRef? result = null;
            return await operations.ExecuteAsync(new NativeOperation<AuditPackageManifest>(binding,
                () => new AuditPackageManifest(tenant, packageId, logicalId, kind), aggregate => aggregate.Acceptance,
                async (aggregate, token) =>
                {
                    try
                    {
                        var valid = guard(aggregate);
                        if (!valid.IsSuccess)
                            return Result<FirstResponseDescriptor>.Failure(valid.Error!);
                        var snapshot = await packages.ReadAsync(tenant, program, packageId, token, logicalId, kind)
                            .ConfigureAwait(false);
                        valid = guard(snapshot.Owner);
                        if (!valid.IsSuccess)
                            return Result<FirstResponseDescriptor>.Failure(valid.Error!);
                        var prepared = await prepare(snapshot, operation, token).ConfigureAwait(false);
                        if (!prepared.IsSuccess)
                            return Result<FirstResponseDescriptor>.Failure(prepared.Error!);
                        var body = accepted
                            ? await PackageContent.WriteAsync(content, tenant, "operation-accepted-response.v1",
                                new OperationAcceptedResponse(logicalId,
                                    $"/api/v1/tenants/{tenant}/programs/{program}/operations/{logicalId}", now), token)
                                .ConfigureAwait(false)
                            : await PackageContent.WriteAsync(content, tenant, UnitResult.Schema, new UnitResult(), token)
                                .ConfigureAwait(false);
                        var schema = accepted ? "operation-accepted-response.v1" : UnitResult.Schema;
                        var response = new FirstResponseDescriptor(accepted ? 202 : 200,
                            ImmutableContentStoreExtensions.JsonMediaType, schema, new StandardResponseBody(body));
                        var mutationResult = await PackageContent.WriteAsync(content, tenant, "mutation-result-content.v1",
                            new MutationResultContent(schema, new StandardResponseBody(body)), token).ConfigureAwait(false);
                        delta = prepared.Value;
                        result = mutationResult;
                        return Result<FirstResponseDescriptor>.Success(response);
                    }
                    catch (ImmutableContentUnavailableException exception)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "Package content is not available yet: " + exception.Message, true));
                    }
                    catch (ImmutableContentIntegrityException exception)
                    {
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "Package content cannot be verified: " + exception.Message, false));
                    }
                },
                (aggregate, frozen) => guard(aggregate) is { IsSuccess: false } invalid
                    ? invalid : apply(aggregate, operation, delta!, frozen, result!)), context, ct).ConfigureAwait(false);
'''
 s=s[:start]+replacement+s[end:]
 start=s.index('    static Result<FirstResponseDescriptor> Prepared(');end=s.index('    static Result<AcceptedAppendResult> Fail(',start);s=s[:start]+s[end:]
 p.write_text(s)

if __name__=='__main__':
 import sys
 target=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/compliance-s29-prepared/work/src/Compliance.Core/Features/AuditPackages/AuditPackageRootOperation.cs')
 fix(target)
 print('async native preparation fix saved',target)
