from pathlib import Path
import re
root=Path('/tmp/compliance-s29-prepared/work');folder=Path('test/Compliance.Tests/Features/AuditPackages')
extra='''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Hosting.Persistence;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz.Testing;
'''
def top_args(text,start):
 depth=1;i=start+1;begin=i;args=[];quote=None;escape=False
 while i<len(text):
  c=text[i]
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c==quote:quote=None
  elif c in '\"\'':quote=c
  elif c in '([{':depth+=1
  elif c in ')]}':
   depth-=1
   if depth==0:
    args.append(text[begin:i].strip());return args,i+1
  elif c==',' and depth==1:
   args.append(text[begin:i].strip());begin=i+1
  i+=1
 raise Exception('unclosed')
def replace_calls(s,name,fn):
 pos=0
 while True:
  m=re.search(re.escape(name)+r'\s*\(',s[pos:])
  if not m:break
  st=pos+m.start();lp=pos+m.end()-1;args,end=top_args(s,lp);replacement=fn(args)
  s=s[:st]+replacement+s[end:];pos=st+len(replacement)
 return s
for file in ['AmendAuditPackageHandlerTests.cs','CreateAuditPackageHandlerTests.cs','ValidateAuditPackageHandlerTests.cs','AuditPackageCommandHandlerTests.cs']:
 p=root/folder/file;s=p.read_text();s=extra+s
 s=s.replace('using AuditPackageAggregate = Bdgrz.Compliance.Features.AuditPackages.AuditPackage;','using AuditPackageAggregate = Bdgrz.Compliance.Features.AuditPackages.AuditPackageRules;')
 s=replace_calls(s,'fixture.Reader.HydrateAsync',lambda a: 'fixture.ReadPackageAsync('+top_args(a[0],a[0].index('('))[0][2]+')' if a[0].startswith('new AuditPackageAggregate(') else 'fixture.Reader.HydrateAsync('+', '.join(a)+')')
 s=s.replace('await Writer.SaveAsync(package, new RequestDispatchContext(RequestActor.System));','await PackageSeeds.WriteAsync(Writer, ContentStore, package.Current!);')
 if file!='ValidateAuditPackageHandlerTests.cs':
  needle='        public IAggregateExecutor Executor { get; }'
  assert needle in s
  s=s.replace(needle,needle+'''
        public IImmutableContentStore ContentStore { get; } =
            new FitzKvImmutableContentStore(new PersistenceKvClient(new InMemoryKvClient()));
        public AuditPackageReader Packages => new(Reader, ContentStore);
        public AuditPackageRootOperation RootOperation => new(Reader, Packages,
            new NativeOperationExecutor(Reader, Executor, ContentStore), ContentStore, _clock);
        public async Task<AuditPackageRules> ReadPackageAsync(Uuid id) =>
            new(TenantId, ProgramId, id, (await Packages.ReadAsync(TenantId, ProgramId, id, CancellationToken.None)).View);
        public async Task<long> ManifestRevisionAsync(Uuid id) =>
            (await Packages.ReadAsync(TenantId, ProgramId, id, CancellationToken.None)).Owner.Revision;
''')
 if file=='AmendAuditPackageHandlerTests.cs':
  s=s.replace('new(Executor, Reader,\n            new AuditPackageSourceBuilder(Reader), _clock);','new(RootOperation, new AuditPackageSourceBuilder(Reader), ContentStore);')
 if file=='CreateAuditPackageHandlerTests.cs':
  s=s.replace('new(Executor,\n            new AuditPackageSourceBuilder(Reader), _clock);','new(RootOperation,\n            new AuditPackageSourceBuilder(Reader), ContentStore);')
 if file=='ValidateAuditPackageHandlerTests.cs':
  s=s.replace('new ValidateAuditPackageHandler(fixture.Executor, fixture.Reader,\n            new AuditPackageSourceBuilder(fixture.Reader), fixture.ArtifactStore,\n            TimeProvider.System)','new ValidateAuditPackageHandler(fixture.RootOperation,\n            new AuditPackageSourceBuilder(fixture.Reader), fixture.ArtifactStore, fixture.ContentStore)')
 if file=='AuditPackageCommandHandlerTests.cs':
  s=s.replace('readonly TimeProvider _clock = new FixedTimeProvider(Now);','readonly TimeProvider _clock = new FixedTimeProvider(Now.AddMinutes(4));')
  s=s.replace('new(Executor, _clock);','new(RootOperation, ContentStore);')
  s=s.replace('new(Executor);','new(RootOperation, ContentStore, ArtifactStore);')
  s=s.replace('        public IAggregateExecutor Executor { get; }','''        readonly string _artifactRoot = Path.Combine(Path.GetTempPath(), $"package-command-{Guid.NewGuid():N}");
        public IArtifactContentStore ArtifactStore { get; }
        public IAggregateExecutor Executor { get; }''')
  s=s.replace('            var services = new ServiceCollection();','''            ArtifactStore = new LocalArtifactContentStore(new ArtifactContentStoreOptions(
                _artifactRoot, null, ArtifactContentLimits.MaxContentLength), _clock);
            var services = new ServiceCollection();''')
  s=s.replace('            await _provider.DisposeAsync();','''            await _provider.DisposeAsync();
            if (Directory.Exists(_artifactRoot))
                Directory.Delete(_artifactRoot, recursive: true);''')
  # Seed actual source/archive bytes for delivery's newly mandatory proof gate.
  s=s.replace("new string('b', 64), 512",'Hash("control-17"), 10').replace("new string('c', 64), 1024",'Hash("artifact-9"), 10')
  s=s.replace('''            Assert.Null(package.RecordBuildResult(package.Revision, attempt.BuildAttemptId,
                new AuditPackageBuildOutput(manifest.AuditPackageManifestId,
                    manifest.ManifestSha256, manifest.Entries, ArchiveId,
                    new string('f', 64), 4096, null), null, "build-worker", Now.AddMinutes(2)));''','''            await StoreSourceBytesAsync();
            var built = await new AuditPackageArchiveBuilder(ArtifactStore).BuildAsync(TenantId, manifest,
                CancellationToken.None);
            Assert.True(built.IsSuccess, built.Error?.Message);
            Assert.Null(package.RecordBuildResult(package.Revision, attempt.BuildAttemptId,
                built.Value!, null, "build-worker", Now.AddMinutes(2)));''')
  s=s.replace('        AuditPackageContent Content(Uuid packageId)', '''        static string Hash(string value) => Convert.ToHexStringLower(System.Security.Cryptography.SHA256.HashData(
            System.Text.Encoding.UTF8.GetBytes(value)));
        async Task StoreSourceBytesAsync()
        {
            await ArtifactStore.StoreIfAbsentAsync(TenantId, new MemoryStream(System.Text.Encoding.UTF8.GetBytes("control-17")));
            await ArtifactStore.StoreIfAbsentAsync(TenantId, new MemoryStream(System.Text.Encoding.UTF8.GetBytes("artifact-9")));
        }

        AuditPackageContent Content(Uuid packageId)''')
  s=s.replace('using Bdgrz.Compliance.Features.AuditPackages;','using Bdgrz.Compliance.Features.AuditPackages;\nusing Bdgrz.Compliance.Features.Artifacts;')
 # Insert authored tokens into test request constructors. Existing identity/revision intent assertions remain.
 s=replace_calls(s,'new AmendAuditPackage',lambda a: 'new AmendAuditPackage(Uuid.CreateVersion4(), '+', '.join(a)+')')
 s=replace_calls(s,'new ValidateAuditPackage',lambda a: 'new ValidateAuditPackage(Uuid.CreateVersion4(), '+', '.join(a[:4])+', await fixture.ManifestRevisionAsync('+a[2]+'), '+', '.join(a[4:])+')')
 s=replace_calls(s,'new ApproveAuditPackageDisclosure',lambda a: 'new ApproveAuditPackageDisclosure(Uuid.CreateVersion4(), '+', '.join(a[:4])+', await fixture.ManifestRevisionAsync('+a[2]+'), '+', '.join(a[4:])+')')
 s=replace_calls(s,'new ApproveAuditPackageValidationOverride',lambda a: 'new ApproveAuditPackageValidationOverride(Uuid.CreateVersion4(), '+', '.join(a[:4])+', await fixture.ManifestRevisionAsync('+a[2]+'), '+', '.join(a[4:])+')')
 s=replace_calls(s,'new RequestAuditPackageBuild',lambda a: 'new RequestAuditPackageBuild('+', '.join(a)+', await fixture.ManifestRevisionAsync('+a[3]+'), 1)')
 s=replace_calls(s,'new RecordAuditPackageDelivery',lambda a: 'new RecordAuditPackageDelivery('+', '.join(a)+', AuditPackageCommandIdentity.Delivery('+', '.join([a[2],a[3],a[4],a[6]])+'), await fixture.ManifestRevisionAsync('+a[2]+'))')
 # Avoid duplicate using directives (the source set already contains some test helpers).
 seen=set();out=[]
 for line in s.splitlines():
  if line.startswith('using '):
   if line in seen:continue
   seen.add(line)
  out.append(line)
 p.write_text('\n'.join(out)+'\n')
