from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
def write(path,text):
 p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text.strip()+'\n')
core='src/Compliance.Core/Features/AuditPackages/'
write(core+'PackageContent.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Verified immutable package content; candidates use fresh ids until an owner's append accepts one.</summary>
static class PackageContent
{
    public static Task<ImmutableContentRef> WriteAsync<T>(IImmutableContentStore content, Uuid tenant, string schema,
        T value, CancellationToken ct) where T : notnull =>
        content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(), schema, value, ct);

    public static Task<T> ReadAsync<T>(IImmutableContentStore content, Uuid tenant, ImmutableContentRef reference,
        CancellationToken ct) where T : notnull => content.ReadJsonAsync<T>(tenant.ToString(), reference, ct);

    public static DurableIntentHeader Header(OperationProvenance operation) => new(operation.RootOperationId,
        operation.Owner, operation.AffectedOwner, operation.ExpectedRevisionOwner, operation.Actor, operation.Episode,
        operation.OriginalExpectedRevision, operation.AuthoredIntentSha256, operation.AcceptedAt);

    public static async ValueTask<PreparedPackageDelta> DeltaAsync<T>(IImmutableContentStore content, Uuid tenant,
        string schema, T value, CancellationToken ct) where T : notnull =>
        new(await WriteAsync(content, tenant, schema, value, ct).ConfigureAwait(false));
}
''')
write(core+'PreparedPackageDelta.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>One unpublished candidate plus the local proofs its final atomic owner guard must bind.</summary>
sealed record PreparedPackageDelta(ImmutableContentRef Content, NativeFactReference? Build = null,
    NativeFactReference? Disclosure = null, IReadOnlyList<NativeFactReference>? Validations = null);
''')
write(core+'AuditPackageRootOperation.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Resolves exact acceptance before source/currentness checks, then freezes and appends one owner delta.</summary>
public sealed class AuditPackageRootOperation(IAggregateReader reader, AuditPackageReader packages,
    NativeOperationExecutor operations, IImmutableContentStore content, TimeProvider clock)
{
    internal async ValueTask<Result<AcceptedAppendResult>> ExecuteAsync<TRequest>(IRequestContext<TRequest> context,
        Uuid tenant, Uuid program, Uuid packageId, Uuid logicalId, string kind, long? expectedRevision,
        Func<AuditPackageManifest, long> newVersion, Func<AuditPackageManifest, Result> guard,
        Func<AuditPackageSnapshot, OperationProvenance, CancellationToken, ValueTask<Result<PreparedPackageDelta>>> prepare,
        Func<AuditPackageManifest, OperationProvenance, PreparedPackageDelta, ImmutableContentRef,
            ImmutableContentRef, Result> apply, bool accepted, CancellationToken ct) where TRequest : IRequestBase
    {
        if (!AuditPackageCommandActor.TryGet(context.Actor, context.Invocation, tenant, out var member, out var display))
            return Fail(RequestErrorKind.Forbidden, "A package decision requires a personal HTTP actor.");
        if (tenant == Uuid.Empty || program == Uuid.Empty || packageId == Uuid.Empty || logicalId == Uuid.Empty ||
            expectedRevision is < 0)
            return Fail(RequestErrorKind.Validation, "A package command requires exact identities and a nonnegative revision.");
        try
        {
            var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, packageId, logicalId, kind), ct)
                .ConfigureAwait(false);
            if (owner.IsCreated && owner.ProgramId != program)
                return Fail(RequestErrorKind.NotFound, "The package was not found in this program.");
            var version = owner.Acceptance.SelectedFact is IAuditPackageManifestFact existing
                ? existing.PackageVersion : newVersion(owner);
            var now = clock.GetUtcNow();
            var operation = new OperationProvenance(logicalId, logicalId, null, kind,
                ActorReference.ForMember(member, display), owner.Stream, version.ToString(CultureInfo.InvariantCulture),
                expectedRevision is { } expected ? (ulong)expected : null, AuthoredIntentDigest.Compute(context.Request),
                now, owner.Stream, owner.Stream);
            var binding = AcceptedOperationBinding.Of(operation);
            PreparedPackageDelta? delta = null;
            FirstResponseDescriptor? response = null;
            ImmutableContentRef? result = null;
            if (owner.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)
            {
                var valid = guard(owner);
                if (!valid.IsSuccess)
                    return Result<AcceptedAppendResult>.Failure(valid.Error!);
                var snapshot = await packages.ReadAsync(tenant, program, packageId, ct, logicalId, kind)
                    .ConfigureAwait(false);
                valid = guard(snapshot.Owner);
                if (!valid.IsSuccess)
                    return Result<AcceptedAppendResult>.Failure(valid.Error!);
                var prepared = await prepare(snapshot, operation, ct).ConfigureAwait(false);
                if (!prepared.IsSuccess)
                    return Result<AcceptedAppendResult>.Failure(prepared.Error!);
                delta = prepared.Value;
                var body = accepted
                    ? await PackageContent.WriteAsync(content, tenant, "operation-accepted-response.v1",
                        new OperationAcceptedResponse(logicalId,
                            $"/api/v1/tenants/{tenant}/programs/{program}/operations/{logicalId}", now), ct)
                        .ConfigureAwait(false)
                    : await PackageContent.WriteAsync(content, tenant, UnitResult.Schema, new UnitResult(), ct)
                        .ConfigureAwait(false);
                var schema = accepted ? "operation-accepted-response.v1" : UnitResult.Schema;
                response = new FirstResponseDescriptor(accepted ? 202 : 200,
                    ImmutableContentStoreExtensions.JsonMediaType, schema, new StandardResponseBody(body));
                result = await PackageContent.WriteAsync(content, tenant, "mutation-result-content.v1",
                    new MutationResultContent(schema, new StandardResponseBody(body)), ct).ConfigureAwait(false);
            }
            return await operations.ExecuteAsync(new NativeOperation<AuditPackageManifest>(binding,
                () => new AuditPackageManifest(tenant, packageId, logicalId, kind), aggregate => aggregate.Acceptance,
                aggregate => Prepared(guard(aggregate), response),
                (aggregate, frozen) => guard(aggregate) is { IsSuccess: false } invalid
                    ? invalid : apply(aggregate, operation, delta!, frozen, result!)), context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException exception)
        {
            return Fail(RequestErrorKind.Conflict, "Package content is not available yet: " + exception.Message, true);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Fail(RequestErrorKind.Conflict, "Package content cannot be verified: " + exception.Message, false);
        }
    }

    internal static Result Unit(Result<AcceptedAppendResult> outcome) => !outcome.IsSuccess
        ? Result.Failure(outcome.Error!) : outcome.Value is AcceptedAppendResult.Conflict
            ? Result.Failure(AcceptedAppendResult.ConflictError) : Result.Success;

    internal async ValueTask<Result<OperationAcceptedResponse>> AcknowledgmentAsync(Uuid tenant,
        Result<AcceptedAppendResult> outcome, CancellationToken ct)
    {
        if (!outcome.IsSuccess)
            return Result<OperationAcceptedResponse>.Failure(outcome.Error!);
        var response = outcome.Value switch { AcceptedAppendResult.Committed committed => committed.Response,
            AcceptedAppendResult.Replayed replayed => replayed.Response, _ => null };
        if (response?.Body is not StandardResponseBody body)
            return Result<OperationAcceptedResponse>.Failure(AcceptedAppendResult.ConflictError);
        return Result<OperationAcceptedResponse>.Success(await PackageContent.ReadAsync<OperationAcceptedResponse>(content,
            tenant, body.Content, ct).ConfigureAwait(false));
    }

    static Result<FirstResponseDescriptor> Prepared(Result guarded, FirstResponseDescriptor? response) =>
        !guarded.IsSuccess ? Result<FirstResponseDescriptor>.Failure(guarded.Error!) : response is null
            ? Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The manifest changed while the command was prepared; retry.", true))
            : Result<FirstResponseDescriptor>.Success(response);
    static Result<AcceptedAppendResult> Fail(RequestErrorKind kind, string message, bool transient = false) =>
        Result<AcceptedAppendResult>.Failure(new RequestError(kind, message, transient));
}
''')
