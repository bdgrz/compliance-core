from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
p=root/'test/Compliance.Tests/Testing/PackageSeeds.cs';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text('''using System.Globalization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.AuditPackages;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

/// <summary>Explicit native fixture construction from a rule-composed view; no runtime legacy read/write adapter exists.</summary>
static class PackageSeeds
{
    public static Task WriteAsync(IAggregateWriter writer, IImmutableContentStore content, AuditPackageView view,
        CancellationToken ct = default) => SaveAsync(null, writer, content, view, ct);
    public static Task AppendAsync(IAggregateReader reader, IAggregateWriter writer, IImmutableContentStore content,
        AuditPackageView view, CancellationToken ct = default) => SaveAsync(reader, writer, content, view, ct);

    static async Task SaveAsync(IAggregateReader? reader, IAggregateWriter writer, IImmutableContentStore content,
        AuditPackageView view, CancellationToken ct)
    {
        var tenant = view.TenantId;
        var owner = reader is null ? new AuditPackageManifest(tenant, view.AuditPackageId) :
            await reader.HydrateAsync(new AuditPackageManifest(tenant, view.AuditPackageId), ct);
        var unit = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(), UnitResult.Schema,
            new UnitResult(), ct);
        var response = await FirstResponses.FreezeAsync(content, tenant.ToString(), new FirstResponseDescriptor(200,
            ImmutableContentStoreExtensions.JsonMediaType, UnitResult.Schema, new StandardResponseBody(unit)), ct);
        foreach (var version in view.Versions)
        {
            var actor = ActorReference.ForMember(version.CreatedByMemberId, version.CreatedByDisplay);
            if (owner.VersionContent(version.PackageVersion) is null)
            {
                var operation = Root(version.PackageVersion == 1 ? view.AuditPackageId : Uuid.CreateVersion4(),
                    version.PackageVersion == 1 ? nameof(CreateAuditPackage) : nameof(AmendAuditPackage), actor,
                    owner, version.PackageVersion, version.CreatedAt);
                var data = new AuditPackageContent(view.ExaminationId, view.PackageKind, version.SourceSnapshotKind,
                    version.SourceSnapshotId, version.SourceSnapshotSha256, view.Name, version.SelectedContent,
                    version.SourcePeriodId);
                var change = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                    version.PackageVersion == 1 ? "AuditPackageCreated.change.v1" : "AuditPackageAmended.change.v1",
                    new AuditPackageManifestVersionContent(view.ProgramId, data, version.Manifest,
                        version.AmendsVersion, version.AmendmentReason, actor, version.CreatedAt), ct);
                Assert.True((version.PackageVersion == 1
                    ? owner.Create(view.ProgramId, operation, change, response, unit)
                    : owner.Amend(view.ProgramId, owner.Revision, operation, change, response, unit)).IsSuccess);
                await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
            }
            foreach (var build in version.BuildAttempts)
            {
                var admitted = owner.Facts.OfType<AuditPackageBuildRequestedV2>().FirstOrDefault(fact =>
                    fact.Operation.LogicalId == build.BuildAttemptId);
                if (admitted is null)
                {
                    var operation = Root(build.BuildAttemptId, nameof(RequestAuditPackageBuild),
                        ActorReference.ForMember(build.RequestedByMemberId ?? version.CreatedByMemberId,
                            build.RequestedByDisplay), owner, version.PackageVersion, build.RequestedAt);
                    var manifest = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                        "audit-package-manifest.v1", version.Manifest, ct);
                    IReadOnlyList<AuditPackageSelectionEntry> rows = version.Manifest.Entries
                        .OrderBy(entry => entry.RelativePath, StringComparer.Ordinal).Select(entry => entry.Source).ToArray();
                    var selection = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                        "audit-package-selection-entry.v1", rows, ct);
                    var intent = new PackageBuildIntent(Header(operation), view.AuditPackageId, view.ExaminationId,
                        view.PackageKind, version.PackageVersion, build.BuildAttemptId, build.BuildKey,
                        version.Manifest.AuditPackageManifestId, version.Manifest.ManifestSha256, manifest,
                        new ImmutableSelectionManifest(selection, "audit-package-selection-entry.v1", rows.Count,
                            SelectionOrder.CanonicalKey, selection.Sha256));
                    var frozen = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                        PackageBuildIntent.Schema, intent, ct);
                    Assert.True(owner.AdmitBuild(view.ProgramId, owner.Revision, version.PackageVersion, operation,
                        frozen, response).IsSuccess);
                    await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
                    admitted = owner.Facts.OfType<AuditPackageBuildRequestedV2>().Last();
                }
                if (build.Status != "built" || owner.Facts.OfType<AuditPackageBuiltV2>().Any(fact =>
                        fact.Operation.RootOperationId == build.BuildAttemptId))
                    continue;
                var source = NativeFactReference.Of(owner.Stream, admitted);
                var operationBuilt = SourceUseReceiverSupport.Child(Uuid.CreateVersion5(source.EventId, "seed-result"),
                    nameof(RecordAuditPackageBuildResultV2), source.EventId, Header(admitted.Operation), owner.Stream,
                    build.CompletedAt ?? build.UpdatedAt);
                var output = new AuditPackageBuildOutput(version.Manifest.AuditPackageManifestId,
                    version.Manifest.ManifestSha256, version.Manifest.Entries, build.ArchiveArtifactId,
                    build.ArchiveSha256, build.ArchiveBytes, null);
                var successful = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                    "AuditPackageBuilt.change.v1", new AuditPackageBuiltChange(build.BuildAttemptId, output,
                        build.CompletedAt ?? build.UpdatedAt), ct);
                Assert.True(owner.RecordBuilt(view.ProgramId, owner.Revision, version.PackageVersion, operationBuilt,
                    source, successful).IsSuccess);
                await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
            }
            foreach (var validation in version.Validations)
            {
                var existing = new List<AuditPackageValidatedV2>();
                foreach (var fact in owner.Facts.OfType<AuditPackageValidatedV2>())
                {
                    var data = await content.ReadJsonAsync<AuditPackageValidationView>(tenant.ToString(), fact.Change, ct);
                    if (data.AuditPackageValidationId == validation.AuditPackageValidationId)
                        existing.Add(fact);
                }
                if (existing.Count == 0)
                {
                    var operation = Root(Uuid.CreateVersion4(), nameof(ValidateAuditPackage),
                        ActorReference.ForMember(validation.ValidatedByMemberId, validation.ValidatedByDisplay), owner,
                        version.PackageVersion, validation.UpdatedAt);
                    var initial = validation with { Overrides = [],
                        Status = validation.Findings.Any(finding => finding.BlocksDelivery) ? "blocked" : "passed" };
                    var change = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                        "AuditPackageValidated.change.v1", initial, ct);
                    Assert.True(owner.RecordValidation(view.ProgramId, owner.Revision, version.PackageVersion,
                        operation, change, response, unit).IsSuccess);
                    await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
                }
                foreach (var approved in validation.Overrides)
                {
                    var duplicate = false;
                    foreach (var fact in owner.Facts.OfType<AuditPackageValidationOverrideApprovedV2>())
                    {
                        var data = await content.ReadJsonAsync<AuditPackageValidationOverrideChange>(tenant.ToString(),
                            fact.Change, ct);
                        duplicate |= data.ValidationId == validation.AuditPackageValidationId && data.Override == approved;
                    }
                    if (duplicate)
                        continue;
                    var operation = Root(Uuid.CreateVersion4(), nameof(ApproveAuditPackageValidationOverride),
                        ActorReference.ForMember(approved.ApprovedByMemberId, approved.ApprovedByDisplay), owner,
                        version.PackageVersion, approved.ApprovedAt);
                    var change = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                        "AuditPackageValidationOverrideApproved.change.v1",
                        new AuditPackageValidationOverrideChange(validation.AuditPackageValidationId, approved), ct);
                    Assert.True(owner.ApproveOverride(view.ProgramId, owner.Revision, version.PackageVersion,
                        operation, change, response, unit).IsSuccess);
                    await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
                }
            }
            foreach (var approval in version.DisclosureApprovals)
            {
                var duplicate = false;
                foreach (var fact in owner.Facts.OfType<AuditPackageDisclosureApprovedV2>())
                {
                    var data = await content.ReadJsonAsync<AuditPackageDisclosureApprovalView>(tenant.ToString(),
                        fact.Change, ct);
                    duplicate |= data.DisclosureApprovalId == approval.DisclosureApprovalId;
                }
                if (duplicate)
                    continue;
                var operation = Root(Uuid.CreateVersion4(), nameof(ApproveAuditPackageDisclosure),
                    ActorReference.ForMember(approval.ApprovedByMemberId, approval.ApprovedByDisplay), owner,
                    version.PackageVersion, approval.ApprovedAt);
                var change = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                    "AuditPackageDisclosureApproved.change.v1", approval, ct);
                Assert.True(owner.ApproveDisclosure(view.ProgramId, owner.Revision, version.PackageVersion,
                    operation, change, response, unit).IsSuccess);
                await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
            }
            foreach (var delivery in version.Deliveries)
            {
                var admission = owner.Facts.OfType<AuditPackageDeliveryAdmitted>().FirstOrDefault(fact =>
                    fact.Operation.LogicalId == delivery.AuditPackageDeliveryId);
                PackageDeliveryRecordingIntent intent;
                if (admission is null)
                {
                    var disclosure = owner.Facts.OfType<AuditPackageDisclosureApprovedV2>().Last(fact =>
                        fact.PackageVersion == version.PackageVersion);
                    var build = owner.Facts.OfType<AuditPackageBuiltV2>().Last(fact =>
                        fact.PackageVersion == version.PackageVersion);
                    var latest = owner.Facts.OfType<AuditPackageValidatedV2>().Last(fact =>
                        fact.PackageVersion == version.PackageVersion);
                    IReadOnlyList<NativeFactReference> proofs = [NativeFactReference.Of(owner.Stream, latest),
                        .. owner.Facts.OfType<AuditPackageValidationOverrideApprovedV2>().Where(fact =>
                            fact.PackageVersion == version.PackageVersion && fact.Revision > latest.Revision)
                            .Select(fact => NativeFactReference.Of(owner.Stream, fact))];
                    var proofManifest = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                        "audit-package-validation-proof.v1", proofs, ct);
                    var operation = Root(delivery.AuditPackageDeliveryId, nameof(RecordAuditPackageDelivery),
                        ActorReference.ForMember(delivery.ActorMemberId ?? version.CreatedByMemberId, delivery.ActorDisplay),
                        owner, version.PackageVersion, delivery.UpdatedAt);
                    intent = new PackageDeliveryRecordingIntent(Header(operation), delivery.AuditPackageDeliveryId,
                        view.AuditPackageId, version.PackageVersion, delivery.ManifestId, delivery.ManifestSha256,
                        delivery.ArchiveArtifactId, delivery.ArchiveSha256, delivery.Recipient, delivery.DeliveryReference,
                        delivery.UpdatedAt, delivery.UpdatedAt, delivery.ActorMemberId ?? version.CreatedByMemberId,
                        NativeFactReference.Of(owner.Stream, disclosure), new ImmutableSelectionManifest(proofManifest,
                            "audit-package-validation-proof.v1", proofs.Count, SelectionOrder.CanonicalKey, proofManifest.Sha256));
                    var frozen = await content.WriteJsonAsync(tenant.ToString(), Uuid.CreateVersion4(),
                        PackageDeliveryRecordingIntent.Schema, intent, ct);
                    Assert.True(owner.AdmitDelivery(view.ProgramId, owner.Revision, version.PackageVersion, operation,
                        frozen, NativeFactReference.Of(owner.Stream, build), NativeFactReference.Of(owner.Stream, disclosure),
                        proofs, response).IsSuccess);
                    await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
                    admission = owner.Facts.OfType<AuditPackageDeliveryAdmitted>().Last();
                }
                else
                    intent = await content.ReadJsonAsync<PackageDeliveryRecordingIntent>(tenant.ToString(), admission.Intent, ct);
                var commandId = Uuid.CreateVersion5(admission.Metadata.EventId, "seed-materialization");
                var child = new AuditPackageDelivery(tenant, view.AuditPackageId, version.PackageVersion,
                    delivery.AuditPackageDeliveryId, commandId);
                if (reader is not null)
                    child = await reader.HydrateAsync(child, ct);
                if (child.IsMaterialized)
                    continue;
                var source = NativeFactReference.Of(owner.Stream, admission);
                var operationChild = SourceUseReceiverSupport.Child(commandId, nameof(MaterializeRecordedAuditPackageDelivery),
                    source.EventId, intent.Header, child.Stream, intent.RecordedAt);
                Assert.True(child.Materialize(view.ProgramId, operationChild, intent, admission.Intent, source).IsSuccess);
                await writer.SaveAsync(child, new RequestDispatchContext(RequestActor.System), ct);
            }
        }
    }

    static OperationProvenance Root(Uuid logicalId, string kind, ActorReference actor, AuditPackageManifest owner,
        long version, DateTimeOffset at) => new(logicalId, logicalId, null, kind, actor, owner.Stream,
        version.ToString(CultureInfo.InvariantCulture), owner.Revision == 0 ? null : (ulong)owner.Revision,
        new string('a', 64), at, owner.Stream, owner.Stream);
    static DurableIntentHeader Header(OperationProvenance operation) => new(operation.RootOperationId, operation.Owner,
        operation.AffectedOwner, operation.ExpectedRevisionOwner, operation.Actor, operation.Episode,
        operation.OriginalExpectedRevision, operation.AuthoredIntentSha256, operation.AcceptedAt);
}
''')
