from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
core=root/'src/Compliance.Core/Features/AuditPackages';common=root/'src/Compliance.Common/Features/AuditPackages'
# Remove the obsolete runtime aggregate and direct-worker path. Prerelease history has no dual-read path.
for f in [core/'AuditPackage.cs',core/'RecordAuditPackageBuildResultAuthorizer.cs',core/'RecordAuditPackageBuildResultHandler.cs',common/'RecordAuditPackageBuildResult.cs',common/'AuditPackageBuildFailed.cs',common/'AuditPackageBuildProgressRecorded.cs']:
 f.unlink(missing_ok=True)
# New native CLR contracts take the owning names after the full read/command migration.
for folder in [core,common]:
 for p in list(folder.glob('*V2*.cs')):
  name=p.name.replace('V2','');p.rename(folder/name)
for p in root.rglob('*.cs'):
 s=p.read_text()
 for name in ['AuditPackageCreated','AuditPackageAmended','AuditPackageBuildRequested','AuditPackageBuilt','AuditPackageValidated','AuditPackageValidationOverrideApproved','AuditPackageDisclosureApproved','AuditPackageDelivered','RecordAuditPackageBuildResult']:
  s=s.replace(name+'V2',name)
 p.write_text(s)
# Pure rules no longer instantiate any event schema, including process-only progress/failure facts.
p=core/'AuditPackageRules.cs';s=p.read_text()
def args_at(st):
 depth=1;i=st+1;begin=i;args=[];quote=None;escape=False
 while i<len(s):
  c=s[i]
  if quote:
   if escape:escape=False
   elif c=='\\':escape=True
   elif c==quote:quote=None
  elif c in '\"\'':quote=c
  elif c in '([{':depth+=1
  elif c in ')]}':
   depth-=1
   if depth==0:args.append(s[begin:i].strip());return args,i+1
  elif c==',' and depth==1:args.append(s[begin:i].strip());begin=i+1
  i+=1
 raise RuntimeError('unclosed emit')
pos=0;count=0
while True:
 st=s.find('Emit(',pos)
 if st<0 or st>s.index('    CommandFailure? Emit('):break
 lp=st+len('Emit');args,end=args_at(lp)
 keep=args[:3]+[a for a in args[3:] if a.startswith('creating:')]
 replacement='Emit('+', '.join(keep)+')'
 s=s[:st]+replacement+s[end:];pos=st+len(replacement);count+=1
s=s.replace('''    CommandFailure? Emit(AuditPackageView state, Uuid? actorMemberId, DateTimeOffset occurredAt,
        Func<Uuid, Uuid, long, Uuid?, AuditPackageView, DateTimeOffset, DomainEvent> createEvent,
        bool creating = false)''','''    CommandFailure? Emit(AuditPackageView state, Uuid? actorMemberId, DateTimeOffset occurredAt,
        bool creating = false)''')
assert 'new AuditPackageBuildFailed' not in s and 'new AuditPackageCreated' not in s
p.write_text(s)
print('Converted pure rule event factories:',count)
