from pathlib import Path
import difflib,hashlib,json,re,datetime,shutil,subprocess
root=Path('/tmp/compliance-s29-prepared');base=root/'base';work=root/'work'
paths=sorted(set(p.relative_to(base) for p in base.rglob('*.cs'))|set(p.relative_to(work) for p in work.rglob('*.cs')))
manifest=[];patches={'tests':[],'implementation':[]};oldtests=set();newtests=set()
for rel in paths:
 before=(base/rel).read_text() if (base/rel).exists() else '';after=(work/rel).read_text() if (work/rel).exists() else ''
 if before==after:continue
 kind='tests' if str(rel).startswith('test/') else 'implementation'
 patches[kind].extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+str(rel) if before else '/dev/null',tofile='b/'+str(rel) if after else '/dev/null'))
 manifest.append({'path':str(rel),'status':'added' if not before else 'deleted' if not after else 'modified','before_sha256':hashlib.sha256(before.encode()).hexdigest() if before else None,'after_sha256':hashlib.sha256(after.encode()).hexdigest() if after else None})
 if kind=='tests':
  oldtests.update(re.findall(r'public (?:async )?(?:Task|void) (Should\w+)\(',before));newtests.update(re.findall(r'public (?:async )?(?:Task|void) (Should\w+)\(',after))
for name,parts in patches.items():(root/(name+'.patch')).write_text(''.join(parts))
verify=root/'apply-check';shutil.rmtree(verify,ignore_errors=True);shutil.copytree(base,verify)
for name in ['tests','implementation']:
 done=subprocess.run(['patch','-E','-p1','--batch','--forward','-i',str(root/(name+'.patch'))],cwd=verify,capture_output=True,text=True)
 if done.returncode:raise RuntimeError(done.stdout+done.stderr)
for m in manifest:
 p=verify/m['path'];assert (not p.exists()) if m['after_sha256'] is None else hashlib.sha256(p.read_bytes()).hexdigest()==m['after_sha256'],m['path']
obj={'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Prepared native S29 owner cutover; no main source, Git, branches, issues or builds modified by this agent.','files':manifest,'files_changed':len(manifest),'original_acceptance_names':len(oldtests),'prepared_acceptance_names':len(newtests),'removed_acceptance_names':sorted(oldtests-newtests),'added_acceptance_names':sorted(newtests-oldtests),'validation':{'all_csharp_syntax_clean':True,'patch_reconstruction_matches_all_sha256':True,'dotnet_build_test':'NOT RUN; parent owns centralized orchestration'},'remaining_internal_work':[{'kind':'canonical_source_byte_publication','status':'open follow-on implementation','detail':'Native ZIP builder consumes exact tenant bytes via IArtifactContentStore and waits for missing source bytes. Existing baseline source contributors often compute canonical digests without publishing bytes. Producer-to-store publication must cover real Type I and Type II source producers before S29 is complete.'}],'shared_wiring':'shared-wiring-deltas.json','patch_application_order':['tests.patch','implementation.patch','parent-owned shared wiring deltas'],'source_of_truth':'work/ contains final prepared files. Preparation scripts are historical and must not be rerun.'}
(root/'manifest.json').write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'tests_old':len(oldtests),'tests_new':len(newtests),'removed':sorted(oldtests-newtests),'tests_patch_bytes':(root/'tests.patch').stat().st_size,'implementation_patch_bytes':(root/'implementation.patch').stat().st_size,'patch_sha_match':True},indent=2))
