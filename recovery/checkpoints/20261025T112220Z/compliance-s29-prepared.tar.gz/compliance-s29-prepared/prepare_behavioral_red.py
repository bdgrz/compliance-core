from pathlib import Path
import difflib,json
r=Path('/tmp/compliance-s29-prepared');rel='test/Compliance.Tests/Features/AuditPackages/CreateAuditPackageHandlerTests.cs'
base=(r/'base'/rel).read_text();anchor='    sealed class Fixture : IAsyncDisposable'
name='ShouldReplayCreationGivenLostResponseAndLaterRetryTime'
old='''    [Fact]
    public async Task ShouldReplayCreationGivenLostResponseAndLaterRetryTime()
    {
        // Arrange
        await using var fixture = new Fixture();
        var baseline = await fixture.SeedTypeIBaselineAsync();
        var packageId = Uuid.CreateVersion4();
        var command = fixture.Command(packageId, baseline);
        var first = await fixture.Handler().HandleAsync(Fixture.Context(fixture.UserId, command), CancellationToken.None);
        Assert.True(first.IsSuccess, first.Error?.Message);
        var retryHandler = new CreateAuditPackageHandler(fixture.Executor,
            new AuditPackageSourceBuilder(fixture.Reader), new FixedTimeProvider(Now.AddDays(1)));

        // Act
        var replay = await retryHandler.HandleAsync(Fixture.Context(fixture.UserId, command), CancellationToken.None);
        var saved = await fixture.Reader.HydrateAsync(new AuditPackageAggregate(fixture.TenantId,
            fixture.ProgramId, packageId));

        // Assert
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(1, saved.Revision);
        Assert.Equal(Now, saved.Current!.CreatedAt);
    }

'''
assert anchor in base
red=base.replace(anchor,old+anchor)
(r/'behavioral-red.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),red.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
p=r/'work'/rel;current=p.read_text();native=old.replace('''        var retryHandler = new CreateAuditPackageHandler(fixture.Executor,
            new AuditPackageSourceBuilder(fixture.Reader), new FixedTimeProvider(Now.AddDays(1)));''','''        var retryOperations = new AuditPackageRootOperation(fixture.Reader, fixture.Packages,
            new NativeOperationExecutor(fixture.Reader, fixture.Executor, fixture.ContentStore), fixture.ContentStore,
            new FixedTimeProvider(Now.AddDays(1)));
        var retryHandler = new CreateAuditPackageHandler(retryOperations,
            new AuditPackageSourceBuilder(fixture.Reader), fixture.ContentStore);''').replace('''        var saved = await fixture.Reader.HydrateAsync(new AuditPackageAggregate(fixture.TenantId,
            fixture.ProgramId, packageId));''','''        var saved = await fixture.ReadPackageAsync(packageId);''')
assert name not in current;p.write_text(current.replace(anchor,native+anchor))
(r/'behavioral-red-instructions.json').write_text(json.dumps({'filter':'FullyQualifiedName~CreateAuditPackageHandlerTests.ShouldReplayCreationGivenLostResponseAndLaterRetryTime','expected_old_failure':'First create succeeds. Identical retry one day later returns Conflict because AuditPackage.SameInitialContent compares server-created CreatedAt to the later clock, instead of replaying first-owner acceptance. Assert.True(replay.IsSuccess) fails.','order':['Apply behavioral-red.patch only to current old source/test tree.','Run focused unit filter above and preserve RED log.','Reverse behavioral-red.patch using patch -R -p1 -i before applying full tests.patch (the named regression is already included there with native dependencies).','Apply tests.patch + implementation.patch + parent shared wiring, then run same filter for GREEN.'],'new_owner_regression_preserved':name,'build_test_status':'Not run by this child; parent owns slot.'},indent=2)+'\n')
print('standalone behavioral RED patch and migrated native test saved')
