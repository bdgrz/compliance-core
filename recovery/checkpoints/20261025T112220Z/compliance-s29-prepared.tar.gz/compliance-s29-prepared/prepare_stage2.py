from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
def write(path,text):
 p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text.strip()+'\n')
core='src/Compliance.Core/Features/AuditPackages/'
common='src/Compliance.Common/Features/AuditPackages/'
s=(Path('/tmp/compliance-s29-prepared/base')/(core+'AuditPackage.cs')).read_text()
s=s.replace('public sealed class AuditPackage : Aggregate','public sealed class AuditPackageRules')
start=s.index('    public AuditPackage('); end=s.index('    public CommandFailure? Create(',start)
s=s[:start]+'''    public Uuid Id { get; }

    public AuditPackageRules(Uuid tenantId, Uuid programId, Uuid packageId, AuditPackageView? current = null)
    {
        (_tenantId, _programId, Id, _current) = (tenantId, programId, packageId, current);
    }

'''+s[end:]
start=s.index('    void Apply(AuditPackageCreated'); end=s.index('    bool ValidTransitionForEmit',start)
s=s[:start]+'''    CommandFailure? Emit(AuditPackageView state, Uuid? actorMemberId, DateTimeOffset occurredAt,
        Func<Uuid, Uuid, long, Uuid?, AuditPackageView, DateTimeOffset, DomainEvent> createEvent,
        bool creating = false)
    {
        if (state.Revision != Revision + 1 || !ValidTransitionForEmit(state, creating))
            return Invalid("The package transition does not advance exactly one valid revision.");
        _current = Freeze(state);
        return null;
    }

'''+s[end:]
s=s.replace('''/// One package stream owns its frozen source selection, deterministic manifest,
/// build attempts, validation decisions, exact-recipient disclosures, deliveries,
/// and immutable amendment lineage. Source authorization and freshness are checked
/// by handlers before they provide package content or validation results.''','''/// Pure normalization and business rules over a composed package read view. This class is not an aggregate and
/// never emits or persists events. Native owner guards recheck the local revision before any accepted delta appends.''')
# The old snapshot payload bound is inappropriate for immutable content. Keep selection/business validation bounds.
s=s.replace('    const int MaximumEventBytes = DomainEventPayload.MaximumBytes;\n','')
s=s.replace('    static bool Fits(DomainEvent ev) => DomainEventPayload.Size(ev) <= MaximumEventBytes;\n','')
s=s.replace('using Bdgrz.Compliance.Hosting.Persistence;\n','')
write(core+'AuditPackageRules.cs',s)
write(common+'AuditPackageManifestVersionContent.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>One complete immutable manifest version, with no builds, decisions, deliveries or unrelated history.</summary>
public sealed record AuditPackageManifestVersionContent(Uuid ProgramId, AuditPackageContent Content,
    AuditPackageManifestView Manifest, int? AmendsVersion, string? AmendmentReason, ActorReference CreatedBy,
    DateTimeOffset CreatedAt);
''')
write(common+'AuditPackageBuiltChange.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Only the successful verified output of one admitted build; attempts and failures are technical state.</summary>
public sealed record AuditPackageBuiltChange(Uuid BuildId, AuditPackageBuildOutput Output, DateTimeOffset CompletedAt);
''')
write(common+'AuditPackageValidationOverrideChange.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>One independent override decision on one exact validation.</summary>
public sealed record AuditPackageValidationOverrideChange(Uuid ValidationId, AuditPackageValidationOverrideView Override);
''')
write(core+'AuditPackageReader.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Composes immutable owner deltas and independently materialized deliveries for read consumers.</summary>
public sealed class AuditPackageReader(IAggregateReader reader, IImmutableContentStore content)
{
    public async ValueTask<AuditPackageSnapshot> ReadAsync(Uuid tenantId, Uuid programId, Uuid packageId,
        CancellationToken ct, Uuid selectedLogicalId = default, string? selectedCommandKind = null)
    {
        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenantId, packageId, selectedLogicalId,
            selectedCommandKind), ct).ConfigureAwait(false);
        if (!owner.IsCreated || owner.ProgramId != programId)
            return new AuditPackageSnapshot(owner, null);
        var versions = new List<AuditPackageVersionView>();
        AuditPackageView? view = null;
        foreach (var domainEvent in owner.Facts)
        {
            var fact = (IAuditPackageManifestFact)domainEvent;
            var versionNumber = checked((int)fact.PackageVersion);
            var index = versionNumber - 1;
            var actor = fact.Operation.Actor;
            var memberId = actor.Kind == "member" && Uuid.TryParse(actor.Id, CultureInfo.InvariantCulture, out var id)
                ? id : (Uuid?)null;
            switch (domainEvent)
            {
                case AuditPackageCreatedV2 or AuditPackageAmendedV2:
                {
                    var value = await PackageContent.ReadAsync<AuditPackageManifestVersionContent>(content, tenantId,
                        fact.Change, ct).ConfigureAwait(false);
                    if (value.ProgramId != programId || value.Manifest.TenantId != tenantId ||
                        value.Manifest.ProgramId != programId || value.Manifest.AuditPackageId != packageId ||
                        value.Manifest.PackageVersion != versionNumber || value.Content.ExaminationId == Uuid.Empty)
                        throw new ImmutableContentIntegrityException("A manifest version differs from its exact owner.");
                    var creator = Uuid.Parse(value.CreatedBy.Id, CultureInfo.InvariantCulture);
                    versions.Add(new AuditPackageVersionView(versionNumber, "draft", value.Content.SourceSnapshotId,
                        value.Content.SourceSnapshotKind, value.Content.SourceSnapshotSha256, value.Content.SelectedContent,
                        value.Manifest, [], [], [], [], value.AmendsVersion, value.AmendmentReason, creator,
                        value.CreatedBy.Display, value.CreatedAt, value.Content.SourcePeriodId));
                    view ??= new AuditPackageView(tenantId, programId, packageId, value.Content.ExaminationId,
                        value.Content.PackageKind, value.Content.Name, "draft", 0, 1, value.CreatedAt,
                        memberId, actor.Display, value.CreatedAt, []);
                    break;
                }
                case AuditPackageBuildRequestedV2:
                {
                    var intent = await PackageContent.ReadAsync<PackageBuildIntent>(content, tenantId, fact.Change, ct)
                        .ConfigureAwait(false);
                    var attempt = new AuditPackageBuildAttemptView(intent.BuildId, intent.BuildKey, "requested", 0,
                        versions[index].Manifest.Entries.Count, intent.Header.AcceptedAt, intent.Header.AcceptedAt,
                        memberId, actor.Display, null, null, null, null, null, null);
                    versions[index] = versions[index] with { Status = "building",
                        BuildAttempts = [.. versions[index].BuildAttempts, attempt] };
                    break;
                }
                case AuditPackageBuiltV2:
                {
                    var change = await PackageContent.ReadAsync<AuditPackageBuiltChange>(content, tenantId,
                        fact.Change, ct).ConfigureAwait(false);
                    var attempts = versions[index].BuildAttempts.ToArray();
                    var attemptIndex = Array.FindIndex(attempts, attempt => attempt.BuildAttemptId == change.BuildId);
                    if (attemptIndex < 0)
                        throw new ImmutableContentIntegrityException("A successful build has no matching admission.");
                    attempts[attemptIndex] = attempts[attemptIndex] with { Status = "built",
                        CompletedEntryCount = versions[index].Manifest.Entries.Count, UpdatedAt = change.CompletedAt,
                        CompletedAt = change.CompletedAt, ArchiveArtifactId = change.Output.ArchiveArtifactId,
                        ArchiveSha256 = change.Output.ArchiveSha256, ArchiveBytes = change.Output.ArchiveBytes };
                    versions[index] = versions[index] with { Status = "built", BuildAttempts = attempts };
                    break;
                }
                case AuditPackageValidatedV2:
                {
                    var validation = await PackageContent.ReadAsync<AuditPackageValidationView>(content, tenantId,
                        fact.Change, ct).ConfigureAwait(false);
                    versions[index] = versions[index] with { Status = validation.Status,
                        Validations = [.. versions[index].Validations, validation] };
                    break;
                }
                case AuditPackageValidationOverrideApprovedV2:
                {
                    var change = await PackageContent.ReadAsync<AuditPackageValidationOverrideChange>(content,
                        tenantId, fact.Change, ct).ConfigureAwait(false);
                    var validations = versions[index].Validations.ToArray();
                    var validationIndex = Array.FindIndex(validations,
                        validation => validation.AuditPackageValidationId == change.ValidationId);
                    if (validationIndex < 0)
                        throw new ImmutableContentIntegrityException("An override has no matching validation.");
                    validations[validationIndex] = validations[validationIndex] with {
                        Overrides = [.. validations[validationIndex].Overrides, change.Override] };
                    versions[index] = versions[index] with { Validations = validations };
                    break;
                }
                case AuditPackageDisclosureApprovedV2:
                {
                    var approval = await PackageContent.ReadAsync<AuditPackageDisclosureApprovalView>(content,
                        tenantId, fact.Change, ct).ConfigureAwait(false);
                    versions[index] = versions[index] with {
                        DisclosureApprovals = [.. versions[index].DisclosureApprovals, approval] };
                    break;
                }
                case AuditPackageDeliveryAdmitted admitted:
                {
                    versions[index] = versions[index] with { Status = "delivery_pending" };
                    var delivery = await reader.HydrateAsync(new AuditPackageDelivery(tenantId, packageId,
                        fact.PackageVersion, admitted.Operation.LogicalId), ct).ConfigureAwait(false);
                    if (delivery.Delivered is { } recorded)
                    {
                        var frozen = await PackageContent.ReadAsync<PackageDeliveryRecordingIntent>(content, tenantId,
                            recorded.Change, ct).ConfigureAwait(false);
                        if (recorded.ProgramId != programId || recorded.Change != admitted.Intent ||
                            recorded.Admission != NativeFactReference.Of(owner.Stream, admitted))
                            throw new ImmutableContentIntegrityException("A delivery differs from its exact admission.");
                        var item = new AuditPackageDeliveryView(tenantId, programId, frozen.DeliveryId, packageId,
                            versionNumber, frozen.ManifestId, frozen.ManifestSha256, frozen.ArchiveArtifactId,
                            frozen.ArchiveSha256, frozen.Recipient, frozen.DeliveryReference, "delivered", 1,
                            frozen.DeliveredAt, frozen.RecorderMemberId, frozen.Header.OriginalActor.Display);
                        versions[index] = versions[index] with { Status = "delivered",
                            Deliveries = [.. versions[index].Deliveries, item] };
                    }
                    break;
                }
            }
            if (view is not null)
                view = view with { Revision = fact.Revision, CurrentVersion = versions.Count,
                    Status = versions[^1].Status, Versions = versions.ToArray(), ActorMemberId = memberId,
                    ActorDisplay = actor.Display, UpdatedAt = fact.OccurredAt };
        }
        return new AuditPackageSnapshot(owner, view);
    }
}
''')
write(core+'AuditPackageSnapshot.cs','''namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>The native manifest and its composed read view; owner revisions never stand in for child revisions.</summary>
public sealed record AuditPackageSnapshot(AuditPackageManifest Owner, AuditPackageView? View);
''')
# Keep the created author stable in the package read model; mutable actor snapshots belong to each native fact.
p=root/(core+'AuditPackageReader.cs'); s=p.read_text().replace('memberId, actor.Display, value.CreatedAt, []);','creator, value.CreatedBy.Display, value.CreatedAt, []);')
s=s.replace('Status = validation.Status,','Status = validation.Status == "blocked" ? "validation_blocked" : "validated",')
s=s.replace('''                    validations[validationIndex] = validations[validationIndex] with {
                        Overrides = [.. validations[validationIndex].Overrides, change.Override] };
                    versions[index] = versions[index] with { Validations = validations };''','''                    var overrides = validations[validationIndex].Overrides.Append(change.Override).ToArray();
                    var complete = validations[validationIndex].Findings.Where(finding => finding.BlocksDelivery)
                        .All(finding => overrides.Any(approved => approved.FindingId == finding.FindingId));
                    validations[validationIndex] = validations[validationIndex] with {
                        Overrides = overrides, Status = complete ? "passed_with_overrides" : "blocked",
                        Revision = validations[validationIndex].Revision + 1, UpdatedAt = change.Override.ApprovedAt };
                    versions[index] = versions[index] with { Validations = validations,
                        Status = complete ? "validated_with_overrides" : "validation_blocked" };''')
s=s.replace('Status = "delivery_pending"','Status = versions[index].Deliveries.Count > 0 ? "delivered" : "delivery_pending"')
s=s.replace('''                    Status = versions[^1].Status, Versions = versions.ToArray(), ActorMemberId = memberId,
                    ActorDisplay = actor.Display, UpdatedAt = fact.OccurredAt };''','''                    Status = versions[^1].Status, Versions = versions.ToArray(), UpdatedAt = fact.OccurredAt };''')
p.write_text(s)
p=root/(core+'AuditPackageDelivery.cs'); s=p.read_text().replace('Uuid.CreateVersion5(packageId, version.ToString(CultureInfo.InvariantCulture)), deliveryId);','version.ToString(CultureInfo.InvariantCulture), deliveryId);'); p.write_text(s)
write(common+'AuditPackageCommandIdentity.cs','''using System.Globalization;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Stable logical identities retain the accepted build and personal-handoff algorithms.</summary>
public static class AuditPackageCommandIdentity
{
    static readonly Uuid BuildNamespace = Uuid.Parse("698c0bb6-2dfc-58b3-b2fd-2f3dc04369f8", CultureInfo.InvariantCulture);
    static readonly Uuid DeliveryNamespace = Uuid.Parse("53cb20d6-01ef-5fd5-99b3-04087e39bf77", CultureInfo.InvariantCulture);
    public static Uuid Build(Uuid packageId, long version, string key) => Uuid.CreateVersion5(BuildNamespace,
        $"{packageId}\\n{version}\\n{key.Trim()}");
    public static Uuid Delivery(Uuid packageId, long version, string recipient, string reference) =>
        Uuid.CreateVersion5(DeliveryNamespace, $"{packageId}\\n{version}\\n{recipient.Trim()}\\n{reference.Trim()}");
}
''')
base='''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Programs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;
'''
contracts={
'CreateAuditPackage':('Uuid TenantId, Uuid ProgramId, Uuid PackageId, AuditPackageContent Content','PackageId','IRequest'),
'AmendAuditPackage':('Uuid CommandId, Uuid TenantId, Uuid ProgramId, Uuid PackageId, long ExpectedRevision, string AmendmentReason, IReadOnlyList<Uuid>? IncludedRecordIds = null, AuditPackageContent? Content = null','CommandId','IRequest'),
'ValidateAuditPackage':('Uuid CommandId, Uuid TenantId, Uuid ProgramId, Uuid PackageId, long PackageVersion, long ExpectedRevision, string ValidationKey','CommandId','IRequest'),
'ApproveAuditPackageDisclosure':('Uuid CommandId, Uuid TenantId, Uuid ProgramId, Uuid PackageId, long PackageVersion, long ExpectedRevision, string Recipient, string Purpose, string Rationale','CommandId','IRequest'),
'ApproveAuditPackageValidationOverride':('Uuid CommandId, Uuid TenantId, Uuid ProgramId, Uuid PackageId, long PackageVersion, long ExpectedRevision, string ValidationIssue, string Rationale','CommandId','IRequest'),
'RequestAuditPackageBuild':('Uuid TenantId, Uuid ProgramId, Uuid ExaminationId, Uuid PackageId, string PackageKind, string BuildKey, long ExpectedManifestRevision, long PackageVersion','AuditPackageCommandIdentity.Build(PackageId, PackageVersion, BuildKey)','IRequest<OperationAcceptedResponse>'),
'RecordAuditPackageDelivery':('Uuid TenantId, Uuid ProgramId, Uuid PackageId, long PackageVersion, string Recipient, DateTimeOffset DeliveredAt, string DeliveryReference, Uuid DeliveryId, long ExpectedManifestRevision','DeliveryId','IRequest<OperationAcceptedResponse>')}
for name,(fields,identity,response) in contracts.items():
 old=(Path('/tmp/compliance-s29-prepared/base')/(common+name+'.cs')).read_text(); import re
 discriminator=re.search(r'\[Discriminator\("([^"]+)", (\d+)\)\]',old)
 extras='using Bdgrz.Compliance.Features.NativeOperations;\n' if 'OperationAcceptedResponse' in response else ''
 write(common+name+'.cs',extras+base+f'''
/// <summary>Authored package intent whose exact first-owner acceptance is replayed on every identical retry.</summary>
[Discriminator("{discriminator[1]}", {int(discriminator[2])+1})]
public sealed record {name}({fields})
    : {response}, IProgramScopedRequest, IClientManagementMutationRequest, ICallable, IIdentifiedRequest
{{
    Uuid IIdentifiedRequest.RequestId => {identity};
}}
''')
write(common+'RecordAuditPackageBuildResultV2.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Successful-only callback rooted in the original committed build admission, never an attempt.</summary>
[Discriminator("bdgrz.audit-packages.record-audit-package-build-result", 2)]
public sealed record RecordAuditPackageBuildResultV2(Uuid CommandId, NativeFactReference Source,
    EventStreamAddress Target, Uuid OperationId, long Generation, long? ExpectedRevision, ImmutableContentRef Intent,
    Uuid PackageId, Uuid BuildId, AuditPackageBuildOutput Output)
    : IRequest<ReceiverOutcome>, IAuditPackageReceiver, IIdentifiedRequest
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}
''')
