from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
def write(path,text):
 p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text.strip()+'\n')
core='src/Compliance.Core/Features/AuditPackages/'
imports='''using System.Globalization;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceUse;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;
'''
write(core+'AuditPackageReceiverAuthorizer.cs',imports+'''
/// <summary>Only internal process principals may dispatch effects; every handler also verifies its exact source.</summary>
sealed class AuditPackageReceiverAuthorizer : IRequestAuthorizer<IAuditPackageReceiver>
{
    public ValueTask<Result> AuthorizeAsync(IRequestContext<IAuditPackageReceiver> context, CancellationToken ct) =>
        ValueTask.FromResult(RequestActor.IsSystem(context.Actor) ? Result.Success : Result.Failure(new RequestError(
            RequestErrorKind.Forbidden, "Only the internal package process may dispatch package effects.")));
}
''')
write(core+'StartAuditPackageBuildHandler.cs',imports+'''
/// <summary>Creates verified archive bytes and durably publishes successful output before acknowledging start.</summary>
public sealed class StartAuditPackageBuildHandler(AuditPackageSourceVerifier verifier,
    AuditPackageArchiveBuilder builder, IAuditPackageBuildOutputs outputs, IImmutableContentStore content)
    : IRequestHandler<StartAuditPackageBuild, ReceiverOutcome>
{
    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<StartAuditPackageBuild> context,
        CancellationToken ct)
    {
        var command = context.Request;
        if (command.CommandId == Uuid.Empty || command.ExpectedRevision is not null ||
            !Uuid.TryParse(command.Target.Realm, CultureInfo.InvariantCulture, out var tenant) ||
            command.Target != new AuditPackageManifest(tenant, command.PackageId).Stream ||
            command.Generation != command.ManifestVersion)
            return ReceiverAppend.Invalid("The build effect names another owner, generation or revision authority.");
        try
        {
            var verified = await verifier.BuildAsync(tenant, command.PackageId, command.BuildId, command.ManifestVersion,
                command.OperationId, command.Source, command.Intent, ct).ConfigureAwait(false);
            if (!verified.IsSuccess)
                return Result<ReceiverOutcome>.Failure(verified.Error!);
            var existing = await outputs.ReadAsync(tenant, command.BuildId, ct).ConfigureAwait(false);
            if (existing is not null)
                return existing.Source == command.Source && existing.Intent == command.Intent
                    ? Result<ReceiverOutcome>.Success(new ReceiverOutcome.Performed("verified_archive_recorded"))
                    : ReceiverAppend.Invalid("The logical build output belongs to another exact source or intent.");
            if (verified.Value!.Owner.IsFrozen(command.ManifestVersion))
                return ReceiverAppend.Superseded("The admitted build version was already frozen by a delivery.");
            var built = await builder.BuildAsync(tenant, verified.Value.Manifest, ct).ConfigureAwait(false);
            if (!built.IsSuccess)
                return Result<ReceiverOutcome>.Failure(built.Error!);
            var frozen = await content.WriteJsonAsync(tenant.ToString(),
                Uuid.CreateVersion5(command.BuildId, "verified-output:" + command.Source.EventId),
                "audit-package-build-output.v1", built.Value!, ct).ConfigureAwait(false);
            await outputs.PublishIfAbsentAsync(new AuditPackageBuildOutputRecord(tenant, command.BuildId,
                command.Source, command.Intent, frozen), ct).ConfigureAwait(false);
            return Result<ReceiverOutcome>.Success(new ReceiverOutcome.Performed("verified_archive_recorded"));
        }
        catch (ImmutableContentUnavailableException exception)
        {
            return ReceiverAppend.Wait("The admitted build content is not available yet: " + exception.Message);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return ReceiverAppend.Invalid("The admitted build content cannot be verified: " + exception.Message);
        }
    }
}
''')
write(core+'RecordAuditPackageBuildResultV2Handler.cs',imports+'''
/// <summary>Records only a durable successful output whose actual ZIP verifies against the original admission.</summary>
public sealed class RecordAuditPackageBuildResultV2Handler(AuditPackageSourceVerifier verifier,
    IAggregateReader reader, ReceiverAppend append, IAuditPackageBuildOutputs outputs, IImmutableContentStore content,
    IArtifactContentStore artifacts, TimeProvider clock) : IRequestHandler<RecordAuditPackageBuildResultV2, ReceiverOutcome>
{
    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(IRequestContext<RecordAuditPackageBuildResultV2> context,
        CancellationToken ct)
    {
        var command = context.Request;
        if (command.CommandId == Uuid.Empty || command.ExpectedRevision is < 0 ||
            !Uuid.TryParse(command.Target.Realm, CultureInfo.InvariantCulture, out var tenant) ||
            command.Target != new AuditPackageManifest(tenant, command.PackageId).Stream)
            return ReceiverAppend.Invalid("The build callback names another owner or invalid revision.");
        try
        {
            var verified = await verifier.BuildAsync(tenant, command.PackageId, command.BuildId, command.Generation,
                command.OperationId, command.Source, command.Intent, ct).ConfigureAwait(false);
            if (!verified.IsSuccess)
                return Result<ReceiverOutcome>.Failure(verified.Error!);
            var operation = SourceUseReceiverSupport.Child(command.CommandId, nameof(RecordAuditPackageBuildResultV2),
                command.Source.EventId, verified.Value!.Intent.Header, command.Target, clock.GetUtcNow());
            var binding = AcceptedOperationBinding.Of(operation);
            var selected = await reader.HydrateAsync(new AuditPackageManifest(tenant, command.PackageId,
                command.CommandId, nameof(RecordAuditPackageBuildResultV2)), ct).ConfigureAwait(false);
            if (selected.Acceptance.Decide(binding) == NativeAcceptanceDecision.Conflict)
                return ReceiverAppend.Invalid("The callback command was already accepted with another intent.");
            if (selected.Acceptance.Decide(binding) == NativeAcceptanceDecision.Replayed)
                return Result<ReceiverOutcome>.Success(new ReceiverOutcome.Replayed(
                    NativeFactReference.Of(selected.Stream, selected.Acceptance.SelectedFact!)));
            if (selected.IsFrozen(command.Generation))
                return ReceiverAppend.Superseded("The exact build version has already been frozen by a delivery.");
            var checkpoint = await outputs.ReadAsync(tenant, command.BuildId, ct).ConfigureAwait(false);
            if (checkpoint is null)
                return ReceiverAppend.Wait("The verified successful build checkpoint is not visible yet.");
            if (checkpoint.Source != command.Source || checkpoint.Intent != command.Intent)
                return ReceiverAppend.Invalid("The output checkpoint belongs to another build admission.");
            var output = await PackageContent.ReadAsync<AuditPackageBuildOutput>(content, tenant,
                checkpoint.VerifiedOutput, ct).ConfigureAwait(false);
            if (!Matches(command.Output, output) || output.FailureCode is not null ||
                output.ManifestId != verified.Value.Manifest.AuditPackageManifestId ||
                output.ManifestSha256 != verified.Value.Manifest.ManifestSha256 ||
                output.IncludedEntries is null || !output.IncludedEntries.SequenceEqual(verified.Value.Manifest.Entries) ||
                output.ArchiveArtifactId is null || output.ArchiveSha256 is null || output.ArchiveBytes is not > 0)
                return ReceiverAppend.Invalid("The callback differs from the exact complete verified successful output.");
            var build = new AuditPackageBuildAttemptView(command.BuildId, verified.Value.Intent.BuildKey, "built",
                output.IncludedEntries.Count, output.IncludedEntries.Count, operation.AcceptedAt, operation.AcceptedAt,
                null, string.Empty, operation.AcceptedAt, null, null, output.ArchiveArtifactId, output.ArchiveSha256,
                output.ArchiveBytes);
            var failure = await AuditPackageArchiveVerifier.FailureCodeAsync(artifacts, tenant, build,
                verified.Value.Manifest, ct).ConfigureAwait(false);
            if (failure is not null)
                return failure == "archive_content_unavailable" ? ReceiverAppend.Wait("The actual archive is unavailable.")
                    : ReceiverAppend.Invalid("The actual archive does not match the frozen manifest.");
            var change = await PackageContent.WriteAsync(content, tenant, "AuditPackageBuilt.change.v1",
                new AuditPackageBuiltChange(command.BuildId, output, operation.AcceptedAt), ct).ConfigureAwait(false);
            return await append.ApplyAsync(() => new AuditPackageManifest(tenant, command.PackageId,
                    command.CommandId, nameof(RecordAuditPackageBuildResultV2)), owner => owner.Acceptance, binding,
                owner => owner.IsFrozen(command.Generation)
                    ? ReceiverAppend.Superseded("The exact version was frozen by a delivery.") : null,
                owner => owner.RecordBuilt(verified.Value.Admission.ProgramId, command.ExpectedRevision ?? owner.Revision,
                    command.Generation, operation, command.Source, change), context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException exception)
        {
            return ReceiverAppend.Wait("The successful output content is not available yet: " + exception.Message);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return ReceiverAppend.Invalid("The successful output content cannot be verified: " + exception.Message);
        }
    }

    static bool Matches(AuditPackageBuildOutput left, AuditPackageBuildOutput right) =>
        left.ManifestId == right.ManifestId && left.ManifestSha256 == right.ManifestSha256 &&
        left.ArchiveArtifactId == right.ArchiveArtifactId && left.ArchiveSha256 == right.ArchiveSha256 &&
        left.ArchiveBytes == right.ArchiveBytes && left.FailureCode == right.FailureCode &&
        left.IncludedEntries is not null && right.IncludedEntries is not null &&
        left.IncludedEntries.SequenceEqual(right.IncludedEntries);
}
''')
write(core+'MaterializeRecordedAuditPackageDeliveryHandler.cs',imports+'''
/// <summary>Materializes the exact admitted personal handoff even after a later manifest version exists.</summary>
public sealed class MaterializeRecordedAuditPackageDeliveryHandler(AuditPackageSourceVerifier verifier,
    IAggregateReader reader, ReceiverAppend append, TimeProvider clock)
    : IRequestHandler<MaterializeRecordedAuditPackageDelivery, ReceiverOutcome>
{
    public async ValueTask<Result<ReceiverOutcome>> HandleAsync(
        IRequestContext<MaterializeRecordedAuditPackageDelivery> context, CancellationToken ct)
    {
        var command = context.Request;
        if (command.CommandId == Uuid.Empty || command.ExpectedRevision is not (null or 0) ||
            !Uuid.TryParse(command.Target.Realm, CultureInfo.InvariantCulture, out var tenant) ||
            command.Generation != command.ManifestVersion || command.Target != new AuditPackageDelivery(tenant,
                command.PackageId, command.ManifestVersion, command.DeliveryId).Stream)
            return ReceiverAppend.Invalid("The historical handoff names another child, generation or revision.");
        try
        {
            var verified = await verifier.DeliveryAsync(tenant, command.PackageId, command.DeliveryId,
                command.ManifestVersion, command.OperationId, command.Source, command.Intent, ct).ConfigureAwait(false);
            if (!verified.IsSuccess)
                return Result<ReceiverOutcome>.Failure(verified.Error!);
            var parent = await reader.HydrateAsync(new AuditPackageManifest(tenant, command.PackageId), ct)
                .ConfigureAwait(false);
            var admitted = (AuditPackageDeliveryAdmitted)parent.FactById(command.Source.EventId)!;
            var operation = SourceUseReceiverSupport.Child(command.CommandId, nameof(MaterializeRecordedAuditPackageDelivery),
                command.Source.EventId, verified.Value!.Header, command.Target, clock.GetUtcNow());
            return await append.ApplyAsync(() => new AuditPackageDelivery(tenant, command.PackageId,
                    command.ManifestVersion, command.DeliveryId, command.CommandId), owner => owner.Acceptance,
                AcceptedOperationBinding.Of(operation), owner => owner.IsMaterialized
                    ? ReceiverAppend.Invalid("The handoff child was materialized by another logical effect.") : null,
                owner => owner.Materialize(admitted.ProgramId, operation, verified.Value!, command.Intent,
                    command.Source), context, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentUnavailableException exception)
        {
            return ReceiverAppend.Wait("The admitted handoff content is not available yet: " + exception.Message);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return ReceiverAppend.Invalid("The admitted handoff content cannot be verified: " + exception.Message);
        }
    }
}
''')
