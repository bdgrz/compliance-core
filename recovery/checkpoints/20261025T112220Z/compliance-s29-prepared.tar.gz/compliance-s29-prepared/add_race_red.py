from pathlib import Path
rel='test/Compliance.Tests/Features/AuditPackages/CreateAuditPackageHandlerTests.cs'
method='''    [Fact]
    public async Task ShouldReplayCreationGivenEqualConcurrentCommitBetweenInitialReadAndPreparation()
    {
        // Arrange
        await using var fixture = new Fixture();
        var baseline = await fixture.SeedTypeIBaselineAsync();
        var packageId = Uuid.CreateVersion4();
        var command = fixture.Command(packageId, baseline);
        var raced = false;
        var reader = new InterleavedPackageReader(fixture.Reader, async () =>
        {
            var winner = await fixture.Handler().HandleAsync(Fixture.Context(fixture.UserId, command),
                CancellationToken.None);
            Assert.True(winner.IsSuccess, winner.Error?.Message);
            raced = true;
        });
        var packages = new AuditPackageReader(reader, fixture.ContentStore);
        var operations = new AuditPackageRootOperation(reader, packages,
            new NativeOperationExecutor(reader, fixture.Executor, fixture.ContentStore), fixture.ContentStore,
            new FixedTimeProvider(Now));
        var handler = new CreateAuditPackageHandler(operations, new AuditPackageSourceBuilder(fixture.Reader),
            fixture.ContentStore);

        // Act
        var replay = await handler.HandleAsync(Fixture.Context(fixture.UserId, command), CancellationToken.None);
        var saved = await fixture.ReadPackageAsync(packageId);

        // Assert
        Assert.True(raced);
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(1, saved.Revision);
        Assert.Single((await fixture.Packages.ReadAsync(fixture.TenantId, fixture.ProgramId, packageId,
            CancellationToken.None)).Owner.Facts.OfType<AuditPackageCreated>());
    }

'''
helper='''    sealed class InterleavedPackageReader(IAggregateReader inner, Func<Task> beforeSecondRead) : IAggregateReader
    {
        int _packageReads;
        public async ValueTask<TAggregate> HydrateAsync<TAggregate>(TAggregate aggregate,
            CancellationToken ct = default) where TAggregate : Aggregate
        {
            if (aggregate is AuditPackageManifest && Interlocked.Increment(ref _packageReads) == 2)
                await beforeSecondRead();
            return await inner.HydrateAsync(aggregate, ct);
        }
    }

'''
for root in [Path('.'),Path('/tmp/compliance-s29-prepared/work')]:
 p=root/rel;s=p.read_text();assert 'ShouldReplayCreationGivenEqualConcurrentCommitBetweenInitialReadAndPreparation' not in s
 s=s.replace('    sealed class Fixture : IAsyncDisposable',method+'    sealed class Fixture : IAsyncDisposable')
 s=s.replace('    sealed class FixedTimeProvider',helper+'    sealed class FixedTimeProvider');p.write_text(s)
print('focused native race RED saved; implementation unchanged')
