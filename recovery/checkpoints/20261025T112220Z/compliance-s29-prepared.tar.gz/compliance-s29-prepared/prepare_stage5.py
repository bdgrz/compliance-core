from pathlib import Path
root=Path('/tmp/compliance-s29-prepared/work')
def write(path,text):
 p=root/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text.strip()+'\n')
core='src/Compliance.Core/Features/AuditPackages/'
imports='''using System.Globalization;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Versioning;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;
'''
write(core+'RecordAuditPackageDeliveryHandler.cs',imports+'''
/// <summary>Admits a personal historical handoff and freezes its version before the child is materialized.</summary>
public sealed class RecordAuditPackageDeliveryHandler(AuditPackageRootOperation operations,
    IImmutableContentStore content, IArtifactContentStore artifacts)
    : IRequestHandler<RecordAuditPackageDelivery, OperationAcceptedResponse>
{
    public async ValueTask<Result<OperationAcceptedResponse>> HandleAsync(
        IRequestContext<RecordAuditPackageDelivery> context, CancellationToken ct)
    {
        var request = context.Request;
        var outcome = await operations.ExecuteAsync(context, request.TenantId, request.ProgramId, request.PackageId,
            request.DeliveryId, nameof(RecordAuditPackageDelivery), request.ExpectedManifestRevision,
            _ => request.PackageVersion,
            owner => owner.PrepareWrite(request.ProgramId, request.ExpectedManifestRevision, request.PackageVersion,
                allowFrozen: true), async (snapshot, operation, token) =>
            {
                if (request.DeliveredAt == default || request.DeliveredAt > operation.AcceptedAt ||
                    string.IsNullOrWhiteSpace(request.Recipient) || string.IsNullOrWhiteSpace(request.DeliveryReference) ||
                    request.DeliveryId != AuditPackageCommandIdentity.Delivery(request.PackageId, request.PackageVersion,
                        request.Recipient, request.DeliveryReference))
                    return PackageChanges.Invalid("Delivery requires its stable identity and an authored handoff time in the past.");
                var view = snapshot.View!;
                var version = view.Versions[^1];
                var rules = new AuditPackageRules(request.TenantId, request.ProgramId, request.PackageId, view);
                if (rules.RecordDelivery(request.ExpectedManifestRevision, checked((int)request.PackageVersion),
                        request.Recipient, request.DeliveryReference, PackageChanges.Member(operation), operation.Actor.Display,
                        operation.AcceptedAt) is { } failure)
                    return PackageChanges.Failure(failure);
                var build = version.BuildAttempts.Last(attempt => attempt.Status == "built");
                var unavailable = await AuditPackageArchiveVerifier.FailureCodeAsync(artifacts, request.TenantId,
                    build, version.Manifest, token).ConfigureAwait(false);
                if (unavailable is not null)
                    return Result<PreparedPackageDelta>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The exact actual archive must verify before delivery admission: " + unavailable,
                        unavailable == "archive_content_unavailable"));
                var approval = version.DisclosureApprovals.Last(item => item.Recipient == request.Recipient.Trim() &&
                    item.ManifestId == version.Manifest.AuditPackageManifestId &&
                    item.ManifestSha256 == version.Manifest.ManifestSha256);
                if (request.DeliveredAt < approval.ApprovedAt)
                    return PackageChanges.Conflict("The external handoff cannot precede its exact disclosure approval.");
                NativeFactReference? buildProof = null;
                NativeFactReference? disclosureProof = null;
                var validationProofs = new List<NativeFactReference>();
                var validation = version.Validations[^1];
                foreach (var fact in snapshot.Owner.Facts)
                {
                    if (fact is not IAuditPackageManifestFact native || native.PackageVersion != request.PackageVersion)
                        continue;
                    if (fact is AuditPackageBuiltV2)
                    {
                        var built = await PackageContent.ReadAsync<AuditPackageBuiltChange>(content, request.TenantId,
                            native.Change, token).ConfigureAwait(false);
                        if (built.BuildId == build.BuildAttemptId)
                            buildProof = NativeFactReference.Of(snapshot.Owner.Stream, fact);
                    }
                    if (fact is AuditPackageDisclosureApprovedV2)
                    {
                        var approved = await PackageContent.ReadAsync<AuditPackageDisclosureApprovalView>(content,
                            request.TenantId, native.Change, token).ConfigureAwait(false);
                        if (approved.DisclosureApprovalId == approval.DisclosureApprovalId)
                            disclosureProof = NativeFactReference.Of(snapshot.Owner.Stream, fact);
                    }
                    if (fact is AuditPackageValidatedV2)
                    {
                        var checkedValidation = await PackageContent.ReadAsync<AuditPackageValidationView>(content,
                            request.TenantId, native.Change, token).ConfigureAwait(false);
                        if (checkedValidation.AuditPackageValidationId == validation.AuditPackageValidationId)
                        {
                            validationProofs.Clear();
                            validationProofs.Add(NativeFactReference.Of(snapshot.Owner.Stream, fact));
                        }
                    }
                    if (fact is AuditPackageValidationOverrideApprovedV2)
                    {
                        var approved = await PackageContent.ReadAsync<AuditPackageValidationOverrideChange>(content,
                            request.TenantId, native.Change, token).ConfigureAwait(false);
                        if (approved.ValidationId == validation.AuditPackageValidationId &&
                            validation.Overrides.Any(item => item == approved.Override))
                            validationProofs.Add(NativeFactReference.Of(snapshot.Owner.Stream, fact));
                    }
                }
                if (buildProof is null || disclosureProof is null || validationProofs.Count == 0)
                    return PackageChanges.Conflict("The package's exact native approval proofs are incomplete.");
                var proofs = await PackageContent.WriteAsync<IReadOnlyList<NativeFactReference>>(content,
                    request.TenantId, "audit-package-validation-proof.v1", validationProofs, token).ConfigureAwait(false);
                var intent = new PackageDeliveryRecordingIntent(PackageContent.Header(operation), request.DeliveryId,
                    request.PackageId, request.PackageVersion, version.Manifest.AuditPackageManifestId,
                    version.Manifest.ManifestSha256, build.ArchiveArtifactId!.Value, build.ArchiveSha256!,
                    request.Recipient.Trim(), request.DeliveryReference.Trim(), request.DeliveredAt, operation.AcceptedAt,
                    PackageChanges.Member(operation), disclosureProof, new ImmutableSelectionManifest(proofs,
                        "audit-package-validation-proof.v1", validationProofs.Count, SelectionOrder.CanonicalKey, proofs.Sha256));
                var frozen = await PackageContent.WriteAsync(content, request.TenantId,
                    PackageDeliveryRecordingIntent.Schema, intent, token).ConfigureAwait(false);
                return Result<PreparedPackageDelta>.Success(new PreparedPackageDelta(frozen, buildProof, disclosureProof,
                    validationProofs));
            }, (owner, operation, delta, response, _) => owner.AdmitDelivery(request.ProgramId,
                request.ExpectedManifestRevision, request.PackageVersion, operation, delta.Content, delta.Build!,
                delta.Disclosure!, delta.Validations!, response), true, ct).ConfigureAwait(false);
        return await operations.AcknowledgmentAsync(request.TenantId, outcome, ct).ConfigureAwait(false);
    }
}
''')
write(core+'VerifiedPackageBuild.cs','''namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Verified immutable build admission and exact manifest/selection, independent of current source owners.</summary>
public sealed record VerifiedPackageBuild(AuditPackageManifest Owner, AuditPackageBuildRequestedV2 Admission,
    PackageBuildIntent Intent, AuditPackageManifestView Manifest);
''')
write(core+'AuditPackageSourceVerifier.cs',imports+'''
/// <summary>Verifies source facts on their authoritative owner, then binds every frozen build/delivery field.</summary>
public sealed class AuditPackageSourceVerifier(IAggregateReader reader, IImmutableContentStore content)
{
    public async ValueTask<Result<VerifiedPackageBuild>> BuildAsync(Uuid tenant, Uuid packageId, Uuid buildId,
        long version, Uuid operationId, NativeFactReference source, ImmutableContentRef reference, CancellationToken ct)
    {
        if (reference.Schema != PackageBuildIntent.Schema)
            return BuildFailure("The build intent has another schema.");
        var intent = await PackageContent.ReadAsync<PackageBuildIntent>(content, tenant, reference, ct)
            .ConfigureAwait(false);
        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, packageId), ct).ConfigureAwait(false);
        if (source.Stream != owner.Stream || owner.FactById(source.EventId) is not AuditPackageBuildRequestedV2 admitted)
            return BuildFailure("The exact admitted build is not visible yet.", true);
        if (admitted.Metadata.AggregateVersion != source.AggregateVersion || admitted.Change != reference ||
            admitted.PackageVersion != version || admitted.Operation.LogicalId != buildId ||
            intent.PackageId != packageId || intent.PackageVersion != version || intent.BuildId != buildId ||
            operationId != buildId || !HeaderMatches(intent.Header, admitted.Operation) ||
            intent.BuildId != AuditPackageCommandIdentity.Build(packageId, version, intent.BuildKey))
            return BuildFailure("The build differs from its exact immutable admission.");
        var manifest = await PackageContent.ReadAsync<AuditPackageManifestView>(content, tenant, intent.Manifest, ct)
            .ConfigureAwait(false);
        var selection = await PackageContent.ReadAsync<IReadOnlyList<AuditPackageSelectionEntry>>(content, tenant,
            intent.Selection.Content, ct).ConfigureAwait(false);
        var expected = manifest.Entries.OrderBy(entry => entry.RelativePath, StringComparer.Ordinal)
            .Select(entry => entry.Source).ToArray();
        if (manifest.TenantId != tenant || manifest.ProgramId != admitted.ProgramId || manifest.AuditPackageId != packageId ||
            manifest.PackageVersion != version || manifest.AuditPackageManifestId != intent.ManifestId ||
            manifest.ManifestSha256 != intent.ManifestSha256 || intent.Selection.Count != selection.Count ||
            intent.Selection.ItemsSha256 != intent.Selection.Content.Sha256 ||
            intent.Selection.ItemSchema != "audit-package-selection-entry.v1" ||
            intent.Selection.Content.Schema != intent.Selection.ItemSchema || !selection.SequenceEqual(expected))
            return BuildFailure("The complete build manifest and selection do not match their admitted identity.");
        return Result<VerifiedPackageBuild>.Success(new VerifiedPackageBuild(owner, admitted, intent, manifest));
    }

    public async ValueTask<Result<PackageDeliveryRecordingIntent>> DeliveryAsync(Uuid tenant, Uuid packageId,
        Uuid deliveryId, long version, Uuid operationId, NativeFactReference source, ImmutableContentRef reference,
        CancellationToken ct)
    {
        if (reference.Schema != PackageDeliveryRecordingIntent.Schema)
            return DeliveryFailure("The delivery intent has another schema.");
        var intent = await PackageContent.ReadAsync<PackageDeliveryRecordingIntent>(content, tenant, reference, ct)
            .ConfigureAwait(false);
        var owner = await reader.HydrateAsync(new AuditPackageManifest(tenant, packageId), ct).ConfigureAwait(false);
        if (source.Stream != owner.Stream || owner.FactById(source.EventId) is not AuditPackageDeliveryAdmitted admitted)
            return DeliveryFailure("The exact delivery admission is not visible yet.", true);
        if (admitted.Metadata.AggregateVersion != source.AggregateVersion || admitted.Intent != reference ||
            admitted.PackageVersion != version || admitted.Operation.LogicalId != deliveryId || operationId != deliveryId ||
            intent.PackageId != packageId || intent.PackageVersion != version || intent.DeliveryId != deliveryId ||
            intent.RecordedAt != admitted.OccurredAt || intent.RecordedAt != intent.Header.AcceptedAt ||
            !HeaderMatches(intent.Header, admitted.Operation) ||
            intent.Header.OriginalActor.Kind != "member" || intent.Header.OriginalActor.Id != intent.RecorderMemberId.ToString() ||
            intent.DeliveredAt == default || intent.DeliveredAt > intent.RecordedAt ||
            deliveryId != AuditPackageCommandIdentity.Delivery(packageId, version, intent.Recipient, intent.DeliveryReference))
            return DeliveryFailure("The delivery differs from its exact admitted personal handoff.");
        if (intent.DisclosureApproval.Stream != owner.Stream ||
            owner.FactById(intent.DisclosureApproval.EventId) is not AuditPackageDisclosureApprovedV2 approvalFact ||
            approvalFact.Metadata.AggregateVersion != intent.DisclosureApproval.AggregateVersion ||
            approvalFact.PackageVersion != version || approvalFact.Revision >= admitted.Revision)
            return DeliveryFailure("The handoff does not pin an earlier disclosure on this exact manifest.");
        var approval = await PackageContent.ReadAsync<AuditPackageDisclosureApprovalView>(content, tenant,
            approvalFact.Change, ct).ConfigureAwait(false);
        if (approval.ManifestId != intent.ManifestId || approval.ManifestSha256 != intent.ManifestSha256 ||
            approval.Recipient != intent.Recipient || intent.DeliveredAt < approval.ApprovedAt)
            return DeliveryFailure("The handoff differs from its exact approved recipient, manifest or time.");
        var proofs = await PackageContent.ReadAsync<IReadOnlyList<NativeFactReference>>(content, tenant,
            intent.ValidationProofs.Content, ct).ConfigureAwait(false);
        if (proofs.Count == 0 || intent.ValidationProofs.Count != proofs.Count ||
            intent.ValidationProofs.ItemsSha256 != intent.ValidationProofs.Content.Sha256 ||
            proofs.Any(proof => proof.Stream != owner.Stream || owner.FactById(proof.EventId) is not IAuditPackageManifestFact fact ||
                fact.PackageVersion != version || fact.Revision >= admitted.Revision ||
                ((DomainEvent)fact).Metadata.AggregateVersion != proof.AggregateVersion))
            return DeliveryFailure("The complete validation proof manifest does not match this handoff admission.");
        var latest = owner.Facts.OfType<AuditPackageValidatedV2>().LastOrDefault(fact =>
            fact.PackageVersion == version && fact.Revision < admitted.Revision);
        if (latest is null || proofs.All(proof => proof.EventId != latest.Metadata.EventId))
            return DeliveryFailure("The handoff omits the latest applicable validation.");
        var validation = await PackageContent.ReadAsync<AuditPackageValidationView>(content, tenant, latest.Change, ct)
            .ConfigureAwait(false);
        if (validation.ManifestId != intent.ManifestId || validation.ManifestSha256 != intent.ManifestSha256)
            return DeliveryFailure("The validation concerns another exact manifest.");
        var overrides = new List<AuditPackageValidationOverrideView>();
        foreach (var proof in proofs.Where(proof => proof.EventId != latest.Metadata.EventId))
        {
            if (owner.FactById(proof.EventId) is not AuditPackageValidationOverrideApprovedV2 fact)
                return DeliveryFailure("The validation manifest contains an unrelated native fact.");
            var change = await PackageContent.ReadAsync<AuditPackageValidationOverrideChange>(content, tenant,
                fact.Change, ct).ConfigureAwait(false);
            if (change.ValidationId != validation.AuditPackageValidationId ||
                change.Override.ApprovedByMemberId == validation.ValidatedByMemberId ||
                !validation.Findings.Any(finding => finding.FindingId == change.Override.FindingId &&
                    finding.BlocksDelivery && finding.OverrideAllowed))
                return DeliveryFailure("A handoff override is unrelated, ineligible or not independently approved.");
            overrides.Add(change.Override);
        }
        if (validation.Findings.Any(finding => finding.BlocksDelivery &&
                !overrides.Any(approved => approved.FindingId == finding.FindingId)))
            return DeliveryFailure("The handoff has an unresolved blocking validation finding.");
        return Result<PackageDeliveryRecordingIntent>.Success(intent);
    }

    static bool HeaderMatches(DurableIntentHeader header, OperationProvenance operation) =>
        header.RootOperationId == operation.RootOperationId && header.FirstOwner == operation.Owner &&
        header.AffectedOwner == operation.AffectedOwner && header.ExpectedRevisionOwner == operation.ExpectedRevisionOwner &&
        header.OriginalActor == operation.Actor && header.Episode == operation.Episode &&
        header.OriginalExpectedRevision == operation.OriginalExpectedRevision &&
        header.AuthoredIntentSha256 == operation.AuthoredIntentSha256 && header.AcceptedAt == operation.AcceptedAt;
    static Result<VerifiedPackageBuild> BuildFailure(string message, bool transient = false) =>
        Result<VerifiedPackageBuild>.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
    static Result<PackageDeliveryRecordingIntent> DeliveryFailure(string message, bool transient = false) =>
        Result<PackageDeliveryRecordingIntent>.Failure(new RequestError(RequestErrorKind.Conflict, message, transient));
}
''')
