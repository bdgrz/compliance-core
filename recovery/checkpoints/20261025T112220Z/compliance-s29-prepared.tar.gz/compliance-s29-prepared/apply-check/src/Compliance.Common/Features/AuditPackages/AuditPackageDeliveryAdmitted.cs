using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>Freezes an exact personal external-handoff attestation before independent historical materialization.</summary>
[Discriminator("bdgrz.audit-package-manifest.delivery-admitted", 1)]
public sealed record AuditPackageDeliveryAdmitted(Uuid TenantId, Uuid SubjectId, Uuid ProgramId,
    long Revision, long PackageVersion, ImmutableContentRef Intent, DateTimeOffset OccurredAt,
    OperationProvenance Operation, ImmutableContentRef? FirstResponse) : DomainEvent, IAuditPackageManifestFact
{
    ImmutableContentRef IAuditPackageManifestFact.Change => Intent;
}
