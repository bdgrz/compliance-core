using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.AuditPackages;

/// <summary>The independently materialized historical handoff; no external transmission is performed.</summary>
[Discriminator("bdgrz.auditpackages.audit-package-delivered", 2)]
public sealed record AuditPackageDelivered(Uuid TenantId, Uuid SubjectId, Uuid ProgramId, Uuid PackageId,
    long PackageVersion, Uuid DeliveryId, ImmutableContentRef Change, NativeFactReference Admission,
    DateTimeOffset OccurredAt, OperationProvenance Operation) : DomainEvent, INativeOperationFact
{
    public ImmutableContentRef? FirstResponse => null;
}
