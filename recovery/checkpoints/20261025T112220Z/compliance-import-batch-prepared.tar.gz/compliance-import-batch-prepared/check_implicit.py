from pathlib import Path
import json
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
p=Parser(Language(tree_sitter_c_sharp.language()));r=Path('/tmp/compliance-import-batch-prepared/work')
expected={'StageApplicationImportHandler':(4,4),'CancelApplicationImportHandler':(4,4),'AcceptApplicationImportHandler':(5,6),'CorrelateApplicationImportRowHandler':(5,5),'FreezeApplicationImportOmissionProposalHandler':(5,5)}
rows=[]
for f in r.rglob('*.cs'):
 b=f.read_bytes();stack=[p.parse(b).root_node]
 while stack:
  n=stack.pop();stack.extend(n.children)
  if n.type!='implicit_object_creation_expression':continue
  a=n.parent
  while a and a.type not in ['property_declaration','method_declaration','variable_declaration']:a=a.parent
  if not a:continue
  typ=a.child_by_field_name('type') or a.child_by_field_name('returns')
  if not typ:continue
  name=b[typ.start_byte:typ.end_byte].decode();args=n.child_by_field_name('arguments') or next((child for child in n.named_children if child.type=='argument_list'),None)
  if name not in expected or not args:continue
  count=sum(c.type=='argument' for c in args.named_children);row={'path':str(f.relative_to(r)),'type':name,'arguments':count};rows.append(row);assert expected[name][0]<=count<=expected[name][1],row
print(json.dumps(rows))
