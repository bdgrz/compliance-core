using Bdgrz.Compliance.Features.Applications;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Applications;

public sealed class ApplicationImportAcceptPreparationReplayTests
{
    [Fact]
    public async Task ShouldReplayEqualAcceptanceGivenLosingPlanWriteUnavailableAfterConcurrentSeal()
    {
        // Arrange
        await using var host = new ApplicationImportHost();
        var batch = await host.StageBatchAsync();
        var row = Assert.Single(await host.RowsAsync(batch));
        Assert.True((await host.CorrelateAsync(batch.Id, row.RowId, 1, "create_new")).IsSuccess);
        var command = new AcceptApplicationImport(Uuid.CreateVersion4(), host.TenantId, batch.Id, 2);
        OperationAcceptedResponse? winner = null;
        var store = new LosingPlanStore(host.Content, async () =>
        {
            var accepted = await host.AcceptAsync(batch.Id, 2, command.CommandId);
            Assert.True(accepted.IsSuccess, accepted.Error?.Message);
            winner = accepted.Value;
        });
        var native = new NativeOperationExecutor(host.Reader, host.Services.GetRequiredService<IAggregateExecutor>(), store);
        var handler = ActivatorUtilities.CreateInstance<AcceptApplicationImportHandler>(host.Services, native, store);
        Result<OperationAcceptedResponse> replay = default;

        // Act
        var error = await Record.ExceptionAsync(async () => replay = await handler.HandleAsync(host.Context(command), CancellationToken.None));
        var saved = await host.BatchAsync(batch.Id);

        // Assert
        Assert.Null(error);
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(winner, replay.Value);
        Assert.NotNull(saved.Plan);
        Assert.Equal(3, saved.Revision);
        Assert.Equal(1, store.CompetingSeals);
    }

    sealed class LosingPlanStore(IImmutableContentStore inner, Func<Task> seal) : IImmutableContentStore
    {
        bool _armed = true;
        public int CompetingSeals { get; private set; }
        public async Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema,
            string mediaType, ReadOnlyMemory<byte> bytes, CancellationToken ct = default)
        {
            if (_armed && schema == ImportFrozenPlanIntent.Schema)
            {
                _armed = false;
                await seal();
                CompetingSeals++;
                throw new ImmutableContentUnavailableException("The losing frozen plan write is temporarily unavailable.");
            }
            return await inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        }
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference,
            CancellationToken ct = default) => inner.ReadVerifiedAsync(realm, reference, ct);
    }
}
