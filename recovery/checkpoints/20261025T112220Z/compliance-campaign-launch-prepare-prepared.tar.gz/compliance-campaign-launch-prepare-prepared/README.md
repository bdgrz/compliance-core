# Campaign launch preparation prefix (2 paths)

FROZEN independently of the larger campaign/participant history migration. `implementation.patch` moves real material/roster source resolution, guard results and immutable audience/registration/result writes inside native async preparation, so the central equal-winner and requested-cancellation recovery applies. No per-family recovery catch is added. Current actor/auth, complete frozen audience, exact source callbacks, raw request digest, Unit/registration response bytes and atomic two-fact launch remain their original behavior.

Constructor changes from4services to3: operations,content,clock. Existing `AddScoped<CampaignLaunch>()` needs no edit. The only explicit constructors are the new real race test's two calls; all assertions/names remain.

Use full-from-clean.patch when the race test is absent, or full-after-red.patch if the stable existing-API race test remains installed. New-file mode100644 is explicit. Source-only plus tests-after-red.patch is also exact. Do not include the separate temporary failing lifetime RED in a prefix-only merge. Full-family artifact must layer this prefix before any later owner changes, rather than replay it.

No .NET/format/runtime/Jev/Git/main commands run by preparation agent. Parent must first qualify old-API race theory2, then strict build/focused/full checks and direct exact-source Jev. Original parent RED3 patch is immutable in /tmp/compliance-policy-campaign-native-prepared.
