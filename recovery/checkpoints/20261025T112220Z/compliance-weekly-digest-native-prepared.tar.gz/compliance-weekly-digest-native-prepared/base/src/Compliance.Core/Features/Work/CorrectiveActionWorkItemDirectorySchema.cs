using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Work;

static class CorrectiveActionWorkItemDirectorySchema
{
    public static readonly KvDirectory<AccountableWorkItemProjectionRevision, string> Revisions =
        new("projection_revisions",
            ComplianceCoreJsonContext.Default.AccountableWorkItemProjectionRevision,
            static revision => revision.ProjectorName,
            static projectorName => [projectorName], []);

    public static readonly KvDirectoryIndex<AccountableWorkItemView> ByProgram = new(
        "by_program", 1, static item =>
            [item.ProgramId.ToString(), item.WorkItemId.ToString()]);

    public static readonly KvDirectoryIndex<AccountableWorkItemView> ByFinding = new(
        "by_finding", 1, static item =>
            [item.ProgramId.ToString(), item.FindingId!.Value.ToString(), item.WorkItemId.ToString()]);

    public static readonly KvDirectory<AccountableWorkItemView, Uuid> WorkItems = new(
        "accountable_work_items", ComplianceCoreJsonContext.Default.AccountableWorkItemView,
        static item => WorkItemKey(item.ProgramId, item.WorkItemId),
        static key => [key.ToString()], [ByProgram, ByFinding]);

    public static Uuid WorkItemKey(Uuid programId, Uuid workItemId) =>
        Uuid.CreateVersion5(programId, $"accountable-work-item:{workItemId}");
}
