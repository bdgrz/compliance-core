from pathlib import Path
import difflib,hashlib,json,subprocess,tempfile,shutil,re
r=Path('/tmp/compliance-weekly-digest-native-prepared');prior=Path('/tmp/compliance-work-digest-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((r/'behavioral-red.patch').read_bytes())=='41abf9674fe274d5172e6cc69d15604a05aec43d2dc0c30715fbaf75ac488dc9'
changed=sorted(str(f.relative_to(r/'work')) for f in (r/'work').rglob('*') if f.is_file() and (not(r/'base'/f.relative_to(r/'work')).exists() or f.read_bytes()!=(r/'base'/f.relative_to(r/'work')).read_bytes()))
def before(p):return (r/'base'/p).read_bytes() if(r/'base'/p).exists() else b''
def diff(paths,override=None):
 out=''
 for p in paths:
  b=(override or {}).get(p,before(p));a=(r/'work'/p).read_bytes()
  out+=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+p if b else '/dev/null',tofile='b/'+p))
 return out
with tempfile.TemporaryDirectory(prefix='digest-native-red-') as d:
 for path in changed:
  if (r/'base'/path).exists():
   target=Path(d)/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/'base'/path,target)
 proc=subprocess.run(['patch','--batch','-p1','-d',d,'-i',str(r/'behavioral-red.patch')],capture_output=True,text=True)
 if proc.returncode:raise SystemExit(proc.stdout+proc.stderr)
 red={str(p.relative_to(d)):p.read_bytes() for p in Path(d).rglob('*') if p.is_file()}
sources=[p for p in changed if p.startswith('src/')];tests=[p for p in changed if p.startswith('test/')]
shared=['src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs']
for name,paths,override in [('full.patch',changed,None),('implementation.patch',sources,None),('tests.patch',tests,None),('after-red.patch',changed,red),('shared-deltas.patch',shared,None)]:
 (r/name).write_text(diff(paths,override))
priorpaths={x['path']:x for x in json.loads((prior/'manifest.json').read_text())}
manifest=[]
for p in changed:
 b=before(p) if(r/'base'/p).exists() else None;a=(r/'work'/p).read_bytes()
 manifest.append({'path':p,'before':sha(b) if b is not None else None,'after':sha(a),'kind':'source' if p.startswith('src/') else 'test','shared':p in shared,'digest35Prerequisite':p in priorpaths,'matchesDigest35After':sha(b)==priorpaths[p]['after'] if p in priorpaths and b is not None else None,'currentMainMatchesBefore':(repo/p).read_bytes()==b if(repo/p).exists() else b is None})
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checks=[]
for label,seq in [('full',['full.patch']),('partitioned',['tests.patch','implementation.patch']),('qualified-red-then-green',['behavioral-red.patch','after-red.patch'])]:
 with tempfile.TemporaryDirectory(prefix='digest-native-reconstruct-') as d:
  q=Path(d)
  for p in changed:
   if(r/'base'/p).exists():(q/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/'base'/p,q/p)
  for patch in seq:
   proc=subprocess.run(['patch','--batch','-p1','-d',d,'-i',str(r/patch)],capture_output=True,text=True)
   if proc.returncode:raise SystemExit((label,patch,proc.stdout,proc.stderr))
  bad=[p for p in changed if not(q/p).exists() or(q/p).read_bytes()!=(r/'work'/p).read_bytes()]
  if bad:raise SystemExit((label,bad))
  checks.append({'sequence':label,'exactFiles':len(changed),'passed':True})
(r/'reconstruction.json').write_text(json.dumps(checks,indent=2)+'\n')
new=[];rows=0
for p in tests:
 old=set(re.findall(r'\b(Should\w+)\s*\(',before(p).decode()));a=(r/'work'/p).read_text()
 new.extend({'path':p,'name':n} for n in re.findall(r'\b(Should\w+)\s*\(',a) if n not in old)
 if not(r/'base'/p).exists():rows+=len(re.findall(r'\[Fact\]',a))+len(re.findall(r'\[InlineData\(',a))
report={'changed':len(changed),'source':len(sources),'tests':len(tests),'shared':shared,'newMethods':len(new),'newRows':rows,'manifestSha256':sha((r/'manifest.json').read_bytes()),'patchHashes':{p:sha((r/p).read_bytes()) for p in ['behavioral-red.patch','implementation.patch','tests.patch','shared-deltas.patch','after-red.patch','full.patch']},'digest35Mismatch':[m['path'] for m in manifest if m['digest35Prerequisite'] and not m['matchesDigest35After']],'driftedAgainstCurrentMain':[m['path'] for m in manifest if not m['currentMainMatchesBefore']],'reconstruction':checks}
(r/'export-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
