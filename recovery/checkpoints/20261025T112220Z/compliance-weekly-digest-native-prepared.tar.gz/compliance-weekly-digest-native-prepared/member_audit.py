from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json,re
r=Path('/tmp/compliance-weekly-digest-native-prepared/work');parser=Parser(Language(tree_sitter_c_sharp.language()))
def walk(n):
 yield n
 for c in n.children:yield from walk(c)
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
errors=[];variables=0
for f in (r/'test').rglob('*.cs'):
 t=f.read_bytes()
 for method in walk(parser.parse(t).root_node):
  if method.type!='method_declaration':continue
  kinds={}
  for n in walk(method):
   if n.type!='variable_declarator':continue
   name=n.child_by_field_name('name');v=tx(t,n)
   if name and re.search(r'=\s*new (WeeklyWorkDigestRules|WorkDigestDispatchRules)\(',v):kinds[tx(t,name)]='rules'
   elif name and re.search(r'=\s*await .*\.ReadWeeklyAsync\(',v):kinds[tx(t,name)]='weekly_snapshot'
   elif name and re.search(r'=\s*await .*\.ReadDispatchAsync\(',v):kinds[tx(t,name)]='dispatch_snapshot'
  variables+=len(kinds)
  for n in walk(method):
   if n.type!='member_access_expression':continue
   expr=n.child_by_field_name('expression');name=n.child_by_field_name('name')
   if not expr or not name:continue
   var=tx(t,expr);member=tx(t,name);kind=kinds.get(var)
   bad=kind=='rules' and member in {'Stream','Version','Acceptance','CommittedStreamPosition'} or kind=='weekly_snapshot' and member in {'Read','Revision','Status','DeliveryAttempts','Stream','Version','Schedule','RequestDelivery','RecordDeliveryResult'} or kind=='dispatch_snapshot' and member in {'Version','Stream','StartAttempt','AuthorizeUnknownRetry','RecordSent'}
   if bad:errors.append({'path':str(f.relative_to(r)),'line':t[:n.start_byte].count(b'\n')+1,'variable':var,'kind':kind,'member':member})
  for var,kind in kinds.items():
   if re.search(r'\.SaveAsync\('+re.escape(var)+r'\s*,',tx(t,method)):errors.append({'path':str(f.relative_to(r)),'method':tx(t,method.child_by_field_name('name')),'invalidDirectSave':var,'kind':kind})
result={'qualified':'Static member-shape check, not C# compilation','trackedVariables':variables,'errors':errors};(r.parent/'member-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
