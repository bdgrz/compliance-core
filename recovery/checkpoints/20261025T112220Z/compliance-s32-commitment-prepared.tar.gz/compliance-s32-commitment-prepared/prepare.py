from pathlib import Path
import difflib,hashlib,json
ROOT=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
OUT=Path('/tmp/compliance-s32-commitment-prepared')
changes={}
def original(path):
 dest=OUT/'before'/path
 if not dest.exists():
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/path).read_bytes())
 return dest.read_text()
def put(path,text,phase='implementation'):
 if path not in changes:changes[path]={'before':original(path) if (ROOT/path).exists() else None,'phase':phase}
 dest=OUT/'after'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
def diff(path,a,b):
 return f'diff --git a/{path} b/{path}\n'+('new file mode 100644\n' if a is None else '')+''.join(difflib.unified_diff((a or '').splitlines(True),b.splitlines(True),fromfile='/dev/null' if a is None else 'a/'+path,tofile='b/'+path))

test='test/Compliance.Tests/Features/Commitments/CommitmentDraftReplayTests.cs';before=original(test)
red='''    [Fact]
    public async Task ShouldCreateLegalLargeDraftGivenEscapedStatementAndContext()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var serviceId = Uuid.CreateVersion4();
        var user = Uuid.CreateVersion4();
        var id = CommitmentDraft.IdFor(tenant, program, "service_commitment", "SC-LARGE");
        await using var provider = ProgramManagementServices.Build(new RecordingPermissionAuthorizer(allowed: true),
            portia => portia.AddRequestHandler<CreateCommitmentDraftHandler>());
        await ProgramManagementServices.SeedAsync(provider, new ClientService(tenant, serviceId),
            service => service.Create(program, "Service", "Purpose", "Operations", user, "Author", DateTimeOffset.UtcNow));
        var request = new CreateCommitmentDraft(id, tenant, program, serviceId, "service_commitment", "SC-LARGE",
            new string('<', 16000), new string('<', 16000), "Signed MSA");

        // Act
        // Assert
        await Dispatch(provider, ProgramManagementServices.Actor(user), request, id)
            .ExpectSuccess(new CommitmentDraftRegistration(id, "service_commitment", "SC-LARGE", 1));
    }

'''
marker='    [Fact]\n    public async Task ShouldReplayOriginalCreateAndRejectNewDraftGivenRetiredService()';assert marker in before
put(test,before.replace(marker,red+marker),'tests');changes[test]['red']=before.replace(marker,red+marker)

test='test/Compliance.Tests/Features/Commitments/PersonalCommitmentDecisionTransportTests.cs';before=original(test)
red='''    [Fact]
    public async Task ShouldReplayOriginalRetirementGivenSameCommandAndLaterServerClock()
    {
        // Arrange
        await using var fixture = await Fixture.CreateAsync(approval: true);
        Assert.True((await fixture.DecideAsync(approval: true, "http")).IsSuccess);
        var commandId = Uuid.CreateVersion4();
        var request = new RetireCommitment(fixture.Tenant, fixture.Program, fixture.DraftId, 1,
            new DateOnly(2027, 1, 1), "The original accepted retirement.");
        var first = await IdentifiedRetirementAsync(fixture.Provider, fixture.Approver, request, commandId);
        Assert.True(first.IsSuccess, first.Error?.Message);
        var accepted = await fixture.ReadAsync();
        fixture.Clock.Now = fixture.Clock.Now.AddMinutes(1);

        // Act
        var replay = await IdentifiedRetirementAsync(fixture.Provider, fixture.Approver, request, commandId);
        var retained = await fixture.ReadAsync();

        // Assert
        Assert.True(replay.IsSuccess, replay.Error?.Message);
        Assert.Equal(accepted.CommittedStreamPosition, retained.CommittedStreamPosition);
        Assert.Equal(accepted.RetiredEffectiveOn, retained.RetiredEffectiveOn);
        Assert.Equal(accepted.RetirementRationale, retained.RetirementRationale);
    }

    static async Task<Result> IdentifiedRetirementAsync(IServiceProvider provider, Uuid user, RetireCommitment request, Uuid commandId)
    {
        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<IRequestBus>().DispatchAsync(request,
            new RequestDispatchContext(ProgramManagementServices.Actor(user),
                new HttpInvocation("POST", "/synthetic/commitment/retirement", "/synthetic/commitment/retirement", "synthetic"),
                new RequestMetadata(commandId, commandId)), CancellationToken.None);
    }

'''
marker='    [Theory]\n    [InlineData(false, "direct")]';assert marker in before
red_test = before.replace(marker,red+marker,1)
red_test = red_test.replace('        public ServiceProvider Provider => _provider;', '        public ServiceProvider Provider => _provider;\n        public FixtureClock Clock { get; } = new();')
red_test = red_test.replace('            _provider = services.BuildServiceProvider', '            services.AddSingleton<TimeProvider>(Clock);\n            _provider = services.BuildServiceProvider')
clock = '''        public sealed class FixtureClock : TimeProvider
        {
            public DateTimeOffset Now { get; set; } = new(2026, 9, 1, 13, 0, 0, TimeSpan.Zero);
            public override DateTimeOffset GetUtcNow() => Now;
        }

'''
red_test = red_test.replace('        public ValueTask DisposeAsync() => _provider.DisposeAsync();', clock+'        public ValueTask DisposeAsync() => _provider.DisposeAsync();')
put(test,red_test,'tests');changes[test]['red']=red_test

def emit():
 phases={'tests':[],'implementation':[],'migrated-tests':[],'http-tests':[]};manifest=[]
 for path,row in sorted(changes.items()):
  text=(OUT/'after'/path).read_text()
  if 'red' in row:
   phases['tests'].append(diff(path,row['before'],row['red']))
   if text!=row['red']:phases['migrated-tests'].append(diff(path,row['red'],text))
  else:phases[row['phase']].append(diff(path,row['before'],text))
  manifest.append({'path':path,'phase':row['phase'],'beforeSha256':hashlib.sha256(row['before'].encode()).hexdigest() if row['before'] is not None else None,'afterSha256':hashlib.sha256(text.encode()).hexdigest()})
 for phase,parts in phases.items():(OUT/(phase+'.patch')).write_text(''.join(parts))
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Prepared',len(manifest),'paths')
if __name__=='__main__':emit()
