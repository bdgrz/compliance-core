from pathlib import Path
import re,json
import prepare as p
C='src/Compliance.Common/Features/Commitments/';K='src/Compliance.Core/Features/Commitments/'
EVENTS=['CommitmentDraftCreated','CommitmentDraftRevised','CommitmentReviewed','CommitmentApproved','CommitmentRetired']
def source(path):return p.original(path)
def put(path,text,phase='implementation'):p.put(path,text,phase)
def new(path,text,phase='implementation'):put(path,text.strip()+'\n',phase)

# Original complete mutation payloads remain typed immutable material. Native roots carry only bounded current metadata.
for name in EVENTS:
 old=source(C+name+'.cs');m=re.search(r'public sealed record '+name+r'\((.*?)\)\s*:\s*DomainEvent',old,re.S);assert m,name
 content=old[:m.start()]+f'public sealed record {name}Content('+m.group(1)+') : ICommitmentMutationContent'+old[m.end():]
 content=re.sub(r'\[Discriminator\([^\n]+\)\]\n','',content)
 content=re.sub(r'    \[JsonIgnore\(Condition = JsonIgnoreCondition.WhenWritingNull\)\]\n    public OperationProvenance\? Operation \{ get; init; \}\n\n','',content)
 content=content.replace('using Bdgrz.Compliance.Features.NativeOperations;\n','')
 put(C+name+'Content.cs',content)

new(C+'CommitmentDraftContent.cs','''namespace Bdgrz.Compliance.Features.Commitments;

public sealed record CommitmentDraftContent(string Statement, string Context, string SourceReference);''')
new(C+'CommitmentAuthorityHeader.cs','''using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed record CommitmentAuthorityHeader(Uuid TenantId, Uuid ProgramId, Uuid DraftId, Uuid ServiceId,
    Uuid? ProviderId, string Kind, string Identifier, long Revision, bool IsCreated, bool IsRetired,
    string SourceReference, long EffectiveVersionCount, long? LatestEffectiveRevision, DateOnly? LatestEffectiveFrom,
    Uuid? AcceptedReviewDecisionId, Uuid? AcceptedReviewerMemberId, DateOnly? RetiredEffectiveOn, ImmutableContentRef Content);''')
new(C+'CommitmentDecisionConstraint.cs','''using Bdgrz.Compliance.Features.Responsibilities;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed record CommitmentDecisionConstraint(Uuid MemberId, ResponsibilityType Type, DateTimeOffset At, Uuid? WaiverId);''')
new(C+'CommitmentAuthorityContent.cs','''using Bdgrz.Compliance.Features.Responsibilities;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed record CommitmentAuthorityContent(CommitmentAuthorityHeader Header, IReadOnlyList<Uuid> PendingAuthorMemberIds,
    IReadOnlyList<ResponsibilityAssignmentView> Assignments, IReadOnlyList<CommitmentDecisionConstraint> DecisionConstraints);''')
new(C+'ICommitmentMutationContent.cs','''using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.Responsibilities;

namespace Bdgrz.Compliance.Features.Commitments;

[JsonPolymorphic(TypeDiscriminatorPropertyName = "$commitment_change")]
'''+''.join(f'[JsonDerivedType(typeof({n}Content), "{n}")]\n' for n in EVENTS)+'''[JsonDerivedType(typeof(ResponsibilityAssigned), "ResponsibilityAssigned")]
[JsonDerivedType(typeof(ResponsibilityRevoked), "ResponsibilityRevoked")]
public interface ICommitmentMutationContent { }''')
new(C+'CommitmentMutationContent.cs','''using Bdgrz.Compliance.Features.AccessControl;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed record CommitmentMutationContent(IReadOnlyList<ICommitmentMutationContent> Changes,
    IReadOnlyList<SeparationOfDutiesWaiverProof>? Waivers = null, ICommitmentMutationContent? Receipt = null);''')
new(C+'ICommitmentFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public interface ICommitmentFact : INativeOperationFact
{
    Uuid TenantId { get; }
    CommitmentAuthorityHeader Header { get; }
    ImmutableContentRef Change { get; }
    ImmutableContentRef Authority { get; }
    ImmutableContentRef? OperationResult { get; }
    long NativeSequence { get; }
    int ChangeCount { get; }
}''')
heads={
'CommitmentDraftCreated':'''Uuid TenantId, Uuid ProgramId, Uuid DraftId, Uuid CreateRequestId, Uuid ServiceId,
    string Kind, string Identifier, ImmutableContentRef Content, string SourceReference,
    Uuid ActorMemberId, string ActorDisplay, DateTimeOffset ChangedAt''',
'CommitmentDraftRevised':'''Uuid TenantId, Uuid ProgramId, Uuid DraftId, long Revision, ImmutableContentRef Content,
    string SourceReference, Uuid ActorMemberId, string ActorDisplay, DateTimeOffset ChangedAt''',
'CommitmentReviewed':'''Uuid TenantId, Uuid ProgramId, Uuid DraftId, long Revision, Uuid DecisionId, string Outcome,
    long? Version, DateOnly? EffectiveFrom, Uuid ActorMemberId, string ActorDisplay, DateTimeOffset DecidedAt,
    Uuid? SeparationOfDutiesWaiverId = null, string? SourceVerification = null''',
'CommitmentApproved':'''Uuid TenantId, Uuid ProgramId, Uuid DraftId, long Revision, Uuid DecisionId,
    Uuid AcceptedReviewDecisionId, long Version, DateOnly EffectiveFrom, Uuid ActorMemberId,
    string ActorDisplay, DateTimeOffset DecidedAt, Uuid? SeparationOfDutiesWaiverId = null''',
'CommitmentRetired':'''Uuid TenantId, Uuid ProgramId, Uuid SubjectId, long Revision, Uuid? ActorMemberId,
    string ActorDisplay, DateOnly EffectiveOn, DateTimeOffset OccurredAt'''}
for name,head in heads.items():
 old=source(C+name+'.cs');disc=re.search(r'\[Discriminator\((.*?)\)\]',old).group(1);disc=re.sub(r', 1$',', 2',disc)
 native='''using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

'''+f'[Discriminator({disc})]\npublic sealed record {name}({head}) : DomainEvent, ICommitmentFact\n'+'''{
    public OperationProvenance Operation { get; init; } = default!;
    public ImmutableContentRef? FirstResponse { get; init; }
    public ImmutableContentRef? OperationResult { get; init; }
    public CommitmentAuthorityHeader Header { get; init; } = default!;
    public ImmutableContentRef Change { get; init; } = default!;
    public ImmutableContentRef Authority { get; init; } = default!;
    public long NativeSequence { get; init; }
    public int ChangeCount { get; init; }
'''
 if name=='CommitmentDraftCreated':native+='    public Uuid? ProviderId { get; init; }\n'
 native+='''    [JsonPropertyName("actor")]
    public ActorReference? StoredActor { get; init; }
    [JsonIgnore]
    public ActorReference Actor => StoredActor ?? ActorReference.ForMember('''+('ActorMemberId ?? Uuid.Empty' if name=='CommitmentRetired' else 'ActorMemberId')+''', ActorDisplay);
}
'''
 put(C+name+'.cs',native)

# Shared events gain an optional area-specific header. Existing Control and legacy Boundary serialization stays byte-compatible when null.
for name in ['ResponsibilityAssigned','ResponsibilityRevoked']:
 path='src/Compliance.Common/Features/Responsibilities/'+name+'.cs';old=source(path)
 old='using Bdgrz.Compliance.Features.Commitments;\n'+old
 old=old.replace(': DomainEvent, IControlFact, IControlMutationContent',': DomainEvent, IControlFact, IControlMutationContent, ICommitmentFact, ICommitmentMutationContent')
 point='    [JsonPropertyName("actor")]'
 insert='''    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public CommitmentAuthorityHeader? CommitmentHeader { get; init; }
    CommitmentAuthorityHeader ICommitmentFact.Header => CommitmentHeader!;

'''
 assert point in old;old=old.replace(point,insert+point);put(path,old)

# Retirement acquires the selected stable ID; existing own Unit request signatures stay plain for the global transport adapter.
old=source(C+'RetireCommitment.cs').replace('record RetireCommitment(Uuid TenantId','record RetireCommitment(Uuid CommandId, Uuid TenantId').replace('IClientManagementMutationRequest, ICallable;','IClientManagementMutationRequest, IIdentifiedRequest, ICallable\n{\n    Uuid IIdentifiedRequest.RequestId => CommandId;\n}')
old=old.replace('[Discriminator("bdgrz.commitments.retire-commitment", 1)]','[Discriminator("bdgrz.commitments.retire-commitment", 2)]')
put(C+'RetireCommitment.cs',old)
if __name__=='__main__':p.emit()

rules=source(K+'CommitmentDraft.cs')
rules=rules.replace('public sealed class CommitmentDraft : Aggregate','public sealed class CommitmentRules')
a=rules.index('    public NativeAcceptance ReplayAcceptance');b=rules.index('    // Fitz stream frames',a)
rules=rules[:a]+'''    readonly Dictionary<Type, Action<ICommitmentMutationContent>> _reducers = [];
    readonly List<ICommitmentMutationContent> _pendingChanges = [];
    readonly List<ICommitmentMutationContent> _appliedChanges = [];
    readonly Dictionary<Uuid, SeparationOfDutiesWaiverProof> _waivers = [];
    public Uuid Id { get; }
    public Uuid TenantId => _tenantId;
    public ulong SourcePhysicalPosition { get; internal set; }
    public IReadOnlyList<ICommitmentMutationContent> PendingChanges => _pendingChanges.AsReadOnly();
    internal IReadOnlyList<ICommitmentMutationContent> AppliedChanges => _appliedChanges.AsReadOnly();
    public void ClearPendingChanges() => _pendingChanges.Clear();
    void On<T>(Action<T> reducer) where T : ICommitmentMutationContent =>
        _reducers.Add(typeof(T), value => reducer((T)value));
    void RaiseEvent<T>(T value) where T : ICommitmentMutationContent
    {
        Apply(value);
        _pendingChanges.Add(value);
    }
    public void Apply(ICommitmentMutationContent value)
    {
        if (!_reducers.TryGetValue(value.GetType(), out var reducer))
            throw new InvalidOperationException("The Commitment change has another content kind.");
        reducer(value);
        _appliedChanges.Add(value);
    }

'''+rules[b:]
a=rules.index('    public CommitmentDraft(Uuid');b=rules.index('        _tenantId = tenantId;',a)
rules=rules[:a]+'''    public CommitmentRules(Uuid tenantId, Uuid draftId)
    {
        Id = draftId;
'''+rules[b:]
for name in sorted(EVENTS,key=len,reverse=True):rules=re.sub(r'\b'+name+r'\b',name+'Content',rules)
rules=re.sub(r'            AuthoredCommandReplay.Observe\([^\n]*\);\n','',rules)
rules=re.sub(r'''        if \(AuthoredCommandReplay.TryReplay\(ReplayAcceptance, operation, out var replayFailure\)\)\n            return replayFailure;\n        _pendingOperation = operation;\n''','',rules)
rules=rules.replace(',\n        OperationProvenance? operation = null','')
rules=re.sub(r'            Operation = _pendingOperation,\n','',rules)
rules=rules.replace('SeparationOfDutiesWaiver?', 'SeparationOfDutiesWaiverProof?').replace('IReadOnlyList<SeparationOfDutiesWaiver>','IReadOnlyList<SeparationOfDutiesWaiverProof>')
rules=rules.replace('separationOfDutiesWaiver?.Id','separationOfDutiesWaiver?.WaiverId')
rules=rules.replace('ResponsibilityDecisionGuard.Validate(set,','ResponsibilityDecisionGuard.ValidateAuthorized(set,')
rules=rules.replace('waiver.Allows(waiverScope, memberId, at)','CommitmentWaiverProof.Allows(waiver, _tenantId, waiverScope, memberId, at)')
rules=rules.replace('return set.Assign(assignmentId,','return set.AssignAuthorized(assignmentId,')
rules=re.sub(r'''        if \(JsonSerializer.SerializeToUtf8Bytes\(created,\n                ComplianceCoreJsonContext.Default.CommitmentDraftCreatedContent\).Length >\n            MaximumDraftEventPayloadBytes\)\n            return Result<CommitmentDraftRegistration>.Failure\(new RequestError\(\n                RequestErrorKind.Validation, "The draft exceeds the bounded event payload size."\)\);\n''','',rules)
rules=re.sub(r'''        if \(JsonSerializer.SerializeToUtf8Bytes\(revised,\n                ComplianceCoreJsonContext.Default.CommitmentDraftRevisedContent\).Length >\n            MaximumDraftEventPayloadBytes\)\n            return CommandFailure.InvalidContent\("The draft exceeds the bounded event payload size."\);\n''','',rules)
rules=rules.replace('    static RequestError? Validate(', '    internal static RequestError? Validate(')
rules=rules.replace('using Bdgrz.Compliance.Features.NativeOperations;\n','').replace('using System.Text.Json;\n','')
# Keep exact scalar member identity separate from an optional legacy/process ActorReference snapshot.
rules=rules.replace('    readonly Uuid _tenantId;','''    readonly Uuid _tenantId;
    string _statement = string.Empty;
    string _context = string.Empty;
    Uuid _lastContentMemberId;
    string _lastContentDisplay = string.Empty;
    ActorReference? _lastContentActor;
    DateTimeOffset _lastContentAt;
    CommitmentReviewedContent? _lastReview;
    readonly List<CommitmentVersionView> _readVersions = [];
    readonly List<CommitmentDecisionView> _readDecisions = [];
    readonly List<CommitmentDraftRevisionView> _readRevisions = [];''')
rules=rules.replace('''            _pendingAuthors.Add(ev.ActorMemberId);
        });
        On<CommitmentDraftRevisedContent>''','''            _pendingAuthors.Add(ev.ActorMemberId);
            CaptureDraft(ev.Statement, ev.Context, ev.ActorMemberId, ev.ActorDisplay, ev.Actor, ev.ChangedAt);
        });
        On<CommitmentDraftRevisedContent>''',1)
rules=rules.replace('''            _pendingAuthors.Add(ev.ActorMemberId);
        });
        On<CommitmentReviewedContent>''','''            _pendingAuthors.Add(ev.ActorMemberId);
            _lastReview = null;
            CaptureDraft(ev.Statement, ev.Context, ev.ActorMemberId, ev.ActorDisplay, ev.Actor, ev.ChangedAt);
        });
        On<CommitmentReviewedContent>''',1)
rules=rules.replace('''        On<CommitmentReviewedContent>(ev =>
        {''','''        On<CommitmentReviewedContent>(ev =>
        {
            _lastReview = ev;
            var decision = ReviewView(ev);
            _readDecisions.Add(decision);
            if (ev.Version is { } legacyVersion && ev.EffectiveFrom is { } legacyFrom)
                _readVersions.Add(VersionView(legacyVersion, ev.Revision, legacyFrom, decision, null));''',1)
rules=rules.replace('''        On<CommitmentApprovedContent>(ev =>
        {''','''        On<CommitmentApprovedContent>(ev =>
        {
            var approval = ApprovalView(ev);
            _readDecisions.Add(approval);
            var review = _readDecisions.LastOrDefault(item => item.DecisionId == ev.AcceptedReviewDecisionId && item.Stage == "review");
            if (review is not null)
                _readVersions.Add(VersionView(ev.Version, ev.Revision, ev.EffectiveFrom, review, approval));''',1)
# Remember already authorized immutable proofs only in transient preparation and frozen mutation data.
for name in ['CommitmentReviewedContent','CommitmentApprovedContent']:
 token='        RaiseEvent(new '+name+'('
 rules=rules.replace(token,'        if (separationOfDutiesWaiver is not null)\n            _waivers[separationOfDutiesWaiver.WaiverId] = separationOfDutiesWaiver;\n'+token)
rules=rules.replace('''        return set.AssignAuthorized(assignmentId,''','''        foreach (var waiver in waivers)
            _waivers[waiver.WaiverId] = waiver;
        return set.AssignAuthorized(assignmentId,''')
assert 'ReplayAcceptance' not in rules and '_pendingOperation' not in rules and 'OperationProvenance' not in rules
put(K+'CommitmentRules.cs',rules)

new(K+'CommitmentWaiverProof.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

static class CommitmentWaiverProof
{
    public static bool Allows(SeparationOfDutiesWaiverProof proof, Uuid tenant, SeparationOfDutiesWaiverScope scope,
        Uuid actor, DateTimeOffset at) => proof.TenantId == tenant && proof.WaiverId != Uuid.Empty && proof.SubjectId == actor &&
        proof.ActorId == actor && proof.Action == scope.Action && proof.TargetType == scope.RecordType && proof.TargetId == scope.RecordId &&
        proof.TargetVersionId == scope.VersionId && proof.TargetRevision == scope.Revision &&
        proof.ApprovalFact.Source == new EventStreamAddress(tenant.ToString(), "separation-of-duties-waivers", proof.WaiverId.ToString()) &&
        proof.ApprovalFact.EventId != Uuid.Empty && proof.ApprovalFact.ResourcePosition == 1 && proof.ApprovalFact.AggregateVersion == 2 &&
        proof.ApprovalFact.PayloadSha256 is { Length: 64 } sha && sha.All(character => character is >= '0' and <= '9' or >= 'a' and <= 'f') &&
        at >= proof.ValidFrom && at < proof.ValidUntil;
}''')
if __name__=='__main__':p.emit()

rules=(p.OUT/'after'/K/'CommitmentRules.cs').read_text();rules=rules.rstrip();assert rules.endswith('}')
rules=rules[:-1]+(p.OUT/'templates/CommitmentRulesRead.csfrag').read_text()+'}\n'
put(K+'CommitmentRules.cs',rules)
if __name__=='__main__':p.emit()

put(K+'CommitmentDraft.cs',(p.OUT/'templates/CommitmentDraft.cs').read_text())
if __name__=='__main__':p.emit()

heads={'CommitmentDraftCreated':['TenantId','ProgramId','DraftId','CreateRequestId','ServiceId','Kind','Identifier','Content','SourceReference','ActorMemberId','ActorDisplay','ChangedAt'],
'CommitmentDraftRevised':['TenantId','ProgramId','DraftId','Revision','Content','SourceReference','ActorMemberId','ActorDisplay','ChangedAt'],
'CommitmentReviewed':['TenantId','ProgramId','DraftId','Revision','DecisionId','Outcome','Version','EffectiveFrom','ActorMemberId','ActorDisplay','DecidedAt','SeparationOfDutiesWaiverId','SourceVerification'],
'CommitmentApproved':['TenantId','ProgramId','DraftId','Revision','DecisionId','AcceptedReviewDecisionId','Version','EffectiveFrom','ActorMemberId','ActorDisplay','DecidedAt','SeparationOfDutiesWaiverId'],
'CommitmentRetired':['TenantId','ProgramId','SubjectId','Revision','ActorMemberId','ActorDisplay','EffectiveOn','OccurredAt']}
kindmap={'CreateCommitmentDraft':'CommitmentDraftCreated','ReviseCommitmentDraft':'CommitmentDraftRevised','ReviewCommitmentDraft':'CommitmentReviewed','ApproveCommitmentDraft':'CommitmentApproved','RetireCommitment':'CommitmentRetired','AssignResponsibility':'ResponsibilityAssigned','RevokeResponsibility':'ResponsibilityRevoked'}
f='''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Responsibilities;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public static class CommitmentFactFactory
{
    public static DomainEvent Create(string kind, CommitmentAuthorityHeader header, long sequence, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result,
        CommitmentMutationContent mutation) => kind switch
    {
'''
for kind,event in kindmap.items():f+=f'        nameof({kind}) => {event}(header, sequence, operation, change, authority, first, result, mutation),\n'
f+='''        _ => throw new InvalidOperationException("The commitment command kind is not selected."),
    };
    static T Selected<T>(CommitmentMutationContent mutation) where T : class, ICommitmentMutationContent =>
        (mutation.Changes.Count == 0 ? mutation.Receipt as T : mutation.Changes.OfType<T>().SingleOrDefault())
        ?? throw new InvalidOperationException("The commitment command has another exact prepared content kind.");
'''
for event,args in heads.items():
 fields=['header.Content' if a=='Content' else 'data.'+a for a in args]
 f+=f'''    static {event} {event}(CommitmentAuthorityHeader header, long sequence, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result,
        CommitmentMutationContent mutation)
    {{
        var data = Selected<{event}Content>(mutation);
        return new({', '.join(fields)})
        {{
            Operation = operation, Header = header, Change = change, Authority = authority, NativeSequence = sequence,
            ChangeCount = mutation.Changes.Count, FirstResponse = first, OperationResult = result, StoredActor = data.StoredActor,
'''
 if event=='CommitmentDraftCreated':f+='            ProviderId = data.ProviderId,\n'
 f+='        };\n    }\n'
for event in ['ResponsibilityAssigned','ResponsibilityRevoked']:
 f+=f'''    static {event} {event}(CommitmentAuthorityHeader header, long sequence, OperationProvenance operation,
        ImmutableContentRef change, ImmutableContentRef authority, ImmutableContentRef first, ImmutableContentRef result,
        CommitmentMutationContent mutation)
    {{
        var data = Selected<{event}>(mutation);
        return data with {{ Operation = operation, CommitmentHeader = header, Change = change, Authority = authority,
            NativeSequence = sequence, ChangeCount = mutation.Changes.Count, FirstResponse = first, OperationResult = result }};
    }}
'''
f+='}\n';put(K+'CommitmentFactFactory.cs',f)
new(K+'CommitmentReadFailure.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

static class CommitmentReadFailure
{
    public static RequestError Of(ImmutableContentIntegrityException error) => new(RequestErrorKind.Conflict,
        "The commitment immutable content cannot be verified.", error is ImmutableContentUnavailableException);
}''')
scopes='\n'.join(f'        {n}Content data => data.TenantId == header.TenantId && data.ProgramId == header.ProgramId && data.'+('SubjectId' if n=='CommitmentRetired' else 'DraftId')+' == header.DraftId,' for n in EVENTS)
new(K+'CommitmentFactContent.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.Responsibilities;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public static class CommitmentFactContent
{
    public const string ContentSchema = "commitment-authored-content.v1";
    public const string ChangeSchema = "commitment-mutation-change.v1";
    public const string AuthoritySchema = "commitment-current-authority.v1";
    public static async ValueTask<CommitmentMutationContent> ReadChangeAsync(IImmutableContentStore content,
        ICommitmentFact fact, CancellationToken ct = default)
    {
        ValidateScope(fact);
        if (fact.Change.Schema != ChangeSchema || fact.FirstResponse is null || fact.OperationResult is null)
            throw new ImmutableContentIntegrityException("The commitment change has another content or response schema.");
        var mutation = await content.ReadJsonAsync<CommitmentMutationContent>(fact.TenantId.ToString(), fact.Change, ct).ConfigureAwait(false);
        if (mutation.Changes is null || mutation.Changes.Count != fact.ChangeCount || mutation.Changes.Any(change => !InScope(change, fact.Header)) ||
            mutation.Receipt is { } receipt && !InScope(receipt, fact.Header) ||
            mutation.Changes.Count == 0 != (mutation.Receipt is not null))
            throw new ImmutableContentIntegrityException("The commitment change differs from its exact native scope and receipt.");
        DomainEvent expected;
        try
        {
            expected = CommitmentFactFactory.Create(fact.Operation.CommandKind, fact.Header, fact.NativeSequence,
                fact.Operation, fact.Change, fact.Authority, fact.FirstResponse, fact.OperationResult, mutation);
        }
        catch (InvalidOperationException)
        {
            throw new ImmutableContentIntegrityException("The commitment mutation has no exact selected native receipt.");
        }
        if (fact is not DomainEvent original || original.GetType() != expected.GetType() ||
            ContentDigest.Sha256(original, original.GetType()) != ContentDigest.Sha256(expected, expected.GetType()))
            throw new ImmutableContentIntegrityException("The native commitment receipt differs from its immutable original mutation.");
        return mutation;
    }
    public static ValueTask<CommitmentDraftContent> ReadDraftAsync(IImmutableContentStore content, ICommitmentFact fact,
        CancellationToken ct = default) => ReadContentAsync(content, fact, ct);
    public static async ValueTask<CommitmentDraftContent> ReadContentAsync(IImmutableContentStore content,
        ICommitmentFact fact, CancellationToken ct = default)
    {
        ValidateScope(fact);
        if (fact.Header.Content.Schema != ContentSchema)
            throw new ImmutableContentIntegrityException("The commitment authored body has another schema.");
        var body = await content.ReadJsonAsync<CommitmentDraftContent>(fact.TenantId.ToString(), fact.Header.Content, ct).ConfigureAwait(false);
        if (CommitmentRules.Validate(fact.Header.Kind, fact.Header.Identifier, body.Statement, body.Context,
            body.SourceReference, fact.Header.ProviderId) is not null || body.SourceReference != fact.Header.SourceReference)
            throw new ImmutableContentIntegrityException("The commitment authored body violates its exact current content contract.");
        return body;
    }
    internal static void ValidateScope(ICommitmentFact fact)
    {
        if (fact.Header is not { } header || fact.Operation is null || header.TenantId != fact.TenantId || header.DraftId == Uuid.Empty ||
            header.ProgramId == Uuid.Empty || header.Content is null || fact.Change is null || fact.Authority is null ||
            fact.Operation.Owner != new EventStreamAddress(header.TenantId.ToString(), CommitmentDraft.Area, header.DraftId.ToString()))
            throw new ImmutableContentIntegrityException("The native commitment fact has another exact owner scope.");
        var valid = fact switch
        {
            CommitmentDraftCreated data => data.ProgramId == header.ProgramId && data.DraftId == header.DraftId,
            CommitmentDraftRevised data => data.ProgramId == header.ProgramId && data.DraftId == header.DraftId,
            CommitmentReviewed data => data.ProgramId == header.ProgramId && data.DraftId == header.DraftId,
            CommitmentApproved data => data.ProgramId == header.ProgramId && data.DraftId == header.DraftId,
            CommitmentRetired data => data.ProgramId == header.ProgramId && data.SubjectId == header.DraftId,
            ResponsibilityAssigned data => data.Scope.RecordType == SeparationOfDutiesRecordTypes.Commitment && data.Scope.RecordId == header.DraftId,
            ResponsibilityRevoked data => data.Scope.RecordType == SeparationOfDutiesRecordTypes.Commitment && data.Scope.RecordId == header.DraftId,
            _ => false,
        };
        if (!valid)
            throw new ImmutableContentIntegrityException("The commitment receipt metadata has another exact owner scope.");
    }
    internal static bool InScope(ICommitmentMutationContent change, CommitmentAuthorityHeader header) => change switch
    {
'''+scopes+'''
        ResponsibilityAssigned data => data.TenantId == header.TenantId && data.Scope.RecordType == SeparationOfDutiesRecordTypes.Commitment && data.Scope.RecordId == header.DraftId,
        ResponsibilityRevoked data => data.TenantId == header.TenantId && data.Scope.RecordType == SeparationOfDutiesRecordTypes.Commitment && data.Scope.RecordId == header.DraftId,
        _ => false,
    };
}''')
new(K+'FrozenCommitmentMutation.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed record FrozenCommitmentMutation(CommitmentAuthorityHeader Header, ImmutableContentRef Change, ImmutableContentRef Authority);''')
new(K+'CommitmentContent.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public static class CommitmentContent
{
    public static async ValueTask<FrozenCommitmentMutation> FreezeAsync(IImmutableContentStore content, CommitmentRules after,
        CommitmentMutationContent mutation, CancellationToken ct = default)
    {
        if (after.CurrentContent is not { } current || CommitmentRules.Validate(after.Kind!, after.Identifier!, current.Statement,
            current.Context, current.SourceReference, after.ProviderId) is not null)
            throw new ImmutableContentIntegrityException("The prepared commitment has no valid current authored content.");
        var realm = after.TenantId.ToString();
        var body = await content.WriteJsonAsync(realm, Uuid.CreateVersion5(after.Id,
            CommitmentFactContent.ContentSchema + ":" + AuthoredIntentDigest.Compute(current)),
            CommitmentFactContent.ContentSchema, current, ct).ConfigureAwait(false);
        var header = after.Header(body);
        var state = after.Authority(header);
        var authority = await content.WriteJsonAsync(realm, Uuid.CreateVersion5(after.Id,
            CommitmentFactContent.AuthoritySchema + ":" + AuthoredIntentDigest.Compute(state)),
            CommitmentFactContent.AuthoritySchema, state, ct).ConfigureAwait(false);
        var change = await content.WriteJsonAsync(realm, Uuid.CreateVersion4(), CommitmentFactContent.ChangeSchema, mutation, ct).ConfigureAwait(false);
        return new FrozenCommitmentMutation(header, change, authority);
    }
}''')
if __name__=='__main__':p.emit()

for name in ['CommitmentReader','CommitmentReadSnapshot']:put(K+name+'.cs',(p.OUT/'templates'/f'{name}.cs').read_text())
new(K+'CommitmentResponsibilityReadSnapshot.cs','''using Bdgrz.Compliance.Features.Responsibilities;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed class CommitmentResponsibilityReadSnapshot(Uuid tenantId, ResponsibilityScope scope,
    IReadOnlyList<ResponsibilityAssignmentView> assignments)
{
    public Uuid TenantId { get; } = tenantId;
    public ResponsibilityScope Scope { get; } = scope;
    public IReadOnlyList<ResponsibilityAssignmentView> ReadAssignments() => assignments;
}''')
rules=(p.OUT/'after'/K/'CommitmentRules.cs').read_text().replace('    internal CommitmentDraftContent? CurrentContent',
    '    public CommitmentRetiredContent? Retirement => _appliedChanges.OfType<CommitmentRetiredContent>().LastOrDefault();\n    internal CommitmentDraftContent? CurrentContent')
put(K+'CommitmentRules.cs',rules)
# A preparation receipt is exclusively an acceptance-only no-op; it cannot mask another business change.
owner=(p.OUT/'after'/K/'CommitmentDraft.cs').read_text().replace('mutation.Changes is not null && mutation.Changes.Count == fact.ChangeCount &&',
    'mutation.Changes is not null && mutation.Changes.Count == fact.ChangeCount && (mutation.Changes.Count == 0) == (mutation.Receipt is not null) &&')
owner=owner.replace('Require(value is ResponsibilityAssigned or ResponsibilityRevoked && IsCurrentResponsibilityScope',
    'Require((value is ResponsibilityAssigned or ResponsibilityRevoked) && IsCurrentResponsibilityScope')
owner=owner.replace('Matches(CurrentAuthority!, before with { Assignments', 'Matches(CurrentAuthority!, before! with { Assignments')
put(K+'CommitmentDraft.cs',owner)
if __name__=='__main__':p.emit()

# Carry the exact validated Control native execution pattern; only own preparation and result schemas differ.
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
ops=(root/'src/Compliance.Core/Features/Controls/ControlOperations.cs').read_text()
for a,b in [('ControlOperations','CommitmentOperations'),('ControlReader','CommitmentReader'),('ControlDraft','CommitmentDraft'),('ControlReadSnapshot','CommitmentReadSnapshot'),('ControlWriteActor','CommitmentWriteActor'),('ControlRules','CommitmentRules'),('ControlMutationContent','CommitmentMutationContent'),('FrozenControlMutation','FrozenCommitmentMutation'),('ControlContent','CommitmentContent'),('ControlResponses','CommitmentResponses'),('ControlFactFactory','CommitmentFactFactory'),('Features.Controls','Features.Commitments'),('controlId','draftId')]:ops=ops.replace(a,b)
ops=ops.replace('owner.Prepare(scope, expectedRevision, kind == nameof(CreateCommitmentDraft))','owner.Prepare(scope, kind == nameof(CreateCommitmentDraft))')
start=ops.index('            var schema = kind switch');end=ops.index('            if (descriptor.ResultSchema',start)
ops=ops[:start]+'''            var schema = kind == nameof(CreateCommitmentDraft) ? CommitmentResponses.Registration : UnitResult.Schema;
'''+ops[end:]
ops=ops.replace('"The Control original response has another result schema."','"The commitment original response has another result schema."')
ops=re.sub(r'''            return Result<TOut>.Failure\(new RequestError\(RequestErrorKind.Conflict,\n                "The Control's immutable content cannot be verified.",\n                isTransient: exception is ImmutableContentUnavailableException\)\);''', '            return Result<TOut>.Failure(CommitmentReadFailure.Of(exception));',ops)
put(K+'CommitmentOperations.cs',ops)
actor=(root/'src/Compliance.Core/Features/Controls/ControlWriteActor.cs').read_text().replace('Features.Controls','Features.Commitments').replace('ControlWriteActor','CommitmentWriteActor')
put(K+'CommitmentWriteActor.cs',actor)
respops=(root/'src/Compliance.Core/Features/Controls/ControlOperations.Responsibilities.cs').read_text().replace('Features.Controls','Features.Commitments').replace('ControlOperations','CommitmentOperations').replace('pending control revision','pending commitment revision')
put(K+'CommitmentOperations.Responsibilities.cs',respops)
new(K+'CommitmentResponses.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public static class CommitmentResponses
{
    public const string Registration = "commitment-draft-registration.v1";
    public static async ValueTask<FirstResponseDescriptor> FreezeAsync(IImmutableContentStore content,
        CommitmentRules after, string kind, CancellationToken ct = default)
    {
        if (kind == nameof(CreateCommitmentDraft))
        {
            var body = await content.WriteJsonAsync(after.TenantId.ToString(), Uuid.CreateVersion4(), Registration,
                new CommitmentDraftRegistration(after.Id, after.Kind!, after.Identifier!, 1), ct).ConfigureAwait(false);
            return new FirstResponseDescriptor(200, ImmutableContentStoreExtensions.JsonMediaType, Registration, new StandardResponseBody(body));
        }
        var unit = await content.WriteJsonAsync(after.TenantId.ToString(), Uuid.CreateVersion4(), UnitResult.Schema, new UnitResult(), ct).ConfigureAwait(false);
        return new FirstResponseDescriptor(200, ImmutableContentStoreExtensions.JsonMediaType, UnitResult.Schema, new StandardResponseBody(unit));
    }
}''')
# Shared Control paths are left byte-for-byte intact; route the Commitment family before legacy Boundary preparation.
path='src/Compliance.Core/Features/Responsibilities/AssignResponsibilityHandler.cs';shared=source(path)
shared=shared.replace('IResponsibilityScopeValidator scopeValidator, ControlOperations controls, TimeProvider clock)',
    'IResponsibilityScopeValidator scopeValidator, ControlOperations controls, CommitmentOperations commitments, TimeProvider clock)')
anchor='''            return await controls.AssignResponsibilityAsync(context, memberships, scopeValidator, ct).ConfigureAwait(false);'''
assert anchor in shared;shared=shared.replace(anchor,anchor+'''
        if (request.RecordType == SeparationOfDutiesRecordTypes.Commitment)
            return await commitments.AssignResponsibilityAsync(context, memberships, scopeValidator, ct).ConfigureAwait(false);''')
start=shared.index('        if (request.RecordType == SeparationOfDutiesRecordTypes.Commitment)',shared.index('// Responsibilities live'))
end=shared.index('        return await executor.ExecuteAsync(new SystemBoundary',start)
shared=shared[:start]+shared[end:];put(path,shared)
path='src/Compliance.Core/Features/Responsibilities/RevokeResponsibilityHandler.cs';shared=source(path)
shared=shared.replace('IResponsibilityScopeValidator scopeValidator, ControlOperations controls, TimeProvider clock)',
    'IResponsibilityScopeValidator scopeValidator, ControlOperations controls, CommitmentOperations commitments, TimeProvider clock)')
anchor='''            return await controls.RevokeResponsibilityAsync(context, scopeValidator, ct).ConfigureAwait(false);'''
assert anchor in shared;shared=shared.replace(anchor,anchor+'''
        if (request.RecordType == SeparationOfDutiesRecordTypes.Commitment)
            return await commitments.RevokeResponsibilityAsync(context, scopeValidator, ct).ConfigureAwait(false);''')
start=shared.index('        if (request.RecordType == SeparationOfDutiesRecordTypes.Commitment)',shared.index('var actorMemberId'))
end=shared.index('        return await executor.ExecuteAsync(new SystemBoundary',start)
shared=shared[:start]+shared[end:];put(path,shared)
if __name__=='__main__':p.emit()

ops=(p.OUT/'after'/K/'CommitmentOperations.cs').read_text().replace('ControlAuthorityContent','CommitmentAuthorityContent').replace('SeparationOfDutiesRecordTypes.Control','SeparationOfDutiesRecordTypes.Commitment')
ops=ops.replace('The Control','The commitment').replace('A Control','A commitment')
ops=ops.replace('preparedSequence, preparedPhysical, mutation, beforeAuthority, afterAuthority)',
    'preparedSequence, preparedPhysical, mutation!, beforeAuthority, afterAuthority!)')
put(K+'CommitmentOperations.cs',ops)

new(K+'CreateCommitmentDraftHandler.cs','''using Bdgrz.Compliance.Features.Providers;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed class CreateCommitmentDraftHandler(CommitmentOperations operations, ProviderSource providers)
    : IRequestHandler<CreateCommitmentDraft, CommitmentDraftRegistration>
{
    public ValueTask<Result<CommitmentDraftRegistration>> HandleAsync(IRequestContext<CreateCommitmentDraft> context, CancellationToken ct)
    {
        var request = context.Request;
        var kind = CommitmentDraft.NormalizeKind(request.Kind);
        var identifier = CommitmentDraft.NormalizeIdentifier(request.Identifier);
        if (request.DraftId == Uuid.Empty || request.DraftId != CommitmentDraft.IdFor(request.TenantId, request.ProgramId, kind, identifier))
            return ValueTask.FromResult(Result<CommitmentDraftRegistration>.Failure(new RequestError(RequestErrorKind.Validation,
                "DraftId must match the commitment kind and identifier.")));
        if (request.ProviderId == Uuid.Empty || kind == "subservice_responsibility" && request.ProviderId is null ||
            kind != "subservice_responsibility" && request.ProviderId is not null)
            return ValueTask.FromResult(Result<CommitmentDraftRegistration>.Failure(new RequestError(RequestErrorKind.Validation,
                "A CSOC requires a subservice provider; other commitment kinds cannot reference a provider.")));
        return operations.ExecuteAsync<CreateCommitmentDraft, CommitmentDraftRegistration>(context, request.TenantId, request.ProgramId,
            request.DraftId, request.DraftId, nameof(CreateCommitmentDraft), null,
            async (_, _, _, token) =>
            {
                if (request.ProviderId is { } providerId)
                {
                    var provider = await providers.GetAsync(request.TenantId, providerId, token).ConfigureAwait(false);
                    if (provider is null || !provider.Content.Subservice)
                        return Result.Failure(new RequestError(RequestErrorKind.NotFound, "The subservice provider was not found in this tenant."));
                }
                var service = await operations.Sources.HydrateAsync(new ClientService(request.TenantId, request.ServiceId), token).ConfigureAwait(false);
                return service.IsActive && service.ProgramId == request.ProgramId ? Result.Success
                    : Result.Failure(new RequestError(RequestErrorKind.NotFound, "The program service was not found."));
            },
            (rules, actor, at) =>
            {
                var result = rules.Create(request.ProgramId, request.DraftId, request.ServiceId, kind, identifier, request.Statement,
                    request.Context, request.SourceReference, actor.MemberId, actor.Display, at, request.ProviderId);
                return result.IsSuccess ? Result.Success : Result.Failure(result.Error!);
            }, null, null, ct);
    }
}''')
new(K+'ReviseCommitmentDraftHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed class ReviseCommitmentDraftHandler(CommitmentOperations operations) : IRequestHandler<ReviseCommitmentDraft>
{
    public ValueTask<Result> HandleAsync(IRequestContext<ReviseCommitmentDraft> context, CancellationToken ct)
    {
        var request = context.Request;
        return operations.ExecuteUnitAsync(context, request.TenantId, request.ProgramId, request.DraftId, request.CommandId,
            nameof(ReviseCommitmentDraft), request.ExpectedRevision, (_, _, _, _) => CommitmentOperations.Ready(),
            (rules, actor, at) => CommitmentOperations.Outcome(rules.Revise(request.ProgramId, request.ExpectedRevision,
                request.Statement, request.Context, request.SourceReference, actor.MemberId, actor.Display, at)), null, null, ct);
    }
}''')
for name,action in [('ReviewCommitmentDraft','Review'),('ApproveCommitmentDraft','Approve')]:
 extra=', CommitmentImpactService impact' if name=='ApproveCommitmentDraft' else ''
 code='''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

'''+f'''public sealed class {name}Handler(CommitmentOperations operations{extra}) : IRequestHandler<{name}>
{{
    public ValueTask<Result> HandleAsync(IRequestContext<{name}> context, CancellationToken ct)
    {{
        if (context.Invocation is not HttpInvocation || RequestActor.IsSystem(context.Actor) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out _))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Forbidden,
                "Commitment sign-off requires personal HTTP submission.")));
        var request = context.Request;
        var proofs = new List<SeparationOfDutiesWaiverProof>();
        return operations.ExecuteUnitAsync(context, request.TenantId, request.ProgramId, request.DraftId, request.CommandId,
            nameof({name}), request.ExpectedRevision,
            async (snapshot, actor, at, token) =>
            {{
'''
 if name=='ApproveCommitmentDraft':code+='''                var preview = await impact.PreviewAsync(new PreviewCommitmentImpact(request.TenantId, request.ProgramId,
                    request.DraftId, request.ExpectedRevision), token).ConfigureAwait(false);
                if (!preview.IsSuccess)
                    return Result.Failure(preview.Error!);
                if (!preview.Value.Complete)
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The impact preview is incomplete. Approval cannot acknowledge it."));
                if (!StringComparer.Ordinal.Equals(request.ImpactDigest, preview.Value.Digest))
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict, "The impact preview changed. Reload it before approval."));
'''
 code+=f'''                var proof = await operations.ResolveWaiverAsync(request.TenantId, request.SeparationOfDutiesWaiverId,
                    actor.MemberId, request.DraftId, request.DraftId, snapshot.Revision, SeparationOfDutiesActions.{action}, at, token).ConfigureAwait(false);
                if (!proof.IsSuccess)
                    return Result.Failure(proof.Error!);
                proofs.Clear();
                if (proof.Value is {{ }} allowed)
                    proofs.Add(allowed);
                return Result.Success;
            }},
'''
 if name=='ReviewCommitmentDraft':call='''rules.Review(request.ProgramId, request.ExpectedRevision, request.CommandId, request.Outcome,
                request.OwnerReference, request.Applicability, request.Interpretation, request.InterpretationNote, request.Rationale,
                actor.MemberId, actor.Display, at, proofs.SingleOrDefault(), request.SourceVerifiedReference, request.SourceEvidence)'''
 else:call='''rules.Approve(request.ProgramId, request.ExpectedRevision, request.CommandId, request.AcceptedReviewDecisionId,
                request.EffectiveFrom, request.Rationale, request.ImpactDigest, actor.MemberId, actor.Display, at, proofs.SingleOrDefault())'''
 code+=f'''            (rules, actor, at) => CommitmentOperations.Outcome({call}), null, () => proofs, ct);
    }}
}}
'''
 put(K+name+'Handler.cs',code)
new(K+'RetireCommitmentHandler.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Commitments;

public sealed class RetireCommitmentHandler(CommitmentOperations operations) : IRequestHandler<RetireCommitment>
{
    public ValueTask<Result> HandleAsync(IRequestContext<RetireCommitment> context, CancellationToken ct)
    {
        if (context.Invocation is not HttpInvocation || RequestActor.IsSystem(context.Actor) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out _))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Forbidden,
                "Commitment retirement requires personal HTTP submission.")));
        var request = context.Request;
        return operations.ExecuteUnitAsync(context, request.TenantId, request.ProgramId, request.CommitmentId, request.CommandId,
            nameof(RetireCommitment), request.ExpectedRevision, (_, _, _, _) => CommitmentOperations.Ready(),
            (rules, actor, at) => CommitmentOperations.Outcome(rules.Retire(request.ProgramId, request.ExpectedRevision,
                request.EffectiveOn, request.Rationale, actor.MemberId, actor.Display, at)), null, null, ct);
    }
}''')
if __name__=='__main__':p.emit()

ops=(p.OUT/'after'/K/'CommitmentOperations.cs').read_text().replace('CommitmentReader controls','CommitmentReader commitments').replace('await controls.ReadAsync','await commitments.ReadAsync')
put(K+'CommitmentOperations.cs',ops)
owner=(p.OUT/'after'/K/'CommitmentDraft.cs').read_text()
needle='''        if (fact.ChangeCount == 0)
        {
            Require((value is ResponsibilityAssigned or ResponsibilityRevoked)'''
replacement='''        if (fact.ChangeCount == 0)
        {
            Require(value is ResponsibilityAssigned assignment
                ? operation.CommandKind == nameof(AssignResponsibility) && operation.LogicalId == assignment.AssignmentId
                : value is ResponsibilityRevoked && operation.CommandKind == nameof(RevokeResponsibility),
                "A no-op acceptance must retain its exact responsibility operation identity.");
            Require((value is ResponsibilityAssigned or ResponsibilityRevoked)'''
assert needle in owner;owner=owner.replace(needle,replacement)
put(K+'CommitmentDraft.cs',owner)
facts=(p.OUT/'after'/K/'CommitmentFactContent.cs').read_text().replace('data.Scope.RecordType ==', 'data.Scope is { } scope && scope.RecordType ==').replace('data.Scope.RecordId ==','scope.RecordId ==')
# Parsed payload bodies must bind the immutable native content reference before any projector consumes their relationships.
needle='''        return mutation;
    }
    public static ValueTask<CommitmentDraftContent> ReadDraftAsync'''
replacement='''        var authored = mutation.Changes.Select(change => change switch
        {
            CommitmentDraftCreatedContent created => new CommitmentDraftContent(created.Statement, created.Context, created.SourceReference),
            CommitmentDraftRevisedContent revised => new CommitmentDraftContent(revised.Statement, revised.Context, revised.SourceReference),
            _ => null,
        }).OfType<CommitmentDraftContent>().SingleOrDefault();
        if (authored is not null && (ContentDigest.OfJson(authored) != fact.Header.Content.Sha256 || authored.SourceReference != fact.Header.SourceReference))
            throw new ImmutableContentIntegrityException("The commitment authored mutation differs from its native content reference.");
        return mutation;
    }
    public static ValueTask<CommitmentDraftContent> ReadDraftAsync'''
assert needle in facts;facts=facts.replace(needle,replacement)
put(K+'CommitmentFactContent.cs',facts)
if __name__=='__main__':p.emit()

put('test/Compliance.Tests/Testing/CommitmentSeeds.cs',(p.OUT/'templates/CommitmentSeeds.cs').read_text(),'migrated-tests')
# Replay compares canonical member identity while the persisted provenance retains the original business display snapshot.
ops=(p.OUT/'after'/K/'CommitmentOperations.cs').read_text().replace('ActorReference.ForMember(member, member.ToString())','ActorReference.ForMember(member, actor.Display)')
put(K+'CommitmentOperations.cs',ops)
owner=(p.OUT/'after'/K/'CommitmentDraft.cs').read_text()
needle='''        Require(member == businessActor && at == operation.AcceptedAt, "The commitment receipt lost its original actor or native acceptance instant.");'''
replacement='''        var display = value switch
        {
            CommitmentDraftCreated item => item.ActorDisplay,
            CommitmentDraftRevised item => item.ActorDisplay,
            CommitmentReviewed item => item.ActorDisplay,
            CommitmentApproved item => item.ActorDisplay,
            CommitmentRetired item => item.ActorDisplay,
            ResponsibilityAssigned item => item.AssignedByDisplay,
            ResponsibilityRevoked item => item.RevokedByDisplay,
            _ => string.Empty,
        };
        Require(member == businessActor && at == operation.AcceptedAt && operation.Actor.Display == display,
            "The commitment receipt lost its original member, display snapshot or native acceptance instant.");'''
assert needle in owner;owner=owner.replace(needle,replacement)
put(K+'CommitmentDraft.cs',owner)
facts=(p.OUT/'after'/K/'CommitmentFactContent.cs').read_text().replace('if (mutation.Changes is null || mutation.Changes.Count != fact.ChangeCount',
    'if (fact.ChangeCount is < 0 or > 1 || mutation.Changes is null || mutation.Changes.Count != fact.ChangeCount')
put(K+'CommitmentFactContent.cs',facts)
if __name__=='__main__':p.emit()

# Preserve original pure rule acceptance names; native persistence is covered separately by actual producer/source tests.
for file in ['CommitmentApprovalTests','CommitmentDraftTests','CommitmentReviewTests','CommitmentRetirementTests','CommitmentDraftActorSnapshotTests']:
 path=f'test/Compliance.Tests/Features/Commitments/{file}.cs';text=source(path)
 text=re.sub(r'\bCommitmentDraft\b','CommitmentRules',text)
 for event in EVENTS:text=re.sub(r'\b'+event+r'\b',event+'Content',text)
 text=re.sub(r'new AggregateScenario<CommitmentRules>\((\w+)\)\.PendingEvents',r'\1.PendingChanges',text)
 text=text.replace('SeparationOfDutiesWaiver? waiver', 'SeparationOfDutiesWaiverProof? waiver').replace('static SeparationOfDutiesWaiver CreateWaiver','static SeparationOfDutiesWaiverProof CreateWaiver')
 text=text.replace('        return waiver;', '        return ControlTestWaivers.Proof(waiver);').replace('valid.Id,','valid.WaiverId,').replace('waiver.Id,','waiver.WaiverId,')
 if 'ControlTestWaivers.' in text or file=='CommitmentDraftActorSnapshotTests':text='using Bdgrz.Compliance.Tests.Testing;\n'+text
 if file=='CommitmentRetirementTests':
  text=text.replace('var replay = new AggregateScenario<CommitmentRules>(NewDraft()).Given(events).Aggregate;', 'var replay = NewDraft();\n        foreach (var change in events)\n            replay.Apply(change);')
 if file=='CommitmentDraftActorSnapshotTests':
  old='''        var replayed = new AggregateScenario<CommitmentRules>(
                new CommitmentRules(TenantId, draftId))
            .Given(DomainEventSeed.Attach(created, draftId, 1),
                DomainEventSeed.Attach(revised, draftId, 2)).Aggregate;'''
  assert old in text;text=text.replace(old,'''        var replayed = new CommitmentRules(TenantId, draftId);
        replayed.Apply(created);
        replayed.Apply(revised);''')
 put(path,text,'migrated-tests')

# Existing owning transport fixtures use real native publication; projection remains a discovery accelerator.
path='test/Compliance.Tests/Features/Commitments/CommitmentDraftReplayTests.cs';text=(p.OUT/'after'/path).read_text().replace('new CommitmentDraft(', 'new CommitmentRules(')
put(path,text)
path='test/Compliance.Tests/Features/Commitments/PersonalCommitmentDecisionTransportTests.cs';text=(p.OUT/'after'/path).read_text()
text='using Bdgrz.Compliance.Features.Content;\n'+text
text=text.replace('new CommitmentDraft(', 'new CommitmentRules(').replace('public Task<CommitmentDraft> ReadAsync()', 'public Task<CommitmentRules> ReadAsync()').replace('.CommittedStreamPosition','.SourcePhysicalPosition')
text=text.replace('public Uuid DraftId { get; } = Uuid.CreateVersion4();','public Uuid DraftId => CommitmentDraft.IdFor(Tenant, Program, "service_commitment", "SC-TRANSPORT");')
text=text.replace('new RetireCommitment(', 'new RetireCommitment(Uuid.CreateVersion4(), ')
text=text.replace('''        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<IRequestBus>().DispatchAsync(request,''','''        request = request with { CommandId = commandId };
        await using var scope = provider.CreateAsyncScope();
        return await scope.ServiceProvider.GetRequiredService<IRequestBus>().DispatchAsync(request,''',1)
text=text.replace('        readonly FitzCommitmentDraftDirectory _directory;', '        readonly FitzCommitmentDraftDirectory _directory;\n        readonly AsyncServiceScope _directoryScope;')
text=text.replace('            _directory = new FitzCommitmentDraftDirectory(client);\n','').replace('            services.AddSingleton<ICommitmentDraftDirectoryReader>(_directory);\n','')
text=text.replace('''            _provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true });''','''            _provider = services.BuildServiceProvider(new ServiceProviderOptions { ValidateScopes = true });
            _directoryScope = _provider.CreateAsyncScope();
            _directory = _directoryScope.ServiceProvider.GetRequiredService<FitzCommitmentDraftDirectory>();''')
text=text.replace('new CheckpointIdentity("CommitmentDraftDirectory", pattern)', 'new CheckpointIdentity(FitzCommitmentDraftDirectory.ProjectorName, pattern)')
text=text.replace('Assert.Equal("MSA 4.1", decision.SourceVerifiedReference);', 'Assert.Equal("MSA 4.1", Assert.IsType<CommitmentReviewedContent>(Assert.Single((await fixture.ReadChangeAsync(decision)).Changes)).SourceVerifiedReference);')
text=text.replace('''            retired.Rationale);''','''            Assert.IsType<CommitmentRetiredContent>(Assert.Single((await fixture.ReadChangeAsync(retired)).Changes)).Rationale);''')
needle='''        public async Task<IReadOnlyList<DomainEvent>> ReadEventsAsync()'''
insert='''        public async Task<CommitmentMutationContent> ReadChangeAsync(ICommitmentFact fact)
        {
            await using var scope = _provider.CreateAsyncScope();
            return await CommitmentFactContent.ReadChangeAsync(scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), fact);
        }
'''
assert needle in text;text=text.replace(needle,insert+needle)
text=text.replace('''        public ValueTask DisposeAsync() => _provider.DisposeAsync();''','''        public async ValueTask DisposeAsync()
        {
            await _directoryScope.DisposeAsync();
            await _provider.DisposeAsync();
        }''')
put(path,text)

fixture=Path('/tmp/compliance-s32-policy-prepared/after/test/Compliance.Tests/Testing/PolicySourceFixture.cs').read_text()
for a,b in [('PolicySourceFixture','CommitmentSourceFixture'),('PolicyOperations','CommitmentOperations'),('PolicyReader','CommitmentReader'),('PolicyRules','CommitmentRules'),('PolicySeeds','CommitmentSeeds'),('new Policy(','new CommitmentDraft('),('Policy.Area','CommitmentDraft.Area'),('Features.Policies','Features.Commitments'),('Policies =>','Commitments =>')]:fixture=fixture.replace(a,b)
fixture=fixture.replace('bool http = false) where T', 'bool http = false, string display = "author@example.test") where T')
fixture=fixture.replace('new Claim("name", "Control author")','new Claim("email", display)')
put('test/Compliance.Tests/Testing/CommitmentSourceFixture.cs',fixture,'migrated-tests')
if __name__=='__main__':p.emit()

path='test/Compliance.Tests/Features/Commitments/PersonalCommitmentDecisionTransportTests.cs';text=(p.OUT/'after'/path).read_text()
text=text.replace('retired.Rationale);','Assert.IsType<CommitmentRetiredContent>(Assert.Single((await fixture.ReadChangeAsync(retired)).Changes)).Rationale);')
put(path,text)
ops=(p.OUT/'after'/K/'CommitmentOperations.cs').read_text()
needle='''        var actor = new CommitmentWriteActor(member, UserIdentityClaims.BdgrzDisplay(context.Actor, userId));'''
replacement='''        var display = UserIdentityClaims.BdgrzDisplay(context.Actor, userId);
        if (kind is nameof(AssignResponsibility) or nameof(RevokeResponsibility) or nameof(RetireCommitment))
            display = display.Trim();
        var actor = new CommitmentWriteActor(member, display);'''
assert needle in ops;ops=ops.replace(needle,replacement)
put(K+'CommitmentOperations.cs',ops)
if __name__=='__main__':p.emit()

put('test/Compliance.Tests/Features/Commitments/CommitmentNativeContentTests.cs',(p.OUT/'templates/CommitmentNativeContentTests.cs').read_text(),'migrated-tests')
if __name__=='__main__':p.emit()

path='test/Compliance.Tests/Features/Commitments/CommitmentNativeContentTests.cs';text=(p.OUT/'after'/path).read_text().replace('scenario.CreateAsync(', 'scenario.CreateDraftAsync(').replace('CreateAsync(string display', 'CreateDraftAsync(string display')
put(path,text)
# Shared JSON wiring stays outside the owning implementation patch and preserves other queued verticals.
jsonpath='src/Compliance.Core/ComplianceCoreJsonContext.cs';before=source(jsonpath)
types=['CommitmentDraftContent','CommitmentAuthorityHeader','CommitmentAuthorityContent','CommitmentDecisionConstraint','CommitmentMutationContent','ICommitmentMutationContent']+[n+'Content' for n in EVENTS]
anchor='[JsonSerializable(typeof(CommitmentDraftCreated))]';assert anchor in before
text=before.replace(anchor,''.join(f'[JsonSerializable(typeof({name}))]\n' for name in types)+anchor)
(p.OUT/'shared-json-contracts.patch').write_text(p.diff(jsonpath,before,text))
(p.OUT/'shared-wiring-required.json').write_text(json.dumps({'sourceDI':'AddScoped<CommitmentReader>(); AddScoped<CommitmentOperations>(); Peer owns DI/discovery/source constructor deltas and shared fixture registrations.',
'sharedHandlers':'AssignResponsibilityHandler adds CommitmentOperations before TimeProvider (now7deps). RevokeResponsibilityHandler same newdependency (now5deps). Existing Control paths preserved; Boundary executor logic unchanged.',
'unitWire':'Own4+Shared2 remain plain IRequest/Result per parent. Native successful receipts200 +UnitResult; actual HTTP200{} qualification belongs parent global descriptor-aware transport adapter.',
'json':types,'routes':'RetireCommitment gains required firstCommandId; selected remaining catalog has no explicitHTTP path. Preserve existing route presence and supply CommandId inbody where exposed.'},indent=2)+'\n')
if __name__=='__main__':p.emit()

new(K+'CommitmentCreateIntent.cs','''using Bdgrz.Compliance.Features.Kernel;

namespace Bdgrz.Compliance.Features.Commitments;

/// <summary>Creation compares the normalized identity and authored terms that the existing commitment business contract preserves.</summary>
static class CommitmentCreateIntent
{
    public static string Digest(CreateCommitmentDraft request) => AuthoredIntentDigest.Compute(request with
    {
        Kind = CommitmentDraft.NormalizeKind(request.Kind),
        Identifier = CommitmentDraft.NormalizeIdentifier(request.Identifier),
        Statement = request.Statement?.Trim()!,
        Context = request.Context?.Trim()!,
        SourceReference = request.SourceReference?.Trim()!,
    });
}''')
path=K+'CreateCommitmentDraftHandler.cs';text=(p.OUT/'after'/path).read_text().replace('            }, null, null, ct);','            }, null, null, ct, authoredDigest: CommitmentCreateIntent.Digest(request));');put(path,text)
# The actor/reference test exercises canonical normalization across the retry, not a new authored operation.
path='test/Compliance.Tests/Features/Commitments/CommitmentNativeContentTests.cs';text=(p.OUT/'after'/path).read_text()
text=text.replace('''        var first = await scenario.CreateDraftAsync("original@example.test");''','''        var authored = scenario.Request with { Kind = " SERVICE_COMMITMENT ", Identifier = " native ",
            Statement = " Statement 1 ", Context = " Context ", SourceReference = " MSA " };
        var first = await new CreateCommitmentDraftHandler(scenario.Source.Operations(), new ProviderSource(scenario.Source.Reader, scenario.Source.Content))
            .HandleAsync(CommitmentSourceFixture.Context(authored, scenario.Author, display: "original@example.test"), CancellationToken.None);''')
put(path,text)
if __name__=='__main__':p.emit()

# This actual-host class uses only existing transport/public types, so the route ambiguity can be demonstrated before body/API changes.
path='test/Compliance.Tests/Features/Commitments/CommitmentHttpRoutesTests.cs';text=(p.OUT/'templates/CommitmentHttpRoutesTests.cs').read_text()
put(path,text,'http-tests')
# Parent selected the unambiguous owning completion paths; no client implementation is included.
path='src/Compliance.App/Program.cs';before=source(path);text=before
old='''    app.MapPortiaPut<ReviseCommitmentDraft>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/commitment-drafts/{draft_id}")'''
newroute='''    app.MapPortiaPut<ReviseCommitmentDraft>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/commitment-drafts/{draft_id}/draft-revisions/{command_id}")'''
assert old in text;text=text.replace(old,newroute)
anchor='''    app.MapPortiaGet<ListCommitmentDecisions, Page<CommitmentDecisionView>>('''
insert='''    app.MapPortiaPut<RetireCommitment>(
            "/api/v1/tenants/{tenant_id}/programs/{program_id}/commitments/{commitment_id}/retirements/{command_id}")
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("Commitments");
'''
assert anchor in text;text=text.replace(anchor,insert+anchor)
(p.OUT/'shared-program-routes.patch').write_text(p.diff(path,before,text))
if __name__=='__main__':p.emit()

path='test/Compliance.Tests/Features/Commitments/CommitmentNativeContentTests.cs';text=(p.OUT/'after'/path).read_text()
text=text.replace('using Bdgrz.Compliance.Features.Content;', 'using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;')
marker='    sealed class Scenario : IAsyncDisposable'
extra='''    [Theory]
    [InlineData("actor")]
    [InlineData("gate")]
    [InlineData("authority")]
    [InlineData("verified_wrong_authority")]
    public async Task ShouldRejectMalformedNativeAcceptanceGivenExactCommitmentSourceCut(string defect)
    {
        // Arrange
        await using var scenario = await Scenario.CreateAsync();
        Assert.True((await scenario.CreateDraftAsync()).IsSuccess);
        var owner = await scenario.OwnerAsync();
        var rules = await scenario.Source.Commitments.RulesAsync(scenario.Tenant, scenario.Program, scenario.Id);
        var before = rules.Authority(owner.Header!);
        var member = RbacIds.Member(scenario.Tenant, Uuid.CreateVersion4());
        var command = Uuid.CreateVersion4();
        Assert.Null(rules.Review(scenario.Program, 1, command, "accept", "Owner", "applicable", "supported", null,
            "Reviewed", member, "Reviewer", scenario.Source.Clock.Now, sourceVerifiedReference: "MSA", sourceEvidence: "Signed MSA checked"));
        var mutation = new CommitmentMutationContent(rules.PendingChanges.ToArray());
        var operation = OwnerProvenance.For(owner, command, nameof(ReviewCommitmentDraft), ActorReference.ForMember(member, "Reviewer"),
            scenario.Id.ToString(), 1, AuthoredIntentDigest.Compute(new ReviewCommitmentDraft(command, scenario.Tenant, scenario.Program,
                scenario.Id, 1, "accept", "Reviewed", "Owner", "applicable", "supported", SourceVerifiedReference: "MSA", SourceEvidence: "Signed MSA checked")),
            scenario.Source.Clock.Now);
        if (defect == "gate")
            operation = operation with { OriginalExpectedRevision = 9 };
        var fact = Assert.IsType<CommitmentReviewed>(await CommitmentSeeds.FreezeAsync(scenario.Source.Content, rules, mutation, operation, 2));
        var after = rules.Authority(fact.Header);
        if (defect == "actor")
            fact = fact with { ActorMemberId = RbacIds.Member(scenario.Tenant, scenario.Author) };
        if (defect == "authority")
            fact = fact with { Authority = owner.CurrentAuthority! };
        if (defect == "verified_wrong_authority")
        {
            after = after with { PendingAuthorMemberIds = [] };
            fact = fact with { Authority = await scenario.Source.Content.WriteJsonAsync(scenario.Tenant.ToString(), Uuid.CreateVersion4(),
                CommitmentFactContent.AuthoritySchema, after) };
        }

        // Act
        var result = owner.Append(fact, owner.NativeSequence, owner.CommittedStreamPosition, mutation, before, after);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(RequestErrorKind.Validation, result.Error!.Kind);
        Assert.Equal(1, owner.NativeSequence);
        Assert.Single(await scenario.Source.FactsAsync(scenario.Tenant, scenario.Id));
    }

'''
assert marker in text;text=text.replace(marker,extra+marker)
put(path,text)
if __name__=='__main__':p.emit()
