from pathlib import Path
import hashlib,difflib,json,subprocess,shutil,os
p=Path('/tmp/compliance-risk-work-identity-prepared');base=p/'base';work=p/'work';sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file());source=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')]
def export(name,selected):
 text=[]
 for r in selected:
  a=base/r;b=work/r;text+=difflib.unified_diff(a.read_text().splitlines(True) if a.exists() else [],b.read_text().splitlines(True),fromfile='a/'+r if a.exists() else '/dev/null',tofile='b/'+r)
 f=p/name;f.write_text(''.join(text));return {'path':str(f),'sha256':sha(f),'paths':selected}
arts={k:export(k,v) for k,v in [('implementation.patch',source),('tests.patch',tests),('behavioral-red.patch',tests),('green-after-red.patch',source),('full.patch',paths)]}
checks=[]
for name,sequence in [('full',['full.patch']),('staged',['behavioral-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/name;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest)
 for patch in sequence:
  run=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,text=True,capture_output=True);assert run.returncode==0,run.stdout+run.stderr
 assert all(sha(dest/r)==sha(work/r) for r in paths);checks.append({'sequence':sequence,'exact':True})
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
p=Parser(Language(tree_sitter_c_sharp.language()));fs=list(Path("/tmp/compliance-risk-work-identity-prepared/work").rglob("*.cs"));print(json.dumps({"files":len(fs),"errors":[str(f) for f in fs if p.parse(f.read_bytes()).root_node.has_error]}))
'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')));assert not syntax['errors']
report={'paths':[{'path':r,'before':sha(base/r),'after':sha(work/r)} for r in paths],'artifacts':arts,'reconstruction':checks,'syntax':syntax,'prerequisites':['Assertion14 + Action25 nonshared + four-file shared union','Gov12/native-v2 + Method/Risk109 preceding slices'],'runtime':'Not run; root owns slot.','newTests':3,'cutover':'Only new full scoped review work IDs grant authority. No guessed old ID aliases or migration; old ambiguous projected candidates/assignments must be deliberately rebuilt/reassigned.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n');(p/'behavioral-red-filter.txt').write_text('FullyQualifiedName~RiskActionWorkIdentityTests\n');(p/'focused-filter.txt').write_text('FullyQualifiedName~RiskActionWorkIdentityTests|FullyQualifiedName~RiskOwnerWorkSourceTests|FullyQualifiedName~RiskGovernanceHandlerTests|FullyQualifiedName~WorkQueue|FullyQualifiedName~RiskTreatmentAction|FullyQualifiedName~WorkSourceComposition\n');print(json.dumps({'paths':len(paths),'syntax':syntax,'artifacts':arts},indent=2))
