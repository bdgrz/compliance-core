from pathlib import Path
import shutil
p=Path('/tmp/compliance-risk-work-identity-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');union=Path('/tmp/compliance-risk-assertion-action-compose/work');action=Path('/tmp/compliance-risk-action-prepared/work')
paths=['src/Compliance.Core/Features/Work/WorkSource.cs','src/Compliance.Core/Features/Risks/ReviewRiskTreatmentActionCompletionHandler.cs','src/Compliance.Core/Features/Risks/RiskGovernanceRecord.cs','src/Compliance.Core/Features/Risks/RiskGovernanceSnapshot.cs','src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs']
for rel in paths:
 origin=next(root/rel for root in [union,action,repo] if (root/rel).exists())
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,f)
f=p/'work/src/Compliance.Core/Features/Work/WorkSource.cs';s=f.read_text();marker='        var candidates = new List<WorkCandidate>();';s=s.replace(marker,'''        bool WantedRiskReview(Uuid riskId, Uuid actionId, Uuid submissionId) =>
            workItemId is not { } wanted || RiskTreatmentActionReviewWorkItemId(programId, riskId, actionId, submissionId) == wanted;
'''+marker,1)
s=s.replace('''!WantedRiskAction(action.RiskId, completion.SubmissionId,
                            RiskTreatmentActionReview)''','''!WantedRiskReview(action.RiskId, action.ActionId, completion.SubmissionId)''')
s=s.replace('''governance.SubmitterMemberId(action.RiskId,
                            completion.SubmissionId)''','''governance.SubmitterMemberId(action.RiskId, action.ActionId,
                            completion.SubmissionId)''')
s=s.replace('''RiskTreatmentWorkItemId(programId, action.RiskId,
                            completion.SubmissionId, RiskTreatmentActionReview)''','''RiskTreatmentActionReviewWorkItemId(programId, action.RiskId, action.ActionId,
                            completion.SubmissionId)''')
marker='    public static WorkCandidate ControlOccurrenceCandidate'
s=s.replace(marker,'''    /// <summary>Review work belongs to one action's submission; no command UUID uniqueness across actions is assumed.</summary>
    public static Uuid RiskTreatmentActionReviewWorkItemId(Uuid programId, Uuid riskId, Uuid actionId, Uuid submissionId) =>
        WorkCandidate.IdFor(Uuid.CreateVersion5(programId,
            $"risk-treatment-action-review-work-v2\\n{riskId}\\n{actionId}\\n{submissionId}"), RiskTreatmentActionReview);

'''+marker);f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Risks/ReviewRiskTreatmentActionCompletionHandler.cs';s=f.read_text().replace('''WorkSource.RiskTreatmentWorkItemId(request.ProgramId, request.RiskId, submissionId,
            WorkSource.RiskTreatmentActionReview)''','''WorkSource.RiskTreatmentActionReviewWorkItemId(request.ProgramId, request.RiskId, request.ActionId, submissionId)''');f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Risks/RiskGovernanceRecord.cs';s=f.read_text().replace('IReadOnlyDictionary<Uuid, Uuid> submitters','IReadOnlyDictionary<(Uuid ActionId, Uuid SubmissionId), Uuid> submitters').replace('new Dictionary<Uuid, Uuid>()','new Dictionary<(Uuid ActionId, Uuid SubmissionId), Uuid>()').replace('public IReadOnlyDictionary<Uuid, Uuid> Submitters','public IReadOnlyDictionary<(Uuid ActionId, Uuid SubmissionId), Uuid> Submitters');f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Risks/RiskGovernanceSnapshot.cs';s=f.read_text().replace('SubmitterMemberId(Uuid riskId, Uuid submissionId)', 'SubmitterMemberId(Uuid riskId, Uuid actionId, Uuid submissionId)').replace('Record(riskId).Submitters.TryGetValue(submissionId, out var memberId)','Record(riskId).Submitters.TryGetValue((actionId, submissionId), out var memberId)');f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs';s=f.read_text().replace('var submitters = new Dictionary<Uuid, Uuid>();','var submitters = new Dictionary<(Uuid ActionId, Uuid SubmissionId), Uuid>();').replace('submitters[submission] = submitter;','submitters[(action.ActionId, submission)] = submitter;');f.write_text(s)
