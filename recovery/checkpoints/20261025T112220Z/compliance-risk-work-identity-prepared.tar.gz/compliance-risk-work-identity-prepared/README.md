# Action-scoped completion-review work identity

Frozen six-path follow-on after Assertion14, Action25 and their four-file shared union. No main, builds/tests/git/Jev/issues were performed; root owns runtime qualification.

The previous key used ProgramId/RiskId/SubmissionId for review work. SubmissionId is native to one ActionId, so two independent actions could share it, alias a review assignment and overwrite the combined submitter/SoD map. This correction includes ActionId in a distinct v2 review-work namespace in every actual derivation/filter/assignment-authority caller. Ordinary action work keeps its existing published algorithm. SourceId remains the submission and existing ActionPath identifies its action; no public fields/routes/lookups are added.

The read-side submitter map is now keyed by (ActionId,SubmissionId), nested under the existing risk scope. Per-action native history still supplies exact submitter attribution. Queue exclusion checks, wanted-work filters and the review admission guard all use the same complete scope. No cross-action command UUID uniqueness is assumed.

Apply behavioral-red.patch and run behavioral-red-filter.txt after the predecessor slices, then implementation.patch/green-after-red.patch. Tests use existing old APIs and real producer/queue/assignment/personal review paths: assignment for action A cannot admit review of action B sharing SubmissionId; queue IDs and distinct submitter duties stay separate; an old unscoped assignment cannot grant the new scoped review. Full and staged exact reconstruction and six modern parses pass; runtime evidence is unclaimed.

Cutover is explicit: old ambiguous review work IDs/projections/assignments are not guessed aliases for any action. Their old authority cannot transfer to the new scope. Rebuild owning projected candidates and deliberately assign the new IDs through the existing workflow. Persisted old assignment/history qualification remains a limitation; no fabricated migration or compatibility reader is shipped. The generic legacy assignment store fallback, where it already exists, can read only the exact new ID and never maps an old review key to it.

Parent must capture the genuine old-code RED, then strict/focused/full suites and direct per-file Jev before qualifying or merging. Root separately tracks realm-wide operation binding gaps; this patch does not claim to solve them.
