from pathlib import Path
import json
P=Path('/tmp/compliance-system-description-prepared');shared=['src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.App/Program.cs']
for rel in shared:
 for directory in ['shared-base','shared-work']:
  path=P/directory/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(Path(rel).read_bytes())
p=P/'shared-work'/shared[0];s=p.read_text();needle='        services.AddScoped<ISystemDescriptionDecisionCorrelationReader,';assert needle in s;s=s.replace(needle,'''        services.AddScoped<SystemDescriptionReader>();
        services.AddScoped<SystemDescriptionOperations>();
        services.AddScoped<SystemDescriptionSnapshotSources>();
        services.AddScoped<SystemDescriptionSourceResolver>();
        services.AddScoped<SystemDescriptionReadConsistency>();
        services.AddSingleton<SystemDescriptionDocumentRenderer>();
        services.AddSingleton<ISystemDescriptionExportProcesses,FitzKvSystemDescriptionExportProcesses>();
        services.AddScoped<SystemDescriptionExportProcess>();
'''+needle,1)
s=s.replace('            .AddRequestHandler<GenerateSystemDescriptionExportHandler>()','''            .AddRequestHandler<GenerateSystemDescriptionExportHandler>()
            .AddRequestHandler<GetSystemDescriptionHandler>()
            .AddRequestHandler<ListSystemDescriptionVersionsHandler>()
            .AddRequestHandler<PreviewSystemDescriptionImpactHandler>()''')
p.write_text(s)
jsonroots=['SystemDescriptionAuthorityHeader','SystemDescriptionSnapshotSourceProof','SystemDescriptionSnapshotSourceFact','SystemDescriptionExportIntent','SystemDescriptionExportProcessRecord','SystemDescriptionExportOutput']
jsonroots=['Bdgrz.Compliance.Features.SystemDescription.'+v for v in jsonroots]
for name in ['SystemDescriptionVersionView','SystemDescriptionReviewView','SystemDescriptionApprovalView','SystemDescriptionNoChangeDecisionView','SystemDescriptionBindingView','SystemDescriptionSnapshotSourceFact']:
 jsonroots.append('IReadOnlyList<Bdgrz.Compliance.Features.SystemDescription.'+name+'>')
p=P/'shared-work'/shared[1];s=p.read_text().replace('[JsonSerializable(typeof(Bdgrz.Compliance.Features.SystemDescription.SystemDescriptionExportGenerated))]\n','');i=s.index('[JsonSerializable');s=s[:i]+''.join('[JsonSerializable(typeof('+name+'))]\n' for name in jsonroots)+s[i:];p.write_text(s)
p=P/'shared-work'/shared[2];s=p.read_text();s='using Bdgrz.Compliance.Features.SystemDescription;\n'+s
commands=json.loads((P/'target-command-contracts.json').read_text());maps=[]
for row in commands:
 for route in row['http']:
  name=row['command'];maps.append(f'''    app.MapPortia{route['method'].title()}<{name}>(
            "{route['path']}",config => config.OnNativeResult()).WithNativeFirstResponse<{name}>()
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("System descriptions");''')
root='/api/v1/tenants/{tenant_id}/programs/{program_id}/system-descriptions/{description_id}'
for name,out,path,binder in [('GetSystemDescription','SystemDescriptionView',root,'BindSystemDescriptionRead'),('ListSystemDescriptionVersions','Page<SystemDescriptionVersionView>',root+'/versions','BindSystemDescriptionVersions'),('PreviewSystemDescriptionImpact','SystemDescriptionImpactPreview',root+'/impact-preview','BindSystemDescriptionImpact')]:
 params='''
                .Parameter<Uuid>("tenant_id",PortiaHttpParameterLocation.Route,required:true)
                .Parameter<Uuid>("program_id",PortiaHttpParameterLocation.Route,required:true)
                .Parameter<Uuid>("description_id",PortiaHttpParameterLocation.Route,required:true)'''
 if name=='ListSystemDescriptionVersions':params+='''
                .Parameter<int?>("limit",PortiaHttpParameterLocation.Query,required:false)
                .Parameter<string?>("cursor",PortiaHttpParameterLocation.Query,required:false)'''
 maps.append(f'''    app.MapPortiaGet<{name},{out}>(
            "{path}",endpoint => endpoint.OnBind(Program.{binder}){params})
        .RequireAuthorization(ComplianceAuthorizationPolicies.ApiUser)
        .WithTags("System descriptions");''')
needle='    app.MapMethods(\n        "/api/{**path}",';assert needle in s;s=s.replace(needle,'\n'.join(maps)+'\n'+needle,1)
needle='public partial class Program\n{';assert needle in s
helpers='''
    internal static GetSystemDescription BindSystemDescriptionRead(HttpContext context) => new(
        ApplicationRouteId(context,"tenant_id"),ApplicationRouteId(context,"program_id"),ApplicationRouteId(context,"description_id"));
    internal static PreviewSystemDescriptionImpact BindSystemDescriptionImpact(HttpContext context) => new(
        ApplicationRouteId(context,"tenant_id"),ApplicationRouteId(context,"program_id"),ApplicationRouteId(context,"description_id"));
    internal static ListSystemDescriptionVersions BindSystemDescriptionVersions(HttpContext context)
    {
        var raw = PortiaHttpBinding.ReadQuery(context,"limit");
        int? limit = null;
        if (raw is not null)
            limit = int.TryParse(raw,NumberStyles.Integer,CultureInfo.InvariantCulture,out var parsed) ? parsed :
                throw new BadHttpRequestException("The description version limit is invalid.");
        return new ListSystemDescriptionVersions(ApplicationRouteId(context,"tenant_id"),ApplicationRouteId(context,"program_id"),
            ApplicationRouteId(context,"description_id"),limit,PortiaHttpBinding.ReadQuery(context,"cursor"));
    }
'''
s=s.replace(needle,needle+helpers,1);p.write_text(s)
external=json.loads((P/'external-handoff.json').read_text())
(P/'shared-wiring-deltas.json').write_text(json.dumps({'registrations':{'scoped':['SystemDescriptionReader','SystemDescriptionOperations','SystemDescriptionSnapshotSources','SystemDescriptionSourceResolver','SystemDescriptionReadConsistency','SystemDescriptionExportProcess'],'singleton':['SystemDescriptionDocumentRenderer','ISystemDescriptionExportProcesses -> FitzKvSystemDescriptionExportProcesses']},'new_handlers':['GetSystemDescriptionHandler','ListSystemDescriptionVersionsHandler','PreviewSystemDescriptionImpactHandler'],'json_roots':jsonroots,'remove_json_roots':['SystemDescriptionExportGenerated'],'http_maps':[r for c in commands for r in c['http']]+[{'method':'GET','path':root},{'method':'GET','path':root+'/versions'},{'method':'GET','path':root+'/impact-preview'}],'http_rules':'All8 selected mutations retain plain Unit and compose parent OnNativeResult+WithNativeFirstResponse marker. Read aliases use route-authoritative OnBind; version limit/cursor only are query fields. Generate/export/download remain internal/unmapped; no MCP writes.','external_constructor_deltas':external['constructorDeltas'],'source_qualification':'Verified immutable baseline/close native proofs support as-of approval. Nonempty unqualified persisted source history cannot silently claim live-current permits.','parent_overlays':'Apply delta hunks over current parent HTTP bridge/TypeII/Commitment/Boundary. No main edits.'},indent=2)+'\n')
print('shared ready',len(maps))
