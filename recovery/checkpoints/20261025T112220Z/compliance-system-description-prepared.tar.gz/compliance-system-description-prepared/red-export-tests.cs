using Bdgrz.Compliance.Features.SystemDescription;
using Cntryl.Portia;
using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;

namespace Bdgrz.Compliance.Tests.Features.SystemDescription;

public sealed class SystemDescriptionExportBoundaryTests
{
    static readonly Uuid TenantId = Uuid.CreateVersion4();
    static readonly Uuid ProgramId = Uuid.CreateVersion4();
    static readonly Uuid DescriptionId = Uuid.CreateVersion4();
    static readonly Uuid ExaminationId = Uuid.CreateVersion4();
    static readonly Uuid BaselineId = Uuid.CreateVersion4();
    static readonly Uuid AuthorId = Uuid.CreateVersion4();
    static readonly Uuid ReviewerId = Uuid.CreateVersion4();
    static readonly Uuid ApproverId = Uuid.CreateVersion4();
    static readonly DateTimeOffset Now = new(2026,10,24,12,0,0,TimeSpan.Zero);

    [Fact]
    public void ShouldKeepBusinessRevisionGivenIndependentTechnicalExport()
    {
        // Arrange
        var description = new SystemDescriptionAggregate(TenantId,ProgramId,DescriptionId);
        Assert.Null(description.Create(Uuid.CreateVersion4(),new SystemDescriptionScope("type_i",ExaminationId,BaselineId,null,null),
            Content(),AuthorId,"Author",Now));
        Assert.Null(description.Review(1,ReviewerId,"Reviewer","approve","Reviewed exact version",Now.AddMinutes(1)));
        Assert.Null(description.Approve(1,ApproverId,"Approver","Management approved",Now.AddMinutes(2)));
        var before = description.Revision;

        // Act
        var generated = description.GenerateExport(1,Uuid.CreateVersion4(),"pdf","exact-version-export",ApproverId,"Approver",Now.AddMinutes(3));

        // Assert
        Assert.Null(generated);
        Assert.Equal(before,description.Revision);
    }

    static SystemDescriptionDraftContent Content() => new("System Description",
        [
            new("services", "Services", "Hosted service", "complete", null),
            new("commitments_requirements", "Commitments and requirements", "Availability commitments", "complete", null),
            new("components_infrastructure_software", "Components and infrastructure", "Cloud platform", "complete", null),
            new("people", "People", "Security and operations teams", "complete", null),
            new("procedures", "Procedures", "Change and incident procedures", "complete", null),
            new("information_data_flows", "Information and data flows", "Customer data flows", "complete", null),
            new("system_boundary", "System boundary", "Production system", "complete", null),
            new("control_environment", "Control environment", "Approved controls", "complete", null),
            new("user_entity_controls", "User entity controls", "", "not_applicable", "No user entity controls apply"),
            new("subservice_organizations", "Subservice organizations", "Cloud provider", "complete", null),
            new("exclusions", "Exclusions", "Nonproduction sandbox excluded", "complete", null),
            new("relevant_changes", "Relevant changes", "", "not_applicable", "No changes in this period"),
        ], [], [], []);

}
