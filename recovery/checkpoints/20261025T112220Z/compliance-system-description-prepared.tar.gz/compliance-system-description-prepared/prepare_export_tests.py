from pathlib import Path
R=Path('/tmp/compliance-system-description-prepared/work');T='test/Compliance.Tests/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(T+'SystemDescriptionExportProcessTests.cs','''using System.IO.Compression;
using System.Text;
using System.Xml.Linq;
using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.SystemDescription;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.SystemDescription;

public sealed class SystemDescriptionExportProcessTests
{
    [Theory]
    [InlineData("docx")]
    [InlineData("pdf")]
    public async Task ShouldPublishVerifiedFormatAndExactSourceBytesGivenApprovedDescription(string format)
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        await fixture.SeedAsync(approved:true);
        var request = Request(fixture,format,"verified-format");

        // Act
        var result = await new GenerateSystemDescriptionExportHandler(fixture.Exports).HandleAsync(fixture.Context(request),CancellationToken.None);
        var state = await ReadAsync(fixture,request);
        var output = await fixture.Content.ReadJsonAsync<SystemDescriptionExportOutput>(fixture.Tenant.ToString(),state.Output!);
        var exact = await fixture.Content.ReadVerifiedAsync(fixture.Tenant.ToString(),output.SourceContent);
        await using var opened = await fixture.Artifacts.OpenVerifiedAsync(output.Artifact);
        using var bytes = new MemoryStream();await opened!.CopyToAsync(bytes);
        var document = bytes.ToArray();

        // Assert
        Assert.True(result.IsSuccess,result.Error?.Message);Assert.Equal("completed",state.State);
        Assert.Equal(document.LongLength,output.Artifact.Length);
        Assert.Equal(Bdgrz.Compliance.Features.Kernel.ContentDigest.Sha256(document),output.Artifact.Sha256);
        Assert.Equal(3,(await fixture.FactsAsync()).Count);
        if (format == "docx")
        {
            using var zip = new ZipArchive(new MemoryStream(document),ZipArchiveMode.Read);
            using var text = zip.GetEntry("word/document.xml")!.Open();
            var xml = XDocument.Load(text);
            XNamespace word = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
            var extracted = string.Join("\\n",xml.Descendants(word+"t").Select(item => item.Value));
            Assert.Contains("Approved narrative",extracted,StringComparison.Ordinal);
            Assert.Contains("Exact narrative for information_data_flows",extracted,StringComparison.Ordinal);
            using var part = zip.GetEntry("customXml/item1.xml")!.Open();
            var source = XDocument.Load(part).Root!;
            Assert.Equal(exact.ToArray(),Convert.FromBase64String(source.Value));
            using var types = zip.GetEntry("[Content_Types].xml")!.Open();
            Assert.Equal("http://schemas.openxmlformats.org/package/2006/content-types",XDocument.Load(types).Root!.Name.NamespaceName);
        }
        else
        {
            Assert.True(document.AsSpan().StartsWith("%PDF-1.7"u8));
            Assert.True(document.AsSpan().EndsWith("%%EOF\\n"u8));
            Assert.Contains("(Approved narrative) Tj",Encoding.ASCII.GetString(document),StringComparison.Ordinal);
            Assert.True(document.AsSpan().IndexOf(exact.Span) >= 0);
        }
        var artifacts = Environment.GetEnvironmentVariable("COMPLIANCE_EXPORT_RENDER_ARTIFACTS_DIR");
        if (!string.IsNullOrWhiteSpace(artifacts))
        {
            Directory.CreateDirectory(artifacts);
            await File.WriteAllBytesAsync(Path.Combine(artifacts,"system-description."+format),document);
            await File.WriteAllBytesAsync(Path.Combine(artifacts,"system-description-source.json"),exact.ToArray());
        }
    }

    [Fact]
    public async Task ShouldResumePinnedApprovedBytesGivenUnknownAdmissionAndLaterDescriptionChange()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        await fixture.SeedAsync(approved:true);
        var store = new CommitThenThrowProcesses(fixture.Processes,throwOnAdmission:true);
        var process = new SystemDescriptionExportProcess(store,fixture.Descriptions,fixture.Content,fixture.Artifacts,new SystemDescriptionDocumentRenderer(),fixture.Clock);
        var handler = new GenerateSystemDescriptionExportHandler(process);
        var request = Request(fixture,"docx","pinned-retry");
        var first = await handler.HandleAsync(fixture.Context(request),CancellationToken.None);
        Assert.False(first.IsSuccess);Assert.True(first.Error!.IsTransient);
        var accepted = await ReadAsync(fixture,request);
        var original = await fixture.Content.ReadJsonAsync<SystemDescriptionExportIntent>(fixture.Tenant.ToString(),accepted.Intent);
        fixture.Clock.Now = fixture.Clock.Now.AddHours(1);
        Assert.True((await new ProposeSystemDescriptionSuccessorHandler(fixture.Operations).HandleAsync(fixture.Context(new ProposeSystemDescriptionSuccessor(
            Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Description,3,"Later approved-source successor")),CancellationToken.None)).IsSuccess);
        Assert.True((await new ReviseSystemDescriptionDraftHandler(fixture.Operations).HandleAsync(fixture.Context(new ReviseSystemDescriptionDraft(Uuid.CreateVersion4(),
            fixture.Tenant,fixture.Program,fixture.Description,4,"MUTABLE LATER TITLE",SystemDescriptionNativeFixture.Body().Sections,"Later title")),CancellationToken.None)).IsSuccess);

        // Act
        var retry = await handler.HandleAsync(fixture.Context(request),CancellationToken.None);
        var state = await ReadAsync(fixture,request);
        var output = await fixture.Content.ReadJsonAsync<SystemDescriptionExportOutput>(fixture.Tenant.ToString(),state.Output!);
        await using var opened = await fixture.Artifacts.OpenVerifiedAsync(output.Artifact);
        using var zip = new ZipArchive(opened!,ZipArchiveMode.Read);
        using var body = zip.GetEntry("word/document.xml")!.Open();
        var text = XDocument.Load(body).ToString();

        // Assert
        Assert.True(retry.IsSuccess,retry.Error?.Message);
        Assert.Equal(original.SourceContent,output.SourceContent);Assert.Equal(original.Operation.AcceptedAt,output.Export.GeneratedAt);
        Assert.Equal("docx",output.Format);Assert.Equal(1,output.Version);
        Assert.Contains("Approved narrative",text,StringComparison.Ordinal);Assert.DoesNotContain("MUTABLE LATER TITLE",text,StringComparison.Ordinal);
        Assert.Equal(5,(await fixture.FactsAsync()).Count);
    }

    [Fact]
    public async Task ShouldReplayCompletedOriginalUnitGivenUnknownCompletionOutcomeAndRestart()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        await fixture.SeedAsync(approved:true);
        var process = new SystemDescriptionExportProcess(new CommitThenThrowProcesses(fixture.Processes,throwOnAdmission:false),fixture.Descriptions,
            fixture.Content,fixture.Artifacts,new SystemDescriptionDocumentRenderer(),fixture.Clock);
        var request = Request(fixture,"pdf","unknown-completion");

        // Act
        var first = await new GenerateSystemDescriptionExportHandler(process).HandleAsync(fixture.Context(request),CancellationToken.None);
        var state = await ReadAsync(fixture,request);
        var restarted = new SystemDescriptionExportProcess(new FitzKvSystemDescriptionExportProcesses(fixture.Kv),fixture.Descriptions,fixture.Content,
            fixture.Artifacts,new SystemDescriptionDocumentRenderer(),fixture.Clock);
        var replay = await new GenerateSystemDescriptionExportHandler(restarted).HandleAsync(fixture.Context(request),CancellationToken.None);
        var after = await ReadAsync(fixture,request);

        // Assert
        Assert.True(first.IsSuccess,first.Error?.Message);Assert.True(replay.IsSuccess,replay.Error?.Message);
        Assert.Equal(state.Output,after.Output);Assert.Equal(state.OperationResult,after.OperationResult);
        Assert.Equal(1,after.Attempts);Assert.Equal(3,(await fixture.FactsAsync()).Count);
    }

    [Fact]
    public async Task ShouldFailClosedGivenRootIdentityReusedForAnotherDescriptionOrActor()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        await fixture.SeedAsync(approved:true);
        var request = Request(fixture,"docx","collision");
        var handler = new GenerateSystemDescriptionExportHandler(fixture.Exports);
        Assert.True((await handler.HandleAsync(fixture.Context(request),CancellationToken.None)).IsSuccess);
        var before = await ReadAsync(fixture,request);

        // Act
        var owner = await handler.HandleAsync(fixture.Context(request with { DescriptionId = Uuid.CreateVersion4() }),CancellationToken.None);
        var actor = await handler.HandleAsync(fixture.Context(request,fixture.Reviewer),CancellationToken.None);
        var format = await handler.HandleAsync(fixture.Context(request with { Format = "pdf" }),CancellationToken.None);
        var freshId = await handler.HandleAsync(fixture.Context(request with { CommandId = Uuid.CreateVersion4() }),CancellationToken.None);
        var after = await ReadAsync(fixture,request);

        // Assert
        Assert.False(owner.IsSuccess);Assert.False(actor.IsSuccess);Assert.False(format.IsSuccess);Assert.False(freshId.IsSuccess);
        Assert.Equal(before,after);Assert.Equal(3,(await fixture.FactsAsync()).Count);
    }

    [Fact]
    public async Task ShouldRetainUnicodeInDocxAndFreezeTypedPdfFailureGivenUnsupportedGlyph()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        const string narrative = "完整系统说明 🌍 café";
        await fixture.SeedAsync(approved:true,content:SystemDescriptionNativeFixture.Body(narrative));
        var pdf = Request(fixture,"pdf","unicode-pdf");
        var handler = new GenerateSystemDescriptionExportHandler(fixture.Exports);

        // Act
        var failure = await handler.HandleAsync(fixture.Context(pdf),CancellationToken.None);
        var repeated = await handler.HandleAsync(fixture.Context(pdf),CancellationToken.None);
        var failed = await ReadAsync(fixture,pdf);
        var docx = Request(fixture,"docx","unicode-docx");
        var generated = await handler.HandleAsync(fixture.Context(docx),CancellationToken.None);
        var state = await ReadAsync(fixture,docx);
        var output = await fixture.Content.ReadJsonAsync<SystemDescriptionExportOutput>(fixture.Tenant.ToString(),state.Output!);
        await using var opened = await fixture.Artifacts.OpenVerifiedAsync(output.Artifact);
        using var zip = new ZipArchive(opened!,ZipArchiveMode.Read);using var source = zip.GetEntry("word/document.xml")!.Open();
        var xml = XDocument.Load(source);

        // Assert
        Assert.False(failure.IsSuccess);Assert.Equal(RequestErrorKind.Validation,failure.Error!.Kind);
        Assert.Equal(failure.Error,repeated.Error);Assert.Equal("failed",failed.State);Assert.Null(failed.Output);Assert.Null(failed.OperationResult);
        Assert.True(generated.IsSuccess,generated.Error?.Message);Assert.Contains(narrative,xml.ToString(),StringComparison.Ordinal);
        Assert.Equal(3,(await fixture.FactsAsync()).Count);
    }

    static GenerateSystemDescriptionExport Request(SystemDescriptionNativeFixture fixture,string format,string key) =>
        new(Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Description,1,format,key);
    static async Task<SystemDescriptionExportProcessRecord> ReadAsync(SystemDescriptionNativeFixture fixture,GenerateSystemDescriptionExport request) =>
        (await fixture.Processes.ReadAsync(fixture.Tenant,SystemDescriptionExportProcess.IdFor(request.DescriptionId,request.Version,request.ExportKey),request.CommandId,CancellationToken.None))!;
    sealed class CommitThenThrowProcesses(ISystemDescriptionExportProcesses inner,bool throwOnAdmission) : ISystemDescriptionExportProcesses
    {
        int _thrown;
        public Task<SystemDescriptionExportProcessRecord?> ReadAsync(Uuid tenant,Uuid process,Uuid command,CancellationToken ct) => inner.ReadAsync(tenant,process,command,ct);
        public async Task<Result<SystemDescriptionExportProcessRecord>> AcceptIfAbsentAsync(SystemDescriptionExportProcessRecord candidate,CancellationToken ct)
        {
            var result = await inner.AcceptIfAbsentAsync(candidate,ct);
            if (throwOnAdmission && result.IsSuccess && Interlocked.Exchange(ref _thrown,1) == 0)
                throw new IOException("Unknown technical admission response");
            return result;
        }
        public async Task<Result<SystemDescriptionExportProcessRecord>> ReplaceAsync(SystemDescriptionExportProcessRecord expected,SystemDescriptionExportProcessRecord next,CancellationToken ct)
        {
            var result = await inner.ReplaceAsync(expected,next,ct);
            if (!throwOnAdmission && next.State == "completed" && result.IsSuccess && Interlocked.Exchange(ref _thrown,1) == 0)
                throw new IOException("Unknown technical completion response");
            return result;
        }
    }
}
''')
