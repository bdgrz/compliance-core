from pathlib import Path
P=Path('/tmp/compliance-system-description-prepared');R=P/'work';K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(K+'SystemDescription.cs','''using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Hosting.Persistence;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Bounded native description authority. Narrative content, source manifests and history are immutable references.</summary>
public sealed class SystemDescription : Aggregate
{
    public const string Area = "system-descriptions";
    readonly Uuid _tenantId;
    readonly Uuid _requestedProgramId;
    public SystemDescription(Uuid tenantId,Uuid programId,Uuid descriptionId,Uuid selectedCommandId = default)
        : base(descriptionId,new EventStreamAddress(tenantId.ToString(),Area,descriptionId.ToString()))
    {
        _tenantId = tenantId;
        _requestedProgramId = programId;
        Acceptance = new NativeAcceptance(selectedCommandId);
        On<SystemDescriptionDraftCreated>(ApplyFact);
        On<SystemDescriptionDraftRevised>(ApplyFact);
        On<SystemDescriptionSourcesBound>(ApplyFact);
        On<SystemDescriptionReviewed>(ApplyFact);
        On<SystemDescriptionApproved>(ApplyFact);
        On<SystemDescriptionSuccessorProposed>(ApplyFact);
        On<SystemDescriptionNoChangeRecorded>(ApplyFact);
        On<SystemDescriptionBound>(ApplyFact);
    }
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => Header?.ProgramId ?? _requestedProgramId;
    public long Revision => Header?.Revision ?? 0;
    public long NativeSequence { get; private set; }
    public SystemDescriptionAuthorityHeader? Header { get; private set; }
    public ImmutableContentRef? CurrentVersionContent { get; private set; }
    public NativeAcceptance Acceptance { get; }
    public Result Append(DomainEvent value,FrozenSystemDescriptionMutation prepared,long sequence,ulong physicalPosition)
    {
        if (NativeSequence != sequence || CommittedStreamPosition != physicalPosition)
            return Failure("The description changed while its exact source and narrative were prepared.",true);
        if (value is not ISystemDescriptionFact fact || fact.Header != prepared.Header || fact.CurrentVersionContent != prepared.CurrentVersion ||
            SystemDescriptionContent.Payload(fact) != prepared.Payload || fact.ChangeCount != (prepared.Changed ? 1 : 0) ||
            (Header is null ? prepared.Before.Revision != 0 || prepared.Header.ProgramId != _requestedProgramId :
                prepared.Before.Revision == 0 || SystemDescriptionContent.Header(prepared.Before) != Header) ||
            !SystemDescriptionContent.Verify(prepared))
            return Failure("The description mutation does not carry its exact verified local rule transition.");
        try
        {
            Validate(value,fact);
            if (DomainEventPayload.Size(value) > DomainEventPayload.MaximumBytes)
                return Failure("The compact native description fact exceeds the bounded event envelope.");
        }
        catch (InvalidOperationException)
        {
            return Failure("The description mutation has an invalid native authority binding.");
        }
        RaiseEvent(value);
        return Result.Success;
    }
    void ApplyFact(DomainEvent value)
    {
        var fact = (ISystemDescriptionFact)value;
        Validate(value,fact);
        Header = fact.Header;
        CurrentVersionContent = fact.CurrentVersionContent;
        NativeSequence = fact.NativeSequence;
        Acceptance.Observe(value);
    }
    void Validate(DomainEvent value,ISystemDescriptionFact fact)
    {
        var h = fact.Header;
        var op = fact.Operation;
        if (h is null || op is null || op.Actor is null)
            throw new InvalidOperationException("A description fact requires its complete native authority and operation.");
        OwnerProvenance.RequireOwn(this,op.LogicalId,op);
        var kind = value switch
        {
            SystemDescriptionDraftCreated => nameof(CreateSystemDescriptionDraft),
            SystemDescriptionDraftRevised => nameof(ReviseSystemDescriptionDraft),
            SystemDescriptionSourcesBound => nameof(BindSystemDescriptionSources),
            SystemDescriptionReviewed => nameof(ReviewSystemDescription),
            SystemDescriptionApproved => nameof(ApproveSystemDescription),
            SystemDescriptionSuccessorProposed => nameof(ProposeSystemDescriptionSuccessor),
            SystemDescriptionNoChangeRecorded => nameof(RecordSystemDescriptionNoChangeDecision),
            SystemDescriptionBound => nameof(BindSystemDescriptionToExamination),
            _ => "",
        };
        if (fact.TenantId != _tenantId || h.TenantId != _tenantId || h.ProgramId == Uuid.Empty || fact.ProgramId != h.ProgramId ||
            h.SystemDescriptionId != Id || fact.SystemDescriptionId != Id || fact.AggregateRevision != h.Revision || h.Revision <= 0 ||
            h.CurrentVersion < 1 || h.CurrentVersionId == Uuid.Empty || h.AuthorMemberId == Uuid.Empty ||
            h.Status is not ("draft" or "approved") || string.IsNullOrWhiteSpace(h.Title) || h.Title.Length > 200 ||
            !Hex(h.ContentSha256) || !Hex(h.NoChangeDecisionsSha256) || !Hex(h.BindingsSha256) || !Hex(h.VersionsSha256) ||
            !Hex(h.ReviewsSha256) || !Hex(h.ApprovalsSha256) || h.VersionUpdatedAt == default ||
            fact.NativeSequence != NativeSequence+1 || fact.ChangeCount is < 0 or > 1 || fact.ActorMemberId == Uuid.Empty ||
            op.Actor.Kind != "member" || !Uuid.TryParse(op.Actor.Id,out var member) || member != fact.ActorMemberId ||
            op.CommandKind != kind || op.Owner != Stream || op.FirstOwner != Stream || op.AffectedOwner != Stream ||
            op.ExpectedRevisionOwner != Stream || op.Episode != Id.ToString() || op.RootOperationId != op.LogicalId ||
            op.CausationEventId is not null || !Hex(op.AuthoredIntentSha256) || op.AcceptedAt == default || fact.OccurredAt != op.AcceptedAt ||
            !Reference(fact.CurrentVersionContent,SystemDescriptionContent.CurrentSchema) ||
            !Reference(fact.FirstResponse,FirstResponses.Schema) || !Reference(fact.OperationResult,"mutation-result-content.v1") ||
            SystemDescriptionContent.Payload(fact) is not { Bytes: > 0 } payload || payload.ContentId == Uuid.Empty || !Hex(payload.Sha256))
            throw new InvalidOperationException("The description native fact has another exact scope, actor, result or content binding.");
        if (Header is null)
        {
            if (kind != nameof(CreateSystemDescriptionDraft) || op.LogicalId != Id || h.Revision != 1 || h.CurrentVersion != 1 ||
                h.ParentVersionId is not null || h.Status != "draft" || fact.ChangeCount != 1 || op.OriginalExpectedRevision is not null)
                throw new InvalidOperationException("A description begins with its own identified initial narrative.");
            return;
        }
        var before = Header;
        var nextVersion = value is SystemDescriptionDraftRevised or SystemDescriptionSourcesBound or SystemDescriptionSuccessorProposed;
        if (value is SystemDescriptionDraftCreated || h.ProgramId != before.ProgramId || h.Revision != before.Revision+fact.ChangeCount ||
            h.CurrentVersion != before.CurrentVersion+(nextVersion ? 1 : 0) ||
            nextVersion && (h.ParentVersionId != before.CurrentVersionId || h.CurrentVersionId == before.CurrentVersionId || h.Status != "draft") ||
            !nextVersion && h.CurrentVersionId != before.CurrentVersionId ||
            op.OriginalExpectedRevision != unchecked((ulong)before.Revision) ||
            fact.ChangeCount == 0 && (h != before || fact.CurrentVersionContent != CurrentVersionContent))
            throw new InvalidOperationException("A description transition cannot rewrite identity, lineage or its caller's original revision gate.");
    }
    static bool Reference(ImmutableContentRef? value,string schema) => value is { Bytes: > 0 } && value.ContentId != Uuid.Empty &&
        value.Schema == schema && Hex(value.Sha256);
    static bool Hex(string? value) => value is { Length: 64 } && value.All(Uri.IsHexDigit);
    static Result Failure(string message,bool transient = false) => Result.Failure(new RequestError(RequestErrorKind.Conflict,message,transient));
}
''')
put(K+'SystemDescriptionReader.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Exact native-cut reconstruction of immutable narrative versions, decisions and historical bindings.</summary>
public sealed class SystemDescriptionReader(IAggregateReader reader,IDomainEventReader events,IImmutableContentStore content)
{
    public async ValueTask<SystemDescriptionReadSnapshot> ReadAsync(Uuid tenantId,Uuid programId,Uuid descriptionId,CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new SystemDescription(tenantId,programId,descriptionId),ct).ConfigureAwait(false);
        return await ReadAsync(owner,programId,ct).ConfigureAwait(false);
    }
    internal async ValueTask<SystemDescriptionReadSnapshot> ReadAsync(SystemDescription owner,Uuid programId,CancellationToken ct)
    {
        var rules = new SystemDescriptionRules(owner.TenantId,programId,owner.Id);
        var facts = new List<DomainEvent>();
        if (owner.Header is null || owner.ProgramId != programId)
            return new(owner,rules,facts);
        var sequence = 0L;
        ISystemDescriptionFact? last = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(owner.TenantId.ToString(),SystemDescription.Area,owner.Id.ToString()),EventCursor.Start,ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit)
                continue;
            if (record.Event is not ISystemDescriptionFact fact || fact.NativeSequence != sequence+1 ||
                record.Stream != owner.Stream || fact.TenantId != owner.TenantId || fact.ProgramId != programId)
                throw new ImmutableContentIntegrityException("The description history has another native sequence or exact owner scope.");
            if (fact.NativeSequence > owner.NativeSequence)
                break;
            var mutation = await SystemDescriptionContent.ReadMutationAsync(content,record.Event,ct).ConfigureAwait(false);
            var current = await content.ReadJsonAsync<SystemDescriptionVersionView>(owner.TenantId.ToString(),fact.CurrentVersionContent,ct).ConfigureAwait(false);
            if (fact.CurrentVersionContent.Schema != SystemDescriptionContent.CurrentSchema)
                throw new ImmutableContentIntegrityException("The description current version has another immutable schema.");
            var before = rules.Read();
            var after = SystemDescriptionRules.FromView(before);
            if (fact.ChangeCount == 1)
                after.Apply(mutation);
            var frozen = new FrozenSystemDescriptionMutation(before,after.Read(),fact.Header,fact.CurrentVersionContent,
                SystemDescriptionContent.Payload(fact),mutation,fact.Operation.CommandKind,fact.ChangeCount == 1);
            if (!SystemDescriptionContent.Verify(frozen) || after.CurrentVersion is null ||
                AuthoredIntentDigest.Compute(current) != AuthoredIntentDigest.Compute(after.CurrentVersion))
                throw new ImmutableContentIntegrityException("The description source payload differs from its actual business transition and current authority.");
            if (fact.ChangeCount == 1)
                rules.Apply(mutation);
            facts.Add(record.Event);
            last = fact;
            sequence = fact.NativeSequence;
            if (sequence == owner.NativeSequence)
                break;
        }
        if (sequence != owner.NativeSequence || last is null)
            throw new ImmutableContentUnavailableException("The exact description native source cut is not readable yet.");
        if (last.Header != owner.Header || last.CurrentVersionContent != owner.CurrentVersionContent)
            throw new ImmutableContentIntegrityException("The reconstructed description differs from its compact owner authority.");
        rules.ClearPendingChanges();
        rules.SourceNativeSequence = owner.NativeSequence;
        rules.SourcePhysicalPosition = owner.CommittedStreamPosition;
        return new(owner,rules,facts.AsReadOnly());
    }
    public async ValueTask<SystemDescriptionVersionSource?> VersionSourceAsync(Uuid tenantId,Uuid programId,Uuid descriptionId,
        Uuid versionId,CancellationToken ct = default)
    {
        var snapshot = await ReadAsync(tenantId,programId,descriptionId,ct).ConfigureAwait(false);
        if (snapshot.FindVersion(versionId) is not { } version)
            return null;
        var producing = snapshot.Facts.FirstOrDefault(value => value is SystemDescriptionDraftCreated or SystemDescriptionDraftRevised or
            SystemDescriptionSourcesBound or SystemDescriptionSuccessorProposed && ((ISystemDescriptionFact)value).Header.CurrentVersionId == versionId);
        if (producing is null)
            throw new ImmutableContentIntegrityException("A description version has no exact native producing fact.");
        var current = snapshot.Facts.Last(value => ((ISystemDescriptionFact)value).Header.CurrentVersionId == versionId &&
            ((ISystemDescriptionFact)value).Header.Status == version.Status);
        var reference = ((ISystemDescriptionFact)current).CurrentVersionContent;
        var approval = snapshot.Facts.OfType<SystemDescriptionApproved>().FirstOrDefault(value => value.Header.CurrentVersionId == versionId && value.ChangeCount == 1);
        return new(version,reference,NativeFactReference.Of(snapshot.Stream,producing),
            approval is null ? null : NativeFactReference.Of(snapshot.Stream,approval),snapshot.FindApproval(versionId),
            snapshot.Owner.NativeSequence,snapshot.Owner.CommittedStreamPosition);
    }
    public async ValueTask<SystemDescriptionVersionSource?> VersionSourceAsync(Uuid tenantId,Uuid programId,Uuid descriptionId,
        long version,CancellationToken ct = default)
    {
        var snapshot = await ReadAsync(tenantId,programId,descriptionId,ct).ConfigureAwait(false);
        return snapshot.FindVersion(version) is not { } selected ? null :
            await VersionSourceAsync(tenantId,programId,descriptionId,selected.SystemDescriptionVersionId,ct).ConfigureAwait(false);
    }
}
''')
