from pathlib import Path
import json,re
P=Path('/tmp/compliance-system-description-prepared');R=P/'work';C='src/Compliance.Common/Features/SystemDescription/';K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
# Exact selected request fields; existing plain Unit remains for the parent descriptor-aware HTTP bridge.
rows=json.loads((P/'target-command-contracts.json').read_text())
for row in rows:
 name=row['command'];old=(P/'base'/C/(name+'.cs')).read_text();tag=re.search(r'\[Discriminator\("([^"]+)", (\d+)\)\]',old)
 fields=', '.join(x['type']+' '+x['name'] for x in row['fields'])
 interfaces='IRequest, IIdentifiedRequest, IProgramScopedRequest, IClientManagementMutationRequest'
 put(C+name+'.cs',f'''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Programs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Identified authored intent over its exact selected owner/version scope.</summary>
[Discriminator("{tag[1]}", {int(tag[2])+1})]
public sealed record {name}({fields}) : {interfaces}
{{
    Uuid IIdentifiedRequest.RequestId => {'DescriptionId' if name=='CreateSystemDescriptionDraft' else 'CommandId'};
}}
''')
put(K+'SystemDescriptionOperations.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Versioning;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Exact native acceptance; source guards and immutable publication stay inside recovery-aware preparation.</summary>
public sealed class SystemDescriptionOperations(NativeOperationExecutor operations,SystemDescriptionReader descriptions,
    IImmutableContentStore content,TimeProvider clock)
{
    public async ValueTask<Result> ExecuteAsync<TRequest>(IRequestContext<TRequest> context,Uuid tenant,Uuid program,
        Uuid description,Uuid command,string kind,long? expected,
        Func<SystemDescriptionReadSnapshot,OperationProvenance,CancellationToken,ValueTask<Result>> prepare,
        Func<SystemDescriptionRules,OperationProvenance,object?>? receipt,CancellationToken ct) where TRequest : IRequestBase
    {
        if (context.Invocation is not HttpInvocation || RequestActor.IsSystem(context.Actor) ||
            !SystemDescriptionCommandActor.TryGet(context.Actor,tenant,out var member,out var display))
            return Result.Failure(new RequestError(RequestErrorKind.Forbidden,"A description decision requires a personal HTTP member actor."));
        if (tenant == Uuid.Empty || program == Uuid.Empty || description == Uuid.Empty || command == Uuid.Empty || expected is <= 0)
            return Result.Failure(new RequestError(RequestErrorKind.Validation,"A description operation requires exact identities and its positive original revision when required."));
        var operation = OwnerProvenance.For(new SystemDescription(tenant,program,description),command,kind,
            ActorReference.ForMember(member,display),description.ToString(),expected is { } revision ? unchecked((ulong)revision) : null,
            AuthoredIntentDigest.Compute(context.Request),clock.GetUtcNow());
        FrozenSystemDescriptionMutation? frozen = null;
        ImmutableContentRef? result = null;
        var sequence = 0L;
        var position = 0UL;
        try
        {
            var accepted = await operations.ExecuteAsync(new NativeOperation<SystemDescription>(AcceptedOperationBinding.Of(operation),
                () => new SystemDescription(tenant,program,description,command),owner => owner.Acceptance,
                async (owner,token) =>
                {
                    try
                    {
                        if (kind == nameof(CreateSystemDescriptionDraft) ? owner.Header is not null : owner.Header is null || owner.ProgramId != program)
                            return Result<FirstResponseDescriptor>.Failure(new RequestError(kind == nameof(CreateSystemDescriptionDraft) ? RequestErrorKind.Conflict : RequestErrorKind.NotFound,
                                "The system description is not available for this operation."));
                        if (expected is { } original && owner.Revision != original)
                            return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,"The description requires its original expected logical revision."));
                        var snapshot = await descriptions.ReadAsync(owner,program,token).ConfigureAwait(false);
                        var before = snapshot.View;
                        var ready = await prepare(snapshot,operation,token).ConfigureAwait(false);
                        if (!ready.IsSuccess)
                            return Result<FirstResponseDescriptor>.Failure(ready.Error!);
                        frozen = await SystemDescriptionContent.FreezeAsync(content,before,snapshot.Rules,kind,
                            snapshot.Rules.PendingChanges.Count == 0 ? receipt?.Invoke(snapshot.Rules,operation) : null,token).ConfigureAwait(false);
                        frozen = frozen with { SourceSnapshotContent = snapshot.PreparedSourceSnapshotContent ?? owner.SourceSnapshotContent };
                        var response = await NativeContent.FreezeUnitAsync(content,tenant,token).ConfigureAwait(false);
                        result = response.Result;
                        sequence = owner.NativeSequence;
                        position = owner.CommittedStreamPosition;
                        return Result<FirstResponseDescriptor>.Success(response.Response);
                    }
                    catch (ImmutableContentIntegrityException exception)
                    {
                        return Result<FirstResponseDescriptor>.Failure(SystemDescriptionReadFailure.Of(exception));
                    }
                },(owner,response) => owner.Append(SystemDescriptionFactFactory.Create(frozen!,sequence+1,operation,response,result!),
                    frozen!,sequence,position)),context,ct).ConfigureAwait(false);
            if (!accepted.IsSuccess)
                return Result.Failure(accepted.Error!);
            var descriptor = accepted.Value switch
            {
                AcceptedAppendResult.Committed committed => committed.Response,
                AcceptedAppendResult.Replayed replayed => replayed.Response,
                _ => null,
            };
            if (descriptor is null)
                return Result.Failure(AcceptedAppendResult.ConflictError);
            if (descriptor.HttpStatus != 200 || descriptor.ResultSchema != UnitResult.Schema ||
                descriptor.Body is not StandardResponseBody body || body.Content.Schema != UnitResult.Schema)
                throw new ImmutableContentIntegrityException("The original description response has another result contract.");
            await content.ReadJsonAsync<UnitResult>(tenant.ToString(),body.Content,ct).ConfigureAwait(false);
            return Result.Success;
        }
        catch (ImmutableContentIntegrityException exception)
        {
            return Result.Failure(SystemDescriptionReadFailure.Of(exception));
        }
    }
    public static Result Outcome(CommandFailure? failure) => failure is null ? Result.Success : Result.Failure(failure.ToRequestError());
}
''')
# Source-free descriptions retain rule qualification. Real current-source workflows remain fenced until the selected held-use protocol exists.
put(K+'SystemDescriptionApprovalQualification.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Fails closed rather than substituting a mutable source read for the required held approval permits.</summary>
public static class SystemDescriptionApprovalQualification
{
    public static Result Check(SystemDescriptionReadSnapshot snapshot) => snapshot.CurrentVersion is { } version && version.Content.Sources.Count == 0
        ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict,
            "System description approval with governed sources requires the selected source authorization and settlement protocol, which is not implemented."));
}
''')
for name,apply,receipt in [
('ReviewSystemDescription','snapshot.Rules.Review(request.Version,member,display,request.Outcome,request.Comments,operation.AcceptedAt)',
 'new SystemDescriptionReviewedBody(request.TenantId,request.ProgramId,request.DescriptionId,rules.Revision,rules.Reviews.First(item => item.Version == request.Version && item.ReviewerMemberId == member),operation.AcceptedAt)'),
('ApproveSystemDescription','snapshot.Rules.Approve(request.Version,member,display,request.Rationale,operation.AcceptedAt)','null'),
('RecordSystemDescriptionNoChangeDecision','snapshot.Rules.RecordNoChangeDecision(request.Version,request.ChangeId,request.Rationale,member,display,operation.AcceptedAt)',
 'new SystemDescriptionNoChangeRecordedBody(request.TenantId,request.ProgramId,request.DescriptionId,rules.Revision,rules.NoChangeDecisions.First(item => item.Version == request.Version && item.ChangeId == request.ChangeId),operation.AcceptedAt)')]:
 extra='''                var qualification = SystemDescriptionApprovalQualification.Check(snapshot);
                if (!qualification.IsSuccess)
                    return ValueTask.FromResult(qualification);
''' if name=='ApproveSystemDescription' else ''
 put(K+name+'Handler.cs',f'''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class {name}Handler(SystemDescriptionOperations operations) : IRequestHandler<{name}>
{{
    public ValueTask<Result> HandleAsync(IRequestContext<{name}> context,CancellationToken ct)
    {{
        var request = context.Request;
        if (!SystemDescriptionCommandActor.TryGet(context.Actor,request.TenantId,out var member,out var display))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Unauthorized,"A description decision requires a Bdgrz member identity.")));
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.DescriptionId,request.CommandId,
            nameof({name}),request.ExpectedRevision,(snapshot,operation,token) =>
            {{
{extra}                return ValueTask.FromResult(SystemDescriptionOperations.Outcome({apply}));
            }},(rules,operation) => {receipt},ct);
    }}
}}
''')
put(K+'ReviseSystemDescriptionDraftHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class ReviseSystemDescriptionDraftHandler(SystemDescriptionOperations operations) : IRequestHandler<ReviseSystemDescriptionDraft>
{
    public ValueTask<Result> HandleAsync(IRequestContext<ReviseSystemDescriptionDraft> context,CancellationToken ct)
    {
        var request = context.Request;
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.DescriptionId,request.CommandId,
            nameof(ReviseSystemDescriptionDraft),request.ExpectedRevision,(snapshot,operation,token) =>
            {
                var current = snapshot.CurrentVersion!;
                var value = new SystemDescriptionDraftContent(request.Title,request.Sections,current.Content.Sources,
                    current.Content.PeriodChanges,current.Content.SignificantChangeIds);
                Uuid.TryParse(operation.Actor.Id,out var member);
                return ValueTask.FromResult(SystemDescriptionOperations.Outcome(snapshot.Rules.Revise(request.ExpectedRevision,
                    request.CommandId,value,request.ChangeReason,member,operation.Actor.Display,operation.AcceptedAt)));
            },null,ct);
    }
}
''')
put(K+'ProposeSystemDescriptionSuccessorHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class ProposeSystemDescriptionSuccessorHandler(SystemDescriptionOperations operations) : IRequestHandler<ProposeSystemDescriptionSuccessor>
{
    public ValueTask<Result> HandleAsync(IRequestContext<ProposeSystemDescriptionSuccessor> context,CancellationToken ct)
    {
        var request = context.Request;
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.DescriptionId,request.CommandId,
            nameof(ProposeSystemDescriptionSuccessor),request.ExpectedRevision,(snapshot,operation,token) =>
            {
                Uuid.TryParse(operation.Actor.Id,out var member);
                return ValueTask.FromResult(SystemDescriptionOperations.Outcome(snapshot.Rules.ProposeSuccessor(request.ExpectedRevision,
                    request.CommandId,snapshot.CurrentVersion!.Content,request.ChangeReason,member,operation.Actor.Display,operation.AcceptedAt)));
            },null,ct);
    }
}
''')
put(K+'BindSystemDescriptionToExaminationHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class BindSystemDescriptionToExaminationHandler(SystemDescriptionOperations operations) : IRequestHandler<BindSystemDescriptionToExamination>
{
    public ValueTask<Result> HandleAsync(IRequestContext<BindSystemDescriptionToExamination> context,CancellationToken ct)
    {
        var request = context.Request;
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.DescriptionId,request.CommandId,
            nameof(BindSystemDescriptionToExamination),request.ExpectedRevision,(snapshot,operation,token) =>
            {
                var version = snapshot.FindVersion(request.Version);
                var id = version?.Scope.Stage switch
                {
                    "type_i" => version.Scope.TypeIBaselineId ?? Uuid.Empty,
                    "type_ii" => version.Scope.CloseSnapshotId ?? Uuid.Empty,
                    _ => Uuid.Empty,
                };
                Uuid.TryParse(operation.Actor.Id,out var member);
                return ValueTask.FromResult(SystemDescriptionOperations.Outcome(snapshot.Rules.BindToExamination(request.Version,
                    request.ExaminationId,request.BindingPurpose,id,member,operation.Actor.Display,operation.AcceptedAt)));
            },(rules,operation) => new SystemDescriptionBoundBody(request.TenantId,request.ProgramId,request.DescriptionId,rules.Revision,
                rules.Read().Bindings.First(item => item.Version == request.Version && item.Purpose == request.BindingPurpose),operation.AcceptedAt),ct);
    }
}
''')
