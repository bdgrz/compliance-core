from pathlib import Path
import re
P=Path('/tmp/compliance-system-description-prepared');R=P/'work';T='test/Compliance.Tests/Features/SystemDescription/';K='src/Compliance.Core/Features/SystemDescription/'
# Preserve the main stage2 period reader/seed adaptations before applying this owner's test migration.
for rel in [T+'SystemDescriptionDraftCommandHandlerTests.cs',K+'BindSystemDescriptionSourcesHandler.cs']:
 (P/'base'/rel).write_bytes(Path(rel).read_bytes())
 if rel.startswith('test/'):(R/rel).write_bytes(Path(rel).read_bytes())
p=R/(T+'SystemDescriptionTests.cs');s=p.read_text().replace('using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;','using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescriptionRules;').replace('new AggregateScenario<SystemDescriptionAggregate>(notApplicable).PendingEvents','notApplicable.PendingChanges').replace('new AggregateScenario<SystemDescriptionAggregate>(description).PendingEvents','description.PendingChanges').replace('Assert.IsType<SystemDescriptionDraftCreated>(created)','Assert.IsType<SystemDescriptionDraftCreatedBody>(created)').replace('Assert.IsType<SystemDescriptionSourcesBound>(bound)','Assert.IsType<SystemDescriptionSourcesBoundBody>(bound)')
s=s.replace('public void ShouldRetainCompleteNarrativeGivenValidContentExceedsOldEventEnvelope()','public async Task ShouldRetainCompleteNarrativeGivenValidContentExceedsOldEventEnvelope()');s=s.replace('''        Assert.Equal(72000,description.CurrentVersion!.Content.Sections.Sum(section => section.Content.Length));''','''        Assert.Equal(72000,description.CurrentVersion!.Content.Sections.Sum(section => section.Content.Length));
        await using var fixture = new SystemDescriptionNativeFixture();
        await DescriptionSeeds.WriteAsync(fixture.Writer,fixture.Content,description);
        var read = await fixture.Descriptions.ReadAsync(TenantId,ProgramId,DescriptionId);
        Assert.Equal(72000,read.CurrentVersion!.Content.Sections.Sum(section => section.Content.Length));
        await foreach (var record in fixture.Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString(),"system-descriptions",DescriptionId.ToString()),EventCursor.Start,CancellationToken.None))
            if (!record.Event.Metadata.IsAudit)
                Assert.True(Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.Size(record.Event) < Bdgrz.Compliance.Hosting.Persistence.DomainEventPayload.MaximumBytes);''');p.write_text(s)
# The draft producer fixture retains real frozen baseline and native period/plan source facts.
p=R/(T+'SystemDescriptionDraftCommandHandlerTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.NativeOperations;\n'+s;s=s.replace('using DescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;','using DescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescriptionRules;')
for name in ['ReviseSystemDescriptionDraft','BindSystemDescriptionSources']:s=s.replace('new '+name+'(','new '+name+'(Uuid.CreateVersion4(), ')
s=re.sub(r'await fixture.Reader.HydrateAsync\(new DescriptionAggregate\(([^)]+)\)\)',r'await fixture.Descriptions.ReadAsync(\1)',s)
s=s.replace('        public TypeIIPeriodReader Periods =>','''        public SystemDescriptionReader Descriptions => new(Reader,PeriodEvents,PeriodContent);
        public SystemDescriptionOperations Operations => new(new NativeOperationExecutor(Reader,Executor,PeriodContent),Descriptions,PeriodContent,_clock);
        public SystemDescriptionSourceResolver Sources => new(Reader,Periods,new SystemDescriptionSnapshotSources(PeriodEvents,PeriodContent));
        public TypeIIPeriodReader Periods =>''')
s=s.replace('new(Reader, Executor, _clock)','new(Operations,Sources)').replace('new(Executor, _clock)','new(Operations)').replace('new(Reader, Executor, Periods, _clock)','new(Operations,Sources)')
s=s.replace('await Writer.SaveAsync(aggregate, new RequestDispatchContext(RequestActor.System));\n        }\n\n        public async Task<TypeIIPeriodView>', 'await DescriptionSeeds.WriteAsync(Writer,PeriodContent,aggregate);\n        }\n\n        public async Task<TypeIIPeriodView>')
s=s.replace('''            await Writer.SaveAsync(aggregate, new RequestDispatchContext(RequestActor.System));
        }

        IReadOnlyList<ExaminationContentReference>''','''            await DescriptionSeeds.WriteAsync(Writer,PeriodContent,aggregate);
        }

        IReadOnlyList<ExaminationContentReference>''')
# Existing stale caller revision remains a Conflict rather than a transport validation change.
s=s.replace('Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);\n        Assert.Equal(1, saved.Revision);', 'Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);\n        Assert.Equal(1, saved.Revision);')
p.write_text(s)
# Selected caller ExpectedRevision is explicit on every existing decision command.
p=R/(T+'SystemDescriptionCommandHandlerTests.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;\nusing Cntryl.Fitz.Testing;\n'+s
s=s.replace('new Bdgrz.Compliance.Features.SystemDescription.SystemDescription(', 'new Bdgrz.Compliance.Features.SystemDescription.SystemDescriptionRules(')
s=re.sub(r'await fixture.Reader.HydrateAsync\(new Bdgrz.Compliance.Features.SystemDescription.SystemDescriptionRules\(([^)]+)\)\)',r'await fixture.Descriptions.ReadAsync(\1)',s)
for name in ['ReviewSystemDescription','ApproveSystemDescription','BindSystemDescriptionToExamination','GenerateSystemDescriptionExport','RecordSystemDescriptionNoChangeDecision','ProposeSystemDescriptionSuccessor']:
 s=s.replace('new '+name+'(','new '+name+'(Uuid.CreateVersion4(), ')
s=s.replace('"Required sections and current sources reviewed."))','"Required sections and current sources reviewed.",1))').replace('"Independent review complete."))','"Independent review complete.",1))')
s=s.replace('"Management approves the current system description."))','"Management approves the current system description.",2))').replace('"Author cannot approve their own description."))','"Author cannot approve their own description.",2))')
s=s.replace('descriptionId, 1, fixture.ExaminationId, "type_i_baseline"))','descriptionId, 1, fixture.ExaminationId, "type_i_baseline",3))')
s=s.replace('"The reviewed change does not alter the described system."))','"The reviewed change does not alter the described system.",1))')
s=s.replace('''        Assert.Equal("pdf", Assert.Single(saved.Read().Exports).Format);''','''        Assert.Equal(4,saved.Revision);
        var state = await fixture.ExportProcesses.ReadAsync(fixture.TenantId,SystemDescriptionExportProcess.IdFor(descriptionId,1,"type-i-description-v1"),Uuid.Empty,CancellationToken.None);
        var output = await fixture.Content.ReadJsonAsync<SystemDescriptionExportOutput>(fixture.TenantId.ToString(),state!.Output!);
        Assert.Equal("pdf",output.Format);
        Assert.True(output.Artifact.Length > 0);''')
s=s.replace('            services.AddSingleton<IEventStore>(new InMemoryEventStore());','            services.AddSingleton<IEventStore>(Events);')
s=s.replace('        public IAggregateReader Reader { get; }','''        public InMemoryEventStore Events { get; } = new();
        public IImmutableContentStore Content { get; } = DescriptionSeeds.Content();
        public ISystemDescriptionExportProcesses ExportProcesses { get; } = new FitzKvSystemDescriptionExportProcesses(new InMemoryKvClient());
        public SystemDescriptionReader Descriptions => new(Reader,Events,Content);
        public SystemDescriptionOperations Operations => new(new NativeOperationExecutor(Reader,Executor,Content),Descriptions,Content,_clock);
        public IAggregateReader Reader { get; }''')
s=s.replace('new(Executor, _clock)','new(Operations)')
s=s.replace('        public GenerateSystemDescriptionExportHandler ExportHandler() => new(Operations);','''        readonly string _artifactDirectory = Path.Combine(Path.GetTempPath(),"bdgrz-description-command-"+Guid.NewGuid().ToString("N"));
        public GenerateSystemDescriptionExportHandler ExportHandler() => new(new SystemDescriptionExportProcess(ExportProcesses,Descriptions,Content,
            new Bdgrz.Compliance.Features.Artifacts.LocalArtifactContentStore(new Bdgrz.Compliance.Features.Artifacts.ArtifactContentStoreOptions(_artifactDirectory,new byte[32],
                Bdgrz.Compliance.Features.Artifacts.ArtifactContentLimits.MaxContentLength),_clock),new SystemDescriptionDocumentRenderer(),_clock));''')
s=s.replace('await Writer.SaveAsync(aggregate, new RequestDispatchContext(RequestActor.System));','await DescriptionSeeds.WriteAsync(Writer,Content,aggregate);')
s=s.replace('''            await _provider.DisposeAsync();''','''            await _provider.DisposeAsync();
            if (Directory.Exists(_artifactDirectory))Directory.Delete(_artifactDirectory,recursive:true);''');p.write_text(s)
# Preserve the old export boundary RED name with the actual independently persisted process/backend.
p=R/(T+'SystemDescriptionExportBoundaryTests.cs');p.write_text('''using Bdgrz.Compliance.Features.SystemDescription;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.SystemDescription;

public sealed class SystemDescriptionExportBoundaryTests
{
    [Fact]
    public async Task ShouldKeepBusinessRevisionGivenIndependentTechnicalExport()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        await fixture.SeedAsync(approved:true);
        var before = (await fixture.Descriptions.ReadAsync(fixture.Tenant,fixture.Program,fixture.Description)).Revision;
        var request = new GenerateSystemDescriptionExport(Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Description,1,"pdf","exact-version-export");

        // Act
        var generated = await new GenerateSystemDescriptionExportHandler(fixture.Exports).HandleAsync(fixture.Context(request),CancellationToken.None);
        var after = await fixture.Descriptions.ReadAsync(fixture.Tenant,fixture.Program,fixture.Description);

        // Assert
        Assert.True(generated.IsSuccess,generated.Error?.Message);
        Assert.Equal(before,after.Revision);
        Assert.Equal(3,(await fixture.FactsAsync()).Count);
    }
}
''')
