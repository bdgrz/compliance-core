from pathlib import Path
R=Path('/tmp/compliance-system-description-prepared/work');C='src/Compliance.Common/Features/SystemDescription/';K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(K+'SystemDescriptionSnapshotSourceProof.cs','''using Bdgrz.Compliance.Features.NativeOperations;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Exact authoritative native source cut used to freeze a complete description source-version population.</summary>
public sealed record SystemDescriptionSnapshotSourceProof(SystemDescriptionScope Scope,
    IReadOnlyList<SystemDescriptionSourceReference> Sources,IReadOnlyList<SystemDescriptionSnapshotSourceFact> Facts);
''')
put(K+'SystemDescriptionSnapshotSourceFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed record SystemDescriptionSnapshotSourceFact(NativeFactReference Fact,string EventKind,string PayloadSha256);
''')
put(K+'SystemDescriptionSnapshotSources.cs','''using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.SourceFacts;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Captures immutable native snapshot evidence. This does not claim a held current-at-approval source permit.</summary>
public sealed class SystemDescriptionSnapshotSources(IDomainEventReader events,IImmutableContentStore content)
{
    public const string Schema = "system-description-snapshot-source-proof.v1";
    public async ValueTask<ImmutableContentRef> CaptureAsync(Uuid tenant,Uuid program,SystemDescriptionScope scope,
        IReadOnlyList<SystemDescriptionSourceReference> sources,EventStreamAddress source,Func<DomainEvent,bool> select,
        CancellationToken ct)
    {
        DomainEvent? selected = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(source.Realm,source.Area,source.Resource),EventCursor.Start,ct).ConfigureAwait(false))
            if (!record.Event.Metadata.IsAudit && select(record.Event))
                selected = record.Event;
        if (selected is null || source.Realm != tenant.ToString())
            throw new ImmutableContentUnavailableException("The exact frozen snapshot source fact is not readable yet.");
        var proof = new SystemDescriptionSnapshotSourceProof(scope,sources,[new(NativeFactReference.Of(source,selected),
            EventKind.Of(selected),ContentDigest.Sha256(selected,selected.GetType()))]);
        var reference = await content.WriteJsonAsync(tenant.ToString(),Uuid.CreateVersion4(),Schema,proof,ct).ConfigureAwait(false);
        await VerifyAsync(tenant,program,scope,sources,reference,ct).ConfigureAwait(false);
        return reference;
    }
    public async ValueTask VerifyAsync(Uuid tenant,Uuid program,SystemDescriptionScope scope,
        IReadOnlyList<SystemDescriptionSourceReference> sources,ImmutableContentRef reference,CancellationToken ct)
    {
        if (reference.Schema != Schema)
            throw new ImmutableContentIntegrityException("The description snapshot proof has another schema.");
        var proof = await content.ReadJsonAsync<SystemDescriptionSnapshotSourceProof>(tenant.ToString(),reference,ct).ConfigureAwait(false);
        if (proof.Scope != scope || !Same(proof.Sources,sources) || proof.Facts.Count != 1)
            throw new ImmutableContentIntegrityException("The description snapshot proof differs from its exact scope and complete source set.");
        var claimed = proof.Facts[0];
        if (claimed.Fact.Stream.Realm != tenant.ToString())
            throw new ImmutableContentIntegrityException("The description source proof names another tenant.");
        DomainEvent? found = null;
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(claimed.Fact.Stream.Realm,
            claimed.Fact.Stream.Area,claimed.Fact.Stream.Resource),EventCursor.Start,ct).ConfigureAwait(false))
            if (record.Event.Metadata.EventId == claimed.Fact.EventId && record.Event.Metadata.AggregateVersion == claimed.Fact.AggregateVersion)
                found = record.Event;
        if (found is null)
            throw new ImmutableContentUnavailableException("The proven description snapshot source is not readable yet.");
        if (EventKind.Of(found) != claimed.EventKind || ContentDigest.Sha256(found,found.GetType()) != claimed.PayloadSha256)
            throw new ImmutableContentIntegrityException("The description snapshot proof differs from its authoritative native payload.");
        IReadOnlyList<SystemDescriptionSourceReference>? selected = null;
        switch (found)
        {
            case TypeIBaselineFrozen frozen when scope.Stage == "type_i":
                selected = Baseline(frozen.Baseline,tenant,program,scope);
                break;
            case TypeIBaselineAmended amended when scope.Stage == "type_i":
                selected = Baseline(amended.Baseline,tenant,program,scope);
                break;
            case ITypeIIPeriodStateFact period when scope.Stage == "type_ii" &&
                period.TenantId == tenant && period.Header.ProgramId == program && period.SubjectId == scope.TypeIIPeriodId &&
                period.Header.ExaminationId == scope.ExaminationId:
                var state = await content.ReadJsonAsync<TypeIIPeriodView>(tenant.ToString(),period.CurrentContent,ct).ConfigureAwait(false);
                if (period.CurrentContent.Schema != TypeIIPeriodContent.StateSchema || TypeIIPeriodContent.Header(state) != period.Header)
                    throw new ImmutableContentIntegrityException("The proven native period source differs from its verified immutable authority.");
                var close = state.CloseSnapshots.FirstOrDefault(item => item.CloseSnapshotId == scope.CloseSnapshotId);
                selected = close?.SourceReferences.Select(item => new SystemDescriptionSourceReference(item.SourceType,item.RecordId,
                    item.VersionId,item.Version,item.ContentSha256,"current")).ToArray();
                break;
        }
        if (selected is null || !Same(selected,sources))
            throw new ImmutableContentIntegrityException("The native source does not prove this exact description scope and source-version population.");
    }
    static IReadOnlyList<SystemDescriptionSourceReference>? Baseline(TypeIBaselineView baseline,Uuid tenant,Uuid program,SystemDescriptionScope scope) =>
        baseline.TenantId != tenant || baseline.ProgramId != program || baseline.ExaminationEngagementId != scope.ExaminationId ||
        baseline.TypeIBaselineId != scope.TypeIBaselineId ? null : baseline.Sources.Select(item => new SystemDescriptionSourceReference(
            item.Kind,item.RecordId,item.VersionId,item.Revision,item.ContentSha256,"current")).ToArray();
    static bool Same(IReadOnlyList<SystemDescriptionSourceReference> left,IReadOnlyList<SystemDescriptionSourceReference> right) =>
        left.Count == right.Count && left.OrderBy(item => item.Kind,StringComparer.Ordinal).ThenBy(item => item.RecordId.ToString(),StringComparer.Ordinal)
            .SequenceEqual(right.OrderBy(item => item.Kind,StringComparer.Ordinal).ThenBy(item => item.RecordId.ToString(),StringComparer.Ordinal));
}
''')
# The exact source proof is native authority alongside the current version ref; no foreign live object enters the owner.
p=R/(C+'ISystemDescriptionFact.cs');s=p.read_text().replace('    ImmutableContentRef CurrentVersionContent { get; }','    ImmutableContentRef CurrentVersionContent { get; }\n    ImmutableContentRef? SourceSnapshotContent { get; }');p.write_text(s)
for p in (R/C).glob('*.cs'):
 s=p.read_text()
 if ': DomainEvent, ISystemDescriptionFact;' in s:s=s.replace(': DomainEvent, ISystemDescriptionFact;',': DomainEvent, ISystemDescriptionFact\n{\n    public ImmutableContentRef? SourceSnapshotContent { get; init; }\n}\n');p.write_text(s)
p=R/(K+'FrozenSystemDescriptionMutation.cs');s=p.read_text().replace('    object Mutation,string Kind,bool Changed);','    object Mutation,string Kind,bool Changed)\n{\n    public ImmutableContentRef? SourceSnapshotContent { get; init; }\n}\n');p.write_text(s)
p=R/(K+'SystemDescriptionReadSnapshot.cs');s=p.read_text();s='using Bdgrz.Compliance.Features.Proofs;\n'+s;s=s.replace('    public SystemDescriptionView View','    public ImmutableContentRef? PreparedSourceSnapshotContent { get; set; }\n    public SystemDescriptionView View');p.write_text(s)
p=R/(K+'SystemDescriptionFactFactory.cs');s=p.read_text().replace('first,result,h,frozen.CurrentVersion,sequence,frozen.Changed ? 1 : 0,member),','first,result,h,frozen.CurrentVersion,sequence,frozen.Changed ? 1 : 0,member) { SourceSnapshotContent = frozen.SourceSnapshotContent },');p.write_text(s)
p=R/(K+'SystemDescription.cs');s=p.read_text().replace('    public NativeAcceptance Acceptance { get; }','    public ImmutableContentRef? SourceSnapshotContent { get; private set; }\n    public NativeAcceptance Acceptance { get; }').replace('        NativeSequence = fact.NativeSequence;','        NativeSequence = fact.NativeSequence;\n        SourceSnapshotContent = fact.SourceSnapshotContent;').replace('SystemDescriptionContent.Payload(fact) != prepared.Payload','SystemDescriptionContent.Payload(fact) != prepared.Payload || fact.SourceSnapshotContent != prepared.SourceSnapshotContent');p.write_text(s)
p=R/(K+'SystemDescriptionReader.cs');s=p.read_text().replace('            if (fact.ChangeCount == 1)\n                rules.Apply(mutation);','''            if (fact.SourceSnapshotContent is { } snapshotProof)
                await new SystemDescriptionSnapshotSources(events,content).VerifyAsync(owner.TenantId,programId,current.Scope,
                    current.Content.Sources,snapshotProof,ct).ConfigureAwait(false);
            if (fact.ChangeCount == 1)
                rules.Apply(mutation);''');p.write_text(s)
