from pathlib import Path
P=Path('/tmp/compliance-system-description-prepared');R=P/'work';T='test/Compliance.Tests/Features/SystemDescription/'
s=Path('test/Compliance.Tests/Features/AuditPackages/AuditPackageReadHttpTests.cs').read_text().replace('AuditPackages','SystemDescription').replace('AuditPackageReadHttpTests','SystemDescriptionHttpTests').replace('AuditPackage','SystemDescription').replace('audit-packages','system-descriptions').replace('audit-package','system-description').replace('audit_package_id','system_description_id').replace('package_id','description_id').replace('packageId','descriptionId').replace('package-reader','description-reader')
s=s.replace('GetProperty("description_id").GetString()','GetProperty("system_description_id").GetString()')
s=s.replace('ShouldUseCanonicalPackageRouteGivenMisleadingQueryIdentities','ShouldUseCanonicalDescriptionRouteGivenMisleadingQueryIdentities').replace('ShouldHidePackageGivenAnotherExistingProgramRoute','ShouldHideDescriptionGivenAnotherExistingProgramRoute').replace('ShouldDescribeOnlyCanonicalRouteIdentityGivenCustomPackageReadBinder','ShouldDescribeScopedReadsAndIdentifiedWritesGivenDescriptionHttpContract')
s=s.replace('''        using var response = await fixture.GetAsync(string.Empty);''','''        using var response = await fixture.GetAsync($"/{descriptionId}/versions?limit=1");''',1)
s=s.replace('''        Assert.Equal(descriptionId.ToString(), summary.GetProperty("system_description_id").GetString());
        Assert.Equal("Audit package", summary.GetProperty("name").GetString());
        Assert.Equal("draft", summary.GetProperty("status").GetString());''','''        Assert.Equal(descriptionId.ToString(),summary.GetProperty("system_description_id").GetString());
        Assert.Equal("HTTP narrative",summary.GetProperty("content").GetProperty("title").GetString());
        Assert.Equal("draft",summary.GetProperty("status").GetString());''')
s=s.replace('''        using var list = await fixture.GetAsync(string.Empty);''','''        using var list = await fixture.GetAsync($"/{descriptionId}/versions");
        using var preview = await fixture.GetAsync($"/{descriptionId}/impact-preview");''',1).replace('''        Assert.Equal(HttpStatusCode.Forbidden, list.StatusCode);''','''        Assert.Equal(HttpStatusCode.Forbidden,list.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden,preview.StatusCode);''',1)
s=s.replace('''        Assert.True(route.TryGetProperty("put", out _));''','''        Assert.False(route.TryGetProperty("put",out _));
        Assert.True(paths.GetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/system-descriptions/{description_id}/create-system-description-draft").TryGetProperty("put",out _));
        Assert.True(paths.GetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/system-descriptions/{description_id}/review-system-description/{command_id}").TryGetProperty("put",out _));''')
s=s.replace('''Assert.False(paths.TryGetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/system-descriptions/{system_description_id}", out _));''','''Assert.False(paths.TryGetProperty("/api/v1/tenants/{tenant_id}/programs/{program_id}/system-descriptions/{system_description_id}",out _));''')
s=s.replace('"package_id", "program_id", "tenant_id"','"description_id", "program_id", "tenant_id"')
# Existing package response id string is now the scope alias; explicit query aliases cannot override the canonical route.
s=s.replace('$"/{descriptionId}?system_description_id=', '$"/{descriptionId}?system_description_id=')
# Read fixtures publish a true native description source; no projection placeholders or source-permit fabrication.
a=s.index('            var package = new SystemDescriptionRules(');b=s.index('            return package.Id;',a)+len('            return package.Id;')
s=s[:a]+'''            var description = new SystemDescriptionRules(Tenant,Program,Uuid.CreateVersion4());
            Assert.Null(description.Create(Uuid.CreateVersion4(),new SystemDescriptionScope("type_i",Uuid.CreateVersion4(),Uuid.CreateVersion4(),null,null),
                SystemDescriptionNativeFixture.Body("HTTP narrative"),Member,"Description author",Now));
            await DescriptionSeeds.WriteAsync(writer,content,description);
            return description.Id;'''+s[b:]
s=s.replace('new RecordingPermissionAuthorizer(allowed)','Permissions').replace('        public Fixture(bool allowed = true)\n        {','        public Fixture(bool allowed = true)\n        {\n            Permissions.Allowed = allowed;')
s=s.replace('        public Uuid Tenant { get; }','        public MutablePermissionAuthorizer Permissions { get; } = new();\n        public Uuid Tenant { get; }',1)
# Login is shared by direct read seed and real HTTP creation tests.
a=s.index('            using var loginBody =');b=s.index('            await using var scope =',a)
login=s[a:b]
s=s[:a]+'            await LoginAndProgramAsync();\n'+s[b:]
i=s.index('        public async Task SeedProgramAsync(');s=s[:i]+'''        public async Task LoginAndProgramAsync()
        {
'''+login+'''        }
        public async Task<CreateSystemDescriptionDraft> PrepareCreationAsync()
        {
            await LoginAndProgramAsync();
            await using var scope = _factory.Services.CreateAsyncScope();
            var examination = Uuid.CreateVersion4();
            var boundary = Uuid.CreateVersion4();
            var engagement = new Bdgrz.Compliance.Features.Examinations.ExaminationEngagement(Tenant,Program,examination);
            Assert.Null(engagement.Create(new Bdgrz.Compliance.Features.Examinations.ExaminationEngagementContent("type_i","Audit LLP",
                new DateOnly(2026,10,18),null,["security"],boundary,[]),Member,"Examiner",Now));
            var preview = Bdgrz.Compliance.Tests.Features.Examinations.TypeIBaselinePreviewTestFactory.Create(Tenant,Program,examination,
                [new Bdgrz.Compliance.Features.Examinations.TypeIBaselineSourceReference("approved_boundary",boundary,Uuid.CreateVersion4(),1,new string('a',64))]);
            Assert.Null(engagement.FreezeBaseline(1,Uuid.CreateVersion4(),preview,"Frozen complete source scope",Member,"Examiner",Now));
            await scope.ServiceProvider.GetRequiredService<IAggregateWriter>().SaveAsync(engagement,new RequestDispatchContext(RequestActor.System));
            return new CreateSystemDescriptionDraft(Tenant,Program,Uuid.CreateVersion4(),examination,"HTTP created narrative",SystemDescriptionNativeFixture.Body().Sections);
        }
        public async Task<HttpResponseMessage> PutAsync(CreateSystemDescriptionDraft request)
        {
            using var body = new StringContent(JsonSerializer.Serialize(request,Bdgrz.Compliance.ComplianceCoreJsonContext.Default.CreateSystemDescriptionDraft),Encoding.UTF8,"application/json");
            return await _client.PutAsync($"/api/v1/tenants/{Tenant}/programs/{Program}/system-descriptions/{request.DescriptionId}/create-system-description-draft",body);
        }
        public async Task<HttpResponseMessage> ReviseAsync(ReviseSystemDescriptionDraft request)
        {
            using var body = new StringContent(JsonSerializer.Serialize(request,Bdgrz.Compliance.ComplianceCoreJsonContext.Default.ReviseSystemDescriptionDraft),Encoding.UTF8,"application/json");
            return await _client.PutAsync($"/api/v1/tenants/{Tenant}/programs/{Program}/system-descriptions/{request.DescriptionId}/revise-system-description-draft/{request.CommandId}",body);
        }
        public async Task<HttpResponseMessage> InvalidRevisionAsync(Uuid id,string suffix,string json)
        {
            using var body = new StringContent(json,Encoding.UTF8,"application/json");
            return await _client.PutAsync($"/api/v1/tenants/{Tenant}/programs/{Program}/system-descriptions/{id}/revise-system-description-draft/{suffix}",body);
        }
        public async Task<int> CountAsync(Uuid description)
        {
            var count = 0;
            await foreach (var record in _events.ReadAsync(EventStreamPattern.ForPattern(Tenant.ToString(),Bdgrz.Compliance.Features.SystemDescription.SystemDescription.Area,
                description.ToString()),EventCursor.Start,CancellationToken.None))
                if (!record.Event.Metadata.IsAudit)count++;
            return count;
        }

'''+s[i:]
i=s.index('    sealed class ActiveTenant');s=s[:i]+'''    sealed class MutablePermissionAuthorizer : IPermissionAuthorizer
    {
        public bool Allowed { get; set; } = true;
        public ValueTask<bool> IsAllowedAsync(Uuid tenantId,Uuid userId,Uuid memberId,string permission,CancellationToken ct = default) => ValueTask.FromResult(Allowed);
    }

'''+s[i:]
i=s.index('    sealed class Fixture');s=s[:i]+'''    [Fact]
    public async Task ShouldUseNativeUnit200AndCurrentAuthorizationGivenExactCreationAndRevisionRetries()
    {
        // Arrange
        await using var fixture = new Fixture();
        var request = await fixture.PrepareCreationAsync();

        // Act
        using var created = await fixture.PutAsync(request);
        using var replay = await fixture.PutAsync(request);
        var revision = new ReviseSystemDescriptionDraft(Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,request.DescriptionId,1,
            "Corrected HTTP title",request.Sections,"Correct narrative title");
        using var revised = await fixture.ReviseAsync(revision);
        fixture.Permissions.Allowed = false;
        using var denied = await fixture.ReviseAsync(revision);
        fixture.Permissions.Allowed = true;
        using var original = await fixture.PutAsync(request);

        // Assert
        Assert.Equal(HttpStatusCode.OK,created.StatusCode);Assert.Equal("{}",await created.Content.ReadAsStringAsync());
        Assert.Equal(HttpStatusCode.OK,replay.StatusCode);Assert.Equal(HttpStatusCode.OK,revised.StatusCode);
        Assert.Equal(HttpStatusCode.Forbidden,denied.StatusCode);Assert.Equal(HttpStatusCode.OK,original.StatusCode);
        Assert.Equal("{}",await original.Content.ReadAsStringAsync());Assert.Equal(2,await fixture.CountAsync(request.DescriptionId));
    }

    [Fact]
    public async Task ShouldRejectMalformedAndMissingRequiredLogicalIdentityGivenDescriptionRevisionRoute()
    {
        // Arrange
        await using var fixture = new Fixture();
        var id = await fixture.SeedAsync();

        // Act
        using var malformed = await fixture.InvalidRevisionAsync(id,"not-a-uuid","{}");
        using var missingBody = await fixture.InvalidRevisionAsync(id,Uuid.CreateVersion4().ToString(),"{}");
        using var noId = await fixture.GetAsync("/not-a-uuid");

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest,malformed.StatusCode);Assert.Equal(HttpStatusCode.BadRequest,missingBody.StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest,noId.StatusCode);Assert.Equal(1,await fixture.CountAsync(id));
    }

'''+s[i:]
(R/(T+'SystemDescriptionHttpTests.cs')).write_text(s)
