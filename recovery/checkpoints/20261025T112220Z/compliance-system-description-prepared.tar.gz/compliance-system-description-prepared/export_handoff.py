from pathlib import Path
import hashlib,json,difflib,shutil,subprocess,re
P=Path('/tmp/compliance-system-description-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
def files(root):return {str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()}
external={x['path']:x for x in json.loads((P/'external-baselines.json').read_text())}
allEntries=[];groups={'implementation':[],'tests':[],'shared-wiring':[]}
for beforeDir,afterDir,shared in [('base','work',False),('shared-base','shared-work',True)]:
 before=files(P/beforeDir);after=files(P/afterDir)
 for path in sorted(before.keys()|after.keys()):
  a=before[path].read_bytes() if path in before else None;b=after[path].read_bytes() if path in after else None
  if a==b:continue
  group='shared-wiring' if shared else 'tests' if path.startswith('test/') else 'implementation'
  patch=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True) if a else [],b.decode().splitlines(keepends=True) if b else [],fromfile='a/'+path if a is not None else '/dev/null',tofile='b/'+path if b is not None else '/dev/null'))
  groups[group].append(patch)
  origin=external.get(path,{}).get('baselineSource',str(repo/path) if a is not None else None)
  allEntries.append({'path':path,'group':group,'beforeSha256':sha(a) if a is not None else None,'afterSha256':sha(b) if b is not None else None,'beforeBytes':len(a) if a is not None else None,'afterBytes':len(b) if b is not None else None,'baselineSource':origin,'change':'delete' if b is None else 'create' if a is None else 'modify'})
patches=[]
for group,pieces in groups.items():
 path=P/(group+'.patch');data=''.join(pieces).encode();path.write_bytes(data);patches.append({'file':path.name,'sha256':sha(data),'bytes':len(data),'paths':sum(x['group']==group for x in allEntries)})
patches.append({'file':'behavioral-red.patch','sha256':sha((P/'behavioral-red.patch').read_bytes()),'bytes':(P/'behavioral-red.patch').stat().st_size,'paths':2})
(P/'manifest.json').write_text(json.dumps({'qualification':'Offline preparation; parent owns compile/runtime/Jev/integration.','patches':patches,'paths':allEntries},indent=2)+'\n')
# Reconstruct by applying real unified patches, including selected event deletion, to copies of exact saved originals.
recon=P/'reconstruction';shutil.rmtree(recon,ignore_errors=True);recon.mkdir()
for folder in ['base','shared-base']:
 for path,file in files(P/folder).items():
  target=recon/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,target)
logs=[]
for group in groups:
 result=subprocess.run(['patch','-p1','-E','--batch','-i',str(P/(group+'.patch'))],cwd=recon,text=True,capture_output=True);logs.append({'patch':group,'code':result.returncode,'output':result.stdout+result.stderr});assert result.returncode==0,logs[-1]
checks=[]
for x in allEntries:
 path=recon/x['path'];actual=sha(path.read_bytes()) if path.exists() else None;checks.append({'path':x['path'],'matches':actual==x['afterSha256']});assert checks[-1]['matches'],checks[-1]
redRoot=P/'red-reconstruction';shutil.rmtree(redRoot,ignore_errors=True);redRoot.mkdir()
for x in ['test/Compliance.Tests/Features/SystemDescription/SystemDescriptionTests.cs']:
 target=redRoot/x;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/'base'/x,target)
result=subprocess.run(['patch','-p1','-E','--batch','-i',str(P/'behavioral-red.patch')],cwd=redRoot,text=True,capture_output=True);assert result.returncode==0,result.stdout+result.stderr
for artifact,name in [('red-source-tests.cs','SystemDescriptionTests.cs'),('red-export-tests.cs','SystemDescriptionExportBoundaryTests.cs')]:assert (redRoot/'test/Compliance.Tests/Features/SystemDescription'/name).read_bytes()==(P/artifact).read_bytes()
(P/'reconstruction.json').write_text(json.dumps({'patches':logs,'exactFinalPathsVerified':len(checks),'checks':checks,'standaloneBehavioralRedExact':True},indent=2)+'\n')
static=json.loads((P/'static-checks.json').read_text());handoff={'status':'frozen-offline-parent-validation-pending','readme':'README.md','manifest':'manifest.json','reconstruction':'reconstruction.json','staticChecks':'static-checks.json','patches':patches,'paths':len(allEntries),'existingAcceptanceNames':static['existingAcceptanceNames'],'newAcceptanceNames':len(static['newAcceptanceNames']),'syntaxErrors':static['syntaxErrors'],'constructorErrors':static['explicitConstructorArityErrors'],'removedAcceptanceNames':static['removedAcceptanceNames'],'runtimeEvidence':'none; parent owns old-code RED, strict build, focused/unit/HTTP, format/extraction, Jev and integration','focusedFilter':'FullyQualifiedName~SystemDescription|FullyQualifiedName~ComplianceImpactReactionHandlerTests|FullyQualifiedName~ComplianceIncidentOperationTests|FullyQualifiedName~RecordManagementAssertionHandlerTests|FullyQualifiedName~StartTypeIIObservationPeriodHandlerTests|FullyQualifiedName~ProposeTypeIIOperatingPlanHandlerTests|FullyQualifiedName~ObservationPeriodReadHandlerTests|FullyQualifiedName~TypeIIPeriodCommandHandlerTests','webFilter':'FullyQualifiedName~SystemDescriptionHttpTests','qualificationDocuments':['approval-qualification.md','README.md','external-handoff.json'],'sharedDeltas':'shared-wiring-deltas.json'}
(P/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps(handoff,indent=2))
