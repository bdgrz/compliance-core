from pathlib import Path
r=Path('/tmp/compliance-system-description-prepared/work');test=r/'test/Compliance.Tests'
for rel in ['Features/Changes/ComplianceImpactReactionHandlerTests.cs','Features/Incidents/ComplianceIncidentOperationTests.cs','Features/Examinations/RecordManagementAssertionHandlerTests.cs','Features/Operations/StartTypeIIObservationPeriodHandlerTests.cs','Features/Operations/ProposeTypeIIOperatingPlanHandlerTests.cs']:
 p=test/rel;s=p.read_text();s='using Bdgrz.Compliance.Tests.Features.SystemDescription;\n'+s
 s=s.replace('using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;','using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescriptionRules;')
 if rel.startswith('Features/Changes/'):
  s=s.replace('scenario.ChangeOperations, scenario.Reader)','scenario.ChangeOperations, scenario.Descriptions)').replace('scenario.Operations, scenario.Reader, scenario.Content,','scenario.Operations, scenario.Descriptions, scenario.Content,')
  s=s.replace('            ChangeOperations = new SignificantChangeOperations(Operations,Changes,Content,new FixedTimeProvider(Now));','            ChangeOperations = new SignificantChangeOperations(Operations,Changes,Content,new FixedTimeProvider(Now));\n            Descriptions = new SystemDescriptionReader(Reader, events, Content);')
  s=s.replace('        public SignificantChangeReader Changes { get; }','        public SystemDescriptionReader Descriptions { get; }\n        public ValueTask<Bdgrz.Compliance.Features.SystemDescription.SystemDescription> SaveAsync(SystemDescriptionRules rules) => DescriptionSeeds.WriteAsync(Writer, Content, rules);\n        public SignificantChangeReader Changes { get; }')
 elif rel.startswith('Features/Incidents/'):
  s=s.replace('host.Operations, host.Reader,','host.Operations, host.Descriptions,')
  s=s.replace('        public IAggregateReader Reader { get; }','        public IAggregateReader Reader { get; }\n        public SystemDescriptionReader Descriptions => new(Reader, _events, Content);')
  s=s.replace('await _writer.SaveAsync(description, new RequestDispatchContext(RequestActor.System));','await DescriptionSeeds.WriteAsync(_writer, Content, description);')
 elif rel.startswith('Features/Examinations/'):
  s=s.replace('fixture.Periods, fixture.Clock);','fixture.Periods, fixture.Clock, fixture.Descriptions);').replace('new(Executor, Reader, Packages, Periods, Clock);','new(Executor, Reader, Packages, Periods, Clock, Descriptions);')
  s=s.replace('        public TypeIIPeriodReader Periods => new(Reader, PeriodEvents, ContentStore);','        public TypeIIPeriodReader Periods => new(Reader, PeriodEvents, ContentStore);\n        public SystemDescriptionReader Descriptions => new(Reader, PeriodEvents, ContentStore);')
  s=s.replace('await Writer.SaveAsync(description, new RequestDispatchContext(RequestActor.System));','await DescriptionSeeds.WriteAsync(Writer, ContentStore, description);')
 elif rel.endswith('StartTypeIIObservationPeriodHandlerTests.cs'):
  s=s.replace('await Writer.SaveAsync(description, new RequestDispatchContext(RequestActor.System));','await DescriptionSeeds.WriteAsync(Writer, Host.Content, description);')
 else:
  s=s.replace('scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()), Clock);','scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()), Clock,\n                new SystemDescriptionReader(Reader, events, scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()));')
  s=s.replace('await Writer.SaveAsync(description, new RequestDispatchContext(RequestActor.System));','await DescriptionSeeds.WriteAsync(Writer, scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), description);')
 p.write_text(s)
p=test/'Testing/TypeIIRangeHost.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SystemDescription;\n'+s;s=s.replace('        clock);\n\n    public AmendTypeIIObservationPeriodHandler','        clock, new SystemDescriptionReader(Reader, Events, Content));\n\n    public AmendTypeIIObservationPeriodHandler');p.write_text(s)
p=r/'src/Compliance.Core/Features/Operations/TypeIIPeriodCloseMaterialReader.cs';s=p.read_text().replace('IImmutableContentStore content)','IImmutableContentStore content, SystemDescriptionReader descriptions)',1)
s=s.replace('        foreach (var record in records)\n        {','        var descriptionCuts = new Dictionary<Uuid, SystemDescriptionReadSnapshot>();\n        foreach (var record in records)\n        {',1)
a=s.index('                if (record.Payload.TryGetProperty("version", out var versionJson))');b=s.index('                continue;',a)
s=s[:a]+'''                var descriptionId = Uuid.Parse(record.Fact.Stream.Resource, CultureInfo.InvariantCulture);
                if (!descriptionCuts.TryGetValue(descriptionId, out var description))
                {
                    description = await descriptions.ReadAsync(period.TenantId, period.ProgramId, descriptionId, ct).ConfigureAwait(false);
                    descriptionCuts.Add(descriptionId, description);
                }
                var actual = description.Facts.SingleOrDefault(value => NativeFactReference.Of(description.Stream, value) == record.Fact);
                if (actual is not ISystemDescriptionFact fact)
                    throw new ImmutableContentUnavailableException("The exact native description material source is not visible yet.");
                if (TypeIIPeriodCloseHistory.Capture(description.Stream, actual).PayloadSha256 != record.PayloadSha256 ||
                    description.FindVersion(fact.Header.CurrentVersionId) is not { } version ||
                    version.TenantId != period.TenantId || version.ProgramId != period.ProgramId ||
                    version.SystemDescriptionId != descriptionId)
                    throw new ImmutableContentIntegrityException("The system description differs from its exact native material source.");
                if (version.Scope.TypeIIPeriodId == period.PeriodId && version.Scope.ExaminationId == period.ExaminationId &&
                    version.Scope.CloseSnapshotId == prior.CloseSnapshotId)
                {
                    affected.Add(version.SystemDescriptionId);
                    affected.Add(version.SystemDescriptionVersionId);
                }
'''+s[b:];p.write_text(s)
p=test/'Features/Operations/TypeIIPeriodCommandHandlerTests.NativeOwners.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SystemDescription;\n'+s;s=s.replace('new TypeIIPeriodCloseMaterialReader(fixture.Events, fixture.Host.Content)','new TypeIIPeriodCloseMaterialReader(fixture.Events, fixture.Host.Content, new SystemDescriptionReader(fixture.Reader, fixture.Events, fixture.Host.Content))');p.write_text(s)
p=test/'Features/Operations/ObservationPeriodReadHandlerTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SystemDescription;\n'+s;s=s.replace('new TypeIIPeriodCloseMaterialReader(Events, Content)','new TypeIIPeriodCloseMaterialReader(Events, Content, new SystemDescriptionReader(Reader, Events, Content))');p.write_text(s)
