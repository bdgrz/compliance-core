from pathlib import Path
R=Path('/tmp/compliance-system-description-prepared/work');K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(K+'SystemDescriptionReadConsistency.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Authoritative scoped native/physical source fence; no missing projection is mistaken for absence.</summary>
public sealed class SystemDescriptionReadConsistency(IAggregateReader reader)
{
    public async ValueTask<Result> ConfirmAsync(SystemDescriptionReadSnapshot snapshot,CancellationToken ct)
    {
        var current = await reader.HydrateAsync(new SystemDescription(snapshot.TenantId,snapshot.ProgramId,snapshot.Id),ct).ConfigureAwait(false);
        return current.NativeSequence == snapshot.Owner.NativeSequence && current.CommittedStreamPosition == snapshot.Owner.CommittedStreamPosition
            ? Result.Success : Result.Failure(new RequestError(RequestErrorKind.Conflict,"The description source changed while its response was composed. Retry the query.",true));
    }
}
''')
put(K+'SystemDescriptionVersionCursor.cs','''using System.Globalization;
using System.Text;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

static class SystemDescriptionVersionCursor
{
    public static string Wrap(Uuid tenant,Uuid program,Uuid description,long sequence,int offset) => Convert.ToBase64String(
        Encoding.UTF8.GetBytes($"v1\\n{tenant}\\n{program}\\n{description}\\n{sequence.ToString(CultureInfo.InvariantCulture)}\\n{offset.ToString(CultureInfo.InvariantCulture)}"));
    public static bool TryRead(string? cursor,Uuid tenant,Uuid program,Uuid description,out long? sequence,out int offset)
    {
        sequence = null;offset = 0;
        if (cursor is null)
            return true;
        if (cursor.Length > 2048)
            return false;
        try
        {
            var values = new UTF8Encoding(false,true).GetString(Convert.FromBase64String(cursor)).Split('\\n');
            if (values.Length != 6 || values[0] != "v1" || values[1] != tenant.ToString() || values[2] != program.ToString() || values[3] != description.ToString() ||
                !long.TryParse(values[4],NumberStyles.None,CultureInfo.InvariantCulture,out var cut) || cut < 1 ||
                !int.TryParse(values[5],NumberStyles.None,CultureInfo.InvariantCulture,out offset) || offset < 1)
                return false;
            sequence = cut;return true;
        }
        catch (FormatException) { return false; }
        catch (DecoderFallbackException) { return false; }
    }
}
''')
put(K+'GetSystemDescriptionHandler.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class GetSystemDescriptionHandler(SystemDescriptionReader descriptions,SystemDescriptionReadConsistency consistency)
    : IRequestHandler<GetSystemDescription,SystemDescriptionView>
{
    public async ValueTask<Result<SystemDescriptionView>> HandleAsync(IRequestContext<GetSystemDescription> context,CancellationToken ct)
    {
        var r = context.Request;
        try
        {
            var read = await descriptions.ReadAsync(r.TenantId,r.ProgramId,r.SystemDescriptionId,ct).ConfigureAwait(false);
            if (read.CurrentVersion is null)
                return Result<SystemDescriptionView>.Failure(new RequestError(RequestErrorKind.NotFound,"The system description was not found."));
            var confirmed = await consistency.ConfirmAsync(read,ct).ConfigureAwait(false);
            return confirmed.IsSuccess ? Result<SystemDescriptionView>.Success(read.View) : Result<SystemDescriptionView>.Failure(confirmed.Error!);
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<SystemDescriptionView>.Failure(SystemDescriptionReadFailure.Of(failure));
        }
    }
}
''')
put(K+'ListSystemDescriptionVersionsHandler.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class ListSystemDescriptionVersionsHandler(SystemDescriptionReader descriptions,SystemDescriptionReadConsistency consistency)
    : IRequestHandler<ListSystemDescriptionVersions,Page<SystemDescriptionVersionView>>
{
    public async ValueTask<Result<Page<SystemDescriptionVersionView>>> HandleAsync(IRequestContext<ListSystemDescriptionVersions> context,CancellationToken ct)
    {
        var r = context.Request;
        if (r.Limit is < 1 or > 200 || !SystemDescriptionVersionCursor.TryRead(r.Cursor,r.TenantId,r.ProgramId,r.SystemDescriptionId,out var cut,out var offset))
            return Fail(RequestErrorKind.Validation,"The description version limit or scoped cursor is invalid.");
        try
        {
            var read = await descriptions.ReadAsync(r.TenantId,r.ProgramId,r.SystemDescriptionId,ct).ConfigureAwait(false);
            if (read.CurrentVersion is null)
                return Fail(RequestErrorKind.NotFound,"The system description was not found.");
            if (cut is { } expected && expected != read.Owner.NativeSequence)
                return Fail(RequestErrorKind.Conflict,"The description source changed after this version page was started. Restart the list.",true);
            if (offset > read.View.Versions.Count)
                return Fail(RequestErrorKind.Validation,"The description version cursor is outside its exact history.");
            var values = read.View.Versions.Skip(offset).Take(r.Limit ?? 50).ToArray();
            var next = offset+values.Length < read.View.Versions.Count ? SystemDescriptionVersionCursor.Wrap(r.TenantId,r.ProgramId,
                r.SystemDescriptionId,read.Owner.NativeSequence,offset+values.Length) : null;
            var confirmed = await consistency.ConfirmAsync(read,ct).ConfigureAwait(false);
            return confirmed.IsSuccess ? Result<Page<SystemDescriptionVersionView>>.Success(new(values,next)) : Result<Page<SystemDescriptionVersionView>>.Failure(confirmed.Error!);
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<Page<SystemDescriptionVersionView>>.Failure(SystemDescriptionReadFailure.Of(failure));
        }
    }
    static Result<Page<SystemDescriptionVersionView>> Fail(RequestErrorKind kind,string message,bool transient = false) =>
        Result<Page<SystemDescriptionVersionView>>.Failure(new RequestError(kind,message,transient));
}
''')
put(K+'PreviewSystemDescriptionImpactHandler.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class PreviewSystemDescriptionImpactHandler(SystemDescriptionReader descriptions,SystemDescriptionReadConsistency consistency,TimeProvider clock)
    : IRequestHandler<PreviewSystemDescriptionImpact,SystemDescriptionImpactPreview>
{
    public async ValueTask<Result<SystemDescriptionImpactPreview>> HandleAsync(IRequestContext<PreviewSystemDescriptionImpact> context,CancellationToken ct)
    {
        var r = context.Request;
        try
        {
            var read = await descriptions.ReadAsync(r.TenantId,r.ProgramId,r.SystemDescriptionId,ct).ConfigureAwait(false);
            if (read.CurrentVersion is not { } current)
                return Result<SystemDescriptionImpactPreview>.Failure(new RequestError(RequestErrorKind.NotFound,"The system description was not found."));
            var affected = current.Content.Sources.Select(item => item.RecordId).Concat(current.Content.PeriodChanges.Select(item => item.ChangeId))
                .Concat(current.Content.SignificantChangeIds).Concat(read.View.Bindings.Select(item => item.SnapshotId))
                .Concat(new[] { current.Scope.TypeIBaselineId ?? Uuid.Empty,current.Scope.CloseSnapshotId ?? Uuid.Empty })
                .Where(item => item != Uuid.Empty).Distinct().OrderBy(item => item.ToString(),StringComparer.Ordinal).ToArray();
            var result = new SystemDescriptionImpactPreview(r.TenantId,r.ProgramId,
                $"Version {current.Version} references {current.Content.Sources.Count} exact source versions and {current.Content.PeriodChanges.Count} period changes.",affected,clock.GetUtcNow());
            var confirmed = await consistency.ConfirmAsync(read,ct).ConfigureAwait(false);
            return confirmed.IsSuccess ? Result<SystemDescriptionImpactPreview>.Success(result) : Result<SystemDescriptionImpactPreview>.Failure(confirmed.Error!);
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<SystemDescriptionImpactPreview>.Failure(SystemDescriptionReadFailure.Of(failure));
        }
    }
}
''')
