from pathlib import Path
R=Path('/tmp/compliance-system-description-prepared/work');K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(K+'SystemDescriptionResolvedSources.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed record SystemDescriptionResolvedSources(SystemDescriptionScope Scope,
    IReadOnlyList<SystemDescriptionSourceReference> Sources,ImmutableContentRef Proof);
''')
put(K+'SystemDescriptionSourceResolver.cs','''using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Features.Operations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Resolves one complete exact frozen snapshot population inside the accepting operation's preparation.</summary>
public sealed class SystemDescriptionSourceResolver(IAggregateReader reader,TypeIIPeriodReader periods,SystemDescriptionSnapshotSources proofs)
{
    public async ValueTask<Result<SystemDescriptionResolvedSources>> ResolveAsync(Uuid tenant,Uuid program,Uuid examination,
        SystemDescriptionScope? selected,CancellationToken ct)
    {
        if (selected is null || selected.Stage == "type_i")
        {
            var engagement = await reader.HydrateAsync(new ExaminationEngagement(tenant,program,examination),ct).ConfigureAwait(false);
            var baseline = engagement.Baseline;
            if (engagement.Current is not { Status: "baseline_frozen" } || baseline is null || baseline.Status is not ("frozen" or "amended") ||
                baseline.TenantId != tenant || baseline.ProgramId != program || baseline.ExaminationEngagementId != examination ||
                selected is not null && baseline.TypeIBaselineId != selected.TypeIBaselineId)
                return Fail("The description requires the examination's current exact frozen Type I baseline.");
            var scope = selected ?? new SystemDescriptionScope("type_i",examination,baseline.TypeIBaselineId,null,null);
            var sources = baseline.Sources.Select(item => new SystemDescriptionSourceReference(item.Kind,item.RecordId,item.VersionId,
                item.Revision,item.ContentSha256,"current")).ToArray();
            var proof = await proofs.CaptureAsync(tenant,program,scope,sources,engagement.Stream,value => value switch
            {
                TypeIBaselineFrozen item => item.Baseline == baseline,
                TypeIBaselineAmended item => item.Baseline == baseline,
                _ => false,
            },ct).ConfigureAwait(false);
            return Result<SystemDescriptionResolvedSources>.Success(new(scope,sources,proof));
        }
        if (selected.Stage != "type_ii" || selected.TypeIIPeriodId is not { } periodId || selected.TypeIBaselineId is not { } baselineId ||
            selected.CloseSnapshotId is not { } closeId)
            return Fail("The description requires an exact Type I baseline or Type II frozen close scope.");
        var period = await periods.ReadAsync(tenant,program,periodId,ct).ConfigureAwait(false);
        if (period.View is not { Status: "closed" } current || current.ExaminationId != examination ||
            current.CloseSnapshots.Count == 0 || current.CloseSnapshots[^1].CloseSnapshotId != closeId)
            return Fail("The description must bind the current exact frozen Type II close snapshot.");
        var plan = await reader.HydrateAsync(new TypeIIPlan(tenant,program,current.TypeIIPlanId),ct).ConfigureAwait(false);
        if (plan.Current is not { Status: "approved",Current: { } version } state || state.CurrentVersionNumber != current.TypeIIPlanVersion ||
            version.Content.ExaminationId != examination || version.Content.TypeIBaselineId != baselineId)
            return Fail("The description's Type II close is not backed by its exact approved plan and Type I baseline.");
        var selectedSources = current.CloseSnapshots[^1].SourceReferences.Select(item => new SystemDescriptionSourceReference(item.SourceType,
            item.RecordId,item.VersionId,item.Version,item.ContentSha256,"current")).ToArray();
        var reference = await proofs.CaptureAsync(tenant,program,selected,selectedSources,period.Stream,value => value is ITypeIIPeriodStateFact fact &&
            value is ObservationPeriodCloseFrozen or TypeIIPeriodCloseAmended && fact.Header.LatestCloseSnapshotId == closeId,ct,
            (plan.Stream,value => value is TypeIIPlanApproved approved && approved.State.CurrentVersionNumber == current.TypeIIPlanVersion &&
                approved.State.Current?.ContentSha256 == current.TypeIIPlanContentSha256)).ConfigureAwait(false);
        return Result<SystemDescriptionResolvedSources>.Success(new(selected,selectedSources,reference));
    }
    static Result<SystemDescriptionResolvedSources> Fail(string message) => Result<SystemDescriptionResolvedSources>.Failure(new RequestError(RequestErrorKind.Conflict,message));
}
''')
put(K+'CreateSystemDescriptionDraftHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class CreateSystemDescriptionDraftHandler(SystemDescriptionOperations operations,SystemDescriptionSourceResolver sources)
    : IRequestHandler<CreateSystemDescriptionDraft>
{
    public ValueTask<Result> HandleAsync(IRequestContext<CreateSystemDescriptionDraft> context,CancellationToken ct)
    {
        var request = context.Request;
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.DescriptionId,request.DescriptionId,
            nameof(CreateSystemDescriptionDraft),null,async (snapshot,operation,token) =>
            {
                var resolved = await sources.ResolveAsync(request.TenantId,request.ProgramId,request.ExaminationId,null,token).ConfigureAwait(false);
                if (!resolved.IsSuccess)
                    return Result.Failure(resolved.Error!);
                var exact = resolved.Value;
                snapshot.PreparedSourceSnapshotContent = exact.Proof;
                Uuid.TryParse(operation.Actor.Id,out var member);
                return SystemDescriptionOperations.Outcome(snapshot.Rules.Create(Uuid.CreateVersion5(request.DescriptionId,"initial-version"),
                    exact.Scope,new SystemDescriptionDraftContent(request.Title,request.Sections,exact.Sources,[],[]),member,
                    operation.Actor.Display,operation.AcceptedAt));
            },null,ct);
    }
}
''')
put(K+'BindSystemDescriptionSourcesHandler.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class BindSystemDescriptionSourcesHandler(SystemDescriptionOperations operations,SystemDescriptionSourceResolver sources)
    : IRequestHandler<BindSystemDescriptionSources>
{
    public ValueTask<Result> HandleAsync(IRequestContext<BindSystemDescriptionSources> context,CancellationToken ct)
    {
        var request = context.Request;
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.DescriptionId,request.CommandId,
            nameof(BindSystemDescriptionSources),request.ExpectedRevision,async (snapshot,operation,token) =>
            {
                if (request.SourceVersionIds is null || request.SourceVersionIds.Count == 0 || request.SourceVersionIds.Any(id => id == Uuid.Empty) ||
                    request.SourceVersionIds.Distinct().Count() != request.SourceVersionIds.Count)
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict,"A source refresh requires a nonempty unique source-version population."));
                var current = snapshot.CurrentVersion!;
                var resolved = await sources.ResolveAsync(request.TenantId,request.ProgramId,current.Scope.ExaminationId,current.Scope,token).ConfigureAwait(false);
                if (!resolved.IsSuccess)
                    return Result.Failure(resolved.Error!);
                var exact = resolved.Value;
                var requested = request.SourceVersionIds.ToHashSet();
                if (exact.Sources.Count != requested.Count || !requested.SetEquals(exact.Sources.Select(item => item.VersionId)))
                    return Result.Failure(new RequestError(RequestErrorKind.Conflict,"Every complete frozen source version must resolve exactly once."));
                snapshot.PreparedSourceSnapshotContent = exact.Proof;
                Uuid.TryParse(operation.Actor.Id,out var member);
                return SystemDescriptionOperations.Outcome(snapshot.Rules.BindSources(request.ExpectedRevision,request.CommandId,
                    exact.Sources,member,operation.Actor.Display,operation.AcceptedAt));
            },null,ct);
    }
}
''')
# Extend source capture to freeze the exact approved plan fact needed by a Type II close relationship.
p=R/(K+'SystemDescriptionSnapshotSources.cs');s=p.read_text().replace('''        CancellationToken ct)
    {
        DomainEvent? selected''','''        CancellationToken ct,(EventStreamAddress Stream,Func<DomainEvent,bool> Select)? additional = null)
    {
        DomainEvent? selected''',1)
s=s.replace('''        var proof = new SystemDescriptionSnapshotSourceProof(scope,sources,[new(NativeFactReference.Of(source,selected),
            EventKind.Of(selected),ContentDigest.Sha256(selected,selected.GetType()))]);''','''        var facts = new List<SystemDescriptionSnapshotSourceFact> { new(NativeFactReference.Of(source,selected),
            EventKind.Of(selected),ContentDigest.Sha256(selected,selected.GetType())) };
        if (additional is { } extra)
        {
            DomainEvent? matched = null;
            await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(extra.Stream.Realm,extra.Stream.Area,extra.Stream.Resource),EventCursor.Start,ct).ConfigureAwait(false))
                if (!record.Event.Metadata.IsAudit && extra.Select(record.Event))
                    matched = record.Event;
            if (matched is null || extra.Stream.Realm != tenant.ToString())
                throw new ImmutableContentUnavailableException("The exact approved Type II plan source fact is not readable yet.");
            facts.Add(new(NativeFactReference.Of(extra.Stream,matched),EventKind.Of(matched),ContentDigest.Sha256(matched,matched.GetType())));
        }
        var proof = new SystemDescriptionSnapshotSourceProof(scope,sources,facts);''')
s=s.replace('proof.Facts.Count != 1','proof.Facts.Count != (scope.Stage == "type_ii" ? 2 : 1)')
a=s.index('        var claimed = proof.Facts[0];');b=s.index('        IReadOnlyList<SystemDescriptionSourceReference>? selected = null;',a)
old=s[a:b]
new='''        var proven = new List<DomainEvent>();
        foreach (var claimed in proof.Facts)
        {
'''+''.join('    '+line+'\n' for line in old.splitlines())+'''            proven.Add(found);
        }
        var found = proven[0];
'''
s=s[:a]+new+s[b:]
s=s.replace('''                var close = state.CloseSnapshots.FirstOrDefault''','''                if (proven[1] is not TypeIIPlanApproved plan || plan.TenantId != tenant || plan.State.ProgramId != program ||
                    plan.SubjectId != state.TypeIIPlanId || plan.State.CurrentVersionNumber != state.TypeIIPlanVersion ||
                    plan.State.Current is not { } version || version.ContentSha256 != state.TypeIIPlanContentSha256 ||
                    version.Content.ExaminationId != scope.ExaminationId || version.Content.TypeIBaselineId != scope.TypeIBaselineId)
                    throw new ImmutableContentIntegrityException("The Type II description scope differs from its exact approved plan source.");
                var close = state.CloseSnapshots.FirstOrDefault''')
p.write_text(s)
