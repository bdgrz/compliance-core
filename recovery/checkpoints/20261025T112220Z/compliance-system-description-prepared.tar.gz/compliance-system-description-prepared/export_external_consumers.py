from pathlib import Path
import hashlib,json,difflib,tempfile,shutil,subprocess
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-system-description-prepared');paths=(r/'external-owned-paths.txt').read_text().splitlines();parser=Parser(Language(tree_sitter_c_sharp.language()))
behaviorNames={'ShouldRetryUnavailableDescriptionContentAndRefuseCorruptionGivenAssertionSources','ShouldInvalidateExactNativeDescriptionVersionGivenCloseAmendmentMaterialCapture'}
def walk(n):
 pending=[n]
 while pending:
  x=pending.pop();yield x;pending.extend(reversed(x.children))
def sha(b):return hashlib.sha256(b).hexdigest()
def diff(p,a,b):return ''.join(difflib.unified_diff((a or b'').decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='a/'+p if a is not None else '/dev/null',tofile='b/'+p))
files={};beforeMissing=[]
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
for p in paths:
 a=r/'base'/p;b=r/'work'/p;old=a.read_bytes() if a.exists() else None;new=b.read_bytes()
 if old==new:continue
 if (repo/p).exists() and old is None:beforeMissing.append(p)
 files[p]={'old':old,'new':new}
assert not beforeMissing,beforeMissing
red={p:d['new'] for p,d in files.items()};scaffold={}
for p,d in files.items():
 if not p.startswith('test/') or d['old'] is None:continue
 t=d['new'];remove=[]
 for n in walk(parser.parse(t).root_node):
  if n.type=='method_declaration':
   name=n.child_by_field_name('name')
   if name and t[name.start_byte:name.end_byte].decode() in behaviorNames:remove.append((n.start_byte,n.end_byte))
 for a,b in sorted(remove,reverse=True):t=t[:a]+t[b:]
 scaffold[p]=t
p='src/Compliance.Core/Features/Examinations/RecordManagementAssertionHandler.cs';red[p]=red[p].replace(b'catch (ImmutableContentIntegrityException failure)\n        {\n            return Result.Failure(SystemDescriptionReadFailure.Of(failure));\n        }',b'catch (ImmutableContentIntegrityException)\n        {\n            throw;\n        }')
p='src/Compliance.Core/Features/Operations/TypeIIPeriodCloseMaterialReader.cs';red[p]=red[p].replace(b'                    affected.Add(version.SystemDescriptionId);\n                    affected.Add(version.SystemDescriptionVersionId);',b'                    // Native description material is observed but not invalidated in this RED preparation.\n                    _ = version.SystemDescriptionId;')
p='src/Compliance.Core/Features/Changes/SystemDescriptionDecisionReactor.cs';red[p]=red[p].replace(b'        if (ev.ChangeCount == 0)\n            return;\n',b'').replace(b' ||\n            ContentDigest.Sha256(actual, actual.GetType()) != ContentDigest.Sha256(source, source.GetType())',b'')
groups={name:[] for name in ['external-implementation.patch','external-implementation-red.patch','external-consumer-boundaries.patch','external-tests.patch','external-migrated-tests.patch','external-behavior.tests.patch']};manifest=[]
redSyntax=[]
for p,d in files.items():
 isTest=p.startswith('test/');phase='external-tests.patch' if isTest else 'external-implementation.patch'
 groups[phase].append(diff(p,d['old'],d['new']))
 if isTest:
  if p in scaffold:
   groups['external-migrated-tests.patch'].append(diff(p,d['old'],scaffold[p]))
   if scaffold[p]!=d['new']:groups['external-behavior.tests.patch'].append(diff(p,scaffold[p],d['new']))
  else:groups['external-behavior.tests.patch'].append(diff(p,None,d['new']))
 else:
  groups['external-implementation-red.patch'].append(diff(p,d['old'],red[p]))
  if red[p]!=d['new']:groups['external-consumer-boundaries.patch'].append(diff(p,red[p],d['new']))
  if parser.parse(red[p]).root_node.has_error:redSyntax.append(p)
 manifest.append({'path':p,'phase':phase,'beforeSha256':sha(d['old']) if d['old'] is not None else None,'afterSha256':sha(d['new']),'redSha256':None if isTest else sha(red[p])})
assert not redSyntax,redSyntax
for name,parts in groups.items():(r/name).write_text(''.join(parts))
(r/'external-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
reconstruction={}
for mode,order in [('final',['external-implementation.patch','external-tests.patch']),('red-to-green',['external-implementation-red.patch','external-migrated-tests.patch','external-behavior.tests.patch','external-consumer-boundaries.patch'])]:
 root=Path(tempfile.mkdtemp(prefix='description-external-reconstruct-',dir=r))
 try:
  for p,d in files.items():
   if d['old'] is not None:
    f=root/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(d['old'])
  for name in order:
   proc=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/name)],cwd=root,capture_output=True,text=True)
   assert proc.returncode==0,(name,proc.stdout,proc.stderr)
  bad=[p for p,d in files.items() if not (root/p).exists() or (root/p).read_bytes()!=d['new']];assert not bad,(mode,bad)
  reconstruction[mode]={'patchOrder':order,'exactFiles':len(files)}
 finally:shutil.rmtree(root)
(r/'external-reconstruction.json').write_text(json.dumps(reconstruction,indent=2)+'\n')
deps={}
for p in ['src/Compliance.Core/Features/SystemDescription/SystemDescriptionReader.cs','src/Compliance.Core/Features/SystemDescription/SystemDescriptionReadSnapshot.cs','src/Compliance.Core/Features/SystemDescription/SystemDescriptionVersionSource.cs','test/Compliance.Tests/Features/SystemDescription/DescriptionSeeds.cs','test/Compliance.Tests/Features/SystemDescription/SystemDescriptionNativeFixture.cs']:
 deps[p]=sha((r/'work'/p).read_bytes())
handoff={'root':str(r),'scope':'External SystemDescription native read/correlation/reactor/TypeII/assertion/material consumers and source fixtures only.','status':'External package frozen offline; owner package is a separate sibling-owned work stream; parent compiler/runtime/Jev/Git gates pending.','changedFiles':len(files),'implementationFiles':sum(not p.startswith('test/') for p in files),'testFiles':sum(p.startswith('test/') for p in files),'patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in groups},'stagedOrder':reconstruction['red-to-green']['patchOrder'],'allFinalOrder':reconstruction['final']['patchOrder'],'behaviorFilter':'FullyQualifiedName~ShouldRetryUnavailableDescriptionContentAndRefuseCorruptionGivenAssertionSources|FullyQualifiedName~ShouldInvalidateExactNativeDescriptionVersionGivenCloseAmendmentMaterialCapture|FullyQualifiedName~SystemDescriptionDecisionNativeConsumerTests','newBehaviorCases':5,'expectedBehavioralRedCases':5,'existingAcceptanceNames':72,'staticAudit':'external-audit.json','exactReconstruction':'external-reconstruction.json','baselineProvenance':'external-baselines.json','sourceHashes':'external-manifest.json','observedOwnerApiDependencyHashes':deps,'constructorDeltas':{'RecordSignificantChangeSystemDescriptionDecisionHandler':'(SignificantChangeOperations, SystemDescriptionReader); queued native SignificantChange baseline retained.','RecordComplianceIncidentSystemDescriptionDecisionHandler':'(NativeOperationExecutor, SystemDescriptionReader, IImmutableContentStore, TimeProvider)','SystemDescriptionDecisionReactor':'append SystemDescriptionReader and IImmutableContentStore after IAggregateReader, before assessments','RecordManagementAssertionHandler':'append SystemDescriptionReader after TimeProvider (6 total)','StartTypeIIObservationPeriodHandler':'append SystemDescriptionReader after TimeProvider (8 total)','ProposeTypeIIOperatingPlanHandler':'append SystemDescriptionReader after TimeProvider (7 total)','TypeIIPlanSourceValidator.ValidateAsync':'add SystemDescriptionReader after ControlOperationsReader','TypeIIPeriodCloseMaterialReader':'append SystemDescriptionReader (3 total)'},'notes':['No main/Git/GitHub/dotnet/broker/Jev operations. No new GitHub issues.','Do not apply older queued Change source/test bytes over these external changes; their saved before baselines already include that native package where relevant.','Owning Common/Core/SystemDescription, owning test feature, shared Program/DI/JSON are owned by sibling and untouched here.','Expected RED stages are counterfactual compile-compatible native preparations, not claimed original-main source snapshots.']}
(r/'external-handoff.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps({'changedFiles':len(files),'patches':handoff['patches'],'reconstruction':reconstruction},indent=2))
