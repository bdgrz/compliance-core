from pathlib import Path
import hashlib,json
r=Path('/tmp/compliance-system-description-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=['src/Compliance.Core/Features/Changes/SystemDescriptionDecisionCorrelation.cs','src/Compliance.Core/Features/Changes/SystemDescriptionDecisionReactor.cs','src/Compliance.Core/Features/Changes/RecordSignificantChangeSystemDescriptionDecisionHandler.cs','src/Compliance.Core/Features/Incidents/RecordComplianceIncidentSystemDescriptionDecisionHandler.cs','src/Compliance.Core/Features/Examinations/RecordManagementAssertionHandler.cs','src/Compliance.Core/Features/Operations/StartTypeIIObservationPeriodHandler.cs','src/Compliance.Core/Features/Operations/TypeIIPlanSourceValidator.cs','src/Compliance.Core/Features/Operations/ProposeTypeIIOperatingPlanHandler.cs','src/Compliance.Core/Features/Operations/TypeIIPeriodCloseMaterialReader.cs','test/Compliance.Tests/Features/Changes/ComplianceImpactReactionHandlerTests.cs','test/Compliance.Tests/Features/Incidents/ComplianceIncidentOperationTests.cs','test/Compliance.Tests/Features/Examinations/RecordManagementAssertionHandlerTests.cs','test/Compliance.Tests/Features/Operations/StartTypeIIObservationPeriodHandlerTests.cs','test/Compliance.Tests/Features/Operations/ProposeTypeIIOperatingPlanHandlerTests.cs']
provenance=[]
for p in paths:
 f=repo/p
 for overlay in ['/tmp/compliance-s32-commitment-prepared/after','/tmp/compliance-commitment-consumers-prepared/after','/tmp/compliance-s32-boundary-prepared/after','/tmp/compliance-boundary-consumers-prepared/after','/tmp/compliance-significant-change-prepared/work']:
  if (Path(overlay)/p).exists():f=Path(overlay)/p
 data=f.read_bytes()
 for directory in ['base','work']:
  dest=r/directory/p
  if dest.exists():assert dest.read_bytes()==data,(directory,p,'unexpected existing content')
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 provenance.append({'path':p,'baselineSource':str(f),'beforeSha256':hashlib.sha256(data).hexdigest()})
(r/'external-baselines.json').write_text(json.dumps(provenance,indent=2)+'\n');(r/'external-owned-paths.txt').write_text('\n'.join(paths)+'\n');print(len(paths))
