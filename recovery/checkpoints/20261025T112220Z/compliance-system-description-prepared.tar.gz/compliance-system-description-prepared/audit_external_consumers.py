from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,re,json
r=Path('/tmp/compliance-system-description-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');p=Parser(Language(tree_sitter_c_sharp.language()));paths=(r/'external-owned-paths.txt').read_text().splitlines();new='test/Compliance.Tests/Features/Changes/SystemDescriptionDecisionNativeConsumerTests.cs'
if new not in paths:paths.append(new);(r/'external-owned-paths.txt').write_text('\n'.join(paths)+'\n')
def walk(n):
 pending=[n]
 while pending:
  x=pending.pop();yield x;pending.extend(reversed(x.children))
def text(t,n):return t[n.start_byte:n.end_byte].decode()
def sig(t,n):
 params=[c for c in n.children if c.type=='parameter'];return(sum('=' not in text(t,c) for c in params),len(params))
def defs(t):
 result={}
 for n in walk(p.parse(t).root_node):
  if n.type not in {'class_declaration','record_declaration'}:continue
  name=n.child_by_field_name('name');pl=next((c for c in n.children if c.type=='parameter_list'),None)
  if name is not None and pl:result[text(t,name)]=[sig(t,pl)]
 return result
sources={}
for root in [repo,Path('/tmp/compliance-significant-change-prepared/work'),Path('/tmp/compliance-s32-commitment-prepared/after'),Path('/tmp/compliance-commitment-consumers-prepared/after'),Path('/tmp/compliance-s32-boundary-prepared/after'),Path('/tmp/compliance-boundary-consumers-prepared/after'),r/'work']:
 for d in ['src','test']:
  for f in (root/d).rglob('*.cs'):
   if not {'bin','obj'}.intersection(f.parts):sources[str(f.relative_to(root))]=f
names={'SystemDescriptionReader','SystemDescriptionReadSnapshot','SystemDescriptionRules','SystemDescriptionVersionSource','RecordSignificantChangeSystemDescriptionDecisionHandler','RecordComplianceIncidentSystemDescriptionDecisionHandler','RecordManagementAssertionHandler','StartTypeIIObservationPeriodHandler','ProposeTypeIIOperatingPlanHandler','SystemDescriptionDecisionReactor','TypeIIPeriodCloseMaterialReader'};known={}
for path,f in sources.items():
 if path.startswith('src/'):
  t=f.read_bytes()
  if any(n.encode() in t for n in names):known.update({name:value for name,value in defs(t).items() if name in names})
errors=[];syntax=[];calls=0;originals=0;removed=[];drops=[];missing=[];newNames=[]
for path in paths:
 f=r/'work'/path;t=f.read_bytes();tree=p.parse(t)
 if tree.root_node.has_error:syntax.append(path)
 b=r/'base'/path
 if b.exists():
  old=b.read_text();ns=re.findall(r'\b(Should\w+)\s*\(',old);originals+=len(ns);removed.extend({'path':path,'name':n} for n in ns if not re.search(r'\b'+n+r'\s*\(',t.decode()))
  if t.count(b'Assert.')<old.count('Assert.'):drops.append(path)
  newNames.extend({'path':path,'name':n} for n in re.findall(r'\b(Should\w+)\s*\(',t.decode()) if n not in ns)
 elif (repo/path).exists():missing.append(path)
 else:newNames.extend({'path':path,'name':n} for n in re.findall(r'\b(Should\w+)\s*\(',t.decode()))
for path,f in sources.items():
 t=f.read_bytes()
 if not any(n.encode() in t for n in names):continue
 for n in walk(p.parse(t).root_node):
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=next((x for x in n.children if x.type=='argument_list'),None)
  if typ is None or args is None:continue
  name=text(t,typ).split('.')[-1]
  if name not in known:continue
  count=sum(x.type=='argument' for x in args.children);calls+=1
  if not any(a<=count<=b for a,b in known[name]):errors.append({'path':path,'type':name,'args':count,'expected':known[name]})
a={'qualification':'Static parsing, explicit constructor arity and original acceptance preservation only; no compiler, runtime or Jev evidence.','paths':len(paths),'syntaxErrors':syntax,'relevantConstructorCallsAcrossEffectiveTree':calls,'constructorErrors':errors,'existingAcceptanceNames':originals,'removedAcceptanceNames':removed,'perFileAssertionCountDrops':drops,'existingRepositoryPathsMissingOriginal':missing,'newAcceptanceNames':newNames,'manualTargetTypedConstructorChecks':{'Testing/TypeIIRangeHost.StartHandler':8,'RecordManagementAssertionHandlerTests.Fixture.Handler':6}}
(r/'external-audit.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))
