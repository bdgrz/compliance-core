from pathlib import Path
import json,hashlib
r=Path('/tmp/compliance-system-description-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');paths=['test/Compliance.Tests/Testing/TypeIIRangeHost.cs','test/Compliance.Tests/Features/Operations/TypeIIPeriodCommandHandlerTests.NativeOwners.cs','test/Compliance.Tests/Features/Operations/ObservationPeriodReadHandlerTests.cs'];a=json.loads((r/'external-baselines.json').read_text())
for p in paths:
 f=repo/p;data=f.read_bytes()
 for d in ['base','work']:
  dest=r/d/p
  if dest.exists():assert dest.read_bytes()==data,(d,p)
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 a.append({'path':p,'baselineSource':str(f),'beforeSha256':hashlib.sha256(data).hexdigest()})
(r/'external-baselines.json').write_text(json.dumps(a,indent=2)+'\n');(r/'external-owned-paths.txt').write_text('\n'.join(x['path'] for x in a)+'\n')
