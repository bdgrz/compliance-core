Standalone old-API RED sequence (no new native model dependencies):

- `FullyQualifiedName~SystemDescriptionTests.ShouldRetainCompleteNarrativeGivenValidContentExceedsOldEventEnvelope`
- `FullyQualifiedName~SystemDescriptionExportBoundaryTests.ShouldKeepBusinessRevisionGivenIndependentTechnicalExport`

- `FullyQualifiedName~SystemDescriptionTests.ShouldPreserveOpeningAndClosingSourceVersionsGivenExactPeriodLineage`

The lineage case uses two exact versions of one source record, which real Type II close reconciliation intentionally preserves.

The first supplies valid 12 × 6,000-character section bodies, below the per-section limit, and demonstrates the artificial 48 KiB event rejection. The second demonstrates that the current technical export increments the description business revision. Reverse the standalone patch before applying full implementation/tests. Both names remain in the migrated acceptance suite. Parent owns all runtime.

- `FullyQualifiedName~SystemDescriptionTests.ShouldRetainAllGovernedSourcesAndPeriodChangesGivenLargeValidDescription` removes the invented 512-source/200-period-change caps; 1,000 exact sources and 300 material changes remain complete in native immutable content.
