from pathlib import Path
R=Path('/tmp/compliance-system-description-prepared/work');K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
put(K+'SystemDescriptionExportIntent.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Complete original approved source identity and exact source bytes frozen before technical acceptance.</summary>
public sealed record SystemDescriptionExportIntent(Uuid TenantId,Uuid ProgramId,Uuid DescriptionId,Uuid ProcessId,
    Uuid VersionId,long Version,string Format,string ExportKey,string ContentSha256,ImmutableContentRef SourceContent,
    NativeFactReference VersionSource,NativeFactReference ApprovalSource,OperationProvenance Operation)
{
    public const string Schema = "system-description-export-intent.v1";
}
''')
put(K+'SystemDescriptionExportProcessRecord.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>One technical export authority; attempts and output never become description business facts.</summary>
public sealed record SystemDescriptionExportProcessRecord(Uuid TenantId,Uuid ProgramId,Uuid DescriptionId,Uuid ProcessId,
    AcceptedOperationBinding Binding,ImmutableContentRef Intent,string State,int Attempts,long Revision,
    ImmutableContentRef? Output,ImmutableContentRef? OperationResult,string? FailureCode);
''')
put(K+'SystemDescriptionExportOutput.cs','''using Bdgrz.Compliance.Features.Artifacts;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Verified output bound to one exact approved source and original generated metadata; no access ticket is durable.</summary>
public sealed record SystemDescriptionExportOutput(Uuid TenantId,Uuid ProgramId,Uuid DescriptionId,Uuid ProcessId,
    Uuid VersionId,long Version,string Format,string ExportKey,string ContentSha256,ImmutableContentRef SourceContent,
    NativeFactReference VersionSource,NativeFactReference ApprovalSource,ArtifactContentReference Artifact,string MediaType,
    SystemDescriptionExportView Export)
{
    public const string Schema = "system-description-export-output.v1";
}
''')
put(K+'ISystemDescriptionExportProcesses.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public interface ISystemDescriptionExportProcesses
{
    Task<SystemDescriptionExportProcessRecord?> ReadAsync(Uuid tenant,Uuid processId,Uuid commandId,CancellationToken ct);
    Task<Result<SystemDescriptionExportProcessRecord>> AcceptIfAbsentAsync(SystemDescriptionExportProcessRecord candidate,CancellationToken ct);
    Task<Result<SystemDescriptionExportProcessRecord>> ReplaceAsync(SystemDescriptionExportProcessRecord expected,SystemDescriptionExportProcessRecord next,CancellationToken ct);
}
''')
put(K+'FitzKvSystemDescriptionExportProcesses.cs','''using System.Text;
using System.Text.Json;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Processes;
using Cntryl.Fitz;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>One tenant route atomically binds the process key and root command id before any attempt runs.</summary>
sealed class FitzKvSystemDescriptionExportProcesses(IKvClient client) : ISystemDescriptionExportProcesses
{
    public async Task<SystemDescriptionExportProcessRecord?> ReadAsync(Uuid tenant,Uuid processId,Uuid commandId,CancellationToken ct)
    {
        await using var tx = await client.BeginAsync(Route(tenant),KvMode.ReadOnly,ct).ConfigureAwait(false);
        var command = await tx.GetAsync(CommandKey(commandId),ct).ConfigureAwait(false);
        if (command.Found)
            processId = Uuid.Parse(Encoding.UTF8.GetString(command.Value!.Value.Span),System.Globalization.CultureInfo.InvariantCulture);
        var row = await tx.GetAsync(Key(processId),ct).ConfigureAwait(false);
        if (!row.Found)
        {
            if (command.Found)
                throw new ImmutableContentIntegrityException("An export command index has no owning process.");
            return null;
        }
        var result = Parse(row.Value!.Value.Span);
        if (result.TenantId != tenant || result.ProcessId != processId)
            throw new ImmutableContentIntegrityException("The export process belongs to another tenant or process identity.");
        return result;
    }
    public async Task<Result<SystemDescriptionExportProcessRecord>> AcceptIfAbsentAsync(SystemDescriptionExportProcessRecord candidate,CancellationToken ct)
    {
        for (var attempt = 1; ; attempt++)
        {
            try
            {
                await using var tx = await client.BeginAsync(Route(candidate.TenantId),KvMode.ReadWrite,ct).ConfigureAwait(false);
                var command = await tx.GetAsync(CommandKey(candidate.Binding.LogicalId),ct).ConfigureAwait(false);
                if (command.Found && Encoding.UTF8.GetString(command.Value!.Value.Span) != candidate.ProcessId.ToString())
                    return Conflict();
                var found = await tx.GetAsync(Key(candidate.ProcessId),ct).ConfigureAwait(false);
                if (found.Found)
                {
                    var existing = Parse(found.Value!.Value.Span);
                    return existing.Binding == candidate.Binding && existing.ProgramId == candidate.ProgramId && existing.DescriptionId == candidate.DescriptionId
                        ? Result<SystemDescriptionExportProcessRecord>.Success(existing) : Conflict();
                }
                if (command.Found)
                    throw new ImmutableContentIntegrityException("A bound export command lost its owning technical process.");
                var accepted = candidate with { Revision = 1 };
                await tx.InsertAsync(Key(candidate.ProcessId),JsonSerializer.SerializeToUtf8Bytes(accepted,
                    ComplianceCoreJsonContext.Default.SystemDescriptionExportProcessRecord),ct).ConfigureAwait(false);
                await tx.InsertAsync(CommandKey(candidate.Binding.LogicalId),Encoding.UTF8.GetBytes(candidate.ProcessId.ToString()),ct).ConfigureAwait(false);
                await tx.CommitAsync(KvDurability.Sync,ct).ConfigureAwait(false);
                return Result<SystemDescriptionExportProcessRecord>.Success(accepted);
            }
            catch (KvException exception) when (attempt < 4 && FitzKvProcessRecordStore.IsIsolationConflict(exception))
            {
                // Re-read the single-route authority after the competing admission.
            }
        }
    }
    public async Task<Result<SystemDescriptionExportProcessRecord>> ReplaceAsync(SystemDescriptionExportProcessRecord expected,
        SystemDescriptionExportProcessRecord next,CancellationToken ct)
    {
        if (next.Binding != expected.Binding || next.TenantId != expected.TenantId || next.ProgramId != expected.ProgramId ||
            next.DescriptionId != expected.DescriptionId || next.ProcessId != expected.ProcessId || next.Intent != expected.Intent)
            return Conflict();
        for (var attempt = 1; ; attempt++)
        {
            try
            {
                await using var tx = await client.BeginAsync(Route(expected.TenantId),KvMode.ReadWrite,ct).ConfigureAwait(false);
                var found = await tx.GetAsync(Key(expected.ProcessId),ct).ConfigureAwait(false);
                if (!found.Found)
                    throw new ImmutableContentUnavailableException("The admitted export process is not readable yet.");
                var current = Parse(found.Value!.Value.Span);
                if (current.Binding != expected.Binding || current.Intent != expected.Intent)
                    return Conflict();
                if (current.State is "completed" or "failed")
                    return Result<SystemDescriptionExportProcessRecord>.Success(current);
                if (current.Revision != expected.Revision)
                    return Result<SystemDescriptionExportProcessRecord>.Failure(new RequestError(RequestErrorKind.Conflict,"The technical export attempt changed; retry the original operation.",true));
                var replaced = next with { Revision = current.Revision+1 };
                await tx.ReplaceAsync(Key(expected.ProcessId),JsonSerializer.SerializeToUtf8Bytes(replaced,
                    ComplianceCoreJsonContext.Default.SystemDescriptionExportProcessRecord),ct).ConfigureAwait(false);
                await tx.CommitAsync(KvDurability.Sync,ct).ConfigureAwait(false);
                return Result<SystemDescriptionExportProcessRecord>.Success(replaced);
            }
            catch (KvException exception) when (attempt < 4 && FitzKvProcessRecordStore.IsIsolationConflict(exception))
            {
                // Unknown or concurrent attempts recover from their persisted forward state.
            }
        }
    }
    static string Route(Uuid tenant) => $"kv://bdgrz/system-description-export-processes/{tenant}";
    static byte[] Key(Uuid id) => Encoding.UTF8.GetBytes("e/"+id);
    static byte[] CommandKey(Uuid id) => Encoding.UTF8.GetBytes("c/"+id);
    static SystemDescriptionExportProcessRecord Parse(ReadOnlySpan<byte> bytes) => JsonSerializer.Deserialize(bytes,
        ComplianceCoreJsonContext.Default.SystemDescriptionExportProcessRecord) ?? throw new ImmutableContentIntegrityException("An export process cannot be empty.");
    static Result<SystemDescriptionExportProcessRecord> Conflict() => Result<SystemDescriptionExportProcessRecord>.Failure(new RequestError(RequestErrorKind.Conflict,
        "The export identity is already bound to another exact owner, actor or authored intent."));
}
''')
