from pathlib import Path
import json,re
P=Path('/tmp/compliance-system-description-prepared');R=P/'work';C='src/Compliance.Common/Features/SystemDescription/';K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
p=R/(C+'SystemDescriptionAuthorityHeader.cs');s=p.read_text().replace('long BindingCount,string BindingsSha256,Uuid? LatestApprovedVersionId);','long BindingCount,string BindingsSha256,Uuid? LatestApprovedVersionId,\n    string VersionsSha256,string ReviewsSha256,string ApprovalsSha256);');p.write_text(s)
# Rebuild a transient rules model from a before view already bound to the exact native authority hashes.
p=R/(K+'SystemDescriptionRules.cs');s=p.read_text();i=s.index('    public CommandFailure? Create(');s=s[:i]+'''    internal static SystemDescriptionRules FromView(SystemDescriptionView before)
    {
        var rules = new SystemDescriptionRules(before.TenantId,before.ProgramId,before.SystemDescriptionId);
        rules._versions.AddRange(before.Versions.Select(FreezeVersion));
        rules._reviews.AddRange(before.Reviews);
        rules._approvals.AddRange(before.Approvals);
        rules._noChangeDecisions.AddRange(before.NoChangeDecisions);
        rules._bindings.AddRange(before.Bindings);
        rules.Revision = before.Revision;
        return rules;
    }

'''+s[i:];p.write_text(s)
put(K+'FrozenSystemDescriptionMutation.cs','''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed record FrozenSystemDescriptionMutation(SystemDescriptionView Before,SystemDescriptionView After,
    SystemDescriptionAuthorityHeader Header,ImmutableContentRef CurrentVersion,ImmutableContentRef Payload,
    object Mutation,string Kind,bool Changed);
''')
# Typed payload schema mapping is exactly the selected target event catalog, never a cumulative parent view.
put(K+'SystemDescriptionContent.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public static class SystemDescriptionContent
{
    public const string CurrentSchema = "system-description-current-version.v1";
    public static SystemDescriptionAuthorityHeader Header(SystemDescriptionView view)
    {
        var current = view.CurrentVersion ?? throw new ImmutableContentIntegrityException("The description has no current version.");
        var review = view.Reviews.LastOrDefault(item => item.VersionId == current.SystemDescriptionVersionId);
        return new(view.TenantId,view.ProgramId,view.SystemDescriptionId,view.Revision,current.Version,current.SystemDescriptionVersionId,
            current.ParentVersionId,current.Status,current.Content.Title,current.ContentSha256,current.Scope,current.AuthorMemberId,current.UpdatedAt,
            review?.ReviewId,review?.ReviewerMemberId,review?.Outcome,view.Reviews.Count,view.Approvals.Count,view.NoChangeDecisions.Count,
            AuthoredIntentDigest.Compute(view.NoChangeDecisions),view.Bindings.Count,AuthoredIntentDigest.Compute(view.Bindings),
            view.Approvals.Count == 0 ? null : view.Approvals[^1].VersionId,AuthoredIntentDigest.Compute(view.Versions),
            AuthoredIntentDigest.Compute(view.Reviews),AuthoredIntentDigest.Compute(view.Approvals));
    }
    public static async ValueTask<FrozenSystemDescriptionMutation> FreezeAsync(IImmutableContentStore content,
        SystemDescriptionView before,SystemDescriptionRules rules,string kind,object? receipt,CancellationToken ct)
    {
        var after = rules.Read();
        var mutation = rules.PendingChanges.Count == 1 ? rules.PendingChanges[0] :
            rules.PendingChanges.Count == 0 && receipt is not null ? receipt :
            throw new ImmutableContentIntegrityException("One description command requires one exact business mutation or verified no-op receipt.");
        var current = after.CurrentVersion ?? throw new ImmutableContentIntegrityException("The description has no current version.");
        var reference = await content.WriteJsonAsync(after.TenantId.ToString(),Uuid.CreateVersion5(after.SystemDescriptionId,
            CurrentSchema+":"+AuthoredIntentDigest.Compute(current)),CurrentSchema,current,ct).ConfigureAwait(false);
        var payload = await WritePayloadAsync(content,after.TenantId,mutation,ct).ConfigureAwait(false);
        return new(before,after,Header(after),reference,payload,mutation,kind,rules.PendingChanges.Count == 1);
    }
    static Task<ImmutableContentRef> WritePayloadAsync(IImmutableContentStore store,Uuid tenant,object mutation,CancellationToken ct) => mutation switch
    {
        SystemDescriptionDraftCreatedBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionDraftCreated.VersionContent.v1",item.Version,ct),
        SystemDescriptionDraftRevisedBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionDraftRevised.VersionContent.v1",item.Version,ct),
        SystemDescriptionSourcesBoundBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionSourcesBound.VersionContent.v1",item.Version,ct),
        SystemDescriptionSuccessorProposedBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionSuccessorProposed.VersionContent.v1",item.Version,ct),
        SystemDescriptionReviewedBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionReviewed.ReviewContent.v1",item.Review,ct),
        SystemDescriptionApprovedBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionApproved.ApprovalContent.v1",item.Approval,ct),
        SystemDescriptionNoChangeRecordedBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionNoChangeRecorded.DecisionContent.v1",item.Decision,ct),
        SystemDescriptionBoundBody item => NativeContent.WriteAsync(store,tenant,"SystemDescriptionBound.BindingContent.v1",item.Binding,ct),
        _ => throw new ImmutableContentIntegrityException("The description payload has another mutation kind."),
    };
    public static async ValueTask<object> ReadMutationAsync(IImmutableContentStore store,DomainEvent value,CancellationToken ct)
    {
        var f = value as ISystemDescriptionFact ?? throw new ImmutableContentIntegrityException("The source is not a native description fact.");
        var realm = f.TenantId.ToString();
        return value switch
        {
            SystemDescriptionDraftCreated item => new SystemDescriptionDraftCreatedBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionVersionView>(store,realm,item.VersionContent,"SystemDescriptionDraftCreated.VersionContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            SystemDescriptionDraftRevised item => new SystemDescriptionDraftRevisedBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionVersionView>(store,realm,item.VersionContent,"SystemDescriptionDraftRevised.VersionContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            SystemDescriptionSourcesBound item => new SystemDescriptionSourcesBoundBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionVersionView>(store,realm,item.VersionContent,"SystemDescriptionSourcesBound.VersionContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            SystemDescriptionSuccessorProposed item => new SystemDescriptionSuccessorProposedBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionVersionView>(store,realm,item.VersionContent,"SystemDescriptionSuccessorProposed.VersionContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            SystemDescriptionReviewed item => new SystemDescriptionReviewedBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionReviewView>(store,realm,item.ReviewContent,"SystemDescriptionReviewed.ReviewContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            SystemDescriptionApproved item => new SystemDescriptionApprovedBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionApprovalView>(store,realm,item.ApprovalContent,"SystemDescriptionApproved.ApprovalContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            SystemDescriptionNoChangeRecorded item => new SystemDescriptionNoChangeRecordedBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionNoChangeDecisionView>(store,realm,item.DecisionContent,"SystemDescriptionNoChangeRecorded.DecisionContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            SystemDescriptionBound item => new SystemDescriptionBoundBody(f.TenantId,f.ProgramId,f.SystemDescriptionId,f.AggregateRevision,
                await ReadAsync<SystemDescriptionBindingView>(store,realm,item.BindingContent,"SystemDescriptionBound.BindingContent.v1",ct).ConfigureAwait(false),f.OccurredAt),
            _ => throw new ImmutableContentIntegrityException("The native description source has another mutation kind."),
        };
    }
    static Task<T> ReadAsync<T>(IImmutableContentStore content,string realm,ImmutableContentRef reference,string schema,CancellationToken ct) where T : notnull =>
        reference.Schema == schema ? content.ReadJsonAsync<T>(realm,reference,ct) :
            throw new ImmutableContentIntegrityException("The description payload has another selected content schema.");
    public static ImmutableContentRef Payload(ISystemDescriptionFact fact) => fact switch
    {
        SystemDescriptionDraftCreated item => item.VersionContent,
        SystemDescriptionDraftRevised item => item.VersionContent,
        SystemDescriptionSourcesBound item => item.VersionContent,
        SystemDescriptionSuccessorProposed item => item.VersionContent,
        SystemDescriptionReviewed item => item.ReviewContent,
        SystemDescriptionApproved item => item.ApprovalContent,
        SystemDescriptionNoChangeRecorded item => item.DecisionContent,
        SystemDescriptionBound item => item.BindingContent,
        _ => throw new ImmutableContentIntegrityException("The native description source has another payload kind."),
    };
    public static bool Verify(FrozenSystemDescriptionMutation mutation)
    {
        var before = mutation.Before;
        var rules = SystemDescriptionRules.FromView(before);
        var at = At(mutation.Mutation);
        var failure = mutation.Mutation switch
        {
            SystemDescriptionDraftCreatedBody item => rules.Create(item.Version.SystemDescriptionVersionId,item.Version.Scope,item.Version.Content,
                item.Version.AuthorMemberId,item.Version.AuthorDisplay,at),
            SystemDescriptionDraftRevisedBody item => rules.Revise(before.Revision,item.Version.SystemDescriptionVersionId,item.Version.Content,item.Version.ChangeReason,
                item.Version.AuthorMemberId,item.Version.AuthorDisplay,at),
            SystemDescriptionSourcesBoundBody item => rules.BindSources(before.Revision,item.Version.SystemDescriptionVersionId,item.Version.Content.Sources,
                item.Version.AuthorMemberId,item.Version.AuthorDisplay,at),
            SystemDescriptionSuccessorProposedBody item => rules.ProposeSuccessor(before.Revision,item.Version.SystemDescriptionVersionId,item.Version.Content,item.Version.ChangeReason,
                item.Version.AuthorMemberId,item.Version.AuthorDisplay,at),
            SystemDescriptionReviewedBody item => rules.Review(item.Review.Version,item.Review.ReviewerMemberId,item.Review.ReviewerDisplay,item.Review.Outcome,item.Review.Comments,
                item.Review.ReviewedAt),
            SystemDescriptionApprovedBody item => rules.Approve(item.Approval.Version,item.Approval.ApproverMemberId,item.Approval.ApproverDisplay,item.Approval.Rationale,item.Approval.ApprovedAt),
            SystemDescriptionNoChangeRecordedBody item => rules.RecordNoChangeDecision(item.Decision.Version,item.Decision.ChangeId,item.Decision.Rationale,
                item.Decision.DecidedByMemberId,item.Decision.DecidedByDisplay,item.Decision.DecidedAt),
            SystemDescriptionBoundBody item => rules.BindToExamination(item.Binding.Version,item.Binding.ExaminationId,item.Binding.Purpose,item.Binding.SnapshotId,
                item.Binding.BoundByMemberId,item.Binding.BoundByDisplay,item.Binding.BoundAt),
            _ => throw new ImmutableContentIntegrityException("The description mutation has another rule kind."),
        };
        return failure is null && (rules.PendingChanges.Count > 0) == mutation.Changed &&
            AuthoredIntentDigest.Compute(rules.Read()) == AuthoredIntentDigest.Compute(mutation.After) &&
            Header(mutation.After) == mutation.Header;
    }
    public static DateTimeOffset At(object mutation) => mutation switch
    {
        SystemDescriptionDraftCreatedBody item => item.Version.UpdatedAt,
        SystemDescriptionDraftRevisedBody item => item.Version.UpdatedAt,
        SystemDescriptionSourcesBoundBody item => item.Version.UpdatedAt,
        SystemDescriptionSuccessorProposedBody item => item.Version.UpdatedAt,
        SystemDescriptionReviewedBody item => item.Review.ReviewedAt,
        SystemDescriptionApprovedBody item => item.Approval.ApprovedAt,
        SystemDescriptionNoChangeRecordedBody item => item.Decision.DecidedAt,
        SystemDescriptionBoundBody item => item.Binding.BoundAt,
        _ => throw new ImmutableContentIntegrityException("The description mutation has another attribution kind."),
    };
}
''')
# Factory exact fields are generated from the selected catalog; extra authority fields are additive.
rows=json.loads((P/'target-event-contracts.json').read_text());factories=[]
for row in rows:
 name=row['event'];field=row['contentSchemas'][0]['field'];body=name+'Body'
 args=[]
 for f in row['fields']:
  key=f['name'];args.append({'TenantId':'h.TenantId','ProgramId':'h.ProgramId','SystemDescriptionId':'h.SystemDescriptionId','AggregateRevision':'h.Revision',field:'frozen.Payload','OccurredAt':'operation.AcceptedAt','Operation':'operation','FirstResponse':'first','OperationResult':'result'}[key])
 args+=['h','frozen.CurrentVersion','sequence','frozen.Changed ? 1 : 0','member']
 factories.append('            '+body+' => new '+name+'('+','.join(args)+'),')
put(K+'SystemDescriptionFactFactory.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public static class SystemDescriptionFactFactory
{
    public static DomainEvent Create(FrozenSystemDescriptionMutation frozen,long sequence,OperationProvenance operation,
        ImmutableContentRef first,ImmutableContentRef result)
    {
        if (!Uuid.TryParse(operation.Actor.Id,out var member))
            throw new InvalidOperationException("A description command requires its member actor.");
        var h = frozen.Header;
        return frozen.Mutation switch
        {
'''+ '\n'.join(factories)+'''
            _ => throw new InvalidOperationException("The description mutation has another business kind."),
        };
    }
}
''')
print('core content saved')
