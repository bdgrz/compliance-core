using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Programs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Identified authored intent over its exact selected owner/version scope.</summary>
[Discriminator("bdgrz.system-description.bind-system-description-to-examination", 2)]
public sealed record BindSystemDescriptionToExamination(Uuid CommandId, Uuid TenantId, Uuid ProgramId, Uuid DescriptionId, long Version, Uuid ExaminationId, string BindingPurpose, long ExpectedRevision) : IRequest, IIdentifiedRequest, IProgramScopedRequest, IClientManagementMutationRequest
{
    Uuid IIdentifiedRequest.RequestId => CommandId;
}
