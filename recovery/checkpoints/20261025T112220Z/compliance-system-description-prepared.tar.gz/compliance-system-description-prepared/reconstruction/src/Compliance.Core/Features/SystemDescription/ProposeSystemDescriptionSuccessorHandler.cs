using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public sealed class ProposeSystemDescriptionSuccessorHandler(SystemDescriptionOperations operations) : IRequestHandler<ProposeSystemDescriptionSuccessor>
{
    public ValueTask<Result> HandleAsync(IRequestContext<ProposeSystemDescriptionSuccessor> context,CancellationToken ct)
    {
        var request = context.Request;
        return operations.ExecuteAsync(context,request.TenantId,request.ProgramId,request.DescriptionId,request.CommandId,
            nameof(ProposeSystemDescriptionSuccessor),request.ExpectedRevision,(snapshot,operation,token) =>
            {
                Uuid.TryParse(operation.Actor.Id,out var member);
                return ValueTask.FromResult(SystemDescriptionOperations.Outcome(snapshot.Rules.ProposeSuccessor(request.ExpectedRevision,
                    request.CommandId,snapshot.CurrentVersion!.Content,request.ChangeReason,member,operation.Actor.Display,operation.AcceptedAt)));
            },null,ct);
    }
}
