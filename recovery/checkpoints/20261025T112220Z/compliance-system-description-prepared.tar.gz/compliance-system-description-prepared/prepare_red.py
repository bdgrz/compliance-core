from pathlib import Path
import difflib
P=Path('/tmp/compliance-system-description-prepared');T='test/Compliance.Tests/Features/SystemDescription/'
p=P/'base'/T/'SystemDescriptionTests.cs';before=p.read_text();needle='    [Fact]\n'
new='''    [Fact]
    public void ShouldRetainCompleteNarrativeGivenValidContentExceedsOldEventEnvelope()
    {
        // Arrange
        var description = new SystemDescriptionAggregate(TenantId,ProgramId,DescriptionId);
        var content = Content() with { Sections = Content().Sections.Select(section => section with
        { Content = new string('x',6000) }).ToArray() };

        // Act
        var recorded = description.Create(Uuid.CreateVersion4(),TypeIScope(),content,AuthorId,"Author",Now);

        // Assert
        Assert.Null(recorded);
        Assert.Equal(72000,description.CurrentVersion!.Content.Sections.Sum(section => section.Content.Length));
    }

'''
after=before.replace(needle,new+needle,1);(P/'red-source-tests.cs').write_text(after)
existing=P/'work'/T/'SystemDescriptionTests.cs';existing.write_text(after)
# A standalone old-surface export regression needs no native models or new command signature scaffolding.
start=before.index('    static SystemDescriptionDraftContent Content()');end=before.index('    static SystemDescriptionSection[] WithSection',start);content=before[start:end]
red='''using Bdgrz.Compliance.Features.SystemDescription;
using Cntryl.Portia;
using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;

namespace Bdgrz.Compliance.Tests.Features.SystemDescription;

public sealed class SystemDescriptionExportBoundaryTests
{
    static readonly Uuid TenantId = Uuid.CreateVersion4();
    static readonly Uuid ProgramId = Uuid.CreateVersion4();
    static readonly Uuid DescriptionId = Uuid.CreateVersion4();
    static readonly Uuid ExaminationId = Uuid.CreateVersion4();
    static readonly Uuid BaselineId = Uuid.CreateVersion4();
    static readonly Uuid AuthorId = Uuid.CreateVersion4();
    static readonly Uuid ReviewerId = Uuid.CreateVersion4();
    static readonly Uuid ApproverId = Uuid.CreateVersion4();
    static readonly DateTimeOffset Now = new(2026,10,24,12,0,0,TimeSpan.Zero);

    [Fact]
    public void ShouldKeepBusinessRevisionGivenIndependentTechnicalExport()
    {
        // Arrange
        var description = new SystemDescriptionAggregate(TenantId,ProgramId,DescriptionId);
        Assert.Null(description.Create(Uuid.CreateVersion4(),new SystemDescriptionScope("type_i",ExaminationId,BaselineId,null,null),
            Content(),AuthorId,"Author",Now));
        Assert.Null(description.Review(1,ReviewerId,"Reviewer","approve","Reviewed exact version",Now.AddMinutes(1)));
        Assert.Null(description.Approve(1,ApproverId,"Approver","Management approved",Now.AddMinutes(2)));
        var before = description.Revision;

        // Act
        var generated = description.GenerateExport(1,Uuid.CreateVersion4(),"pdf","exact-version-export",ApproverId,"Approver",Now.AddMinutes(3));

        // Assert
        Assert.Null(generated);
        Assert.Equal(before,description.Revision);
    }

'''+content+'}\n'
(P/'red-export-tests.cs').write_text(red)
(P/'work'/T/'SystemDescriptionExportBoundaryTests.cs').write_text(red)
patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+T+'SystemDescriptionTests.cs',tofile='b/'+T+'SystemDescriptionTests.cs'))
patch+=''.join(difflib.unified_diff([],red.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+T+'SystemDescriptionExportBoundaryTests.cs'))
(P/'behavioral-red.patch').write_text(patch)
(P/'behavioral-red.md').write_text('''Standalone old-API RED sequence (no new native model dependencies):

- `FullyQualifiedName~SystemDescriptionTests.ShouldRetainCompleteNarrativeGivenValidContentExceedsOldEventEnvelope`
- `FullyQualifiedName~SystemDescriptionExportBoundaryTests.ShouldKeepBusinessRevisionGivenIndependentTechnicalExport`

The first supplies valid 12 × 6,000-character section bodies, below the per-section limit, and demonstrates the artificial 48 KiB event rejection. The second demonstrates that the current technical export increments the description business revision. Reverse the standalone patch before applying full implementation/tests. Both names remain in the migrated acceptance suite. Parent owns all runtime.
''')
