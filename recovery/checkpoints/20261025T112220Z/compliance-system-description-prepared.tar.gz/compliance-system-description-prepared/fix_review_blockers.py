from pathlib import Path
P=Path('/tmp/compliance-system-description-prepared');R=P/'work';K='src/Compliance.Core/Features/SystemDescription/'
# Root provenance is explicit even though the general helper permits inferred FirstOwner for older roots.
p=R/(K+'SystemDescriptionOperations.cs');s=p.read_text().replace('''        var operation = OwnerProvenance.For(new SystemDescription(tenant,program,description),command,kind,''','''        var target = new SystemDescription(tenant,program,description);
        var operation = OwnerProvenance.For(target,command,kind,''').replace('AuthoredIntentDigest.Compute(context.Request),clock.GetUtcNow());','AuthoredIntentDigest.Compute(context.Request),clock.GetUtcNow()) with { FirstOwner = target.Stream };');p.write_text(s)
p=R/'test/Compliance.Tests/Features/SystemDescription/DescriptionSeeds.cs';s=p.read_text().replace('AuthoredIntentDigest.Compute(rules.Read()),SystemDescriptionContent.At(value));','AuthoredIntentDigest.Compute(rules.Read()),SystemDescriptionContent.At(value)) with { FirstOwner = owner.Stream };');p.write_text(s)
# Exact proof metadata and stream identity must agree with both the reader result and typed payload owner.
p=R/(K+'SystemDescriptionSnapshotSources.cs');s=p.read_text().replace('''            if (claimed.Fact.Stream.Realm != tenant.ToString())''','''            if (claimed.Fact.Stream.Realm != tenant.ToString() || claimed.Fact.EventId == Uuid.Empty || claimed.Fact.AggregateVersion == 0)''')
s=s.replace('''                    resolvedFact = record.Event;''','''                {
                    if (record.Stream != claimed.Fact.Stream)
                        throw new ImmutableContentIntegrityException("The description source resolver returned another exact native stream.");
                    resolvedFact = record.Event;
                }''')
s=s.replace('''            case TypeIBaselineFrozen frozen when scope.Stage == "type_i":''','''            case TypeIBaselineFrozen frozen when scope.Stage == "type_i" &&
                proof.Facts[0].Fact.Stream == new ExaminationEngagement(tenant,program,scope.ExaminationId).Stream:''').replace('''            case TypeIBaselineAmended amended when scope.Stage == "type_i":''','''            case TypeIBaselineAmended amended when scope.Stage == "type_i" &&
                proof.Facts[0].Fact.Stream == new ExaminationEngagement(tenant,program,scope.ExaminationId).Stream:''')
s=s.replace('''                period.Header.ExaminationId == scope.ExaminationId:''','''                period.Header.ExaminationId == scope.ExaminationId && scope.TypeIIPeriodId is { } periodId &&
                proof.Facts[0].Fact.Stream == new TypeIIPeriod(tenant,program,periodId).Stream:''')
s=s.replace('''                    plan.SubjectId != state.TypeIIPlanId || plan.State.CurrentVersionNumber''','''                    plan.SubjectId != state.TypeIIPlanId || proof.Facts[1].Fact.Stream != new TypeIIPlan(tenant,program,state.TypeIIPlanId).Stream || plan.State.CurrentVersionNumber''');p.write_text(s)
# Use the installed Fitz retry classifier; requested cancellation never enters forward recovery.
p=R/(K+'SystemDescriptionExportProcess.cs');s=p.read_text();s='using Cntryl.Fitz;\n'+s
s=s.replace('''        catch (IOException)
        {''','''        catch (Exception exception) when (!ct.IsCancellationRequested && Retryability.IsRetryable(exception))
        {''')
s=s.replace('''            var recovered = await processes.ReadAsync(request.TenantId,id,request.CommandId,ct).ConfigureAwait(false);
            if (recovered is not null && Matches(recovered,binding,request.ProgramId,request.DescriptionId,id) && recovered.State == "completed")
                return await ReplayAsync(recovered,ct).ConfigureAwait(false);
            return Failure(RequestErrorKind.Conflict,"The export storage outcome is pending. Retry the original operation.",true);''','''            try
            {
                var recovered = await processes.ReadAsync(request.TenantId,id,request.CommandId,ct).ConfigureAwait(false);
                if (recovered is not null && Matches(recovered,binding,request.ProgramId,request.DescriptionId,id) && recovered.State == "completed")
                    return await ReplayAsync(recovered,ct).ConfigureAwait(false);
            }
            catch (Exception recoveryFailure) when (!ct.IsCancellationRequested && Retryability.IsRetryable(recoveryFailure))
            {
                // Outage during recovery is still pending; a later invocation resumes the sealed original intent.
            }
            return Failure(RequestErrorKind.Conflict,"The export storage outcome is pending. Retry the original operation.",true);''')
s=s.replace('''                if (exception is not ImmutableContentUnavailableException && current.State != "failed")
                    await processes.ReplaceAsync(current,current with { State = "failed",FailureCode = "source_integrity" },ct).ConfigureAwait(false);''','''                if (exception is not ImmutableContentUnavailableException && current.State != "failed")
                {
                    var closed = await processes.ReplaceAsync(current,current with { State = "failed",FailureCode = "source_integrity" },ct).ConfigureAwait(false);
                    if (closed.IsSuccess && closed.Value.State == "completed")
                        return await ReplayAsync(closed.Value,ct).ConfigureAwait(false);
                }''')
s=s.replace('request.Version < 1 || request.Format','request.Version < 1 || display.Length > 200 || request.Format')
s=s.replace('''intent.VersionSource.EventId == Uuid.Empty || intent.ApprovalSource.EventId == Uuid.Empty)''','''intent.VersionSource.EventId == Uuid.Empty || intent.ApprovalSource.EventId == Uuid.Empty ||
            intent.VersionSource.AggregateVersion == 0 || intent.ApprovalSource.AggregateVersion == 0)''');p.write_text(s)
# Reconcile the same exact producer issue in the frozen queued Change package, without touching main.
Q=Path('/tmp/compliance-significant-change-prepared/work');K2='src/Compliance.Core/Features/Changes/'
p=Q/(K2+'SignificantChangeOperations.cs');s=p.read_text().replace('''        var operation = OwnerProvenance.For(new SignificantChange(tenantId,programId,changeId),commandId,kind,actor,''','''        var target = new SignificantChange(tenantId,programId,changeId);
        var operation = OwnerProvenance.For(target,commandId,kind,actor,''').replace('AuthoredIntentDigest.Compute(context.Request),clock.GetUtcNow());','AuthoredIntentDigest.Compute(context.Request),clock.GetUtcNow()) with { FirstOwner = target.Stream };');p.write_text(s)
p=Q/'test/Compliance.Tests/Features/Changes/ChangeSeeds.cs';s=p.read_text().replace('AuthoredIntentDigest.Compute(state),state.UpdatedAt);','AuthoredIntentDigest.Compute(state),state.UpdatedAt) with { FirstOwner = owner.Stream };');p.write_text(s)
