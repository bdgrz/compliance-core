from pathlib import Path
r=Path('/tmp/compliance-system-description-prepared/work');core=r/'src/Compliance.Core/Features'
p=core/'Changes/SystemDescriptionDecisionCorrelation.cs';s=p.read_text().replace('using Cntryl.Portia;','using Cntryl.Portia;\nusing Bdgrz.Compliance.Features.SystemDescription;').replace('SystemDescriptionAggregate description','SystemDescriptionReadSnapshot description').replace('using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;\n','');p.write_text(s)
p=core/'Changes/RecordSignificantChangeSystemDescriptionDecisionHandler.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.SystemDescription;','using Bdgrz.Compliance.Features.SystemDescription;\nusing Bdgrz.Compliance.Features.Content;').replace('SignificantChangeOperations operations, IAggregateReader reader)','SignificantChangeOperations operations, SystemDescriptionReader descriptions)')
s=s.replace('                var description = await reader.HydrateAsync(new SystemDescriptionAggregate(request.TenantId,\n                    request.ProgramId,request.SystemDescriptionId),token).ConfigureAwait(false);','''                SystemDescriptionReadSnapshot description;
                try
                {
                    description = await descriptions.ReadAsync(request.TenantId, request.ProgramId, request.SystemDescriptionId, token).ConfigureAwait(false);
                }
                catch (ImmutableContentIntegrityException failure)
                {
                    return Result.Failure(SystemDescriptionReadFailure.Of(failure));
                }''').replace('using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;\n','');p.write_text(s)
p=core/'Incidents/RecordComplianceIncidentSystemDescriptionDecisionHandler.cs';s=p.read_text().replace('IAggregateReader reader, IImmutableContentStore content, TimeProvider clock)','SystemDescriptionReader descriptions, IImmutableContentStore content, TimeProvider clock)')
s=s.replace('            var description = await reader.HydrateAsync(new SystemDescriptionAggregate(request.TenantId,\n                request.ProgramId, request.SystemDescriptionId), token).ConfigureAwait(false);','''            SystemDescriptionReadSnapshot description;
            try
            {
                description = await descriptions.ReadAsync(request.TenantId, request.ProgramId, request.SystemDescriptionId, token).ConfigureAwait(false);
            }
            catch (ImmutableContentIntegrityException failure)
            {
                return Result<FirstResponseDescriptor>.Failure(SystemDescriptionReadFailure.Of(failure));
            }''').replace('using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;\n','');p.write_text(s)
p=core/'Operations/TypeIIPlanSourceValidator.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.AccessControl;','using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Content;').replace('ControlOperationsReader operating, Uuid tenantId,','ControlOperationsReader operating, SystemDescriptionReader descriptions, Uuid tenantId,')
s=s.replace('        var description = await reader.HydrateAsync(new SystemDescriptionAggregate(tenantId,\n            programId, descriptionSource.RecordId), ct).ConfigureAwait(false);','''        SystemDescriptionReadSnapshot description;
        try
        {
            description = await descriptions.ReadAsync(tenantId, programId, descriptionSource.RecordId, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result<TypeIIPlanSourceValidation>.Failure(SystemDescriptionReadFailure.Of(failure));
        }''').replace('using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;\n','');p.write_text(s)
for name in ['StartTypeIIObservationPeriodHandler','ProposeTypeIIOperatingPlanHandler']:
 p=core/f'Operations/{name}.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.SystemDescription;\n'+s
 if name.startswith('Start'):s=s.replace('IImmutableContentStore content, TimeProvider clock)','IImmutableContentStore content, TimeProvider clock, SystemDescriptionReader descriptions)')
 else:s=s.replace('ControlOperationsReader operating, TimeProvider clock)','ControlOperationsReader operating, TimeProvider clock, SystemDescriptionReader descriptions)')
 s=s.replace('TypeIIPlanSourceValidator.ValidateAsync(reader, controlSources, findings, operating,','TypeIIPlanSourceValidator.ValidateAsync(reader, controlSources, findings, operating, descriptions,');p.write_text(s)
p=core/'Examinations/RecordManagementAssertionHandler.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.AuditPackages;','using Bdgrz.Compliance.Features.AuditPackages;\nusing Bdgrz.Compliance.Features.Content;').replace('TypeIIPeriodReader periods, TimeProvider clock)','TypeIIPeriodReader periods, TimeProvider clock, SystemDescriptionReader descriptions)')
s=s.replace('        var description = await reader.HydrateAsync(new SystemDescriptionAggregate(request.TenantId,\n            request.ProgramId, descriptionId), ct).ConfigureAwait(false);','''        SystemDescriptionReadSnapshot description;
        try
        {
            description = await descriptions.ReadAsync(request.TenantId, request.ProgramId, descriptionId, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException failure)
        {
            return Result.Failure(SystemDescriptionReadFailure.Of(failure));
        }''').replace('using SystemDescriptionAggregate = Bdgrz.Compliance.Features.SystemDescription.SystemDescription;\n','');p.write_text(s)
p=core/'Changes/SystemDescriptionDecisionReactor.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.Incidents;','using Bdgrz.Compliance.Features.Incidents;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;').replace('IProjectionCheckpointStore checkpoints, IRequestBus bus, IAggregateReader reader,','IProjectionCheckpointStore checkpoints, IRequestBus bus, IAggregateReader reader,\n    SystemDescriptionReader descriptions, IImmutableContentStore content,')
s=s.replace('        var description = await reader.HydrateAsync(new SystemDescriptionAggregate(ev.TenantId,\n            ev.ProgramId, ev.SystemDescriptionId), ct).ConfigureAwait(false);','        var description = await descriptions.ReadAsync(ev.TenantId, ev.ProgramId, ev.SystemDescriptionId, ct).ConfigureAwait(false);')
# Source matching must precede the no-op guard; malformed receipts cannot silently advance a checkpoint.
a=s.index('        var version = description.FindVersion(ev.Approval.VersionId);');s=s[:a]+'''        RequireSource(description, context.Source.Stream, ev);
        if (ev.ChangeCount == 0)
            return;
        var approval = ((SystemDescriptionApprovedBody)await SystemDescriptionContent.ReadMutationAsync(content, ev, ct).ConfigureAwait(false)).Approval;
'''+s[a:];s=s.replace('ev.Approval','approval')
a=s.index('        if (description.FindVersion(ev.Decision.VersionId)');s=s[:a]+'''        RequireSource(description, context.Source.Stream, ev);
        if (ev.ChangeCount == 0)
            return;
        var decision = ((SystemDescriptionNoChangeRecordedBody)await SystemDescriptionContent.ReadMutationAsync(content, ev, ct).ConfigureAwait(false)).Decision;
'''+s[a:];s=s.replace('ev.Decision','decision')
a=s.index('    void ValidateSource(');s=s[:a]+'''    static void RequireSource(SystemDescriptionReadSnapshot description, EventStreamAddress stream, DomainEvent source)
    {
        var actual = description.Facts.SingleOrDefault(fact => fact.Metadata.EventId == source.Metadata.EventId);
        if (actual is null)
            throw new ImmutableContentUnavailableException("The exact system-description decision source is not visible yet.");
        if (actual.GetType() != source.GetType() || NativeFactReference.Of(stream, actual) != NativeFactReference.Of(stream, source) ||
            ContentDigest.Sha256(actual, actual.GetType()) != ContentDigest.Sha256(source, source.GetType()))
            throw new ImmutableContentIntegrityException("The decision reaction differs from its exact native source fact.");
    }

'''+s[a:];p.write_text(s)
