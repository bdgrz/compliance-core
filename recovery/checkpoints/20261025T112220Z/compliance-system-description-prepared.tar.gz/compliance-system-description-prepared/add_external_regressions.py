from pathlib import Path
r=Path('/tmp/compliance-system-description-prepared/work/test/Compliance.Tests')
p=r/'Features/Examinations/RecordManagementAssertionHandlerTests.cs';s=p.read_text();a=s.index('    [Theory]');s=s[:a]+'''    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ShouldRetryUnavailableDescriptionContentAndRefuseCorruptionGivenAssertionSources(bool unavailable)
    {
        // Arrange
        await using var fixture = new Fixture();
        var sources = await fixture.SeedSourcesAsync();
        var descriptions = new SystemDescriptionReader(fixture.Reader, fixture.PeriodEvents, new FailingPackageContentStore(unavailable));
        var handler = new RecordManagementAssertionHandler(fixture.Executor, fixture.Reader, fixture.Packages,
            fixture.Periods, fixture.Clock, descriptions);

        // Act
        var result = await handler.HandleAsync(fixture.Context(fixture.Request(sources.Content)), CancellationToken.None);
        var saved = await fixture.Reader.HydrateAsync(new ManagementAssertionAggregate(fixture.TenantId, fixture.ProgramId, fixture.AssertionId));

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
        Assert.Equal(unavailable, result.Error!.IsTransient);
        Assert.Null(saved.Current);
    }

'''+s[a:];p.write_text(s)
p=r/'Features/Operations/ObservationPeriodReadHandlerTests.cs';s=p.read_text();s='using Bdgrz.Compliance.Tests.Features.SystemDescription;\n'+s;a=s.index('    [Fact]');s=s[:a]+'''    [Fact]
    public async Task ShouldInvalidateExactNativeDescriptionVersionGivenCloseAmendmentMaterialCapture()
    {
        // Arrange
        await using var fixture = new Fixture();
        var period = await fixture.SeedClosedAsync();
        var prior = period.Current!.CloseSnapshots[^1];
        var id = Uuid.CreateVersion4();
        var version = Uuid.CreateVersion4();
        var description = new SystemDescriptionRules(fixture.Tenant, fixture.Program, id);
        Assert.Null(description.Create(version, new SystemDescriptionScope("type_ii", period.Current.ExaminationId,
            Uuid.CreateVersion4(), period.Id, prior.CloseSnapshotId), SystemDescriptionNativeFixture.Body(), fixture.Member,
            "Description author", prior.RecordedAt.AddHours(1)));
        await DescriptionSeeds.WriteAsync(fixture.Writer, fixture.Content, description);

        // Act
        await fixture.AmendClosedAsync(period);

        // Assert
        var affected = period.Current.CloseSnapshots[^1].AffectedExaminationMaterialIds;
        Assert.Contains(id, affected);
        Assert.Contains(version, affected);
        Assert.Contains(prior.CloseSnapshotId, affected);
    }

'''+s[a:];p.write_text(s)
