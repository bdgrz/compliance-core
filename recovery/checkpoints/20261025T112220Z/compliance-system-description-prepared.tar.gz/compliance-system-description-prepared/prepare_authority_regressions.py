from pathlib import Path
import difflib
P=Path('/tmp/compliance-system-description-prepared');T='test/Compliance.Tests/Features/SystemDescription/'
new='''    [Fact]
    public void ShouldRetainAllGovernedSourcesAndPeriodChangesGivenLargeValidDescription()
    {
        // Arrange
        var description = new SystemDescriptionAggregate(TenantId,ProgramId,DescriptionId);
        var sources = Enumerable.Range(0,1000).Select(_ => new SystemDescriptionSourceReference("control",Uuid.CreateVersion4(),
            Uuid.CreateVersion4(),1,new string('a',64),"current")).ToArray();
        var changes = Enumerable.Range(0,300).Select(_ => new SystemDescriptionPeriodChange(Uuid.CreateVersion4(),true,new string('b',64))).ToArray();
        var content = Content() with { Sources = sources,PeriodChanges = changes,SignificantChangeIds = changes.Select(item => item.ChangeId).ToArray() };
        var scope = new SystemDescriptionScope("type_ii",ExaminationId,BaselineId,Uuid.CreateVersion4(),Uuid.CreateVersion4());

        // Act
        var recorded = description.Create(Uuid.CreateVersion4(),scope,content,AuthorId,"Author",Now);

        // Assert
        Assert.Null(recorded);
        Assert.Equal(1000,description.CurrentVersion!.Content.Sources.Count);
        Assert.Equal(300,description.CurrentVersion.Content.PeriodChanges.Count);
        Assert.Equal(300,description.CurrentVersion.Content.SignificantChangeIds.Count);
    }

'''
p=P/'red-source-tests.cs';s=p.read_text();s=s.replace('    [Fact]\n',new+'    [Fact]\n',1);p.write_text(s)
p=P/'work'/T/'SystemDescriptionTests.cs';s=p.read_text().replace('    [Fact]\n',new+'    [Fact]\n',1);p.write_text(s)
before=(P/'base'/T/'SystemDescriptionTests.cs').read_text();after=(P/'red-source-tests.cs').read_text();red=(P/'red-export-tests.cs').read_text();patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+T+'SystemDescriptionTests.cs',tofile='b/'+T+'SystemDescriptionTests.cs'))+''.join(difflib.unified_diff([],red.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+T+'SystemDescriptionExportBoundaryTests.cs'));(P/'behavioral-red.patch').write_text(patch)
p=P/'behavioral-red.md';s=p.read_text();s+='\n- `FullyQualifiedName~SystemDescriptionTests.ShouldRetainAllGovernedSourcesAndPeriodChangesGivenLargeValidDescription` removes the invented 512-source/200-period-change caps; 1,000 exact sources and 300 material changes remain complete in native immutable content.\n';p.write_text(s)
p=P/'work'/T/'SystemDescriptionNativeTests.cs';s=p.read_text();needle='    sealed class FailedContent';tests='''    [Fact]
    public async Task ShouldEditCurrentDraftWithoutLoadingHistoricalNarrativeGivenOlderSourceBodiesUnavailable()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        await fixture.SeedAsync();
        var original = Assert.IsType<SystemDescriptionDraftCreated>(Assert.Single(await fixture.FactsAsync()));
        Assert.True((await new ReviseSystemDescriptionDraftHandler(fixture.Operations).HandleAsync(fixture.Context(new ReviseSystemDescriptionDraft(
            Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Description,1,"Current second version",SystemDescriptionNativeFixture.Body().Sections,"First revision")),CancellationToken.None)).IsSuccess);
        var unavailable = new HistoricalUnavailableContent(fixture.Content,[original.CurrentVersionContent.ContentId,original.VersionContent.ContentId,
            original.CurrentAuthorityContent.ContentId]);
        var reader = new SystemDescriptionReader(fixture.Reader,fixture.Events,unavailable);
        var operations = new SystemDescriptionOperations(new NativeOperationExecutor(fixture.Reader,fixture.Executor,unavailable),reader,unavailable,fixture.Clock);

        // Act
        var revised = await new ReviseSystemDescriptionDraftHandler(operations).HandleAsync(fixture.Context(new ReviseSystemDescriptionDraft(
            Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Description,2,"Current third version",SystemDescriptionNativeFixture.Body().Sections,"Second revision")),CancellationToken.None);

        // Assert
        Assert.True(revised.IsSuccess,revised.Error?.Message);
        Assert.Equal(0,unavailable.BlockedReads);
        var current = await fixture.Descriptions.ReadAsync(fixture.Tenant,fixture.Program,fixture.Description);
        Assert.Equal(3,current.View.Versions.Count);Assert.Equal("Current third version",current.CurrentVersion!.Content.Title);
        await Assert.ThrowsAsync<ImmutableContentUnavailableException>(async () => await reader.ReadAsync(fixture.Tenant,fixture.Program,fixture.Description));
        Assert.Equal(1,unavailable.BlockedReads);
    }

    [Fact]
    public async Task ShouldRejectHistoricalVersionIdentityReuseGivenCurrentPreparationOmitsOldNarrative()
    {
        // Arrange
        await using var fixture = new SystemDescriptionNativeFixture();
        var initial = await fixture.SeedAsync();
        var versionId = initial.CurrentVersion!.SystemDescriptionVersionId;
        Assert.True((await new ReviseSystemDescriptionDraftHandler(fixture.Operations).HandleAsync(fixture.Context(new ReviseSystemDescriptionDraft(
            Uuid.CreateVersion4(),fixture.Tenant,fixture.Program,fixture.Description,1,"Current second version",SystemDescriptionNativeFixture.Body().Sections,"First revision")),CancellationToken.None)).IsSuccess);

        // Act
        var result = await new ReviseSystemDescriptionDraftHandler(fixture.Operations).HandleAsync(fixture.Context(new ReviseSystemDescriptionDraft(
            versionId,fixture.Tenant,fixture.Program,fixture.Description,2,"Reused identity",SystemDescriptionNativeFixture.Body().Sections,"Must refuse")),CancellationToken.None);

        // Assert
        Assert.False(result.IsSuccess);Assert.Equal(RequestErrorKind.Conflict,result.Error!.Kind);Assert.False(result.Error.IsTransient);
        Assert.Equal(2,(await fixture.FactsAsync()).Count);
    }

    sealed class HistoricalUnavailableContent(IImmutableContentStore inner,IReadOnlyList<Uuid> blocked) : IImmutableContentStore
    {
        public int BlockedReads { get; private set; }
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm,Uuid id,string schema,string mediaType,ReadOnlyMemory<byte> bytes,CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm,id,schema,mediaType,bytes,ct);
        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm,ImmutableContentRef reference,CancellationToken ct = default)
        {
            if (blocked.Contains(reference.ContentId))
            { BlockedReads++;throw new ImmutableContentUnavailableException("Historical source intentionally unavailable"); }
            return inner.ReadVerifiedAsync(realm,reference,ct);
        }
    }
''';assert needle in s;s=s.replace(needle,tests+'\n'+needle);p.write_text(s)
