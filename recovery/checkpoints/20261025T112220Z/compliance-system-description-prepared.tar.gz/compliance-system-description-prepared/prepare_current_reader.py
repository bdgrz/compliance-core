from pathlib import Path
P=Path('/tmp/compliance-system-description-prepared');W=P/'work';K=W/'src/Compliance.Core/Features/SystemDescription'
p=K/'SystemDescriptionReader.cs';s=p.read_text();needle='    internal async ValueTask<SystemDescriptionReadSnapshot> ReadAsync(SystemDescription owner,Uuid programId,CancellationToken ct)\n'
current='''    internal async ValueTask<SystemDescriptionReadSnapshot> ReadCurrentAsync(SystemDescription owner,Uuid programId,CancellationToken ct)
    {
        if (owner.Header is not { } header || owner.ProgramId != programId)
            return new(owner,new SystemDescriptionRules(owner.TenantId,programId,owner.Id),[]);
        if (owner.CurrentAuthorityContent is not { } authorityRef || owner.CurrentVersionContent is not { } currentRef ||
            authorityRef.Schema != SystemDescriptionAuthority.Schema || currentRef.Schema != SystemDescriptionContent.CurrentSchema)
            throw new ImmutableContentIntegrityException("The description lacks its exact native current authority.");
        var authority = await content.ReadJsonAsync<SystemDescriptionCurrentAuthority>(owner.TenantId.ToString(),authorityRef,ct).ConfigureAwait(false);
        var current = await content.ReadJsonAsync<SystemDescriptionVersionView>(owner.TenantId.ToString(),currentRef,ct).ConfigureAwait(false);
        if (authority.CurrentVersionContent != currentRef || !SystemDescriptionAuthority.MatchesCurrent(header,authority,current))
            throw new ImmutableContentIntegrityException("The description current authority differs from its compact native header and narrative.");
        if (owner.SourceSnapshotContent is { } proof)
            await new SystemDescriptionSnapshotSources(events,content).VerifyAsync(owner.TenantId,programId,current.Scope,
                current.Content.Sources,proof,ct).ConfigureAwait(false);
        var rules = SystemDescriptionRules.FromView(SystemDescriptionAuthority.CurrentView(header,authority,current));
        rules.SourceNativeSequence = owner.NativeSequence;
        rules.SourcePhysicalPosition = owner.CommittedStreamPosition;
        return new(owner,rules,[]) { CurrentAuthority = authority };
    }
'''
s=s.replace(needle,current+needle)
s=s.replace('        ISystemDescriptionFact? last = null;','        ISystemDescriptionFact? last = null;\n        SystemDescriptionCurrentAuthority? authority = null;')
s=s.replace('            var frozen = new FrozenSystemDescriptionMutation(before,after.Read(),fact.Header,fact.CurrentVersionContent,', '''            if (fact.CurrentAuthorityContent.Schema != SystemDescriptionAuthority.Schema)
                throw new ImmutableContentIntegrityException("The description decision authority has another immutable schema.");
            var nextAuthority = await content.ReadJsonAsync<SystemDescriptionCurrentAuthority>(owner.TenantId.ToString(),fact.CurrentAuthorityContent,ct).ConfigureAwait(false);
            var frozen = new FrozenSystemDescriptionMutation(before,after.Read(),fact.Header,fact.CurrentVersionContent,''')
s=s.replace('SystemDescriptionContent.Payload(fact),mutation,fact.Operation.CommandKind,fact.ChangeCount == 1);','''SystemDescriptionContent.Payload(fact),mutation,fact.Operation.CommandKind,fact.ChangeCount == 1)
            { BeforeAuthority = authority,Authority = nextAuthority,AuthorityContent = fact.CurrentAuthorityContent };''')
s=s.replace('            last = fact;','            last = fact;\n            authority = nextAuthority;')
s=s.replace('last.CurrentVersionContent != owner.CurrentVersionContent)','last.CurrentVersionContent != owner.CurrentVersionContent || last.CurrentAuthorityContent != owner.CurrentAuthorityContent)')
s=s.replace('        return new(owner,rules,facts.AsReadOnly());','        return new(owner,rules,facts.AsReadOnly()) { CurrentAuthority = authority };');p.write_text(s)
# Add source-generated serializer roots required by exact current-authority body hashes.
p=P/'shared-work/src/Compliance.Core/ComplianceCoreJsonContext.cs';s=p.read_text();needle='[JsonSerializable(typeof(SystemDescriptionAuthorityHeader))]';assert needle in s
s=s.replace(needle,needle+'\n[JsonSerializable(typeof(SystemDescriptionCurrentAuthority))]\n[JsonSerializable(typeof(SystemDescriptionVersionToken))]\n[JsonSerializable(typeof(IReadOnlyList<SystemDescriptionVersionToken>))]');p.write_text(s)
# Update audit metadata without erasing current shared main baseline.
p=P/'shared-wiring-deltas.json';import json;j=json.loads(p.read_text());j['current_authority_roots']=['SystemDescriptionCurrentAuthority','SystemDescriptionVersionToken','IReadOnlyList<SystemDescriptionVersionToken>'];p.write_text(json.dumps(j,indent=2)+'\n')
