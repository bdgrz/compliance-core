from pathlib import Path
import re,json
P=Path('/tmp/compliance-system-description-prepared');R=P/'work';C='src/Compliance.Common/Features/SystemDescription/';K='src/Compliance.Core/Features/SystemDescription/'
def put(rel,s):
 p=R/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
# Keep the actual domain operations as a transient rules/read composition; native facts are compact refs.
s=(P/'base'/K/'SystemDescription.cs').read_text().replace('public sealed class SystemDescription : Aggregate','public sealed class SystemDescriptionRules').replace('public SystemDescription(Uuid tenantId, Uuid programId, Uuid descriptionId)\n        : base(descriptionId, new EventStreamAddress(tenantId.ToString(), "system-descriptions",\n            descriptionId.ToString()))','public SystemDescriptionRules(Uuid tenantId, Uuid programId, Uuid descriptionId)')
s=s.replace('        _tenantId = tenantId;','        Id = descriptionId;\n        Stream = new EventStreamAddress(tenantId.ToString(),SystemDescription.Area,descriptionId.ToString());\n        _tenantId = tenantId;',1)
names=['SystemDescriptionDraftCreated','SystemDescriptionDraftRevised','SystemDescriptionSourcesBound','SystemDescriptionReviewed','SystemDescriptionApproved','SystemDescriptionSuccessorProposed','SystemDescriptionNoChangeRecorded','SystemDescriptionBound']
# Export outcomes belong only to the independent process.
a=s.index('    public CommandFailure? GenerateExport(');b=s.index('    void Apply(SystemDescriptionDraftCreated',a);s=s[:a]+s[b:]
a=s.index('    void Apply(SystemDescriptionExportGenerated');b=s.index('    bool CanApprove',a);s=s[:a]+s[b:]
s=s.replace('    readonly List<SystemDescriptionExportView> _exports = [];\n','').replace('        On<SystemDescriptionExportGenerated>(Apply);\n','').replace('Array.AsReadOnly(_bindings.ToArray()), Array.AsReadOnly(_exports.ToArray()))','Array.AsReadOnly(_bindings.ToArray()), [])')
s=s.replace('    const int MaximumEventBytes = 48 * 1024;\n','')
s=re.sub(r'        if \(!Fits\(ev\)\)\n            return Invalid\("[^"\n]+"\);\n','',s)
a=s.index('    static bool Fits<T>');b=s.index('    static CommandFailure Invalid',a);s=s[:a]+s[b:]
for name in names:s=re.sub(r'\b'+name+r'\b',name+'Body',s)
i=s.index('    readonly Uuid _tenantId;');s=s[:i]+'''    readonly Dictionary<Type,Action<object>> _reducers = [];
    readonly List<object> _applied = [];
    readonly List<object> _pending = [];
    public Uuid Id { get; }
    public EventStreamAddress Stream { get; }
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;
    public long SourceNativeSequence { get; internal set; }
    public ulong SourcePhysicalPosition { get; internal set; }
    public IReadOnlyList<object> AppliedChanges => _applied.AsReadOnly();
    public IReadOnlyList<object> PendingChanges => _pending.AsReadOnly();
    public void ClearPendingChanges() => _pending.Clear();
    void On<T>(Action<T> reducer) where T : class => _reducers.Add(typeof(T),value => reducer((T)value));
    public void Apply(object value)
    {
        if (!_reducers.TryGetValue(value.GetType(),out var reduce))
            throw new InvalidOperationException("The description rule mutation has another kind.");
        reduce(value);
        _applied.Add(value);
    }
    internal void RaiseEvent(object value)
    {
        Apply(value);
        _pending.Add(value);
    }

'''+s[i:]
s=s.replace('One continuing system-description stream owns immutable narrative versions,','A transient rules/read composition reconstructs immutable narrative versions,')
put(K+'SystemDescriptionRules.cs',s)
rows=json.loads((P/'target-event-contracts.json').read_text())
for name in names:
 old=(P/'base'/C/(name+'.cs')).read_text();body=old.replace(name,name+'Body');body=re.sub(r'\[Discriminator\([^\n]+\)\]\n','',body).replace(' : DomainEvent;',';')
 put(K+name+'Body.cs',body)
 row=next(x for x in rows if x['event']==name);fields=row['fields']
 extra=[{'name':'Header','type':'SystemDescriptionAuthorityHeader'},{'name':'CurrentVersionContent','type':'ImmutableContentRef'},{'name':'NativeSequence','type':'long'},{'name':'ChangeCount','type':'int'},{'name':'ActorMemberId','type':'Uuid'}]
 args=',\n    '.join(x['type']+' '+x['name'] for x in fields+extra)
 put(C+name+'.cs',f'''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>One selected native fact, compact authority and exact immutable structured business payload.</summary>
[Discriminator("{row['discriminator']}", {row['discriminatorVersion']})]
public sealed record {name}({args}) : DomainEvent, ISystemDescriptionFact;
''')
put(C+'SystemDescriptionAuthorityHeader.cs','''using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Bounded current description authority; narrative arrays and history are verified immutable content.</summary>
public sealed record SystemDescriptionAuthorityHeader(Uuid TenantId,Uuid ProgramId,Uuid SystemDescriptionId,
    long Revision,long CurrentVersion,Uuid CurrentVersionId,Uuid? ParentVersionId,string Status,string Title,
    string ContentSha256,SystemDescriptionScope Scope,Uuid AuthorMemberId,DateTimeOffset VersionUpdatedAt,
    Uuid? LatestReviewId,Uuid? LatestReviewerMemberId,string? LatestReviewOutcome,
    long ReviewCount,long ApprovalCount,long NoChangeDecisionCount,string NoChangeDecisionsSha256,
    long BindingCount,string BindingsSha256,Uuid? LatestApprovedVersionId);
''')
put(C+'ISystemDescriptionFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public interface ISystemDescriptionFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid ProgramId { get; }
    Uuid SystemDescriptionId { get; }
    long AggregateRevision { get; }
    DateTimeOffset OccurredAt { get; }
    SystemDescriptionAuthorityHeader Header { get; }
    ImmutableContentRef CurrentVersionContent { get; }
    ImmutableContentRef? OperationResult { get; }
    long NativeSequence { get; }
    int ChangeCount { get; }
    Uuid ActorMemberId { get; }
}
''')
put(K+'SystemDescriptionReadSnapshot.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Explicit source-verified read composition, never aggregate command state.</summary>
public sealed record SystemDescriptionReadSnapshot(SystemDescription Owner,SystemDescriptionRules Rules,
    IReadOnlyList<DomainEvent> Facts)
{
    public SystemDescriptionView View => Rules.Read();
    public Uuid Id => Owner.Id;
    public Uuid TenantId => Owner.TenantId;
    public Uuid ProgramId => Owner.ProgramId;
    public long Revision => Rules.Revision;
    public EventStreamAddress Stream => Owner.Stream;
    public SystemDescriptionVersionView? CurrentVersion => Rules.CurrentVersion;
    public IReadOnlyList<SystemDescriptionReviewView> Reviews => Rules.Reviews;
    public IReadOnlyList<SystemDescriptionNoChangeDecisionView> NoChangeDecisions => Rules.NoChangeDecisions;
    public SystemDescriptionView Read() => View;
    public SystemDescriptionVersionView? FindVersion(long version) => Rules.FindVersion(version);
    public SystemDescriptionVersionView? FindVersion(Uuid versionId) => Rules.FindVersion(versionId);
    public SystemDescriptionApprovalView? FindApproval(Uuid versionId) => Rules.FindApproval(versionId);
}
''')
put(K+'SystemDescriptionVersionSource.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.SystemDescription;

/// <summary>Exact verified narrative version and authoritative native production/approval proofs.</summary>
public sealed record SystemDescriptionVersionSource(SystemDescriptionVersionView Version,ImmutableContentRef Content,
    NativeFactReference Source,NativeFactReference? ApprovalSource,SystemDescriptionApprovalView? Approval,
    long NativeSequence,ulong PhysicalPosition);
''')
put(K+'SystemDescriptionReadFailure.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.SystemDescription;

public static class SystemDescriptionReadFailure
{
    public static RequestError Of(ImmutableContentIntegrityException exception) => new(RequestErrorKind.Conflict,
        "The system description's exact immutable source cannot be verified.",exception is ImmutableContentUnavailableException);
}
''')
print('models saved')
