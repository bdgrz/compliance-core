from pathlib import Path
import json,hashlib,difflib
r=Path('/tmp/compliance-product-client-service-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');rows=json.loads((r/'baselines.json').read_text());pro=[]
selected=['src/Compliance.App/Program.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs','test/Compliance.Tests/E2E/ProgramE2ETests.cs']
for rel in selected:
 old=(r/'base'/rel).read_bytes();ours=(r/'work'/rel).read_bytes();current=(repo/rel).read_bytes()
 if current==old:continue
 for tree,data in [('pre-current-rebase-base',old),('pre-current-rebase-work',ours)]:
  p=r/tree/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
 s=current.decode();replacements=[]
 if rel.endswith('/Program.cs'):
  replacements=[
   ('MapPortiaPost<CreateClientService, ClientServiceRegistration>','MapPortiaPut<CreateClientService, ClientServiceRegistration>'),
   ('"/api/v1/tenants/{tenant_id}/programs/{program_id}/client-services", config => config.OnNativeResult()).WithNativeFirstResponse<CreateClientService>()','"/api/v1/tenants/{tenant_id}/programs/{program_id}/client-services/{service_id}", config => config.OnNativeResult()).WithNativeFirstResponse<CreateClientService>()'),
   ('"/api/v1/tenants/{tenant_id}/client-services/{service_id}", config => config.OnNativeResult()).WithNativeFirstResponse<ReviseClientService>()','"/api/v1/tenants/{tenant_id}/client-services/{service_id}/revisions/{command_id}", config => config.OnNativeResult()).WithNativeFirstResponse<ReviseClientService>()'),
   ('MapPortiaPost<RetireClientService>','MapPortiaPut<RetireClientService>'),
   ('"/api/v1/tenants/{tenant_id}/client-services/{service_id}/retirements", config => config.OnNativeResult()).WithNativeFirstResponse<RetireClientService>()','"/api/v1/tenants/{tenant_id}/client-services/{service_id}/retirements/{command_id}", config => config.OnNativeResult()).WithNativeFirstResponse<RetireClientService>()')]
 elif rel.endswith('ComplianceCoreJsonContext.cs'):
  replacements=[('[JsonSerializable(typeof(CreateClientService))]','[JsonSerializable(typeof(ProductClientServiceContent))]\n[JsonSerializable(typeof(ProductClientServiceRetirement))]\n[JsonSerializable(typeof(CreateClientService))]')]
 elif rel.endswith('PersistenceServiceCollectionExtensions.cs'):
  replacements=[('        Decorate<IRequestBus>','        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new ProductClientServiceAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n        Decorate<IRequestBus>')]
 elif rel.endswith('ComplianceServiceCollectionExtensions.cs'):
  replacements=[('        services.AddScoped<FitzClientServiceDirectory>();','        services.AddScoped<ProductClientServiceReader>();\n        services.AddScoped<ProductClientServiceOperations>();\n        services.AddScoped<FitzClientServiceDirectory>();')]
 elif rel.endswith('ProgramManagementServices.cs'):
  a=ours.decode().index('    public static async Task SeedAsync(IServiceProvider provider, ProductClientServiceRules selected,')
  z=ours.decode().index('    public static Task SeedAsync(IServiceProvider provider, ProgramRules selected,',a)
  block=ours.decode()[a:z]
  replacements=[
   ('        collection.AddScoped<ProgramOperations>();','        collection.AddScoped<ProgramOperations>();\n        collection.AddScoped<ProductClientServiceReader>();\n        collection.AddScoped<ProductClientServiceOperations>();'),
   ('        collection.AddVerifiedProgramReader();','        collection.AddVerifiedProgramReader();\n        collection.AddVerifiedProductClientServiceReader();'),
   ('    public static Task SeedAsync(IServiceProvider provider, ProgramRules selected,',block+'    public static Task SeedAsync(IServiceProvider provider, ProgramRules selected,')]
 elif rel.endswith('ProgramE2ETests.cs'):
  # Exact sole Product ClientService creation delta; preserve every parent Program/Guard/Pref refinement.
  replacements=[('owner.PostAsJsonAsync(\n                    $"{programPath}/client-services",','owner.PutAsJsonAsync(\n                    $"{programPath}/client-services" + $"/{Uuid.CreateVersion4()}",')]
 for a,b in replacements:assert s.count(a)==1,(rel,a);s=s.replace(a,b)
 (r/'base'/rel).write_bytes(current);(r/'work'/rel).write_text(s)
 row=next(x for x in rows if x['path']==rel);row['previousBeforeSha256']=row['beforeSha256'];row['beforeSha256']=hashlib.sha256(current).hexdigest();row['rebaseProvenance']='current-rebase.json';pro.append({'path':rel,'previousBeforeSha256':hashlib.sha256(old).hexdigest(),'beforeSha256':row['beforeSha256'],'afterSha256':hashlib.sha256(s.encode()).hexdigest(),'qualification':'Own exact Product deltas only; all current parent Program/Guard/Pref/Evidence changes preserved.'})
(r/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');(r/'current-rebase.json').write_text(json.dumps(pro,indent=2)+'\n');print(json.dumps(pro,indent=2))
