from pathlib import Path
import json,re,hashlib
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-product-client-service-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');program=Path('/tmp/compliance-program-native-prepared');parser=Parser(Language(tree_sitter_c_sharp.language()))
overlay={x['path']:x for x in json.loads((program/'manifest.json').read_text())['paths']};base=json.loads((r/'baselines.json').read_text())
def walk(n):
 st=[n]
 while st:
  x=st.pop();yield x;st.extend(reversed(x.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
changes=[]
for f in (repo/'test/Compliance.Tests/E2E').glob('*.cs'):
 rel=str(f.relative_to(repo));p=r/'work'/rel;origin=p if p.exists() else program/'work'/rel if rel in overlay else f;t=origin.read_bytes();edits=[]
 for n in walk(parser.parse(t).root_node):
  if n.type!='invocation_expression':continue
  fn=n.child_by_field_name('function');aa=n.child_by_field_name('arguments')
  if not fn or not aa:continue
  fun=tx(t,fn)
  if not any(x in fun for x in ['PostAsJsonAsync','PutAsJsonAsync']):continue
  args=[x for x in aa.children if x.type=='argument']
  if len(args)<2:continue
  arg=tx(t,args[0]);par=n
  while par and par.type not in ['method_declaration','local_function_statement']:par=par.parent
  if not par:continue
  meth=tx(t,par.child_by_field_name('name'));body=tx(t,par)
  declared=re.fullmatch(r'\w+',arg) and re.search(r'var '+arg+r'\s*=\s*\$?"[^;\n]*/client-services"\s*;',body)
  create='PostAsJsonAsync' in fun and (arg.endswith('/client-services"') or declared or meth.startswith('CreateService') and arg=='path')
  retire='PostAsJsonAsync' in fun and arg.endswith('/retirements"') and 'service' in arg.lower()
  revise='PutAsJsonAsync' in fun and (arg=='servicePath' or '"/client-services/" + scope.ServiceIds[0]' in arg)
  if create or retire:
   part='' if create else'/retirements'
   edits.append((fn.start_byte,fn.end_byte,fun.replace('PostAsJsonAsync','PutAsJsonAsync').encode()))
   edits.append((args[0].start_byte,args[0].end_byte,(arg+' + $"/{Uuid.CreateVersion4()}"').encode()))
  elif revise:
   edits.append((args[0].start_byte,args[0].end_byte,(arg+' + $"/revisions/{Uuid.CreateVersion4()}"').encode()))
 if not edits:continue
 if not p.exists():
  before=t
  for tree in ['base','work']:
   q=r/tree/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(before)
  base.append({'path':rel,'baselineSource':str(origin),'beforeSha256':hashlib.sha256(before).hexdigest(),'layer':'Program127 after' if rel in overlay else'fresh current main'})
 for a,z,v in sorted(edits,reverse=True):t=t[:a]+v+t[z:]
 s=t.decode()
 if 'Uuid.CreateVersion4()' in s and 'using Cntryl.Portia;' not in s:s='using Cntryl.Portia;\n'+s
 if f.name in ['ClientServiceE2ETests.cs','ClientServiceActorE2ETests.cs']:s=s.replace('HttpStatusCode.NoContent','HttpStatusCode.OK')
 p.write_text(s);changes.append({'path':rel,'edits':len(edits)})
(r/'baselines.json').write_text(json.dumps(base,indent=2)+'\n');(r/'wire-migration.json').write_text(json.dumps(changes,indent=2)+'\n');print(json.dumps(changes,indent=2))
