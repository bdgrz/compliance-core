from pathlib import Path
r=Path('/tmp/compliance-product-client-service-native-prepared');w=r/'work';program=Path('/tmp/compliance-program-native-prepared/work')
def put(rel,s):
 p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
s=(program/'src/Compliance.Core/Features/Programs/ProgramHistory.cs').read_text()
s=s.replace('ProgramHistory','ProductClientServiceHistory').replace('ProgramHistorySnapshot','ProductClientServiceHistorySnapshot').replace('ComplianceProgram','ClientService').replace('IProgramFact','IProductClientServiceFact')
s=s.replace('owner.CurrentContent','owner.CurrentContent').replace('replay.CriteriaEditionId != owner.CriteriaEditionId ||\n            replay.LastChangeWasSelection != owner.LastChangeWasSelection || !Same(replay.CurrentSelection, owner.CurrentSelection)', 'replay.ProgramId != owner.ProgramId || replay.IsActive != owner.IsActive ||\n            !Same((DomainEvent?)replay.CurrentValueFact, (DomainEvent?)owner.CurrentValueFact) || !Same(replay.Retirement, owner.Retirement)')
a=s.index('    public static void ValidateHeader(');z=s.index('    static bool Reference(',a)
s=s[:a]+'''    public static void ValidateHeader(IProductClientServiceFact fact)
    {
        var owner = new ClientService(fact.TenantId, fact.ServiceId);
        var operation = fact.Operation;
        var kind = fact switch
        {
            ClientServiceCreated => nameof(CreateClientService),
            ClientServiceRevised => nameof(ReviseClientService),
            ClientServiceRetired => nameof(RetireClientService),
            _ => throw new ImmutableContentIntegrityException("The service has another native fact kind."),
        };
        if (fact.TenantId == Uuid.Empty || fact.ServiceId == Uuid.Empty || fact.ProgramId == Uuid.Empty ||
            fact.Revision < 1 || fact.NativeSequence < 1 || operation is null || operation.Actor is null ||
            operation.Actor.Display is null || operation.Actor.Kind != "member" || operation.AuthoredIntentSha256 is not { Length: 64 } ||
            !Uuid.TryParse(operation.Actor.Id, CultureInfo.InvariantCulture, out var member) || member == Uuid.Empty ||
            !NativeOwnerHistory.IsOwnRoot(owner, operation, kind, operation.OriginalExpectedRevision) ||
            (fact is ClientServiceCreated ? operation.LogicalId != owner.Id || operation.OriginalExpectedRevision is not null
                : operation.OriginalExpectedRevision is not { } expected || expected > long.MaxValue) ||
            fact.ChangedAt != operation.AcceptedAt || !Reference(fact.Content, ProductClientServiceContent.Schema) ||
            !Reference(fact.FirstResponse, FirstResponses.Schema) || !Reference(fact.OperationResult, "mutation-result-content.v1") ||
            fact is ClientServiceRetired retired && !Reference(retired.Retirement, ProductClientServiceRetirement.Schema))
            throw new ImmutableContentIntegrityException("The service header differs from its exact native root, scope, member or immutable references.");
    }

'''+s[z:]
s=s.replace('new ProductClientServiceHistorySnapshot(owner, facts)','new ProductClientServiceHistorySnapshot(owner, facts)').replace('The program','The client service').replace('program prefix','client service prefix').replace('program acceptance','client service acceptance')
put('src/Compliance.Core/Features/Programs/ProductClientServiceHistory.cs',s)
put('src/Compliance.Core/Features/Programs/ProductClientServiceHistorySnapshot.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public sealed record ProductClientServiceHistorySnapshot(ClientService Owner, IReadOnlyList<DomainEvent> Facts);
''')
put('src/Compliance.Core/Features/Programs/ProductClientServiceReadFailure.cs','''using Bdgrz.Compliance.Features.Content;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public static class ProductClientServiceReadFailure
{
    public static RequestError Of(ImmutableContentIntegrityException error) => new(RequestErrorKind.Conflict,
        "The client service's exact immutable source cannot be verified.", error is ImmutableContentUnavailableException);
}
''')
put('src/Compliance.Core/Features/Programs/ProductClientServiceReader.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public sealed class ProductClientServiceReader(IAggregateReader reader, IDomainEventReader events, IImmutableContentStore content)
{
    public async Task<ProductClientServiceHistorySnapshot> HistoryAsync(Uuid tenantId, Uuid serviceId, CancellationToken ct = default)
    {
        var owner = await reader.HydrateAsync(new ClientService(tenantId, serviceId), ct).ConfigureAwait(false);
        return await ProductClientServiceHistory.ReadAsync(events, owner, ct).ConfigureAwait(false);
    }

    public async Task<ProductClientServiceRules> RulesAsync(Uuid tenantId, Uuid serviceId, CancellationToken ct = default)
    {
        var history = await HistoryAsync(tenantId, serviceId, ct).ConfigureAwait(false);
        var rules = new ProductClientServiceRules(tenantId, serviceId);
        foreach (var fact in history.Facts.OfType<IProductClientServiceFact>())
        {
            var member = Uuid.Parse(fact.Operation.Actor.Id, CultureInfo.InvariantCulture);
            var actor = fact.Operation.Actor.Display;
            if (fact is ClientServiceRetired retirement)
            {
                var value = await ReadRetirementAsync(content, retirement, ct).ConfigureAwait(false);
                if (rules.Retire(fact.Revision - 1, value.Rationale, member, actor, fact.ChangedAt) is not null)
                    throw new ImmutableContentIntegrityException("The service retirement differs from its recorded business transition.");
            }
            else
            {
                var value = await ReadContentAsync(content, fact, ct).ConfigureAwait(false);
                if (fact is ClientServiceCreated)
                {
                    var created = rules.Create(fact.ProgramId, value.Name, value.Purpose, value.OwnerReference, member, actor, fact.ChangedAt);
                    if (!created.IsSuccess)
                        throw new ImmutableContentIntegrityException("The service creation differs from its recorded business transition.");
                }
                else if (rules.Revise(fact.Revision - 1, value.Name, value.Purpose, value.OwnerReference, member, actor, fact.ChangedAt) is not null)
                    throw new ImmutableContentIntegrityException("The service revision differs from its recorded business transition.");
            }
        }
        rules.ClearPendingChanges();
        return rules;
    }

    public static async Task<ProductClientServiceContent> ReadContentAsync(IImmutableContentStore content,
        IProductClientServiceFact fact, CancellationToken ct = default)
    {
        ProductClientServiceHistory.ValidateHeader(fact);
        var value = await content.ReadJsonAsync<ProductClientServiceContent>(fact.TenantId.ToString(), fact.Content, ct).ConfigureAwait(false);
        if (ProductClientServiceRules.Validate(value) is not null || value.Name != value.Name.Trim() ||
            value.Purpose != value.Purpose.Trim() || value.OwnerReference != value.OwnerReference.Trim())
            throw new ImmutableContentIntegrityException("The service value is malformed or not canonical.");
        var digest = fact switch
        {
            ClientServiceCreated => AuthoredIntentDigest.Compute(new CreateClientService(fact.ServiceId, fact.TenantId, fact.ProgramId,
                value.Name, value.Purpose, value.OwnerReference)),
            ClientServiceRevised => AuthoredIntentDigest.Compute(new ReviseClientService(fact.Operation.LogicalId, fact.TenantId, fact.ServiceId,
                (long)fact.Operation.OriginalExpectedRevision!.Value, value.Name, value.Purpose, value.OwnerReference)),
            ClientServiceRetired => null,
            _ => throw new ImmutableContentIntegrityException("The service has another value-producing fact kind."),
        };
        if (digest is not null && digest != fact.Operation.AuthoredIntentSha256)
            throw new ImmutableContentIntegrityException("The service value differs from its exact authored command binding.");
        return value;
    }

    public static async Task<ProductClientServiceRetirement> ReadRetirementAsync(IImmutableContentStore content,
        ClientServiceRetired fact, CancellationToken ct = default)
    {
        ProductClientServiceHistory.ValidateHeader(fact);
        var value = await content.ReadJsonAsync<ProductClientServiceRetirement>(fact.TenantId.ToString(), fact.Retirement, ct).ConfigureAwait(false);
        if (string.IsNullOrWhiteSpace(value.Rationale) || value.Rationale != value.Rationale.Trim() ||
            AuthoredIntentDigest.Compute(new RetireClientService(fact.Operation.LogicalId, fact.TenantId, fact.ServiceId,
                (long)fact.Operation.OriginalExpectedRevision!.Value, value.Rationale)) != fact.Operation.AuthoredIntentSha256)
            throw new ImmutableContentIntegrityException("The service retirement differs from its exact authored command binding.");
        return value;
    }
}
''')
