from pathlib import Path
import re
r=Path('/tmp/compliance-product-client-service-native-prepared');w=r/'work';b=r/'base'
for p in (w/'test').rglob('*.cs'):
 s=p.read_text()
 s=re.sub(r'(ProgramManagementServices\.SeedAsync\([\s\S]{0,110}?)new ClientService\(',r'\1new ProductClientServiceRules(',s)
 s=s.replace('new CreateClientService(Tenant, Program,','new CreateClientService(Uuid.CreateVersion4(), Tenant, Program,')
 for name in ['ClientServiceCreated','ClientServiceRevised','ClientServiceRetired']:
  s=s.replace('AddPortiaEvent<'+name+'>(1,','AddPortiaEvent<'+name+'>(2,')
 p.write_text(s)
p=w/'test/Compliance.Tests/Features/Programs/ClientServiceTests.cs';s=p.read_text()
s='using Bdgrz.Compliance.Tests.Testing;\n'+s
s=s.replace('var service = new ClientService(', 'var service = new ProductClientServiceRules(')
s=s.replace('public void ShouldPreserveActorSnapshotGivenChangedDisplayAndLegacyReplay()', 'public async Task ShouldPreserveActorSnapshotGivenChangedDisplayAndLegacyReplay()')
s=s.replace('public void ShouldRejectStaleRevisionAndInvalidRetirementGivenServiceHistory()', 'public async Task ShouldRejectStaleRevisionAndInvalidRetirementGivenServiceHistory()')
s=s.replace('var events = new AggregateScenario<ClientService>(service).PendingEvents;', 'await using var native = new ProductClientServiceFixture();\n        var events = await ProductClientServiceSeeds.FactsAsync(native.Content, service);')
for name,var in [('Created','created'),('Revised','revised'),('Retired','retired')]:
 pattern=r'var legacy'+name+r' = JsonSerializer\.Deserialize\(\$\$"""[\s\S]*?""", ComplianceCoreJsonContext.Default.ClientService'+name+r'\);'
 repl='var legacy'+name+' = JsonSerializer.Deserialize(JsonSerializer.Serialize('+var+', ComplianceCoreJsonContext.Default.ClientService'+name+'), ComplianceCoreJsonContext.Default.ClientService'+name+');'
 s=re.sub(pattern,repl,s)
 s=s.replace(var+'.StoredActor',var+'.Operation.Actor')
 s=s.replace('Assert.Null(legacy'+name+'?.StoredActor);','Assert.Equal('+var+'.Operation, legacy'+name+'?.Operation);')
s=s.replace('Assert.Equal(2, new AggregateScenario<ClientService>(service).PendingEvents.Count);','Assert.Equal(2, service.AppliedChanges.Count);')
# Actual event-stream activity is seeded via verified native admissions, retaining all false-foreign assertions.
s=s.replace('await using var fixture = new StoreFixture();\n        var activity = new EventSourcedClientServiceActivity(fixture.Repository);','await using var fixture = new ProductClientServiceFixture();\n        var activity = new EventSourcedClientServiceActivity(fixture.Reader);')
s=s.replace('await fixture.Repository.SaveAsync(service, new ExecutionContext(), CancellationToken.None);','await fixture.PublishAsync(service);')
s=s.replace('service = await fixture.Repository.HydrateAsync(new ClientService(tenantId, serviceId),\n            CancellationToken.None);','service = await fixture.Services.RulesAsync(tenantId, serviceId);')
# Native retirement facts contain real immutable rationale rather than raw text.
s=s.replace('        Assert.Collection(new AggregateScenario<ClientService>(service).PendingEvents,','        await using var native = new ProductClientServiceFixture();\n        var facts = await ProductClientServiceSeeds.FactsAsync(native.Content, service);\n        var retiredFact = Assert.IsType<ClientServiceRetired>(facts[^1]);\n        var retirement = await ProductClientServiceReader.ReadRetirementAsync(native.Content, retiredFact);\n        Assert.Collection(facts,')
s=s.replace('ev => Assert.Equal("Service ended", Assert.IsType<ClientServiceRetired>(ev).Rationale));','ev =>\n            {\n                Assert.Equal(retiredFact.Retirement, Assert.IsType<ClientServiceRetired>(ev).Retirement);\n                Assert.Equal("Service ended", retirement.Rationale);\n            });')
# Obsolete local execution context is no longer part of this fixture's authority.
a=s.index('    sealed class ExecutionContext : IExecutionContext');z=s.index('    [Fact]',a);s=s[:a]+s[z:]
p.write_text(s)
# Source-only owner fakes are real native value fixtures, not raw aggregate shims.
for rel in ['test/Compliance.Tests/Features/Programs/ProjectionFreshnessTests.cs','test/Compliance.Tests/Features/Programs/ProgramResourceScopeResolverTests.cs']:
 p=w/rel;s=p.read_text()
 pattern=r'var (?P<v>service|source) = new ClientService\((?P<ids>[^;]+)\);(?P<create>\s+Assert.True\((?P=v)\.Create\([\s\S]*?\.IsSuccess\);)'
 def migrate(m):
  v=m['v'];text=m[0].replace('new ClientService(', 'new ProductClientServiceRules(',1);text=re.sub(r'\b'+v+r'\b',v+'Rules',text)
  return text+'\n        await using var serviceNative = new ProductClientServiceFixture();\n        var '+v+' = await ProductClientServiceSeeds.OwnerAsync(serviceNative.Content, '+v+'Rules);'
 s=re.sub(pattern,migrate,s);p.write_text(s)
p=w/'test/Compliance.Tests/Features/Commitments/CommitmentNativeContentTests.cs';s=p.read_text().replace('var service = new ClientService(scenario.Tenant, scenario.Service);','var service = new ProductClientServiceRules(scenario.Tenant, scenario.Service);').replace('await scenario.Source.Writer.SaveAsync(service, new RequestDispatchContext(RequestActor.System));','await ProductClientServiceSeeds.WriteAsync(scenario.Source.Reader, scenario.Source.Writer, scenario.Source.Events, scenario.Source.Content, service);');p.write_text(s)
# Native event attribution is retained on the provenance; public DTO legacy actor fallback stays unchanged.
p=w/'test/Compliance.Tests/E2E/ClientServiceActorE2ETests.cs';s=p.read_text()
for name in ['ClientServiceCreated','ClientServiceRevised','ClientServiceRetired']:s=s.replace('Assert.IsType<'+name+'>(ev).StoredActor','Assert.IsType<'+name+'>(ev).Operation.Actor')
p.write_text(s)
