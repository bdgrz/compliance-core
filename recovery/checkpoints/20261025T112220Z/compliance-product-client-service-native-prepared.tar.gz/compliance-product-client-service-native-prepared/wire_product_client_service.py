from pathlib import Path
r=Path('/tmp/compliance-product-client-service-native-prepared');w=r/'work';b=r/'base';program=Path('/tmp/compliance-program-native-prepared/work')
# Preserve every pre-existing wrapper and use a distinct outer keyed layer.
rel='test/Compliance.Tests/Testing/VerifiedProductClientServiceServices.cs';s=(program/'test/Compliance.Tests/Testing/VerifiedProgramServices.cs').read_text().replace('VerifiedProgramServices','VerifiedProductClientServiceServices').replace('AddVerifiedProgramReader','AddVerifiedProductClientServiceReader').replace('ProgramAggregateReader','ProductClientServiceAggregateReader');(w/rel).write_text(s)
p=w/'src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';s=p.read_text().replace('        services.AddScoped<FitzClientServiceDirectory>();','        services.AddScoped<ProductClientServiceReader>();\n        services.AddScoped<ProductClientServiceOperations>();\n        services.AddScoped<FitzClientServiceDirectory>();');assert 'AddScoped<ProductClientServiceReader>' in s;p.write_text(s)
p=w/'src/Compliance.Core/ComplianceCoreJsonContext.cs';s=p.read_text().replace('[JsonSerializable(typeof(CreateClientService))]','[JsonSerializable(typeof(ProductClientServiceContent))]\n[JsonSerializable(typeof(ProductClientServiceRetirement))]\n[JsonSerializable(typeof(CreateClientService))]');p.write_text(s)
p=w/'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=p.read_text().replace('        Decorate<IRequestBus>','        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new ProductClientServiceAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n        Decorate<IRequestBus>');p.write_text(s)
p=w/'src/Compliance.App/Program.cs';s=p.read_text();s=s.replace('MapPortiaPost<CreateClientService, ClientServiceRegistration>','MapPortiaPut<CreateClientService, ClientServiceRegistration>').replace('"/api/v1/tenants/{tenant_id}/programs/{program_id}/client-services", config => config.OnNativeResult()).WithNativeFirstResponse<CreateClientService>()','"/api/v1/tenants/{tenant_id}/programs/{program_id}/client-services/{service_id}", config => config.OnNativeResult()).WithNativeFirstResponse<CreateClientService>()')
s=s.replace('"/api/v1/tenants/{tenant_id}/client-services/{service_id}", config => config.OnNativeResult()).WithNativeFirstResponse<ReviseClientService>()','"/api/v1/tenants/{tenant_id}/client-services/{service_id}/revisions/{command_id}", config => config.OnNativeResult()).WithNativeFirstResponse<ReviseClientService>()')
s=s.replace('MapPortiaPost<RetireClientService>','MapPortiaPut<RetireClientService>').replace('"/api/v1/tenants/{tenant_id}/client-services/{service_id}/retirements", config => config.OnNativeResult()).WithNativeFirstResponse<RetireClientService>()','"/api/v1/tenants/{tenant_id}/client-services/{service_id}/retirements/{command_id}", config => config.OnNativeResult()).WithNativeFirstResponse<RetireClientService>()');p.write_text(s)
p=w/'test/Compliance.Tests/Testing/ProgramManagementServices.cs';s=p.read_text().replace('        collection.AddScoped<ProgramOperations>();','        collection.AddScoped<ProgramOperations>();\n        collection.AddScoped<ProductClientServiceReader>();\n        collection.AddScoped<ProductClientServiceOperations>();').replace('        collection.AddVerifiedProgramReader();','        collection.AddVerifiedProgramReader();\n        collection.AddVerifiedProductClientServiceReader();')
mark='    public static Task SeedAsync(IServiceProvider provider, ProgramRules selected,'
helpers='''    public static async Task SeedAsync(IServiceProvider provider, ProductClientServiceRules selected,
        Func<ProductClientServiceRules, Result> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var rules = await services.GetRequiredService<ProductClientServiceReader>().RulesAsync(selected.TenantId, selected.Id);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await ProductClientServiceSeeds.AppendAsync(services.GetRequiredService<IAggregateReader>(), services.GetRequiredService<IAggregateWriter>(),
            services.GetRequiredService<IDomainEventReader>(), services.GetRequiredService<IImmutableContentStore>(), rules);
    }

    public static async Task SeedAsync<TOut>(IServiceProvider provider, ProductClientServiceRules selected,
        Func<ProductClientServiceRules, Result<TOut>> operation)
    {
        await using var scope = provider.CreateAsyncScope();
        var services = scope.ServiceProvider;
        var rules = await services.GetRequiredService<ProductClientServiceReader>().RulesAsync(selected.TenantId, selected.Id);
        var result = operation(rules);
        Assert.True(result.IsSuccess, result.Error?.Message);
        await ProductClientServiceSeeds.AppendAsync(services.GetRequiredService<IAggregateReader>(), services.GetRequiredService<IAggregateWriter>(),
            services.GetRequiredService<IDomainEventReader>(), services.GetRequiredService<IImmutableContentStore>(), rules);
    }

'''
s=s.replace(mark,helpers+mark);p.write_text(s)
# Materialize complete native value/rationale bytes, checking exact program scope and authored binding.
p=w/'src/Compliance.Core/Features/Programs/FitzClientServiceDirectory.cs';s=p.read_text().replace('using System.Globalization;','using System.Globalization;\nusing Bdgrz.Compliance.Features.Content;').replace('FitzClientServiceDirectory(IKvClient client)','FitzClientServiceDirectory(IKvClient client, IImmutableContentStore content)')
s=s.replace('        switch (domainEvent)','        if (domainEvent is IProductClientServiceFact native)\n            ProductClientServiceHistory.ValidateHeader(native);\n        switch (domainEvent)')
s=s.replace('case ClientServiceCreated created:\n','case ClientServiceCreated created:\n                var creation = await ProductClientServiceReader.ReadContentAsync(content, created, ct).ConfigureAwait(false);\n')
for field in ['Name','Purpose','OwnerReference']:s=s.replace('created.'+field,'creation.'+field)
s=s.replace('case ClientServiceRevised revised:\n','case ClientServiceRevised revised:\n                var revision = await ProductClientServiceReader.ReadContentAsync(content, revised, ct).ConfigureAwait(false);\n')
for field in ['Name','Purpose','OwnerReference']:s=s.replace('revised.'+field,'revision.'+field)
s=s.replace('                await ClientServiceDirectorySchema.Directory.ReplaceAsync(Transaction, current,','                if (current.ProgramId != revised.ProgramId || current.Status != "active" || current.Revision + 1 != revised.Revision)\n                    throw new ImmutableContentIntegrityException("The service revision differs from its actual projected predecessor.");\n                await ClientServiceDirectorySchema.Directory.ReplaceAsync(Transaction, current,',1)
s=s.replace('case ClientServiceRetired retired:\n','case ClientServiceRetired retired:\n                var retirement = await ProductClientServiceReader.ReadRetirementAsync(content, retired, ct).ConfigureAwait(false);\n')
s=s.replace('retired.Rationale','retirement.Rationale')
s=s.replace('                await ClientServiceDirectorySchema.Directory.ReplaceAsync(Transaction, active,','                if (active.ProgramId != retired.ProgramId || active.Status != "active" || active.Revision + 1 != retired.Revision)\n                    throw new ImmutableContentIntegrityException("The service retirement differs from its actual projected predecessor.");\n                await ClientServiceDirectorySchema.Directory.ReplaceAsync(Transaction, active,',1)
p.write_text(s)
