from pathlib import Path
import json,hashlib,re
repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');r=Path('/tmp/compliance-product-client-service-native-prepared');program=Path('/tmp/compliance-program-native-prepared');paths=set()
terms=['ClientService','IClientService','CreateClientService','ReviseClientService','RetireClientService']
for folder in ['src','test']:
 for f in (repo/folder).rglob('*.cs'):
  if {'bin','obj'}.intersection(f.parts):continue
  s=f.read_text()
  if any(x in s for x in terms):paths.add(str(f.relative_to(repo)))
for p in ['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.App/Program.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs','test/Compliance.Tests/Testing/VerifiedSourceUseServices.cs']:
 paths.add(p)
frozen=json.loads((program/'manifest.json').read_text());overlay={x['path']:x for x in frozen['paths']}
rows=[]
for p in sorted(paths):
 origin=program/'work'/p if p in overlay else repo/p
 data=origin.read_bytes()
 if p in overlay:assert hashlib.sha256(data).hexdigest()==overlay[p]['afterSha256']
 for tree in ['base','work']:
  f=r/tree/p;f.parent.mkdir(parents=True,exist_ok=True);assert not f.exists();f.write_bytes(data)
 rows.append({'path':p,'baselineSource':str(origin),'beforeSha256':hashlib.sha256(data).hexdigest(),'layer':'frozen Program127 after' if p in overlay else'fresh current main','acceptanceNames':re.findall(r'\b(Should\w+)\s*\(',data.decode()) if p.startswith('test/') else[]})
(r/'baselines.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows))
