from pathlib import Path
import json,hashlib,difflib,subprocess,shutil,re
r=Path('/tmp/compliance-product-client-service-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
h=lambda b:hashlib.sha256(b).hexdigest()
base_rows={x['path']:x for x in json.loads((r/'baselines.json').read_text())};redrows={x['path']:x for x in json.loads((r/'qualified-red-baselines.json').read_text())}
paths=sorted(str(p.relative_to(r/'work')) for p in (r/'work').rglob('*.cs') if not (r/'base'/p.relative_to(r/'work')).exists() or p.read_bytes()!=(r/'base'/p.relative_to(r/'work')).read_bytes())
assert len(paths)==50
rows=[];impl=[];tests=[];original_names=0
for p in paths:
 b=r/'base'/p;w=r/'work'/p;rb=r/'qualified-red-base'/p;after=w.read_bytes();before=b.read_bytes() if b.exists() else None
 assert not (repo/p).exists() or before is not None,(p,'current existing clean path needs original baseline')
 if before is not None:
  assert p in base_rows and h(before)==base_rows[p]['beforeSha256']
  assert (repo/p).read_bytes()==before,(p,'current production baseline changed')
 if p.startswith('src/'):impl.append(p)
 else:tests.append(p)
 before_red=rb.read_bytes() if rb.exists() else before
 if p in redrows:assert h(before_red)==redrows[p]['beforeRedSha256']
 oldnames=re.findall(r'\b(Should\w+)\s*\(',before_red.decode()) if before_red and p.startswith('test/') else[]
 assert set(oldnames)<=set(re.findall(r'\b(Should\w+)\s*\(',after.decode()))
 if before_red and p.startswith('test/'):assert after.count(b'Assert.')>=before_red.count(b'Assert.')
 rows.append({'path':p,'partition':'implementation' if p.startswith('src/') else 'tests','beforeCleanSha256':h(before) if before is not None else None,'beforeRedSha256':h(before_red) if before_red is not None else None,'afterSha256':h(after),'baselineSource':base_rows[p]['baselineSource'] if p in base_rows else None,'qualifiedRedSource':redrows[p]['qualifiedRuntimeSource'] if p in redrows else None,'afterSource':str(w),'originalQualifiedAcceptanceNames':oldnames})
for p,row in base_rows.items():
 if not p.startswith('test/'):continue
 old=(r/'base'/p).read_text();now=(r/'work'/p).read_text();names=re.findall(r'\b(Should\w+)\s*\(',old);original_names+=len(names);assert set(names)<=set(re.findall(r'\b(Should\w+)\s*\(',now))
 assert now.count('Assert.')>=old.count('Assert.')
assert len(impl)==26 and len(tests)==24

def patch(paths,stage):
 out=[]
 for p in paths:
  b=(r/'qualified-red-base'/p) if stage=='red' and (r/'qualified-red-base'/p).exists() else r/'base'/p
  before=b.read_text().splitlines(True) if b.exists() else[];after=(r/'work'/p).read_text().splitlines(True)
  if before==after:continue
  out.append('diff --git a/'+p+' b/'+p+'\n')
  if not b.exists():out.append('new file mode 100644\n')
  out.extend(difflib.unified_diff(before,after,fromfile='a/'+p if b.exists() else '/dev/null',tofile='b/'+p,n=3))
 return ''.join(out)
shared=['src/Compliance.App/Program.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs']
exports={'shared.patch':patch(shared,'clean'),'implementation.patch':patch(impl,'clean'),'tests.clean.patch':patch(tests,'clean'),'tests.after-red.patch':patch(tests,'red'),'full.clean.patch':patch(paths,'clean'),'full.after-red.patch':patch(paths,'red')}
for n,t in exports.items():(r/n).write_text(t)
reconstruction=[]
for label,stage,patches in [('clean-full','clean',['full.clean.patch']),('clean-partition','clean',['implementation.patch','tests.clean.patch']),('red-full','red',['full.after-red.patch']),('red-partition','red',['implementation.patch','tests.after-red.patch'])]:
 d=r/'reconstruction'/label
 if d.exists():shutil.rmtree(d)
 d.mkdir(parents=True)
 for p in paths:
  b=(r/'qualified-red-base'/p) if stage=='red' and (r/'qualified-red-base'/p).exists() else r/'base'/p
  if b.exists():q=d/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b.read_bytes())
 outputs=[]
 for n in patches:
  result=subprocess.run(['patch','-p1','--batch','--forward','--fuzz=0','-i',str(r/n)],cwd=d,capture_output=True,text=True);assert result.returncode==0,(label,n,result.stdout,result.stderr);outputs.append(result.stdout)
 for row in rows:assert h((d/row['path']).read_bytes())==row['afterSha256'],(label,row['path'])
 assert not list(d.rglob('*.rej')) and not list(d.rglob('*.orig'))
 reconstruction.append({'stage':label,'pathsVerified':len(paths),'patches':patches,'allFinalHashesMatch':True})
(r/'reconstruction.json').write_text(json.dumps(reconstruction,indent=2)+'\n')
(r/'manifest.json').write_text(json.dumps({'status':'FROZEN','paths':rows,'existingOriginalBeforeGate':True,'allCapturedOriginalAcceptanceNamesPreserved':original_names,'qualifiedRedAcceptanceNamesPreserved':sum(len(x['originalQualifiedAcceptanceNames']) for x in rows),'testRefinement':'Exact parent-qualified corrected/formatted RED4 carried to native fixtures and complete body readback; source, metadata, retry, prepared-cut, rollback and actual-host regressions prepared.','runtime':'Parent qualified Product ClientService RED4 against de2e8c36; initial CS9007 candidate excluded. Agent did not run .NET/runtime/format/brokers/Jev/Git.'},indent=2)+'\n')
ctordeltas=[
 {'type':'CreateClientServiceHandler','before':'IAggregateExecutor, IAggregateReader, TimeProvider','after':'ProductClientServiceOperations'},
 {'type':'ReviseClientServiceHandler','before':'IAggregateExecutor, TimeProvider','after':'ProductClientServiceOperations'},
 {'type':'RetireClientServiceHandler','before':'IAggregateExecutor, TimeProvider','after':'ProductClientServiceOperations'},
 {'type':'FitzClientServiceDirectory','before':'IKvClient','after':'IKvClient, IImmutableContentStore'}]
(r/'constructor-deltas.json').write_text(json.dumps(ctordeltas,indent=2)+'\\n')
implicit={'qualification':'Static target-type review only, not a compiler.','targets':[{'type':'ProductClientServiceReader','site':'ProductClientServiceFixture.Services','arity':3},{'type':'NativeReplayCommitment','site':'ClientService.NativeCut','arity':0}],'sourceRead':'Fresh search found no direct changed handler/Directory constructor beyond prepared test and DI sites; registration uses current immutable store.','errors':[]}
(r/'implicit-constructor-audit.json').write_text(json.dumps(implicit,indent=2)+'\\n')
files={n:{'path':str(r/n),'sha256':h((r/n).read_bytes())} for n in [*exports,'README.md','LOCAL-QUALIFICATIONS.md','BINDINGS.md','manifest.json','static-audit.json','method-audit.json','reconstruction.json','qualified-red-baselines.json','implicit-constructor-audit.json','source-invariant-audit.json','constructor-deltas.json','current-rebase.json','wire-migration.json']}
prereq=[]
for rel in ['src/Compliance.Core/Features/NativeOperations/NativeReplayCommitment.cs','src/Compliance.Core/Features/NativeOperations/NativeOwnerHistory.cs','src/Compliance.Core/Features/NativeOperations/NativeOperationExecutor.cs','src/Compliance.Core/Features/Programs/ComplianceProgram.cs','test/Compliance.Tests/Testing/ProgramSeeds.cs','src/Compliance.App/Hosting/NativeResponses/NativeFirstResponseContracts.cs']:
 prereq.append({'path':rel,'sha256':h((repo/rel).read_bytes()),'changes':'Reused current parent source unchanged; Program native3 and shared full-metadata commitment prerequisites.'})
handoff={'status':'FROZEN','artifact':str(r),'paths':len(paths),'production':len(impl),'tests':len(tests),'newFiles':19,'constructorDeltas':ctordeltas,'sharedWiringDeltas':shared,'wireChanges':'Required ServiceId on creation, CommandId on revise/retire; explicit IIdentifiedRequest mappings and three selected PUT paths; native3 occupied version2 business facts; original200 registration/plainUnit bodies. See README.','prerequisites':prereq,'qualifiedRed':{'rows':4,'base':'de2e8c36','filter':'FullyQualifiedName~ClientServiceNativeBoundaryTests','baseline':str(r/'qualified-red-base'),'variant':'Exact corrected/formatted genuine old-API RED4, SHA82ea3fa04daff07519fb8ba978d53aa66ec9ba33b2cc798f15b5a01b1e694cf8. Initial raw-string CS9007 excluded/preserved.'},'preparedSelectedNativeRows':28,'httpRegressionRows':5,'focusedFilter':'Category!=BrokerIntegration&Category!=WebIntegration&(FullyQualifiedName~Features.Programs|FullyQualifiedName~ClientServiceNativeBoundaryTests|FullyQualifiedName~ProductClientService|FullyQualifiedName~CommitmentDraftReplayTests|FullyQualifiedName~CommitmentNativeContentTests|FullyQualifiedName~ProviderReferenceTests)','httpFilter':'Category!=BrokerIntegration&FullyQualifiedName~ProductClientServiceNativeHttpTests','patchAlternatives':{'clean':['implementation.patch','tests.clean.patch'],'afterExactQualifiedRed':['implementation.patch','tests.after-red.patch']},'staticOnly':True,'runtimePending':'Parent-owned compiler/analyzers, format, focused/full unit, actual HTTP, exact-source Jev and delivery pending for this packet. Shared metadata helper currently parent build/focus pending.','reconstruction':reconstruction,'files':files,'localQualifications':str(r/'LOCAL-QUALIFICATIONS.md')}
(r/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'handoffSha256':h((r/'handoff.json').read_bytes()),'manifestSha256':h((r/'manifest.json').read_bytes()),'readmeSha256':h((r/'README.md').read_bytes()),'paths':len(paths),'originalAcceptanceNamesPreserved':original_names,'exports':{n:h((r/n).read_bytes()) for n in exports}},indent=2))
