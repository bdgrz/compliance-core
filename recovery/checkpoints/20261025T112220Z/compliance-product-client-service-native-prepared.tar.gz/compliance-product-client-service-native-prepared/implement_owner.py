from pathlib import Path
r=Path('/tmp/compliance-product-client-service-native-prepared');w=r/'work';b=r/'base';program=Path('/tmp/compliance-program-native-prepared/work')
def put(rel,s):
 p=w/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
for name,fields,schema in [
 ('ProductClientServiceContent','string Name, string Purpose, string OwnerReference','product-client-service-content.v1'),
 ('ProductClientServiceRetirement','string Rationale','product-client-service-retirement.v1')]:
 put('src/Compliance.Common/Features/Programs/'+name+'.cs',f'namespace Bdgrz.Compliance.Features.Programs;\n\npublic sealed record {name}({fields})\n{{\n    public const string Schema = "{schema}";\n}}\n')
put('src/Compliance.Common/Features/Programs/IProductClientServiceFact.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public interface IProductClientServiceFact : INativeOperationFact
{
    Uuid TenantId { get; }
    Uuid ServiceId { get; }
    Uuid ProgramId { get; }
    long Revision { get; }
    ImmutableContentRef Content { get; }
    DateTimeOffset ChangedAt { get; }
    ulong NativeSequence { get; }
}
''')
for name,tag in [('ClientServiceCreated','created'),('ClientServiceRevised','revised'),('ClientServiceRetired','retired')]:
 extra=', ImmutableContentRef Retirement' if tag=='retired' else''
 put('src/Compliance.Common/Features/Programs/'+name+'.cs',f'''using System.Globalization;
using System.Text.Json.Serialization;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

[Discriminator("bdgrz.client-service.{tag}", 2)]
public sealed record {name}(Uuid TenantId, Uuid ServiceId, Uuid ProgramId, long Revision,
    ImmutableContentRef Content{extra}, DateTimeOffset ChangedAt, OperationProvenance Operation,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult, ulong NativeSequence)
    : DomainEvent, IProductClientServiceFact
{{
    [JsonIgnore]
    public ActorReference Actor => Operation.Actor;
    [JsonIgnore]
    public Uuid ActorMemberId => Uuid.TryParse(Actor.Id, CultureInfo.InvariantCulture, out var member) ? member : Uuid.Empty;
    [JsonIgnore]
    public string ActorDisplay => Actor.Display;
}}
''')
# Pure original business decisions; complete authored values are only transient reader/rule state.
s=(b/'src/Compliance.Core/Features/Programs/ClientService.cs').read_text()
s=s.replace('public sealed class ClientService : Aggregate','public sealed class ProductClientServiceRules')
s=s.replace('public ClientService(Uuid tenantId, Uuid serviceId)\n        : base(serviceId, new EventStreamAddress(tenantId.ToString(), "client-services", serviceId.ToString()))','public ProductClientServiceRules(Uuid tenantId, Uuid serviceId)')
a=s.index('        On<ClientServiceCreated>');z=s.index('\n    public Result<ClientServiceRegistration> Create',a)
s=s[:a]+'''        Id = serviceId;
    }
    public Uuid TenantId => _tenantId;
    public Uuid Id { get; }
    public IReadOnlyList<ProductClientServiceChange> AppliedChanges => _applied;
    public IReadOnlyList<ProductClientServiceChange> PendingChanges => _pending;
    readonly List<ProductClientServiceChange> _applied = [];
    readonly List<ProductClientServiceChange> _pending = [];
    public void ClearPendingChanges() => _pending.Clear();
    void Add(ProductClientServiceChange change)
    {
        _applied.Add(change);
        _pending.Add(change);
        _revision = change.Revision;
        if (change.Kind == nameof(CreateClientService))
        {
            _created = true;
            _programId = change.ProgramId;
            _initialName = change.Content!.Name;
            _initialPurpose = change.Content.Purpose;
            _initialOwnerReference = change.Content.OwnerReference;
        }
        if (change.Kind == nameof(RetireClientService))
            _retired = true;
    }
''' + s[z:]
for name,kind,body in [
 ('ClientServiceCreated','CreateClientService','new ProductClientServiceContent(name.Trim(), purpose.Trim(), ownerReference.Trim()), null'),
 ('ClientServiceRevised','ReviseClientService','new ProductClientServiceContent(name.Trim(), purpose.Trim(), ownerReference.Trim()), null'),
 ('ClientServiceRetired','RetireClientService','null, rationale.Trim()')]:
 a=s.index('        RaiseEvent(new '+name);z=s.index('        return ',a)
 rev='1' if name=='ClientServiceCreated' else'_revision + 1'
 prog='programId' if name=='ClientServiceCreated' else'_programId'
 s=s[:a]+f'''        Add(new ProductClientServiceChange(nameof({kind}), {rev}, {prog}, {body},
            ActorReference.ForMember(actorMemberId, actorDisplay), changedAt));
'''+s[z:]
s=s.replace('    static RequestError? Validate(string name, string purpose, string ownerReference)','''    public static RequestError? Validate(ProductClientServiceContent value) => Validate(value.Name, value.Purpose, value.OwnerReference);

    static RequestError? Validate(string name, string purpose, string ownerReference)''')
put('src/Compliance.Core/Features/Programs/ProductClientServiceRules.cs',s)
put('src/Compliance.Core/Features/Programs/ProductClientServiceChange.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Programs;

public sealed record ProductClientServiceChange(string Kind, long Revision, Uuid ProgramId,
    ProductClientServiceContent? Content, string? Rationale, ActorReference Actor, DateTimeOffset ChangedAt);
''')
for name in ['ProductClientServiceDigest','ProductClientServiceNativeCut','ProductClientServiceAggregateReader']:
 original={'ProductClientServiceDigest':'ProgramDigest','ProductClientServiceNativeCut':'ProgramNativeCut','ProductClientServiceAggregateReader':'ProgramAggregateReader'}[name]
 s=(program/f'src/Compliance.Core/Features/Programs/{original}.cs').read_text().replace('ComplianceProgram','ClientService').replace('ProgramAggregateReader','ProductClientServiceAggregateReader').replace('ProgramHistory','ProductClientServiceHistory').replace('ProgramDigest','ProductClientServiceDigest').replace('ProgramNativeCut','ProductClientServiceNativeCut')
 s=s.replace('The program','The client service').replace('A program','A client service').replace('an program','a client service').replace('The program','The client service')
 put(f'src/Compliance.Core/Features/Programs/{name}.cs',s)
for name,field in [('CreateClientService','ServiceId'),('ReviseClientService','CommandId'),('RetireClientService','CommandId')]:
 p='src/Compliance.Common/Features/Programs/'+name+'.cs';s=(b/p).read_text().replace(name+'(Uuid TenantId,',name+'(Uuid '+field+', Uuid TenantId,').replace('ICallable;',f'ICallable, IIdentifiedRequest\n{{\n    Uuid IIdentifiedRequest.RequestId => {field};\n}}')
 put(p,s)
