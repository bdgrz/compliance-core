from pathlib import Path
import json
r=Path('/tmp/compliance-product-client-service-native-prepared');w=r/'work'
owner=(w/'src/Compliance.Core/Features/Programs/ClientService.cs').read_text()
assert not any(x in owner for x in ['_initialName','_initialPurpose','_initialOwnerReference','List<','Dictionary<'])
assert 'internal NativeReplayCommitment NativeCut' in owner and 'NativeCut.Observe(ev, _emitting)' in owner and 'NativeCut.Observe(ev, false)' in owner
assert 'Acceptance.Observe((DomainEvent)fact)' in owner
assert not (w/'src/Compliance.Core/Features/Programs/ProductClientServiceDigest.cs').exists()
assert not (w/'src/Compliance.Core/Features/Programs/ProductClientServiceNativeCut.cs').exists()
history=(w/'src/Compliance.Core/Features/Programs/ProductClientServiceHistory.cs').read_text();assert 'owner.NativeCut.KnownThroughVersion' in history and 'replay.NativeCut.MetadataDigest, known' in history
for name,field in [('CreateClientService','ServiceId'),('ReviseClientService','CommandId'),('RetireClientService','CommandId')]:
 s=(w/f'src/Compliance.Common/Features/Programs/{name}.cs').read_text();assert 'Uuid IIdentifiedRequest.RequestId => '+field in s
for name in ['ClientServiceCreated','ClientServiceRevised','ClientServiceRetired']:
 s=(w/f'src/Compliance.Common/Features/Programs/{name}.cs').read_text();assert ', 2)]' in s;assert not any(x in s for x in ['string Name','string Purpose','string OwnerReference','string Rationale','StoredActor'])
for rel in ['src/Compliance.Core/Features/Programs/ProductClientServiceOperations.cs','test/Compliance.Tests/Testing/ProductClientServiceSeeds.cs']:
 assert 'RootOperation.InitialEpisode' in (w/rel).read_text()
for rel in ['src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs']:
 before=(r/'base'/rel).read_text();after=(w/rel).read_text()
 for row in before.splitlines():
  if 'AggregateReader(' in row or '.AddVerified' in row:assert row in after,(rel,row)
out={'qualification':'Static source only, not a compiler/runtime/Jev claim.','boundedCurrentOwner':True,'fullSavedMetadataSharedCommitment':True,'distinctProductHelperNamesPreserveIndependenceFamily':True,'selectedIdentifiedDTOs':3,'nativeVersion2BusinessFacts':3,'allProducerInitialRootEpisodes':True,'existingReaderLayersPreserved':True,'errors':[]}
(r/'source-invariant-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
