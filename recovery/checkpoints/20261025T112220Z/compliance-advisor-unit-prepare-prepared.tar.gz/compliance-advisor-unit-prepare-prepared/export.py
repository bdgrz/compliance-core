from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
src=Path('/tmp/compliance-advisor-history-prepared');r=Path('/tmp/compliance-advisor-unit-prepare-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=['src/Compliance.Core/Features/AdvisorCollaboration/AdvisorUnitOperation.cs','test/Compliance.Tests/Testing/AdvisorHost.cs','test/Compliance.Tests/Features/AdvisorCollaboration/AdvisorPreparationRaceTests.cs'];sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=[];patches={x:[] for x in ['implementation.patch','wiring.patch','tests.patch','full.patch','full-from-clean.patch']}
for p in paths:
 red=p==paths[-1];before=(src/'old-api-preparation-race-red.cs').read_bytes() if red else(src/'base'/p).read_bytes();after=(src/'work'/p).read_bytes()
 if not red:assert(repo/p).read_bytes()==before,p
 elif(repo/p).exists():assert(repo/p).read_bytes()==before,p
 for d,data in [('base',before),('work',after)]:
  f=r/d/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 diff=lambda a,z,fr='a/'+p:''.join(difflib.unified_diff(a.decode().splitlines(True),z.decode().splitlines(True),fromfile=fr,tofile='b/'+p))
 phase='implementation.patch' if p.startswith('src/') else 'wiring.patch' if p.endswith('AdvisorHost.cs') else 'tests.patch';d=diff(before,after);patches[phase].append(d);patches['full.patch'].append(d);patches['full-from-clean.patch'].append(diff(b'',after,'/dev/null') if red else d)
 manifest.append({'path':p,'beforeSha256':sha(before),'afterSha256':sha(after),'phase':phase,'baselineSource':str(src/'old-api-preparation-race-red.cs') if red else str(repo/p),'stage':'qualified original-API RED installed' if red else 'existing source/fixture','currentRepositorySha256AtExport':sha((repo/p).read_bytes()) if(repo/p).exists() else None})
for n,x in patches.items():(r/n).write_text(''.join(x))
(r/'tests-red.patch').write_bytes((src/'behavioral-preparation-race-red.patch').read_bytes());(r/'old-api-red.cs').write_bytes((src/'old-api-preparation-race-red.cs').read_bytes());(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
orders={'qualified-red':['full.patch'],'clean-red-green':['tests-red.patch','full.patch'],'split-after-red':['implementation.patch','wiring.patch','tests.patch'],'all-from-clean':['full-from-clean.patch']};out={}
for mode,order in orders.items():
 t=Path(tempfile.mkdtemp(prefix='advisor-unit-reconstruct-',dir=r))
 try:
  for p in paths:
   if mode in ['clean-red-green','all-from-clean'] and p==paths[-1]:continue
   f=t/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((r/'base'/p).read_bytes())
  for patch in order:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/patch)],cwd=t,capture_output=True,text=True);assert x.returncode==0,(mode,patch,x.stdout,x.stderr)
  assert all((t/p).read_bytes()==(r/'work'/p).read_bytes() for p in paths),mode
  out[mode]={'exactFiles':3,'patchOrder':order}
 finally:shutil.rmtree(t)
(r/'reconstruction.json').write_text(json.dumps(out,indent=2)+'\n')
h={'root':str(r),'status':'FROZEN narrow advisor unit preparation recovery correction; parent qualified original-API RED2. No agent runtime/Jev claims.','changedPaths':3,'existingSourceFixtureOriginals':2,'qualifiedRedTestOriginals':1,'sourcePaths':1,'wiringFixturePaths':1,'testPaths':1,'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'readme':'README.md','audit':'audit.json','reconstruction':'reconstruction.json','patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in ['tests-red.patch',*patches]},'cleanOrder':['full-from-clean.patch'],'afterRedOrder':['full.patch'],'focusedFilter':'FullyQualifiedName~AdvisorPreparationRaceTests|FullyQualifiedName~AdvisorHandoff|FullyQualifiedName~AdvisorFeedback|FullyQualifiedName~NativeOperationExecutorTests','suiteFilter':'Category!=BrokerIntegration','constructorDelta':'AdvisorUnitOperation(NativeOperationExecutor,IImmutableContentStore); removed unused IAggregateReader. DI AddScoped type registration unchanged; AdvisorHost and2 race-test construction sites migrated.','originalAcceptanceNames':2,'noWireOrSchemaChange':True,'noRuntimeOrJevClaims':True}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print('manifest',h['manifestSha256']);print('handoff',sha((r/'handoff.json').read_bytes()));print(json.dumps(h['patches'],indent=2))
