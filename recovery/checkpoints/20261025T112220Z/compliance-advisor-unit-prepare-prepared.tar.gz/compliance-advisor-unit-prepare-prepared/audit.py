from pathlib import Path
import json,re
from tree_sitter import Parser,Language
import tree_sitter_c_sharp
r=Path('/tmp/compliance-advisor-unit-prepare-prepared');parser=Parser(Language(tree_sitter_c_sharp.language()));syntax=[];tokens=[];removed=[];assertdrops=[];names=0;ctors=[]
def walk(n):
 yield n
 for x in n.children:yield from walk(x)
for p in (r/'work').rglob('*.cs'):
 data=p.read_bytes();before=(r/'base'/p.relative_to(r/'work')).read_text();t=data.decode();root=parser.parse(data).root_node
 for n in walk(root):
  if n.type=='ERROR' or n.is_missing:syntax.append({'path':str(p),'line':data[:n.start_byte].count(b'\n')+1})
  if n.type=='parameter_list':
   pars=[x for x in n.children if x.type=='parameter']
   for i,x in enumerate(pars):
    typ=x.child_by_field_name('type')
    if typ and data[typ.start_byte:typ.end_byte]==b'CancellationToken' and i!=len(pars)-1:tokens.append(str(p))
  if n.type=='object_creation_expression':
   typ=n.child_by_field_name('type');al=next((x for x in n.children if x.type=='argument_list'),None)
   if typ and al:
    name=data[typ.start_byte:typ.end_byte].decode()
    if name in ['AdvisorUnitOperation','NativeOperationExecutor','RespondToAdvisorFeedbackHandler']:
     num=sum(x.type=='argument' for x in al.children);expected={'AdvisorUnitOperation':[2],'NativeOperationExecutor':[3,4],'RespondToAdvisorFeedbackHandler':[3]}[name];assert num in expected,(name,num);ctors.append({'type':name,'arguments':num})
 old=re.findall(r'\b(Should\w+)\s*\(',before);new=re.findall(r'\b(Should\w+)\s*\(',t);names+=len(old);removed.extend(x for x in old if x not in new)
 if t.count('Assert.')<before.count('Assert.'):assertdrops.append(str(p))
assert not(syntax or tokens or removed or assertdrops)
fixture=(r/'work/test/Compliance.Tests/Testing/AdvisorHost.cs').read_text();assert 'AdvisorUnitOperation Unit => new(Operations, Content);' in fixture
out={'qualification':'Static only. Parent qualified old RED2; parent runs compiler/analyzers/runtime/full suite/Jev.','paths':3,'syntaxErrors':syntax,'cancellationTokenNotLast':tokens,'constructorCalls':ctors,'implicitFixtureConstructor':'AdvisorUnitOperation Unit => new(Operations, Content), inspected two-parameter declared constructor.','removedAcceptanceNames':removed,'originalAcceptanceNames':names,'assertionCountDrops':assertdrops,'existingPathsWithoutOriginal':[]}
(r/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
