from pathlib import Path
p=Path('/tmp/compliance-risk-source-bytes-prepared');f=p/'work/test/Compliance.Tests/Features/Examinations/RiskTypeIBaselineSourceContributorTests.cs'
s=f.read_text().replace('using Bdgrz.Compliance.Features.AuditPackages;','using Bdgrz.Compliance.Features.AuditPackages;\nusing Bdgrz.Compliance.Features.Proofs;')
marker='    static ExaminationEngagementView Engagement()'
test='''    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ShouldReturnClassifiedPublicationFailureGivenUnverifiableRiskBusinessBytes(bool unavailable)
    {
        // Arrange
        await using var fixture = await Fixture(includeAssessmentAndOwner: true,
            sourceContent: content => new UnavailableBusinessContent(content, unavailable));
        var root = Directory.CreateTempSubdirectory("bdgrz-risk-source-failure-").FullName;
        try
        {
            var artifacts = new LocalArtifactContentStore(new ArtifactContentStoreOptions(root, null,
                ArtifactContentLimits.MaxContentLength), TimeProvider.System);
            var publisher = new PublishedTypeIBaselinePreviewReader(new TypeIBaselinePreviewReader([fixture.Contributor]),
                artifacts, fixture.Provider.GetRequiredService<IImmutableContentStore>());

            // Act
            var result = await publisher.ReadAsync(Engagement());

            // Assert
            Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind);
            Assert.Equal(unavailable, result.Error!.IsTransient);
        }
        finally
        {
            Directory.Delete(root, recursive: true);
        }
    }

'''
s=s.replace(marker,test+marker)
s=s.replace('bool evaluationDirectoryCaughtUp = true, bool includeAcceptedControlTreatment = false)',
'''bool evaluationDirectoryCaughtUp = true, bool includeAcceptedControlTreatment = false,
        Func<IImmutableContentStore, IImmutableContentStore>? sourceContent = null)''')
s=s.replace('evaluationDirectory, new RiskGovernanceReader(reader, store, content), content, reader, store), provider);',
'''evaluationDirectory, new RiskGovernanceReader(reader, store, content), sourceContent?.Invoke(content) ?? content,
            reader, store), provider);''')
marker='    sealed record FixtureState'
wrapper='''    sealed class UnavailableBusinessContent(IImmutableContentStore inner, bool unavailable) : IImmutableContentStore
    {
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);

        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference,
            CancellationToken ct = default) => reference.Schema == RiskEvaluationContent.AuthoritySchema
            ? throw (unavailable ? new ImmutableContentUnavailableException("The risk body is temporarily unavailable.")
                : new ImmutableContentIntegrityException("The risk body failed verification."))
            : inner.ReadVerifiedAsync(realm, reference, ct);
    }

'''
s=s.replace(marker,wrapper+marker);f.write_text(s)
