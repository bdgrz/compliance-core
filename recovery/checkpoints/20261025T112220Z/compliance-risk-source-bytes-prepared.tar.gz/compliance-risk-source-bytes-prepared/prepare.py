from pathlib import Path
import shutil
root=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
p=Path('/tmp/compliance-risk-source-bytes-prepared')
paths={
 'src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs':Path('/tmp/compliance-all-source-receipts-prepared/work'),
 'src/Compliance.Core/Features/Examinations/RiskSourceEvent.cs':root,
 'src/Compliance.Core/Features/Snapshots/SnapshotSourceCapture.cs':root,
 'test/Compliance.Tests/Features/Examinations/RiskTypeIBaselineSourceContributorTests.cs':Path('/tmp/compliance-risk-native-prepared/work'),
}
for rel,origin in paths.items():
 for part in ['base','work']:
  dest=p/part/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin/rel,dest)
# Test is intentionally independent of all new implementation symbols; RED applies after the Risk109 owner baseline.
t=p/'work/test/Compliance.Tests/Features/Examinations/RiskTypeIBaselineSourceContributorTests.cs'
s=t.read_text()
s='using System.IO.Compression;\nusing System.Security.Cryptography;\nusing System.Text;\nusing System.Text.Json;\nusing Bdgrz.Compliance.Features.Artifacts;\nusing Bdgrz.Compliance.Features.AuditPackages;\n'+s
marker='    static ExaminationEngagementView Engagement()'
case='''    [Fact]
    public async Task ShouldArchiveExactSelectedRiskNarrativesGivenProductionNativeSourcePublication()
    {
        // Arrange
        await using var fixture = await Fixture(includeAssessmentAndOwner: true);
        var root = Directory.CreateTempSubdirectory("bdgrz-risk-source-archive-").FullName;
        try
        {
            var content = fixture.Provider.GetRequiredService<IImmutableContentStore>();
            var artifacts = new LocalArtifactContentStore(new ArtifactContentStoreOptions(root, null,
                ArtifactContentLimits.MaxContentLength), TimeProvider.System);
            var publisher = new PublishedTypeIBaselinePreviewReader(
                new TypeIBaselinePreviewReader([fixture.Contributor]), artifacts, content);
            var preview = await publisher.ReadAsync(Engagement());
            Assert.True(preview.IsSuccess, preview.Error?.Message);
            var source = Assert.Single(preview.Value.Sources);
            Assert.NotNull(source.Content);
            var selected = new AuditPackageSelectionEntry("risks", "R-01", source.Kind,
                source.RecordId, source.Revision, source.Content.FileExtension,
                source.ContentSha256, source.Content.Bytes, "product_calculated", source.VersionId,
                source.Content);
            var manifest = new AuditPackageManifestView(TenantId, ProgramId, Uuid.CreateVersion4(),
                Uuid.CreateVersion4(), 1, Uuid.CreateVersion4(), preview.Value.ContentSha256,
                [RiskId], [new AuditPackageManifestEntryView(selected, "risks/R-01." + selected.Extension)],
                new string('a', 64), CreatedAt);

            // Act
            var built = await new AuditPackageArchiveBuilder(artifacts).BuildAsync(TenantId, manifest,
                CancellationToken.None);
            Assert.True(built.IsSuccess, built.Error?.Message);
            await using var stored = await artifacts.OpenVerifiedAsync(new ArtifactContentReference(TenantId,
                built.Value!.ArchiveSha256!, built.Value.ArchiveBytes!.Value));
            using var zip = new ZipArchive(stored!, ZipArchiveMode.Read);
            var entry = Assert.Single(zip.Entries);
            await using var payload = entry.Open();
            using var envelope = await JsonDocument.ParseAsync(payload);
            var proof = Convert.FromBase64String(envelope.RootElement.GetProperty("source_base64").GetString()!);
            var blobs = envelope.RootElement.GetProperty("content_blobs").EnumerateArray().ToArray();
            var recovered = new List<string>();
            foreach (var blob in blobs)
            {
                var reference = blob.GetProperty("reference").Deserialize(ComplianceCoreJsonContext.Default.ImmutableContentRef)!;
                var bytes = Convert.FromBase64String(blob.GetProperty("base64").GetString()!);
                Assert.Equal(reference.Bytes, bytes.LongLength);
                Assert.Equal(reference.Sha256, Convert.ToHexStringLower(SHA256.HashData(bytes)));
                Assert.Equal((await content.ReadVerifiedAsync(TenantId.ToString(), reference)).ToArray(), bytes);
                recovered.Add(Encoding.UTF8.GetString(bytes));
            }

            // Assert
            Assert.Equal(source.ContentSha256, Convert.ToHexStringLower(SHA256.HashData(proof)));
            Assert.Equal(source.ContentSha256, envelope.RootElement.GetProperty("logical_content_sha256").GetString());
            Assert.Equal("application/vnd.bdgrz.risk-snapshot-source.v1+json", source.Content.MediaType);
            Assert.Equal(source.Content.Bytes, entry.Length);
            Assert.Contains(recovered, body => body.Contains("Credential misuse", StringComparison.Ordinal));
            Assert.Contains(recovered, body => body.Contains("A compromised credential could expose customer records.", StringComparison.Ordinal));
            Assert.Contains(recovered, body => body.Contains("Risk owner is accountable for the mitigation.", StringComparison.Ordinal));
            Assert.DoesNotContain(recovered, body => body.Contains("Revised credential misuse", StringComparison.Ordinal));
            Assert.DoesNotContain(recovered, body => body.Contains("Updated after the audit date.", StringComparison.Ordinal));
        }
        finally
        {
            Directory.Delete(root, recursive: true);
        }
    }

'''
assert marker in s;s=s.replace(marker,case+marker)
t.write_text(s)
# Snapshot capture stores only a separate physical envelope: original digest preimage remains byte for byte unchanged.
f=p/'work/src/Compliance.Core/Features/Snapshots/SnapshotSourceCapture.cs'
s=f.read_text().replace('using Cntryl.Portia;','using Cntryl.Portia;\nusing Bdgrz.Compliance.Features.Content;')
marker='    internal sealed class Scope : IDisposable'
method='''    public static void Risk(string logicalSha256, ReadOnlySpan<byte> source,
        IReadOnlyList<SnapshotSourceContentBlob> blobs)
    {
        if (blobs.Count > 0 && Current.Value is { } scope)
            scope.Risk(logicalSha256, source, blobs);
    }

'''
s=s.replace(marker,method+marker)
marker='        public void Dispose()'
method='''        public void Risk(string logicalSha256, ReadOnlySpan<byte> source,
            IReadOnlyList<SnapshotSourceContentBlob> blobs)
        {
            if (Convert.ToHexStringLower(SHA256.HashData(source)) != logicalSha256)
                throw new ImmutableContentIntegrityException("A risk source envelope differs from its exact logical preimage.");
            var unique = new Dictionary<Uuid, SnapshotSourceContentBlob>();
            foreach (var blob in blobs)
            {
                if (blob.Reference.ContentId == Uuid.Empty || blob.Reference.Bytes != blob.Bytes.LongLength ||
                    Convert.ToHexStringLower(SHA256.HashData(blob.Bytes)) != blob.Reference.Sha256 ||
                    unique.TryGetValue(blob.Reference.ContentId, out var prior) && prior.Reference != blob.Reference)
                    throw new ImmutableContentIntegrityException("A risk source blob differs from its exact immutable reference.");
                unique.TryAdd(blob.Reference.ContentId, blob);
            }
            lock (_gate)
            {
                if (_materials.TryGetValue(logicalSha256, out var existing))
                {
                    File.Delete(existing.Path);
                    _materials.Remove(logicalSha256);
                }
                var path = Path.Combine(_directory, logicalSha256 + ".source");
                using (var output = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                using (var writer = new Utf8JsonWriter(output, SnapshotContentIdentity.CanonicalWriterOptions))
                {
                    writer.WriteStartObject();
                    writer.WriteNumber("format_version", 1);
                    writer.WriteString("logical_content_sha256", logicalSha256);
                    writer.WriteBase64String("source_base64", source);
                    writer.WriteStartArray("content_blobs");
                    foreach (var blob in unique.Values.OrderBy(item => item.Reference.ContentId.ToString(), StringComparer.Ordinal))
                    {
                        writer.WriteStartObject();
                        writer.WritePropertyName("reference");
                        var reference = JsonSerializer.SerializeToElement(blob.Reference,
                            ComplianceCoreJsonContext.Default.ImmutableContentRef);
                        SnapshotContentIdentity.WriteCanonical(writer, reference);
                        writer.WriteBase64String("base64", blob.Bytes);
                        writer.WriteEndObject();
                    }
                    writer.WriteEndArray();
                    writer.WriteEndObject();
                }
                using var input = File.OpenRead(path);
                var physical = Convert.ToHexStringLower(SHA256.HashData(input));
                var descriptor = new SnapshotSourceBlob(physical, input.Length,
                    "application/vnd.bdgrz.risk-snapshot-source.v1+json", "json",
                    "Exact canonical risk source proof and its digest-verified immutable business content bytes.");
                _materials.Add(logicalSha256, new Material(path, descriptor));
            }
        }

'''
s=s.replace(marker,method+marker);f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Snapshots/SnapshotSourceContentBlob.cs'
f.write_text('''using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Snapshots;

/// <summary>Verified immutable business bytes included in a physical snapshot source envelope.</summary>
sealed record SnapshotSourceContentBlob(ImmutableContentRef Reference, byte[] Bytes);
''')
f=p/'work/src/Compliance.Core/Features/Examinations/RiskSourceEvent.cs'
s=f.read_text().replace('using System.Text.Json;','using System.Text.Json;\nusing System.Text.Json.Serialization;\nusing Bdgrz.Compliance.Features.Snapshots;')
s=s.replace('string Kind, JsonElement Content);','''string Kind, JsonElement Content)
{
    // Physical source publication retains these bytes without changing the historical logical digest preimage.
    [JsonIgnore]
    public IReadOnlyList<SnapshotSourceContentBlob>? ContentBlobs { get; init; }
}
''')
f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs'
s=f.read_text().replace('using Bdgrz.Compliance.Features.Snapshots;','using Bdgrz.Compliance.Features.Snapshots;\nusing Bdgrz.Compliance.Features.Proofs;')
s=s.replace('SerializeEvent(record.Event, "risks", summary.RiskId, metadata)', 'await SerializeEventAsync(content, tenantId, record.Event, "risks", summary.RiskId, metadata, ct).ConfigureAwait(false)')
s=s.replace('SerializeEvent(record.Event, "risk-evaluations", riskId, metadata)', 'await SerializeEventAsync(content, tenantId, record.Event, "risk-evaluations", riskId, metadata, ct).ConfigureAwait(false)')
s=s.replace('SerializeEvent(published, "risk-methods", methodId, metadata)', 'await SerializeEventAsync(content, tenantId, published, "risk-methods", methodId, metadata, ct).ConfigureAwait(false)')
s=s.replace('SerializeEvent(fact, stream.Area, metadata.AggregateId, metadata)', 'await SerializeEventAsync(content, tenantId, fact, stream.Area, metadata.AggregateId, metadata, ct).ConfigureAwait(false)')
s=s.replace('static RiskSourceEvent SerializeEvent(DomainEvent domainEvent, string area,\n        Uuid aggregateId, DomainEventMetadata metadata)', 'static async ValueTask<RiskSourceEvent> SerializeEventAsync(IImmutableContentStore store, Uuid tenantId,\n        DomainEvent domainEvent, string area, Uuid aggregateId, DomainEventMetadata metadata, CancellationToken ct)')
s=s.replace('''        return new RiskSourceEvent(area, aggregateId, metadata.EventId,
            metadata.AggregateVersion, metadata.OccurredOn, kind, content);''','''        IReadOnlyList<ImmutableContentRef> references = domainEvent switch
        {
            IRiskDraftFact fact => [fact.Content],
            IRiskEvaluationFact fact => [fact.ChangeContent, fact.CurrentAuthorityContent],
            RiskOwnerAssigned fact => [fact.OwnerContent],
            RiskReassessmentTriggered fact => [fact.TriggerContent],
            RiskControlTreatmentProposed fact => [fact.TreatmentContent],
            RiskTreatmentActionAdded fact => [fact.ActionContent],
            RiskTreatmentActionRevised fact => [fact.EvidenceRequestIdsManifest],
            RiskTreatmentActionCompletionSubmitted fact => [fact.EvidenceRequestIdsManifest],
            RiskTreatmentActionCompletionReviewAccepted fact => fact.SourceProofs is { } proofs
                ? [fact.Intent, proofs] : [fact.Intent],
            RiskTreatmentActionCompletionReviewed fact => [fact.Intent],
            RiskTreatmentActionCompletionReviewCanceled fact => fact.SourceProofs is { } proofs
                ? [fact.Intent, proofs] : [fact.Intent],
            _ => [],
        };
        var blobs = new List<SnapshotSourceContentBlob>(references.Count);
        foreach (var reference in references.Distinct())
        {
            var bytes = await store.ReadVerifiedAsync(tenantId.ToString(), reference, ct).ConfigureAwait(false);
            if (bytes.Length != reference.Bytes || Convert.ToHexStringLower(SHA256.HashData(bytes.Span)) != reference.Sha256)
                throw new ImmutableContentIntegrityException("A risk source business blob failed exact digest verification.");
            blobs.Add(new SnapshotSourceContentBlob(reference, bytes.ToArray()));
        }
        return new RiskSourceEvent(area, aggregateId, metadata.EventId,
            metadata.AggregateVersion, metadata.OccurredOn, kind, content)
        { ContentBlobs = blobs.Count == 0 ? null : blobs.AsReadOnly() };''')
s=s.replace('''        return Convert.ToHexStringLower(SnapshotSourceCapture.HashData(material));''','''        var digest = Convert.ToHexStringLower(SnapshotSourceCapture.HashData(material));
        var blobs = content.Events.SelectMany(item => item.ContentBlobs ?? []).ToArray();
        SnapshotSourceCapture.Risk(digest, material, blobs);
        return digest;''')
s=s.replace('''        catch (ImmutableContentIntegrityException)
        {
            return InvalidHistory<GovernanceHistory>();
        }''','''        catch (ImmutableContentIntegrityException failure)
        {
            return Result<GovernanceHistory>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact risk governance source content cannot be verified.", failure is ImmutableContentUnavailableException));
        }''')
assert 'SerializeEvent(' not in s
f.write_text(s)
