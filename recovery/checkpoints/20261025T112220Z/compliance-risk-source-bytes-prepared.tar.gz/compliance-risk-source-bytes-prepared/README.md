# Risk source bytes: independent Risk109 overlay

Frozen at `handoff.json`. Six paths: four Core source files and two unit test files. No main edits, builds, tests, git operations, Jev calls or issues were performed by this agent.

## Baseline and application

Apply the frozen Risk109 owner slice first, preserving the already merged receipt selection seam with `overlap-risk-native.patch` from the all-source receipt handoff. This package's contributor baseline is precisely that future-native receipt-corrected version. Its other existing source baselines are current main. SnapshotSourceCapture has no shared registration/JSON/HTTP delta. It requires no RiskMethod compaction.

To capture meaningful RED, apply only `behavioral-red.patch`, and run the filter in `behavioral-red-filter.txt`. It contains no new implementation symbols. The existing production path archives the prefixed compact event proof without the referenced narratives, so the regression cannot recover the expected self-contained JSON envelope/draft/assessment/owner bytes. Apply `green-after-red.patch` afterward. Alternatively `implementation.patch` plus `tests.patch`, or `full.patch`, reconstruct the same six final hashes. Exact full and staged reconstructions passed.

## Proven path and behavior

The production contributor reads and validates immutable content, but `IImmutableContentStore.ReadVerifiedAsync` does not register bytes with SnapshotSourceCapture. That scope previously observed only the final logical digest preimage. The production publisher then publishes only that captured preimage, and the ZIP builder archives only the selected artifact; ref headers alone do not retain authored narrative bytes.

The correction deliberately leaves the serialized RiskSourceContent and its exact prefixed digest preimage unchanged. Ignored per-event capture data carries verified business-content references and bytes to the physical publication boundary. When blobs exist, the optional SnapshotSourceBlob describes a separate `application/vnd.bdgrz.risk-snapshot-source.v1+json` envelope containing:

- the exact original domain-prefixed canonical source preimage as source_base64;
- its unchanged logical_content_sha256;
- sorted, deduplicated immutable business-content references and exact base64 bytes.

Its physical SHA and length come from the actual envelope file. Legacy/no-blob paths retain their original .snapshot bytes, media type, length and digest. No JSON label is applied to prefixed non-JSON bytes. No fabricated body or live-current fallback exists. Captured bodies belong only to selected source facts; later draft revisions are not published. Existing receipt cut, current visibility, directory checkpoint and content schema checks remain in place. Missing immutable governance blobs now return a transient Conflict; corrupt content remains permanent.

Covered immutable business refs: native draft revisions; evaluation change/current authority; governance owner and trigger; proposed control treatment; treatment action initial body, revised/submitted evidence manifests, and review intent/source-proof manifests. Operation result/first-response blobs are not substituted for business content, and unrelated evidence bodies remain the owning source family's responsibility.

The real archive regression uses the actual native Risk109 fixture, production contributor, PublishedTypeIBaselinePreviewReader, real local content adapter and AuditPackageArchiveBuilder/verifier. It opens the generated ZIP, recovers each body, compares its exact stored bytes/hash/length, checks original logical preimage identity, and checks draft/assessment/owner narratives while excluding a later revision. This is a one-family source publication/archive acceptance fixture; it does not claim a complete readiness baseline or full production qualification.

## Static evidence and remaining runtime work

Six modern C# parses passed. Six existing contributor acceptance names are preserved, with no assertion count reduction. Eight new test rows cover the real ZIP, missing/corrupt source classification, stable legacy preimage, verified physical envelope, ordering/deduplication and contradictory proof/body refusal. Full and staged patch reconstruction match exact final SHA256s. Parent must run strict formatting/build, the supplied RED, focused/full units and direct per-file Jev; none is claimed here.
