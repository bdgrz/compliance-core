from pathlib import Path
import hashlib,json,difflib,re,subprocess,shutil
p=Path('/tmp/compliance-risk-source-bytes-prepared');base=p/'base';work=p/'work'
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
def patch(name,selected):
 out=[]
 for rel in selected:
  a=base/rel;b=work/rel
  out.extend(difflib.unified_diff(a.read_text().splitlines(True) if a.exists() else [],b.read_text().splitlines(True) if b.exists() else [],fromfile='a/'+rel if a.exists() else '/dev/null',tofile='b/'+rel if b.exists() else '/dev/null'))
 f=p/name;f.write_text(''.join(out));return {'path':str(f),'sha256':sha(f),'paths':selected}
source=[x for x in paths if x.startswith('src/')];tests=[x for x in paths if x.startswith('test/')];oldtest=[x for x in tests if (base/x).exists()];newtest=[x for x in tests if not (base/x).exists()]
artifacts={name:patch(name,selected) for name,selected in [('implementation.patch',source),('tests.patch',tests),('behavioral-red.patch',oldtest),('green-after-red.patch',source+newtest),('full.patch',paths)]}
checks=[]
for name,sequence in [('full',['full.patch']),('staged',['behavioral-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/name
 if dest.exists():shutil.rmtree(dest)
 shutil.copytree(base,dest)
 for file in sequence:
  run=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/file)],cwd=dest,text=True,capture_output=True)
  if run.returncode:raise RuntimeError(run.stdout+run.stderr)
 bad=[r for r in paths if sha(dest/r)!=sha(work/r)]
 assert not bad,bad
 checks.append({'sequence':sequence,'exact':True,'paths':len(paths)})
oldnames=[];newnames=[]
for r in oldtest:
 names=lambda f:re.findall(r'public\s+(?:async\s+)?(?:Task(?:<[^>]+>)?|ValueTask(?:<[^>]+>)?|void)\s+(Should\w+)\s*\(',f.read_text())
 before=names(base/r);after=names(work/r)
 assert set(before)<=set(after)
 assert (work/r).read_text().count('Assert.') >= (base/r).read_text().count('Assert.')
 oldnames+=before;newnames+=list(set(after)-set(before))
# Full tree walk only modern parser has no-error; no unsafe node walking.
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
parser=Parser(Language(tree_sitter_c_sharp.language()))
paths=list(Path("/tmp/compliance-risk-source-bytes-prepared/work").rglob("*.cs"))
errors=[str(f) for f in paths if parser.parse(f.read_bytes()).root_node.has_error]
print(json.dumps({"files":len(paths),"errors":errors}))
'''
env=dict(__import__('os').environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],env=env,text=True));assert not syntax['errors']
report={'paths':[{'path':r,'before':sha(base/r),'after':sha(work/r)} for r in paths],'artifacts':artifacts,'reconstruction':checks,'syntax':syntax,'preservedAcceptanceNames':oldnames,'newContributorAcceptanceNames':newnames,'runtime':'Not run; parent owns all builds/tests/Jev.','baseline':'Risk109 frozen native owners + overlap-risk-native receipt correction; SnapshotSourceCapture and RiskSourceEvent from current main. No main edits.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n')
(p/'behavioral-red-filter.txt').write_text('FullyQualifiedName~RiskTypeIBaselineSourceContributorTests.ShouldArchiveExactSelectedRiskNarrativesGivenProductionNativeSourcePublication\n')
(p/'focused-filter.txt').write_text('FullyQualifiedName~RiskTypeIBaselineSourceContributorTests|FullyQualifiedName~RiskSnapshotSourceEnvelopeTests|FullyQualifiedName~SnapshotSourcePublicationTests\n')
print(json.dumps({'files':len(paths),'source':len(source),'tests':len(tests),'preserved':len(oldnames),'syntax':syntax,'artifacts':artifacts,'reconstruction':checks},indent=2))
