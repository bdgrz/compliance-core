using System.Collections;
using System.Reflection;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Operations;

public sealed class TypeIICalendarCompactionTests
{
    [Fact]
    public void ShouldKeepCalendarOwnerBoundedGivenLifetimeReleasedReservations()
    {
        // Arrange
        const int count = 32;
        var tenant = Uuid.CreateVersion4(); var program = Uuid.CreateVersion4();
        var calendar = new TypeIIObservationCalendar(tenant, program);
        var intent = new ImmutableContentRef(Uuid.CreateVersion4(), new string('a', 64), 2, "application/json", "type-i-i-range-intent.v1");
        var range = new ObservationRange(new DateOnly(2026, 10, 1), new DateOnly(2027, 9, 30));
        for (var index = 0; index < count; index++)
        {
            var period = Uuid.CreateVersion4(); var root = Uuid.CreateVersion4();
            var operation = new OperationProvenance(Uuid.CreateVersion4(), root, null, "Synthetic",
                ActorReference.ForMember(Uuid.CreateVersion4(), "Period manager"), calendar.Stream, "initial", null,
                new string('b', 64), DateTimeOffset.UtcNow, calendar.Stream, calendar.Stream);
            Assert.True(calendar.Authorize(operation, intent, period, TypeIIRangeOperationKind.Opening, range, null).IsSuccess);
            Assert.True(calendar.Settle(operation with { LogicalId = Uuid.CreateVersion4() }, intent, period,
                TypeIIRangeSettlementKind.Activated, root, null).IsSuccess);
            Assert.True(calendar.Settle(operation with { LogicalId = Uuid.CreateVersion4() }, intent, period,
                TypeIIRangeSettlementKind.Released, root, null).IsSuccess);
        }
        var facts = new AggregateScenario<TypeIIObservationCalendar>(calendar).PendingEvents.ToArray();

        // Act
        var replay = new AggregateScenario<TypeIIObservationCalendar>(new TypeIIObservationCalendar(tenant, program)).Given(facts).Aggregate;
        var retained = typeof(TypeIIObservationCalendar).GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(replay) is ICollection { Count: > 0 }).ToArray();

        // Assert
        Assert.Empty(retained);
        Assert.Equal(count * 3, replay.Revision);
        Assert.Equal(count, replay.ReservationGeneration);
        Assert.Empty(replay.Reservations.Where(value => value.IsLive));
    }
}
