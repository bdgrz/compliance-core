from pathlib import Path
r=Path('/tmp/compliance-calendar-prepared');w=r/'work';op=w/'test/Compliance.Tests/Features/Operations';testing=w/'test/Compliance.Tests/Testing'
p=op/'TypeIIObservationCalendarTests.cs';s=p.read_text().replace('using Cntryl.Portia.Testing;\n','');s=s.replace('new TypeIIObservationCalendar(','new TypeIICalendarRules(').replace('TypeIIObservationCalendar calendar','TypeIICalendarRules calendar');s=s.replace('''        var events = new AggregateScenario<TypeIIObservationCalendar>(calendar).PendingEvents.ToArray();''','''        var events = calendar.AppliedChanges.ToArray();''');s=s.replace('''        var replay = new AggregateScenario<TypeIIObservationCalendar>(
            new TypeIICalendarRules(TenantId, ProgramId)).Given(events).Aggregate;''','''        var replay = new TypeIICalendarRules(TenantId, ProgramId);
        foreach (var change in events) replay.Apply(change);''');p.write_text(s)
p=testing/'TypeIIRangeHost.cs';s=p.read_text();s=s.replace('''    public TypeIIPeriodReader Periods => new(Reader, Events, Content);''','''    public TypeIICalendarReader Calendars => new(Reader, Events, Content);

    public TypeIIPeriodReader Periods => new(Reader, Events, Content);''');s=s.replace('''        Services.GetRequiredService<NativeOperationExecutor>(), Reader, Periods, Content, clock);''','''        Services.GetRequiredService<NativeOperationExecutor>(), Reader, Periods, Content, clock, Calendars);''');p.write_text(s)
p=testing/'TypeIIRangeFixture.cs';s=p.read_text();s=s.replace('''    public Task<TypeIIObservationCalendar> CalendarAsync() =>
        Host.HydrateAsync(new TypeIIObservationCalendar(TenantId, ProgramId));''','''    public Task<TypeIICalendarReadSnapshot> CalendarAsync(params Uuid[] selectedRoots) =>
        Host.Calendars.ReadAsync(TenantId, ProgramId, selectedRoots).AsTask();''');p.write_text(s)
p=op/'StartTypeIIObservationPeriodHandlerTests.cs';s=p.read_text();old='''await fixture.Reader.HydrateAsync(new TypeIIObservationCalendar(fixture.TenantId,
            fixture.ProgramId))''';assert s.count(old)==4;s=s.replace(old,'''await fixture.Host.Calendars.ReadAsync(fixture.TenantId, fixture.ProgramId, [fixture.PeriodId])''');start=s.index('public async Task ShouldRejectSecondOpeningAndKeepFirstRangeGivenOverlappingProgramPeriod');end=s.index('    [Fact]',start);part=s[start:end].replace('[fixture.PeriodId])','[fixture.PeriodId, secondPeriodId])');s=s[:start]+part+s[end:];start=s.index('public async Task ShouldAllowDateReuseGivenCloseFreezeReleasedTheRange');end=s.index('    [Fact]',start);part=s[start:end].replace('[fixture.PeriodId])','[fixture.PeriodId, reopenedId])');s=s[:start]+part+s[end:];p.write_text(s)
p=op/'TypeIIPeriodCommandHandlerTests.cs';s=p.read_text();old='''await fixture.Reader.HydrateAsync(new TypeIIObservationCalendar(
            fixture.TenantId, fixture.ProgramId))''';assert s.count(old)==3;s=s.replace(old,'''await fixture.Host.Calendars.ReadAsync(fixture.TenantId, fixture.ProgramId, [fixture.PeriodId])''',3);start=s.index('public async Task ShouldHoldBothRangesThenReleaseOldRangeGivenAmendmentProcess');end=s.index('    [Fact]',start);part=s[start:end].replace('[fixture.PeriodId])','[fixture.PeriodId, request.CommandId])');s=s[:start]+part+s[end:];s=s.replace('''            var calendar = new TypeIIObservationCalendar(TenantId, ProgramId);

            // The calendar holds''','''            var calendar = new TypeIICalendarRules(TenantId, ProgramId);

            // The calendar holds''');s=s.replace('''            await Writer.SaveAsync(calendar, new RequestDispatchContext(RequestActor.System));''','''            await TypeIICalendarSeeds.WriteAsync(Reader, Writer, Events, Host.Content, calendar);''');p.write_text(s)
p=op/'TypeIIRangeProcessTests.cs';s=p.read_text();replacements={
 'var firstGeneration = (await fixture.CalendarAsync())':'var firstGeneration = (await fixture.CalendarAsync(period))',
 'var held = await fixture.CalendarAsync();':'var held = await fixture.CalendarAsync(period, request.CommandId);',
 'var beforeRelease = await fixture.CalendarAsync();':'var beforeRelease = await fixture.CalendarAsync(period, request.CommandId);',
 'var released = await fixture.CalendarAsync();':'var released = await fixture.CalendarAsync(period, request.CommandId);',
 'var afterOldCancellation = await fixture.CalendarAsync();':'var afterOldCancellation = await fixture.CalendarAsync(period, next.CommandId);',
 'var afterOldClose = await fixture.CalendarAsync();':'var afterOldClose = await fixture.CalendarAsync(next.CommandId);',
 'var afterClose = await fixture.CalendarAsync();':'var afterClose = await fixture.CalendarAsync(next.CommandId);',
 'var calendarBefore = await fixture.CalendarAsync();':'var calendarBefore = await fixture.CalendarAsync(period);',
 'var midway = await fixture.CalendarAsync();':'var midway = await fixture.CalendarAsync(period);',
}
for a,b in replacements.items():assert a in s,a;s=s.replace(a,b)
def method(name,replace):
 global s
 start=s.index('public async Task '+name);end=s.find('    [Fact]',start);end=len(s) if end<0 else end;part=s[start:end]
 for a,b in replace.items():assert a in part,(name,a);part=part.replace(a,b)
 s=s[:start]+part+s[end:]
method('ShouldPersistOpeningIntentBeforeCalendarAndRecoverGivenCrashAfterAcquisition',{'var calendar = await fixture.CalendarAsync();':'var calendar = await fixture.CalendarAsync(period);'})
method('ShouldRejectAmendmentAndKeepOldRangeGivenNewRangeOverlappingThirdPeriod',{'var calendar = await fixture.CalendarAsync();':'var calendar = await fixture.CalendarAsync(intoThird.CommandId, first, third);','var after = await fixture.CalendarAsync();':'var after = await fixture.CalendarAsync(first, earlier.CommandId, third);'})
method('ShouldFenceDelayedAcquisitionGivenCancellationAndReleaseBeforeAnyAcquire',{'var calendar = await fixture.CalendarAsync();':'var calendar = await fixture.CalendarAsync(request.CommandId, period);'})
method('ShouldReleaseNothingGivenStaleSettlementProofOrMissingPeriodFact',{'var before = await fixture.CalendarAsync();':'var before = await fixture.CalendarAsync(request.CommandId);','var after = await fixture.CalendarAsync();':'var after = await fixture.CalendarAsync(request.CommandId);'})
method('ShouldNotApplyAndNotForgeRejectionGivenFencedOpeningAndUnprovenConflict',{'var calendar = await fixture.CalendarAsync();':'var calendar = await fixture.CalendarAsync(first);'})
p.write_text(s)
(testing/'TypeIICalendarSeeds.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Operations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Testing;

/// <summary>Publishes each pure range decision through its actual immutable native owner cut.</summary>
static class TypeIICalendarSeeds
{
    public static Task<TypeIIObservationCalendar> WriteAsync(IAggregateReader reader, IAggregateWriter writer,
        IDomainEventReader events, IImmutableContentStore content, TypeIICalendarRules source, CancellationToken ct = default) =>
        SaveAsync(reader, writer, events, content, source, source.AppliedChanges.ToArray(), ct);

    public static Task<TypeIIObservationCalendar> AppendAsync(IAggregateReader reader, IAggregateWriter writer,
        IDomainEventReader events, IImmutableContentStore content, TypeIICalendarRules source, CancellationToken ct = default) =>
        SaveAsync(reader, writer, events, content, source, source.PendingChanges.ToArray(), ct);

    static async Task<TypeIIObservationCalendar> SaveAsync(IAggregateReader reader, IAggregateWriter writer,
        IDomainEventReader events, IImmutableContentStore content, TypeIICalendarRules source, IReadOnlyList<object> changes, CancellationToken ct)
    {
        var calendars = new TypeIICalendarReader(reader, events, content);
        TypeIIObservationCalendar? owner = null;
        foreach (var change in changes)
        {
            var snapshot = await calendars.ReadAsync(source.TenantId, source.Id, TypeIICalendarContent.RequiredRoots(change), ct: ct);
            var rules = snapshot.Rules;
            var decision = change switch
            {
                TypeIICalendarAuthorizationChange value => rules.Authorize(value.Operation, value.Intent, value.PeriodId,
                    value.Kind, value.NewRange, value.PriorOperationId),
                TypeIICalendarSettlementChange value => rules.Settle(value.Operation, value.Intent, value.PeriodId,
                    value.Settlement, value.TargetOperationId, value.ReleasedOperationId),
                _ => throw new InvalidOperationException("Another calendar fixture mutation kind."),
            };
            Assert.True(decision.IsSuccess, decision.Error?.Message);
            var prepared = await TypeIICalendarContent.FreezeAsync(content, snapshot, rules, ct);
            owner = snapshot.Owner;
            var appended = owner.Append(TypeIICalendarContent.Fact(prepared), prepared, owner.NativeSequence, owner.CommittedStreamPosition);
            Assert.True(appended.IsSuccess, appended.Error?.Message);
            await writer.SaveAsync(owner, new RequestDispatchContext(RequestActor.System), ct);
        }
        source.ClearPendingChanges();
        return owner ?? await reader.HydrateAsync(new TypeIIObservationCalendar(source.TenantId, source.Id), ct);
    }
}
''')
print('Prepared6 existing test/helper migrations and native CalendarSeeds')
