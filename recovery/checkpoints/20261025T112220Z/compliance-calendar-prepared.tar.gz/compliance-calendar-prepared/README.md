# Frozen Calendar native authority handoff

Start with `handoff.json`. `manifest.json` records all28 final paths and exact original/final/RED hashes; all13 existing changed paths have physical originals in `base/`. The15 new paths and final integration bytes are in `work/`.

The actual owner is `TypeIIObservationCalendar`. It now retains a bounded header, the current immutable authority reference, native sequence and one selected native acceptance. Current authority contains live pending/active ranges and a linked immutable terminal-history head. Released reservations and cancellation fences remain durable authority, selected explicitly when a decision needs them. Ordinary read results contain live state.

`TypeIICalendarReader` verifies the exact current cut and terminal chain prefix, then resolves actual native authorization/settlement facts with original metadata. Scalar reservation bindings cover each complete typed mutation. A verified exhausted chain proves absence; missing or corrupt links block admission. `Append` independently checks the exact immutable before/after bytes, business transition, membership/absence evidence, native sequence and physical cut.

The existing acquire/apply/settle/reject protocol is preserved. Amendment activation archives the old reservation using the new amendment's settlement event. Historical released acquisitions retain original authorization receipts; fences retain actual settlement evidence. Rejection can resolve an authorization after release. Accepted logical child retries replay before current Calendar immutable reads. Concurrent fresh calendar cuts reprepare through the existing bounded retry loop. Time releases nothing.

Child provenance keeps the period FirstOwner, original root expected gate/actor and nullable child response fields. The original HTTP202 response remains on the period owner. No route or public command contract changes; keep parent's existing native result hooks and current authorization pipeline.

## Parent execution

1. Apply `tests-red.patch` to the old Calendar API and run `FullyQualifiedName~TypeIICalendarCompactionTests`. The old command owner retains its lifetime terminal dictionary after32 authorize/activate/release cycles and replay, so the retention assertion should fail. Actual RED is parent-owned.
2. Apply `implementation.patch`, `shared.patch`, `migrated-tests.patch`, `native-tests.patch`. Run the native and consumer filters in `handoff.json`, including existing range transport202, cancellation/recovery and close workflows, followed by the required backend suite with `Category!=BrokerIntegration`.
3. Parent runs format/build/analyzers, direct per-file Jev on exact final hashes, resolves actual failures and performs delivery.

After RED is recorded, `implementation.patch`, `shared.patch`, `tests-full.patch` produce the same final files. Both patch orders were applied in isolated `/tmp` directories and reconstructed all28 final files byte-for-byte; see `reconstruction.json`.

The migrated tests retain38 original acceptance names and every existing per-file Assert count. Native regressions use32 real full start→freeze-close→release process cycles, actual missing/corrupt stored history chunks, direct receiver failure classification, original receipt replay with damaged later current content, and rejection of truncated terminal absence evidence at native Append. None were executed by this preparation agent.

`audit.json` records28 C# parses,39 explicit constructor checks, token-last/import/duplicate-using checks and original-baseline gates, all clear. `wiring.json` records the scoped reader, constructor deltas, seven JSON roots, v2 fact fields and fixture selectors. Apply narrow shared/helper delta hunks while preserving newer parent Risk/SystemDescription/TypeII work.

See `LOCAL-BLOCKERS.md` for persistence compatibility, chain traversal cost and remaining evidence boundaries. No main checkout, build, broker, Git, worktree, GitHub, Jev, issue or memory mutations were performed. Cross-family projection key changes remain separately parent assigned.
