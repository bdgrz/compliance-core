from pathlib import Path
import json,re,hashlib
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-calendar-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');parser=Parser(Language(tree_sitter_c_sharp.language()))
paths=[str(p.relative_to(r/'work')) for p in (r/'work/test').rglob('*.cs')]
def walk(node):
 pending=[node]
 while pending:
  value=pending.pop();yield value;pending.extend(reversed(value.children))
def tx(t,n):return t[n.start_byte:n.end_byte].decode()
def sig(t,node):
 ps=[c for c in node.children if c.type=='parameter'];return(sum('=' not in tx(t,c) for c in ps),len(ps))
syntax=[];removed=[];drops=[];missing=[];duplicates=[];tokens=[];names=[];manifest=[]
for path in paths:
 p=r/'work'/path;t=p.read_bytes();old=r/'base'/path;tree=parser.parse(t)
 if tree.root_node.has_error:syntax.append(path)
 seen=set()
 for line in t.decode().splitlines():
  if line.startswith('using ') and line.endswith(';'):
   if line in seen:duplicates.append({'path':path,'using':line})
   seen.add(line)
 for node in walk(tree.root_node):
  if node.type!='parameter_list':continue
  pars=[c for c in node.children if c.type=='parameter']
  for i,par in enumerate(pars):
   typ=par.child_by_field_name('type')
   if typ and tx(t,typ).split('.')[-1]=='CancellationToken' and i!=len(pars)-1:tokens.append({'path':path,'line':t[:par.start_byte].count(b'\n')+1})
 if (repo/path).exists() and not old.exists():missing.append(path)
 if old.exists():
  before=old.read_text();prior=re.findall(r'\b(Should\w+)\s*\(',before);now=re.findall(r'\b(Should\w+)\s*\(',t.decode());names.extend({'path':path,'name':n} for n in prior);removed.extend({'path':path,'name':n} for n in prior if n not in now)
  if t.count(b'Assert.')<before.count('Assert.'):drops.append({'path':path,'before':before.count('Assert.'),'after':t.count(b'Assert.')})
 manifest.append({'path':path,'beforeSha256':hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None,'afterSha256':hashlib.sha256(t).hexdigest()})
known={}
for root in [repo,r/'work']:
 for p in (root/'src').rglob('*.cs'):
  if {'obj','bin'}.intersection(p.parts) or not p.name.startswith(('TypeIICalendar','TypeIIObservationCalendar','AmendTypeIIObservationPeriodHandler')):continue
  t=p.read_bytes()
  if b'TypeIICalendar' not in t and b'AmendTypeIIObservationPeriodHandler' not in t:continue
  tree=parser.parse(t)
  for node in walk(tree.root_node):
   if node.type not in ['class_declaration','record_declaration']:continue
   name=node.child_by_field_name('name');pl=next((c for c in node.children if c.type=='parameter_list'),None)
   if not name:continue
   nm=tx(t,name)
   if pl:known[nm]=[sig(t,pl)]
   body=node.child_by_field_name('body')
   if body:
    for c in body.children:
     if c.type=='constructor_declaration':
      pl=next((x for x in c.children if x.type=='parameter_list'),None)
      if pl:known.setdefault(nm,[]).append(sig(t,pl))
ctors=[];errors=[]
for path in paths:
 t=(r/'work'/path).read_bytes()
 tree=parser.parse(t)
 for node in walk(tree.root_node):
  if node.type!='object_creation_expression':continue
  typ=node.child_by_field_name('type');args=next((x for x in node.children if x.type=='argument_list'),None)
  if not typ or not args:continue
  nm=tx(t,typ).split('.')[-1]
  if nm not in known or not (nm.startswith('TypeIICalendar') or nm in ['TypeIIObservationCalendar','AmendTypeIIObservationPeriodHandler']):continue
  n=sum(x.type=='argument' for x in args.children);item={'path':path,'line':t[:node.start_byte].count(b'\n')+1,'type':nm,'arguments':n};ctors.append(item)
  if not any(a<=n<=b for a,b in known[nm]):errors.append(item|{'expected':known[nm]})
a={'qualification':'Static syntax/explicit ctor/token-order/acceptance/assertion checks only. No compiler/runtime/RED/Jev proof.','paths':len(paths),'syntaxErrors':syntax,'constructorCalls':len(ctors),'constructorErrors':errors,'cancellationTokenNotLast':tokens,'duplicateUsings':duplicates,'missingExistingBeforeBaseline':missing,'originalAcceptanceNames':len(names),'removedAcceptanceNames':removed,'assertionCountDrops':drops,'names':names}
(r/'test-static-audit.json').write_text(json.dumps(a,indent=2)+'\n');(r/'test-source-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({k:v for k,v in a.items() if k!='names'},indent=2))
