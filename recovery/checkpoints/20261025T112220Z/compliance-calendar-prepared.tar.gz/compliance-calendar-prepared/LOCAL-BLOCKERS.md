No missing source-use permit, callback or business protocol was invented. Acquire/apply/settle/reject use the selected existing native TypeIIPeriod/TypeIIRangeProcess protocol. No GitHub issue or memory entry was created.

The two calendar facts explicitly advance to discriminator v2. Persisted v1 upcast/replay, deployed projection/stream migration and broker qualification remain unverified. There is no dual-read compatibility path in this package.

History membership and absence verification traverse an immutable chain prefix. Work grows with prefix length; command business state retains bounded refs and ordinary read results retain current live state. The preparation does not assert constant-time history access or bounded source-scan work.

Shared DI/JSON and the TypeIIRangeHost test helper were based on parent current native TypeII source. Compose only the saved delta hunks with later Risk/SystemDescription/shared changes.

Compiler/analyzers/format, actual old-API RED and native GREEN, production HTTP202/authorization/recovery tests, the backend suite, broker execution and direct per-file Jev remain parent-owned. Static syntax/arity/name/patch checks are not runtime evidence. Parent excludes BrokerIntegration; no brokers were started.

The parent assigned cross-family projection version/decision owner-scope keys to a separate agent. This Calendar handoff changes no such projection keys and excludes parent-owned Boundary keys.
