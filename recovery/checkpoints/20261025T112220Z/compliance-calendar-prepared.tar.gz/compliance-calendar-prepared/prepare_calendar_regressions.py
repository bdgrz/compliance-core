from pathlib import Path
r=Path('/tmp/compliance-calendar-prepared');op=r/'work/test/Compliance.Tests/Features/Operations'
(r/'old-calendar-api-red.cs').write_text('''using System.Collections;
using System.Reflection;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Operations;

public sealed class TypeIICalendarCompactionTests
{
    [Fact]
    public void ShouldKeepCalendarOwnerBoundedGivenLifetimeReleasedReservations()
    {
        // Arrange
        const int count = 32;
        var tenant = Uuid.CreateVersion4(); var program = Uuid.CreateVersion4();
        var calendar = new TypeIIObservationCalendar(tenant, program);
        var intent = new ImmutableContentRef(Uuid.CreateVersion4(), new string('a', 64), 2, "application/json", "type-i-i-range-intent.v1");
        var range = new ObservationRange(new DateOnly(2026, 10, 1), new DateOnly(2027, 9, 30));
        for (var index = 0; index < count; index++)
        {
            var period = Uuid.CreateVersion4(); var root = Uuid.CreateVersion4();
            var operation = new OperationProvenance(Uuid.CreateVersion4(), root, null, "Synthetic",
                ActorReference.ForMember(Uuid.CreateVersion4(), "Period manager"), calendar.Stream, "initial", null,
                new string('b', 64), DateTimeOffset.UtcNow, calendar.Stream, calendar.Stream);
            Assert.True(calendar.Authorize(operation, intent, period, TypeIIRangeOperationKind.Opening, range, null).IsSuccess);
            Assert.True(calendar.Settle(operation with { LogicalId = Uuid.CreateVersion4() }, intent, period,
                TypeIIRangeSettlementKind.Activated, root, null).IsSuccess);
            Assert.True(calendar.Settle(operation with { LogicalId = Uuid.CreateVersion4() }, intent, period,
                TypeIIRangeSettlementKind.Released, root, null).IsSuccess);
        }
        var facts = new AggregateScenario<TypeIIObservationCalendar>(calendar).PendingEvents.ToArray();

        // Act
        var replay = new AggregateScenario<TypeIIObservationCalendar>(new TypeIIObservationCalendar(tenant, program)).Given(facts).Aggregate;
        var retained = typeof(TypeIIObservationCalendar).GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(replay) is ICollection { Count: > 0 }).ToArray();

        // Assert
        Assert.Empty(retained);
        Assert.Equal(count * 3, replay.Revision);
        Assert.Equal(count, replay.ReservationGeneration);
        Assert.Empty(replay.Reservations.Where(value => value.IsLive));
    }
}
''')
(op/'TypeIICalendarCompactionTests.cs').write_text('''using System.Collections;
using System.Reflection;
using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.Operations;

public sealed class TypeIICalendarCompactionTests
{
    [Fact]
    public async Task ShouldKeepCalendarOwnerBoundedGivenLifetimeReleasedReservations()
    {
        // Arrange
        const int count = 32;
        await using var fixture = new TypeIIRangeFixture();
        var roots = new List<Uuid>();
        for (var index = 0; index < count; index++)
        {
            var root = await fixture.StartPeriodAsync(Uuid.CreateVersion4());
            roots.Add(root);
            await fixture.FreezeCloseAsync(root);
            await fixture.Host.ReleaseAsync<ObservationPeriodCloseFrozen>(fixture.StreamOf(root));
        }

        // Act
        var ordinary = await fixture.CalendarAsync();
        var owner = ordinary.Owner;
        var selected = await fixture.CalendarAsync(roots[0], roots[^1]);
        var facts = await fixture.Host.EventsAsync<DomainEvent>(fixture.CalendarStream);
        var retained = typeof(TypeIIObservationCalendar).GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(owner) is ICollection { Count: > 0 }).ToArray();

        // Assert
        Assert.Empty(retained);
        Assert.Equal(count * 3, owner.Revision);
        Assert.Equal(count, owner.ReservationGeneration);
        Assert.Empty(ordinary.Reservations.Where(value => value.IsLive));
        Assert.Empty(ordinary.History);
        Assert.Equal(count, ordinary.Authority.TerminalCount);
        Assert.Null(ordinary.Find(roots[0]));
        Assert.Equal(TypeIIRangeReservationState.Released, selected.Find(roots[0])!.State);
        Assert.Equal(TypeIIRangeReservationState.Released, selected.Find(roots[^1])!.State);
        Assert.Equal(facts[0].Metadata, selected.Find(roots[0])!.AuthorizedFact!.Metadata);
        Assert.Equal(facts[^1].Metadata, selected.Find(roots[^1])!.SettledFact!.Metadata);
        Assert.Equal(count * 3, facts.Count);
    }
}
''')
(op/'TypeIICalendarNativeHistoryTests.cs').write_text('''using System.Text;
using Bdgrz.Compliance.Features.AuditPopulations;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Operations;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Operations;

public sealed class TypeIICalendarNativeHistoryTests
{
    [Theory]
    [InlineData(true, false)]
    [InlineData(false, false)]
    [InlineData(true, true)]
    [InlineData(false, true)]
    public async Task ShouldRejectUnprovenTerminalMembershipOrAbsenceGivenDamagedCalendarHistoryHead(bool unavailable, bool absent)
    {
        // Arrange
        await using var fixture = new TypeIIRangeFixture();
        var closed = await fixture.StartPeriodAsync();
        await fixture.FreezeCloseAsync(closed);
        await fixture.Host.ReleaseAsync<ObservationPeriodCloseFrozen>(fixture.StreamOf(closed));
        var current = await fixture.CalendarAsync();
        var head = current.Authority.ReleasedHistory!;
        var pending = await fixture.AcceptOpeningAsync(Uuid.CreateVersion4());
        var period = await fixture.PeriodAsync(pending);
        var accepted = period.AcceptedFor(pending)!;
        var intentReference = TypeIIPeriod.IntentOf(accepted)!;
        var intent = await fixture.Host.Content.ReadJsonAsync<TypeIIRangeIntent>(fixture.TenantId.ToString(), intentReference);
        var source = current.Rules;
        var operation = TypeIIRangeEffects.Child(TypeIIRangeEffects.ReceiverCommandId(accepted.Metadata.EventId,
            nameof(AcquireTypeIIPeriodRange), intent.Header.Episode), nameof(AcquireTypeIIPeriodRange), accepted.Metadata.EventId,
            intent, fixture.CalendarStream, TypeIIRangeFixture.StartedAt);
        Assert.True(source.Authorize(operation, intentReference, pending, TypeIIRangeOperationKind.Opening, intent.NewRange, null).IsSuccess);
        await DamageAsync(fixture.Host.Services.GetRequiredService<IKvClient>(), fixture.TenantId.ToString(), head, unavailable);

        // Act
        var failure = await Record.ExceptionAsync(async () =>
        {
            if (absent)
                await TypeIICalendarSeeds.AppendAsync(fixture.Host.Reader, fixture.Host.Writer, fixture.Host.Events, fixture.Host.Content, source);
            else
                await fixture.Host.Calendars.ReadAsync(fixture.TenantId, fixture.ProgramId, [closed]);
        });
        var after = await fixture.CalendarAsync();
        var facts = await fixture.Host.EventsAsync<DomainEvent>(fixture.CalendarStream);

        // Assert
        if (unavailable) Assert.IsType<ImmutableContentUnavailableException>(failure);
        else Assert.IsType<ImmutableContentIntegrityException>(failure);
        Assert.Equal(current.Revision, after.Revision);
        Assert.Equal(current.Owner.NativeSequence, after.Owner.NativeSequence);
        Assert.Equal(current.Owner.CurrentAuthority, after.Owner.CurrentAuthority);
        Assert.Empty(after.History);
        Assert.Empty(after.Reservations);
        Assert.Equal(3, facts.Count);
    }

    static async Task DamageAsync(IKvClient client, string realm, Bdgrz.Compliance.Features.Proofs.ImmutableContentRef reference,
        bool unavailable)
    {
        var hex = reference.ContentId.ToString().Replace("-", "", StringComparison.Ordinal).ToLowerInvariant();
        await using var transaction = await client.BeginAsync($"kv://bdgrz/immutable-content/{realm}-{hex[..2]}", KvMode.ReadWrite);
        if (unavailable)
            await transaction.DeleteAsync(Encoding.UTF8.GetBytes($"m/{hex}"));
        else
        {
            var key = Encoding.UTF8.GetBytes($"c/{hex}/000000");
            var stored = await transaction.GetAsync(key);
            Assert.True(stored.Found);
            var bytes = stored.Value!.Value.ToArray();
            bytes[0] ^= 1;
            await transaction.PutAsync(key, bytes);
        }
        await transaction.CommitAsync(KvDurability.Sync);
    }
}
''')
print('Saved old API RED and native retained-state/real KV terminal-history regressions')
