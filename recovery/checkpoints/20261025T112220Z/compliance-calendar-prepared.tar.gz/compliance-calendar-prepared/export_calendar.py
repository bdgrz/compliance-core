from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
r=Path('/tmp/compliance-calendar-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
def sha(b):return hashlib.sha256(b).hexdigest()
def diff(p,a,b):return ''.join(difflib.unified_diff((a or b'').decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p if a is not None else '/dev/null',tofile='b/'+p))
redPath='test/Compliance.Tests/Features/Operations/TypeIICalendarCompactionTests.cs';red=(r/'old-calendar-api-red.cs').read_bytes();shared={'src/Compliance.Core/ComplianceCoreJsonContext.cs','src/Compliance.Core/ComplianceServiceCollectionExtensions.cs'}
provenance={x['path']:x for x in json.loads((r/'baselines.json').read_text())};files={};groups={name:[] for name in ['tests-red.patch','implementation.patch','shared.patch','migrated-tests.patch','native-tests.patch','tests-full.patch']};groups['tests-red.patch']=[diff(redPath,None,red)]
manifest=[]
for f in sorted((r/'work').rglob('*.cs')):
 p=str(f.relative_to(r/'work'));b=r/'base'/p;old=b.read_bytes() if b.exists() else None;new=f.read_bytes()
 if old==new:continue
 assert not (repo/p).exists() or old is not None,'Existing path missing saved original: '+p
 assert new.endswith(b'\n') and b'\r\n' not in new,p
 if old is not None:assert p in provenance and provenance[p]['beforeSha256']==sha(old),p
 files[p]={'before':old,'after':new}
 phase='shared.patch' if p in shared else 'native-tests.patch' if p.endswith('TypeIICalendarNativeHistoryTests.cs') else 'migrated-tests.patch' if p.startswith('test/') else 'implementation.patch'
 groups[phase].append(diff(p,red if p==redPath else old,new))
 if p.startswith('test/'):groups['tests-full.patch'].append(diff(p,old,new))
 manifest.append({'path':p,'phase':phase,'beforeSha256':sha(old) if old is not None else None,'afterSha256':sha(new),'redBeforeSha256':sha(red) if p==redPath else None,'baselineSource':provenance[p]['baselineSource'] if p in provenance else None,'originalExistsInRepository':(repo/p).exists()})
assert redPath in files and files[redPath]['before'] is None
for name,parts in groups.items():(r/name).write_text(''.join(parts))
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
orders={'tests-first':['tests-red.patch','implementation.patch','shared.patch','migrated-tests.patch','native-tests.patch'],'all-final':['implementation.patch','shared.patch','tests-full.patch']};verified={}
for mode,order in orders.items():
 target=Path(tempfile.mkdtemp(prefix='calendar-reconstruct-',dir=r))
 try:
  for p,v in files.items():
   if v['before'] is not None:
    f=target/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(v['before'])
  for name in order:
   result=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/name)],cwd=target,capture_output=True,text=True);assert result.returncode==0,(mode,name,result.stdout,result.stderr)
  bad=[p for p,v in files.items() if not (target/p).exists() or (target/p).read_bytes()!=v['after']];assert not bad,(mode,bad)
  verified[mode]={'patchOrder':order,'exactFiles':len(files)}
 finally:shutil.rmtree(target)
(r/'reconstruction.json').write_text(json.dumps(verified,indent=2)+'\n')
audit=json.loads((r/'audit.json').read_text())
for field in ['syntaxErrors','constructorErrors','cancellationTokenNotLast','duplicateUsings','potentialMissingProofsUsing','removedAcceptanceNames','assertionCountDrops','existingRepositoryPathsMissingBefore']:assert not audit[field],(field,audit[field])
h={'root':str(r),'status':'Frozen offline native Calendar authority compaction; parent owns actual runtime RED/GREEN, compiler/analyzers, tests, direct per-file Jev review and Git/GitHub delivery.','changedFiles':len(files),'implementationFiles':sum(not p.startswith('test/') and p not in shared for p in files),'testFiles':sum(p.startswith('test/') for p in files),'sharedFiles':len(shared),'existingPathsWithOriginals':sum(v['before'] is not None for v in files.values()),'newPaths':sum(v['before'] is None for v in files.values()),'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in groups},'testsFirstOrder':orders['tests-first'],'allFinalOrder':orders['all-final'],'oldApiRedFilter':'FullyQualifiedName~TypeIICalendarCompactionTests','expectedOldApiRed':'ShouldKeepCalendarOwnerBoundedGivenLifetimeReleasedReservations: existing command owner retains nonempty lifetime terminal dictionary after32 authorize/activate/release cycles and replay.','nativeFocusedFilter':'FullyQualifiedName~TypeIICalendarCompactionTests|FullyQualifiedName~TypeIICalendarNativeHistoryTests|FullyQualifiedName~TypeIIObservationCalendarTests|FullyQualifiedName~TypeIIRangeProcessTests','consumerFocusedFilter':'FullyQualifiedName~StartTypeIIObservationPeriodHandlerTests|FullyQualifiedName~TypeIIPeriodCommandHandlerTests|FullyQualifiedName~TypeIIRangeTransport|FullyQualifiedName~GenerateDueControlOccurrences|FullyQualifiedName~ControlOccurrenceFanOut|FullyQualifiedName~ClosePreview','suiteFilter':'Category!=BrokerIntegration','staticAudit':'audit.json','exactReconstruction':'reconstruction.json','wiring':'wiring.json','readme':'README.md','localBlockers':'LOCAL-BLOCKERS.md','originalAcceptanceNames':audit['originalAcceptanceNames'],'constructorCalls':audit['constructorCallsAcrossEffectiveTree'],'notes':['Fresh selected protocol is TypeIIObservationCalendar, child Acquire/Apply/Settle/Reject over native TypeIIPeriod; no new permit/callback/business protocol contract.','Owner retains only current Header/CurrentAuthorityRef, native sequence and selected acceptance. Current authority stores live ranges; released/fenced history is a linked immutable head. Ordinary read result contains live state and explicitly selected terminal roots.','Native Append verifies actual before content, full typed transition and linked terminal membership/absence evidence. History source proof returns actual stored authorization/settlement native facts and exact metadata.','Child period FirstOwner/root expected gate/null response semantics retained. Original HTTP202 remains on period; accepted child replay precedes Calendar immutable reads.','Apply only narrow shared/test-helper delta hunks while preserving parent current Risk/SystemDescription/TypeII integration.','Facts explicitly use native v2; persisted v1 replay/upcast/rebuild qualification not claimed.','Separate cross-family projection-key audit is parent assigned; Boundary and all such key edits remain outside this Calendar package.'],'noRuntimeClaims':True}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n')
print(json.dumps({k:h[k] for k in ['changedFiles','implementationFiles','testFiles','sharedFiles','existingPathsWithOriginals','newPaths','manifestSha256','patches']},indent=2))
