from pathlib import Path
r=Path('/tmp/compliance-import-receiver-preparation-prepared');p='src/Compliance.Core/Features/Applications/ApplicationImportReceivers.cs';s=(r/'work'/p).read_text();a=s.index('    public async ValueTask<Result<ReceiverOutcome>> ReserveAsync(');b=s.index('    public async ValueTask<Result<ReceiverOutcome>> CommitAsync(',a)
s=s[:a]+'''    public async ValueTask<Result<ReceiverOutcome>> ReserveAsync(IExecutionContext context,
        ReserveApplicationImportTarget command, CancellationToken ct)
    {
        if (Malformed(command.CommandId, command.OperationId, command.Generation))
            return SourceUseReceiverSupport.Permanent("The reservation names another generation or operation.");
        var native = await ReadTargetNativeAsync(command.Target, command.Source, command.BatchId, command.ApplicationId,
            command.OperationId, ct).ConfigureAwait(false);
        if (native.Failure is { } refused)
            return refused;
        var bound = await BindTargetRowsAsync(native.Context!, command.ApplicationId, command.Intent, command.GroupedRows, ct)
            .ConfigureAwait(false);
        if (!bound.IsSuccess)
            return Result<ReceiverOutcome>.Failure(bound.Error!);
        var (tenant, batch, group) = (native.Context!.TenantId, native.Context.Batch, bound.Value!);
        var provenance = ApplicationImportEffects.Child(command.CommandId, nameof(ReserveApplicationImportTarget),
            command.Source.EventId, ApplicationImportIntentBindings.HeaderOf(batch.Plan!.Operation), command.Target, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        Result<ReceiverOutcome>? Early(DeclaredApplication application, bool prepared)
        {
            var hold = application.FindImportHold(batch.Id);
            if (hold?.Reserved is { } reserved &&
                (reserved.Intent != command.Intent || reserved.InitialApplicationRevision != group.InitialApplicationRevision ||
                    reserved.CandidateContentRevision != group.CandidateContentRevision ||
                    reserved.Operation.RootOperationId != command.OperationId || reserved.Operation.CausationEventId != command.Source.EventId ||
                    reserved.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(reserved.Operation with { LogicalId = command.CommandId }) != binding))
                return SourceUseReceiverSupport.Permanent("The target reservation has another exact native group binding.");
            if (Decide(application.Acceptance, binding, application.Stream) is { } decided)
                return decided;
            if (hold?.Reserved is not null)
                return hold.Settled is not null || hold.Fence is not null
                    ? SourceUseReceiverSupport.Superseded("The target was fenced or settled before it was reserved.",
                        NativeFactReference.Of(application.Stream, (DomainEvent?)hold.Settled ?? hold.Fence!))
                    : SourceUseReceiverSupport.Replayed(NativeFactReference.Of(application.Stream, hold.Reserved));
            if (!prepared)
                return null;
            if (hold is not null)
                return SourceUseReceiverSupport.Superseded("The target was fenced or settled before it was reserved.",
                    NativeFactReference.Of(application.Stream, (DomainEvent?)hold.Settled ?? hold.Fence!));
            return application.CheckReserve(batch.Id, group.InitialApplicationRevision) is { } error
                ? Result<ReceiverOutcome>.Failure(error) : null;
        }
        var preparation = await NativeReceiverPreparation.PrepareAsync<DeclaredApplication, PreparedTarget>(reader,
            () => new DeclaredApplication(tenant, command.ApplicationId, command.CommandId),
            application => Early(application, false),
            (_, token) => PrepareTargetAsync(command.Target, command.Source, command.BatchId, command.ApplicationId,
                command.OperationId, command.Intent, command.GroupedRows, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        if (preparation.Value.Value!.Outcome is { } terminal)
            return terminal;
        return await AppendAsync(context, () => new DeclaredApplication(tenant, command.ApplicationId, command.CommandId),
            application => application.Acceptance, application => Early(application, true),
            (DeclaredApplication application) => application.Reserve(provenance, command.Intent, batch.Id, command.ApplicationId,
                group.InitialApplicationRevision, group.CandidateContentRevision), ct).ConfigureAwait(false);
    }

    public async ValueTask<Result<ReceiverOutcome>> ApplyAsync(IExecutionContext context,
        ApplyApplicationImportEffect command, CancellationToken ct)
    {
        if (Malformed(command.CommandId, command.OperationId, command.Generation))
            return SourceUseReceiverSupport.Permanent("The apply names another generation or operation.");
        var native = await ReadTargetNativeAsync(command.Target, command.Source, command.BatchId, command.ApplicationId,
            command.OperationId, ct).ConfigureAwait(false);
        if (native.Failure is { } refused)
            return refused;
        var bound = await BindTargetRowsAsync(native.Context!, command.ApplicationId, command.Intent, command.RowGroup, ct)
            .ConfigureAwait(false);
        if (!bound.IsSuccess)
            return Result<ReceiverOutcome>.Failure(bound.Error!);
        var (tenant, batch, group) = (native.Context!.TenantId, native.Context.Batch, bound.Value!);
        var active = await tenants.IsActiveAsync(tenant, ct).ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        if (!active)
            return SourceUseReceiverSupport.Transient("The tenant is not active; retry after reactivation.");
        var provenance = ApplicationImportEffects.Child(command.CommandId, nameof(ApplyApplicationImportEffect),
            command.Source.EventId, ApplicationImportIntentBindings.HeaderOf(batch.Plan!.Operation), command.Target, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        Result<ReceiverOutcome>? Early(DeclaredApplication application, bool prepared)
        {
            var hold = application.FindImportHold(batch.Id);
            if (hold is { IsApplied: true })
            {
                var effect = hold.Effects[0];
                if (effect.Intent != command.Intent || effect.FrozenPlan != batch.Plan.FrozenPlan ||
                    effect.PlanRevision != batch.Plan.Revision || effect.PlanSha256 != batch.Plan.PlanSha256 ||
                    effect.Operation.RootOperationId != command.OperationId || effect.Operation.CausationEventId != command.Source.EventId ||
                    effect.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(effect.Operation with { LogicalId = command.CommandId }) != binding)
                    return SourceUseReceiverSupport.Permanent("The target effect has another exact native group binding.");
            }
            if (Decide(application.Acceptance, binding, application.Stream) is { } decided)
                return decided;
            if (hold is { IsApplied: true, Fence: null, Settled: null })
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(application.Stream, hold.Effects[0]));
            if (!prepared)
                return null;
            if (hold is null)
                return SourceUseReceiverSupport.Transient("The target reservation is not visible yet.");
            if (hold.Fence is not null || hold.Settled is not null)
                return SourceUseReceiverSupport.Superseded("The target was fenced or settled; the delayed apply does nothing.",
                    NativeFactReference.Of(application.Stream, (DomainEvent?)hold.Settled ?? hold.Fence!));
            if (hold.Reserved is null || hold.Reserved.InitialApplicationRevision != group.InitialApplicationRevision ||
                hold.Reserved.CandidateContentRevision != group.CandidateContentRevision)
                return SourceUseReceiverSupport.Permanent("The target hold differs from the frozen group.");
            return null;
        }
        var preparation = await NativeReceiverPreparation.PrepareAsync<DeclaredApplication, PreparedApply>(reader,
            () => new DeclaredApplication(tenant, command.ApplicationId, command.CommandId),
            application => Early(application, false),
            (_, token) => PrepareApplyAsync(command, provenance, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var prepared = preparation.Value.Value!;
        if (prepared.Outcome is { } terminal)
            return terminal;
        var accepted = prepared.Context!.Batch.Plan!;
        return await AppendAsync(context, () => new DeclaredApplication(tenant, command.ApplicationId, command.CommandId),
            application => application.Acceptance, application => Early(application, true),
            (DeclaredApplication application) => application.ApplyImportGroup(batch.Id, accepted.Revision, accepted.PlanSha256,
                accepted.FrozenPlan, command.Intent, prepared.Inputs!, prepared.RecordedAt), ct).ConfigureAwait(false);
    }

'''+s[b:]
a=s.index('    async ValueTask<TargetVerification> VerifyTargetAsync(')
s=s[:a]+'''    async ValueTask<NativeTargetVerification> ReadTargetNativeAsync(EventStreamAddress target, NativeFactReference source,
        Uuid batchId, Uuid applicationId, Uuid operationId, CancellationToken ct)
    {
        var native = await verifier.LoadNativeAsync(target.Realm, batchId, Uuid.Empty, ct).ConfigureAwait(false);
        if (!native.IsSuccess)
            return new NativeTargetVerification(null, Result<ReceiverOutcome>.Failure(native.Error!));
        var batch = native.Value!.Batch;
        if (batch.IsCancelRequested || batch.IsEnded)
            return new NativeTargetVerification(null, ApplicationImportVerifier.Ended(batch, "The batch ended before this target step."));
        if (!ApplicationImportVerifier.IsFact(source, batch, batch.Authorization))
            return new NativeTargetVerification(null, SourceUseReceiverSupport.Transient("The execution authorization is not visible yet."));
        return operationId != batch.Plan!.Operation.RootOperationId || target != new DeclaredApplication(native.Value.TenantId, applicationId).Stream
            ? new NativeTargetVerification(null, SourceUseReceiverSupport.Permanent("The target differs from its exact native execution authorization."))
            : new NativeTargetVerification(native.Value, null);
    }

    async ValueTask<Result<ImportTargetGroupIntent>> BindTargetRowsAsync(ApplicationImportNativeContext native,
        Uuid applicationId, ImmutableContentRef intent, ImmutableContentRef rows, CancellationToken ct)
    {
        try
        {
            var group = await ApplicationImportContent.ReadAsync<ImportTargetGroupIntent>(content, native.TenantId, intent, ct)
                .ConfigureAwait(false);
            return group.BatchId != native.Batch.Id || group.ApplicationId != applicationId || group.Rows is null || group.Rows.Content != rows
                ? Result<ImportTargetGroupIntent>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The target rows differ from the frozen group intent.", false))
                : Result<ImportTargetGroupIntent>.Success(group);
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<ImportTargetGroupIntent>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The required target-row binding cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

    async ValueTask<Result<PreparedTarget>> PrepareTargetAsync(EventStreamAddress target, NativeFactReference source,
        Uuid batchId, Uuid applicationId, Uuid operationId, ImmutableContentRef intent, ImmutableContentRef rows,
        CancellationToken ct)
    {
        try
        {
            var verified = await VerifyTargetAsync(target, source, batchId, applicationId, operationId, intent, ct)
                .ConfigureAwait(false);
            if (verified.Failure is { } failure)
                return failure.IsSuccess ? Result<PreparedTarget>.Success(new PreparedTarget(null, null, failure))
                    : Result<PreparedTarget>.Failure(failure.Error!);
            return rows != verified.Group!.Rows.Content
                ? Result<PreparedTarget>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The target differs from its frozen row group.", false))
                : Result<PreparedTarget>.Success(new PreparedTarget(verified.Context!, verified.Group, null));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedTarget>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen target cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

    async ValueTask<Result<PreparedApply>> PrepareApplyAsync(ApplyApplicationImportEffect command,
        OperationProvenance provenance, CancellationToken ct)
    {
        var verified = await PrepareTargetAsync(command.Target, command.Source, command.BatchId, command.ApplicationId,
            command.OperationId, command.Intent, command.RowGroup, ct).ConfigureAwait(false);
        if (!verified.IsSuccess)
            return Result<PreparedApply>.Failure(verified.Error!);
        if (verified.Value!.Outcome is { } terminal)
            return Result<PreparedApply>.Success(new PreparedApply(null, null, default, terminal));
        var (loaded, group) = (verified.Value.Context!, verified.Value.Group!);
        try
        {
            var rows = await ApplicationImportContent.ReadSelectionAsync<ApplicationImportPlannedRow>(content,
                loaded.TenantId, group.Rows, ct).ConfigureAwait(false);
            if (rows.Count == 0 || rows.Any(row => row.ApplicationId != command.ApplicationId))
                return Result<PreparedApply>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The frozen group rows name another application.", false));
            if (await VerifyRetirementsAsync(loaded, rows, ct).ConfigureAwait(false) is { } retirement)
                return Result<PreparedApply>.Failure(retirement.Error!);
            var planned = ApplicationImportGroupFold.Fold(group.InitialApplicationRevision != 0,
                false, (long)group.InitialApplicationRevision, rows);
            if (!planned.IsSuccess || (ulong)planned.Value![^1] != group.CandidateContentRevision)
                return Result<PreparedApply>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The frozen group differs from its candidate revision.", false));
            var inputs = new List<ApplicationImportEffectInput>(rows.Count);
            for (var index = 0; index < rows.Count; index++)
                inputs.Add(new ApplicationImportEffectInput(provenance with
                {
                    LogicalId = ApplicationImportEffects.EffectLogicalId(command.CommandId, index, rows[index].RowId),
                }, rows[index], planned.Value[index]));
            return Result<PreparedApply>.Success(new PreparedApply(loaded, inputs, clock.GetUtcNow(), null));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedApply>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The frozen group rows cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
a=s.index('    sealed record TargetVerification(')
s=s[:a]+'''    sealed record NativeTargetVerification(ApplicationImportNativeContext? Context, Result<ReceiverOutcome>? Failure);

    sealed record PreparedTarget(ApplicationImportContext? Context, ImportTargetGroupIntent? Group,
        Result<ReceiverOutcome>? Outcome);

    sealed record PreparedApply(ApplicationImportContext? Context, IReadOnlyList<ApplicationImportEffectInput>? Inputs,
        DateTimeOffset RecordedAt, Result<ReceiverOutcome>? Outcome);

'''+s[a:]
(r/'work'/p).write_text(s)
