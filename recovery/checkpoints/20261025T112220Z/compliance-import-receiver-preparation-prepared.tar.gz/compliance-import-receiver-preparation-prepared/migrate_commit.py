from pathlib import Path
r=Path('/tmp/compliance-import-receiver-preparation-prepared');p='src/Compliance.Core/Features/Applications/ApplicationImportReceivers.cs';s=(r/'work'/p).read_text();a=s.index('    public async ValueTask<Result<ReceiverOutcome>> CommitAsync(');b=s.index('    public async ValueTask<Result<ReceiverOutcome>> FenceAsync(',a)
s=s[:a]+'''    public async ValueTask<Result<ReceiverOutcome>> CommitAsync(IExecutionContext context,
        CommitApplicationImportBatch command, CancellationToken ct)
    {
        if (Malformed(command.CommandId, command.OperationId, command.Generation))
            return SourceUseReceiverSupport.Permanent("The commit names another generation or operation.");
        var native = await verifier.LoadNativeAsync(command.Target.Realm, command.BatchId, command.CommandId, ct)
            .ConfigureAwait(false);
        if (!native.IsSuccess)
            return Result<ReceiverOutcome>.Failure(native.Error!);
        var (tenant, batch) = (native.Value!.TenantId, native.Value.Batch);
        var plan = batch.Plan!;
        if (command.Target != batch.Stream || command.Intent != plan.FrozenPlan || command.OperationId != plan.Operation.RootOperationId)
            return SourceUseReceiverSupport.Permanent("The commit differs from the frozen import plan.");
        if ((batch.IsCancelRequested || batch.IsEnded) && batch.Committed is null)
            return ApplicationImportVerifier.Ended(batch, "The batch ended before it published.");
        if (!ApplicationImportVerifier.IsFact(command.Source, batch, batch.Authorization))
            return SourceUseReceiverSupport.Transient("The execution authorization is not visible yet.");
        var provenance = ApplicationImportEffects.Child(command.CommandId, nameof(CommitApplicationImportBatch),
            command.Source.EventId, ApplicationImportIntentBindings.HeaderOf(plan.Operation), batch.Stream, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        Result<ReceiverOutcome>? Early(ApplicationImportBatch owner)
        {
            if (owner.Committed is { } committed &&
                (committed.Intent != command.Intent || committed.Operation.RootOperationId != command.OperationId ||
                    committed.Operation.CausationEventId != command.Source.EventId || committed.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(committed.Operation with { LogicalId = command.CommandId }) != binding))
                return SourceUseReceiverSupport.Permanent("The publication has another exact native execution binding.");
            if (Decide(owner.Acceptance, binding, owner.Stream) is { } decided)
                return decided;
            if (owner.Committed is { } existing)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, existing));
            return owner.IsCancelRequested || owner.IsEnded
                ? ApplicationImportVerifier.Ended(owner, "The batch ended before it published.") : null;
        }
        var preparation = await NativeReceiverPreparation.PrepareAsync<ApplicationImportBatch, PreparedCommit>(reader,
            () => new ApplicationImportBatch(tenant, batch.Id, command.CommandId), Early,
            (owner, token) => PrepareCommitAsync(command, native.Value with { Batch = owner }, token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var prepared = preparation.Value.Value!;
        var frozen = prepared.Context.Plan;
        return await AppendAsync(context, () => new ApplicationImportBatch(tenant, batch.Id, command.CommandId),
            fresh => fresh.Acceptance, Early,
            (ApplicationImportBatch fresh) => fresh.Commit(provenance, command.Intent, command.TargetProofManifest,
                frozen.Rows.Content, frozen.SourceRevision, prepared.RecordedAt, prepared.Result), ct).ConfigureAwait(false);
    }

'''+s[b:]
a=s.index('    async ValueTask<CancellationNativeVerification> ReadCancellationNativeAsync(')
s=s[:a]+'''    async ValueTask<Result<PreparedCommit>> PrepareCommitAsync(CommitApplicationImportBatch command,
        ApplicationImportNativeContext native, CancellationToken ct)
    {
        var loaded = await verifier.PrepareAsync(native, ct).ConfigureAwait(false);
        if (!loaded.IsSuccess)
            return Result<PreparedCommit>.Failure(loaded.Error!);
        try
        {
            var rows = await verifier.RowsAsync(loaded.Value!, ct).ConfigureAwait(false);
            if (!rows.IsSuccess)
                return Result<PreparedCommit>.Failure(rows.Error!);
            var proofs = await ApplicationImportContent.ReadAsync<IReadOnlyList<ApplicationImportEffectProof>>(content,
                native.TenantId, command.TargetProofManifest, ct).ConfigureAwait(false);
            if (await VerifyProofsAsync(loaded.Value!, rows.Value!, proofs, ct).ConfigureAwait(false) is { } proven)
                return Result<PreparedCommit>.Failure(proven.Error!);
            if (!await tenants.IsActiveAsync(native.TenantId, ct).ConfigureAwait(false))
                return Result<PreparedCommit>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The tenant is not active; retry after reactivation.", true));
            if (await VerifyRetirementsAsync(loaded.Value!, rows.Value!, ct).ConfigureAwait(false) is { } retirement)
                return Result<PreparedCommit>.Failure(retirement.Error!);
            var now = clock.GetUtcNow();
            var result = await ApplicationImportContent.UnitResultAsync(content, native.TenantId, command.OperationId, ct)
                .ConfigureAwait(false);
            return Result<PreparedCommit>.Success(new PreparedCommit(loaded.Value!, now, result));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedCommit>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The import publication cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
a=s.index('    sealed record CancellationNativeVerification(');s=s[:a]+'''    sealed record PreparedCommit(ApplicationImportContext Context, DateTimeOffset RecordedAt, ImmutableContentRef Result);

'''+s[a:];(r/'work'/p).write_text(s)
