from pathlib import Path
r=Path('/tmp/compliance-import-receiver-preparation-prepared');p='src/Compliance.Core/Features/Applications/ApplicationImportReceivers.cs';s=(r/'base'/p).read_text();a=s.index('        var loaded = await verifier.LoadAsync(');b=s.index('    public async ValueTask<Result<ReceiverOutcome>> ReserveAsync(',a)
s=s[:a]+'''        var native = await verifier.LoadNativeAsync(command.Target.Realm, command.BatchId, Uuid.Empty, ct)
            .ConfigureAwait(false);
        if (!native.IsSuccess)
            return Result<ReceiverOutcome>.Failure(native.Error!);
        var (tenant, batch) = (native.Value!.TenantId, native.Value.Batch);
        var plan = batch.Plan!;
        var stream = new ApplicationImportSource(tenant, plan.SourceKey, plan.SourceNamespace).Stream;
        if (!ApplicationImportVerifier.IsFact(command.Source, batch, plan) || command.Intent != plan.FrozenPlan ||
            command.OperationId != plan.Operation.RootOperationId || command.Target != stream ||
            command.SourceKey != plan.SourceKey || command.SourceNamespace != plan.SourceNamespace)
            return SourceUseReceiverSupport.Permanent("The claim differs from the frozen import plan.");
        var provenance = ApplicationImportEffects.Child(command.CommandId, nameof(ClaimApplicationImportSource),
            command.Source.EventId, ApplicationImportIntentBindings.HeaderOf(plan.Operation), stream, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        Result<ReceiverOutcome>? Early(ApplicationImportSource source, bool prepared)
        {
            var slot = source.Find(batch.Id);
            if (slot?.Admitted is { } admitted)
            {
                if (command.ExpectedRevision != admitted.Revision - 1 || admitted.Intent != command.Intent ||
                    admitted.Operation.RootOperationId != command.OperationId ||
                    admitted.Operation.CausationEventId != command.Source.EventId || admitted.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(admitted.Operation with { LogicalId = command.CommandId }) != binding)
                    return SourceUseReceiverSupport.Permanent("The claim differs from its exact native source admission.");
            }
            else if (!prepared)
                return null;
            if (batch.IsCancelRequested || batch.IsEnded)
                return ApplicationImportVerifier.Ended(batch, "The batch ended before its source was claimed.");
            if (Decide(source.Acceptance, binding, source.Stream) is { } decided)
                return decided;
            if (slot is not null)
                return slot.Settled is not null
                    ? SourceUseReceiverSupport.Superseded("The source claim of this batch was settled before it was granted.",
                        NativeFactReference.Of(source.Stream, slot.Settled))
                    : SourceUseReceiverSupport.Replayed(NativeFactReference.Of(source.Stream, slot.Admitted!));
            if (source.ActiveBatchId is not null)
                return SourceUseReceiverSupport.Transient("Another batch holds this source. Retry after it settles.");
            return source.Revision != command.ExpectedRevision
                ? SourceUseReceiverSupport.Permanent("The source changed after this plan was frozen.")
                : null;
        }

        var preparation = await NativeReceiverPreparation.PrepareAsync<ApplicationImportSource, ApplicationImportContext>(reader,
            () => new ApplicationImportSource(tenant, plan.SourceKey, plan.SourceNamespace, command.CommandId, batch.Id),
            source => Early(source, false), async (_, token) =>
            {
                var loaded = await verifier.PrepareAsync(native.Value, token).ConfigureAwait(false);
                if (!loaded.IsSuccess)
                    return Result<ApplicationImportContext>.Failure(loaded.Error!);
                return command.ExpectedRevision != loaded.Value!.Plan.SourceRevision
                    ? Result<ApplicationImportContext>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The claim differs from the frozen import plan.", false))
                    : loaded;
            }, ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        return await AppendAsync(context, () => new ApplicationImportSource(tenant, plan.SourceKey,
                plan.SourceNamespace, command.CommandId, batch.Id), source => source.Acceptance,
            source => Early(source, true),
            (ApplicationImportSource source) => source.Claim(provenance, command.Intent, batch.Id), ct).ConfigureAwait(false);
    }

'''+s[b:];(r/'work'/p).write_text(s)
