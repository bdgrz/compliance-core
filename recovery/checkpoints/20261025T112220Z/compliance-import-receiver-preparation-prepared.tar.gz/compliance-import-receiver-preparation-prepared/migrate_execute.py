from pathlib import Path
r=Path('/tmp/compliance-import-receiver-preparation-prepared');p='src/Compliance.Core/Features/Applications/ExecuteApplicationImportHandler.cs';s=(r/'base'/p).read_text();s=s.replace('using Bdgrz.Compliance.Features.NativeOperations;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Processes;\nusing Bdgrz.Compliance.Features.SourceUse;')
a=s.index('        var loaded = await verifier.LoadAsync(');b=s.index('        for (var attempt',a)
s=s[:a]+'''        var native = await verifier.LoadNativeAsync(request.TenantId.ToString(), request.BatchId, request.CommandId, ct)
            .ConfigureAwait(false);
        if (!native.IsSuccess)
            return Result.Failure(native.Error!);
        var batch = native.Value!.Batch;
        var plan = batch.Plan!;
        if (batch.IsCancelRequested || batch.IsEnded)
            return Result.Success;
        var source = await reader.HydrateAsync(new ApplicationImportSource(request.TenantId, plan.SourceKey,
            plan.SourceNamespace, selectedBatchId: batch.Id), ct).ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        if (source.Find(batch.Id) is not { IsActive: true, Admitted: { } admitted } ||
            admitted.Intent != plan.FrozenPlan || admitted.Operation.CausationEventId != plan.Metadata.EventId ||
            admitted.Operation.RootOperationId != plan.Operation.RootOperationId)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The source claim of this batch is not visible yet.", isTransient: true));
        var provenance = ApplicationImportEffects.Child(request.CommandId, CommandKind, plan.Metadata.EventId,
            ApplicationImportIntentBindings.HeaderOf(plan.Operation), batch.Stream, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        Result<ReceiverOutcome>? Decide(ApplicationImportBatch owner)
        {
            switch (owner.Acceptance.Decide(binding))
            {
                case NativeAcceptanceDecision.Replayed:
                    return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, owner.Acceptance.SelectedFact!));
                case NativeAcceptanceDecision.Conflict:
                    return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
            }
            return owner.Authorization is not null || owner.IsCancelRequested || owner.IsEnded
                ? SourceUseReceiverSupport.Superseded("The batch already authorized execution or ended.",
                    owner.Authorization is { } authorized ? NativeFactReference.Of(owner.Stream, authorized)
                        : ApplicationImportVerifier.Evidence(owner))
                : null;
        }
        var preparation = await NativeReceiverPreparation.PrepareAsync<ApplicationImportBatch, ApplicationImportContext>(reader,
            () => new ApplicationImportBatch(request.TenantId, batch.Id, request.CommandId), Decide,
            (owner, token) => verifier.PrepareAsync(new ApplicationImportNativeContext(request.TenantId, owner), token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known.IsSuccess ? Result.Success : Result.Failure(known.Error!);
'''+s[b:]
s=s.replace('fresh.AuthorizeExecution(provenance, loaded.Value.PlanRef)','fresh.AuthorizeExecution(provenance, plan.FrozenPlan)')
(r/'work'/p).write_text(s)
# Remove an unreachable duplicate after the already selected terminal receipt and preserve requested-token priority.
p='src/Compliance.Core/Features/Applications/ApplicationImportReceivers.cs';s=(r/'work'/p).read_text().replace('''            if (hold.Settled is not null)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(application.Stream, hold.Settled));
            if (disposition ==''','''            if (disposition ==''')
a=s.index('    async ValueTask<TerminalVerification> VerifyTerminalNativeAsync(');b=s.index('    async ValueTask<Result<ImportFrozenPlanIntent>>',a);part=s[a:b].replace('''            .ConfigureAwait(false);
        if (!batch.IsCreated''','''            .ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        if (!batch.IsCreated''');s=s[:a]+part+s[b:];(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/Applications/ApplicationImportVerifier.cs';s=(r/'work'/p).read_text().replace('''            .ConfigureAwait(false);
        return !batch.IsCreated''','''            .ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        return !batch.IsCreated''').replace('''            ApplicationImportIntentBindings.Require(plan.Header, accepted.Operation);''','''            if (plan.Header is null)
                throw new ImmutableContentIntegrityException("The frozen plan has no root header.");
            ApplicationImportIntentBindings.Require(plan.Header, accepted.Operation);''');(r/'work'/p).write_text(s)
