from pathlib import Path
r=Path('/tmp/compliance-import-receiver-preparation-prepared');p='src/Compliance.Core/Features/Applications/ApplicationImportVerifier.cs';s=(r/'base'/p).read_text()
a=s.index('        var tenant = Uuid.Parse');b=s.index('        ImportFrozenPlanIntent plan;',a)
s=s[:a]+'''        var native = await LoadNativeAsync(realm, batchId, Uuid.Empty, ct).ConfigureAwait(false);
        return !native.IsSuccess ? Result<ApplicationImportContext>.Failure(native.Error!)
            : await PrepareAsync(native.Value!, ct).ConfigureAwait(false);
    }

    /// <summary>Reads the exact authoritative batch before immutable preparation or selected receiver decisions.</summary>
    public async ValueTask<Result<ApplicationImportNativeContext>> LoadNativeAsync(string realm, Uuid batchId,
        Uuid selectedLogicalId, CancellationToken ct)
    {
        var tenant = Uuid.Parse(realm, CultureInfo.InvariantCulture);
        var batch = await reader.HydrateAsync(new ApplicationImportBatch(tenant, batchId, selectedLogicalId), ct)
            .ConfigureAwait(false);
        return !batch.IsCreated || batch.Plan is null
            ? Result<ApplicationImportNativeContext>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The sealed import plan is not visible yet.", true))
            : Result<ApplicationImportNativeContext>.Success(new ApplicationImportNativeContext(tenant, batch));
    }

    /// <summary>Binds and validates the complete frozen plan for a new receiver candidate.</summary>
    public async ValueTask<Result<ApplicationImportContext>> PrepareAsync(ApplicationImportNativeContext native,
        CancellationToken ct)
    {
        var (tenant, batch) = (native.TenantId, native.Batch);
        var batchId = batch.Id;
'''+s[b:]
s=s.replace('batch.Plan.FrozenPlan','batch.Plan!.FrozenPlan')
s=s.replace('''        catch (ImmutableContentIntegrityException exception)
        {
''','''        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
''')
s+='''
/// <summary>The actual native source cut, before immutable plan preparation.</summary>
sealed record ApplicationImportNativeContext(Uuid TenantId, ApplicationImportBatch Batch)
{
    public ImmutableContentRef PlanRef => Batch.Plan!.FrozenPlan;
}
''';(r/'work'/p).write_text(s)
p='src/Compliance.Core/Features/Applications/ApplicationImportIntentBindings.cs';s=(r/'base'/p).read_text();pos=s.index('    public static void Require(');s=s[:pos]+'''    public static DurableIntentHeader HeaderOf(OperationProvenance operation) =>
        new(operation.RootOperationId, operation.FirstOwner ?? operation.Owner, operation.AffectedOwner,
            operation.ExpectedRevisionOwner, operation.Actor, operation.Episode, operation.OriginalExpectedRevision,
            operation.AuthoredIntentSha256, operation.AcceptedAt);

'''+s[pos:];(r/'work'/p).write_text(s)
