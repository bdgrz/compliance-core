from pathlib import Path
r=Path('/tmp/compliance-import-receiver-preparation-prepared');p='src/Compliance.Core/Features/Applications/ApplicationImportReceivers.cs';s=(r/'work'/p).read_text();a=s.index('    public async ValueTask<Result<ReceiverOutcome>> FenceAsync(');b=s.index('    public async ValueTask<Result<ReceiverOutcome>> ReleaseSourceAsync(',a)
s=s[:a]+'''    public async ValueTask<Result<ReceiverOutcome>> FenceAsync(IExecutionContext context,
        FenceApplicationImportTarget command, CancellationToken ct)
    {
        if (Malformed(command.CommandId, command.OperationId, command.Generation))
            return SourceUseReceiverSupport.Permanent("The fence names another generation or operation.");
        var native = await ReadCancellationNativeAsync(command.Target.Realm, command.Source, command.BatchId,
            command.OperationId, Uuid.Empty, ct).ConfigureAwait(false);
        if (native.Failure is { } refused)
            return refused;
        var (tenant, batch) = (native.TenantId, native.Batch!);
        if (command.Target != new DeclaredApplication(tenant, command.ApplicationId).Stream || batch.Plan is null)
            return SourceUseReceiverSupport.Permanent("The fence names another target or an unsealed batch with no targets.");
        var provenance = ApplicationImportEffects.Child(command.CommandId, nameof(FenceApplicationImportTarget),
            command.Source.EventId, ApplicationImportIntentBindings.HeaderOf(batch.CancellationAccepted!.Operation),
            command.Target, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        Result<ReceiverOutcome>? Early(DeclaredApplication application, bool prepared)
        {
            var hold = application.FindImportHold(batch.Id);
            if (hold?.Fence is { } fence &&
                (fence.Intent != command.Intent || fence.Operation.RootOperationId != command.OperationId ||
                    fence.Operation.CausationEventId != command.Source.EventId || fence.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(fence.Operation with { LogicalId = command.CommandId }) != binding))
                return SourceUseReceiverSupport.Permanent("The target fence has another exact native cancellation binding.");
            if (Decide(application.Acceptance, binding, application.Stream) is { } decided)
                return decided;
            if (hold?.Fence is { } existing)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(application.Stream, existing));
            return prepared && hold?.Settled is { } settled
                ? SourceUseReceiverSupport.Superseded("The target was already settled.", NativeFactReference.Of(application.Stream, settled))
                : null;
        }
        var preparation = await NativeReceiverPreparation.PrepareAsync<DeclaredApplication, PreparedFence>(reader,
            () => new DeclaredApplication(tenant, command.ApplicationId, command.CommandId),
            application => Early(application, false), (_, token) => PrepareFenceAsync(command, batch, token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        if (preparation.Value.Value!.Outcome is { } terminal)
            return terminal;
        return await AppendAsync(context, () => new DeclaredApplication(tenant, command.ApplicationId, command.CommandId),
            application => application.Acceptance, application => Early(application, true),
            (DeclaredApplication application) => application.Fence(provenance, command.Intent, batch.Id, command.ApplicationId), ct)
            .ConfigureAwait(false);
    }

    public async ValueTask<Result<ReceiverOutcome>> CompleteAsync(IExecutionContext context,
        CompleteApplicationImportCancellation command, CancellationToken ct)
    {
        if (Malformed(command.CommandId, command.OperationId, command.Generation))
            return SourceUseReceiverSupport.Permanent("The completion names another generation or operation.");
        var native = await ReadCancellationNativeAsync(command.Target.Realm, command.Source, command.BatchId,
            command.OperationId, command.CommandId, ct).ConfigureAwait(false);
        if (native.Failure is { } refused)
            return refused;
        var (tenant, batch) = (native.TenantId, native.Batch!);
        if (command.Target != batch.Stream || command.Intent != batch.CancellationAccepted!.Intent)
            return SourceUseReceiverSupport.Permanent("The completion differs from the accepted cancellation.");
        // The native canceled fact does not bind this extra manifest. Preserve its original required typed read.
        IReadOnlyList<ApplicationImportFenceProof> fences;
        try
        {
            fences = await ApplicationImportContent.ReadAsync<IReadOnlyList<ApplicationImportFenceProof>>(content,
                tenant, command.TargetFenceManifest, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The cancellation cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
        var provenance = ApplicationImportEffects.Child(command.CommandId, nameof(CompleteApplicationImportCancellation),
            command.Source.EventId, ApplicationImportIntentBindings.HeaderOf(batch.CancellationAccepted.Operation),
            batch.Stream, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        Result<ReceiverOutcome>? Early(ApplicationImportBatch owner)
        {
            if (owner.Canceled is { } canceled &&
                (canceled.Intent != command.Intent || canceled.Operation.RootOperationId != command.OperationId ||
                    canceled.Operation.CausationEventId != command.Source.EventId || canceled.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(canceled.Operation with { LogicalId = command.CommandId }) != binding))
                return SourceUseReceiverSupport.Permanent("The completed cancellation has another exact native root binding.");
            if (Decide(owner.Acceptance, binding, owner.Stream) is { } decided)
                return decided;
            if (owner.Committed is { } committed)
                return SourceUseReceiverSupport.Superseded("The batch already published; the cancellation recovers forward.",
                    NativeFactReference.Of(owner.Stream, committed));
            return owner.Canceled is { } existing
                ? SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, existing)) : null;
        }
        var preparation = await NativeReceiverPreparation.PrepareAsync<ApplicationImportBatch, PreparedCancellation>(reader,
            () => new ApplicationImportBatch(tenant, batch.Id, command.CommandId), Early,
            (_, token) => PrepareCancellationAsync(command, batch, fences, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var prepared = preparation.Value.Value!;
        return await AppendAsync(context, () => new ApplicationImportBatch(tenant, batch.Id, command.CommandId),
            fresh => fresh.Acceptance, Early,
            (ApplicationImportBatch fresh) => fresh.CompleteCancellation(provenance, command.Intent, prepared.Reason,
                prepared.ActorMemberId, prepared.ActorDisplay, prepared.RecordedAt, prepared.Result), ct).ConfigureAwait(false);
    }

'''+s[b:]
a=s.index('    async ValueTask<NativeTargetVerification> ReadTargetNativeAsync(')
s=s[:a]+'''    async ValueTask<CancellationNativeVerification> ReadCancellationNativeAsync(string realm, NativeFactReference source,
        Uuid batchId, Uuid operationId, Uuid selectedLogicalId, CancellationToken ct)
    {
        var tenant = Uuid.Parse(realm, CultureInfo.InvariantCulture);
        var batch = await reader.HydrateAsync(new ApplicationImportBatch(tenant, batchId, selectedLogicalId), ct)
            .ConfigureAwait(false);
        ct.ThrowIfCancellationRequested();
        if (!batch.IsCreated || batch.CancellationAccepted is not { } accepted ||
            !ApplicationImportVerifier.IsFact(source, batch, accepted))
            return new CancellationNativeVerification(tenant, null,
                SourceUseReceiverSupport.Transient("The accepted cancellation is not visible yet."));
        return operationId != accepted.Operation.RootOperationId
            ? new CancellationNativeVerification(tenant, null,
                SourceUseReceiverSupport.Permanent("The command differs from the actual native cancellation root."))
            : new CancellationNativeVerification(tenant, batch, null);
    }

    async ValueTask<Result<PreparedFence>> PrepareFenceAsync(FenceApplicationImportTarget command,
        ApplicationImportBatch batch, CancellationToken ct)
    {
        try
        {
            var verified = await VerifyCancellationTargetAsync(command.Target, command.Source, command.BatchId,
                command.ApplicationId, command.Intent, ct).ConfigureAwait(false);
            if (verified.Failure is { } failure)
                return failure.IsSuccess ? Result<PreparedFence>.Success(new PreparedFence(failure))
                    : Result<PreparedFence>.Failure(failure.Error!);
            ApplicationImportIntentBindings.Require(verified.Cancellation!.Header, batch.CancellationAccepted!.Operation);
            return command.OperationId != verified.Cancellation.Header.RootOperationId
                ? Result<PreparedFence>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The fence names another cancellation.", false))
                : Result<PreparedFence>.Success(new PreparedFence(null));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedFence>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The cancellation target cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

    async ValueTask<Result<PreparedCancellation>> PrepareCancellationAsync(CompleteApplicationImportCancellation command,
        ApplicationImportBatch batch, IReadOnlyList<ApplicationImportFenceProof> fences, CancellationToken ct)
    {
        var tenant = Uuid.Parse(command.Target.Realm, CultureInfo.InvariantCulture);
        try
        {
            var cancellation = await ApplicationImportContent.ReadAsync<ImportFrozenPlanIntent>(content, tenant,
                command.Intent, ct).ConfigureAwait(false);
            if (cancellation.BatchId != command.BatchId || cancellation.Header is null ||
                cancellation.Header.RootOperationId != command.OperationId)
                return Result<PreparedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The completion differs from the accepted cancellation.", false));
            ApplicationImportIntentBindings.Require(cancellation.Header, batch.CancellationAccepted!.Operation);
            var expected = new List<Uuid>();
            if (batch.Plan is not null)
            {
                var sealedPlan = await verifier.LoadAsync(command.Target.Realm, command.BatchId, ct).ConfigureAwait(false);
                if (!sealedPlan.IsSuccess)
                    return Result<PreparedCancellation>.Failure(sealedPlan.Error!);
                var groups = await verifier.GroupsAsync(sealedPlan.Value!, ct).ConfigureAwait(false);
                if (!groups.IsSuccess)
                    return Result<PreparedCancellation>.Failure(groups.Error!);
                expected.AddRange(groups.Value!.Select(group => group.ApplicationId));
            }
            if (fences.Count != expected.Count || fences.Select(fence => fence.ApplicationId).Order().SequenceEqual(expected.Order()) is false)
                return Result<PreparedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The fence manifest does not cover exactly the frozen targets.", false));
            foreach (var fence in fences)
            {
                var target = await reader.HydrateAsync(new DeclaredApplication(tenant, fence.ApplicationId), ct).ConfigureAwait(false);
                if (target.FindImportHold(batch.Id)?.Fence is not { Metadata: { } metadata } held ||
                    metadata.EventId != fence.EventId || metadata.AggregateVersion != fence.EventVersion)
                    return Result<PreparedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "A target fence is not durable yet.", true));
                var actual = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, target, ct).ConfigureAwait(false);
                var stored = actual.SingleOrDefault(fact => fact.Metadata.EventId == fence.EventId);
                if (stored is null)
                    return Result<PreparedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The exact target fence is not visible in its captured physical source prefix.", true));
                if (stored.GetType() != held.GetType() || stored.Metadata != held.Metadata ||
                    Kernel.ContentDigest.Sha256(stored, stored.GetType()) != Kernel.ContentDigest.Sha256(held, held.GetType()))
                    return Result<PreparedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The cancellation fence differs from its exact committed source payload and metadata.", false));
            }
            var actor = cancellation.Header.OriginalActor;
            var actorMember = Uuid.TryParse(actor.Id, CultureInfo.InvariantCulture, out var memberId) ? memberId : Uuid.Empty;
            var now = clock.GetUtcNow();
            var result = await ApplicationImportContent.UnitResultAsync(content, tenant, command.OperationId, ct).ConfigureAwait(false);
            return Result<PreparedCancellation>.Success(new PreparedCancellation(cancellation.CancellationReason ?? string.Empty,
                actorMember, actor.Display, now, result));
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<PreparedCancellation>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The cancellation cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

'''+s[a:]
a=s.index('    sealed record NativeTargetVerification(')
s=s[:a]+'''    sealed record CancellationNativeVerification(Uuid TenantId, ApplicationImportBatch? Batch, Result<ReceiverOutcome>? Failure);

    sealed record PreparedFence(Result<ReceiverOutcome>? Outcome);

    sealed record PreparedCancellation(string Reason, Uuid ActorMemberId, string ActorDisplay, DateTimeOffset RecordedAt,
        ImmutableContentRef Result);

'''+s[a:]
(r/'work'/p).write_text(s)
