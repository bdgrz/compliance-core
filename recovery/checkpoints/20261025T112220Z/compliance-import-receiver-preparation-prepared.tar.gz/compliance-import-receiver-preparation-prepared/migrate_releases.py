from pathlib import Path
r=Path('/tmp/compliance-import-receiver-preparation-prepared');p='src/Compliance.Core/Features/Applications/ApplicationImportReceivers.cs';s=(r/'work'/p).read_text()
# Keep the old terminal read as the bounded preparation function; the new stage derives actual native authority.
a=s.index('    async ValueTask<TerminalVerification> VerifyTerminalAsync(')
b=s.index('    /// <summary>Every native proof',a)
old=s[a:b]
new='''    async ValueTask<TerminalVerification> VerifyTerminalNativeAsync(string realm, Uuid batchId, NativeFactReference source,
        ImmutableContentRef intent, Uuid operationId, CancellationToken ct)
    {
        var tenant = Uuid.Parse(realm, CultureInfo.InvariantCulture);
        var batch = await reader.HydrateAsync(new ApplicationImportBatch(tenant, batchId), ct).ConfigureAwait(false);
        if (!batch.IsCreated || ApplicationImportVerifier.Terminal(batch) is not { } terminal ||
            !ApplicationImportVerifier.IsFact(source, batch, terminal.Fact))
            return new TerminalVerification(null, null, default,
                SourceUseReceiverSupport.Transient("The terminal batch fact is not visible yet."));
        var expectedIntent = batch.Canceled?.Intent ?? batch.Plan?.FrozenPlan;
        var root = batch.Canceled is not null ? batch.CancellationAccepted?.Operation : batch.Plan?.Operation;
        if (expectedIntent is null || intent != expectedIntent || root is null || operationId != root.RootOperationId)
            return new TerminalVerification(null, null, default,
                SourceUseReceiverSupport.Permanent("The release differs from the exact native terminal batch intent or root."));
        // Failed has no selected current producer. Preserve its original immutable binding; do not invent one.
        if (terminal.Disposition == ApplicationImportDisposition.Failed)
            return await VerifyTerminalAsync(realm, batchId, source, intent, operationId, ct).ConfigureAwait(false);
        return new TerminalVerification(batch, ApplicationImportIntentBindings.HeaderOf(root), terminal.Disposition, null);
    }

    async ValueTask<Result<ImportFrozenPlanIntent>> PrepareTerminalAsync(Uuid tenant, ApplicationImportBatch batch,
        ImmutableContentRef intent, Uuid operationId, CancellationToken ct)
    {
        try
        {
            var plan = await ApplicationImportContent.ReadAsync<ImportFrozenPlanIntent>(content, tenant, intent, ct)
                .ConfigureAwait(false);
            var root = batch.Canceled is not null ? batch.CancellationAccepted!.Operation : batch.Plan!.Operation;
            ApplicationImportIntentBindings.Require(plan.Header, root);
            return plan.Header.RootOperationId != operationId
                ? Result<ImportFrozenPlanIntent>.Failure(new RequestError(RequestErrorKind.Conflict,
                    "The release names another operation than the terminal batch.", false))
                : Result<ImportFrozenPlanIntent>.Success(plan);
        }
        catch (ImmutableContentIntegrityException error)
        {
            ct.ThrowIfCancellationRequested();
            return Result<ImportFrozenPlanIntent>.Failure(new RequestError(RequestErrorKind.Conflict,
                $"The terminal intent cannot be verified: {error.Message}", error is ImmutableContentUnavailableException));
        }
    }

'''
s=s[:a]+new+old+s[b:]
for name in ['ReleaseSourceAsync','ReleaseTargetAsync']:
 a=s.index('    public async ValueTask<Result<ReceiverOutcome>> '+name);b=s.find('    public async ValueTask<Result<ReceiverOutcome>> ',a+10)
 if b<0:b=s.index('    async ValueTask<TargetVerification>',a)
 part=s[a:b].replace('await VerifyTerminalAsync(', 'await VerifyTerminalNativeAsync(')
 if name=='ReleaseSourceAsync':
  marker='''        Result<ReceiverOutcome>? Early(ApplicationImportSource source)
        {
'''
  guard='''            if (source.Find(batch.Id)?.Settled is { } settled &&
                (settled.Intent != command.Intent || settled.Disposition != disposition ||
                    settled.Operation.RootOperationId != command.OperationId || settled.Operation.CausationEventId != command.Source.EventId ||
                    settled.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(settled.Operation with { LogicalId = command.CommandId }) != binding))
                return SourceUseReceiverSupport.Permanent("The source settlement has another exact native terminal binding.");
'''
  part=part.replace(marker,marker+guard)
  part=part.replace('source.Find(batch.Id) is { Settled: { } settled }','source.Find(batch.Id) is { Settled: { } existing }').replace('NativeFactReference.Of(source.Stream, settled))','NativeFactReference.Of(source.Stream, existing))')
  idx=part.index('        return await AppendAsync(')
  prep='''        var preparation = await NativeReceiverPreparation.PrepareAsync<ApplicationImportSource, ImportFrozenPlanIntent>(reader,
            () => new ApplicationImportSource(tenant, batch.SourceKey!, batch.SourceNamespace!, command.CommandId, batch.Id),
            Early, (_, token) => PrepareTerminalAsync(tenant, batch, command.Intent, command.OperationId, token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
'''
 else:
  part=part.replace('Result<ReceiverOutcome>? Early(DeclaredApplication application)','Result<ReceiverOutcome>? Early(DeclaredApplication application, bool prepared)')
  idx=part.index('            if (Decide(application.Acceptance')
  part=part[:idx]+'''            if (application.FindImportHold(batch.Id)?.Settled is { } settled &&
                (settled.Intent != command.Intent || settled.Disposition != disposition ||
                    settled.Operation.RootOperationId != command.OperationId || settled.Operation.CausationEventId != command.Source.EventId ||
                    settled.Operation.FirstOwner != batch.Stream ||
                    AcceptedOperationBinding.Of(settled.Operation with { LogicalId = command.CommandId }) != binding))
                return SourceUseReceiverSupport.Permanent("The target settlement has another exact native terminal binding.");
'''+part[idx:]
  part=part.replace('''            if (hold is null)
''','''            if (hold?.Settled is { } existing)
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(application.Stream, existing));
            if (!prepared)
                return null;
            if (hold is null)
''')
  idx=part.index('        return await AppendAsync(')
  prep='''        var preparation = await NativeReceiverPreparation.PrepareAsync<DeclaredApplication, ImportFrozenPlanIntent>(reader,
            () => new DeclaredApplication(tenant, command.ApplicationId, command.CommandId),
            application => Early(application, false),
            (_, token) => PrepareTerminalAsync(tenant, batch, command.Intent, command.OperationId, token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
'''
  part=part.replace('application => application.Acceptance, Early,','application => application.Acceptance, application => Early(application, true),')
 part=part[:idx]+prep+part[idx:]
 s=s[:a]+part+s[b:]
# Required legacy failed-terminal read now also preserves requested cancellation.
a=s.index('    async ValueTask<TerminalVerification> VerifyTerminalAsync(');b=s.index('    /// <summary>Every native proof',a);part=s[a:b].replace('''        catch (ImmutableContentIntegrityException exception)
        {
''','''        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
''');s=s[:a]+part+s[b:]
(r/'work'/p).write_text(s)
