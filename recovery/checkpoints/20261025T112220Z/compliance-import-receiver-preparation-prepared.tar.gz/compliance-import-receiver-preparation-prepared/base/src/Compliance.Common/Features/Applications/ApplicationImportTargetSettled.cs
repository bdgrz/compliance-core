using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Applications;

/// <summary>
///     The target hold ends with the batch's exact terminal fact. A published disposition promotes the frozen
///     candidate to the application's content without a second revision increment; a canceled or failed disposition
///     discards it. <paramref name="Revision" /> is the published content revision after the settlement.
/// </summary>
[Discriminator("bdgrz.declared_application.import_target_settled", 1)]
public sealed record ApplicationImportTargetSettled(EventStreamAddress Owner, long Revision, long Generation,
    ImmutableContentRef Intent, ImmutableContentRef? SourceProofs, OperationProvenance Operation,
    ImmutableContentRef? FirstResponse, ImmutableContentRef? OperationResult, Uuid BatchId, Uuid ApplicationId,
    ApplicationImportDisposition Disposition) : DomainEvent, INativeOperationFact;
