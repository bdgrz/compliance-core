using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Applications;

public interface IApplicationControlVersionReferenceDirectory
{
    ValueTask<Page<ApplicationControlVersionReferenceView>> ListAsync(Uuid tenantId,
        string subjectType, Uuid recordId, int limit, string? cursor,
        CancellationToken ct = default);

    ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId,
        CancellationToken ct = default);
}

public interface IApplicationControlVersionReferenceProjection : IProjectionStore
{
    ValueTask ApplyAsync(DomainEvent domainEvent, CancellationToken ct = default);
}
