from pathlib import Path
p=Path('/tmp/compliance-risk-assertion-prepared')
f=p/'work/src/Compliance.Core/Features/Risks/RiskTreatmentAssertionHistory.cs';f.write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Complete immutable assertion history outside bounded pending/accepted command authority.</summary>
public static class RiskTreatmentAssertionHistory
{
    public static async Task<IReadOnlyList<DomainEvent>> ReadAsync(IDomainEventReader events,
        RiskTreatmentAssertion owner, CancellationToken ct = default)
    {
        var facts = await NativeOwnerHistory.ReadAsync<DomainEvent>(events, owner, ct).ConfigureAwait(false);
        if (facts.Count != owner.Revision || facts.Count > 0 && (owner.Latest is null ||
            ContentDigest.Sha256(facts[^1], facts[^1].GetType()) != ContentDigest.Sha256(owner.Latest, owner.Latest.GetType())))
            throw new ImmutableContentIntegrityException("The assertion history differs from its exact hydrated cut.");
        for (var index = 0; index < facts.Count; index++)
        {
            var valid = facts[index] switch
            {
                RiskControlTreatmentProposed fact => fact.TenantId == owner.TenantId && fact.ProgramId == owner.ProgramId && fact.RiskId == owner.RiskId && fact.Revision == index + 1,
                RiskControlTreatmentReviewed fact => fact.TenantId == owner.TenantId && fact.ProgramId == owner.ProgramId && fact.RiskId == owner.RiskId && fact.Revision == index + 1,
                RiskControlTreatmentRetired fact => fact.TenantId == owner.TenantId && fact.ProgramId == owner.ProgramId && fact.RiskId == owner.RiskId && fact.Revision == index + 1,
                _ => false,
            };
            if (!valid)
                throw new ImmutableContentIntegrityException("The assertion source has another risk, kind or predecessor.");
        }
        return facts;
    }
}
''')
f=p/'work/src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs';s=f.read_text();s=s.replace('''        foreach (var treatment in line.Treatments)''','''        var facts = await RiskTreatmentAssertionHistory.ReadAsync(events, line, ct).ConfigureAwait(false);
        var composed = RiskTreatmentAssertionRules.FromFacts(tenantId, line.ProgramId, line.RiskId, line.ControlId, facts);
        foreach (var treatment in composed.Treatments)''')
# Read-only accepted-command discovery must not pick an unrelated first matching public treatment identity.
a=s.index('    /// <summary>The control a treatment');b=s.index('    /// <summary>The treatments of a line',a)
s=s[:a]+'''    /// <summary>Resolves an immutable treatment locator in its exact tenant/program/risk scope, retaining ambiguity.</summary>
    public async ValueTask<Uuid?> LocateControlAsync(Uuid tenantId, Uuid programId, Uuid riskId, Uuid treatmentId,
        CancellationToken ct = default)
    {
        var matches = new HashSet<Uuid>();
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(tenantId.ToString(),
            RiskTreatmentAssertion.Area), EventCursor.Start, ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit || record.Event is not RiskControlTreatmentProposed proposed ||
                proposed.TenantId != tenantId || proposed.ProgramId != programId || proposed.RiskId != riskId ||
                proposed.Operation.LogicalId != treatmentId)
                continue;
            var view = await FindingContent.ReadAsync<RiskControlTreatmentView>(content, tenantId, proposed.TreatmentContent, ct).ConfigureAwait(false);
            if (view.RiskId != riskId || view.TreatmentId != treatmentId || view.ControlId == Uuid.Empty ||
                record.Stream != new RiskTreatmentAssertion(tenantId, programId, riskId, view.ControlId).Stream ||
                proposed.Operation.Owner != record.Stream || proposed.Operation.FirstOwner != record.Stream)
                throw new ImmutableContentIntegrityException("The immutable treatment locator differs from its exact native owner.");
            matches.Add(view.ControlId);
        }
        if (matches.Count > 1)
            throw new ImmutableContentIntegrityException("The scoped treatment identity is ambiguous across control assertion owners.");
        return matches.Count == 0 ? null : matches.Single();
    }

    /// <summary>Uses exact existing native admission facts to route an authorized retry before fresh source reads.</summary>
    internal async Task<EventStreamAddress?> LocateAssertionAdmissionAsync(Uuid tenantId, Uuid programId, Uuid riskId,
        Uuid commandId, CancellationToken ct = default)
    {
        var owners = new HashSet<EventStreamAddress>();
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(tenantId.ToString(),
            RiskTreatmentAssertion.Area), EventCursor.Start, ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit)
                continue;
            var matches = record.Event switch
            {
                RiskControlTreatmentProposed fact => fact.TenantId == tenantId && fact.ProgramId == programId && fact.RiskId == riskId && fact.Operation.LogicalId == commandId,
                RiskControlTreatmentReviewed fact => fact.TenantId == tenantId && fact.ProgramId == programId && fact.RiskId == riskId && fact.Operation.LogicalId == commandId,
                RiskControlTreatmentRetired fact => fact.TenantId == tenantId && fact.ProgramId == programId && fact.RiskId == riskId && fact.Operation.LogicalId == commandId,
                _ => false,
            };
            if (!matches)
                continue;
            var operation = ((INativeOperationFact)record.Event).Operation;
            if (record.Stream.Realm != tenantId.ToString() || record.Stream.Area != RiskTreatmentAssertion.Area ||
                record.Stream.Resource != record.Event.Metadata.AggregateId.ToString() || operation.Owner != record.Stream ||
                operation.FirstOwner != record.Stream || record.Event.Metadata.EventId == Uuid.Empty || record.Event.Metadata.AggregateVersion == 0)
                throw new ImmutableContentIntegrityException("The assertion admission locator has another exact native source binding.");
            owners.Add(record.Stream);
        }
        if (owners.Count > 1)
            throw new ImmutableContentIntegrityException("The scoped command identity is ambiguous across assertion owners.");
        return owners.Count == 0 ? null : owners.Single();
    }

'''+s[b:];f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs';s=f.read_text().replace('history.CaptureAsync(line.Stream, line.Facts, tenantId, content, through, context, ct)', 'history.CaptureAsync(line.Stream, await RiskTreatmentAssertionHistory.ReadAsync(events, line, ct).ConfigureAwait(false), tenantId, content, through, context, ct)');f.write_text(s)
