# RiskTreatmentAssertion compact native authority

Frozen `handoff.json`: 14 changed paths, ten owning source and four tests/helpers. Four additional unchanged baselines are saved for static context. Depends on Governance12 plus its native-v2 overlay, Method36, Risk109/source bytes and NativeOwnerHistory. No main edits, dotnet/build/test/format, git/Jev or issues were performed.

## Staged behavioral evidence

`behavioral-red.patch` is tests-only against the existing old API. Run `behavioral-red-filter.txt` before implementation. It demonstrates exact proposal retry incorrectly reselecting an unavailable mutable risk source, and a scoped duplicate TreatmentId across independent control owners being resolved by picking the first match. Apply `green-after-red.patch` afterward. Full, split and RED/green reconstruction pass exactly for all 14 final hashes. Runtime evidence remains with root.

## Owner and native producers

The command owner retains at most one pending proposal, one accepted proposal/review, latest native fact, revision and selected acceptance. It has no lifetime treatment/fact collections or historical Find compatibility method. Complete histories and supersession/retirement views use explicit RiskTreatmentAssertionRules/read composition outside Aggregate, verified at the owner's exact native/physical cut. Current proposal and accepted authority retain only immutable content references and bounded actor/decision headers.

All three existing handlers use async native preparation. Exact original actor/intent/expected revision binding resolves before mutable risk/control/waiver checks. Proposal preserves the exact existing current-approved control and mitigate rules; only pending-line/current accepted body needs reading. Review retains personal HTTP, independent proposer and exact waiver-scope rules; retirement withdraws only the exact accepted assertion. Frozen registration/Unit200 descriptors and MutationResultContent remain original after later reviews, retirement and succession. Existing request fields, constructor dependencies, HTTP routes and global native transport bridge remain unchanged. No new DI/JSON registration is needed.

Review/Retire omit ControlId. Their scoped native-admission locator first resolves an existing command's immutable first-owner address within tenant/program/risk, preserving multi-owner ambiguity. An address-bound replay-only owner validates all native scope/actor/predecessor facts and cannot emit new business state; the installed native binding decides the original actor/intent/gate result. A new command uses its immutable proposal locator, which validates the derived control owner and rejects duplicate identities across controls. No bare/global lookup, realm-wide mutation binding or fabricated migration authority is claimed.

Actual unchanged already-externalized v2 fact tags remain v2 per root instruction. Optional historical FirstOwner is normalized exactly as the installed native contract (`FirstOwner ?? Owner`); every new producer explicitly supplies FirstOwner. There is no old wide-v1 reader or tag reassignment. Precise metadata/current-source qualification is in `qualification.json`.

## Consumers and tests

RiskGovernanceReader and Risk source contributor consume verified assertion history, preserve existing receipt selection and exact physical byte publication, and retain independent Action branches for separate composition. RiskSeeds changes only assertion branches to exact initial operation provenance/selected logical identity. Existing pure rules acceptance tests retain their names/assertions using explicit non-owner Rules; native tests exercise actual handlers, 53 facts, 24 rejections, retirement plus accepted successor, and immutable original proposal/retirement replay. Another test proves an accepted personal review can replay without fetching an unavailable proposal narrative.

18 C# files parse; 16 relevant explicit constructor calls match; 15 captured prior acceptance names remain with no assertion reduction. Four new test methods include the two old-API RED cases and native full-history/source recovery. No runtime qualification is claimed.

## Required qualification boundary

The existing current-control check/public gate is preserved by root direction. A stronger atomic current-through-append guarantee lacks a selected ControlDraft/control-version acquire/settle pair and SourceUsePurpose; no invented permit or false qualification is added. Historical review/retire remain available. Scoped locator ambiguity fails closed and does not solve #1042's realm-wide first-owner binding.

Action25 is separately frozen. `/tmp/compliance-risk-assertion-action-compose` contains the four exact shared-file unions so root can apply non-shared Action implementation/tests, Assertion14, then the shared compose overlay without overwriting either family. Root owns strict build, meaningful RED/green, full suites, direct per-file Jev and merge.
