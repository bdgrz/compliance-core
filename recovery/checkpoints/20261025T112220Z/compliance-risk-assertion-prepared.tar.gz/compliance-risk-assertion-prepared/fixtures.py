from pathlib import Path
p=Path('/tmp/compliance-risk-assertion-prepared')
f=p/'work/test/Compliance.Tests/Features/Risks/RiskOwnerBoundaryTests.cs';s=f.read_text().replace('static RiskTreatmentAssertion NewLine()', 'static RiskTreatmentAssertionRules NewLine()').replace('static Uuid Propose(RiskTreatmentAssertion line,', 'static Uuid Propose(RiskTreatmentAssertionRules line,')
marker='    static OperationProvenance Operation(Aggregate owner,'
s=s.replace(marker,'''    static OperationProvenance Operation(RiskTreatmentAssertionRules owner, Uuid id, ulong expected, ActorReference actor) =>
        new(id, id, null, "RiskOwnerTest", actor, owner.Stream, "0", expected, new string('a', 64), Now, owner.Stream, owner.Stream);

'''+marker);f.write_text(s)
f=p/'work/test/Compliance.Tests/Testing/RiskSeeds.cs';s=f.read_text()
s=s.replace('RiskStates.TreatmentProposed,\n            rationale, actor, at,', 'RiskStates.TreatmentProposed,\n            rationale.Trim(), actor, at,')
s=s.replace('''var operation = Operation(owner, treatment, (ulong)owner.Revision, actor, at, nameof(ProposeRiskControlTreatment), view);''','''var request = new ProposeRiskControlTreatment(treatment, tenant, program, risk, owner.Revision, control, version, rationale);
        var operation = RootOperation.Provenance(treatment, nameof(ProposeRiskControlTreatment), owner.Stream, actor,
            owner.Revision, AuthoredIntentDigest.Compute(request), at) with { FirstOwner = owner.Stream };''')
s=s.replace('''new RiskTreatmentAssertion(tenant, program, risk, control),
            source => source.Propose''','''new RiskTreatmentAssertion(tenant, program, risk, control, treatment),
            source => source.Propose''')
s=s.replace('''var operation = Operation(owner, Uuid.CreateVersion4(), (ulong)owner.Revision, actor, at,
            nameof(ReviewRiskControlTreatment), new { treatment, outcome, rationale });''','''var command = Uuid.CreateVersion4();
        var request = new ReviewRiskControlTreatment(command, tenant, program, risk, treatment, owner.Revision, outcome, rationale);
        var operation = RootOperation.Provenance(command, nameof(ReviewRiskControlTreatment), owner.Stream, actor,
            owner.Revision, AuthoredIntentDigest.Compute(request), at) with { FirstOwner = owner.Stream };''')
s=s.replace('''new RiskTreatmentAssertion(tenant, program, risk, control),
            source => source.Review''','''new RiskTreatmentAssertion(tenant, program, risk, control, command),
            source => source.Review''');f.write_text(s)
