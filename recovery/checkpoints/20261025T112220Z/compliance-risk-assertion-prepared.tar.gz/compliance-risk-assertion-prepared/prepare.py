from pathlib import Path
import shutil
p=Path('/tmp/compliance-risk-assertion-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');gov=Path('/tmp/compliance-risk-governance-prepared/work');method=Path('/tmp/compliance-risk-method-prepared/work');risk=Path('/tmp/compliance-risk-native-prepared/work')
paths=['src/Compliance.Core/Features/Risks/RiskTreatmentAssertion.cs','src/Compliance.Core/Features/Risks/ProposeRiskControlTreatmentHandler.cs','src/Compliance.Core/Features/Risks/ReviewRiskControlTreatmentHandler.cs','src/Compliance.Core/Features/Risks/RetireRiskControlTreatmentHandler.cs','src/Compliance.Core/Features/Risks/RiskGovernanceReader.cs','src/Compliance.Core/Features/Examinations/RiskTypeIBaselineSourceContributor.cs','src/Compliance.Common/Features/Risks/RiskControlTreatmentProposed.cs','src/Compliance.Common/Features/Risks/RiskControlTreatmentReviewed.cs','src/Compliance.Common/Features/Risks/RiskControlTreatmentRetired.cs','test/Compliance.Tests/Testing/RiskSeeds.cs','test/Compliance.Tests/Features/Risks/RiskOwnerBoundaryTests.cs','test/Compliance.Tests/Features/Risks/PersonalRiskSignoffTransportTests.cs']
for rel in paths:
 origin=next(root/rel for root in [gov,method,risk,repo] if (root/rel).exists())
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,f)
f=p/'work/src/Compliance.Core/Features/Risks/RiskTreatmentAssertionRules.cs';s=(p/'base/src/Compliance.Core/Features/Risks/RiskTreatmentAssertion.cs').read_text().replace('public sealed class RiskTreatmentAssertion : Aggregate','public sealed class RiskTreatmentAssertionRules').replace('public RiskTreatmentAssertion(', 'public RiskTreatmentAssertionRules(')
a=s.index('        : base(');b=s.index('        (_tenantId',a);s=s[:a]+'    {\n'+s[b:]
for line in ['        On<RiskControlTreatmentProposed>(Apply);\n','        On<RiskControlTreatmentReviewed>(Apply);\n','        On<RiskControlTreatmentRetired>(Apply);\n']:s=s.replace(line,'')
s=s.replace('''    /// <summary>Acceptance of the logical operation''','''    public Uuid Id => IdentityOf(_tenantId, _programId, _riskId, _controlId);
    public EventStreamAddress Stream => new(_tenantId.ToString(), Area, Id.ToString());
    public static RiskTreatmentAssertionRules FromFacts(Uuid tenant, Uuid program, Uuid risk, Uuid control, IReadOnlyList<DomainEvent> facts)
    {
        var rules = new RiskTreatmentAssertionRules(tenant, program, risk, control);
        foreach (var fact in facts)
            rules.RaiseEvent(fact);
        return rules;
    }
    void RaiseEvent(DomainEvent fact)
    {
        switch (fact)
        {
            case RiskControlTreatmentProposed proposed: Apply(proposed); break;
            case RiskControlTreatmentReviewed reviewed: Apply(reviewed); break;
            case RiskControlTreatmentRetired retired: Apply(retired); break;
            default: throw new InvalidOperationException("An assertion source contains another fact type.");
        }
    }

    /// <summary>Acceptance of the logical operation''')
f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Risks/RiskTreatmentAssertion.cs';s=(p/'base/src/Compliance.Core/Features/Risks/RiskTreatmentAssertion.cs').read_text()
s=s.replace('''    readonly List<RiskTreatmentLine> _lines = [];
    readonly List<DomainEvent> _facts = [];''','''    RiskTreatmentLine? _pending;
    RiskTreatmentLine? _accepted;
    DomainEvent? _latest;
    readonly bool _replayOnly;''')
# Private address-based construction is read-only replay, not a new public owner lookup or authority.
a=s.index('    /// <summary>The identity of the line');s=s[:a]+'''    RiskTreatmentAssertion(Uuid tenant, Uuid program, Uuid risk, EventStreamAddress source, Uuid logical)
        : base(Uuid.Parse(source.Resource, System.Globalization.CultureInfo.InvariantCulture), source)
    {
        (_tenantId, _programId, _riskId, _controlId) = (tenant, program, risk, Uuid.Empty);
        _replayOnly = true;
        Acceptance = new NativeAcceptance(logical);
        On<RiskControlTreatmentProposed>(Apply);
        On<RiskControlTreatmentReviewed>(Apply);
        On<RiskControlTreatmentRetired>(Apply);
    }

    internal static RiskTreatmentAssertion ForAcceptedReplay(Uuid tenant, Uuid program, Uuid risk,
        EventStreamAddress source, Uuid logical) => source.Realm == tenant.ToString() && source.Area == Area
            ? new RiskTreatmentAssertion(tenant, program, risk, source, logical)
            : throw new InvalidOperationException("An accepted assertion owner must belong to the exact requested tenant scope.");

'''+s[a:]
a=s.index('    /// <summary>Every treatment of the line');b=s.index('    /// <summary>Checks that a treatment can be proposed',a)
s=s[:a]+'''    public DomainEvent? Latest => _latest;
    public Uuid TenantId => _tenantId;
    public Uuid ProgramId => _programId;
    public RiskTreatmentLine? Pending => _pending;
    public RiskTreatmentLine? Accepted => _accepted;

'''+s[b:]
s=s.replace('''if (Find(treatmentId) is not { } line)''','''if (Pending is not { } line || line.TreatmentId != treatmentId)''',1)
# Retirement checks only the live accepted authority. Existing historical existence semantics are supplied by the owning locator.
s=s.replace('''if (Find(treatmentId) is not { } line)''','''if (Accepted is not { } line || line.TreatmentId != treatmentId)''',1)
s=s.replace('''if (Pending is not null || Find(ev.Operation.LogicalId) is not null)''','''if (Pending is not null || Accepted?.TreatmentId == ev.Operation.LogicalId)''')
s=s.replace('''        _lines.Add(new RiskTreatmentLine(ev));''','''        _pending = new RiskTreatmentLine(ev);''')
s=s.replace('''        var line = Find(ev.TreatmentId);''','''        var line = Pending?.TreatmentId == ev.TreatmentId ? Pending : null;''',1)
a=s.index('''        if (ev.Outcome == RiskStates.Accept)
            foreach''');b=s.index('        Advance(ev);',a)
s=s[:a]+'''        if (ev.Outcome is not (RiskStates.Accept or RiskStates.Reject))
            throw new InvalidOperationException("An assertion review requires its exact accepted or rejected outcome.");
        line.Reviewed = ev;
        line.Status = ev.Outcome == RiskStates.Accept ? RiskStates.TreatmentAccepted : RiskStates.TreatmentRejected;
        if (ev.Outcome == RiskStates.Accept)
            _accepted = line;
        _pending = null;
'''+s[b:]
s=s.replace('''        var line = Find(ev.TreatmentId);''','''        var line = Accepted?.TreatmentId == ev.TreatmentId ? Accepted : null;''',1)
s=s.replace('''        line.Status = RiskStates.TreatmentRetired;
        Advance(ev);''','''        line.Status = RiskStates.TreatmentRetired;
        _accepted = null;
        Advance(ev);''')
s=s.replace('''        _facts.Add(fact);''','''        _latest = fact;''')
s=s.replace('''if (operation.Owner != Stream || operation.OriginalExpectedRevision is not { } expected)''','''if (_replayOnly || operation.Owner != Stream || operation.LogicalId != Acceptance.SelectedLogicalId ||
            operation.OriginalExpectedRevision is not { } expected)''')
s=s.replace('''            operation.Owner != Stream)''','''            operation.Owner != Stream || operation.FirstOwner != Stream || operation.Actor.Kind != "member" ||
            !Uuid.TryParse(operation.Actor.Id, out var actor) || actor == Uuid.Empty ||
            !NativeOwnerHistory.IsOwnRoot(this, operation, operation.CommandKind, (ulong)_revision) ||
            operation.CommandKind is not (nameof(ProposeRiskControlTreatment) or nameof(ReviewRiskControlTreatment) or nameof(RetireRiskControlTreatment)))''')
# Validate the fact kind against its command, attribution and immutable schema before observing acceptance.
s=s.replace('''        Acceptance.Observe(ev);
        EnsureNext(ev.TenantId, ev.ProgramId, ev.RiskId, ev.Revision, ev.Operation);''','''        EnsureNext(ev.TenantId, ev.ProgramId, ev.RiskId, ev.Revision, ev.Operation);
        Acceptance.Observe(ev);''')
s=s.replace('''    void Apply(RiskControlTreatmentProposed ev)
    {''','''    void Apply(RiskControlTreatmentProposed ev)
    {
        if (ev.Operation.CommandKind != nameof(ProposeRiskControlTreatment) || ev.Operation.Actor.Id != ev.ProposerMemberId.ToString() ||
            ev.TreatmentContent.Schema != RiskContent.TreatmentSchema || ev.FirstResponse is null || ev.OperationResult is null)
            throw new InvalidOperationException("The assertion proposal has another exact native kind or proposer.");''')
s=s.replace('''    void Apply(RiskControlTreatmentReviewed ev)
    {''','''    void Apply(RiskControlTreatmentReviewed ev)
    {
        if (ev.Operation.CommandKind != nameof(ReviewRiskControlTreatment) || ev.Reviewer != ev.Operation.Actor || ev.ReviewedAt != ev.Operation.AcceptedAt ||
            ev.DecisionId != ev.Operation.LogicalId || ev.FirstResponse is null || ev.OperationResult is null)
            throw new InvalidOperationException("The assertion review has another exact native decision or actor.");''')
s=s.replace('''    void Apply(RiskControlTreatmentRetired ev)
    {''','''    void Apply(RiskControlTreatmentRetired ev)
    {
        if (ev.Operation.CommandKind != nameof(RetireRiskControlTreatment) || ev.RetiredBy != ev.Operation.Actor || ev.RetiredAt != ev.Operation.AcceptedAt ||
            ev.FirstResponse is null || ev.OperationResult is null)
            throw new InvalidOperationException("The assertion retirement has another exact native kind or actor.");''')
f.write_text(s)
for name in ['RiskControlTreatmentProposed','RiskControlTreatmentReviewed','RiskControlTreatmentRetired']:
 f=p/'work/src/Compliance.Common/Features/Risks'/f'{name}.cs';f.write_text(f.read_text().replace(', 2)]',', 1)]'))
