from pathlib import Path
import os,json,re,subprocess
p=Path('/tmp/compliance-risk-assertion-prepared')
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
parser=Parser(Language(tree_sitter_c_sharp.language()));files=list(Path("/tmp/compliance-risk-assertion-prepared/work").rglob("*.cs"))
print(json.dumps({"files":len(files),"errors":[str(f) for f in files if parser.parse(f.read_bytes()).root_node.has_error]}))
'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')));assert not syntax['errors']
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()))
expected={'RiskTreatmentAssertion':(4,5),'RiskTreatmentAssertionRules':(4,4),'ProposeRiskControlTreatmentHandler':(6,6),'ReviewRiskControlTreatmentHandler':(6,6),'RetireRiskControlTreatmentHandler':(5,5),'RiskGovernanceReader':(3,3),'PreparedRiskAssertion':(2,3)}
issues=[];calls=[]
for f in (p/'work').rglob('*.cs'):
 data=f.read_bytes();stack=[parser.parse(data).root_node]
 while stack:
  n=stack.pop();stack.extend(n.children)
  if n.type!='object_creation_expression':continue
  typ=n.child_by_field_name('type');args=n.child_by_field_name('arguments')
  if not typ or not args:continue
  name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
  if name not in expected:continue
  count=sum(c.type=='argument' for c in args.named_children);calls.append({'path':str(f.relative_to(p/'work')),'type':name,'arguments':count})
  if not expected[name][0]<=count<=expected[name][1]:issues.append(calls[-1])
preserved=[]
for before in (p/'base/test').rglob('*.cs'):
 after=p/'work'/before.relative_to(p/'base')
 names=lambda f:set(re.findall(r'\b(Should\w+)\s*\(',f.read_text()))
 assert names(before)<=names(after)
 assert after.read_text().count('Assert.')>=before.read_text().count('Assert.')
 preserved+=sorted(names(before))
assert not issues,issues
report={'syntax':syntax,'constructorCalls':calls,'preservedAcceptanceNames':preserved,'issues':issues,'runtime':'Not run; root owns slot.'}
(p/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'syntax':syntax,'constructorCalls':len(calls),'preserved':len(preserved),'issues':issues}))
