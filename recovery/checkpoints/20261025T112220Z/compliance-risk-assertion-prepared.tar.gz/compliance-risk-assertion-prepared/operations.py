from pathlib import Path
p=Path('/tmp/compliance-risk-assertion-prepared/work/src/Compliance.Core/Features/Risks')
(p/'PreparedRiskAssertion.cs').write_text('''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;

namespace Bdgrz.Compliance.Features.Risks;

sealed record PreparedRiskAssertion(FirstResponseDescriptor Response, ImmutableContentRef Result,
    ImmutableContentRef? Proposal = null);
''')
(p/'RiskTreatmentAssertionOperations.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Remediation;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Exact scoped first-owner resolution and native preparation shared by the three assertion commands.</summary>
static class RiskTreatmentAssertionOperations
{
    public static async ValueTask<Result<TOut>> ExecuteAsync<TRequest, TOut>(NativeOperationExecutor operations,
        IAggregateReader reader, RiskGovernanceReader history, IImmutableContentStore content, TimeProvider clock,
        IRequestContext<TRequest> context, Uuid tenant, Uuid program, Uuid risk, Uuid command, long expected,
        Uuid? control, Uuid treatment, string kind,
        Func<RiskTreatmentAssertion, OperationProvenance, CancellationToken, ValueTask<Result<PreparedRiskAssertion>>> prepare,
        Func<RiskTreatmentAssertion, OperationProvenance, ImmutableContentRef, PreparedRiskAssertion, Result> apply,
        CancellationToken ct) where TRequest : IRequestBase where TOut : notnull
    {
        if (tenant == Uuid.Empty || program == Uuid.Empty || risk == Uuid.Empty || command == Uuid.Empty || expected < 0)
            return Result<TOut>.Failure(new RequestError(RequestErrorKind.Validation,
                "An assertion operation requires its typed identity and original non-negative revision."));
        var actor = RiskActor.From(context.Actor, tenant);
        try
        {
            EventStreamAddress? admission = null;
            if (control is null)
            {
                admission = await history.LocateAssertionAdmissionAsync(tenant, program, risk, command, ct).ConfigureAwait(false);
                if (admission is null)
                {
                    control = await history.LocateControlAsync(tenant, program, risk, treatment, ct).ConfigureAwait(false);
                    if (control is null)
                        return Result<TOut>.Failure(new RequestError(RequestErrorKind.NotFound, "The risk control treatment was not found."));
                }
            }
            RiskTreatmentAssertion Open() => admission is { } source
                ? RiskTreatmentAssertion.ForAcceptedReplay(tenant, program, risk, source, command)
                : new RiskTreatmentAssertion(tenant, program, risk, control!.Value, command);
            var ownerStream = Open().Stream;
            var operation = FindingContent.Provenance(command, kind, ownerStream,
                ActorReference.ForMember(actor.MemberId, actor.Display), (ulong)expected, FindingCommands.Digest(context.Request!),
                clock.GetUtcNow()) with { FirstOwner = ownerStream };
            PreparedRiskAssertion? prepared = null;
            var accepted = await operations.ExecuteAsync(new NativeOperation<RiskTreatmentAssertion>(AcceptedOperationBinding.Of(operation),
                Open, owner => owner.Acceptance,
                async (owner, token) =>
                {
                    if (admission is not null)
                        return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                            "The scoped admission cannot be matched to its original native binding."));
                    var found = await RiskOwnerResolution.RequireRiskAsync(reader, tenant, program, risk, token).ConfigureAwait(false);
                    if (!found.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(found.Error!);
                    var next = await prepare(owner, operation, token).ConfigureAwait(false);
                    if (!next.IsSuccess)
                        return Result<FirstResponseDescriptor>.Failure(next.Error!);
                    prepared = next.Value!;
                    return Result<FirstResponseDescriptor>.Success(prepared.Response);
                }, (owner, first) => apply(owner, operation, first, prepared!)), context, ct).ConfigureAwait(false);
            return await NativeContent.ResponseAsync<TOut>(content, tenant, accepted, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException error)
        {
            return Result<TOut>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The exact scoped assertion source cannot be verified.", error is ImmutableContentUnavailableException));
        }
    }
}
''')
(p/'ProposeRiskControlTreatmentHandler.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Controls;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Remediation;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Admits one exact current-control proposal after native replay and preserves its original registration.</summary>
public sealed class ProposeRiskControlTreatmentHandler(NativeOperationExecutor operations, IAggregateReader reader,
    RiskGovernanceReader governanceReader, ControlActivationSource controls, IImmutableContentStore content,
    TimeProvider clock) : IRequestHandler<ProposeRiskControlTreatment, RiskControlTreatmentRegistration>
{
    public ValueTask<Result<RiskControlTreatmentRegistration>> HandleAsync(IRequestContext<ProposeRiskControlTreatment> context,
        CancellationToken ct)
    {
        var request = context.Request;
        return RiskTreatmentAssertionOperations.ExecuteAsync<ProposeRiskControlTreatment, RiskControlTreatmentRegistration>(operations,
            reader, governanceReader, content, clock, context, request.TenantId, request.ProgramId, request.RiskId, request.CommandId,
            request.ExpectedRevision, request.ControlId, request.CommandId, nameof(ProposeRiskControlTreatment),
            async (owner, operation, token) =>
            {
                var gate = owner.PreparePropose(request.ExpectedRevision);
                if (!gate.IsSuccess)
                    return Result<PreparedRiskAssertion>.Failure(gate.Error!);
                if (request.ControlId == Uuid.Empty || request.ControlVersionId == Uuid.Empty || RiskCommands.InvalidText(request.Rationale))
                    return Failure(RequestErrorKind.Validation, "A control treatment requires an approved control version and bounded rationale.");
                var source = await controls.LoadAsync(request.TenantId, request.ProgramId, request.ControlId, token).ConfigureAwait(false);
                if (!source.IsSuccess)
                    return Result<PreparedRiskAssertion>.Failure(source.Error!);
                if (source.Value.ApprovedVersion is not { Status: "approved" } approved || approved.VersionId != request.ControlVersionId)
                    return Failure(RequestErrorKind.Conflict, "A control treatment must name the control's current approved version.");
                var evaluation = await reader.HydrateAsync(new RiskEvaluation(request.TenantId, request.RiskId), token).ConfigureAwait(false);
                if (evaluation.Header?.TreatmentKind != "mitigate")
                    return Failure(RequestErrorKind.Conflict, "Choose the mitigate treatment before asserting a control treatment.");
                if (owner.Accepted is { } active)
                {
                    var accepted = await FindingContent.ReadAsync<RiskControlTreatmentView>(content, request.TenantId,
                        active.Proposed.TreatmentContent, token).ConfigureAwait(false);
                    if (accepted.ControlVersionId == request.ControlVersionId)
                        return Failure(RequestErrorKind.Conflict, "An accepted treatment assertion already names this exact control version.");
                }
                var view = new RiskControlTreatmentView(request.CommandId, request.RiskId, request.ControlId, request.ControlVersionId,
                    RiskStates.TreatmentProposed, request.Rationale.Trim(), operation.Actor, operation.AcceptedAt,
                    null, null, null, null, null, null, null, null) { Revision = owner.Revision + 1 };
                var blob = await FindingContent.WriteAsync(content, request.TenantId, RiskContent.TreatmentSchema, view, token).ConfigureAwait(false);
                var frozen = await FindingContent.FreezeAsync(content, request.TenantId, RiskContent.ControlTreatmentRegistrationSchema,
                    new RiskControlTreatmentRegistration(request.CommandId, owner.Revision + 1), token).ConfigureAwait(false);
                return Result<PreparedRiskAssertion>.Success(new(frozen.Response, frozen.Result, blob));
            }, (owner, operation, first, frozen) => owner.Propose(operation, frozen.Proposal!,
                Uuid.Parse(operation.Actor.Id, System.Globalization.CultureInfo.InvariantCulture), first, frozen.Result), ct);
    }

    static Result<PreparedRiskAssertion> Failure(RequestErrorKind kind, string message) => Result<PreparedRiskAssertion>.Failure(new RequestError(kind, message));
}
''')
(p/'ReviewRiskControlTreatmentHandler.cs').write_text('''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Independence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Remediation;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Records exact independent review; current personal authorization precedes native retry resolution.</summary>
public sealed class ReviewRiskControlTreatmentHandler(NativeOperationExecutor operations, IAggregateReader reader,
    RiskGovernanceReader governanceReader, ISeparationOfDutiesWaiverProofResolver waivers,
    IImmutableContentStore content, TimeProvider clock) : IRequestHandler<ReviewRiskControlTreatment>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<ReviewRiskControlTreatment> context, CancellationToken ct)
    {
        if (context.Invocation is not HttpInvocation || RequestActor.IsSystem(context.Actor) || !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out _))
            return Result.Failure(new RequestError(RequestErrorKind.Forbidden, "Risk sign-off requires a personal HTTP invocation."));
        var request = context.Request;
        var reviewed = await RiskTreatmentAssertionOperations.ExecuteAsync<ReviewRiskControlTreatment, UnitResult>(operations, reader,
            governanceReader, content, clock, context, request.TenantId, request.ProgramId, request.RiskId, request.CommandId,
            request.ExpectedRevision, null, request.TreatmentId, nameof(ReviewRiskControlTreatment),
            async (owner, operation, token) =>
            {
                if (owner.Pending is not { } pending || pending.TreatmentId != request.TreatmentId)
                    return Failure(RequestErrorKind.Conflict, "The control treatment has no pending assertion to review.");
                var gate = owner.PrepareReview(request.TreatmentId, request.ExpectedRevision);
                if (!gate.IsSuccess)
                    return Result<PreparedRiskAssertion>.Failure(gate.Error!);
                var proposed = await FindingContent.ReadAsync<RiskControlTreatmentView>(content, request.TenantId, pending.Proposed.TreatmentContent, token).ConfigureAwait(false);
                var member = Uuid.Parse(operation.Actor.Id, System.Globalization.CultureInfo.InvariantCulture);
                if (request.SeparationOfDutiesWaiverId is { } waiver)
                {
                    var scope = new SeparationOfDutiesWaiverProofScope(request.TenantId, waiver, member, member,
                        SeparationOfDutiesActions.Review, SeparationOfDutiesRecordTypes.RiskControlTreatment, request.TreatmentId,
                        proposed.ControlVersionId, request.ExpectedRevision);
                    var proof = await waivers.ResolveAsync(scope, operation.AcceptedAt, token).ConfigureAwait(false);
                    if (!proof.IsSuccess)
                        return Failure(RequestErrorKind.Forbidden, "The separation-of-duties waiver is not active for this member and treatment revision.");
                }
                else if (pending.ProposerMemberId == member)
                    return Failure(RequestErrorKind.Forbidden, "A control treatment proposer cannot review their own assertion.");
                if (request.Outcome is not (RiskStates.Accept or RiskStates.Reject) || RiskCommands.InvalidText(request.Rationale))
                    return Failure(RequestErrorKind.Validation, "A treatment review requires accept or reject and a bounded rationale.");
                var frozen = await RiskCommands.FreezeUnitAsync(content, request.TenantId, token).ConfigureAwait(false);
                return Result<PreparedRiskAssertion>.Success(new(frozen.Response, frozen.Result));
            }, (owner, operation, first, frozen) => owner.Review(operation, request.TreatmentId, request.Outcome,
                request.Rationale.Trim(), operation.Actor, operation.AcceptedAt, request.SeparationOfDutiesWaiverId, first, frozen.Result), ct).ConfigureAwait(false);
        return reviewed.IsSuccess ? Result.Success : Result.Failure(reviewed.Error!);
    }

    static Result<PreparedRiskAssertion> Failure(RequestErrorKind kind, string message) => Result<PreparedRiskAssertion>.Failure(new RequestError(kind, message));
}
''')
(p/'RetireRiskControlTreatmentHandler.cs').write_text('''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Risks;

/// <summary>Retires only the exact accepted assertion; retries retain the original native result after succession.</summary>
public sealed class RetireRiskControlTreatmentHandler(NativeOperationExecutor operations, IAggregateReader reader,
    RiskGovernanceReader governanceReader, IImmutableContentStore content, TimeProvider clock) : IRequestHandler<RetireRiskControlTreatment>
{
    public async ValueTask<Result> HandleAsync(IRequestContext<RetireRiskControlTreatment> context, CancellationToken ct)
    {
        var request = context.Request;
        var retired = await RiskTreatmentAssertionOperations.ExecuteAsync<RetireRiskControlTreatment, UnitResult>(operations, reader,
            governanceReader, content, clock, context, request.TenantId, request.ProgramId, request.RiskId, request.CommandId,
            request.ExpectedRevision, null, request.TreatmentId, nameof(RetireRiskControlTreatment),
            async (owner, _, token) =>
            {
                if (owner.Accepted?.TreatmentId != request.TreatmentId)
                    return Result<PreparedRiskAssertion>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "Only the exact accepted control treatment assertion can be retired."));
                var gate = owner.PrepareRetire(request.TreatmentId, request.ExpectedRevision);
                if (!gate.IsSuccess)
                    return Result<PreparedRiskAssertion>.Failure(gate.Error!);
                if (RiskCommands.InvalidText(request.Rationale))
                    return Result<PreparedRiskAssertion>.Failure(new RequestError(RequestErrorKind.Validation,
                        "Retiring a control treatment requires a bounded rationale."));
                var frozen = await RiskCommands.FreezeUnitAsync(content, request.TenantId, token).ConfigureAwait(false);
                return Result<PreparedRiskAssertion>.Success(new(frozen.Response, frozen.Result));
            }, (owner, operation, first, frozen) => owner.Retire(operation, request.TreatmentId, request.Rationale.Trim(),
                operation.Actor, operation.AcceptedAt, first, frozen.Result), ct).ConfigureAwait(false);
        return retired.IsSuccess ? Result.Success : Result.Failure(retired.Error!);
    }
}
''')
