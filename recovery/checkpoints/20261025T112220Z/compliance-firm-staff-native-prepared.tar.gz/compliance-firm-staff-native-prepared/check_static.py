from pathlib import Path
import json,os,re,subprocess
p=Path('/tmp/compliance-firm-staff-native-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
q=Parser(Language(tree_sitter_c_sharp.language()));fs=list(Path("/tmp/compliance-firm-staff-native-prepared/work").rglob("*.cs"));print(json.dumps({"files":len(fs),"errors":[str(f) for f in fs if q.parse(f.read_bytes()).root_node.has_error]}))'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')));assert not syntax['errors'],syntax
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
parser=Parser(Language(tree_sitter_c_sharp.language()))
expected={'FirmStaffRecord':(1,2),'FirmStaffIdentityClaim':(1,2),'SetFirmStaffStatusHandler':(3,3),
'RegisterFirmStaffHandler':(4,4),'FirmStaffViews':(3,3),'FirmStaffRegistrationReactor':(5,5),
'FirmStaffStatusReevaluationReactor':(9,9),'FirmStaffDirectoryProjector':(2,2),'FirmStaffAggregateReader':(2,2),
'FirmStaffRegistrationReceivers':(4,4),'FirmStaffHistorySnapshot':(1,1)}
files={str(f.relative_to(repo)):f for part in ['src','test'] for f in (repo/part).rglob('*.cs')}
for f in (p/'work').rglob('*.cs'):files[str(f.relative_to(p/'work'))]=f
calls=[];issues=[]
for rel,f in files.items():
 data=f.read_bytes();stack=[parser.parse(data).root_node]
 while stack:
  node=stack.pop();stack.extend(node.children)
  if node.type!='object_creation_expression':continue
  typ=node.child_by_field_name('type');args=node.child_by_field_name('arguments')
  if not typ or not args:continue
  name=data[typ.start_byte:typ.end_byte].decode().split('.')[-1]
  if name not in expected:continue
  count=sum(c.type=='argument' for c in args.named_children);row={'path':rel,'type':name,'arguments':count};calls.append(row)
  if not expected[name][0]<=count<=expected[name][1]:issues.append(row)
assert not issues,issues
preserved=[]
for before in (p/'base/test').rglob('*.cs'):
 after=p/'work'/before.relative_to(p/'base');names=lambda f:set(re.findall(r'\b(Should\w+)\s*\(',f.read_text()))
 assert names(before)<=names(after),(str(before),names(before)-names(after))
 assert after.read_text().count('Assert.')>=before.read_text().count('Assert.'),str(before)
 preserved+=sorted(names(before))
report={'syntax':syntax,'constructors':calls,'preservedAcceptanceNames':preserved,'issues':issues,'runtime':'Not run. Root owns slot.'}
(p/'static-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'syntax':syntax,'constructors':len(calls),'preserved':len(preserved),'issues':issues}))
