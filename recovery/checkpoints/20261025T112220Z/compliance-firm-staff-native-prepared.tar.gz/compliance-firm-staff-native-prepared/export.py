from pathlib import Path
import hashlib,json,difflib,shutil,subprocess
p=Path('/tmp/compliance-firm-staff-native-prepared');base=p/'base';work=p/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
src=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')]
redtree=p/'verify/red-baseline';shutil.rmtree(redtree,ignore_errors=True);shutil.copytree(base,redtree)
result=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/'behavioral-red.patch')],cwd=redtree,capture_output=True,text=True);assert result.returncode==0,result.stdout+result.stderr
arts={}
for name,selected,before in [('implementation.patch',src,base),('tests.patch',tests,base),('green-after-red.patch',paths,redtree),('full.patch',paths,base)]:
 value=''
 for r in selected:
  b=before/r;f=work/r
  value+=''.join(difflib.unified_diff(b.read_text().splitlines(True) if b.exists() else [],f.read_text().splitlines(True),fromfile='a/'+r if b.exists() else '/dev/null',tofile='b/'+r))
 f=p/name;f.write_text(value);arts[name]={'path':str(f),'sha256':sha(f)}
arts['behavioral-red.patch']={'path':str(p/'behavioral-red.patch'),'sha256':sha(p/'behavioral-red.patch')}
checks=[]
for label,sequence in [('full',['full.patch']),('split',['tests.patch','implementation.patch']),('staged',['behavioral-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/label;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest)
 for patch in sequence:
  result=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,capture_output=True,text=True);assert result.returncode==0,result.stdout+result.stderr
 assert all(sha(dest/r)==sha(work/r) for r in paths),label
 checks.append({'sequence':sequence,'exact':True})
rows=[{'path':r,'before':sha(base/r),'after':sha(work/r),'currentMainMatchesBase':sha(repo/r)==sha(base/r)} for r in paths]
(p/'owned-paths.txt').write_text('\n'.join(paths)+'\n');(p/'hashes.json').write_text(json.dumps(rows,indent=2)+'\n')
report={'status':'FROZEN','paths':rows,'artifacts':arts,'reconstruction':checks,
'scope':'FirmStaffRecord current registration/rejection/latest/revision authority plus SourceUseReservations and rolling native cut; lifetime _changes removed. Complete transient history validates all native roots/children/use chronology and unique logical IDs at actual physical cut. Default installed reader also verifies permanent one-fact canonical-user claims. Status prepares/freezes inside native executor and both public producers compare exact prepared payload/immutable metadata cuts before append. Complete receiver uses shared NativeReceiverPreparation only after all immutable command binding guards. Current/historical staff views verify original registered identity, exact native decision, full body attributes and MutationResultContent reference. Directory reevaluation discovery/handler/reactor no longer read retained-owner changes. Both actual reactors verify committed source checkpoint tuple/payload/full metadata before side effects or no-op. Directory projector composes verified historical views.',
'wire':'Existing DTOs, personal platform auth, event payloads/discriminator versions, response schemas and fixed202 registration/typed200 status stay unchanged. Root/child producers now fill existing FirstOwner explicitly. Claim/completion retain nullable ExpectedRevision or zero; process factory already supplies null. Independent professional-duty and engagement source-use logic/active permits/settled-before-grant fences stay intact, with selected append cut required. Source-use grant settlement can precede staff registration as before; no new caps, permits or trusted commands.',
'shared':'One additional FirmStaffAggregateReader production decorator. Existing FirmStaffViews gains IDomainEventReader; registration reactor gains ISourceFactResolver+IAggregateReader; status reactor gains IDomainEventReader+ISourceFactResolver+IImmutableContentStore. Directory projector second ctor arg is FirmStaffViews instead of content store; status handler removes obsolete IAggregateReader arg. Auto registrations already exist; no Program/JSON/shared service mutations. Preserve all current root wrappers. IndependenceHost gets explicit in-memory source resolver; FirmStaffFacts projector and real accepted-event child causation/selected completion/FirstOwner are migrated; one source-use fixture selects its actual grant and settle command IDs.',
'qualification':'No persisted legacy qualification is claimed for old child facts with null FirstOwner or fabricated root UUID causation in synthetic histories; new production/seeds emit exact native first owner and actual acceptance event cause. Durable schema identity is unchanged. Complete native retry still requires verified original registration body to bind supplied UserId (and Claim Practice) because those extra command terms are not all stored in target native binding. Do not skip that immutable guard. After binding, completion resolves/rechecks receipt before claim/candidate writes through shared helper; its focused equal-winner regression is included. Source/Batch import protocol qualification remains separately recorded, no changes to frozen artifacts. No full fifth-family completion claim.',
'validation':'Static parse46 C#;95 explicit effective constructor callsites;29 saved baseline acceptance method names and no Assert count drops. Full/split/qualified-oldAPI-RED-then-green exact final reconstruction. New native tests cover intermediate payload/event substitution, truncation, unselected duplicate logical status on installed reader, valid older cut after later append, forged registration checkpoint with hashed aggregate identity, and actual completion equal winner before losing immutable write. No local .NET/runtime/Jev/Git/main edits.',
'runtimeEvidence':'Root-qualified OLD-API RED2 exact source/tests/logs at /Users/jrepanich/.codex/recovery/compliance-core-20261024T141258Z/firm-staff-qualified-red:49 retained changes; actual equal status winner lost after losing immutable StaffContent write. Behavioral RED patch preserves those two names/tests and original assertions. Root owns final runtime qualification.',
'filters':['FullyQualifiedName~FirmStaff|FullyQualifiedName~DirectoryIndependenceReevaluation|FullyQualifiedName~ProfessionalDutyChange|FullyQualifiedName~EngagementPersonalDecision|FullyQualifiedName~SourceUseReservationsVerifiedHistory'],
'next':'FirmProfessionalDutyDesignation, then PracticeIndependenceCommitment, ClientServiceIndependence, ServiceEngagementIndependence as bounded independently frozen layers. No new issues.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'source':len(src),'tests':len(tests),'artifacts':arts,'reconstruction':checks,'handoffSha256':sha(p/'handoff.json')},indent=2))
