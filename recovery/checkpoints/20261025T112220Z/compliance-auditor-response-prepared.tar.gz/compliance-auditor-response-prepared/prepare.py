from pathlib import Path
import shutil,re
p=Path('/tmp/compliance-auditor-response-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=['src/Compliance.Core/Features/AuditorRequests/'+n+'.cs' for n in ['AuditorResponse','AuthorizeAuditorResponseRequestResolutionUseHandler','ReviseAuditResponseDraftHandler','SubmitAuditResponseHandler','ReviewAuditResponseHandler','DeliverAuditResponseHandler','RecordAuditorResponseDispositionHandler']]+['test/Compliance.Tests/Features/AuditorRequests/'+n+'.cs' for n in ['AuditorRequestFixture','AuditorRequestTests','AuditorResponseCommandHandlerTests']]
for rel in paths:
 for side in ['base','work']:
  f=p/side/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,f)
d=p/'work/src/Compliance.Core/Features/AuditorRequests';f=d/'AuditorResponse.cs';s=f.read_text().replace('    readonly List<DomainEvent> _facts = [];\n','').replace('    readonly SortedSet<long> _closedGenerations = [];','    long? _closedByGeneration;').replace('_closedGenerations.Add(settled.Generation);','_closedByGeneration ??= settled.Generation;').replace('_closedGenerations.Count > 0','_closedByGeneration is not null')
s=re.sub(r'^\s*_facts.Add\([^\n]+\);\n','\n',s,flags=re.M)
a=s.index('    /// <summary>The request generations whose resolution fenced this response.');b=s.index('    /// <summary>Checks that the response can be materialized.',a)
s=s[:a]+'''    /// <summary>The first resolved parent generation whose verified settlement permanently fenced this response.</summary>
    public long? ClosedByGeneration => _closedByGeneration;

    /// <summary>The tenant of this response owner.</summary>
    public Uuid TenantId => _tenantId;

    /// <summary>The exact latest immutable content fact that a resolution may pin.</summary>
    public DomainEvent? CurrentContentFactById(Uuid eventId) => _latest?.Metadata.EventId == eventId ? _latest : null;

'''+s[b:]
s=s.replace('\n\n\n','\n\n').replace('Uses.ApplyGranted(SourceUsePurpose.RequestResolution, granted);\n\n','Uses.ApplyGranted(SourceUsePurpose.RequestResolution, granted);\n')
assert '_facts' not in s and '_closedGenerations' not in s and 'Uses.ObserveOwnerFact(ev);' in s and 'base.Apply(ev);' in s
f.write_text(s)
f=d/'AuthorizeAuditorResponseRequestResolutionUseHandler.cs';f.write_text(f.read_text().replace('response.FactById(request.SourceContentEventId)','response.CurrentContentFactById(request.SourceContentEventId)'))
for name in ['ReviseAuditResponseDraftHandler','SubmitAuditResponseHandler','ReviewAuditResponseHandler','DeliverAuditResponseHandler','RecordAuditorResponseDispositionHandler']:
 f=d/(name+'.cs');s=f.read_text();a=s.index('        var snapshot = await reader.HydrateAsync(');b=s.index('        var provenance =',a)
 s=s[:a]+'''        var snapshot = new AuditorResponse(request.TenantId, request.ProgramId,
            request.RequestId, request.ResponseId, request.CommandId);
'''+s[b:]
 s=s.replace('AuditorCommands.Digest(request), now);','AuditorCommands.Digest(request), now) with { FirstOwner = snapshot.Stream };')
 a=s.index('        if (snapshot.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');start=s.index('\n        {',a)+len('\n        {');end=s.index('\n        }\n\n        var outcome =',start)
 body=s[start:end].replace('snapshot.', 'owner.').replace('request.TenantId, snapshot,','request.TenantId, owner,').replace(', ct)', ', token)').replace(', ct\n', ', token\n')
 body=body.replace('return prepared;','return Result<FirstResponseDescriptor>.Failure(prepared.Error!);').replace('return available;','return Result<FirstResponseDescriptor>.Failure(available.Error!);').replace('return Result.Failure(policy.Error!);','return Result<FirstResponseDescriptor>.Failure(policy.Error!);')
 body=re.sub(r'return AuditorCommands.Validation\(("[^"\n]+")\);',r'return Result<FirstResponseDescriptor>.Failure(AuditorCommands.Validation(\1).Error!);',body)
 s=s[:a]+'''        async ValueTask<Result<FirstResponseDescriptor>> PrepareAsync(AuditorResponse owner, CancellationToken token)
        {'''+body+'''
            return Result<FirstResponseDescriptor>.Success(response!);
        }
'''+s[end+len('\n        }'):]
 a=s.index('            auditorResponse => AuditorContent.Prepared(');b=s.index('\n            (AuditorResponse auditorResponse',a)
 s=s[:a]+'            PrepareAsync,'+s[b:]
 s=s.replace('NativeOperationExecutor operations, IAggregateReader reader,\n    ','NativeOperationExecutor operations, ')
 s=s.replace('\n\n\n','\n\n');f.write_text(s)
