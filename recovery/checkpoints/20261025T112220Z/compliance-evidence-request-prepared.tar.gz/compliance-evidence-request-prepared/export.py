from pathlib import Path
import hashlib,difflib,json,subprocess,shutil,os,re
p=Path('/tmp/compliance-evidence-request-prepared');base=p/'base';work=p/'work';repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None
paths=sorted(str(f.relative_to(work)) for f in work.rglob('*') if f.is_file() and sha(f)!=sha(base/f.relative_to(work)))
source=[r for r in paths if r.startswith('src/')];tests=[r for r in paths if r.startswith('test/')]
def export(name,selected):
 text=[]
 for r in selected:
  a=base/r;b=work/r;text+=difflib.unified_diff(a.read_text().splitlines(True) if a.exists() else [],b.read_text().splitlines(True),fromfile='a/'+r if a.exists() else '/dev/null',tofile='b/'+r)
 f=p/name;f.write_text(''.join(text));return {'path':str(f),'sha256':sha(f),'paths':selected}
arts={k:export(k,v) for k,v in [('implementation.patch',source),('tests.patch',tests),('behavioral-red.patch',tests),('green-after-red.patch',source),('full.patch',paths)]}
checks=[]
for name,sequence in [('full',['full.patch']),('staged',['behavioral-red.patch','green-after-red.patch'])]:
 dest=p/'verify'/name;shutil.rmtree(dest,ignore_errors=True);shutil.copytree(base,dest)
 for patch in sequence:
  run=subprocess.run(['patch','-p1','-E','--batch','-i',str(p/patch)],cwd=dest,text=True,capture_output=True);assert run.returncode==0,run.stdout+run.stderr
 assert all(sha(dest/r)==sha(work/r) for r in paths);checks.append({'sequence':sequence,'exact':True})
code='''from pathlib import Path
from tree_sitter import Language,Parser
import tree_sitter_c_sharp,json
p=Parser(Language(tree_sitter_c_sharp.language()));fs=list(Path("/tmp/compliance-evidence-request-prepared/work").rglob("*.cs"));print(json.dumps({"files":len(fs),"errors":[str(f) for f in fs if p.parse(f.read_bytes()).root_node.has_error]}))
'''
syntax=json.loads(subprocess.check_output(['/opt/homebrew/bin/python3','-c',code],text=True,env=dict(os.environ,PYTHONPATH='/tmp/compliance-csharp-syntax314')));assert not syntax['errors'],syntax
acceptances=[]
for name in ['EvidenceRequestTests.cs','EvidenceRequestHandlerTests.cs']:
 f=repo/'test/Compliance.Tests/Features/Evidence'/name
 acceptances+=sorted(set(re.findall(r'\b(Should\w+)\s*\(',f.read_text())))
newtests=[name for r in tests for name in re.findall(r'\b(Should\w+)\s*\(',(work/r).read_text())]
report={'paths':[{'path':r,'before':sha(base/r),'after':sha(work/r),'mainStillMatchesBaseline':sha(repo/r)==sha(base/r)} for r in paths],'artifacts':arts,'reconstruction':checks,'syntax':syntax,'prerequisites':['Current SourceUse72 finalized-history selection + protected owner fact hook','Merged central NativeOperationExecutor expected preparation failure acceptance recheck'],'runtime':'Not run; root owns slot.','preservedAcceptanceNames':acceptances,'newTests':newtests,'constructors':{'CancelEvidenceRequestHandler':'(NativeOperationExecutor, IImmutableContentStore, TimeProvider); removed unused IAggregateReader. No direct new call sites found in repo. Other handler constructors unchanged.'},'sourceUse':'base.Apply(ev); Uses.ObserveOwnerFact(ev) preserved exactly. No generic reservation edits or terminal dictionaries. Content pin is bounded lifecycle facts only, generic authorization keeps exact current/latest fact check.','wire':'Existing v2 lifecycle/v1 source-use tags and result/HTTP/query contracts unchanged. Fresh root producers explicitly record FirstOwner.','scope':'Evidence lifecycle bounded at 2 original content facts; no artificial externalization. Historical proof reads are verified transiently by installed finalized SourceUseAggregateReader.'}
(p/'handoff.json').write_text(json.dumps(report,indent=2)+'\n');(p/'behavioral-red-filter.txt').write_text('FullyQualifiedName~EvidenceRequestNativePreparationTests|FullyQualifiedName~EvidenceRequestNativeHistoryTests\n');(p/'focused-filter.txt').write_text('FullyQualifiedName~EvidenceRequest|FullyQualifiedName~RiskGovernanceHandlerTests|FullyQualifiedName~RiskTreatmentActionNative|FullyQualifiedName~SourceUseReservations\n');print(json.dumps({'paths':len(paths),'syntax':syntax,'newTests':newtests,'artifacts':arts},indent=2))
