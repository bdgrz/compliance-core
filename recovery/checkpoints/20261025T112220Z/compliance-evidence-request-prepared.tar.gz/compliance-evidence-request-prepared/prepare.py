from pathlib import Path
import shutil
p=Path('/tmp/compliance-evidence-request-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=['src/Compliance.Core/Features/Evidence/EvidenceRequest.cs','src/Compliance.Core/Features/Evidence/OpenEvidenceRequestHandler.cs','src/Compliance.Core/Features/Evidence/FulfilEvidenceRequestHandler.cs','src/Compliance.Core/Features/Evidence/CancelEvidenceRequestHandler.cs','src/Compliance.Core/Features/Evidence/AuthorizeEvidenceRequestActionCompletionUseHandler.cs','src/Compliance.Core/Features/Evidence/EvidenceRequestReader.cs']
for rel in paths:
 for part in ['base','work']:
  f=p/part/rel;f.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(repo/rel,f)
f=p/'work/src/Compliance.Core/Features/Evidence/EvidenceRequest.cs';s=f.read_text().replace('    readonly List<DomainEvent> _facts = [];\n','')
import re
s=re.sub(r'^\s*_facts.Add\([^\n]+\);\n','\n',s,flags=re.M)
s=s.replace('''    /// <summary>The fact with this event id.</summary>
    public DomainEvent? FactById(Uuid eventId) => _facts.FirstOrDefault(fact => fact.Metadata?.EventId == eventId);''','''    /// <summary>The exact original lifecycle content fact; technical source-use history belongs to its verified selection.</summary>
    public DomainEvent? ContentFactById(Uuid eventId) => _opened?.Metadata.EventId == eventId ? _opened
        : _fulfilled?.Metadata.EventId == eventId ? _fulfilled
        : _cancelled?.Metadata.EventId == eventId ? _cancelled : null;''')
assert 'Uses.ObserveOwnerFact(ev);' in s and 'base.Apply(ev);' in s
f.write_text(s)
f=p/'work/src/Compliance.Core/Features/Evidence/AuthorizeEvidenceRequestActionCompletionUseHandler.cs';s=f.read_text().replace('evidence.FactById(request.SourceContentEventId)', 'evidence.ContentFactById(request.SourceContentEventId)');f.write_text(s)
# Move complete new-operation preparation under the native executor; current authorization remains before replay.
for name,outtype in [('OpenEvidenceRequestHandler','EvidenceRequestView'),('CancelEvidenceRequestHandler','EvidenceRequestView'),('FulfilEvidenceRequestHandler','EvidenceRequestView')]:
 f=p/'work/src/Compliance.Core/Features/Evidence'/f'{name}.cs';s=f.read_text()
 # Open/Cancel do not need an external snapshot at all. Fulfil retains its immutable opening owner + current manager authorization.
 if name!='FulfilEvidenceRequestHandler':
  a=s.index('        var snapshot = await reader.HydrateAsync(');b=s.index('        var provenance =',a)
  prefix='''        var snapshot = new EvidenceRequest(request.TenantId, request.ProgramId,
            request.EvidenceRequestId, '''+('request.EvidenceRequestId' if name=='OpenEvidenceRequestHandler' else 'request.CommandId')+''');
'''
  s=s[:a]+prefix+s[b:]
 s=s.replace('FindingCommands.Digest(request), now);','FindingCommands.Digest(request), now) with { FirstOwner = snapshot.Stream };')
 a=s.index('        if (snapshot.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');start=s.index('\n        {',a)+len('\n        {');end=s.index('\n        }\n\n        var outcome = ',start)
 body=s[start:end].replace('snapshot.', 'owner.').replace(', ct)', ', token)').replace(', ct\n', ', token\n')
 body=body.replace('Result<EvidenceRequestView>.Failure', 'Result<FirstResponseDescriptor>.Failure')
 block='''        async ValueTask<Result<FirstResponseDescriptor>> PrepareAsync(EvidenceRequest owner, CancellationToken token)
        {'''+body+'''
            return Result<FirstResponseDescriptor>.Success(response!);
        }
'''
 s=s[:a]+block+s[end+len('\n        }'):]
 if name=='OpenEvidenceRequestHandler':
  s=s.replace('''            evidenceRequest => FindingCommands.Prepared(evidenceRequest.PrepareOpen(), response),''','''            PrepareAsync,''')
 else:
  s=s.replace('''            evidenceRequest => FindingCommands.Prepared(evidenceRequest.PrepareDecision(request.ExpectedRevision),
                response),''','''            PrepareAsync,''')
 # Cancel does not otherwise need its reader after moving hydration; retain it only if current authorization/source policy uses it.
 if name=='CancelEvidenceRequestHandler':
  s=s.replace('NativeOperationExecutor operations, IAggregateReader reader,\n    IImmutableContentStore content', 'NativeOperationExecutor operations, IImmutableContentStore content')
 f.write_text(s)
