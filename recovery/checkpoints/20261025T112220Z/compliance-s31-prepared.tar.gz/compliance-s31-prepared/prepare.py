from pathlib import Path
import json, hashlib, difflib
ROOT=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
OUT=Path('/tmp/compliance-s31-prepared')
BEFORE=OUT/'before'; AFTER=OUT/'after'
import shutil
if AFTER.exists(): shutil.rmtree(AFTER)
changed={}
def put(path,text):
 p=ROOT/path
 old=p.read_text() if p.exists() else None
 if path not in changed:
  changed[path]=old
  if old is not None:
   b=BEFORE/path;b.parent.mkdir(parents=True,exist_ok=True);b.write_text(old)
 a=AFTER/path;a.parent.mkdir(parents=True,exist_ok=True);a.write_text(text)
def edit(path,fn):
 text=(AFTER/path).read_text() if (AFTER/path).exists() else (ROOT/path).read_text()
 put(path,fn(text))
def delete(path):
 put(path,'');(AFTER/path).unlink()
core='src/Compliance.Core/Features/Retention/'
common='src/Compliance.Common/Features/Retention/'
tests='test/Compliance.Tests/Features/Retention/'
for name in ['RecordArtifactRetentionBasis','ReleaseArtifactLegalHold']:
 edit(common+name+'.cs',lambda s,n=name:s.replace('record '+n+'(Uuid TenantId','record '+n+'(Uuid CommandId, Uuid TenantId'))
for name in ['ArtifactRetentionBound','ArtifactRetentionBasisRecorded','ArtifactLegalHoldPlaced','ArtifactLegalHoldReleased']:
 edit(common+name+'.cs',lambda s:s.replace('using Cntryl.Portia;','using Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;\nusing Cntryl.Portia;').replace('DateTimeOffset RecordedAt) : DomainEvent;','DateTimeOffset RecordedAt,\n    OperationProvenance Operation, ImmutableContentRef? FirstResponse = null,\n    ImmutableContentRef? OperationResult = null) : DomainEvent, INativeOperationFact;'))
put(core+'ArtifactRetentionRules.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

/// <summary>Policy and exact-source validation shared by the independent retention owners.</summary>
public static class ArtifactRetentionRules
{
    /// <summary>The existing seven-year retention policy; splitting owners does not authorize disposition.</summary>
    public const string Policy = "m0_d16_v1";

    public static bool IsSupportedSource(string kind) => kind is "evidence_artifact" or "application_import";
    public static bool ValidSource(ArtifactRetentionSource source) => source.TenantId != Uuid.Empty &&
        source.SourceId != Uuid.Empty && IsSupportedSource(source.SourceKind) &&
        source.ContentSha256 is { Length: 64 } &&
        source.ContentSha256.All(static c => c is >= '0' and <= '9' or >= 'a' and <= 'f');
    internal static bool ValidActor(ActorReference actor) => actor is { Kind: "member", Display.Length: > 0 and <= 2000 } &&
        !string.IsNullOrWhiteSpace(actor.Display) && Uuid.TryParse(actor.Id, null, out var id) && id != Uuid.Empty;
    internal static bool ValidReason(string reason) => !string.IsNullOrWhiteSpace(reason) && reason.Length <= 2000;
    internal static bool ValidPeriod(DateOnly first, DateOnly last) => first <= last && last.Year <= 9992;
    internal static string BasisKind(string kind) => kind == "evidence_artifact" ? "source_period" : "admin_period";
    internal static Result Invalid(string message) => Result.Failure(new RequestError(RequestErrorKind.Validation, message));
    internal static Result Conflict(string message) => Result.Failure(new RequestError(RequestErrorKind.Conflict, message));

    internal static Result? Replay(NativeAcceptance acceptance, OperationProvenance operation) =>
        acceptance.Decide(AcceptedOperationBinding.Of(operation)) switch
        {
            NativeAcceptanceDecision.Replayed => Result.Success,
            NativeAcceptanceDecision.Conflict => Result.Failure(AcceptedAppendResult.ConflictError),
            _ => null,
        };

    internal static bool ValidOperation(OperationProvenance operation, EventStreamAddress owner,
        string kind, long expectedRevision) => operation.Owner == owner && operation.AffectedOwner == owner &&
        operation.ExpectedRevisionOwner == owner && operation.CommandKind == kind &&
        operation.LogicalId != Uuid.Empty && operation.RootOperationId == operation.LogicalId &&
        operation.OriginalExpectedRevision == (ulong)expectedRevision && ValidActor(operation.Actor) &&
        operation.AcceptedAt != default;
}
''')
put(core+'ArtifactRetentionBasis.cs','''using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

/// <summary>One immutable seven-year basis for one exact tenant artifact content identity.</summary>
public sealed class ArtifactRetentionBasis : Aggregate
{
    public const string Area = "artifact-retention-bases";
    readonly ArtifactRetentionSource _source;

    public ArtifactRetentionBasis(ArtifactRetentionSource source, Uuid selectedLogicalId = default)
        : base(IdentityOf(source), new EventStreamAddress(source.TenantId.ToString(), Area, IdentityOf(source).ToString()))
    {
        _source = source;
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<ArtifactRetentionBasisRecorded>(Apply);
    }

    public static Uuid IdentityOf(ArtifactRetentionSource source)
    {
        ArgumentNullException.ThrowIfNull(source);
        if (!ArtifactRetentionRules.ValidSource(source))
            throw new ArgumentException("A retention basis requires an exact supported tenant content identity.", nameof(source));
        return AggregateIdentity.Create("ArtifactRetentionBasis", source.TenantId, source.SourceKind,
            source.SourceId, source.ContentSha256);
    }

    public NativeAcceptance Acceptance { get; }
    public long Revision => Basis is null ? 0 : 1;
    public ArtifactRetentionSource Source => _source;
    public ArtifactRetentionBasisRecorded? Basis { get; private set; }

    public Result PrepareRecord(ArtifactRetentionSourceSnapshot source, long expectedRevision,
        DateOnly? periodStart, DateOnly? periodEnd, string reason)
    {
        if (source.Source != _source || source.Position == 0)
            return ArtifactRetentionRules.Conflict("The basis requires its exact durable source content.");
        if (expectedRevision < 0 || !ArtifactRetentionRules.ValidReason(reason))
            return ArtifactRetentionRules.Invalid("A basis requires a non-negative revision and bounded reason.");
        if (expectedRevision != Revision || Basis is not null)
            return ArtifactRetentionRules.Conflict("This exact content already has a basis or its revision changed.");
        if ((periodStart is null) != (periodEnd is null))
            return InvalidPeriod();
        if (_source.SourceKind == "evidence_artifact")
        {
            if (source.PeriodStart is not { } nativeStart || source.PeriodEnd is not { } nativeEnd ||
                periodStart is { } first && first != nativeStart || periodEnd is { } last && last != nativeEnd)
                return InvalidPeriod();
            periodStart = nativeStart;
            periodEnd = nativeEnd;
        }
        return periodStart is { } start && periodEnd is { } end && ArtifactRetentionRules.ValidPeriod(start, end)
            ? Result.Success : InvalidPeriod();
    }

    public Result Record(OperationProvenance operation, ArtifactRetentionSourceSnapshot source,
        DateOnly? periodStart, DateOnly? periodEnd, string reason,
        ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        if (ArtifactRetentionRules.Replay(Acceptance, operation) is { } retry)
            return retry;
        if (operation.OriginalExpectedRevision is not { } expected || expected > long.MaxValue ||
            !ArtifactRetentionRules.ValidOperation(operation, Stream, "RecordArtifactRetentionBasis", (long)expected))
            return ArtifactRetentionRules.Invalid("The basis requires its exact native root operation.");
        var prepared = PrepareRecord(source, (long)expected, periodStart, periodEnd, reason);
        if (!prepared.IsSuccess)
            return prepared;
        var first = _source.SourceKind == "evidence_artifact" ? source.PeriodStart!.Value : periodStart!.Value;
        var last = _source.SourceKind == "evidence_artifact" ? source.PeriodEnd!.Value : periodEnd!.Value;
        RaiseEvent(new ArtifactRetentionBasisRecorded(_source, 1, source.Position, ArtifactRetentionRules.Policy,
            first, last, last.AddYears(7), ArtifactRetentionRules.BasisKind(_source.SourceKind), reason.Trim(),
            operation.Actor, operation.AcceptedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    void Apply(ArtifactRetentionBasisRecorded ev)
    {
        if (Basis is not null || ev.Source != _source || ev.Revision != 1 || ev.SourcePosition == 0 ||
            ev.Policy != ArtifactRetentionRules.Policy || !ArtifactRetentionRules.ValidPeriod(ev.PeriodStart, ev.PeriodEnd) ||
            ev.RetainsThrough != ev.PeriodEnd.AddYears(7) || ev.BasisKind != ArtifactRetentionRules.BasisKind(_source.SourceKind) ||
            !ArtifactRetentionRules.ValidReason(ev.Reason) || ev.Reason != ev.Reason.Trim() ||
            ev.RecordedBy != ev.Operation.Actor || ev.RecordedAt != ev.Operation.AcceptedAt ||
            !ArtifactRetentionRules.ValidOperation(ev.Operation, Stream, "RecordArtifactRetentionBasis", 0) ||
            ev.FirstResponse is null || ev.OperationResult is null)
            throw new InvalidOperationException("A retention basis is one exact attributed native content decision.");
        Acceptance.Observe(ev);
        Basis = ev;
    }

    static Result InvalidPeriod() => ArtifactRetentionRules.Invalid(
        "Retention requires the exact explicit supported period within policy date bounds.");
}
''')
put(core+'ArtifactLegalHold.cs','''using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

/// <summary>One indefinite legal hold and its one exact release, bound forever to the placed content.</summary>
public sealed class ArtifactLegalHold : Aggregate
{
    public const string Area = "artifact-legal-holds";
    readonly Uuid _tenantId;

    public ArtifactLegalHold(Uuid tenantId, Uuid holdId, Uuid selectedLogicalId = default)
        : base(holdId, new EventStreamAddress(tenantId.ToString(), Area, holdId.ToString()))
    {
        _tenantId = tenantId;
        Acceptance = new NativeAcceptance(selectedLogicalId);
        On<ArtifactLegalHoldPlaced>(Apply);
        On<ArtifactLegalHoldReleased>(Apply);
    }

    public NativeAcceptance Acceptance { get; }
    public ArtifactLegalHoldPlaced? Placement { get; private set; }
    public ArtifactLegalHoldReleased? Release { get; private set; }
    public long Revision => Release is not null ? 2 : Placement is not null ? 1 : 0;
    public ArtifactRetentionSource? Source => Placement?.Source;
    public ArtifactLegalHoldView? View => Placement is { } placed
        ? new(Id, placed.Reason, placed.RecordedBy, placed.RecordedAt,
            Release?.Reason, Release?.RecordedBy, Release?.RecordedAt)
        : null;

    public Result PreparePlace(ArtifactRetentionSourceSnapshot source, long expectedRevision, string reason)
    {
        if (!ValidSource(source) || expectedRevision < 0 || !ArtifactRetentionRules.ValidReason(reason))
            return ArtifactRetentionRules.Invalid("A legal hold requires exact durable content and a bounded reason.");
        return expectedRevision == 0 && Placement is null ? Result.Success :
            ArtifactRetentionRules.Conflict("The hold identity is already placed or its original revision changed.");
    }

    public Result PrepareRelease(ArtifactRetentionSourceSnapshot source, long expectedRevision, string reason,
        DateTimeOffset at)
    {
        if (!ValidSource(source) || expectedRevision < 0 || !ArtifactRetentionRules.ValidReason(reason) || at == default)
            return ArtifactRetentionRules.Invalid("A release requires exact durable content and a bounded reason.");
        if (Placement is null)
            return Result.Failure(new RequestError(RequestErrorKind.NotFound, "The legal hold was not found."));
        if (source.Source != Placement.Source || source.Position < Placement.SourcePosition)
            return ArtifactRetentionRules.Conflict("The release source differs from or precedes the exact held content.");
        if (Release is not null || expectedRevision != 1)
            return ArtifactRetentionRules.Conflict("The legal hold is released or its revision changed.");
        return at >= Placement.RecordedAt ? Result.Success :
            ArtifactRetentionRules.Invalid("A release cannot precede the placement.");
    }

    public Result Place(OperationProvenance operation, ArtifactRetentionSourceSnapshot source, string reason,
        ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        if (ArtifactRetentionRules.Replay(Acceptance, operation) is { } retry)
            return retry;
        if (operation.LogicalId != Id ||
            !ArtifactRetentionRules.ValidOperation(operation, Stream, "PlaceArtifactLegalHold", 0))
            return ArtifactRetentionRules.Invalid("The hold identity is its exact native creation operation.");
        var prepared = PreparePlace(source, 0, reason);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new ArtifactLegalHoldPlaced(source.Source, 1, source.Position, Id, reason.Trim(), operation.Actor,
            operation.AcceptedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    public Result ReleaseHold(OperationProvenance operation, ArtifactRetentionSourceSnapshot source, string reason,
        ImmutableContentRef firstResponse, ImmutableContentRef operationResult)
    {
        ArgumentNullException.ThrowIfNull(operation);
        if (ArtifactRetentionRules.Replay(Acceptance, operation) is { } retry)
            return retry;
        if (!ArtifactRetentionRules.ValidOperation(operation, Stream, "ReleaseArtifactLegalHold", 1))
            return ArtifactRetentionRules.Invalid("A hold release is its exact native operation at the original revision.");
        var prepared = PrepareRelease(source, 1, reason, operation.AcceptedAt);
        if (!prepared.IsSuccess)
            return prepared;
        RaiseEvent(new ArtifactLegalHoldReleased(source.Source, 2, source.Position, Id, reason.Trim(), operation.Actor,
            operation.AcceptedAt, operation, firstResponse, operationResult));
        return Result.Success;
    }

    bool ValidSource(ArtifactRetentionSourceSnapshot source) => Id != Uuid.Empty && _tenantId != Uuid.Empty &&
        ArtifactRetentionRules.ValidSource(source.Source) && source.Source.TenantId == _tenantId && source.Position > 0;

    void Apply(ArtifactLegalHoldPlaced ev)
    {
        if (Placement is not null || ev.HoldId != Id || ev.Revision != 1 || ev.SourcePosition == 0 ||
            !ValidSource(new(ev.Source, ev.SourcePosition)) || ev.Operation.LogicalId != Id ||
            !ValidFact(ev.Operation, ev.RecordedBy, ev.RecordedAt, ev.Reason, "PlaceArtifactLegalHold", 0) ||
            ev.FirstResponse is null || ev.OperationResult is null)
            throw new InvalidOperationException("A legal hold is one exact attributed native placement.");
        Acceptance.Observe(ev);
        Placement = ev;
    }

    void Apply(ArtifactLegalHoldReleased ev)
    {
        if (Placement is null || Release is not null || ev.HoldId != Id || ev.Revision != 2 ||
            ev.Source != Placement.Source || ev.SourcePosition < Placement.SourcePosition ||
            ev.RecordedAt < Placement.RecordedAt ||
            !ValidFact(ev.Operation, ev.RecordedBy, ev.RecordedAt, ev.Reason, "ReleaseArtifactLegalHold", 1) ||
            ev.FirstResponse is null || ev.OperationResult is null)
            throw new InvalidOperationException("A legal hold has one exact native release of its placed content.");
        Acceptance.Observe(ev);
        Release = ev;
    }

    bool ValidFact(OperationProvenance operation, ActorReference actor, DateTimeOffset at, string reason,
        string kind, long expected) => operation.Actor == actor && operation.AcceptedAt == at &&
        ArtifactRetentionRules.ValidReason(reason) && reason == reason.Trim() &&
        ArtifactRetentionRules.ValidOperation(operation, Stream, kind, expected);
}
''')
put(core+'ArtifactRetentionMutation.cs','''using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

/// <summary>Native root admission for independently owned retention decisions; authorization stays in the request pipeline.</summary>
sealed class ArtifactRetentionMutation(NativeOperationExecutor operations, IAggregateReader reader,
    IImmutableContentStore content, TimeProvider clock)
{
    public ValueTask<Result> RecordBasisAsync(IRequestContext<RecordArtifactRetentionBasis> context, CancellationToken ct) =>
        Personal(context, actor => RecordBasisAsync(context, context.Request, actor, ct));

    // Generated exports already prove their personal actor and exact frozen source. Preserve that existing policy
    // while moving their basis to the same native owner; the separate export process remains a later slice.
    internal ValueTask<Result> RecordBasisAsync(IExecutionContext context, RecordArtifactRetentionBasis request,
        ActorReference actor, CancellationToken ct) => ExecuteAsync(context, request, request.TenantId,
        request.SourceKind, request.SourceId, request.ExpectedContentSha256, request.CommandId,
        "RecordArtifactRetentionBasis", request.ExpectedRevision, actor,
        () => new ArtifactRetentionBasis(new(request.TenantId, request.SourceKind, request.SourceId,
            request.ExpectedContentSha256), request.CommandId), basis => basis.Acceptance,
        (basis, source, _) => basis.PrepareRecord(source, request.ExpectedRevision,
            request.PeriodStart, request.PeriodEnd, request.Reason),
        (basis, source, operation, first, result) => basis.Record(operation, source,
            request.PeriodStart, request.PeriodEnd, request.Reason, first, result), ct);

    public ValueTask<Result> PlaceAsync(IRequestContext<PlaceArtifactLegalHold> context, CancellationToken ct) =>
        Personal(context, actor =>
        {
            var request = context.Request;
            return ExecuteAsync(context, request, request.TenantId, request.SourceKind, request.SourceId,
                request.ExpectedContentSha256, request.HoldId, "PlaceArtifactLegalHold", request.ExpectedRevision, actor,
                () => new ArtifactLegalHold(request.TenantId, request.HoldId, request.HoldId), hold => hold.Acceptance,
                (hold, source, _) => hold.PreparePlace(source, request.ExpectedRevision, request.Reason),
                (hold, source, operation, first, result) => hold.Place(operation, source, request.Reason, first, result), ct);
        });

    public ValueTask<Result> ReleaseAsync(IRequestContext<ReleaseArtifactLegalHold> context, CancellationToken ct) =>
        Personal(context, actor =>
        {
            var request = context.Request;
            return ExecuteAsync(context, request, request.TenantId, request.SourceKind, request.SourceId,
                request.ExpectedContentSha256, request.CommandId, "ReleaseArtifactLegalHold", request.ExpectedRevision, actor,
                () => new ArtifactLegalHold(request.TenantId, request.HoldId, request.CommandId), hold => hold.Acceptance,
                (hold, source, at) => hold.PrepareRelease(source, request.ExpectedRevision, request.Reason, at),
                (hold, source, operation, first, result) => hold.ReleaseHold(operation, source, request.Reason, first, result), ct);
        });

    static ValueTask<Result> Personal<T>(IRequestContext<T> context, Func<ActorReference, ValueTask<Result>> next)
        where T : IArtifactRetentionAdminRequest
    {
        if (context.Invocation is not HttpInvocation || RequestActor.IsSystem(context.Actor) ||
            !UserIdentityClaims.TryGetBdgrzSubject(context.Actor, out var user))
            return ValueTask.FromResult(Result.Failure(new RequestError(RequestErrorKind.Forbidden,
                "Retention decisions require a personal Bdgrz HTTP invocation.")));
        return next(ActorReference.ForMember(RbacIds.Member(context.Request.TenantId, user),
            UserIdentityClaims.BdgrzDisplay(context.Actor, user)));
    }

    async ValueTask<Result> ExecuteAsync<TRequest, TOwner>(IExecutionContext context, TRequest request,
        Uuid tenant, string kind, Uuid sourceId, string expectedSha, Uuid logicalId, string commandKind,
        long expectedRevision, ActorReference actor, Func<TOwner> hydrate, Func<TOwner, NativeAcceptance> acceptance,
        Func<TOwner, ArtifactRetentionSourceSnapshot, DateTimeOffset, Result> prepare,
        Func<TOwner, ArtifactRetentionSourceSnapshot, OperationProvenance, ImmutableContentRef, ImmutableContentRef, Result> apply,
        CancellationToken ct) where TRequest : notnull where TOwner : Aggregate
    {
        var identity = new ArtifactRetentionSource(tenant, kind, sourceId, expectedSha);
        if (logicalId == Uuid.Empty || expectedRevision < 0 || !ArtifactRetentionRules.ValidSource(identity))
            return ArtifactRetentionRules.Invalid("A retention decision requires its exact typed identity, digest and non-negative owner revision.");
        var owner = hydrate();
        var at = clock.GetUtcNow();
        var operation = FindingContent.Provenance(logicalId, commandKind, owner.Stream, actor,
            (ulong)expectedRevision, AuthoredIntentDigest.Compute(request), at);
        ArtifactRetentionSourceSnapshot? selected = null;
        ImmutableContentRef? result = null;
        var outcome = await operations.ExecuteAsync(new NativeOperation<TOwner>(AcceptedOperationBinding.Of(operation),
            hydrate, acceptance, async (aggregate, token) =>
            {
                var source = await ArtifactRetentionSourceReader.LoadAsync(reader, tenant, kind, sourceId, token)
                    .ConfigureAwait(false);
                if (!source.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(source.Error!);
                if (source.Value.Source != identity)
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.Conflict,
                        "The retained source content differs from the authored exact digest."));
                var valid = prepare(aggregate, source.Value, at);
                if (!valid.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(valid.Error!);
                var fence = await ArtifactRetentionSourceReader.CheckAsync(reader, source.Value, token).ConfigureAwait(false);
                if (!fence.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(fence.Error!);
                selected = source.Value;
                var frozen = await FindingContent.FreezeAsync(content, tenant, UnitResult.Schema, new UnitResult(), token)
                    .ConfigureAwait(false);
                result = frozen.Result;
                return Result<FirstResponseDescriptor>.Success(frozen.Response);
            }, (aggregate, first) => apply(aggregate, selected!, operation, first, result!)), context, ct).ConfigureAwait(false);
        var response = await FindingContent.ResponseAsync<UnitResult>(content, tenant, outcome, ct).ConfigureAwait(false);
        return response.IsSuccess ? Result.Success : Result.Failure(response.Error!);
    }
}
''')
for cls,method in [('RecordArtifactRetentionBasis','RecordBasisAsync'),('PlaceArtifactLegalHold','PlaceAsync'),('ReleaseArtifactLegalHold','ReleaseAsync')]:
 put(core+cls+'Handler.cs',f'''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

sealed class {cls}Handler(ArtifactRetentionMutation mutation) : IRequestHandler<{cls}>
{{
    public ValueTask<Result> HandleAsync(IRequestContext<{cls}> context, CancellationToken ct) =>
        mutation.{method}(context, ct);
}}
''')
put(core+'ArtifactRetentionSnapshot.cs','''namespace Bdgrz.Compliance.Features.Retention;

/// <summary>A read composition of independent owners, never an admission or disposition authority.</summary>
public sealed record ArtifactRetentionSnapshot(ArtifactRetentionSource Source, ArtifactRetentionBasisRecorded? Basis,
    IReadOnlyList<ArtifactLegalHoldView> Holds, long Revision, string Stamp)
{
    public ArtifactRetentionView Assess(DateOnly assessedAt)
    {
        var active = Holds.Count(static hold => hold.ReleasedAt is null);
        var elapsed = Basis is not null && assessedAt > Basis.RetainsThrough;
        var blockers = new List<string>();
        if (Basis is null)
        {
            blockers.Add("retention_basis_unrecorded");
            blockers.Add("supported_period_unrecorded");
        }
        else if (!elapsed)
            blockers.Add("retention_unelapsed");
        if (active > 0)
            blockers.Add("active_legal_hold");
        blockers.Add("engagement_hold_authority_unavailable");
        blockers.Add("historical_reliance_unavailable");
        blockers.Add("disposition_approval_unavailable");
        blockers.Add(Source.SourceKind == "application_import" ? "inline_disposition_unsupported" : "storage_hold_enforcement_pending");
        return new(Source, Revision, Basis?.Policy, Basis?.PeriodStart, Basis?.PeriodEnd, Basis?.RetainsThrough,
            elapsed, active, Holds.Count, false, blockers.AsReadOnly());
    }
}
''')
put(core+'ArtifactRetentionReader.cs','''using System.Globalization;
using Bdgrz.Compliance.Features.Kernel;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

/// <summary>Discovers holds from native placement facts and composes each independent authoritative owner.</summary>
public sealed class ArtifactRetentionReader(IAggregateReader aggregates, IDomainEventReader events)
{
    public async ValueTask<Result<ArtifactRetentionSnapshot>> ReadAsync(ArtifactRetentionSourceSnapshot source,
        CancellationToken ct = default)
    {
        var first = await ReadOnceAsync(source, ct).ConfigureAwait(false);
        if (!first.IsSuccess)
            return first;
        var second = await ReadOnceAsync(source, ct).ConfigureAwait(false);
        return !second.IsSuccess ? second : first.Value.Stamp != second.Value.Stamp
            ? Changed() : first;
    }

    async ValueTask<Result<ArtifactRetentionSnapshot>> ReadOnceAsync(ArtifactRetentionSourceSnapshot source,
        CancellationToken ct)
    {
        var basis = await aggregates.HydrateAsync(new ArtifactRetentionBasis(source.Source), ct).ConfigureAwait(false);
        // Copy all scalar/read values immediately: an adapter returning a reused mutable owner must not erase the fence.
        var basisFact = basis.Basis;
        var basisPosition = basis.CommittedStreamPosition;
        var basisRevision = basis.Revision;
        if (basisFact is { } recorded && (recorded.Source != source.Source || recorded.SourcePosition > source.Position ||
                recorded.BasisKind == "source_period" &&
                (recorded.PeriodStart != source.PeriodStart || recorded.PeriodEnd != source.PeriodEnd)))
            return Changed();
        var ids = new HashSet<Uuid>();
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(source.Source.TenantId.ToString(),
                           ArtifactLegalHold.Area), EventCursor.Start, ct).ConfigureAwait(false))
        {
            if (record.Event.Metadata.IsAudit || record.Event is not ArtifactLegalHoldPlaced placed || placed.Source != source.Source)
                continue;
            var address = new EventStreamAddress(source.Source.TenantId.ToString(), ArtifactLegalHold.Area, placed.HoldId.ToString());
            if (record.Stream != address || record.Event.Metadata.AggregateId != placed.HoldId ||
                record.Event.Metadata.EventId == Uuid.Empty || !ids.Add(placed.HoldId))
                return Changed();
        }
        var holds = new List<ArtifactLegalHoldView>();
        var stamp = new List<string>
        {
            basis.Stream.ToString(), basisPosition.ToString(CultureInfo.InvariantCulture),
            basisRevision.ToString(CultureInfo.InvariantCulture),
        };
        var revision = basisRevision;
        foreach (var id in ids.OrderBy(static id => id.ToString(), StringComparer.Ordinal))
        {
            var hold = await aggregates.HydrateAsync(new ArtifactLegalHold(source.Source.TenantId, id), ct).ConfigureAwait(false);
            if (hold.Placement is not { } placed || placed.Source != source.Source ||
                placed.SourcePosition > source.Position || hold.Release is { } released && released.SourcePosition > source.Position ||
                hold.View is not { } view)
                return Changed();
            holds.Add(view);
            revision = checked(revision + hold.Revision);
            stamp.Add(id.ToString());
            stamp.Add(hold.CommittedStreamPosition.ToString(CultureInfo.InvariantCulture));
            stamp.Add(hold.Revision.ToString(CultureInfo.InvariantCulture));
        }
        return Result<ArtifactRetentionSnapshot>.Success(new(source.Source, basisFact, Array.AsReadOnly(holds.ToArray()),
            revision, ContentDigest.Sha256(System.Text.Encoding.UTF8.GetBytes(string.Join("\\n", stamp)))));
    }

    static Result<ArtifactRetentionSnapshot> Changed() => Result<ArtifactRetentionSnapshot>.Failure(
        new RequestError(RequestErrorKind.Conflict, "Retention sources changed or their complete owner history is unavailable.", true));
}
''')
put(core+'ArtifactRetentionRead.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

sealed class ArtifactRetentionRead(IAggregateReader reader, IDomainEventReader events, TimeProvider clock)
{
    public async ValueTask<Result<ArtifactRetentionView>> GetAsync(Uuid tenant, string kind, Uuid id,
        long? minimumRevision, CancellationToken ct)
    {
        if (minimumRevision is < 1)
            return Result<ArtifactRetentionView>.Failure(new RequestError(RequestErrorKind.Validation,
                "The minimum retention revision must be positive."));
        var source = await ArtifactRetentionSourceReader.LoadAsync(reader, tenant, kind, id, ct).ConfigureAwait(false);
        if (!source.IsSuccess)
            return Result<ArtifactRetentionView>.Failure(source.Error!);
        var directory = new ArtifactRetentionReader(reader, events);
        var retention = await directory.ReadAsync(source.Value, ct).ConfigureAwait(false);
        if (!retention.IsSuccess)
            return Result<ArtifactRetentionView>.Failure(retention.Error!);
        if (minimumRevision > retention.Value.Revision)
            return Result<ArtifactRetentionView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The requested retention composition revision is not yet durable.", true));
        var fence = await ArtifactRetentionSourceReader.CheckAsync(reader, source.Value, ct).ConfigureAwait(false);
        if (!fence.IsSuccess)
            return Result<ArtifactRetentionView>.Failure(fence.Error!);
        var current = await directory.ReadAsync(source.Value, ct).ConfigureAwait(false);
        if (!current.IsSuccess || current.Value.Stamp != retention.Value.Stamp)
            return Result<ArtifactRetentionView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "Retention changed during this request.", true));
        return Result<ArtifactRetentionView>.Success(retention.Value.Assess(DateOnly.FromDateTime(clock.GetUtcNow().UtcDateTime)));
    }
}
''')
put(core+'ListArtifactLegalHoldsHandler.cs','''using System.Globalization;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

sealed class ListArtifactLegalHoldsHandler(IAggregateReader reader, IDomainEventReader events)
    : IRequestHandler<ListArtifactLegalHolds, Page<ArtifactLegalHoldView>>
{
    public async ValueTask<Result<Page<ArtifactLegalHoldView>>> HandleAsync(
        IRequestContext<ListArtifactLegalHolds> context, CancellationToken ct)
    {
        var request = context.Request;
        if (request.Limit is < 1 or > 200 || request.MinimumRevision is < 1 || request.Cursor is { Length: > 256 })
            return Fail(RequestErrorKind.Validation, "The retention history paging parameters are invalid.");
        var source = await ArtifactRetentionSourceReader.LoadAsync(reader, request.TenantId,
            request.SourceKind, request.SourceId, ct).ConfigureAwait(false);
        if (!source.IsSuccess)
            return Result<Page<ArtifactLegalHoldView>>.Failure(source.Error!);
        var directory = new ArtifactRetentionReader(reader, events);
        var retention = await directory.ReadAsync(source.Value, ct).ConfigureAwait(false);
        if (!retention.IsSuccess)
            return Result<Page<ArtifactLegalHoldView>>.Failure(retention.Error!);
        if (request.MinimumRevision > retention.Value.Revision)
            return Fail(RequestErrorKind.Conflict, "The requested retention composition revision is not yet durable.", true);
        var identity = ArtifactRetentionBasis.IdentityOf(source.Value.Source);
        var prefix = $"retention_holds_v2:{identity}:{retention.Value.Stamp}:";
        var offset = 0;
        if (request.Cursor is { } cursor)
        {
            var parts = cursor.Split(':');
            if (parts.Length != 4 || parts[0] != "retention_holds_v2" || parts[1] != identity.ToString() ||
                parts[2].Length != 64 || !int.TryParse(parts[3], NumberStyles.None, CultureInfo.InvariantCulture, out offset))
                return Fail(RequestErrorKind.Validation, "The retention history cursor is invalid.");
            if (parts[2] != retention.Value.Stamp)
                return Fail(RequestErrorKind.Conflict, "The retention history cursor is stale.", true);
        }
        var holds = retention.Value.Holds;
        if (offset > holds.Count)
            return Fail(RequestErrorKind.Validation, "The retention history cursor is invalid.");
        var items = Array.AsReadOnly(holds.Skip(offset).Take(request.Limit ?? 50).ToArray());
        var next = offset + items.Length < holds.Count
            ? prefix + (offset + items.Length).ToString(CultureInfo.InvariantCulture) : null;
        var fence = await ArtifactRetentionSourceReader.CheckAsync(reader, source.Value, ct).ConfigureAwait(false);
        if (!fence.IsSuccess)
            return Result<Page<ArtifactLegalHoldView>>.Failure(fence.Error!);
        var current = await directory.ReadAsync(source.Value, ct).ConfigureAwait(false);
        if (!current.IsSuccess || current.Value.Stamp != retention.Value.Stamp)
            return Fail(RequestErrorKind.Conflict, "Retention changed during this request.", true);
        return Result<Page<ArtifactLegalHoldView>>.Success(new(items, next));
    }

    static Result<Page<ArtifactLegalHoldView>> Fail(RequestErrorKind kind, string message, bool transient = false) =>
        Result<Page<ArtifactLegalHoldView>>.Failure(new RequestError(kind, message, transient));
}
''')
edit(core+'ArtifactRetentionSourceReader.cs',lambda s:s.replace('ArtifactRetention.IsSupportedSource','ArtifactRetentionRules.IsSupportedSource'))
edit(core+'ArtifactDisposition.cs',lambda s:s.replace('ArtifactRetention.Policy','ArtifactRetentionRules.Policy'))
delete(core+'ArtifactRetention.cs')
put(tests+'ArtifactRetentionTests.cs','''using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Kernel;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Retention;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Retention;

public sealed class ArtifactRetentionTests
{
    static readonly DateTimeOffset Now = new(2026, 10, 7, 0, 0, 0, TimeSpan.Zero);
    static readonly ActorReference Admin = ActorReference.ForMember(Uuid.CreateVersion4(), "Org Admin");
    static readonly ImmutableContentRef Response = new(Uuid.CreateVersion4(), new string('a', 64), 1, "application/json", "test-response.v1");

    [Fact]
    public void ShouldRecordSevenYearsFromExplicitPeriodGivenSourceBoundImportDecision()
    {
        // Arrange
        var source = Source();
        var id = Uuid.CreateVersion4();
        var basis = new ArtifactRetentionBasis(source.Source, id);
        var operation = Operation(basis, id, "RecordArtifactRetentionBasis", 0);

        // Act
        var result = basis.Record(operation, source, new(2019, 1, 1), new(2019, 12, 31), "Verified", Response, Response);

        // Assert
        Assert.True(result.IsSuccess);
        Assert.Equal(new DateOnly(2026, 12, 31), basis.Basis!.RetainsThrough);
        Assert.Equal(Admin, basis.Basis.RecordedBy);
        Assert.Equal(source.Source, basis.Source);
        Assert.Equal(1, basis.Revision);
        Assert.Single(new AggregateScenario<ArtifactRetentionBasis>(basis).PendingEvents);
    }

    [Fact]
    public void ShouldKeepIndefiniteLegalHoldHistoryGivenAttributedPersonalRelease()
    {
        // Arrange
        var source = Source();
        var holdId = Uuid.CreateVersion4();
        var releaseId = Uuid.CreateVersion4();
        var hold = new ArtifactLegalHold(source.Source.TenantId, holdId, holdId);
        Assert.True(hold.Place(Operation(hold, holdId, "PlaceArtifactLegalHold", 0), source, "Legal matter", Response, Response).IsSuccess);
        var active = hold.View;
        var placed = Assert.IsType<ArtifactLegalHoldPlaced>(Assert.Single(new AggregateScenario<ArtifactLegalHold>(hold).PendingEvents));
        var reopened = new AggregateScenario<ArtifactLegalHold>(new(source.Source.TenantId, holdId, releaseId))
            .Given(DomainEventSeed.Attach(placed, holdId, 1)).Aggregate;

        // Act
        var released = reopened.ReleaseHold(Operation(reopened, releaseId, "ReleaseArtifactLegalHold", 1) with
            { AcceptedAt = Now.AddYears(10) }, source, "Authorized release", Response, Response);

        // Assert
        Assert.True(released.IsSuccess);
        Assert.Null(active!.ReleasedAt);
        Assert.Equal(Admin, reopened.View!.PlacedBy);
        Assert.Equal(Admin, reopened.View.ReleasedBy);
        Assert.Equal(Now.AddYears(10), reopened.View.ReleasedAt);
        Assert.Equal(2, reopened.Revision);
    }

    [Fact]
    public void ShouldRejectRegressingSourcePositionGivenAlreadyBoundAuthority()
    {
        // Arrange
        var source = Source() with { Position = 10 };
        var hold = new ArtifactLegalHold(source.Source.TenantId, Uuid.CreateVersion4());
        var operation = Operation(hold, hold.Id, "PlaceArtifactLegalHold", 0);
        // Select the operation so native replay and changed-intent decisions use the same production protocol.
        hold = new(source.Source.TenantId, hold.Id, hold.Id);
        Assert.True(hold.Place(operation, source, "Preserve", Response, Response).IsSuccess);

        // Act
        var result = hold.PrepareRelease(source with { Position = 9 }, 1, "Release", Now);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(1, hold.Revision);
    }

    [Theory]
    [InlineData("digest")]
    [InlineData("tenant")]
    [InlineData("period")]
    [InlineData("revision")]
    [InlineData("reason")]
    public void ShouldRejectChangedIntentGivenRecordedEvidenceBasis(string change)
    {
        // Arrange
        var source = Source("evidence_artifact") with { PeriodStart = new(2019, 1, 1), PeriodEnd = new(2019, 12, 31) };
        var id = Uuid.CreateVersion4();
        var basis = new ArtifactRetentionBasis(source.Source, id);
        var accepted = Operation(basis, id, "RecordArtifactRetentionBasis", 0);
        Assert.True(basis.Record(accepted, source, null, null, "Verified", Response, Response).IsSuccess);
        var changed = accepted with { AuthoredIntentSha256 = new string('b', 64) };
        var altered = change switch
        {
            "digest" => source with { Source = source.Source with { ContentSha256 = new string('b', 64) } },
            "tenant" => source with { Source = source.Source with { TenantId = Uuid.CreateVersion4() } },
            "period" => source with { PeriodEnd = source.PeriodEnd!.Value.AddDays(1) },
            _ => source,
        };
        if (change == "revision")
            changed = changed with { OriginalExpectedRevision = 1 };

        // Act
        var result = basis.Record(changed, altered, null, null, change == "reason" ? "Changed" : "Verified", Response, Response);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(1, basis.Revision);
        Assert.Equal(source.Source, basis.Source);
    }

    [Fact]
    public void ShouldRemainBlockedGivenElapsedPeriodAndReleasedHold()
    {
        // Arrange
        var source = Source();
        var basisId = Uuid.CreateVersion4();
        var basis = new ArtifactRetentionBasis(source.Source, basisId);
        Assert.True(basis.Record(Operation(basis, basisId, "RecordArtifactRetentionBasis", 0), source,
            new(2019, 1, 1), new(2019, 12, 31), "Verified", Response, Response).IsSuccess);
        var holdId = Uuid.CreateVersion4();
        var hold = new ArtifactLegalHold(source.Source.TenantId, holdId, holdId);
        var placed = Operation(hold, holdId, "PlaceArtifactLegalHold", 0);
        Assert.True(hold.Place(placed, source, "Legal matter", Response, Response).IsSuccess);
        var placement = Assert.IsType<ArtifactLegalHoldPlaced>(Assert.Single(new AggregateScenario<ArtifactLegalHold>(hold).PendingEvents));
        var releaseId = Uuid.CreateVersion4();
        var current = new AggregateScenario<ArtifactLegalHold>(new(source.Source.TenantId, holdId, releaseId))
            .Given(DomainEventSeed.Attach(placement, holdId, 1)).Aggregate;
        Assert.True(current.ReleaseHold(Operation(current, releaseId, "ReleaseArtifactLegalHold", 1), source,
            "Matter closed", Response, Response).IsSuccess);
        var snapshot = new ArtifactRetentionSnapshot(source.Source, basis.Basis, [current.View!], 3, "stable");

        // Act
        var anniversary = snapshot.Assess(new(2026, 12, 31));
        var elapsed = snapshot.Assess(new(2027, 1, 1));

        // Assert
        Assert.False(anniversary.RetentionElapsed);
        Assert.True(elapsed.RetentionElapsed);
        Assert.False(elapsed.DispositionAllowed);
        Assert.Equal(0, elapsed.ActiveLegalHoldCount);
        Assert.Equal(1, elapsed.LegalHoldHistoryCount);
        Assert.Contains("engagement_hold_authority_unavailable", elapsed.Blockers);
        Assert.Contains("historical_reliance_unavailable", elapsed.Blockers);
        Assert.Contains("inline_disposition_unsupported", elapsed.Blockers);
    }

    [Fact]
    public void ShouldRequireExplicitSupportedPeriodGivenRawImportRows()
    {
        // Arrange
        var source = Source();
        var id = Uuid.CreateVersion4();
        var basis = new ArtifactRetentionBasis(source.Source, id);

        // Act
        var result = basis.Record(Operation(basis, id, "RecordArtifactRetentionBasis", 0), source,
            null, null, "Submitted today", Response, Response);

        // Assert
        Assert.False(result.IsSuccess);
        Assert.Equal(0, basis.Revision);
        Assert.Empty(new AggregateScenario<ArtifactRetentionBasis>(basis).PendingEvents);
    }

    [Theory]
    [InlineData("basis")]
    [InlineData("place")]
    [InlineData("release")]
    public void ShouldRejectChangedActorGivenAttributedHistoricalDecisionRetry(string kind)
    {
        // Arrange
        var source = Source();
        var id = Uuid.CreateVersion4();
        var basis = new ArtifactRetentionBasis(source.Source, id);
        var hold = new ArtifactLegalHold(source.Source.TenantId, id, id);
        var command = kind == "basis" ? "RecordArtifactRetentionBasis" : "PlaceArtifactLegalHold";
        Aggregate owner = kind == "basis" ? basis : hold;
        var operation = Operation(owner, id, command, 0);
        Assert.True(kind == "basis"
            ? basis.Record(operation, source, new(2019, 1, 1), new(2019, 12, 31), "Verified", Response, Response).IsSuccess
            : hold.Place(operation, source, "Preserve", Response, Response).IsSuccess);
        if (kind == "release")
        {
            var placed = Assert.IsType<ArtifactLegalHoldPlaced>(Assert.Single(new AggregateScenario<ArtifactLegalHold>(hold).PendingEvents));
            id = Uuid.CreateVersion4();
            hold = new AggregateScenario<ArtifactLegalHold>(new(source.Source.TenantId, hold.Id, id))
                .Given(DomainEventSeed.Attach(placed, hold.Id, 1)).Aggregate;
            operation = Operation(hold, id, "ReleaseArtifactLegalHold", 1);
            Assert.True(hold.ReleaseHold(operation, source, "Released", Response, Response).IsSuccess);
        }
        var changed = operation with { Actor = ActorReference.ForMember(Uuid.CreateVersion4(), "Other admin") };

        // Act
        var result = kind switch
        {
            "basis" => basis.Record(changed, source, new(2019, 1, 1), new(2019, 12, 31), "Verified", Response, Response),
            "place" => hold.Place(changed, source, "Preserve", Response, Response),
            _ => hold.ReleaseHold(changed, source, "Released", Response, Response),
        };

        // Assert
        Assert.False(result.IsSuccess);
    }

    [Fact]
    public void ShouldUseDifferentBasisOwnersGivenDifferentExactContent()
    {
        // Arrange
        var source = Source();

        // Act
        var original = ArtifactRetentionBasis.IdentityOf(source.Source);
        var changed = ArtifactRetentionBasis.IdentityOf(source.Source with { ContentSha256 = new string('b', 64) });

        // Assert
        Assert.NotEqual(original, changed);
    }

    static ArtifactRetentionSourceSnapshot Source(string kind = "application_import") =>
        new(new(Uuid.CreateVersion4(), kind, Uuid.CreateVersion4(), new string('a', 64)), 1);

    static OperationProvenance Operation(Aggregate owner, Uuid id, string kind, ulong revision) =>
        new(id, id, null, kind, Admin, owner.Stream, "initial", revision,
            ContentDigest.Sha256(System.Text.Encoding.UTF8.GetBytes(kind)), Now, owner.Stream, owner.Stream);
}
''')
# Adapt the existing proof-only Type I consumer to independent owners without weakening its point-in-time view.
p='src/Compliance.Core/Features/Examinations/EvidenceGovernanceTypeIBaselineSourceContributor.cs'
def baseline(s):
 start=s.index('        var retention = await aggregates.HydrateAsync(new ArtifactRetention(',s.index('ReadRetentionAsOfAsync(Uuid'))
 end=s.index('        if (retention.Source is { } source',start)
 s=s[:start]+'''        var loaded = await ArtifactRetentionSourceReader.LoadAsync(aggregates, tenantId,
            "evidence_artifact", artifactId, ct).ConfigureAwait(false);
        if (!loaded.IsSuccess)
            return Result<RetentionAsOf>.Failure(loaded.Error!);
        var read = await new ArtifactRetentionReader(aggregates, events).ReadAsync(loaded.Value, ct).ConfigureAwait(false);
        if (!read.IsSuccess)
            return Result<RetentionAsOf>.Failure(read.Error!);
        var retention = read.Value;
'''+s[end:]
 return s.replace('retention.GetLegalHolds()', 'retention.Holds')
edit(p,baseline)
# Preserve the current generated-export retention policy on the new owner, without claiming the S35 export process is done.
p='src/Compliance.Core/Features/AuditPopulations/GenerateAuditPopulationExportHandler.cs'
def export(s):
 s=s.replace('using Bdgrz.Compliance.Features.Retention;','using Bdgrz.Compliance.Features.Retention;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;')
 s=s.replace('IAggregateReader reader, EvidenceIntake evidenceIntake, TimeProvider clock)',
             'IAggregateReader reader, EvidenceIntake evidenceIntake, TimeProvider clock,\n    NativeOperationExecutor operations, IImmutableContentStore content)')
 start=s.index('        var recorded = await executor.ExecuteAsync(new ArtifactRetention(')
 end=s.index('        if (current.Basis is not { } basis',start)
 s=s[:start]+'''        var commandId = Uuid.CreateVersion5(artifact.Id, "generated-export-retention-basis:v1");
        var request = new RecordArtifactRetentionBasis(commandId, registration.TenantId, "evidence_artifact",
            artifact.Id, source.Value.Source.ContentSha256, 0, RetentionReason, periodStart, periodEnd);
        var recorded = await new ArtifactRetentionMutation(operations, reader, content, clock)
            .RecordBasisAsync(context, request, registration.Collector, ct).ConfigureAwait(false);
        if (!recorded.IsSuccess)
            return recorded;
        var current = await reader.HydrateAsync(new ArtifactRetentionBasis(source.Value.Source), ct).ConfigureAwait(false);
'''+s[end:]
 return s
edit(p,export)
# The existing focused handler tests retain all previous authority/transport/source/race scenarios.
import re
p=tests+'ArtifactRetentionHandlerTests.cs'
def handler_tests(s):
 s=s.replace('using System.Security.Claims;','using System.Security.Claims;\nusing Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.NativeOperations;\nusing Bdgrz.Compliance.Features.Proofs;')
 for name in ['RecordArtifactRetentionBasis','ReleaseArtifactLegalHold']:
  s=s.replace('new '+name+'(', 'new '+name+'(Uuid.CreateVersion4(), ')
  s=re.sub(r'(RequestContext<'+name+r'>\(\s*new\()',r'\1Uuid.CreateVersion4(), ',s)
 s=s.replace('new ArtifactRetention(fixture.Tenant, "evidence_artifact", id)',
             'new ArtifactRetentionBasis(new(fixture.Tenant, "evidence_artifact", id, Fixture.Sha))')
 s=s.replace('fixture.Tenant, "evidence_artifact", id, 2, CancellationToken.None','fixture.Tenant, "evidence_artifact", id, 1, CancellationToken.None')
 s=s.replace('fixture.Tenant, "application_import", batch, 2, CancellationToken.None','fixture.Tenant, "application_import", batch, 1, CancellationToken.None')
 s=s.replace('Assert.Equal(2UL, aggregate.CommittedStreamPosition);','Assert.Equal(1UL, aggregate.CommittedStreamPosition);')
 s=s.replace('holds[index], index == 0 ? 0 : index + 1,','holds[index], 0,')
 s=s.replace('holds[0], 4, "Matter closed"','holds[0], 1, "Matter closed"')
 s=s.replace('hold, 2, "Release"','hold, 1, "Release"')
 s=s.replace('new ListArtifactLegalHoldsHandler(fixture.Reader)','new ListArtifactLegalHoldsHandler(fixture.Reader, fixture.Events)')
 s=s.replace('new ListArtifactLegalHoldsHandler(reader)','new ListArtifactLegalHoldsHandler(reader, fixture.Events)')
 s=s.replace('new ArtifactRetentionRead(reader, TimeProvider.System)','new ArtifactRetentionRead(reader, fixture.Events, TimeProvider.System)')
 s=s.replace('aggregate is ArtifactRetention)', 'aggregate is ArtifactRetentionBasis)')
 s=s.replace('ShouldCommitOneDecisionGivenCompetingExpectedRetentionRevision','ShouldCommitIndependentHoldsGivenSameOwnerLocalRevision')
 start=s.index('        var retention = await fixture.Reader.HydrateAsync(new ArtifactRetentionBasis(',s.index('ShouldCommitIndependentHoldsGivenSameOwnerLocalRevision'))
 end=s.index('    [Theory]',start)
 s=s[:start]+'''        var source = await ArtifactRetentionSourceReader.LoadAsync(fixture.Reader, fixture.Tenant,
            "evidence_artifact", id, CancellationToken.None);
        var retention = await new ArtifactRetentionReader(fixture.Reader, fixture.Events).ReadAsync(source.Value);

        // Assert
        Assert.All(results, result => Assert.True(result.IsSuccess, result.Error?.Message));
        Assert.Equal(2, retention.Value.Holds.Count);
        Assert.Equal(2, retention.Value.Revision);
    }

'''+s[end:]
 start=s.index('    sealed class ReusingPolicyReader(')
 end=s.index('    [Theory]',start)
 s=s[:start]+'''    sealed class ReusingPolicyReader(IAggregateReader inner) : IAggregateReader
    {
        ArtifactRetentionBasis? _shared;
        public async ValueTask<T> HydrateAsync<T>(T aggregate, CancellationToken ct = default) where T : Aggregate
        {
            if (aggregate is not ArtifactRetentionBasis basis)
                return await inner.HydrateAsync(aggregate, ct);
            if (_shared is null)
                _shared = basis;
            else if (_shared.Basis is null)
            {
                var actor = ActorReference.ForMember(Uuid.CreateVersion4(), "Org Admin");
                var id = Uuid.CreateVersion4();
                var now = DateTimeOffset.UtcNow;
                var operation = new OperationProvenance(id, id, null, "RecordArtifactRetentionBasis", actor,
                    _shared.Stream, "initial", 0, new string('a', 64), now, _shared.Stream, _shared.Stream);
                var response = new ImmutableContentRef(id, new string('a', 64), 1, "application/json", "test.v1");
                new AggregateScenario<ArtifactRetentionBasis>(_shared).Given(DomainEventSeed.Attach(
                    new ArtifactRetentionBasisRecorded(_shared.Source, 1, 1, ArtifactRetentionRules.Policy,
                        new(2019, 1, 1), new(2019, 12, 31), new(2026, 12, 31), "source_period", "Verified", actor,
                        now, operation, response, response), _shared.Id, 1));
            }
            return (T)(Aggregate)_shared;
        }
    }

'''+s[end:]
 # Query composition revisions are no longer the admission revision of each individual owner.
 s=s.replace('var retained = await fixture.Reader.HydrateAsync(new ArtifactRetentionBasis(new(fixture.Tenant, "evidence_artifact", id, Fixture.Sha)));',
 '''var source = await ArtifactRetentionSourceReader.LoadAsync(fixture.Reader, fixture.Tenant, "evidence_artifact", id, CancellationToken.None);
        var retained = await new ArtifactRetentionReader(fixture.Reader, fixture.Events).ReadAsync(source.Value);''')
 s=s.replace('Assert.Equal(allowed ? operation == "release" ? 3 : 2 : operation == "release" ? 2 : 0, retained.Revision);',
             'Assert.Equal(allowed ? operation == "release" ? 2 : 1 : operation == "release" ? 1 : 0, retained.Value.Revision);')
 s=s.replace('        public IAggregateExecutor Executor { get; }','        public IAggregateExecutor Executor { get; }\n        public IDomainEventReader Events { get; }')
 s=s.replace('services.AddSingleton<IEventStore>(new InMemoryEventStore());',
             'var events = new InMemoryEventStore();\n            services.AddSingleton<IEventStore>(events);\n            services.AddSingleton<IDomainEventReader>(events);')
 s=s.replace('Executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();',
             'Executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();\n            Events = _scope.ServiceProvider.GetRequiredService<IDomainEventReader>();')
 s=s.replace('Mutation = new(Executor, Reader, TimeProvider.System);','Mutation = new(new NativeOperationExecutor(Reader, Executor, Content), Reader, Content, TimeProvider.System);')
 s=s.replace('Read = new(Reader, TimeProvider.System);','Read = new(Reader, Events, TimeProvider.System);')
 return s
edit(p,handler_tests)
p=tests+'AttestRetentionManagementWriteWallTests.cs'
def wall(s):
 for name in ['RecordArtifactRetentionBasis','ReleaseArtifactLegalHold']:
  s=s.replace('new '+name+'(', 'new '+name+'(Uuid.CreateVersion4(), ')
 s=s.replace('new ArtifactRetention(Tenant, "evidence_artifact", id)', 'new ArtifactRetentionBasis(new(Tenant, "evidence_artifact", id, Sha))')
 s=s.replace('Sha, hold, before.Revision,','Sha, hold, 1,')
 s=s.replace('Assert.Equal(2, retained.Revision);','Assert.Equal(1, retained.Revision);')
 return s
edit(p,wall)
p='test/Compliance.Tests/Features/AuditPopulations/GenerateAuditPopulationExportHandlerTests.cs'
def export_tests(s):
 s=s.replace('new EvidenceIntake(_store, _inspector, Reader, Writer, _clock), _clock);',
 '''new EvidenceIntake(_store, _inspector, Reader, Writer, _clock), _clock,
            new Bdgrz.Compliance.Features.NativeOperations.NativeOperationExecutor(Reader, Executor, _content), _content);''')
 s=s.replace('        readonly Inspector _inspector;', '''        readonly Inspector _inspector;
        readonly Bdgrz.Compliance.Features.Content.IImmutableContentStore _content =
            new Bdgrz.Compliance.Features.Content.FitzKvImmutableContentStore(new Cntryl.Fitz.Testing.InMemoryKvClient());''')
 s=s.replace('''        public Task<ArtifactRetention> RetentionAsync(Uuid artifactId) =>
            Reader.HydrateAsync(new ArtifactRetention(TenantId, "evidence_artifact", artifactId)).AsTask();''',
 '''        public async Task<ArtifactRetentionBasis> RetentionAsync(Uuid artifactId)
        {
            var artifact = await Reader.HydrateAsync(new EvidenceArtifact(TenantId, artifactId));
            return await Reader.HydrateAsync(new ArtifactRetentionBasis(new(TenantId, "evidence_artifact",
                artifactId, artifact.ContentSha256!)));
        }''')
 return s
edit(p,export_tests)
# ReadOnlyCollection exposes Count rather than Length.
edit(core+'ListArtifactLegalHoldsHandler.cs',lambda s:s.replace('items.Length','items.Count'))
put(tests+'ArtifactRetentionNativeOperationTests.cs','''using System.Security.Claims;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Retention;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Retention;

public sealed class ArtifactRetentionNativeOperationTests
{
    [Fact]
    public async Task ShouldReturnOriginalResultGivenPlacementRetryAfterRelease()
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        var request = fixture.Place(source);
        var handler = new PlaceArtifactLegalHoldHandler(fixture.Mutation());
        Assert.True((await handler.HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var release = fixture.Release(source, request.HoldId);
        Assert.True((await new ReleaseArtifactLegalHoldHandler(fixture.Mutation())
            .HandleAsync(fixture.Context(release), CancellationToken.None)).IsSuccess);
        var noSource = new NoSourceReader(fixture.Reader);
        var retry = new PlaceArtifactLegalHoldHandler(fixture.Mutation(noSource));

        // Act
        var result = await retry.HandleAsync(fixture.Context(request), CancellationToken.None);
        var held = await fixture.Reader.HydrateAsync(new ArtifactLegalHold(fixture.Tenant, request.HoldId));

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(2, held.Revision);
        Assert.Equal(2UL, held.CommittedStreamPosition);
        Assert.NotNull(held.View!.ReleasedAt);
    }

    [Fact]
    public async Task ShouldReturnOriginalResultWithoutReselectingSourceGivenBasisRetry()
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        var request = fixture.Basis(source);
        Assert.True((await new RecordArtifactRetentionBasisHandler(fixture.Mutation())
            .HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);
        var noSource = new NoSourceReader(fixture.Reader);

        // Act
        var result = await new RecordArtifactRetentionBasisHandler(fixture.Mutation(noSource))
            .HandleAsync(fixture.Context(request), CancellationToken.None);
        var basis = await fixture.Reader.HydrateAsync(new ArtifactRetentionBasis(source));

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        Assert.Equal(1UL, basis.CommittedStreamPosition);
    }

    [Theory]
    [InlineData("basis")]
    [InlineData("place")]
    [InlineData("release")]
    public async Task ShouldConflictGivenSameIdentityWithChangedActorIntentOrOriginalRevision(string operation)
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        var basis = fixture.Basis(source);
        var place = fixture.Place(source);
        var release = fixture.Release(source, place.HoldId);
        if (operation != "basis")
            Assert.True((await new PlaceArtifactLegalHoldHandler(fixture.Mutation())
                .HandleAsync(fixture.Context(place), CancellationToken.None)).IsSuccess);
        if (operation == "basis")
            Assert.True((await new RecordArtifactRetentionBasisHandler(fixture.Mutation())
                .HandleAsync(fixture.Context(basis), CancellationToken.None)).IsSuccess);
        if (operation == "release")
            Assert.True((await new ReleaseArtifactLegalHoldHandler(fixture.Mutation())
                .HandleAsync(fixture.Context(release), CancellationToken.None)).IsSuccess);

        // Act
        var results = new List<Result>();
        foreach (var change in new[] { "actor", "reason", "revision", "content", "source" })
        {
            var actor = change == "actor" ? Fixture.Actor(Uuid.CreateVersion4()) : fixture.User;
            results.Add(operation switch
            {
                "basis" => await new RecordArtifactRetentionBasisHandler(fixture.Mutation()).HandleAsync(
                    fixture.Context(basis with
                    {
                        Reason = change == "reason" ? "Changed" : basis.Reason,
                        ExpectedRevision = change == "revision" ? 1 : basis.ExpectedRevision,
                        // A different content digest determines another first owner for a basis; that cross-owner
                        // reuse remains #1042's prerequisite. Exercise authored period/source fields on this owner.
                        PeriodStart = change == "content" ? new DateOnly(2020, 1, 1) : basis.PeriodStart,
                        PeriodEnd = change == "source" ? new DateOnly(2020, 12, 31) : basis.PeriodEnd,
                    }, actor), CancellationToken.None),
                "place" => await new PlaceArtifactLegalHoldHandler(fixture.Mutation()).HandleAsync(
                    fixture.Context(place with
                    {
                        Reason = change == "reason" ? "Changed" : place.Reason,
                        ExpectedRevision = change == "revision" ? 1 : place.ExpectedRevision,
                        ExpectedContentSha256 = change == "content" ? new string('b', 64) : place.ExpectedContentSha256,
                        SourceId = change == "source" ? Uuid.CreateVersion4() : place.SourceId,
                    }, actor), CancellationToken.None),
                _ => await new ReleaseArtifactLegalHoldHandler(fixture.Mutation()).HandleAsync(
                    fixture.Context(release with
                    {
                        Reason = change == "reason" ? "Changed" : release.Reason,
                        ExpectedRevision = change == "revision" ? 2 : release.ExpectedRevision,
                        ExpectedContentSha256 = change == "content" ? new string('b', 64) : release.ExpectedContentSha256,
                        SourceId = change == "source" ? Uuid.CreateVersion4() : release.SourceId,
                    }, actor), CancellationToken.None),
            });
        }

        // Assert
        Assert.All(results, result => Assert.Equal(RequestErrorKind.Conflict, result.Error?.Kind));
        if (operation == "basis")
            Assert.Equal(1UL, (await fixture.Reader.HydrateAsync(new ArtifactRetentionBasis(source))).CommittedStreamPosition);
        else
            Assert.Equal(operation == "release" ? 2UL : 1UL,
                (await fixture.Reader.HydrateAsync(new ArtifactLegalHold(fixture.Tenant, place.HoldId))).CommittedStreamPosition);
    }

    [Theory]
    [InlineData("basis")]
    [InlineData("place")]
    [InlineData("release")]
    public async Task ShouldRejectWithoutAppendGivenMissingCommandIdentity(string operation)
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        var holdId = Uuid.CreateVersion4();

        // Act
        var result = operation switch
        {
            "basis" => await new RecordArtifactRetentionBasisHandler(fixture.Mutation()).HandleAsync(
                fixture.Context(fixture.Basis(source) with { CommandId = Uuid.Empty }), CancellationToken.None),
            "place" => await new PlaceArtifactLegalHoldHandler(fixture.Mutation()).HandleAsync(
                fixture.Context(fixture.Place(source) with { HoldId = Uuid.Empty }), CancellationToken.None),
            _ => await new ReleaseArtifactLegalHoldHandler(fixture.Mutation()).HandleAsync(
                fixture.Context(fixture.Release(source, holdId) with { CommandId = Uuid.Empty }), CancellationToken.None),
        };

        // Assert
        Assert.Equal(RequestErrorKind.Validation, result.Error?.Kind);
        Assert.Equal(0UL, (await fixture.Reader.HydrateAsync(new ArtifactRetentionBasis(source))).CommittedStreamPosition);
        Assert.Equal(0UL, (await fixture.Reader.HydrateAsync(new ArtifactLegalHold(fixture.Tenant, holdId))).CommittedStreamPosition);
    }

    [Theory]
    [InlineData("basis")]
    [InlineData("place")]
    [InlineData("release")]
    public async Task ShouldRecoverWithoutDuplicateAppendGivenUnknownAppendOutcome(string operation)
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        var place = fixture.Place(source);
        if (operation == "release")
            Assert.True((await new PlaceArtifactLegalHoldHandler(fixture.Mutation())
                .HandleAsync(fixture.Context(place), CancellationToken.None)).IsSuccess);
        var mutation = fixture.Mutation(executor: new CommitThenFailOnceExecutor(fixture.Executor));

        // Act
        var result = operation switch
        {
            "basis" => await new RecordArtifactRetentionBasisHandler(mutation).HandleAsync(
                fixture.Context(fixture.Basis(source)), CancellationToken.None),
            "place" => await new PlaceArtifactLegalHoldHandler(mutation).HandleAsync(fixture.Context(place), CancellationToken.None),
            _ => await new ReleaseArtifactLegalHoldHandler(mutation).HandleAsync(
                fixture.Context(fixture.Release(source, place.HoldId)), CancellationToken.None),
        };

        // Assert
        Assert.True(result.IsSuccess, result.Error?.Message);
        if (operation == "basis")
            Assert.Equal(1UL, (await fixture.Reader.HydrateAsync(new ArtifactRetentionBasis(source))).CommittedStreamPosition);
        else
            Assert.Equal(operation == "release" ? 2UL : 1UL,
                (await fixture.Reader.HydrateAsync(new ArtifactLegalHold(fixture.Tenant, place.HoldId))).CommittedStreamPosition);
    }

    [Fact]
    public async Task ShouldCommitOneCreationGivenEqualConcurrentHoldIdentity()
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        var request = fixture.Place(source);
        var handler = new PlaceArtifactLegalHoldHandler(fixture.Mutation());

        // Act
        var results = await Task.WhenAll(handler.HandleAsync(fixture.Context(request), CancellationToken.None).AsTask(),
            handler.HandleAsync(fixture.Context(request), CancellationToken.None).AsTask());
        var hold = await fixture.Reader.HydrateAsync(new ArtifactLegalHold(fixture.Tenant, request.HoldId));

        // Assert
        Assert.All(results, result => Assert.True(result.IsSuccess, result.Error?.Message));
        Assert.Equal(1UL, hold.CommittedStreamPosition);
    }

    [Fact]
    public async Task ShouldKeepEveryIndependentHoldGivenMoreThanSixtyFourPlacements()
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        var handler = new PlaceArtifactLegalHoldHandler(fixture.Mutation());
        for (var index = 0; index < 70; index++)
            Assert.True((await handler.HandleAsync(fixture.Context(fixture.Place(source)), CancellationToken.None)).IsSuccess);
        var captured = await ArtifactRetentionSourceReader.LoadAsync(fixture.Reader, fixture.Tenant,
            source.SourceKind, source.SourceId, CancellationToken.None);

        // Act
        var snapshot = await new ArtifactRetentionReader(fixture.Reader, fixture.Events).ReadAsync(captured.Value);

        // Assert
        Assert.True(snapshot.IsSuccess, snapshot.Error?.Message);
        Assert.Equal(70, snapshot.Value.Holds.Count);
        Assert.Equal(70, snapshot.Value.Assess(new DateOnly(2050, 1, 1)).ActiveLegalHoldCount);
        Assert.False(snapshot.Value.Assess(new DateOnly(2050, 1, 1)).DispositionAllowed);
    }

    sealed class NoSourceReader(IAggregateReader inner) : IAggregateReader
    {
        public ValueTask<T> HydrateAsync<T>(T aggregate, CancellationToken ct = default) where T : Aggregate =>
            aggregate is EvidenceArtifact ? throw new InvalidOperationException("An accepted retry must not reselect source state.")
                : inner.HydrateAsync(aggregate, ct);
    }

    sealed class CommitThenFailOnceExecutor(IAggregateExecutor inner) : IAggregateExecutor
    {
        int _calls;
        public ValueTask<Result> ExecuteAsync<T>(T aggregate, Func<T, AggregateOutcome> operation,
            IExecutionContext context, CancellationToken ct) where T : Aggregate => inner.ExecuteAsync(aggregate, operation, context, ct);
        public async ValueTask<Result<TResult>> ExecuteAsync<T, TResult>(T aggregate,
            Func<T, AggregateOutcome<TResult>> operation, IExecutionContext context, CancellationToken ct) where T : Aggregate
        {
            var result = await inner.ExecuteAsync(aggregate, operation, context, ct);
            if (Interlocked.Increment(ref _calls) == 1)
                throw new EventStreamConcurrencyException("Native append outcome unknown.", new TimeoutException());
            return result;
        }
    }

    sealed class Fixture : IAsyncDisposable
    {
        readonly ServiceProvider _provider;
        readonly AsyncServiceScope _scope;
        readonly IAggregateWriter _writer;
        readonly IImmutableContentStore _content = new FitzKvImmutableContentStore(new InMemoryKvClient());
        public Uuid Tenant { get; } = Uuid.CreateVersion4();
        public ClaimsPrincipal User { get; } = Actor(Uuid.CreateVersion4());
        public IAggregateReader Reader { get; }
        public IAggregateExecutor Executor { get; }
        public IDomainEventReader Events { get; }

        public Fixture()
        {
            var services = new ServiceCollection();
            var events = new InMemoryEventStore();
            services.AddSingleton<IEventStore>(events);
            services.AddSingleton<IDomainEventReader>(events);
            services.AddPortia();
            _provider = services.BuildServiceProvider();
            _scope = _provider.CreateAsyncScope();
            Reader = _scope.ServiceProvider.GetRequiredService<IAggregateReader>();
            Executor = _scope.ServiceProvider.GetRequiredService<IAggregateExecutor>();
            Events = events;
            _writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
        }
        public ArtifactRetentionMutation Mutation(IAggregateReader? reader = null, IAggregateExecutor? executor = null) =>
            new(new NativeOperationExecutor(reader ?? Reader, executor ?? Executor, _content), reader ?? Reader, _content, TimeProvider.System);
        public static ClaimsPrincipal Actor(Uuid id) => new(new ClaimsIdentity(
            [new Claim("iss", "bdgrz"), new Claim("sub", id.ToString())], "BdgrzSession"));
        public IRequestContext<T> Context<T>(T request, ClaimsPrincipal? actor = null) where T : IRequestBase =>
            new Cntryl.Portia.RequestContext<T>(request, new RequestDispatchContext(actor ?? User,
                new HttpInvocation("PUT", "/synthetic/retention", null, "retention-native-test")));
        public RecordArtifactRetentionBasis Basis(ArtifactRetentionSource source) =>
            new(Uuid.CreateVersion4(), Tenant, source.SourceKind, source.SourceId, source.ContentSha256, 0, "Native period verified");
        public PlaceArtifactLegalHold Place(ArtifactRetentionSource source) =>
            new(Tenant, source.SourceKind, source.SourceId, source.ContentSha256, Uuid.CreateVersion4(), 0, "Legal matter");
        public ReleaseArtifactLegalHold Release(ArtifactRetentionSource source, Uuid hold) =>
            new(Uuid.CreateVersion4(), Tenant, source.SourceKind, source.SourceId, source.ContentSha256, hold, 1, "Matter closed");
        public async Task<ArtifactRetentionSource> EvidenceAsync()
        {
            var id = Uuid.CreateVersion4();
            var sha = new string('a', 64);
            var artifact = new EvidenceArtifact(Tenant, id);
            Assert.True(artifact.Register(new("Evidence", null, "export", "manual", DateTimeOffset.UtcNow,
                    new(2019, 1, 1), new(2019, 12, 31), "confidential"), sha, 100,
                ActorReference.ForMember(Uuid.CreateVersion4(), "Collector"), DateTimeOffset.UtcNow).IsSuccess);
            await _writer.SaveAsync(artifact, Context(new GetArtifactRetention(Tenant, "evidence_artifact", id)));
            return new(Tenant, "evidence_artifact", id, sha);
        }
        public async ValueTask DisposeAsync()
        {
            await _scope.DisposeAsync();
            await _provider.DisposeAsync();
        }
    }
}
''')
# Generate separate tests-first and implementation patches, preserving a complete before/after manifest.
manifest=[];patches={'tests':[],'implementation':[]}
for path,old in sorted(changed.items()):
 after=AFTER/path
 new=after.read_text() if after.exists() else None
 if old==new:continue
 kind='tests' if path.startswith('test/') else 'implementation'
 patch='diff --git a/'+path+' b/'+path+'\n'
 if old is None:patch+='new file mode 100644\n'
 if new is None:patch+='deleted file mode 100644\n'
 patch+=''.join(difflib.unified_diff((old or '').splitlines(keepends=True),(new or '').splitlines(keepends=True),
   fromfile='/dev/null' if old is None else 'a/'+path,tofile='/dev/null' if new is None else 'b/'+path))
 patches[kind].append(patch)
 manifest.append({'path':path,'patch':kind+'.patch','action':'add' if old is None else 'delete' if new is None else 'modify',
   'beforeSha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,
   'afterSha256':hashlib.sha256(new.encode()).hexdigest() if new is not None else None})
for name,parts in patches.items():(OUT/(name+'.patch')).write_text(''.join(parts))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'newfiles':[m['path'] for m in manifest if m['action']=='add'],
                 'testsPatchBytes':(OUT/'tests.patch').stat().st_size,'implementationPatchBytes':(OUT/'implementation.patch').stat().st_size},indent=2))
# A legacy combined stream cannot count as an empty set of holds after the cutover.
put(core+'ArtifactRetentionLegacyGuard.cs','''using Cntryl.Portia;

namespace Bdgrz.Compliance.Features.Retention;

/// <summary>Fails closed when a source still has combined-owner history for which no migration is selected.</summary>
static class ArtifactRetentionLegacyGuard
{
    public static async ValueTask<Result> RequireNoLegacyAsync(IDomainEventReader events, ArtifactRetentionSource source,
        CancellationToken ct)
    {
        var id = Uuid.CreateVersion5(source.TenantId, $"artifact_retention:{source.SourceKind}:{source.SourceId}");
        await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(source.TenantId.ToString(),
                           "artifact_retention"), EventCursor.Start, ct).ConfigureAwait(false))
            if (!record.Event.Metadata.IsAudit && record.Stream.Resource == id.ToString() &&
                record.Event is ArtifactRetentionBound or ArtifactRetentionBasisRecorded or ArtifactLegalHoldPlaced or ArtifactLegalHoldReleased)
                return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                    "This source has combined retention history; its verified owner migration is required before retention decisions or reads.", true));
        return Result.Success;
    }
}
''')
def reader_fences(s):
 s=s.replace('''        var first = await ReadOnceAsync(source, ct).ConfigureAwait(false);''','''        var legacy = await ArtifactRetentionLegacyGuard.RequireNoLegacyAsync(events, source.Source, ct).ConfigureAwait(false);
        if (!legacy.IsSuccess)
            return Result<ArtifactRetentionSnapshot>.Failure(legacy.Error!);
        var first = await ReadOnceAsync(source, ct).ConfigureAwait(false);''')
 start=s.index('        var basis = await aggregates.HydrateAsync')
 middle=s.index('        var ids = new HashSet<Uuid>();',start)
 end=s.index('        var holds = new List<ArtifactLegalHoldView>();',middle)
 basis=s[start:middle];discovery=s[middle:end]
 s=s[:start]+discovery+basis+s[end:]
 s=s.replace('''            basis.Stream.ToString(), basisPosition.ToString''','''            source.Position.ToString(CultureInfo.InvariantCulture), basis.Stream.ToString(), basisPosition.ToString''')
 return s
edit(core+'ArtifactRetentionReader.cs',reader_fences)
edit(core+'ArtifactRetentionMutation.cs',lambda s:s.replace('IImmutableContentStore content, TimeProvider clock)',
 'IImmutableContentStore content, TimeProvider clock, IDomainEventReader events)').replace('''                var source = await ArtifactRetentionSourceReader.LoadAsync''','''                var legacy = await ArtifactRetentionLegacyGuard.RequireNoLegacyAsync(events, identity, token).ConfigureAwait(false);
                if (!legacy.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(legacy.Error!);
                var source = await ArtifactRetentionSourceReader.LoadAsync'''))
edit('src/Compliance.Core/Features/AuditPopulations/GenerateAuditPopulationExportHandler.cs',lambda s:s.replace(
 'NativeOperationExecutor operations, IImmutableContentStore content)',
 'NativeOperationExecutor operations, IImmutableContentStore content, IDomainEventReader events)').replace(
 'new ArtifactRetentionMutation(operations, reader, content, clock)',
 'new ArtifactRetentionMutation(operations, reader, content, clock, events)'))
edit(tests+'ArtifactRetentionHandlerTests.cs',lambda s:s.replace(
 'new NativeOperationExecutor(Reader, Executor, Content), Reader, Content, TimeProvider.System);',
 'new NativeOperationExecutor(Reader, Executor, Content), Reader, Content, TimeProvider.System, Events);'))
edit('test/Compliance.Tests/Features/AuditPopulations/GenerateAuditPopulationExportHandlerTests.cs',lambda s:s.replace(
 'services.AddSingleton<IEventStore>(new InMemoryEventStore());',
 'var events = new InMemoryEventStore();\n            services.AddSingleton<IEventStore>(events);\n            services.AddSingleton<IDomainEventReader>(events);').replace(
 'Executor, _content), _content);','Executor, _content), _content, _scope.ServiceProvider.GetRequiredService<IDomainEventReader>());'))
def native_more(s):
 s=s.replace('reader ?? Reader, _content, TimeProvider.System);','reader ?? Reader, _content, TimeProvider.System, Events);')
 pos=s.index('    sealed class NoSourceReader(')
 s=s[:pos]+'''    [Fact]
    public async Task ShouldFailClosedGivenUnmigratedCombinedRetentionHistory()
    {
        // Arrange
        await using var fixture = new Fixture();
        var source = await fixture.EvidenceAsync();
        await fixture.SeedLegacyAsync(source);

        // Act
        var read = await new ArtifactRetentionRead(fixture.Reader, fixture.Events, TimeProvider.System)
            .GetAsync(fixture.Tenant, source.SourceKind, source.SourceId, null, CancellationToken.None);
        var write = await new PlaceArtifactLegalHoldHandler(fixture.Mutation())
            .HandleAsync(fixture.Context(fixture.Place(source)), CancellationToken.None);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, read.Error?.Kind);
        Assert.Contains("migration", read.Error!.Message, StringComparison.Ordinal);
        Assert.Equal(RequestErrorKind.Conflict, write.Error?.Kind);
    }

    sealed class LegacyRetentionSeed : Aggregate
    {
        public LegacyRetentionSeed(ArtifactRetentionSource source)
            : base(Uuid.CreateVersion5(source.TenantId, $"artifact_retention:{source.SourceKind}:{source.SourceId}"),
                new EventStreamAddress(source.TenantId.ToString(), "artifact_retention",
                    Uuid.CreateVersion5(source.TenantId, $"artifact_retention:{source.SourceKind}:{source.SourceId}").ToString()))
        {
            On<ArtifactRetentionBound>(_ => { });
            var actor = ActorReference.ForMember(Uuid.CreateVersion4(), "Historical administrator");
            var id = Uuid.CreateVersion4();
            var at = DateTimeOffset.UtcNow;
            var operation = new OperationProvenance(id, id, null, "RecordArtifactRetentionBasis", actor,
                Stream, "initial", 0, new string('a', 64), at, Stream, Stream);
            RaiseEvent(new ArtifactRetentionBound(source, 1, 1, actor, at, operation));
        }
    }

'''+s[pos:]
 s=s.replace('''        public async Task<ArtifactRetentionSource> EvidenceAsync()''','''        public Task SeedLegacyAsync(ArtifactRetentionSource source) =>
            _writer.SaveAsync(new LegacyRetentionSeed(source), Context(new GetArtifactRetention(Tenant, source.SourceKind, source.SourceId))).AsTask();
        public async Task<ArtifactRetentionSource> EvidenceAsync()''')
 return s
edit(tests+'ArtifactRetentionNativeOperationTests.cs',native_more)
put(tests+'ArtifactRetentionSplitRegressionTests.cs','''using System.Security.Claims;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.Evidence;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.Retention;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.Retention;

/// <summary>Behavioral RED cases compile against both the combined and the selected split command surfaces.</summary>
public sealed class ArtifactRetentionSplitRegressionTests
{
    [Fact]
    public async Task ShouldConflictGivenCreationRetryWithChangedOriginalOwnerRevision()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifact = await fixture.EvidenceAsync();
        var request = new PlaceArtifactLegalHold(fixture.Tenant, "evidence_artifact", artifact, Fixture.Sha,
            Uuid.CreateVersion4(), 0, "Preserve exact source");
        var handler = new PlaceArtifactLegalHoldHandler(fixture.Mutation);
        Assert.True((await handler.HandleAsync(fixture.Context(request), CancellationToken.None)).IsSuccess);

        // Act
        var changed = await handler.HandleAsync(fixture.Context(request with { ExpectedRevision = 1 }), CancellationToken.None);

        // Assert
        Assert.Equal(RequestErrorKind.Conflict, changed.Error?.Kind);
    }

    [Fact]
    public async Task ShouldAdmitBothHoldsGivenDifferentHoldIdentitiesAndInitialOwnerRevision()
    {
        // Arrange
        await using var fixture = new Fixture();
        var artifact = await fixture.EvidenceAsync();
        var first = new PlaceArtifactLegalHold(fixture.Tenant, "evidence_artifact", artifact, Fixture.Sha,
            Uuid.CreateVersion4(), 0, "Matter A");
        var second = first with { HoldId = Uuid.CreateVersion4(), Reason = "Matter B" };
        var handler = new PlaceArtifactLegalHoldHandler(fixture.Mutation);

        // Act
        var results = await Task.WhenAll(handler.HandleAsync(fixture.Context(first), CancellationToken.None).AsTask(),
            handler.HandleAsync(fixture.Context(second), CancellationToken.None).AsTask());

        // Assert
        Assert.All(results, result => Assert.True(result.IsSuccess, result.Error?.Message));
    }

    sealed class Fixture : IAsyncDisposable
    {
        public const string Sha = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        readonly ServiceProvider _provider;
        readonly AsyncServiceScope _scope;
        readonly IAggregateWriter _writer;
        readonly ClaimsPrincipal _actor = new(new ClaimsIdentity(
            [new Claim("iss", "bdgrz"), new Claim("sub", Uuid.CreateVersion4().ToString())], "BdgrzSession"));
        public Uuid Tenant { get; } = Uuid.CreateVersion4();
        public ArtifactRetentionMutation Mutation { get; }

        public Fixture()
        {
            var services = new ServiceCollection();
            var events = new InMemoryEventStore();
            services.AddSingleton<IEventStore>(events);
            services.AddSingleton<IDomainEventReader>(events);
            services.AddSingleton<IImmutableContentStore>(new FitzKvImmutableContentStore(new InMemoryKvClient()));
            services.AddSingleton(TimeProvider.System);
            services.AddScoped<NativeOperationExecutor>();
            services.AddPortia();
            _provider = services.BuildServiceProvider();
            _scope = _provider.CreateAsyncScope();
            _writer = _scope.ServiceProvider.GetRequiredService<IAggregateWriter>();
            Mutation = ActivatorUtilities.CreateInstance<ArtifactRetentionMutation>(_scope.ServiceProvider);
        }

        public IRequestContext<T> Context<T>(T request) where T : IRequestBase => new Cntryl.Portia.RequestContext<T>(request,
            new RequestDispatchContext(_actor, new HttpInvocation("PUT", "/synthetic/retention", null, "retention-red")));

        public async Task<Uuid> EvidenceAsync()
        {
            var id = Uuid.CreateVersion4();
            var artifact = new EvidenceArtifact(Tenant, id);
            Assert.True(artifact.Register(new("Evidence", null, "export", "manual", DateTimeOffset.UtcNow,
                    new(2019, 1, 1), new(2019, 12, 31), "confidential"), Sha, 100,
                ActorReference.ForMember(Uuid.CreateVersion4(), "Collector"), DateTimeOffset.UtcNow).IsSuccess);
            await _writer.SaveAsync(artifact, Context(new GetArtifactRetention(Tenant, "evidence_artifact", id)));
            return id;
        }
        public async ValueTask DisposeAsync()
        {
            await _scope.DisposeAsync();
            await _provider.DisposeAsync();
        }
    }
}
''')
# Re-emit all artifacts after the final read/cutover regressions. The small tests.patch is executable before the API migration.
manifest=[];patches={'tests':[],'migrated-tests':[],'implementation':[]}
red_path=tests+'ArtifactRetentionSplitRegressionTests.cs'
for path,old in sorted(changed.items()):
 after=AFTER/path
 new=after.read_text() if after.exists() else None
 if old==new:continue
 kind='tests' if path==red_path else 'migrated-tests' if path.startswith('test/') else 'implementation'
 patch='diff --git a/'+path+' b/'+path+'\n'
 if old is None:patch+='new file mode 100644\n'
 if new is None:patch+='deleted file mode 100644\n'
 patch+=''.join(difflib.unified_diff((old or '').splitlines(keepends=True),(new or '').splitlines(keepends=True),
   fromfile='/dev/null' if old is None else 'a/'+path,tofile='/dev/null' if new is None else 'b/'+path))
 patches[kind].append(patch)
 manifest.append({'path':path,'patch':kind+'.patch','action':'add' if old is None else 'delete' if new is None else 'modify',
   'beforeSha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,
   'afterSha256':hashlib.sha256(new.encode()).hexdigest() if new is not None else None})
for name,parts in patches.items():(OUT/(name+'.patch')).write_text(''.join(parts))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'newfiles.json').write_text(json.dumps([m for m in manifest if m['action']=='add'],indent=2)+'\n')
print(json.dumps({'files':len(manifest),'patches':{k:(OUT/(k+'.patch')).stat().st_size for k in patches}},indent=2))
