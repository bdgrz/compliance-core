# S31 retention owners: prepared patch artifacts

Prepared outside the repository. No main-checkout source, index, branch, worktree, GitHub or build mutation was performed. No tests or compiler were run; this is an implementation candidate for the parent's RED/GREEN and direct Jev review, not a green or merged claim.

## Apply in this order

1. Apply `tests.patch`. It adds only `ArtifactRetentionSplitRegressionTests`, using command/handler surfaces that compile against the current combined owner. Its DI fixture resolves the old/new mutation constructor through ActivatorUtilities. Run the focused class before implementing: the current source should wrongly accept a changed original hold revision and reject one of two unrelated holds at initial revision zero.
2. Apply `implementation.patch` and `migrated-tests.patch` together. The latter migrates existing acceptance fixtures to the selected command signatures/owner revisions and adds native recovery regressions. This extra patch is required because a test that names the new owners cannot compile before those types exist.
3. Parent owns shared files: apply or reproduce the exact `shared-deltas.patch` route changes in Program.cs. All three mutation routes become identified PUT routes; MCP mutation exposure stays disabled.
4. Run the focused retention, generated population export and Type I evidence governance unit tests, then the full unit suite. Run formatting/build/analyzers as the parent coordinates the build slot. Direct Jev per modified file remains for the parent after application.

Suggested RED filter: `FullyQualifiedName~ArtifactRetentionSplitRegressionTests`.
Suggested GREEN filter: `FullyQualifiedName~Features.Retention|FullyQualifiedName~GenerateAuditPopulationExportHandlerTests|FullyQualifiedName~EvidenceGovernanceTypeIBaselineSourceContributorTests`.

All four patch files passed `git apply --check` against the frozen main checkout. `manifest.json` records each source baseline hash and proposed hash, and `newfiles.json` identifies additions. Verify the baseline before applying after any intervening edit. `before/` and `after/` are reviewable file snapshots, not Git worktrees.

## Behavior implemented

- `ArtifactRetentionBasis`: one immutable seven-year basis keyed by exact `(tenant, source kind, source ID, lowercase content SHA-256)` through AggregateIdentity's typed length-prefix encoding. An artifact ID alone cannot alias another content version. Native evidence periods are required; imports require an explicit supported period. The seventh anniversary is retained through that date.
- `ArtifactLegalHold`: one HoldId lifecycle, immutable exact-source/content placement and one attributed release. Placement uses revision 0; release uses revision 1. Different HoldIds never contend on a global retention counter. Source position cannot regress during release, release time cannot precede placement, and no hold history cap is added.
- Basis recording and release require typed CommandId. Placement uses the authored HoldId. Native acceptance binds full original authored request, actor identity and original owner revision, freezes original Unit response/result, and resolves exact retry before new-operation source guards. An old placement retry after release never restores the hold.
- Queries discover independent hold owners from native placement facts, hydrate them authoritatively, copy read values before confirmation, and fence repeated discovery/tails/source positions. Query `Revision` is a monotonic composition sum used only for minimum-read/paging fences; authored mutation revisions belong to the individual basis or hold owner.
- The Type I source contributor composes the new owners and preserves its point-in-time filtering. Generated population export preserves its existing seven-year source-period decision on the new native basis owner, using a stable derived child identity and original collector. Its broader independent export process remains existing S35 work; this patch does not claim that separation complete.
- Disposition is always false, including an elapsed period with every hold released. Missing engagement/reliance/approval/storage-enforcement proofs remain blockers.
- `ArtifactRetentionBound` remains a native-shaped legacy detection schema; fresh basis admission needs only its complete `ArtifactRetentionBasisRecorded` native fact. It does not emit two accepting facts for one logical ID.

## Exact shared registration deltas

Program.cs: use the supplied route-only patch. Record basis becomes PUT `.../basis/{command_id}`; place becomes PUT `.../legal-holds/{hold_id}`; release becomes PUT `.../legal-holds/{hold_id}/releases/{command_id}`.

ComplianceCoreJsonContext.cs: no additional type registration is needed for this bounded slice. The two changed commands and four event schemas are already registered; native provenance, immutable references, UnitResult, FirstResponseDescriptor and MutationResultContent are already registered. The source generator must regenerate metadata for the changed fields when compiling.

ComplianceServiceCollectionExtensions.cs: no additional registration is required. Existing ArtifactRetentionMutation/ArtifactRetentionRead/handlers remain registered, and NativeOperationExecutor, IImmutableContentStore, TimeProvider and IDomainEventReader already serve other native owners. Mutation now also consumes IDomainEventReader. ArtifactRetentionReader is composed directly by the read handlers and baseline contributor.

## Evidence preserved and added

`test-preservation.json` shows every existing test method retained except the deliberate replacement of the old global-hold-contention assertion with independent-HoldId acceptance. Seven-year native/import periods, wrong source/digest/tenant/actor, source position regression, independent attribution, current administrator authority, historical attest write wall, HTTP-only mutation, MCP-safe reads, changing source/owner reads, reused mutable reader races, paging cursor scope/staleness, and permanent disposal blockers remain covered in the migrated tests.

New focused cases cover wrong original hold revision, independent hold admission, exact original basis/placement replay without source reselection, placement retry after release, changed actor/intent/original revision, missing command identity, commit-then-unknown append for all three commands, equal concurrent placement, more than 64 independent holds, content-key separation and fail-closed legacy history.

## Local blocker and qualification boundary

Persisted combined `artifact_retention` streams do not have a selected trusted migration/import protocol in the accepted specs. The patch explicitly refuses reads and fresh decisions for such a source, rather than presenting historical active holds as absent. Existing exact native retries can still resolve their original receipt. No historical data is removed. A verified migration that preserves original placement/release attribution and complete history is required before enabling this cutover on existing persisted data; see `blockers.json`. Keep old writers quiesced during any future cutover.

#1042 is not a blocker for these per-first-owner writes. Bare operation-ID status/result lookup and cross-route deduplication remain disabled. Protected download/crypto, content guard/seal disposition enforcement, export/disposition execution, engagement holds and the rest of S31/S35 are outside this prepared slice. No new GitHub issues were created.
