from pathlib import Path
p=Path('/tmp/compliance-policy-campaign-native-prepared/work/test/Compliance.Tests/Features/PolicyDistribution/CampaignClosurePreparationTests.cs');s=p.read_text()
s=s.replace('var fault = new FaultStore(host.Content, async () =>','var fault = new FaultStore(host.Content, abort, async () =>')
s=s.replace('var fault = new FaultStore(host.Content, null);','var fault = new ReplayStore(host.Content, abort);')
s=s.replace('ShouldReplayClosureWithoutIntentReadGivenAlreadyAcceptedNativeReceipt','ShouldReplayClosureWithOnlyRequiredSourceBindingGivenAlreadyAcceptedNativeReceipt')
s=s.replace('Assert.Equal(0, fault.Reads);','Assert.Equal(abort ? 0 : 1, fault.IntentReads);\n        Assert.Equal(0, fault.OtherReads);')
pos=s.index('    static async Task<Commands> SeedAsync')
s=s[:pos]+'''    [Fact]
    public async Task ShouldRejectChangedManifestGivenAcceptedCompleteReceiptWithUnchangedNativeBinding()
    {
        // Arrange
        await using var host = new CampaignHost();
        var commands = await SeedAsync(host);
        var winner = await HandleAsync(host, commands, abort: false, host.Content, CancellationToken.None);
        Assert.True(winner.IsSuccess, winner.Error?.Message);
        var changed = commands with { Complete = commands.Complete with
            { ParticipantProofManifest = commands.Complete.Intent } };

        // Act
        var replay = await HandleAsync(host, changed, abort: false, host.Content, CancellationToken.None);

        // Assert
        Assert.False(replay.IsSuccess);
        Assert.Equal(RequestErrorKind.Conflict, replay.Error?.Kind);
        Assert.False(replay.Error!.IsTransient);
        Assert.Equal(await WrittenAsync(host, commands, abort: false), Assert.IsType<ReceiverOutcome.Applied>(winner.Value).Fact);
    }

''' +s[pos:]
s=s.replace('sealed class FaultStore(IImmutableContentStore inner, Func<Task>? beforeFailure)', 'sealed class FaultStore(IImmutableContentStore inner, bool abort, Func<Task>? beforeFailure)')
s=s.replace('''        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
''','''        public async Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default)
        {
            if (!abort && schema == PolicyCampaignContent.TotalsSchema)
            {
                Reads++;
                if (beforeFailure is not null)
                    await beforeFailure();
                throw new ImmutableContentUnavailableException("The losing derived closure totals write failed.");
            }
            return await inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        }
''')
s=s.replace('if (reference.Schema == ClosureIntent.Schema)','if (abort && reference.Schema == ClosureIntent.Schema)')
pos=s.index('    sealed class FaultStore(')
s=s[:pos]+'''    sealed class ReplayStore(IImmutableContentStore inner, bool abort) : IImmutableContentStore
    {
        public int IntentReads { get; private set; }
        public int OtherReads { get; private set; }

        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            throw new InvalidOperationException("An accepted closure retry cannot prepare new derived content.");

        public Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference, CancellationToken ct = default)
        {
            if (reference.Schema == ClosureIntent.Schema && !abort)
            {
                IntentReads++;
                return inner.ReadVerifiedAsync(realm, reference, ct);
            }
            OtherReads++;
            throw new ImmutableContentUnavailableException("Historical closure preparation bodies are unavailable.");
        }
    }

''' +s[pos:]
p.write_text(s)
p=Path('/tmp/compliance-policy-campaign-native-prepared/work/src/Compliance.Core/Features/PolicyDistribution/PolicyCampaignClosureVerifier.cs');s=p.read_text().replace('''        return intent.Header != expected || intent.ParentKind != ClosureParentKind.PolicyCampaign ||
            intent.ParentId''','''        return intent.Header != expected || intent.ParentKind != ClosureParentKind.PolicyCampaign ||
            intent.SourceUses is null || !PolicyCampaignHistory.Reference(intent.SourceUses.Content, SourceUseRequirement.Schema) ||
            intent.ParentId''');p.write_text(s)
