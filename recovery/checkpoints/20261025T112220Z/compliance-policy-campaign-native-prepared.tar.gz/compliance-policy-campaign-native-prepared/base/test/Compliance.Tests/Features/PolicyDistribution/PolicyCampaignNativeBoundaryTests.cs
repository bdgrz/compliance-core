using System.Collections;
using System.Reflection;
using Bdgrz.Compliance.Features.AccessControl;
using Bdgrz.Compliance.Features.PolicyDistribution;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;

namespace Bdgrz.Compliance.Tests.Features.PolicyDistribution;

public sealed class PolicyCampaignNativeBoundaryTests
{
    [Fact]
    public void ShouldRetainOnlyCurrentAuthorityGivenManyReconciliationsAdmissionsAndCanceledClosures()
    {
        // Arrange
        var tenant = Uuid.CreateVersion4();
        var program = Uuid.CreateVersion4();
        var campaignId = Uuid.CreateVersion4();
        var personId = Uuid.CreateVersion4();
        var member = Uuid.CreateVersion4();
        var actor = ActorReference.ForMember(member, "Campaign manager");
        var campaign = new PolicyDistributionCampaign(tenant, campaignId);
        var participant = new PolicyCampaignParticipant(tenant, campaignId, personId);
        var root = PolicyCampaignContent.Provenance(campaignId, nameof(LaunchPolicyCampaign), campaign.Stream,
            campaign.Stream, actor, null, new string('a', 64), NativeFacts.Now);
        Assert.True(campaign.LaunchCampaign(root, program, CampaignHost.PolicySubject, "core_security", NativeFacts.Ref(),
            Uuid.CreateVersion4(), new string('b', 64), DateOnly.FromDateTime(NativeFacts.Now.UtcDateTime),
            DateOnly.FromDateTime(NativeFacts.Now.UtcDateTime).AddDays(30), "Review exact policy", 1, actor, member,
            NativeFacts.Now, NativeFacts.Ref(), NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
        var firstResult = Uuid.Empty;

        // Act
        for (var index = 0; index < 105; index++)
        {
            var reconciliation = PolicyCampaignContent.Provenance(Uuid.CreateVersion4(), nameof(ReconcileCampaignAudience),
                campaign.Stream, campaign.Stream, actor, campaign.Revision, new string('c', 64), NativeFacts.Now);
            Assert.True(campaign.Reconcile(reconciliation, Uuid.CreateVersion4(), new string('d', 64),
                DateOnly.FromDateTime(NativeFacts.Now.UtcDateTime), NativeFacts.Ref(), actor, NativeFacts.Now,
                NativeFacts.Ref(), NativeFacts.Ref()).IsSuccess);
            var admittedRoot = Uuid.CreateVersion4();
            if (index == 0)
                firstResult = admittedRoot;
            var admission = PolicyCampaignContent.Provenance(admittedRoot, nameof(ApproveCampaignWaiver), campaign.Stream,
                participant.Stream, actor, campaign.Revision, new string('e', 64), NativeFacts.Now);
            var intent = NativeFacts.Ref();
            Assert.True(campaign.AdmitResult(admission, intent, NativeFacts.Ref()).IsSuccess);
            var admitted = campaign.AdmittedFor(admittedRoot)!;
            var applied = PolicyCampaignContent.Child(Uuid.CreateVersion4(), "ApplyPolicyParticipantResult",
                admitted.Metadata.EventId, PolicyCampaignContent.HeaderOf(admission, campaign.Stream, participant.Stream,
                    NativeFacts.Now), participant.Stream, NativeFacts.Now);
            Assert.True(participant.ApproveWaiver(applied, "Exception " + index,
                DateOnly.FromDateTime(NativeFacts.Now.UtcDateTime).AddDays(1), actor, member, NativeFacts.Now,
                intent, NativeFacts.Ref()).IsSuccess);
            var closure = PolicyCampaignContent.Provenance(Uuid.CreateVersion4(), nameof(CloseCampaign), campaign.Stream,
                campaign.Stream, actor, campaign.Revision, new string('f', 64), NativeFacts.Now);
            var closureIntent = NativeFacts.Ref();
            Assert.True(campaign.AcceptClosure(closure, closureIntent, NativeFacts.Ref()).IsSuccess);
            var abort = PolicyCampaignContent.Child(Uuid.CreateVersion4(), nameof(AbortPolicyCampaignClosure),
                campaign.PendingClosure!.Metadata.EventId,
                PolicyCampaignContent.HeaderOf(closure, campaign.Stream, campaign.Stream, NativeFacts.Now), campaign.Stream,
                NativeFacts.Now);
            Assert.True(campaign.CancelClosure(abort, closureIntent).IsSuccess);
        }
        var retained = new Aggregate[] { campaign, participant }.SelectMany(owner => owner.GetType()
            .GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly)
            .Where(field => field.GetValue(owner) is ICollection { Count: > 2 })).ToArray();

        // Assert
        Assert.Equal(421, campaign.Revision);
        Assert.Equal(106, campaign.Generation);
        Assert.Equal(105, campaign.Reconciliations);
        Assert.Equal(105, participant.Revision);
        Assert.NotNull(campaign.AdmittedFor(firstResult));
        Assert.NotNull(participant.ResultFor(firstResult));
        Assert.Empty(retained);
    }
}
