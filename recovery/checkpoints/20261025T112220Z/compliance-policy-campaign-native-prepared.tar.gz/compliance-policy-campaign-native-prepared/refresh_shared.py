from pathlib import Path
import json,hashlib
r=Path('/tmp/compliance-policy-campaign-native-prepared'); repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=['src/Compliance.Core/ComplianceServiceCollectionExtensions.cs','src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs','test/Compliance.Tests/Testing/ProgramManagementServices.cs','docs/product/aggregate-boundary-ledger.md']
metadata=json.loads((r/'baselines.json').read_text())
for p in paths:
 data=(repo/p).read_bytes()
 for tree in ['base','work']:
  (r/tree/p).parent.mkdir(parents=True,exist_ok=True);(r/tree/p).write_bytes(data)
 row=next(v for v in metadata if v['path']==p);row['beforeSha256']=hashlib.sha256(data).hexdigest();row['baselineSource']=str(repo/p)+' (root-authorized stable merged55dc8c23 capture; retain all current family layers)'
p=r/'work'/paths[0];s=p.read_text();assert s.count('services.AddScoped<CampaignSource>();')==1;s=s.replace('services.AddScoped<CampaignSource>();','services.AddScoped<CampaignSource>();\n        services.AddScoped<PolicyCampaignReader>();');p.write_text(s)
p=r/'work'/paths[1];s=p.read_text();s='using Bdgrz.Compliance.Features.PolicyDistribution;\n'+s;anchor='        Decorate<IRequestBus>(services, (_, inner) => new PersistenceValidationRequestBus(inner));';assert s.count(anchor)==1;s=s.replace(anchor,'        Decorate<IAggregateReader>(services, (provider, inner) =>\n            new PolicyCampaignAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));\n'+anchor);p.write_text(s)
p=r/'work'/paths[2];s=p.read_text();assert s.count('collection.AddVerifiedSourceUseReader();')==1;s=s.replace('collection.AddVerifiedSourceUseReader();','collection.AddVerifiedSourceUseReader();\n        collection.AddVerifiedPolicyCampaignReader();');p.write_text(s)
p=r/'work'/paths[3];s=p.read_text();lines=s.splitlines(True)
for i,line in enumerate(lines):
 if line.startswith('| `PolicyDistributionCampaign` |'):
  cells=line.rstrip('\n').split(' | ');cells[-2]='state: bounded current launch/frozen/pending/closed frames, revision/generation/admission counters and exact native cut; at most one selected roster/closure/acceptance. Complete verified amendment/admission/terminal history is composed by PolicyCampaignReader outside the command owner; no lifetime cap. Audience/manifests/totals remain complete immutable content; native tags and existing authored limits unchanged';lines[i]=' | '.join(cells)+'\n'
 if line.startswith('| `PolicyCampaignParticipant` |'):
  cells=line.rstrip('\n').split(' | ');cells[-2]='state: result count/current acknowledgement/completion flags, exact native cut, selected root/acceptance, active and explicitly selected source-use authority; no lifetime result collection. Complete verified results and waivers are composed by PolicyCampaignReader outside the owner; no history cap. Existing inline authored values and CampaignClosure grant/settle/fence proofs unchanged';lines[i]=' | '.join(cells)+'\n'
p.write_text(''.join(lines));(r/'baselines.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({p:hashlib.sha256((r/'base'/p).read_bytes()).hexdigest() for p in paths},indent=2))
