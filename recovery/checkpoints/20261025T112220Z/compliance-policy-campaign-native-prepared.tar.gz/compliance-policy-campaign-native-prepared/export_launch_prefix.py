from pathlib import Path
import hashlib,json,difflib,tempfile,shutil,subprocess
parent=Path('/tmp/compliance-policy-campaign-native-prepared');r=Path('/tmp/compliance-campaign-launch-prepare-prepared');r.mkdir(exist_ok=True)
src='src/Compliance.Core/Features/PolicyDistribution/CampaignLaunch.cs';test='test/Compliance.Tests/Features/PolicyDistribution/CampaignLaunchPreparationRaceTests.cs';paths=[src,test]
old={src:(parent/'base'/src).read_bytes(),test:(parent/'old-api-CampaignLaunchPreparationRaceTests.cs').read_bytes()}
new={p:(parent/'work'/p).read_bytes() for p in paths};sha=lambda b:hashlib.sha256(b).hexdigest()
for p in paths:
 for stage,data in [('base',old[p]),('work',new[p])]:
  f=r/stage/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
def delta(ps,clean):
 out=[]
 for p in ps:
  before=None if clean and p==test else old[p]
  out.append(f'diff --git a/{p} b/{p}\n'+('new file mode 100644\n' if before is None else ''))
  out.extend(difflib.unified_diff((before or b'').decode().splitlines(True),new[p].decode().splitlines(True),fromfile='/dev/null' if before is None else 'a/'+p,tofile='b/'+p,n=3))
 return ''.join(out)
for name,ps,clean in [('implementation.patch',[src],False),('tests-after-red.patch',[test],False),('full-after-red.patch',paths,False),('full-from-clean.patch',paths,True)]:
 (r/name).write_text(delta(ps,clean))
checks=[]
for label,patches,clean in [('clean',['full-from-clean.patch'],True),('after-red',['full-after-red.patch'],False),('partitioned',['implementation.patch','tests-after-red.patch'],False)]:
 with tempfile.TemporaryDirectory(prefix='reconstruct-',dir=r) as d:
  t=Path(d);shutil.copytree(r/'base',t,dirs_exist_ok=True)
  if clean:(t/test).unlink()
  for name in patches:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/name)],cwd=t,text=True,capture_output=True);assert x.returncode==0,(x.stdout,x.stderr)
  assert all((t/p).read_bytes()==new[p] for p in paths)
  checks.append(label)
m={'status':'FROZEN','package':'CampaignLaunchPrepare2','paths':[{'path':p,'originalBeforeSha256':sha(old[p]),'cleanBeforeSha256':None if p==test else sha(old[p]),'afterRedBeforeSha256':sha(old[p]),'afterSha256':sha(new[p])} for p in paths],'patches':{p.name:sha(p.read_bytes()) for p in r.glob('*.patch')},'reconstructionPassed':checks,'api':'CampaignLaunch constructor drops unused IAggregateReader: now operations,content,clock3; existing scoped DI resolves without wiring changes. All source callbacks/guards/candidate writes/first response descriptor move inside native asynchronous Prepare; current actor/auth boundary stays before replay.','runtime':'Parent owns actual RED/GREEN/build/full/Jev. No runtime preparation claims. Existing-API race2 is part of parent Campaign RED3; original old4ctor test saved in parent old-api file.','unresolved':'Whole campaign/participant lifetime compaction remains separate parent artifact work; do not retain its temporary failing lifetime RED when merging this narrow prefix.'}
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
(r/'README.md').write_text('''# Campaign launch preparation prefix (2 paths)\n\nFROZEN independently of the larger campaign/participant history migration. `implementation.patch` moves real material/roster source resolution, guard results and immutable audience/registration/result writes inside native async preparation, so the central equal-winner and requested-cancellation recovery applies. No per-family recovery catch is added. Current actor/auth, complete frozen audience, exact source callbacks, raw request digest, Unit/registration response bytes and atomic two-fact launch remain their original behavior.\n\nConstructor changes from4services to3: operations,content,clock. Existing `AddScoped<CampaignLaunch>()` needs no edit. The only explicit constructors are the new real race test's two calls; all assertions/names remain.\n\nUse full-from-clean.patch when the race test is absent, or full-after-red.patch if the stable existing-API race test remains installed. New-file mode100644 is explicit. Source-only plus tests-after-red.patch is also exact. Do not include the separate temporary failing lifetime RED in a prefix-only merge. Full-family artifact must layer this prefix before any later owner changes, rather than replay it.\n\nNo .NET/format/runtime/Jev/Git/main commands run by preparation agent. Parent must first qualify old-API race theory2, then strict build/focused/full checks and direct exact-source Jev. Original parent RED3 patch is immutable in /tmp/compliance-policy-campaign-native-prepared.\n''')
h={'status':'FROZEN','root':str(r),'manifestSha256':sha((r/'manifest.json').read_bytes()),'readmeSha256':sha((r/'README.md').read_bytes()),'sourceAfterSha256':sha(new[src]),'patches':m['patches'],'filter':'FullyQualifiedName~CampaignLaunchPreparationRaceTests','paths':2,'runtime':'Parent only; no runtime claims.'}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'handoffSha256':sha((r/'handoff.json').read_bytes()),**h},indent=2))
