from pathlib import Path
import difflib,hashlib,json,tempfile,shutil,subprocess
p=Path('/tmp/compliance-policy-campaign-native-prepared');r=Path('/tmp/compliance-campaign-member-binding-prepared');r.mkdir(exist_ok=True)
src='src/Compliance.Core/Features/PolicyDistribution/PolicyDistributionCampaign.cs';test='test/Compliance.Tests/Features/PolicyDistribution/CampaignLaunchMemberBindingTests.cs';paths=[src,test];old={src:(p/'base'/src).read_bytes(),test:(p/'old-api-CampaignLaunchMemberBindingTests.cs').read_bytes()};new={x:(p/'work'/x).read_bytes() for x in paths};sha=lambda b:hashlib.sha256(b).hexdigest()
for x in paths:
 for stage,data in [('base',old[x]),('work',new[x])]:
  f=r/stage/x;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
def patch(selected,clean):
 out=[]
 for x in selected:
  before=None if clean and x==test else old[x]
  if before==new[x]:continue
  out.append(f'diff --git a/{x} b/{x}\n'+('new file mode 100644\n' if before is None else ''))
  out.extend(difflib.unified_diff((before or b'').decode().splitlines(True),new[x].decode().splitlines(True),fromfile='/dev/null' if before is None else 'a/'+x,tofile='b/'+x,n=3))
 return ''.join(out)
for name,xs,clean in [('implementation.patch',[src],False),('full-after-red.patch',paths,False),('full-from-clean.patch',paths,True)]: (r/name).write_text(patch(xs,clean))
checks=[]
for label,names,clean in [('clean',['full-from-clean.patch'],True),('after-red',['full-after-red.patch'],False),('source-only',['implementation.patch'],False)]:
 with tempfile.TemporaryDirectory(prefix='reconstruct-',dir=r) as d:
  target=Path(d);shutil.copytree(r/'base',target,dirs_exist_ok=True)
  if clean:(target/test).unlink()
  for name in names:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/name)],cwd=target,text=True,capture_output=True);assert x.returncode==0,(x.stdout,x.stderr)
  assert all((target/x).read_bytes()==new[x] for x in paths);checks.append(label)
m={'status':'FROZEN','package':'CampaignMemberBinding2','paths':[{'path':x,'beforeSha256':sha(old[x]),'cleanBeforeSha256':None if x==test else sha(old[x]),'afterSha256':sha(new[x])} for x in paths],'patches':{x.name:sha(x.read_bytes()) for x in r.glob('*.patch')},'reconstruction':checks,'qualification':'Source verification + static only. Parent must first qualify oldAPI authorityRED6 then strictbuild/focus/full/Jev; no runtime claims.','change':'One owning launch reducer guard binds persisted ActorMemberId to actual nonempty member actor UUID and matching Operation.Actor. Actual producer PolicyActor.From derives all from same member. No payload/schema/route/command/identity/sourceuse changes.','red':'/tmp/compliance-policy-campaign-native-prepared/authority-red.patch','filter':'FullyQualifiedName~CampaignLaunchMemberBindingTests'}
(r/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(r/'README.md').write_text('''# Campaign launching-member binding (2 paths)\n\nFROZEN narrow owning guard plus unchanged existing-API authority RED6, independent of future campaign history compaction. The actual launch producer derives Actor and ActorMemberId from the same member; the old persisted event stores these independently and its reducer trusted ActorMemberId as OwnerMemberId. The guard requires nonempty matching member UUID, member kind and actual native operation actor equality. It runs before the forged authority becomes visible.\n\nFirst qualify stable authority-red.patch against old current source, then apply implementation.patch (also full-after-red.patch, since the test is unchanged). full-from-clean.patch includes the new test with explicit new-file mode100644. All3 isolated reconstruction orders passed. Existing wire/native discriminator/source-use/identity contracts stay unchanged. No .NET/runtime/format/Jev/Git/main action by preparation agent; parent owns all qualification. Full-family package will layer this prefix instead of reapplying it.\n''')
h={'status':'FROZEN','root':str(r),'manifestSha256':sha((r/'manifest.json').read_bytes()),'readmeSha256':sha((r/'README.md').read_bytes()),'sourceAfterSha256':sha(new[src]),'patches':m['patches'],'filter':m['filter'],'runtime':'Parent only; no runtime claims.'};(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps({'handoffSha256':sha((r/'handoff.json').read_bytes()),**h},indent=2))
