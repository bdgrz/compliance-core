from pathlib import Path
r=Path('/tmp/compliance-policy-campaign-native-prepared/work')
p=r/'src/Compliance.Core/Features/NativeOperations/NativeReceiverPreparation.cs'
s=p.read_text().replace('Func<CancellationToken, ValueTask<Result<TPrepared>>> prepare', 'Func<TOwner, CancellationToken, ValueTask<Result<TPrepared>>> prepare')
s=s.replace('var known = await RecheckAsync(reader, open, decide, ct).ConfigureAwait(false);', 'var owner = await reader.HydrateAsync(open(), ct).ConfigureAwait(false);\n        var known = decide(owner);')
s=s.replace('candidate = await prepare(ct).ConfigureAwait(false);','candidate = await prepare(owner, ct).ConfigureAwait(false);')
p.write_text(s)
p=r/'src/Compliance.Core/Features/PolicyDistribution/ApplyPolicyParticipantResultHandler.cs'
s=p.read_text().replace('owner => Decide(owner, binding), token => PrepareAsync(campaign, admitted, command, expectedHeader, token), ct)', 'owner => Decide(owner, binding), (_, token) => PrepareAsync(campaign, admitted, command, expectedHeader, token), ct)')
p.write_text(s)
p=r/'src/Compliance.Core/Features/PolicyDistribution/PolicyCampaignClosureVerifier.cs'
s=p.read_text()
start=s.index('        var loaded = await LoadAsync',s.index('public async ValueTask<PolicyCampaignClosure> VerifyAcceptedAsync'))
end=s.index('\n    /// <summary>Verifies the terminal', start)
s=s[:start]+'''        var loaded = await ReadAcceptedAsync(source, intentReference, operationId, commandId, ct).ConfigureAwait(false);
        return loaded.Error is not null ? loaded : await PrepareAsync(loaded, ct).ConfigureAwait(false);
    }

    /// <summary>Resolves only the exact native acceptance, before any immutable preparation or receiver replay.</summary>
    public async ValueTask<PolicyCampaignClosure> ReadAcceptedAsync(NativeFactReference source,
        ImmutableContentRef intentReference, Uuid operationId, Uuid commandId, CancellationToken ct)
    {
        var loaded = await LoadNativeAsync(source, intentReference, operationId, commandId, ct).ConfigureAwait(false);
        if (loaded.Error is not null)
            return loaded;
        var accepted = loaded.Accepted!;
        return accepted.Metadata.EventId != source.EventId || accepted.Metadata.AggregateVersion != source.AggregateVersion
            ? PolicyCampaignClosure.Failed(Permanent("The source is not the accepted closure of this campaign."))
            : loaded;
    }
''' +s[end:]
s=s.replace('var loaded = await LoadAsync(source, intentReference, operationId, commandId, ct).ConfigureAwait(false);','var loaded = await LoadNativeAsync(source, intentReference, operationId, commandId, ct).ConfigureAwait(false);')
s=s.replace(': loaded with { Accepted = accepted };', ': await PrepareAsync(loaded with { Accepted = accepted }, ct).ConfigureAwait(false);')
start=s.index('    async ValueTask<PolicyCampaignClosure> LoadAsync')
end=s.index('\n    static RequestError Permanent', start)
s=s[:start]+'''    async ValueTask<PolicyCampaignClosure> LoadNativeAsync(NativeFactReference source, ImmutableContentRef intentReference,
        Uuid operationId, Uuid commandId, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(source);
        ArgumentNullException.ThrowIfNull(intentReference);
        if (!Uuid.TryParse(source.Stream.Realm, System.Globalization.CultureInfo.InvariantCulture, out var tenantId) ||
            !Uuid.TryParse(source.Stream.Resource, System.Globalization.CultureInfo.InvariantCulture, out var campaignId) ||
            source.Stream.Area != PolicyDistributionCampaign.Area)
            return PolicyCampaignClosure.Failed(Permanent("The closure names another campaign stream."));
        var campaign = await new PolicyCampaignReader(reader, events).ReadAsync(tenantId, campaignId,
            commandId, selectedClosureRootId: operationId, ct: ct).ConfigureAwait(false);
        if (campaign.Stream != source.Stream)
            return PolicyCampaignClosure.Failed(Permanent("The closure names another campaign stream."));
        if (campaign.ClosureFor(operationId) is not { } accepted)
            return PolicyCampaignClosure.Failed(Transient("The accepted closure is not visible yet."));
        return accepted.Intent != intentReference
            ? PolicyCampaignClosure.Failed(Permanent("The command differs from the frozen closure intent."))
            : new PolicyCampaignClosure(campaign, accepted, null, null, null);
    }

    /// <summary>Verifies complete immutable closure terms only after native receipt knowledge was decided.</summary>
    public async ValueTask<PolicyCampaignClosure> PrepareAsync(PolicyCampaignClosure closure, CancellationToken ct)
    {
        var campaign = closure.Campaign!;
        var accepted = closure.Accepted!;
        ClosureIntent intent;
        IReadOnlyList<ClosureParticipant> participants;
        try
        {
            intent = await PolicyCampaignContent.ReadAsync<ClosureIntent>(content, campaign.TenantId, accepted.Intent, ct)
                .ConfigureAwait(false);
            participants = await ClosureParticipant.ReadAsync(content, campaign.TenantId, intent, ct).ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return PolicyCampaignClosure.Failed(Permanent($"The frozen closure cannot be verified: {exception.Message}"));
        }
        var expected = PolicyCampaignContent.HeaderOf(accepted.Operation, campaign.Stream, campaign.Stream,
            accepted.Operation.AcceptedAt);
        return intent.Header != expected || intent.ParentKind != ClosureParentKind.PolicyCampaign ||
            intent.ParentId != campaign.Id || intent.ParentGeneration != (ulong)accepted.Generation
            ? PolicyCampaignClosure.Failed(Permanent("The command differs from the frozen closure intent."))
            : closure with { Intent = intent, Participants = participants };
    }
''' +s[end:]
p.write_text(s)
