from pathlib import Path
r=Path('work/src/Compliance.Core/Features/PolicyDistribution')
p=r/'ReconcileCampaignAudienceHandler.cs';s=p.read_text()
a=s.index('        var source = await campaigns.ReadAsync(');b=s.index('        var actor = PolicyActor.From(',a);s=s[:a]+s[b:]
s=s.replace('''        var provenance = PolicyCampaignContent.Provenance(request.CommandId, CommandKind, campaign.Stream,
            campaign.Stream,''','''        var stream = new PolicyDistributionCampaign(request.TenantId, request.CampaignId).Stream;
        var provenance = PolicyCampaignContent.Provenance(request.CommandId, CommandKind, stream,
            stream,''')
a=s.index('        if (campaign.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');b=s.index('        var outcome = await operations.ExecuteAsync(',a)
block=s[a:b].replace('''        if (campaign.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)
        {
''','').removesuffix('        }\n\n')
block=block.replace('Result<CampaignReconciliationView>.Failure','Result<FirstResponseDescriptor>.Failure').replace('return Failure(', 'return Result<FirstResponseDescriptor>.Failure(new RequestError(')
# Convert the two simple two-argument request error return statements.
block=block.replace('"The campaign already reconciled that roster snapshot.");','"The campaign already reconciled that roster snapshot."));').replace('"Reconciliation requires a roster snapshot frozen after the campaign\'s latest one.");','"Reconciliation requires a roster snapshot frozen after the campaign\'s latest one."));')
block=block.replace(', ct)', ', token)')
s=s[:a]+s[b:]
s=s.replace('''        FirstResponseDescriptor? response = null;''','''        PolicyCampaignPreparedCut? preparedCut = null;''')
s=s.replace('''            () => new PolicyDistributionCampaign(request.TenantId, request.CampaignId, request.CommandId),
            owner => owner.Acceptance, owner => Prepare(owner, request.ExpectedRevision, response),
            (PolicyDistributionCampaign owner, ImmutableContentRef frozen) => owner.Reconcile(provenance,
                request.RosterSnapshotId, rosterSha!, observedOn, amendments!, actor.Reference, now, frozen, result!)),''','''            () => new PolicyDistributionCampaign(request.TenantId, request.CampaignId, request.CommandId, request.RosterSnapshotId),
            owner => owner.Acceptance, async (owner, token) =>
            {
                preparedCut = PolicyCampaignPreparedCut.Capture(owner);
                if (!owner.IsLaunched || owner.ProgramId != request.ProgramId)
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The campaign was not found."));
                var source = await campaigns.StateOfAsync(owner, token).ConfigureAwait(false);
                if (!source.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(source.Error!);
                var state = source.Value;
                var campaign = state.Campaign;
'''+''.join('    '+line if line.strip() else line for line in block.splitlines(True)).replace('''                response = PolicyCampaignContent.OkResponse(PolicyCampaignContent.ReconciliationSchema, body);''','''                var prepared = owner.PrepareOpenAdmission(request.ExpectedRevision);
                return prepared.IsSuccess
                    ? Result<FirstResponseDescriptor>.Success(PolicyCampaignContent.OkResponse(PolicyCampaignContent.ReconciliationSchema, body))
                    : Result<FirstResponseDescriptor>.Failure(prepared.Error!);''')+'''            },
            (PolicyDistributionCampaign owner, ImmutableContentRef frozen) =>
            {
                var guarded = owner.PrepareOpenAdmission(request.ExpectedRevision);
                if (!guarded.IsSuccess)
                    return guarded;
                return preparedCut is null || !preparedCut.Matches(owner)
                    ? PolicyCampaignPreparedCut.Changed()
                    : owner.Reconcile(provenance, request.RosterSnapshotId, rosterSha!, observedOn, amendments!,
                        actor.Reference, now, frozen, result!);
            }),''')
a=s.index('    static Result<FirstResponseDescriptor> Prepare(');b=s.index('    static Result<CampaignReconciliationView> Failure(',a);s=s[:a]+s[b:];p.write_text(s)
p=r/'CloseCampaignHandler.cs';s=p.read_text();a=s.index('        var source = await campaigns.ReadAsync(');b=s.index('        var actor = PolicyActor.From(',a);s=s[:a]+s[b:]
s=s.replace('''        var provenance = PolicyCampaignContent.Provenance(request.CommandId, CommandKind, campaign.Stream,
            campaign.Stream,''','''        var stream = new PolicyDistributionCampaign(request.TenantId, request.CampaignId).Stream;
        var provenance = PolicyCampaignContent.Provenance(request.CommandId, CommandKind, stream,
            stream,''')
a=s.index('        FirstResponseDescriptor? response = null;');b=s.index('        var outcome = await operations.ExecuteAsync(',a)
s=s[:a]+'''        PolicyCampaignPreparedCut? preparedCut = null;
'''+s[b:]
s=s.replace('''            owner => owner.Acceptance, owner => Prepare(owner, request.ExpectedRevision, response),
            (PolicyDistributionCampaign owner, ImmutableContentRef frozen) =>
                owner.AcceptClosure(provenance, intent!, frozen)),''','''            owner => owner.Acceptance, async (owner, token) =>
            {
                preparedCut = PolicyCampaignPreparedCut.Capture(owner);
                if (!owner.IsLaunched || owner.ProgramId != request.ProgramId)
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The campaign was not found."));
                var source = await campaigns.StateOfAsync(owner, token).ConfigureAwait(false);
                if (!source.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(source.Error!);
                if (CampaignRules.CheckClosure(source.Value, request) is { } failure)
                    return Result<FirstResponseDescriptor>.Failure(failure.ToRequestError());
                intent = await FreezeAsync(source.Value, request, provenance, now, token).ConfigureAwait(false);
                var response = await PolicyCampaignContent.AcceptedResponseAsync(content, request.TenantId, request.CommandId,
                    now, token).ConfigureAwait(false);
                var prepared = owner.PrepareOpenAdmission(request.ExpectedRevision);
                return prepared.IsSuccess ? Result<FirstResponseDescriptor>.Success(response)
                    : Result<FirstResponseDescriptor>.Failure(prepared.Error!);
            },
            (PolicyDistributionCampaign owner, ImmutableContentRef frozen) =>
            {
                var guarded = owner.PrepareOpenAdmission(request.ExpectedRevision);
                if (!guarded.IsSuccess)
                    return guarded;
                return preparedCut is null || !preparedCut.Matches(owner)
                    ? PolicyCampaignPreparedCut.Changed()
                    : owner.AcceptClosure(provenance, intent!, frozen);
            }),''')
a=s.index('    static Result<FirstResponseDescriptor> Prepare(');b=s.index('    static Result<OperationAcceptedResponse> Failure(',a);s=s[:a]+s[b:];p.write_text(s)
s=Path('/tmp/compliance-advisor-history-prepared/work/src/Compliance.Core/Features/AdvisorCollaboration/AdvisorPreparedCut.cs').read_text().replace('Features.AdvisorCollaboration','Features.PolicyDistribution').replace('AdvisorPreparedCut','PolicyCampaignPreparedCut').replace('AdvisorHandoff value','PolicyDistributionCampaign value').replace('AdvisorFeedbackThread value','PolicyCampaignParticipant value').replace('advisor','campaign')
(r/'PolicyCampaignPreparedCut.cs').write_text(s)
