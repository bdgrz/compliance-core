from pathlib import Path
r=Path('work/src/Compliance.Core/Features/PolicyDistribution')
p=r/'PolicyCampaignClosure.cs';s=p.read_text().replace('PolicyDistributionCampaign? Campaign','PolicyCampaignSnapshot? Campaign');p.write_text(s)
p=r/'PolicyCampaignClosureVerifier.cs';s=p.read_text().replace('sealed class PolicyCampaignClosureVerifier(IAggregateReader reader, IImmutableContentStore content)','sealed class PolicyCampaignClosureVerifier(IAggregateReader reader, IImmutableContentStore content,\n    IDomainEventReader events)')
s=s.replace('''        var campaign = await reader.HydrateAsync(new PolicyDistributionCampaign(tenantId, intent.ParentId, commandId),
            ct).ConfigureAwait(false);''','''        var campaign = await new PolicyCampaignReader(reader, events).ReadAsync(tenantId, intent.ParentId,
            commandId, selectedClosureRootId: operationId, ct: ct).ConfigureAwait(false);''')
s=s.replace('''        catch (ImmutableContentIntegrityException exception)
        {
            return''','''        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return''');p.write_text(s)
p=r/'AbortPolicyCampaignClosureHandler.cs';s=p.read_text().replace('IImmutableContentStore content, TimeProvider clock)', 'IImmutableContentStore content, TimeProvider clock, IDomainEventReader events)')
s=s.replace('''new PolicyDistributionCampaign(tenantId, intent.ParentId,
            command.CommandId)''','''new PolicyDistributionCampaign(tenantId, intent.ParentId,
            command.CommandId, selectedClosureRootId: command.OperationId)''').replace('''new PolicyDistributionCampaign(tenantId, intent.ParentId,
                    command.CommandId)''','''new PolicyDistributionCampaign(tenantId, intent.ParentId,
                    command.CommandId, selectedClosureRootId: command.OperationId)''')
s=s.replace('campaign.ClosureFor(command.OperationId)', 'campaign.SelectedClosure').replace('pending.CanceledFor(command.OperationId)', 'pending.SelectedCancellation')
# Events are needed to finalize explicit owner reads too, even for manually composed receiver fixtures.
s=s.replace('''        if (campaign.Stream != command.Target''','''        _ = await PolicyCampaignHistory.ReadAsync(campaign, events, ct).ConfigureAwait(false);
        if (campaign.Stream != command.Target''')
s=s.replace('''        catch (ImmutableContentIntegrityException exception)
        {
            return''','''        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return''');p.write_text(s)
p=r/'CompletePolicyCampaignClosureHandler.cs';s=p.read_text();s=s.replace('''new PolicyDistributionCampaign(campaign.TenantId, campaign.Id,
                    command.CommandId)''','''new PolicyDistributionCampaign(campaign.TenantId, campaign.Id,
                    command.CommandId, selectedClosureRootId: command.OperationId)''').replace('campaign.CanceledFor(operationId)', 'campaign.SelectedCancellation');p.write_text(s)
p=r/'AuthorizePolicyCampaignParticipantCampaignClosureUseHandler.cs';s=p.read_text().replace('PolicyCampaignClosureVerifier verifier, PolicyCampaignClosureFences fences)', 'PolicyCampaignClosureVerifier verifier, PolicyCampaignClosureFences fences, PolicyCampaignReader history)')
s=s.replace('''        return admitted.All(result => owner.ResultFor(result.OperationId) is not null)''','''        var snapshot = await history.ReadParticipantAsync(owner, ct).ConfigureAwait(false);
        return admitted.All(result => snapshot.ResultFor(result.OperationId) is not null)''');p.write_text(s)
p=r/'ApplyPolicyParticipantResultHandler.cs';s=p.read_text().replace('IImmutableContentStore content, TimeProvider clock)', 'IImmutableContentStore content, TimeProvider clock, IDomainEventReader events)')
s=s.replace('''        var campaign = await reader.HydrateAsync(new PolicyDistributionCampaign(tenantId, command.CampaignId), ct)
            .ConfigureAwait(false);''','''        var campaign = await new PolicyCampaignReader(reader, events).ReadAsync(tenantId, command.CampaignId,
            ct: ct).ConfigureAwait(false);''')
s=s.replace('''new PolicyCampaignParticipant(tenantId, command.CampaignId,
                    command.PersonId, command.CommandId)''','''new PolicyCampaignParticipant(tenantId, command.CampaignId,
                    command.PersonId, command.CommandId, command.OperationId)''').replace('participant.ResultFor(command.OperationId)', 'participant.SelectedResult')
s=s.replace('async ValueTask<Built> BuildAsync(PolicyDistributionCampaign campaign,', 'async ValueTask<Built> BuildAsync(PolicyCampaignSnapshot campaign,')
s=s.replace('''        catch (ImmutableContentIntegrityException exception)
        {
            return''','''        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return''')
p.write_text(s)
