from pathlib import Path
p=Path('work/src/Compliance.Core/Features/PolicyDistribution/ApplyPolicyParticipantResultHandler.cs');s=p.read_text()
a=s.index('''        var current = await reader.HydrateAsync(''');b=s.index('''        for (var attempt = 1;''',a)
old=s[a:b]
preparestart=old.index('''        ChildAdmissionIntent intent;''');prepareend=old.index('''        var built = await BuildAsync(''',preparestart)
prep=old[preparestart:prepareend]
# Private preparation returns the same typed failures; central helper rechecks native receipt knowledge on that failed result.
prep=prep.replace('return SourceUseReceiverSupport.Permanent(', 'return Result<Built>.Failure(Permanent(')
prep=prep.replace('''$"The frozen admission cannot be verified: {exception.Message}");''','''$"The frozen admission cannot be verified: {exception.Message}"));''').replace('''"The application differs from the frozen admission intent.");''','''"The application differs from the frozen admission intent."));''')
s=s[:a]+'''        var preparation = await NativeReceiverPreparation.PrepareAsync<PolicyCampaignParticipant, Built>(reader,
            () => new PolicyCampaignParticipant(tenantId, command.CampaignId, command.PersonId, command.CommandId, command.OperationId),
            owner => Decide(owner, binding), token => PrepareAsync(campaign, command, expectedHeader, token), ct)
            .ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        var built = preparation.Value.Value!;
'''+s[b:]
a=s.index('''    async ValueTask<Built> BuildAsync(''')
method='''    async ValueTask<Result<Built>> PrepareAsync(PolicyCampaignSnapshot campaign, ApplyPolicyParticipantResult command,
        DurableIntentHeader expectedHeader, CancellationToken ct)
    {
        var tenantId = campaign.TenantId;
'''+prep+'''        var built = await BuildAsync(campaign, command, intent, ct).ConfigureAwait(false);
        return built.Error is null ? Result<Built>.Success(built) : Result<Built>.Failure(built.Error);
    }

'''
s=s[:a]+method+s[a:];p.write_text(s)
