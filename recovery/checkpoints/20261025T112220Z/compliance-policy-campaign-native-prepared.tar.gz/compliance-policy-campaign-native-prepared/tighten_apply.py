from pathlib import Path
p=Path('work/src/Compliance.Core/Features/PolicyDistribution/ApplyPolicyParticipantResultHandler.cs');s=p.read_text().replace('using Bdgrz.Compliance.Features.Content;','using Bdgrz.Compliance.Features.Content;\nusing Bdgrz.Compliance.Features.Kernel;')
a=s.index('        ChildAdmissionIntent intent;');b=s.index('        for (var attempt = 1;',a)
old=s[a:b]
new='''        var expectedHeader = PolicyCampaignContent.HeaderOf(admitted.Operation, campaign.Stream, command.Target,
            admitted.Operation.AcceptedAt);
        var provenance = PolicyCampaignContent.Child(command.CommandId, nameof(ApplyPolicyParticipantResult),
            command.Source.EventId, expectedHeader, command.Target, clock.GetUtcNow());
        var binding = AcceptedOperationBinding.Of(provenance);
        var current = await reader.HydrateAsync(new PolicyCampaignParticipant(tenantId, command.CampaignId,
            command.PersonId, command.CommandId, command.OperationId), ct).ConfigureAwait(false);
        if (Decide(current, binding) is { } early)
            return early;

        ChildAdmissionIntent intent;
        try
        {
            intent = await PolicyCampaignContent.ReadAsync<ChildAdmissionIntent>(content, tenantId, command.Intent, ct)
                .ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return SourceUseReceiverSupport.Permanent($"The frozen admission cannot be verified: {exception.Message}");
        }
        if (intent.Header != expectedHeader || intent.Header.RootOperationId != command.OperationId ||
            intent.ParentId != campaign.Id || intent.ChildId != command.OperationId ||
            intent.ChildKind != ChildKindOf(command.ResultKind) || intent.ParentGeneration != (ulong)admitted.Generation ||
            intent.ParentAdmissionRevision != (ulong)admitted.Revision || intent.Header.AffectedOwner != command.Target)
            return SourceUseReceiverSupport.Permanent("The application differs from the frozen admission intent.");

        var built = await BuildAsync(campaign, command, intent, ct).ConfigureAwait(false);
        if (built.Error is not null)
            return Result<ReceiverOutcome>.Failure(built.Error);
'''
s=s[:a]+new+s[b:]
a=s.index('''                        switch (participant.Acceptance.Decide(binding))''');b=s.index('''                        var raised = command.ResultKind switch''',a)
s=s[:a]+'''                        if (Decide(participant, binding) is { } decided)
                            return AggregateOutcome.Discard(Result<Step>.Success(new Step(decided)));
'''+s[b:]
s=s.replace('''AggregateOutcome.Commit(Result<Step>.Success(new Step(
                                NativeFactReference.Of(participant.Stream, participant.Acceptance.SelectedFact!),
                                true)))''','''AggregateOutcome.Commit(Result<Step>.Success(new Step(SourceUseReceiverSupport.Applied(
                                NativeFactReference.Of(participant.Stream, participant.Acceptance.SelectedFact!)))))''')
s=s.replace('''                return step.Value!.Applied
                    ? SourceUseReceiverSupport.Applied(step.Value.Fact)
                    : SourceUseReceiverSupport.Replayed(step.Value.Fact);''','''                return step.Value!.Outcome;''')
s=s.replace('''        ChildAdmissionIntent intent, PolicyParticipantAdmissionProof proof, CancellationToken ct)''','''        ChildAdmissionIntent intent, CancellationToken ct)''')
needle='''        try
        {
            switch (command.ResultKind)'''
repl='''        try
        {
            var proofs = await PolicyCampaignContent.ReadManifestAsync<PolicyParticipantAdmissionProof>(content, tenantId,
                intent.SelectedSourceProofs, ct).ConfigureAwait(false);
            if (proofs.Count != 1)
                return Built.Failed(Permanent("The admission must name its exact material and including audience fact."));
            var proof = proofs[0];
            if (proof.Material != NativeFactReference.Of(campaign.Stream, campaign.Launch!) ||
                proof.Audience.Stream != campaign.Stream ||
                campaign.Facts.SingleOrDefault(value => value.Metadata.EventId == proof.Audience.EventId) is not { } audience ||
                audience.Metadata.AggregateVersion != proof.Audience.AggregateVersion ||
                audience is not (PolicyCampaignAudienceFrozen or PolicyCampaignAudienceAmended))
                return Built.Failed(Permanent("The admission source proof names another material or audience event."));
            switch (command.ResultKind)'''
assert needle in s;s=s.replace(needle,repl)
# Bind actual typed DTO tuples and original input hashes to the native admission header.
s=s.replace('''if (request.PersonId != command.PersonId || proof.Performer is not { } performer)''','''if (request.PersonId != command.PersonId || request.TenantId != tenantId || request.ProgramId != campaign.ProgramId ||
                            request.CampaignId != campaign.Id || request.CommandId != command.OperationId ||
                            !Original(intent, request.ExpectedCampaignRevision, request, PolicyCampaignContent.AcknowledgeCommandSchema) ||
                            proof.Performer is not { } performer)''')
s=s.replace('''if (request.PersonId != command.PersonId)
                            return Built.Failed(Permanent("The completion differs''','''if (request.PersonId != command.PersonId || request.TenantId != tenantId || request.ProgramId != campaign.ProgramId ||
                            request.CampaignId != campaign.Id || request.CommandId != command.OperationId ||
                            !Original(intent, request.ExpectedCampaignRevision, request, PolicyCampaignContent.CompletionCommandSchema))
                            return Built.Failed(Permanent("The completion differs''')
s=s.replace('''if (request.PersonId != command.PersonId ||
                            !Uuid.TryParse(header.OriginalActor.Id,''','''if (request.PersonId != command.PersonId || request.TenantId != tenantId || request.ProgramId != campaign.ProgramId ||
                            request.CampaignId != campaign.Id || request.CommandId != command.OperationId ||
                            !Original(intent, request.ExpectedCampaignRevision, request, PolicyCampaignContent.WaiverCommandSchema) ||
                            header.OriginalActor.Kind != "member" || !Uuid.TryParse(header.OriginalActor.Id,''')
s=s.replace('''    sealed record Step(NativeFactReference Fact, bool Applied);''','''    static bool Original<T>(ChildAdmissionIntent intent, long expected, T request, string schema) where T : notnull =>
        expected >= 0 && intent.Header.OriginalExpectedRevision == (ulong)expected &&
        intent.CanonicalAuthoredContent.Schema == schema && AuthoredIntentDigest.Compute(request) == intent.Header.AuthoredIntentSha256;

    static Result<ReceiverOutcome>? Decide(PolicyCampaignParticipant owner, AcceptedOperationBinding binding)
    {
        switch (owner.Acceptance.Decide(binding))
        {
            case NativeAcceptanceDecision.Replayed:
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, owner.Acceptance.SelectedFact!));
            case NativeAcceptanceDecision.Conflict:
                return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
        }
        return owner.SelectedResult is { } result
            ? SourceUseReceiverSupport.Replayed(NativeFactReference.Of(owner.Stream, result))
            : null;
    }

    sealed record Step(Result<ReceiverOutcome> Outcome);''')
p.write_text(s)
