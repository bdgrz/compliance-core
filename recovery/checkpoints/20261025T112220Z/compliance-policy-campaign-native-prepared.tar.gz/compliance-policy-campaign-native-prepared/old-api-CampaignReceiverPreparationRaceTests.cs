using Bdgrz.Compliance.Features.Content;
using Bdgrz.Compliance.Features.NativeOperations;
using Bdgrz.Compliance.Features.PolicyDistribution;
using Bdgrz.Compliance.Features.Processes;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Portia;
using Microsoft.Extensions.DependencyInjection;

namespace Bdgrz.Compliance.Tests.Features.PolicyDistribution;

public sealed class CampaignReceiverPreparationRaceTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShouldReplayReceiverReceiptOrRequestedCancellationGivenEqualWinnerBeforeIntentReadFailure(bool cancel)
    {
        // Arrange
        await using var host = new CampaignHost();
        await host.SeedAsync();
        var campaignId = await host.LaunchAsync();
        var root = Uuid.CreateVersion4();
        var admitted = await host.SendAsync(host.Acknowledge(campaignId, host.LearnerPerson, 1, root), host.Learner);
        Assert.True(admitted.IsSuccess, admitted.Error?.Message);
        var campaign = await host.CampaignAsync(campaignId);
        var fact = campaign.AdmittedFor(root)!;
        var command = new ApplyPolicyParticipantResult(Uuid.CreateVersion5(root, "apply"),
            NativeFactReference.Of(campaign.Stream, fact), PolicyCampaignParticipant.StreamOf(host.Tenant, campaignId,
                host.LearnerPerson), root, fact.Generation, null, fact.Intent, campaignId, host.LearnerPerson,
            CampaignParticipantResultKind.PolicyAcknowledgement);
        var context = new Cntryl.Portia.RequestContext<ApplyPolicyParticipantResult>(command,
            new RequestDispatchContext(RequestActor.System));
        var services = host.Scope.ServiceProvider;
        var reader = services.GetRequiredService<IAggregateReader>();
        var executor = services.GetRequiredService<IAggregateExecutor>();
        var healthy = new ApplyPolicyParticipantResultHandler(reader, executor, host.Content, host.Clock);
        using var cancellation = new CancellationTokenSource();
        var winner = Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict, "No winner yet."));
        var fault = new FaultStore(host.Content, async () =>
        {
            winner = await healthy.HandleAsync(context, CancellationToken.None);
            Assert.True(winner.IsSuccess, winner.Error?.Message);
            if (cancel)
                cancellation.Cancel();
        });
        var losing = new ApplyPolicyParticipantResultHandler(reader, executor, fault, host.Clock);
        var actual = Result<ReceiverOutcome>.Failure(new RequestError(RequestErrorKind.Conflict, "No losing result yet."));

        // Act
        var failure = await Record.ExceptionAsync(async () => actual = await losing.HandleAsync(context, cancellation.Token));
        var written = Assert.Single(await host.EventsAsync<PolicyAcknowledgementRecorded>(command.Target));

        // Assert
        Assert.True(winner.IsSuccess);
        if (cancel)
        {
            var canceled = Assert.IsAssignableFrom<OperationCanceledException>(failure);
            Assert.Equal(cancellation.Token, canceled.CancellationToken);
        }
        else
        {
            Assert.Null(failure);
            Assert.True(actual.IsSuccess, actual.Error?.Message);
            var original = Assert.IsType<ReceiverOutcome.Applied>(winner.Value);
            var replay = Assert.IsType<ReceiverOutcome.Replayed>(actual.Value);
            Assert.Equal(original.Fact, replay.Fact);
            Assert.Equal(NativeFactReference.Of(command.Target, written), replay.Fact);
        }
        Assert.Equal(root, written.Operation.RootOperationId);
        Assert.Equal(command.CommandId, written.Operation.LogicalId);
        Assert.Equal(1, (await host.ParticipantAsync(campaignId, host.LearnerPerson)).Revision);
    }

    sealed class FaultStore(IImmutableContentStore inner, Func<Task> commitWinner) : IImmutableContentStore
    {
        bool _failed;
        public Task<ImmutableContentRef> WriteVerifiedAsync(string realm, Uuid contentId, string schema, string mediaType,
            ReadOnlyMemory<byte> bytes, CancellationToken ct = default) =>
            inner.WriteVerifiedAsync(realm, contentId, schema, mediaType, bytes, ct);
        public async Task<ReadOnlyMemory<byte>> ReadVerifiedAsync(string realm, ImmutableContentRef reference,
            CancellationToken ct = default)
        {
            if (!_failed && reference.Schema == ChildAdmissionIntent.Schema)
            {
                _failed = true;
                await commitWinner();
                throw new ImmutableContentUnavailableException("The losing actual receiver intent read failed.");
            }
            return await inner.ReadVerifiedAsync(realm, reference, ct);
        }
    }
}
