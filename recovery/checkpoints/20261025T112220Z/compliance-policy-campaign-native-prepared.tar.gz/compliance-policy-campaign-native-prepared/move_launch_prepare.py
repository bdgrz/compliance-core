from pathlib import Path
p=Path('work/src/Compliance.Core/Features/PolicyDistribution/CampaignLaunch.cs');s=p.read_text().replace('sealed class CampaignLaunch(NativeOperationExecutor operations, IAggregateReader reader,\n    IImmutableContentStore content, TimeProvider clock)', 'sealed class CampaignLaunch(NativeOperationExecutor operations, IImmutableContentStore content, TimeProvider clock)')
a=s.index('        var current = await reader.HydrateAsync(');b=s.index('        ImmutableContentRef? result = null;',a)
s=s[:a]+s[b:]
a=s.index('        if (current.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)');b=s.index('        var outcome = await operations.ExecuteAsync(',a)
prepare=s[a:b]
prepare=prepare.replace('        if (current.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)\n        {\n','').removesuffix('        }\n\n')
prepare=prepare.replace('current.PrepareLaunch()', 'owner.PrepareLaunch()').replace('Result<CampaignRegistration>.Failure', 'Result<FirstResponseDescriptor>.Failure')
prepare=prepare.replace('await resolve(ct)', 'await resolve(token)').replace(', ct)', ', token)')
prepare=prepare.replace('            response = PolicyCampaignContent.OkResponse(PolicyCampaignContent.RegistrationSchema, body);','            return Result<FirstResponseDescriptor>.Success(PolicyCampaignContent.OkResponse(PolicyCampaignContent.RegistrationSchema, body));')
s=s[:a]+s[b:]
s=s.replace('''            owner => Prepare(owner, response),''','''            async (owner, token) =>
            {
'''+prepare+'''            },''')
a=s.index('    static Result<FirstResponseDescriptor> Prepare(');b=s.index('    static Result<CampaignRegistration> Failure(',a);s=s[:a]+s[b:]
p.write_text(s)
p=Path('work/test/Compliance.Tests/Features/PolicyDistribution/CampaignLaunchPreparationRaceTests.cs');s=p.read_text().replace('new CampaignLaunch(new NativeOperationExecutor(reader, executor, host.Content), reader,\n            host.Content, host.Clock)', 'new CampaignLaunch(new NativeOperationExecutor(reader, executor, host.Content),\n            host.Content, host.Clock)').replace('new CampaignLaunch(new NativeOperationExecutor(reader, executor, fault, trace), reader,\n            fault, host.Clock)', 'new CampaignLaunch(new NativeOperationExecutor(reader, executor, fault, trace),\n            fault, host.Clock)');p.write_text(s)
