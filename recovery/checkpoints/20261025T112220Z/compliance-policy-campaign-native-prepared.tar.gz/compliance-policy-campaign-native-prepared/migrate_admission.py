from pathlib import Path
r=Path('work/src/Compliance.Core/Features/PolicyDistribution')
p=r/'PolicyParticipantAdmission.cs';s=p.read_text().replace('sealed class PolicyParticipantAdmission(NativeOperationExecutor operations, IImmutableContentStore content)', 'sealed class PolicyParticipantAdmission(NativeOperationExecutor operations, IImmutableContentStore content, CampaignSource campaigns)')
s=s.replace('''        IRequestContext<TRequest> context, CampaignState state, ParticipantAdmissionPlan plan, TRequest request,''','''        IRequestContext<TRequest> context, Uuid tenantId, Uuid programId, Uuid campaignId,
        ParticipantAdmissionPlan plan, TRequest request,''')
s=s.replace('''        var campaign = state.Campaign;
        var tenantId = campaign.TenantId;
        var participant = PolicyCampaignParticipant.StreamOf(tenantId, campaign.Id, plan.PersonId);''','''        var stream = new PolicyDistributionCampaign(tenantId, campaignId).Stream;
        var participant = PolicyCampaignParticipant.StreamOf(tenantId, campaignId, plan.PersonId);''').replace('''plan.CommandKind, campaign.Stream,
            participant,''','''plan.CommandKind, stream,
            participant,''')
a=s.index('        // A logical id that was already accepted');b=s.index('        var outcome = await operations.ExecuteAsync(',a)
block=s[a:b];start=block.index('''        if (campaign.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)
        {
''');body=block[start:].replace('''        if (campaign.Acceptance.Decide(binding) == NativeAcceptanceDecision.None)
        {
''','').removesuffix('        }\n\n')
body=body.replace('Result<OperationAcceptedResponse>.Failure','Result<FirstResponseDescriptor>.Failure').replace(', ct)', ', token)')
body=body.replace('''            var member = state.Roster.FindActive(plan.PersonId)!;''','''            var member = state.Roster.FindActive(plan.PersonId)!;
            var performer = plan.Performer ?? (plan.ChildKind == AdmittedChildKind.PolicyAcknowledgement
                ? new ActorReference("workforce_person", plan.PersonId.ToString(), state.DisplayNameOf(plan.PersonId) ?? "Workforce person")
                : null);''').replace('member.IncludingFact, plan.Performer, plan.RecordedOnBehalf', 'member.IncludingFact, performer, plan.RecordedOnBehalf')
body=body.replace('''            response = await PolicyCampaignContent.AcceptedResponseAsync''','''            var response = await PolicyCampaignContent.AcceptedResponseAsync''')
s=s[:a]+'''        ImmutableContentRef? intent = null;
        PolicyCampaignPreparedCut? preparedCut = null;
'''+s[b:]
s=s.replace('''            () => new PolicyDistributionCampaign(tenantId, campaign.Id, plan.CommandId),
            owner => owner.Acceptance, owner => Prepare(owner, plan.ExpectedRevision, response),
            (PolicyDistributionCampaign owner, ImmutableContentRef frozen) =>
                owner.AdmitResult(provenance, intent!, frozen)),''','''            () => new PolicyDistributionCampaign(tenantId, campaignId, plan.CommandId),
            owner => owner.Acceptance, async (owner, token) =>
            {
                preparedCut = PolicyCampaignPreparedCut.Capture(owner);
                if (!owner.IsLaunched || owner.ProgramId != programId)
                    return Result<FirstResponseDescriptor>.Failure(new RequestError(RequestErrorKind.NotFound, "The campaign was not found."));
                var loaded = await campaigns.StateOfAsync(owner, token).ConfigureAwait(false);
                if (!loaded.IsSuccess)
                    return Result<FirstResponseDescriptor>.Failure(loaded.Error!);
                var state = loaded.Value;
                var campaign = state.Campaign;
'''+''.join('    '+line if line.strip() else line for line in body.splitlines(True))+'''                var prepared = owner.PrepareOpenAdmission(plan.ExpectedRevision);
                return prepared.IsSuccess ? Result<FirstResponseDescriptor>.Success(response)
                    : Result<FirstResponseDescriptor>.Failure(prepared.Error!);
            },
            (PolicyDistributionCampaign owner, ImmutableContentRef frozen) =>
            {
                var guarded = owner.PrepareOpenAdmission(plan.ExpectedRevision);
                if (!guarded.IsSuccess)
                    return guarded;
                return preparedCut is null || !preparedCut.Matches(owner)
                    ? PolicyCampaignPreparedCut.Changed()
                    : owner.AdmitResult(provenance, intent!, frozen);
            }),''')
a=s.index('    static Result<FirstResponseDescriptor> Prepare(');b=s.index('    static Result<OperationAcceptedResponse> Failure(',a);s=s[:a]+s[b:];p.write_text(s)
# Read only bounded campaign scope before current caller authorization, not mutable latest audience/body composition.
p=r/'CampaignSource.cs';s=p.read_text();anchor='''    internal async ValueTask<Result<CampaignState>> ReadAsync''';s=s.replace(anchor,'''    internal async ValueTask<Result<PolicyDistributionCampaign>> ReadOwnerAsync(Uuid tenantId, Uuid programId,
        Uuid campaignId, Uuid selectedLogicalId, CancellationToken ct)
    {
        var owner = await reader.HydrateAsync(new PolicyDistributionCampaign(tenantId, campaignId, selectedLogicalId), ct)
            .ConfigureAwait(false);
        _ = await PolicyCampaignHistory.ReadAsync(owner, events, ct).ConfigureAwait(false);
        return owner.IsLaunched && owner.ProgramId == programId
            ? Result<PolicyDistributionCampaign>.Success(owner)
            : Result<PolicyDistributionCampaign>.Failure(new RequestError(RequestErrorKind.NotFound, "The campaign was not found."));
    }

'''+anchor);p.write_text(s)
for name in ['AcknowledgePolicyHandler','RecordTrainingCompletionHandler','ApproveCampaignWaiverHandler']:
 p=r/(name+'.cs');s=p.read_text();s=s.replace('''var source = await campaigns.ReadAsync(request.TenantId, request.ProgramId, request.CampaignId, ct,
            request.CommandId)''','''var source = await campaigns.ReadOwnerAsync(request.TenantId, request.ProgramId, request.CampaignId,
            request.CommandId, ct)''')
 s=s.replace('''        var state = source.Value;
''','')
 s=s.replace('''        // An accepted retry is resolved from the campaign's own facts; the audience is judged when it is admitted.
        if (state.Campaign.Acceptance.SelectedFact is null && state.Roster.FindActive(request.PersonId) is null)
            return NotInAudience();
''','')
 s=s.replace('''        var performer = new ActorReference("workforce_person", request.PersonId.ToString(),
            state.DisplayNameOf(request.PersonId) ?? "Workforce person");
''','')
 s=s.replace('actor.Reference, performer, onBehalf,', 'actor.Reference, null, onBehalf,')
 s=s.replace('''admission.AdmitAsync(context, state, plan, request,''','''admission.AdmitAsync(context, request.TenantId, request.ProgramId, request.CampaignId, plan, request,''')
 s=s.replace('''admission.AdmitAsync(context, source.Value, plan, request,''','''admission.AdmitAsync(context, request.TenantId, request.ProgramId, request.CampaignId, plan, request,''')
 p.write_text(s)
