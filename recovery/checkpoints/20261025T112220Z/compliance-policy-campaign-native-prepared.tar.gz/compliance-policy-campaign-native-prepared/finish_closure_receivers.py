from pathlib import Path
r=Path('/tmp/compliance-policy-campaign-native-prepared/work/src/Compliance.Core/Features/PolicyDistribution')
p=r/'CompletePolicyCampaignClosureHandler.cs';s=p.read_text()
s=s.replace('verifier.VerifyAcceptedAsync(command.Source','verifier.ReadAcceptedAsync(command.Source')
s=s.replace('var (campaign, accepted, intent) = (closure.Campaign!, closure.Accepted!, closure.Intent!);','var (campaign, accepted) = (closure.Campaign!, closure.Accepted!);')
s=s.replace('command.Generation != accepted.Generation || command.ParticipantProofManifest != intent.SourceUses.Content)', 'command.Generation != accepted.Generation)')
s=s.replace('var provenance = PolicyCampaignContent.Child(command.CommandId, nameof(CompletePolicyCampaignClosure),\n            command.Source.EventId, intent.Header, campaign.Stream, clock.GetUtcNow());', 'var header = PolicyCampaignContent.HeaderOf(accepted.Operation, campaign.Stream, campaign.Stream,\n            accepted.Operation.AcceptedAt);\n        var provenance = PolicyCampaignContent.Child(command.CommandId, nameof(CompletePolicyCampaignClosure),\n            command.Source.EventId, header, campaign.Stream, clock.GetUtcNow());')
a=s.index('                var current = await reader.HydrateAsync(')
b=s.index('                var step = await executor.ExecuteAsync(',a)
s=s[:a]+'''                var preparation = await NativeReceiverPreparation.PrepareAsync<PolicyDistributionCampaign, Built>(reader,
                    () => new PolicyDistributionCampaign(campaign.TenantId, campaign.Id, command.CommandId,
                        selectedClosureRootId: command.OperationId), owner => Decide(owner, binding, command.OperationId),
                    (owner, token) => PrepareAsync(owner, closure, command, token), ct).ConfigureAwait(false);
                if (!preparation.IsSuccess)
                    return Result<ReceiverOutcome>.Failure(preparation.Error!);
                if (preparation.Value!.Outcome is { } known)
                    return known;
                var built = preparation.Value.Value!;
                if (built.Superseded is not null)
                    return built.Superseded.Value;
''' +s[b:]
s=s.replace('if (fresh.Revision != revision)', 'if (built.Cut is null || !built.Cut.Matches(fresh))')
s=s.replace('built.Totals!, intent.Header.OriginalActor, intent.Header.AcceptedAt, built.Proofs!,','built.Totals!, header.OriginalActor, header.AcceptedAt, built.Proofs!,')
pos=s.index('    async ValueTask<Built> BuildAsync')
s=s[:pos]+'''    async ValueTask<Result<Built>> PrepareAsync(PolicyDistributionCampaign campaign, PolicyCampaignClosure closure,
        CompletePolicyCampaignClosure command, CancellationToken ct)
    {
        var cut = PolicyCampaignPreparedCut.Capture(campaign);
        var prepared = await verifier.PrepareAsync(closure, ct).ConfigureAwait(false);
        if (prepared.Error is not null)
            return Result<Built>.Failure(prepared.Error);
        if (command.ParticipantProofManifest != prepared.Intent!.SourceUses.Content)
            return Result<Built>.Failure(SourceUseReceiverSupport.Permanent(
                "The completion differs from the frozen closure intent.").Error!);
        var built = await BuildAsync(campaign, prepared, command, ct).ConfigureAwait(false);
        return built.Error is not null ? Result<Built>.Failure(built.Error) : Result<Built>.Success(built with { Cut = cut });
    }

''' +s[pos:]
s=s.replace('CompletePolicyCampaignClosure command, OperationProvenance provenance, CancellationToken ct)', 'CompletePolicyCampaignClosure command, CancellationToken ct)')
s=s.replace('catch (ImmutableContentIntegrityException exception)\n        {\n            return Built.Failed', 'catch (ImmutableContentIntegrityException exception)\n        {\n            ct.ThrowIfCancellationRequested();\n            return Built.Failed')
s=s.replace('    {\n        public static Built Failed(RequestError error)', '    {\n        public PolicyCampaignPreparedCut? Cut { get; init; }\n\n        public static Built Failed(RequestError error)')
p.write_text(s)
p=r/'AbortPolicyCampaignClosureHandler.cs';s=p.read_text()
a=s.index('        var tenantId = PolicyCampaignContent.ParseTenant')
b=s.index('        var binding = AcceptedOperationBinding.Of(provenance);',a)
s=s[:a]+'''        if (!Uuid.TryParse(command.Target.Realm, System.Globalization.CultureInfo.InvariantCulture, out var tenantId) ||
            !Uuid.TryParse(command.Target.Resource, System.Globalization.CultureInfo.InvariantCulture, out var campaignId) ||
            command.Target.Area != PolicyDistributionCampaign.Area)
            return SourceUseReceiverSupport.Permanent("The abort names another campaign stream.");
        var campaign = await new PolicyCampaignReader(reader, events).ReadAsync(tenantId, campaignId,
            command.CommandId, selectedClosureRootId: command.OperationId, ct: ct).ConfigureAwait(false);
        if (campaign.Stream != command.Target || campaign.Owner.SelectedClosure is not { } accepted ||
            accepted.Intent != command.FailureProof || accepted.Revision != command.ExpectedRevision ||
            accepted.Generation != command.Generation)
            return SourceUseReceiverSupport.Permanent("An abort requires the exact frozen closure of its campaign.");
        var header = PolicyCampaignContent.HeaderOf(accepted.Operation, campaign.Stream, campaign.Stream,
            accepted.Operation.AcceptedAt);
        var provenance = PolicyCampaignContent.Child(command.CommandId, nameof(AbortPolicyCampaignClosure),
            accepted.Metadata.EventId, header, campaign.Stream, clock.GetUtcNow());
''' +s[b:]
s=s.replace('        for (var attempt = 1; ; attempt++)', '''        var preparation = await NativeReceiverPreparation.PrepareAsync<PolicyDistributionCampaign, ClosureIntent>(reader,
            () => new PolicyDistributionCampaign(tenantId, campaignId, command.CommandId,
                selectedClosureRootId: command.OperationId), owner => Decide(owner, binding, command.OperationId),
            (_, token) => PrepareAsync(tenantId, campaignId, accepted, command, header, token), ct).ConfigureAwait(false);
        if (!preparation.IsSuccess)
            return Result<ReceiverOutcome>.Failure(preparation.Error!);
        if (preparation.Value!.Outcome is { } known)
            return known;
        for (var attempt = 1; ; attempt++)''',1)
s=s.replace('new PolicyDistributionCampaign(tenantId, intent.ParentId,','new PolicyDistributionCampaign(tenantId, campaignId,')
a=s.index('                        switch (pending.Acceptance.Decide(binding))')
b=s.index('                        var raised = pending.CancelClosure',a)
s=s[:a]+'''                        if (Decide(pending, binding, command.OperationId) is { } decided)
                            return AggregateOutcome.Discard(Result<Step>.Success(new Step(decided)));
''' +s[b:]
s=s.replace('''? AggregateOutcome.Commit(Result<Step>.Success(new Step(
                                NativeFactReference.Of(pending.Stream, pending.Acceptance.SelectedFact!), true,
                                false)))''','''? AggregateOutcome.Commit(Result<Step>.Success(new Step(SourceUseReceiverSupport.Applied(
                                NativeFactReference.Of(pending.Stream, pending.Acceptance.SelectedFact!)))))''')
a=s.index('                if (step.Value!.Foreign)')
b=s.index('\n            }\n            catch',a)
s=s[:a]+'''                return step.Value!.Outcome;''' +s[b:]
a=s.index('    /// <summary>Fact is the appended')
s=s[:a]+'''    async ValueTask<Result<ClosureIntent>> PrepareAsync(Uuid tenantId, Uuid campaignId,
        PolicyCampaignClosureAccepted accepted, AbortPolicyCampaignClosure command, DurableIntentHeader header,
        CancellationToken ct)
    {
        ClosureIntent intent;
        try
        {
            intent = await PolicyCampaignContent.ReadAsync<ClosureIntent>(content, tenantId, command.FailureProof, ct)
                .ConfigureAwait(false);
        }
        catch (ImmutableContentIntegrityException exception)
        {
            ct.ThrowIfCancellationRequested();
            return Result<ClosureIntent>.Failure(SourceUseReceiverSupport.Permanent(
                $"The frozen closure cannot be verified: {exception.Message}").Error!);
        }
        return intent.Header != header || intent.ParentKind != ClosureParentKind.PolicyCampaign ||
            intent.ParentId != campaignId || intent.ParentGeneration != (ulong)accepted.Generation
            ? Result<ClosureIntent>.Failure(SourceUseReceiverSupport.Permanent(
                "The abort differs from the frozen closure intent.").Error!)
            : Result<ClosureIntent>.Success(intent);
    }

    static Result<ReceiverOutcome>? Decide(PolicyDistributionCampaign campaign, AcceptedOperationBinding binding,
        Uuid operationId)
    {
        switch (campaign.Acceptance.Decide(binding))
        {
            case NativeAcceptanceDecision.Replayed:
                return SourceUseReceiverSupport.Replayed(NativeFactReference.Of(campaign.Stream, campaign.Acceptance.SelectedFact!));
            case NativeAcceptanceDecision.Conflict:
                return Result<ReceiverOutcome>.Failure(AcceptedAppendResult.ConflictError);
        }
        if (campaign.SelectedCancellation is { } canceled)
            return SourceUseReceiverSupport.Superseded("The closure was already canceled.",
                NativeFactReference.Of(campaign.Stream, canceled));
        return campaign.Closing is { } closed && closed.Operation.RootOperationId == operationId
            ? SourceUseReceiverSupport.Superseded("The closure already completed and recovers forward.")
            : null;
    }

    sealed record Step(Result<ReceiverOutcome> Outcome);
}
'''
p.write_text(s)
