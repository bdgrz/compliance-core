from pathlib import Path
r=Path('work/src/Compliance.Core/Features/PolicyDistribution')
for name in ['AdvisorReplayDigest','AdvisorReplayCut']:
 source=Path('/tmp/compliance-advisor-history-prepared/work/src/Compliance.Core/Features/AdvisorCollaboration')/(name+'.cs')
 s=source.read_text().replace('Features.AdvisorCollaboration','Features.PolicyDistribution').replace('AdvisorReplayDigest','PolicyCampaignReplayDigest').replace('AdvisorReplayCut','PolicyCampaignReplayCut').replace('advisor','policy campaign')
 (r/(name.replace('Advisor','PolicyCampaign')+'.cs')).write_text(s)
p=r/'PolicyDistributionCampaign.cs';s=p.read_text()
a=s.index('    readonly List<PolicyCampaignAudienceAmended>');b=s.index('    PolicyCampaignLaunched? _launch;',a)
s=s[:a]+'''    readonly PolicyCampaignReplayCut _cut = new();
    long _generation = 1;
    long _admissionCount;

'''+s[b:]
s=s.replace('Uuid selectedLogicalId = default)\n', 'Uuid selectedLogicalId = default,\n        Uuid selectedRosterSnapshotId = default, Uuid selectedClosureRootId = default)\n',1)
s=s.replace('''        _tenantId = tenantId;
        Acceptance''','''        _tenantId = tenantId;
        SelectedRosterSnapshotId = selectedRosterSnapshotId;
        SelectedClosureRootId = selectedClosureRootId;
        Acceptance''')
s=s.replace('            _reconciledSnapshots.Add(ev.RosterSnapshotId);\n','')
s=s.replace('''ev.Operation.Owner != Stream || ev.Reconciliation != _reconciliations + 1 || ev.Batch != 1 ||
                !_reconciledSnapshots.Add(ev.RosterSnapshotId))''','''ev.Operation.Owner != Stream || ev.Reconciliation != _reconciliations + 1 || ev.Batch != 1)''')
s=s.replace('            _amendments.Add(ev);\n','')
s=s.replace('''ev.Revision != _revision + 1 || ev.Generation != Generation ||
                !_admittedByRoot.TryAdd(ev.Operation.RootOperationId, ev) || ev.FirstResponse is null)''','''ev.Revision != _revision + 1 || ev.Generation != Generation || ev.FirstResponse is null)''')
s=s.replace('            _admitted.Add(ev);','            _admissionCount++;')
s=s.replace('''ev.Revision != _revision + 1 || ev.Generation != Generation || ev.FirstResponse is null ||
                !_closures.TryAdd(ev.Operation.RootOperationId, ev))''','''ev.Revision != _revision + 1 || ev.Generation != Generation || ev.FirstResponse is null)''')
s=s.replace('            _canceled.Add(ev.Operation.RootOperationId, ev);','            _generation++;')
s=s.replace('public long Generation => _canceled.Count + 1;', 'public long Generation => _generation;')
a=s.index('    /// <summary>Every reconciliation in order.</summary>');b=s.index('    /// <summary>The accepted closure that is neither completed nor canceled.</summary>',a);s=s[:a]+s[b:]
a=s.index('    /// <summary>True when a roster snapshot was already reconciled');b=s.index('    /// <summary>The result kind an admission carries',a);s=s[:a]+s[b:]
anchor='''    /// <summary>The roster snapshot the audience was last reconciled against.</summary>'''
s=s.replace(anchor,'''    internal PolicyCampaignReplayCut ReplayCut => _cut;
    internal Uuid SelectedRosterSnapshotId { get; }
    internal bool SelectedRosterSnapshotSeen { get; set; }
    internal Uuid SelectedClosureRootId { get; }
    internal PolicyCampaignClosureAccepted? SelectedClosure { get; set; }
    internal PolicyCampaignClosureCanceled? SelectedCancellation { get; set; }
    public long AdmissionCount => _admissionCount;

'''+anchor)
s=s.replace('''        if (_reconciledSnapshots.Contains(rosterSnapshotId))
            return Conflict("The campaign already reconciled that roster snapshot.");''','''        if (SelectedRosterSnapshotId != rosterSnapshotId)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "A reconciliation requires its exact selected roster snapshot at the finalized native cut.", true));
        if (SelectedRosterSnapshotSeen)
            return Conflict("The campaign already reconciled that roster snapshot.");''')
# Every public business append is checked before its first native fact. Frozen is the atomic launch follow-up.
for typ in ['PolicyCampaignLaunched','PolicyCampaignAudienceAmended','PolicyParticipantResultAdmitted','PolicyCampaignClosureAccepted','PolicyCampaignClosureCanceled','PolicyCampaignClosed']:
 needle='        RaiseEvent(new '+typ+'('
 assert s.count(needle)==1,(typ,s.count(needle))
 s=s.replace(needle,'''        var append = _cut.Require(this, Acceptance, operation);
        if (!append.IsSuccess)
            return append;
'''+needle)
s=s.replace('''            Acceptance.Observe(ev);''','''            if (ev.Operation is null)
                throw new Bdgrz.Compliance.Features.Content.ImmutableContentIntegrityException("The native campaign fact lacks operation provenance.");
            if (Acceptance.SelectedFact is not null && Acceptance.SelectedLogicalId == ev.Operation.LogicalId)
                throw new Bdgrz.Compliance.Features.Content.ImmutableContentIntegrityException("The selected native campaign operation occurs more than once.");
            Acceptance.Observe(ev);''')
s=s.replace('throw new InvalidOperationException(', 'throw new ImmutableContentIntegrityException(')
anchor='''    Result Stale() =>'''
s=s.replace(anchor,'''    protected override void Apply(DomainEvent ev)
    {
        _cut.Observe(ev);
        base.Apply(ev);
    }

'''+anchor)
p.write_text(s)
p=r/'PolicyCampaignParticipant.cs';s=p.read_text().replace('using Bdgrz.Compliance.Features.AccessControl;','using Bdgrz.Compliance.Features.AccessControl;\nusing Bdgrz.Compliance.Features.Content;')
a=s.index('    readonly List<DomainEvent>');b=s.index('    /// <summary>Opens the participant',a)
s=s[:a]+'''    readonly PolicyCampaignReplayCut _cut = new();
    long _revision;
    bool _hasAcknowledgement;
    bool _hasCompletion;

'''+s[b:]
s=s.replace('Uuid selectedLogicalId = default)\n', 'Uuid selectedLogicalId = default, Uuid selectedResultRootId = default)\n',1)
s=s.replace('''        Acceptance = new NativeAcceptance(selectedLogicalId);''','''        SelectedResultRootId = selectedResultRootId;
        Acceptance = new NativeAcceptance(selectedLogicalId);''')
s=s.replace('_acknowledgement is not null','_hasAcknowledgement').replace('_completion is not null','_hasCompletion')
s=s.replace('            _acknowledgement = ev;','            _hasAcknowledgement = true;').replace('            _completion = ev;','            _hasCompletion = true;')
s=s.replace('            _waivers.Add(ev);\n','').replace('granted.Revision != _results.Count','granted.Revision != _revision')
s=s.replace('public long Revision => _results.Count;', 'public long Revision => _revision;')
a=s.index('    /// <summary>The applied acknowledgement, if any.</summary>');b=s.index('    /// <summary>The identity of the participant',a)
s=s[:a]+'''    internal PolicyCampaignReplayCut ReplayCut => _cut;
    internal Uuid SelectedResultRootId { get; }
    internal DomainEvent? SelectedResult { get; set; }
    public bool HasAcknowledgement => _hasAcknowledgement;
    public bool HasCompletion => _hasCompletion;

'''+s[b:]
a=s.index('    /// <summary>The applied result of an admission, by the root');b=s.index('    /// <summary>Applies an admitted acknowledgement',a);s=s[:a]+s[b:]
s=s.replace('''        if (_byRoot.ContainsKey(operation.RootOperationId))
            return Conflict("The admitted result was already applied to this participant.");
        return Uses.HasActiveUse
            ? Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The participant is held by a campaign closure; its results can no longer change.", true))
            : Result.Success;''','''        if (SelectedResultRootId == operation.RootOperationId && SelectedResult is not null)
            return Conflict("The admitted result was already applied to this participant.");
        if (Uses.HasActiveUse)
            return Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "The participant is held by a campaign closure; its results can no longer change.", true));
        var append = _cut.Require(this, Acceptance, operation);
        if (!append.IsSuccess)
            return append;
        return SelectedResultRootId == operation.RootOperationId || Version == 0 && CommittedStreamPosition == 0
            ? Result.Success
            : Result.Failure(new RequestError(RequestErrorKind.Conflict,
                "A participant application requires its exact selected admitted root at the finalized native cut.", true));''')
s=s.replace('''tenantId == TenantId && campaignId == CampaignId && personId == PersonId && operation.Owner == Stream &&
        !_byRoot.ContainsKey(operation.RootOperationId);''','''tenantId == TenantId && campaignId == CampaignId && personId == PersonId && operation.Owner == Stream;''')
s=s.replace('''        _results.Add(fact);
        _byRoot.Add(operation.RootOperationId, fact);''','''        _revision++;
        if (operation.RootOperationId == SelectedResultRootId)
            SelectedResult = fact;''')
s=s.replace('''        base.Apply(ev);
        Uses.ObserveOwnerFact(ev);''','''        _cut.Observe(ev);
        base.Apply(ev);
        Uses.ObserveOwnerFact(ev);''')
for name in ['ev','granted','settled']:
 needle='            Acceptance.Observe('+name+');'
 s=s.replace(needle,'''            if ('''+name+'''.Operation is null)
                throw new ImmutableContentIntegrityException("The native participant fact lacks operation provenance.");
            if (Acceptance.SelectedFact is not null && Acceptance.SelectedLogicalId == '''+name+'''.Operation.LogicalId)
                throw new ImmutableContentIntegrityException("The selected native participant operation occurs more than once.");
'''+needle)
s=s.replace('throw new InvalidOperationException(', 'throw new ImmutableContentIntegrityException(')
p.write_text(s)
