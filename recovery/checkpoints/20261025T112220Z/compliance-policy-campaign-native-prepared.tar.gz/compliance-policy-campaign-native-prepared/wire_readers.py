from pathlib import Path
import hashlib,json,re
r=Path('work');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');meta=json.loads(Path('baselines.json').read_text())
shared='test/Compliance.Tests/Testing/ProgramManagementServices.cs'
if not (Path('base')/shared).exists():
 data=(repo/shared).read_bytes()
 for root in [Path('base'),r]:
  f=root/shared;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 meta.append({'path':shared,'baselineSource':str(repo/shared),'beforeSha256':hashlib.sha256(data).hexdigest(),'acceptanceNames':re.findall(r'\b(Should\w+)\s*\(',data.decode())})
Path('baselines.json').write_text(json.dumps(meta,indent=2)+'\n')
p=r/'src/Compliance.Core/ComplianceServiceCollectionExtensions.cs';s=p.read_text().replace('        services.AddScoped<CampaignSource>();','        services.AddScoped<CampaignSource>();\n        services.AddScoped<PolicyCampaignReader>();');p.write_text(s)
p=r/'src/Compliance.Core/Hosting/Persistence/PersistenceServiceCollectionExtensions.cs';s=p.read_text();s='using Bdgrz.Compliance.Features.PolicyDistribution;\n'+s;needle='        Decorate<IRequestBus>(services, (_, inner) => new PersistenceValidationRequestBus(inner));';assert s.count(needle)==1;s=s.replace(needle,'''        Decorate<IAggregateReader>(services, (provider, inner) =>
            new PolicyCampaignAggregateReader(inner, provider.GetRequiredService<IDomainEventReader>()));
'''+needle);p.write_text(s)
# Same opaque-key lifetime/disposal semantics as the root's verified source-use fixture helper.
s=(repo/'test/Compliance.Tests/Testing/VerifiedSourceUseServices.cs').read_text().replace('Features.SourceUse','Features.PolicyDistribution').replace('VerifiedSourceUseServices','VerifiedPolicyCampaignServices').replace('AddVerifiedSourceUseReader','AddVerifiedPolicyCampaignReader').replace('SourceUseAggregateReader','PolicyCampaignAggregateReader')
(r/'test/Compliance.Tests/Testing/VerifiedPolicyCampaignServices.cs').write_text(s)
p=r/shared;s=p.read_text().replace('        collection.AddVerifiedSourceUseReader();','        collection.AddVerifiedSourceUseReader();\n        collection.AddVerifiedPolicyCampaignReader();');p.write_text(s)
p=r/'test/Compliance.Tests/Testing/CampaignOwnerHarness.cs';s=p.read_text().replace('        services.AddPortia();','        services.AddPortia();\n        services.AddVerifiedSourceUseReader();\n        services.AddVerifiedPolicyCampaignReader();');p.write_text(s)
for name in ['CampaignHost','CampaignOwnerHarness']:
 p=r/'test/Compliance.Tests/Testing'/(name+'.cs');s=p.read_text().replace('scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()).ReadAsync(', 'scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(),\n            scope.ServiceProvider.GetRequiredService<IDomainEventReader>()).ReadAsync(');p.write_text(s)
p=r/'test/Compliance.Tests/Testing/CampaignSeed.cs';s=p.read_text().replace('new CampaignSource(reader, content)', 'new CampaignSource(reader, content, scope.ServiceProvider.GetRequiredService<IDomainEventReader>())');p.write_text(s)
p=r/'test/Compliance.Tests/Features/Examinations/PolicyCommunicationTypeIBaselineSourceContributorTests.cs';s=p.read_text().replace('new CampaignSource(reader, content)', 'new CampaignSource(reader, content, _events)');p.write_text(s)
p=r/'test/Compliance.Tests/Features/PolicyDistribution/PersonalCampaignWaiverTransportTests.cs';s=p.read_text().replace('scope.ServiceProvider.GetRequiredService<IImmutableContentStore>()).ReadAsync(', 'scope.ServiceProvider.GetRequiredService<IImmutableContentStore>(), scope.ServiceProvider.GetRequiredService<IDomainEventReader>()).ReadAsync(');p.write_text(s)
p=r/'test/Compliance.Tests/Features/PolicyDistribution/CampaignAdmissionTests.cs';s=p.read_text().replace('new CampaignSource(reader, content)', 'new CampaignSource(reader, content, scope.ServiceProvider.GetRequiredService<IDomainEventReader>())');p.write_text(s)
p=Path('static_audit.py');s=p.read_text().replace("if n.startswith(('PolicyDistributionCampaign','PolicyCampaignParticipant','CampaignLaunch','CampaignSubject','RosterAudience','RosterMatch'))", "if n.startswith(('PolicyDistributionCampaign','PolicyCampaign','PolicyParticipant','Campaign','FitzCampaign','RosterAudience','RosterMatch'))");p.write_text(s)
