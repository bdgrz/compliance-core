from pathlib import Path
import json,hashlib,difflib,tempfile,subprocess,shutil
from tree_sitter import Language,Parser
import tree_sitter_c_sharp
r=Path('/tmp/compliance-mapping-member-binding-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core');paths=['src/Compliance.Core/Features/ControlMappings/MappingLineTransitions.cs','test/Compliance.Tests/Features/ControlMappings/ApplicabilityNativeActorBindingTests.cs'];sha=lambda b:hashlib.sha256(b).hexdigest();parser=Parser(Language(tree_sitter_c_sharp.language()));syntax=[];manifest=[];full='';clean=''
for p in paths:
 before=(r/'base'/p).read_bytes();after=(r/'work'/p).read_bytes();assert(repo/p).read_bytes()==before,p
 tree=parser.parse(after);nodes=[tree.root_node]
 while nodes:
  n=nodes.pop();nodes.extend(n.children)
  if n.type=='ERROR' or n.is_missing:syntax.append({'path':p,'line':after[:n.start_byte].count(b'\n')+1})
 diff=lambda a,z,fr='a/'+p:''.join(difflib.unified_diff(a.decode().splitlines(True),z.decode().splitlines(True),fromfile=fr,tofile='b/'+p))
 d=diff(before,after);full+=d;clean+=diff(b'',after,'/dev/null') if p.startswith('test/') else d
 if p.startswith('test/'):(r/'tests-green.patch').write_text(d)
 manifest.append({'path':p,'beforeSha256':sha(before),'afterSha256':sha(after),'baselineSource':str(repo/p),'baselineStage':'current-v3 source' if p.startswith('src/') else 'qualified-current-v3 RED installed','beforeAssertions':before.count(b'Assert.') if p.startswith('test/') else None,'afterAssertions':after.count(b'Assert.') if p.startswith('test/') else None})
assert not syntax,syntax
(r/'full.patch').write_text(full);(r/'full-from-clean.patch').write_text(clean);(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
orders={'red-then-green':['tests-red-compilable.patch','implementation.patch','tests-green.patch'],'source-after-red':['implementation.patch','tests-green.patch'],'full-after-red':['full.patch'],'full-clean':['full-from-clean.patch']};out={}
for mode,order in orders.items():
 t=Path(tempfile.mkdtemp(prefix='mapping-member-reconstruct-',dir=r))
 try:
  for p in paths:
   if mode in ['red-then-green','full-clean'] and p.startswith('test/'):continue
   f=t/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((r/'base'/p).read_bytes())
  for patch in order:
   x=subprocess.run(['patch','-p1','--batch','--forward','-i',str(r/patch)],cwd=t,capture_output=True,text=True);assert x.returncode==0,(mode,x.stdout,x.stderr)
  assert all((t/p).read_bytes()==(r/'work'/p).read_bytes() for p in paths)
  out[mode]={'exactFiles':2,'patchOrder':order}
 finally:shutil.rmtree(t)
(r/'reconstruction.json').write_text(json.dumps(out,indent=2)+'\n');(r/'audit.json').write_text(json.dumps({'staticOnly':True,'paths':2,'syntaxErrors':syntax,'existingChangedPathsMissingOriginal':[],'constructorInspection':'Current-v3 CriterionApplicabilityRules4 required, owner4+optional selection, primaryActorReference3, MappingLine aggregate-reader helper existing current-main DI; no ctor contract change.','cancellationTokenLast':True,'newTestMethod':'ShouldRejectForgedProposerAuthorityGivenCoherentNativeAndImmutableHeaders','rows':6,'sourceScope':'Only CriterionNotApplicableProposed member kind/id equals actual explicit Actor. Mapping computed-Actor cases untouched.','greenTestOnlyAddition':'Explicitly proves typed immutable-body decoding and current-value validation succeed for coherent forged payload before raw-actor assertion.'},indent=2)+'\n')
h={'root':str(r),'status':'FROZEN current-v3 narrow actor/proposer authority binding follow-up; parent runs actual RED6 before source, then GREEN/review.','paths':2,'sourcePaths':1,'testPaths':1,'manifest':'manifest.json','manifestSha256':sha((r/'manifest.json').read_bytes()),'patches':{n:{'sha256':sha((r/n).read_bytes()),'bytes':(r/n).stat().st_size} for n in ['tests-red.patch','tests-red-compilable.patch','implementation.patch','tests-green.patch','full.patch','full-from-clean.patch']},'afterOriginalRed':['implementation.patch','tests-green.patch'],'freshRedThenGreen':orders['red-then-green'],'filter':'FullyQualifiedName~ApplicabilityNativeActorBindingTests','readme':'README.md','audit':'audit.json','reconstruction':'reconstruction.json','noRuntimeOrJevClaims':True}
(r/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print('handoff',sha((r/'handoff.json').read_bytes()));print('manifest',h['manifestSha256']);print(json.dumps(h['patches'],indent=2))
