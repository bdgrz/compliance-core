from pathlib import Path
root=Path('/tmp/compliance-baseline-identity-prepared/work')
def edit(name,replacements):
 p=root/name;s=p.read_text()
 for a,b in replacements:
  assert a in s,(name,a);s=s.replace(a,b)
 p.write_text(s)
edit('src/Compliance.Core/Features/Examinations/ExaminationEngagementDirectorySchema.cs',[
('KvDirectory<TypeIBaselineView, Uuid> Baselines','KvDirectory<TypeIBaselineView, string> Baselines'),
('    public static readonly KvDirectory<TypeIBaselineView, string> Baselines','    public static readonly KvDirectoryIndex<TypeIBaselineView> ByProgramBaseline = new("by_program_baseline", 1,\n        static baseline => [baseline.ProgramId.ToString(), baseline.TypeIBaselineId.ToString(), baseline.ExaminationEngagementId.ToString()]);\n\n    public static readonly KvDirectory<TypeIBaselineView, string> Baselines'),
('static baseline => baseline.TypeIBaselineId,\n        static baselineId => [baselineId.ToString()], []);','static baseline => BaselineKey(baseline.ExaminationEngagementId, baseline.TypeIBaselineId),\n        static key => [key], [ByProgramBaseline]);\n\n    public static string BaselineKey(Uuid engagementId, Uuid baselineId) => $"{engagementId}:{baselineId}";')])
edit('src/Compliance.Core/Features/Examinations/IExaminationEngagementDirectoryReader.cs',[
('    ValueTask<ExaminationEngagementView?> GetAsync','    ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId, CancellationToken ct = default);\n\n    ValueTask<ExaminationEngagementView?> GetAsync'),
('GetBaselineAsync(Uuid tenantId, Uuid typeIBaselineId,','GetBaselineAsync(Uuid tenantId, Uuid examinationEngagementId, Uuid typeIBaselineId,'),
('''        CancellationToken ct = default);
}''','''        CancellationToken ct = default);

    /// <summary>At most two exact owning baseline matches; two matches retain ambiguity without choosing an engagement.</summary>
    ValueTask<IReadOnlyList<TypeIBaselineView>> FindBaselinesAsync(Uuid tenantId, Uuid programId, Uuid typeIBaselineId,
        CancellationToken ct = default);
}''')])
edit('src/Compliance.Core/Features/Examinations/ExaminationEngagementDirectoryProjector.cs',[
('EventStreamPattern.ForTenant(),','EventStreamPattern.ForTenant("examinations"),')])
edit('src/Compliance.Core/Features/Examinations/FitzExaminationEngagementDirectory.cs',[
('using Cntryl.Fitz;','using System.Globalization;\nusing Cntryl.Fitz;'),
('projection-v2','projection-v3'),('ExaminationEngagementDirectoryV2','ExaminationEngagementDirectoryV3'),
('    public async ValueTask ApplyAsync','''    Uuid? _batchTenantId;

    public new ValueTask<IProjectionBatch> BeginAsync(ProjectionBatchContext context, CancellationToken ct = default) =>
        BeginTenantBatchAsync(context, ct);

    ValueTask<IProjectionBatch> IProjectionStore.BeginAsync(ProjectionBatchContext context, CancellationToken ct) =>
        BeginTenantBatchAsync(context, ct);

    async ValueTask<IProjectionBatch> BeginTenantBatchAsync(ProjectionBatchContext context, CancellationToken ct)
    {
        if (context.Identity.Pattern.Area != "examinations" || context.Identity.Pattern.Resource is not null ||
            !Uuid.TryParse(context.Identity.Pattern.Realm, CultureInfo.InvariantCulture, out var tenant) || tenant == Uuid.Empty)
            throw new InvalidOperationException("An examination directory batch requires its exact tenant examination area.");
        var batch = await base.BeginAsync(context, ct).ConfigureAwait(false);
        _batchTenantId = tenant;
        return batch;
    }

    public async ValueTask ApplyAsync'''),
('if (tenantId == Uuid.Empty || engagement.TenantId != tenantId ||','if (tenantId == Uuid.Empty || _batchTenantId != tenantId || engagement.TenantId != tenantId ||'),
('''                    predecessorId, ct).ConfigureAwait(false);''','''                    ExaminationEngagementDirectorySchema.BaselineKey(baseline.ExaminationEngagementId, predecessorId), ct).ConfigureAwait(false);'''),
('''            baseline.TypeIBaselineId, ct).ConfigureAwait(false);''','''            ExaminationEngagementDirectorySchema.BaselineKey(baseline.ExaminationEngagementId, baseline.TypeIBaselineId), ct).ConfigureAwait(false);'''),
('''    public async ValueTask<TypeIBaselineView?> GetBaselineAsync(Uuid tenantId,
        Uuid typeIBaselineId, CancellationToken ct = default)''','''    public async ValueTask<TypeIBaselineView?> GetBaselineAsync(Uuid tenantId,
        Uuid examinationEngagementId, Uuid typeIBaselineId, CancellationToken ct = default)'''),
('''            typeIBaselineId, ct).ConfigureAwait(false);''','''            ExaminationEngagementDirectorySchema.BaselineKey(examinationEngagementId, typeIBaselineId), ct).ConfigureAwait(false);'''),
('''    public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync''','''    public async ValueTask<IReadOnlyList<TypeIBaselineView>> FindBaselinesAsync(Uuid tenantId, Uuid programId,
        Uuid typeIBaselineId, CancellationToken ct = default)
    {
        await using var tx = await BeginReadAsync(tenantId.ToString(), ct).ConfigureAwait(false);
        var matches = await ExaminationEngagementDirectorySchema.Baselines.QueryAsync(tx,
            ExaminationEngagementDirectorySchema.ByProgramBaseline.Query().WithPrefix(programId.ToString(), typeIBaselineId.ToString())
                .Take(2), ct).ConfigureAwait(false);
        return matches.Items;
    }

    public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync'''),
('EventStreamPattern.ForPattern(tenantId.ToString())), ct);','EventStreamPattern.ForPattern(tenantId.ToString(), "examinations")), ct);')])
edit('src/Compliance.Core/Features/Examinations/GetTypeIBaselineHandler.cs',[
('public sealed class GetTypeIBaselineHandler(IExaminationEngagementDirectoryReader directory,','public sealed class GetTypeIBaselineHandler(IExaminationEngagementDirectoryReader directory, IDomainEventReader events,'),
('''        var baseline = await directory.GetBaselineAsync(request.TenantId,
            request.TypeIBaselineId, ct).ConfigureAwait(false);
        if (baseline is not { } view || view.TenantId != request.TenantId ||''','''        var before = await directory.LoadCheckpointAsync(request.TenantId, ct).ConfigureAwait(false);
        if (await HasPendingSourceAsync(request.TenantId, before, ct).ConfigureAwait(false))
            return BehindSource();
        var matches = await directory.FindBaselinesAsync(request.TenantId, request.ProgramId,
            request.TypeIBaselineId, ct).ConfigureAwait(false);
        if (matches.Count > 2 || matches.Any(row => row.TenantId != request.TenantId || row.ProgramId != request.ProgramId ||
            row.TypeIBaselineId != request.TypeIBaselineId || row.ExaminationEngagementId == Uuid.Empty) ||
            matches.Select(row => row.ExaminationEngagementId).Distinct().Count() != matches.Count)
            return Result<TypeIBaselineView>.Failure(new RequestError(RequestErrorKind.Conflict, "The baseline locator returned invalid owner scope."));
        var after = await directory.LoadCheckpointAsync(request.TenantId, ct).ConfigureAwait(false);
        if (before != after || await HasPendingSourceAsync(request.TenantId, after, ct).ConfigureAwait(false))
            return BehindSource();
        if (matches.Count > 1)
            return Result<TypeIBaselineView>.Failure(new RequestError(RequestErrorKind.Conflict,
                "The baseline identity belongs to more than one examination in the requested program."));
        var baseline = matches.Count == 0 ? null : await directory.GetBaselineAsync(request.TenantId,
            matches[0].ExaminationEngagementId, request.TypeIBaselineId, ct).ConfigureAwait(false);
        if (baseline is not { } view || view.TenantId != request.TenantId ||'''),
('''view.ProgramId != request.ProgramId || view.TypeIBaselineId != request.TypeIBaselineId)''','''view.ProgramId != request.ProgramId || view.TypeIBaselineId != request.TypeIBaselineId ||
            view.ExaminationEngagementId != matches[0].ExaminationEngagementId)'''),
('''    }
}''','''    }

    async ValueTask<bool> HasPendingSourceAsync(Uuid tenantId, ProjectionCheckpoint checkpoint, CancellationToken ct)
    {
        await using var pending = events.ReadAsync(EventStreamPattern.ForPattern(tenantId.ToString(), "examinations"),
            checkpoint.Cursor, ct).GetAsyncEnumerator(ct);
        return await pending.MoveNextAsync().ConfigureAwait(false);
    }

    static Result<TypeIBaselineView> BehindSource() => Result<TypeIBaselineView>.Failure(new RequestError(RequestErrorKind.Conflict,
        "The examination baseline directory changed or has not reached its exact source. Retry the read.", true));
}''')])
print('Prepared exact owner-scoped baseline keys/lineage, ambiguity-preserving lookup, and tenant-examination source fence.')
