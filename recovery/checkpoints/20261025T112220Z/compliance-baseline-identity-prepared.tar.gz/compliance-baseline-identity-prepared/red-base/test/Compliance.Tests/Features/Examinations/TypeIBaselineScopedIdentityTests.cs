using System.Text.Json;
using Bdgrz.Compliance.Features.Proofs;
using Bdgrz.Compliance.Features.Examinations;
using Bdgrz.Compliance.Tests.Testing;
using Cntryl.Fitz.Testing;
using Cntryl.Portia;
using Cntryl.Portia.Testing;

namespace Bdgrz.Compliance.Tests.Features.Examinations;

public sealed class TypeIBaselineScopedIdentityTests
{
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task ShouldPreserveBothOwnerLineagesGivenReusedBaselineAndAmendmentIds(bool differentPrograms, bool amend)
    {
        // Arrange
        var source = await Sources.CreateAsync(differentPrograms, amend);
        var directory = new FitzExaminationEngagementDirectory(new InMemoryKvClient());

        // Act
        await source.ProjectAsync(directory);

        // Assert
        foreach (var owner in source.Owners)
        {
            var current = await directory.GetAsync(source.Tenant, owner.Id);
            Assert.Equal(JsonSerializer.Serialize(owner.Current, ComplianceCoreJsonContext.Default.ExaminationEngagementView),
                JsonSerializer.Serialize(current, ComplianceCoreJsonContext.Default.ExaminationEngagementView));
            Assert.Equal("baseline_frozen", current!.Status);
            Assert.Equal(amend ? 2 : 1, owner.Baseline!.Revision);
        }
        Assert.Equal(source.SharedBaseline, source.Owners[0].BaselineHistory[0].TypeIBaselineId);
        Assert.Equal(source.SharedBaseline, source.Owners[1].BaselineHistory[0].TypeIBaselineId);
    }

    [Fact]
    public async Task ShouldRejectConflictingReplayGivenOnlyFrozenSourceProofDescriptorChanged()
    {
        // Arrange
        var source = await Sources.CreateAsync(false, false, 1);
        var directory = new FitzExaminationEngagementDirectory(new InMemoryKvClient());
        await source.ProjectAsync(directory);
        var owner = source.Owners[0];
        var changed = owner.Baseline! with
        {
            SourceContentManifest = new ImmutableContentRef(Uuid.CreateVersion4(), new string('d', 64), 100,
                "application/json", "snapshot-source-publication-manifest.v1"),
        };
        var identity = new CheckpointIdentity(FitzExaminationEngagementDirectory.ProjectorName,
            EventStreamPattern.ForPattern(source.Tenant.ToString(), "examinations"));
        await using var batch = await directory.BeginAsync(new ProjectionBatchContext(identity,
            await directory.LoadCheckpointAsync(source.Tenant)));

        // Act
        var error = await Record.ExceptionAsync(async () =>
            await directory.ApplyAsync(new TypeIBaselineFrozen(source.Tenant, owner.Current!, changed, changed.UpdatedAt)));

        // Assert
        Assert.IsType<InvalidOperationException>(error);
    }

    sealed class Sources
    {
        public Uuid Tenant { get; } = Uuid.CreateVersion4();
        public Uuid Program { get; } = Uuid.CreateVersion4();
        public Uuid SharedBaseline { get; } = Uuid.CreateVersion4();
        public Uuid SharedAmendment { get; } = Uuid.CreateVersion4();
        public InMemoryEventStore Events { get; } = new();
        public List<ExaminationEngagement> Owners { get; } = [];

        public static async Task<Sources> CreateAsync(bool differentPrograms, bool amend, int ownerCount = 2)
        {
            var source = new Sources();
            var at = new DateTimeOffset(2026, 10, 24, 12, 0, 0, TimeSpan.Zero);
            for (var index = 0; index < ownerCount; index++)
            {
                var program = differentPrograms && index == 1 ? Uuid.CreateVersion4() : source.Program;
                var owner = new ExaminationEngagement(source.Tenant, program, Uuid.CreateVersion4());
                var boundary = Uuid.CreateVersion4();
                var actor = Uuid.CreateVersion4();
                Assert.Null(owner.Create(new ExaminationEngagementContent("type_i", "Audit LLP", new DateOnly(2026, 9, 30),
                    null, ["security"], boundary, []), actor, "Examiner", at));
                var preview = TypeIBaselinePreviewTestFactory.Create(source.Tenant, program, owner.Id,
                    [new TypeIBaselineSourceReference("approved_boundary", boundary, Uuid.CreateVersion4(), 1, new string('b', 64))]);
                Assert.Null(owner.FreezeBaseline(1, source.SharedBaseline, preview, "Confirmed exact source", actor,
                    "Examiner", at.AddMinutes(1)));
                if (amend)
                {
                    var changed = TypeIBaselinePreviewTestFactory.Create(source.Tenant, program, owner.Id,
                        [new TypeIBaselineSourceReference("approved_boundary", boundary, Uuid.CreateVersion4(), 2, new string('c', 64))]);
                    Assert.Null(owner.AmendBaseline(2, source.SharedAmendment, changed, [boundary], [], "Corrected source scope",
                        Uuid.CreateVersion4(), "Approver", at.AddMinutes(2)));
                }
                source.Owners.Add(owner);
                await source.Events.AppendAsync(owner.Stream, 0, NativeFacts.Raised(owner));
            }
            return source;
        }

        public async Task ProjectAsync(FitzExaminationEngagementDirectory directory)
        {
            var pattern = EventStreamPattern.ForPattern(Tenant.ToString(), "examinations");
            var identity = new CheckpointIdentity(FitzExaminationEngagementDirectory.ProjectorName, pattern);
            var before = await directory.LoadCheckpointAsync(Tenant);
            await using var batch = await directory.BeginAsync(new ProjectionBatchContext(identity, before));
            var cursor = EventCursor.Start;
            await foreach (var record in Events.ReadAsync(pattern, cursor, CancellationToken.None))
            {
                await directory.ApplyAsync(record.Event);
                cursor = record.NextCursor;
            }
            await batch.CommitAsync(new ProjectionCheckpoint(cursor));
        }
    }
}
