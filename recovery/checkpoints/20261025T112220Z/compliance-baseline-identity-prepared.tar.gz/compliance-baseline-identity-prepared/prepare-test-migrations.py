from pathlib import Path
root=Path('/tmp/compliance-baseline-identity-prepared/work/test/Compliance.Tests')
# Existing scoped directory callers/fixtures.
p=root/'Features/Examinations/FitzExaminationEngagementDirectoryTests.cs';s=p.read_text().replace('EventStreamPattern.ForPattern(tenantId.ToString()))','EventStreamPattern.ForPattern(tenantId.ToString(), "examinations"))').replace('GetBaselineAsync(tenantId, baseline.TypeIBaselineId)','GetBaselineAsync(tenantId, engagementId, baseline.TypeIBaselineId)').replace('GetBaselineAsync(tenantId, amended.TypeIBaselineId)','GetBaselineAsync(tenantId, engagementId, amended.TypeIBaselineId)').replace('GetBaselineAsync(Uuid.CreateVersion4(),\n            baseline.TypeIBaselineId)','GetBaselineAsync(Uuid.CreateVersion4(), engagementId,\n            baseline.TypeIBaselineId)');p.write_text(s)
for name in ['Features/Examinations/TypeIBaselineCommandHandlerTests.cs','Features/Examinations/PreviewTypeIBaselineHandlerTests.cs']:
 p=root/name;s=p.read_text()
 s=s.replace('GetBaselineAsync(Uuid tenantId, Uuid typeIBaselineId,','GetBaselineAsync(Uuid tenantId, Uuid examinationEngagementId, Uuid typeIBaselineId,').replace('GetBaselineAsync(Uuid tenantId,\n            Uuid typeIBaselineId,','GetBaselineAsync(Uuid tenantId, Uuid examinationEngagementId,\n            Uuid typeIBaselineId,')
 anchor='''        public ExaminationEngagementView? Engagement { get; set; }'''
 addition='''        public ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId, CancellationToken ct = default) =>
            ValueTask.FromResult(ProjectionCheckpoint.Start);
        public ValueTask<IReadOnlyList<TypeIBaselineView>> FindBaselinesAsync(Uuid tenantId, Uuid programId, Uuid typeIBaselineId,
            CancellationToken ct = default) => ValueTask.FromResult<IReadOnlyList<TypeIBaselineView>>([]);
'''
 assert anchor in s;s=s.replace(anchor,anchor+'\n'+addition);p.write_text(s)
p=root/'Features/Examinations/ExaminationEngagementCommandHandlerTests.cs';s=p.read_text()
s=s.replace('new GetTypeIBaselineHandler(fixture.Directory)','new GetTypeIBaselineHandler(fixture.Directory, fixture.Events)')
s=s.replace('public FitzExaminationEngagementDirectory Directory { get; }','public FitzExaminationEngagementDirectory Directory { get; }\n        public InMemoryEventStore Events { get; } = new();')
s=s.replace('services.AddSingleton<IEventStore>(new InMemoryEventStore());','services.AddSingleton<IEventStore>(Events);')
s=s.replace('EventStreamPattern.ForPattern(TenantId.ToString()));','EventStreamPattern.ForPattern(TenantId.ToString(), "examinations"));')
a='''            await batch.CommitAsync(ProjectionCheckpoint.Start);
        }

        public async ValueTask DisposeAsync()'''
b='''            var cursor = EventCursor.Start;
            await foreach (var record in Events.ReadAsync(EventStreamPattern.ForPattern(TenantId.ToString(), "examinations"),
                EventCursor.Start, CancellationToken.None))
                cursor = record.NextCursor;
            await batch.CommitAsync(new ProjectionCheckpoint(cursor));
        }

        public async ValueTask DisposeAsync()'''
assert a in s;s=s.replace(a,b);p.write_text(s)
p=root/'Features/AuditPackages/SnapshotSourcePublicationTests.cs';s=p.read_text()
s=s.replace('new GetTypeIBaselineHandler(directory, fixture.Content)','new GetTypeIBaselineHandler(directory, fixture.PeriodEvents, fixture.Content)').replace('new GetTypeIBaselineHandler(fixture.Directory, fixture.Content)','new GetTypeIBaselineHandler(fixture.Directory, fixture.PeriodEvents, fixture.Content)')
s=s.replace('public EngagementDirectory Directory { get; } = new();','public EngagementDirectory Directory { get; }')
s=s.replace('''        public Fixture()
        {
            var services''','''        public Fixture()
        {
            Directory = new EngagementDirectory(PeriodEvents);
            var services''')
s=s.replace('sealed class EngagementDirectory : IExaminationEngagementDirectoryReader','sealed class EngagementDirectory(IDomainEventReader events) : IExaminationEngagementDirectoryReader')
s=s.replace('''        public ValueTask<TypeIBaselineView?> GetBaselineAsync(Uuid tenantId, Uuid typeIBaselineId,
            CancellationToken ct = default) => ValueTask.FromResult(Baseline);''','''        public ValueTask<TypeIBaselineView?> GetBaselineAsync(Uuid tenantId, Uuid examinationEngagementId, Uuid typeIBaselineId,
            CancellationToken ct = default) => ValueTask.FromResult(Baseline is { } value && value.TenantId == tenantId &&
                value.ExaminationEngagementId == examinationEngagementId && value.TypeIBaselineId == typeIBaselineId ? value : null);
        public ValueTask<IReadOnlyList<TypeIBaselineView>> FindBaselinesAsync(Uuid tenantId, Uuid programId, Uuid typeIBaselineId,
            CancellationToken ct = default) => ValueTask.FromResult<IReadOnlyList<TypeIBaselineView>>(Baseline is { } value &&
                value.TenantId == tenantId && value.ProgramId == programId && value.TypeIBaselineId == typeIBaselineId ? [value] : []);
        public async ValueTask<ProjectionCheckpoint> LoadCheckpointAsync(Uuid tenantId, CancellationToken ct = default)
        {
            var cursor = EventCursor.Start;
            await foreach (var record in events.ReadAsync(EventStreamPattern.ForPattern(tenantId.ToString(), "examinations"), cursor, ct))
                cursor = record.NextCursor;
            return new ProjectionCheckpoint(cursor);
        }''')
p.write_text(s)
print('Migrated original acceptance fixtures and internal scoped getters without removing tests.')
