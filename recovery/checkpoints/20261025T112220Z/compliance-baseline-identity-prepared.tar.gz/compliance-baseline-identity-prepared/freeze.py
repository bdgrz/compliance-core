from pathlib import Path
import hashlib,difflib,json,subprocess,shutil
root=Path('/tmp/compliance-baseline-identity-prepared');repo=Path('/Users/jrepanich/Code/bdgrz/compliance-core')
paths=sorted(str(f.relative_to(root/'work')) for f in (root/'work').rglob('*.cs'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
read=lambda p:p.read_text() if p.exists() else ''
def diff(a,b,names):
 out=[]
 for n in names:
  x,y=a/n,b/n
  out.extend(difflib.unified_diff(read(x).splitlines(keepends=True),read(y).splitlines(keepends=True),fromfile='a/'+n if x.exists() else '/dev/null',tofile='b/'+n if y.exists() else '/dev/null'))
 return ''.join(out)
source=[p for p in paths if p.startswith('src/')];tests=[p for p in paths if p.startswith('test/')]
for name,selected in [('full.patch',paths),('implementation.patch',source),('tests.patch',tests)]:
 (root/name).write_text(diff(root/'base',root/'work',selected))
empty=root/'empty';empty.mkdir(exist_ok=True)
redpaths=sorted(str(f.relative_to(root/'red')) for f in (root/'red').rglob('*.cs'))
(root/'behavioral-red.patch').write_text(diff(empty,root/'red',redpaths))
redbase=root/'red-base'
if redbase.exists():shutil.rmtree(redbase)
shutil.copytree(root/'base',redbase)
for n in redpaths:
 dst=redbase/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/'red'/n,dst)
(root/'after-red.patch').write_text(diff(redbase,root/'work',paths))
checks=[]
for patch,before,expected,names in [('full.patch',root/'base',root/'work',paths),('behavioral-red.patch',empty,root/'red',redpaths),('after-red.patch',redbase,root/'work',paths)]:
 verify=root/('verify-'+patch.removesuffix('.patch'))
 if verify.exists():shutil.rmtree(verify)
 shutil.copytree(before,verify)
 r=subprocess.run(['patch','--batch','-p1'],cwd=verify,input=(root/patch).read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 mismatches=[n for n in names if sha(verify/n)!=sha(expected/n)]
 assert r.returncode==0 and not mismatches,(patch,r.stdout.decode(),mismatches)
 checks.append({'patch':patch,'exit_code':r.returncode,'mismatches':mismatches})
manifest=[{'path':n,'before_sha256':sha(root/'base'/n),'after_sha256':sha(root/'work'/n),'current_main_matches_before':sha(repo/n)==sha(root/'base'/n)} for n in paths]
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'red-filter.txt').write_text('FullyQualifiedName~TypeIBaselineScopedIdentityTests\n')
(root/'target-filter.txt').write_text('FullyQualifiedName~TypeIBaselineScopedIdentityTests|FullyQualifiedName~FitzExaminationEngagementDirectoryTests|FullyQualifiedName~ExaminationEngagementCommandHandlerTests|FullyQualifiedName~TypeIBaselineCommandHandlerTests|FullyQualifiedName~PreviewTypeIBaselineHandlerTests|FullyQualifiedName~SnapshotSourcePublicationTests\n')
h={'status':'offline_prepared_not_compiled_or_executed','paths':len(paths),'source_paths':len(source),'test_paths':len(tests),'old_api_red_rows':5,'new_final_behavior_rows':11,'source_owner':'tenant/examinations/{engagementId}; BaselineId is local to that owner','public_contract':'GetTypeIBaseline(TenantId,ProgramId,TypeIBaselineId) and route unchanged; two owning matches within program return permanent Conflict','changes':['baseline primary key and amendment predecessor lookup include engagement+baseline','bounded program+baseline locator retains up to two engagement matches','query verifies current native tenant/examinations checkpoint before and after discovery','projector/store/read fence agree on exact tenant examination area in fresh projection v3','same-baseline replay also compares immutable source publication proof descriptor'],'internal_ctor_delta':'GetTypeIBaselineHandler(directory, IDomainEventReader events, IImmutableContentStore? content = null); production DI already resolves the event reader','internal_port_delta':'IExaminationEngagementDirectoryReader adds LoadCheckpointAsync and FindBaselinesAsync; GetBaselineAsync now includes examinationEngagementId','shared_wiring_deltas':[],'preserved':['baseline IDs','amendment predecessor IDs and depth','source reference IDs and digests','canonical manifest preimages','source publication content/proof identities','public request DTO/route/discriminator','program authorization pipeline'],'apply_order':['apply behavioral-red.patch alone to unchanged baseline; run red-filter.txt','apply after-red.patch directly on RED state; run target-filter.txt','alternatively apply full.patch from unchanged baseline'],'patches':{n:sha(root/n) for n in ['behavioral-red.patch','after-red.patch','implementation.patch','tests.patch','full.patch']},'reconstruction':checks,'main_drift':[row['path'] for row in manifest if not row['current_main_matches_before']],'qualification':['Fresh v3 projection requires full examination-source replay; old v2 rows/checkpoints remain intact. No inferred aliases or in-place migration authority.','Public request has no engagement identity, so ambiguity stays a Conflict; no new public routing or global BaselineId uniqueness is claimed.','This does not compact ExaminationEngagement command state or qualify every legacy persisted stream; those are separate owner work.']}
(root/'handoff.json').write_text(json.dumps(h,indent=2)+'\n')
print(json.dumps({'paths':len(paths),'source':len(source),'tests':len(tests),'old_api_red_rows':5,'new_final_rows':11,'exact_reconstruction':checks,'main_drift':h['main_drift']},indent=2))
